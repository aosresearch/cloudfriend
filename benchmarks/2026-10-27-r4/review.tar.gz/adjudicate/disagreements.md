## p0689
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-12T06:44:32.074Z
```
{"service":"mobservice1","message":"2021-08-12 06:44:32,074 | WARNING | 0.0.0.1 | 172.17.0.5 | mobservice1 | a27e0e3748d14b9d | wait for 11 seconds for follow-up operations to simulate the login failure of the QR code expired"}
```
Same service, the 2 minutes before (oldest first):
  06:44:25.370 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  06:44:25.371 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'ad921dec-faf5-11eb-9c7e-0242ac110003'}  (×4)
  06:44:25.436 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'ad921dec-faf5-11eb-9c7e-0242ac110003', 'value': 'cCODHfIu'}  (×4)
  06:44:25.496 [mobservice1] INFO info ad921dec-faf5-11eb-9c7e-0242ac110003:cCODHfIu write success
  06:44:28.055 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  06:44:28.189 [mobservice1] INFO info af2cb46e-faf5-11eb-9c50-0242ac110003:hpcKRNdx write success
  06:44:29.704 [mobservice1] INFO info b01a7b86-faf5-11eb-ac48-0242ac110004:TIjYgWhS write success
  06:44:31.339 [mobservice1] INFO info b10f7cee-faf5-11eb-af3a-0242ac110003:MBoWvOAG write success
All services, 30 seconds either side (sampled):
  06:44:02.163 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  06:44:02.330 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×42)
  06:44:02.458 [logservice2] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': '9fb91086-faf5-11eb-9108-0242ac110003', 'user_id': 'CeJfdxpR'}  (×79)
  06:44:02.731 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'a03d7fb0-faf5-11eb-ad34-0242ac110003', 'value': '', 'ex': 10}  (×41)
  06:44:03.181 [logservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×38)
  06:44:03.424 [dbservice2] INFO a03d7fb0-faf5-11eb-ad34-0242ac110003-bGtJCiAM-5{+Aa/EZ2QN( token generate success token=MTYyODcyMTg0My40MjQyMDg2OmEwM2Q3ZmIwLWZhZjUtMTFlYi1hZDM0LTAyNDJhYzE
  06:44:03.703 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×38)
  06:44:06.511 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'a24f1de0-faf5-11eb-8837-0242ac110003', 'value': 'pKxfZBio'}  (×35)
  06:44:09.917 [dbservice1] INFO a405d4da-faf5-11eb-ae05-0242ac110003-zLGEjrhw-D*Rm7c>0WY.N token generate success token=MTYyODcyMTg0OS45MTcyNjY0OmE0MDVkNGRhLWZhZjUtMTFlYi1hZTA1LTAyNDJhYzE
  06:44:12.891 [dbservice2] INFO a5cff034-faf5-11eb-b23f-0242ac110004-VMivmOPL-_z$IfwVSs+#T token generate success token=MTYyODcyMTg1Mi44OTEwMzE1OmE1Y2ZmMDM0LWZhZjUtMTFlYi1iMjNmLTAyNDJhYzE
  06:44:15.604 [dbservice2] INFO a77b881c-faf5-11eb-983c-0242ac110003-UfMpdlBq-fL(<c!OYDx@^ token generate success token=MTYyODcyMTg1NS42MDM3NDE2OmE3N2I4ODFjLWZhZjUtMTFlYi05ODNjLTAyNDJhYzE
  06:44:18.267 [mobservice2] INFO info a944daf4-faf5-11eb-8679-0242ac110004:xcEhGPZd write success
  06:44:20.820 [mobservice2] INFO info aac99248-faf5-11eb-9202-0242ac110004:kXfZVAUx write success
  06:44:23.506 [dbservice2] ERROR password in database of {user} is null, the user is not registered
  06:44:25.920 [dbservice1] INFO ad921dec-faf5-11eb-9c7e-0242ac110003-cCODHfIu-x6(1%5_Mw>&: token generate success token=MTYyODcyMTg2NS45MTk5NzIyOmFkOTIxZGVjLWZhZjUtMTFlYi05YzdlLTAyNDJhYzE
  06:44:28.189 [mobservice1] INFO info af2cb46e-faf5-11eb-9c50-0242ac110003:hpcKRNdx write success
  06:44:31.339 [mobservice1] INFO info b10f7cee-faf5-11eb-af3a-0242ac110003:MBoWvOAG write success
  06:44:34.665 [mobservice1] INFO info b3041ffa-faf5-11eb-9e2f-0242ac110003:mwbCGSva write success
  06:44:38.037 [mobservice2] INFO info b510e3dc-faf5-11eb-973d-0242ac110004:DjXaKYNR write success
  06:44:41.281 [mobservice1] INFO info b6fea062-faf5-11eb-af19-0242ac110004:KmknXdcJ write success
  06:44:43.267 [redisservice2] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400
  06:44:46.159 [dbservice2] INFO b9a56288-faf5-11eb-964a-0242ac110003-mTjXOuZo-G/o^jX*g(<l9 token generate success token=MTYyODcyMTg4Ni4xNTkzOTM6YjlhNTYyODgtZmFmNS0xMWViLTk2NGEtMDI0MmFjMTE
  06:44:49.096 [mobservice2] INFO info bba3b2c4-faf5-11eb-8cb0-0242ac110003:CMzFsYZh write success
  06:44:51.625 [mobservice2] INFO info bd2aba48-faf5-11eb-a10e-0242ac110003:kWcbAndl write success
  06:44:54.547 [mobservice2] INFO info bed8ce66-faf5-11eb-81e5-0242ac110004:oneLisuW write success
  06:44:56.917 [mobservice2] INFO info c055e7d8-faf5-11eb-9b09-0242ac110004:DHpIOPcr write success
  06:44:59.745 [dbservice2] INFO c1ce60e0-faf5-11eb-87fe-0242ac110004-ALRXkDds-%t(^UlzPXqY& token generate success token=MTYyODcyMTg5OS43NDUzMzE6YzFjZTYwZTAtZmFmNS0xMWViLTg3ZmUtMDI0MmFjMTE

Reviewer A: benign (0.55): WARNING says mobservice is waiting in order to simulate an expired-QR login failure, which is a deliberate workload behaviour rather than a fault. It is still a warning about a failed login path, so confidence is moderate.
Reviewer B: relevant (0.5): WARNING that the service is deliberately delaying to produce a QR-code-expired login failure; a QR-expired error from redisservice2 follows in context, so this marks an induced login failure.


## p0584
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:41.179Z
```
{"timestamp":1733596301179031800,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:41.178  INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl       : nullUSER TOKEN"}
```
Same service, the 2 minutes before (oldest first):
  18:31:30.676 [ts-auth-service] 2024-12-07 18:31:30.675 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×4)
  18:31:30.676 [ts-auth-service] 2024-12-07 18:31:30.676 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×4)
  18:31:31.064 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null
  18:31:31.065 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID
  18:31:36.611 [ts-auth-service] 2024-12-07 18:31:36.611 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null
  18:31:36.611 [ts-auth-service] 2024-12-07 18:31:36.611 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:31:37.923 [ts-auth-service] 2024-12-07 18:31:37.922 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×3)
  18:31:37.923 [ts-auth-service] 2024-12-07 18:31:37.922 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×3)
All services, 30 seconds either side (sampled):
  18:31:11.514 [ts-admin-basic-info-service] 2024-12-07 18:31:11.514 INFO 1 --- [io-18767-exec-9] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×2)
  18:31:11.600 [ts-travel-service] 2024-12-07 18:31:11.600 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×7)
  18:31:11.625 [ts-basic-service] 2024-12-07 18:31:11.625 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×3)
  18:31:11.643 [ts-basic-service] 2024-12-07 18:31:11.643 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×4)
  18:31:11.663 [ts-order-service] 2024-12-07 18:31:11.663 INFO 1 --- [io-12031-exec-6] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×3)
  18:31:11.717 [ts-order-service] 2024-12-07 18:31:11.716 INFO 1 --- [io-12031-exec-5] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×5)
  18:31:11.814 [ts-seat-service] 2024-12-07 18:31:11.814 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×3)
  18:31:11.991 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:11 +0800] "POST /api/v1/users/login HTTP/1.1" 503 19 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel M  (×2)
  18:31:12.083 [ts-seat-service] 2024-12-07 18:31:12.083 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN
  18:31:12.102 [ts-travel2-service] 2024-12-07 18:31:12.102 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  18:31:12.157 [ts-seat-service] 2024-12-07 18:31:12.157 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×2)
  18:31:12.212 [ts-travel-service] 2024-12-07 18:31:12.212 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×2)
  18:31:12.292 [ts-basic-service] 2024-12-07 18:31:12.291 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan
  18:31:12.472 [ts-travel-service] 2024-12-07 18:31:12.472 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×2)
  18:31:13.839 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:13 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 403 145 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×11)
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  18:31:18.568 [ts-auth-service] 2024-12-07 18:31:18.568 INFO 1 --- [io-12340-exec-3] org.mongodb.driver.connection : Opened connection [connectionId{localValue:3, serverValue:22}] to ts-auth-m  (×2)
  18:31:19.324 [ts-travel-service] 2024-12-07 18:31:19.323 INFO 1 --- [io-12346-exec-5] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  18:31:19.687 [ts-travel2-service] 2024-12-07 18:31:19.687 ERROR 1 --- [o-16346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  18:31:27.403 [ts-travel-mongo] {"t":{"$date":"2024-12-07T18:31:27.403+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.268 [ts-admin-travel-service] 2024-12-07 18:31:28.268 ERROR 1 --- [io-16114-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×8)
  18:31:29.841 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:31:29.841+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:30.519 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T18:31:30.518+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:31.065 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×2)
  18:31:32.280 [ts-admin-basic-info-service] 2024-12-07 18:31:32.280 ERROR 1 --- [io-18767-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×13)
  18:31:42.161 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T18:31:42.161+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359630
  18:31:51.505 [ts-food-service] 2024-12-07 18:31:51.504 ERROR 1 --- [io-18856-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)

Reviewer A: benign (0.6): 'nullUSER TOKEN' is the auth service's normal debug output during login. Login 503s and an auth-service restart appear nearby, but this line does not report them.
Reviewer B: relevant (0.65): The auth service logs a null user token, whereas this line normally carries a JWT; this fits the MalformedJwt 'Found: 0' errors and login 503s seen in context.


## p0795
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-08T08:40:04.161Z
```
{"timestamp":1733647204161974300,"container_name":"ts-auth-service","pod_name":"ts-auth-service-75dfb9459b-qsspl","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 08:40:04.161  INFO 1 --- [       Thread-5] o.s.i.endpoint.EventDrivenConsumer       : stopped _org.springframework.integration.errorLogger"}
```
Same service, the 2 minutes before (oldest first):
  08:39:54.481 [ts-auth-service] 2024-12-08 08:39:54.481 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  08:39:54.481 [ts-auth-service] 2024-12-08 08:39:54.481 INFO 1 --- [io-12340-exec-8] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  08:39:54.666 [ts-auth-service] 2024-12-08 08:39:54.666 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×4)
  08:39:54.666 [ts-auth-service] 2024-12-08 08:39:54.666 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : 4c7ef37c-e8cb-4d29-aaca-62bd7a8da985 USER ID  (×4)
  08:39:58.201 [ts-auth-service] 2024-12-08 08:39:58.201 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×3)
  08:39:58.201 [ts-auth-service] 2024-12-08 08:39:58.201 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×3)
  08:40:04.157 [ts-auth-service] 2024-12-08 08:40:04.156 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  08:40:04.159 [ts-auth-service] 2024-12-08 08:40:04.158 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  08:40:04.160 [ts-auth-service] 2024-12-08 08:40:04.160 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  08:40:04.161 [ts-auth-service] 2024-12-08 08:40:04.161 INFO 1 --- [ Thread-5] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 0 subscriber(s).
All services, 30 seconds either side (sampled):
  08:39:34.456 [ts-food-service] 2024-12-08 08:39:34.456 INFO 1 --- [io-18856-exec-2] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×3)
  08:39:34.706 [ts-admin-basic-info-service] 2024-12-08 08:39:34.705 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  08:39:39.176 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:39:39 +0800] "POST /api/v1/users/login HTTP/1.1" 200 380 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×10)
  08:39:39.262 [ts-basic-service] 2024-12-08 08:39:39.262 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×21)
  08:39:39.290 [ts-order-other-service] 2024-12-08 08:39:39.290 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:0  (×13)
  08:39:39.367 [ts-order-other-service] 2024-12-08 08:39:39.366 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=208356  (×13)
  08:39:39.519 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:39:39 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 356 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×16)
  08:39:41.578 [ts-travel-service] 2024-12-08 08:39:41.577 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×8)
  08:39:41.626 [ts-basic-service] 2024-12-08 08:39:41.626 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×12)
  08:39:41.672 [ts-travel-service] 2024-12-08 08:39:41.672 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, tr  (×12)
  08:39:41.853 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:39:41 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 200 119 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
  08:39:41.966 [ts-security-service] 2024-12-08 08:39:41.966 INFO 1 --- [io-11188-exec-7] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....
  08:39:42.077 [ts-preserve-service] 2024-12-08 08:39:42.077 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Contacts Id: 47e015f5-6a9d-41ce-9b3a-e09
  08:39:42.155 [ts-basic-service] 2024-12-08 08:39:42.155 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe  (×3)
  08:39:42.349 [ts-seat-service] 2024-12-08 08:39:42.349 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×4)
  08:39:42.459 [ts-travel-service] 2024-12-08 08:39:42.459 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×2)
  08:39:42.495 [ts-preserve-service] 2024-12-08 08:39:42.494 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service][Order Price] Price is: 50.0
  08:39:42.518 [ts-preserve-service] 2024-12-08 08:39:42.518 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service][Add food Order] Creating....
  08:39:45.651 [ts-order-other-service] 2024-12-08 08:39:45.650 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=208356
  08:39:50.849 [ts-travel2-service] 2024-12-08 08:39:50.849 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×18)
  08:39:55.072 [ts-seat-service] 2024-12-08 08:39:55.072 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×5)
  08:39:55.599 [ts-travel-service] 2024-12-08 08:39:55.598 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1236
  08:40:01.457 [ts-travel2-service] 2024-12-08 08:40:01.457 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×3)
  08:40:04.165 [ts-auth-service] 2024-12-08 08:40:04.165 INFO 1 --- [ Thread-5] o.s.j.e.a.AnnotationMBeanExporter : Unregistering JMX-exposed beans on shutdown
  08:40:09.576 [ts-train-mongo] {"t":{"$date":"2024-12-08T08:40:09.576+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364720
  08:40:09.978 [ts-config-mongo] {"t":{"$date":"2024-12-08T08:40:09.978+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364720
  08:40:12.489 [ts-food-map-mongo] {"t":{"$date":"2024-12-08T08:40:12.488+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364721
  08:40:26.028 [ts-basic-service] 2024-12-08 08:40:26.028 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  08:40:30.988 [ts-auth-service] 2024-12-08 08:40:30.988 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'objectPostProcessor' of type [org.springframework.security.config.an

Reviewer A: benign (0.55): One line of a graceful Spring shutdown of ts-auth-service (stopping the errorLogger endpoint), followed by a normal restart in context. The line itself reports no error, but whether the restart was planned can't be seen.
Reviewer B: unsure (0.5): Graceful shutdown line of ts-auth-service (stopping the errorLogger) followed by a restart; the packet does not show whether this is a planned rollout or an unexpected restart that takes auth offline.


## p0783
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service payment, 2024-11-24T13:44:24.857Z
```
{"timestamp":1732455864857422000,"container_name":"payment","pod_name":"payment-78bf948dc4-fxv9x","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-24T13:44:24Z caller=logging.go:29 method=Authorise result=false took=5.502µs"}
```
Same service, the 2 minutes before (oldest first):
  13:44:10.738 [payment] ts=2024-11-24T13:44:10Z caller=logging.go:29 method=Authorise result=true took=707ns  (×9)
  13:44:13.039 [payment] ts=2024-11-24T13:44:13Z caller=logging.go:40 method=Health result=1 took=5.595µs  (×8)
  13:44:13.244 [payment] ts=2024-11-24T13:44:13Z caller=logging.go:29 method=Authorise result=true took=1.181µs  (×2)
  13:44:17.864 [payment] ts=2024-11-24T13:44:17Z caller=logging.go:29 method=Authorise result=false took=5.657µs
All services, 30 seconds either side (sampled):
  13:43:55.009 [front-end] Posting Customer: {"username":"bmZgCJWzTSCseXx","password":"RPOnxdhpv","email":"bmZgCJWzTSCseXx@gmail.com","firstName":"bmZgCJWzTSCseXx","lastName":"bmZgCJWzTSC
  13:43:55.050 [front-end] GET /catalogue 200 - ms - -  (×59)
  13:43:55.224 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67432  (×60)
  13:43:55.250 [shipping] Adding shipment to queue...  (×53)
  13:43:55.278 [carts] 2024-11-24 13:43:55.277 INFO [carts,e6c445d7e113d9b4,1f767d45e54e83bc,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.controllers.ItemsController : Did not find item.  (×40)
  13:43:55.916 [orders] 2024-11-24 13:43:55.915 INFO [orders,fca1b15d23ed4a63,6e5b7ea83cb95771,false] 7 --- [p-nio-80-exec-2] w.w.s.o.controllers.OrdersController : Received payment re  (×45)
  13:43:57.963 [front-end] Received response: "{\"firstName\":\"FscbswrMi\",\"lastName\":\"FscbswrMi\",\"username\":\"FscbswrMi\",\"id\":\"67432d8df6d875000162061f\",\"_links\":{\"address
  13:44:00.075 [front-end] Received response: "{\"firstName\":\"voZAjzQbwxx\",\"lastName\":\"voZAjzQbwxx\",\"username\":\"voZAjzQbwxx\",\"id\":\"67432d92f6d875000162062d\",\"_links\":{\"a
  13:44:02.147 [front-end] Order response: {"id":"67432da2c4380300078a49a9","customerId":"67432d8ef6d8750001620625","customer":{"id":null,"firstName":"oPLiAGKNlVdYA","lastName":"oPLiAGKNl
  13:44:03.765 [queue-master] 2024-11-24 13:44:03.765 ERROR 7 --- [pool-6-thread-2] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×9)
  13:44:05.294 [front-end] Received response: "{\"firstName\":\"EuTjoz\",\"lastName\":\"EuTjoz\",\"username\":\"EuTjoz\",\"id\":\"67432d97f6d875000162063c\",\"_links\":{\"addresses\":{\"h
  13:44:07.525 [user] ts=2024-11-24T13:44:07.525535758Z caller=middlewares.go:46 method=Register username=jimOXULBw email=jimOXULBw@gmail.com took=1.794445ms
  13:44:09.538 [front-end] Order response: {"id":"67432da9c4380300078a49b3","customerId":"67432d94f6d8750001620634","customer":{"id":null,"firstName":"xnwJWG","lastName":"xnwJWG","usernam
  13:44:11.148 [user] ts=2024-11-24T13:44:11.147905313Z caller=middlewares.go:46 method=Register username=xuBmYTBRh email=xuBmYTBRh@gmail.com took=2.034475ms
  13:44:13.257 [front-end] Order response: {"statusCode":201,"body":{"id":"67432dadc4380300078a49b9","customerId":"67432d9bf6d8750001620646","customer":{"id":null,"firstName":"bmZgCJWzTSC
  13:44:17.059 [front-end] Posting Customer: {"username":"QJcmDDccjPBklKc","password":"Djqxap","email":"QJcmDDccjPBklKc@gmail.com","firstName":"QJcmDDccjPBklKc","lastName":"QJcmDDccjPBklK
  13:44:21.992 [front-end] Received response: "{\"firstName\":\"sVAFwkKPFH\",\"lastName\":\"sVAFwkKPFH\",\"username\":\"sVAFwkKPFH\",\"id\":\"67432d9ef6d875000162065d\",\"_links\":{\"addr
  13:44:22.782 [front-end] Order response: {"id":"67432db6c4380300078a49bf","customerId":"67432da3f6d8750001620669","customer":{"id":null,"firstName":"fzmtXvultKAzW","lastName":"fzmtXvult
  13:44:29.366 [front-end] Posting Customer: {"username":"IzSgX","password":"KHLVTeVp","email":"IzSgX@gmail.com","firstName":"IzSgX","lastName":"IzSgX"}
  13:44:32.582 [front-end] Order response: {"id":"67432dc0c4380300078a49c4","customerId":"67432dadf6d8750001620680","customer":{"id":null,"firstName":"pAhYLwzaPNwMQ","lastName":"pAhYLwzaP
  13:44:34.998 [front-end] Received response: "{\"firstName\":\"dcazMJhNaHMDhN\",\"lastName\":\"dcazMJhNaHMDhN\",\"username\":\"dcazMJhNaHMDhN\",\"id\":\"67432db0f6d8750001620689\",\"_lin
  13:44:36.410 [front-end] Posting Customer: {"username":"sJYobZOTxjEclja","password":"OKVLR","email":"sJYobZOTxjEclja@gmail.com","firstName":"sJYobZOTxjEclja","lastName":"sJYobZOTxjEclja
  13:44:38.731 [front-end] Order response: {"statusCode":201,"body":{"id":"67432dc6c4380300078a49cd","customerId":"67432db5f6d875000162069d","customer":{"id":null,"firstName":"bBxUoRFNHZp
  13:44:39.488 [front-end] Received response: "{\"firstName\":\"vKeqjLcHflbSm\",\"lastName\":\"vKeqjLcHflbSm\",\"username\":\"vKeqjLcHflbSm\",\"id\":\"67432db7f6d87500016206aa\",\"_links\
  13:44:43.343 [front-end] Order response: {"statusCode":201,"body":{"id":"67432dcbc4380300078a49d2","customerId":"67432db6f6d87500016206a1","customer":{"id":null,"firstName":"UPpAcuiDEgz
  13:44:47.705 [front-end] Posting Customer: {"username":"rGDTXEMY","password":"egXBpcn","email":"rGDTXEMY@gmail.com","firstName":"rGDTXEMY","lastName":"rGDTXEMY"}
  13:44:50.603 [front-end] Order response: {"statusCode":201,"body":{"id":"67432dd2c4380300078a49d3","customerId":"67432dbdf6d87500016206b7","customer":{"id":null,"firstName":"IzSgX","las
  13:44:52.704 [front-end] Order response: {"statusCode":201,"body":{"id":"67432dd4c4380300078a49d5","customerId":"67432dbaf6d87500016206af","customer":{"id":null,"firstName":"ZpZtfLtSzSv

Reviewer A: relevant (0.55): Payment Authorise returned result=false, which means a payment authorisation failed. It may be a business-rule decline, but the packet doesn't show the reason.
Reviewer B: benign (0.55): A single payment authorisation returned result=false while most return true; this looks like an ordinary business decline, not a service fault. Nothing in the context ties it to a payment failure.


## p0006
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-13T01:00:31.559Z
```
{"service":"mobservice1","message":"2021-08-13 01:00:31,559 | ERROR | 0.0.0.1 | mobservice1 | mob_helper.py -> mob_info_to_redis -> 88 | b35f8795a1f4686e | uuid:c6aa7df8-fb8e-11eb-b1c5-0242ac110004 information has expired, mobile phone login is invalid"}
```
Same service, the 2 minutes before (oldest first):
  01:00:23.241 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  01:00:23.241 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'c8575360-fb8e-11eb-aadd-0242ac110003'}  (×5)
  01:00:23.286 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'c8575360-fb8e-11eb-aadd-0242ac110003', 'value': 'tWMvxnLr'}  (×3)
  01:00:23.331 [mobservice1] INFO info c8575360-fb8e-11eb-aadd-0242ac110003:tWMvxnLr write success
  01:00:24.946 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  01:00:25.063 [mobservice1] INFO info c9593f08-fb8e-11eb-a834-0242ac110004:GxrcRlDj write success
  01:00:30.907 [mobservice1] INFO info ccd7cd66-fb8e-11eb-81ad-0242ac110003:Xkwacyxi write success
All services, 30 seconds either side (sampled):
  01:00:01.561 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×35)
  01:00:01.890 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  01:00:02.109 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  01:00:02.393 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×35)
  01:00:02.681 [webservice1] ERROR an error occurred in the downstream service
  01:00:02.961 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  01:00:03.329 [redisservice2] INFO redis读取信息成功, status_code: 200  (×42)
  01:00:03.486 [dbservice2] INFO query = select passwards from username_table where user_name='sjignBZH'  (×39)
  01:00:05.658 [mobservice2] INFO info bdcb51a8-fb8e-11eb-b7cd-0242ac110004:rDnqUwke write success
  01:00:08.147 [mobservice1] INFO info bf4807e2-fb8e-11eb-a34f-0242ac110003:AnasJGMP write success
  01:00:10.662 [mobservice1] INFO info c0bf6c32-fb8e-11eb-9216-0242ac110004:wKjLqdJi write success
  01:00:13.037 [mobservice1] INFO info c2322e56-fb8e-11eb-bf61-0242ac110004:cUsPLdAz write success
  01:00:15.496 [mobservice2] INFO info c3a3423e-fb8e-11eb-a22d-0242ac110003:EAoGeZwV write success
  01:00:18.192 [mobservice1] INFO info c5396b0a-fb8e-11eb-9ec5-0242ac110003:riyTUAVs write success
  01:00:22.041 [dbservice1] INFO c74ba32c-fb8e-11eb-972e-0242ac110004-XUtTqLre-dtbi.SgcZV?! token generate success token=MTYyODc4NzYyMi4wNDEzODczOmM3NGJhMzJjLWZiOGUtMTFlYi05NzJlLTAyNDJhYzE
  01:00:25.468 [dbservice2] INFO c9593f08-fb8e-11eb-a834-0242ac110004-GxrcRlDj-Lw{tNT75j/%g token generate success token=MTYyODc4NzYyNS40Njc1MzAzOmM5NTkzZjA4LWZiOGUtMTFlYi1hODM0LTAyNDJhYzE
  01:00:32.046 [dbservice2] INFO cd445fa8-fb8e-11eb-9212-0242ac110004-TebkoQLO-YN(rC/LgHR*? token generate success token=MTYyODc4NzYzMi4wNDYzMTc4OmNkNDQ1ZmE4LWZiOGUtMTFlYi05MjEyLTAyNDJhYzE
  01:00:34.483 [dbservice1] INFO cec3bb8a-fb8e-11eb-8eaf-0242ac110003-ZQXfBztT-3J}/s50kecn{ token generate success token=MTYyODc4NzYzNC40ODM0MTI3OmNlYzNiYjhhLWZiOGUtMTFlYi04ZWFmLTAyNDJhYzE  (×2)
  01:00:37.123 [mobservice1] INFO info d08b5c2a-fb8e-11eb-8b77-0242ac110003:UfMpdlBq write success
  01:00:39.924 [mobservice1] INFO info d2397156-fb8e-11eb-9b8a-0242ac110003:tdfCvYKb write success
  01:00:42.745 [mobservice2] INFO info d3df3e46-fb8e-11eb-b4ec-0242ac110004:xgpqRfCn write success
  01:00:45.420 [mobservice1] INFO info d56e84c4-fb8e-11eb-b4db-0242ac110003:RcoJYnsh write success
  01:00:48.517 [mobservice2] INFO info d7582790-fb8e-11eb-977e-0242ac110003:aFPAvDqO write success
  01:00:51.457 [mobservice2] INFO info d9129db8-fb8e-11eb-ad4b-0242ac110004:iOlErWzF write success
  01:00:54.215 [mobservice1] INFO info dabe5472-fb8e-11eb-950f-0242ac110003:UVDQSlfP write success
  01:00:56.596 [mobservice2] INFO info dc28e7dc-fb8e-11eb-bf11-0242ac110003:CyQWkovZ write success
  01:00:59.922 [mobservice1] INFO info de272c7e-fb8e-11eb-8cb7-0242ac110004:GOhWXRIV write success

Reviewer A: relevant (0.55): ERROR in mobservice1: the login info expired and the mobile phone login was invalid, so a user login failed. It may be ordinary QR-code expiry, hence the low confidence.
Reviewer B: benign (0.5): Logged as ERROR, but it is an expired QR-login session (normal TTL expiry in this login flow). Nothing in the context shows a system fault causing it.


## p0034
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-13T07:53:39.332Z
```
{"service":"mobservice2","message":"2021-08-13 07:53:39,332 | ERROR | 0.0.0.4 | mobservice2 | mob_helper.py -> mob_info_to_redis -> 88 | 94302efe6f18271 | uuid:7d56e5d0-fbc8-11eb-9453-0242ac110004 information has expired, mobile phone login is invalid"}
```
Same service, the 2 minutes before (oldest first):
  07:53:28.316 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '7d5e06c6-fbc8-11eb-b1fa-0242ac110003', 'value': 'zxoeJtIu'}  (×4)
  07:53:28.367 [mobservice2] INFO info 7d5e06c6-fbc8-11eb-b1fa-0242ac110003:zxoeJtIu write success
  07:53:29.099 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  07:53:29.099 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  07:53:29.100 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '7de0a428-fbc8-11eb-862b-0242ac110003'}  (×4)
  07:53:29.202 [mobservice2] INFO info 7de0a428-fbc8-11eb-862b-0242ac110003:GNqpIFum write success
  07:53:31.754 [mobservice2] INFO info 7f642e78-fbc8-11eb-b764-0242ac110003:tRLZzuQg write success
  07:53:36.812 [mobservice2] INFO info 8267eaf6-fbc8-11eb-9fb0-0242ac110004:jSevQlNq write success
All services, 30 seconds either side (sampled):
  07:53:09.393 [redisservice1] INFO redis write success  (×77)
  07:53:09.625 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×35)
  07:53:09.835 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×32)
  07:53:09.973 [redisservice2] INFO service accept, status_code: 200  (×45)
  07:53:10.395 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '72b54090-fbc8-11eb-aba8-0242ac110004'}  (×49)
  07:53:11.197 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×49)
  07:53:11.406 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×42)
  07:53:12.124 [webservice1] INFO uuid: 73d70bf2-fbc8-11eb-a1b3-0242ac110003 write redis successfully  (×41)
  07:53:13.925 [mobservice1] INFO info 74c27178-fbc8-11eb-95ac-0242ac110004:QSUqdTsv write success
  07:53:16.180 [mobservice2] INFO info 7620fa76-fbc8-11eb-92f1-0242ac110003:xgKipZPG write success
  07:53:18.499 [mobservice2] INFO info 777d886c-fbc8-11eb-a15b-0242ac110004:iBnyvbLP write success
  07:53:20.915 [mobservice2] INFO info 78ef63d2-fbc8-11eb-9543-0242ac110003:IcmKxDtR write success  (×2)
  07:53:23.455 [mobservice1] INFO info 7a71bc46-fbc8-11eb-ba06-0242ac110003:zwDGqUsI write success
  07:53:26.154 [dbservice2] INFO 7bd27d32-fbc8-11eb-94d7-0242ac110003-rnAReBSk-Wjgud#1.N>^z token generate success token=MTYyODgxMjQwNi4xNTQzMzM0OjdiZDI3ZDMyLWZiYzgtMTFlYi05NGQ3LTAyNDJhYzE
  07:53:29.599 [dbservice1] INFO 7de0a428-fbc8-11eb-862b-0242ac110003-GNqpIFum-6p{Revl/Jr90 token generate success token=MTYyODgxMjQwOS41OTg3NzU5OjdkZTBhNDI4LWZiYzgtMTFlYi04NjJiLTAyNDJhYzE
  07:53:32.661 [mobservice1] INFO info 7fe4ffd0-fbc8-11eb-ac16-0242ac110003:THZxeBPz write success
  07:53:36.063 [mobservice1] INFO info 81e81e5c-fbc8-11eb-8d9c-0242ac110003:nAxhWmpD write success
  07:53:42.326 [dbservice2] INFO 856f7cbe-fbc8-11eb-8136-0242ac110003-tJwGvlrd-_X.0m+hp>Z-/ token generate success token=MTYyODgxMjQyMi4zMjY1MDQ1Ojg1NmY3Y2JlLWZiYzgtMTFlYi04MTM2LTAyNDJhYzE
  07:53:46.116 [mobservice2] INFO info 87f2fae2-fbc8-11eb-afa4-0242ac110004:edQqtaui write success
  07:53:48.657 [mobservice1] INFO info 8976f59e-fbc8-11eb-954b-0242ac110003:jliMGRSf write success
  07:53:51.025 [mobservice2] INFO info 8ae3a3fa-fbc8-11eb-b3d7-0242ac110004:EQWxHTiy write success
  07:53:53.507 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×2)
  07:53:56.119 [mobservice1] INFO info 8de1e576-fbc8-11eb-84a4-0242ac110003:qwpdAUNi write success
  07:53:58.941 [mobservice2] INFO info 8f8ba7cc-fbc8-11eb-8d4e-0242ac110003:rfqKcNpJ write success
  07:54:01.821 [mobservice2] INFO info 914fd43e-fbc8-11eb-9b7b-0242ac110003:QUpJkdTY write success
  07:54:04.676 [mobservice1] INFO info 930292f8-fbc8-11eb-a82d-0242ac110003:QYryCKLk write success
  07:54:08.143 [dbservice2] ERROR password in database of {user} is null, the user is not registered

Reviewer A: relevant (0.55): ERROR in mobservice2: the login info expired and the mobile phone login was invalid, so a user login failed. It may be ordinary QR-code expiry, hence the low confidence.
Reviewer B: benign (0.5): ERROR-level, but it reports an expired QR-login uuid (normal session TTL expiry) and nothing indicates a system fault. Kept consistent with p0006.


## p0050
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice2, 2021-08-13T08:15:11.252Z
```
{"service":"redisservice2","message":"2021-08-13 08:15:11,252 | INFO | 0.0.0.2 | redisservice2 | redis_helper.py -> keys_existence_check -> 107 | 2a1ea7e2216e71e6 | service refuse, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  08:15:06.753 [redisservice2] INFO service refuse, status_code: 200  (×2)
  08:15:06.899 [redisservice2] INFO redis write success  (×9)
  08:15:07.471 [redisservice2] INFO service accept, status_code: 200  (×4)
  08:15:08.037 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×3)
  08:15:09.671 [redisservice2] INFO redis读取信息成功, status_code: 200  (×2)
All services, 30 seconds either side (sampled):
  08:14:41.278 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '741cbf78-fbcb-11eb-92e3-0242ac110004', 'value': 'LUmfKNIy'}  (×47)
  08:14:41.456 [redisservice1] INFO redis读取信息成功, status_code: 200  (×43)
  08:14:41.551 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  08:14:41.808 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '74987366-fbcb-11eb-96f5-0242ac110003', 'value': '', 'ex': 10}  (×47)
  08:14:42.207 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×39)
  08:14:42.425 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '74987366-fbcb-11eb-96f5-0242ac110003'}  (×45)
  08:14:42.775 [redisservice2] INFO service accept, status_code: 200  (×23)
  08:14:44.157 [mobservice1] INFO info 75cd978e-fbcb-11eb-a53f-0242ac110003:nSPeKIZU write success
  08:14:45.426 [dbservice1] INFO 764b550c-fbcb-11eb-913d-0242ac110003-gSjZMlmO--CEXg)FY#_sv token generate success token=MTYyODgxMzY4NS40MjYwNjMzOjc2NGI1NTBjLWZiY2ItMTFlYi05MTNkLTAyNDJhYzE
  08:14:45.738 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×41)
  08:14:46.538 [mobservice1] INFO info 773d7774-fbcb-11eb-a238-0242ac110003:cSnIQPJM write success
  08:14:48.702 [mobservice1] INFO info 7886f538-fbcb-11eb-b315-0242ac110004:KPxfCQdu write success
  08:14:51.873 [mobservice2] INFO info 7a60c456-fbcb-11eb-9a37-0242ac110003:auOjVYlz write success
  08:14:54.349 [mobservice1] INFO info 7be6ba74-fbcb-11eb-82f5-0242ac110004:CkWFaQYZ write success
  08:14:57.032 [dbservice1] INFO 7d38b152-fbcb-11eb-855f-0242ac110003-kWcbAndl-+K)#TtAh_eL$ token generate success token=MTYyODgxMzY5Ny4wMzI1MzM6N2QzOGIxNTItZmJjYi0xMWViLTg1NWYtMDI0MmFjMTE
  08:15:00.245 [mobservice2] INFO info 7f5f66ba-fbcb-11eb-9431-0242ac110004:bAyVlxfw write success
  08:15:02.661 [dbservice1] INFO 808af1da-fbcb-11eb-b6e5-0242ac110003-xYHiSMPL-Gx3@4LTvA_5z token generate success token=MTYyODgxMzcwMi42NjA3NTE6ODA4YWYxZGEtZmJjYi0xMWViLWI2ZTUtMDI0MmFjMTE
  08:15:05.609 [dbservice1] INFO 824b7e90-fbcb-11eb-b25d-0242ac110003-uiZfvcTY-6xlZ>er?yf*z token generate success token=MTYyODgxMzcwNS42MDkxMzQ3OjgyNGI3ZTkwLWZiY2ItMTFlYi1iMjVkLTAyNDJhYzE
  08:15:08.801 [mobservice2] INFO info 847ad3aa-fbcb-11eb-93d8-0242ac110003:UFfHkLJX write success
  08:15:11.855 [mobservice1] INFO info 864f668c-fbcb-11eb-ab29-0242ac110003:LtXTsDKV write success
  08:15:14.526 [mobservice2] INFO info 87ec95b4-fbcb-11eb-bfc7-0242ac110003:COxkLyBN write success
  08:15:18.129 [mobservice2] INFO info 8a0a4148-fbcb-11eb-85ca-0242ac110003:MiawoxWe write success
  08:15:22.134 [mobservice2] INFO info 8c68033a-fbcb-11eb-9fc1-0242ac110003:kxDurOQh write success
  08:15:25.156 [mobservice2] INFO info 8e3c975c-fbcb-11eb-a688-0242ac110003:SjMAKXaq write success
  08:15:27.841 [dbservice1] INFO 8f9cdd32-fbcb-11eb-a0ef-0242ac110003-jnuiIECt-_JI:sCNEZ%ay token generate success token=MTYyODgxMzcyNy44NDEwMTg0OjhmOWNkZDMyLWZiY2ItMTFlYi1hMGVmLTAyNDJhYzE
  08:15:31.641 [dbservice1] INFO 91ec208e-fbcb-11eb-840a-0242ac110003-FAmtCcIX-WbpwIhFy&DB@ token generate success token=MTYyODgxMzczMS42NDA4MzI0OjkxZWMyMDhlLWZiY2ItMTFlYi04NDBhLTAyNDJhYzE

Reviewer A: benign (0.55): INFO 'service refuse, status_code: 200' from the keys-existence check. It appears routinely alongside 'service accept' and the context shows no errors, though a refusal could also point to access problems.
Reviewer B: unsure (0.5): INFO 'service refuse, status_code: 200' from a key-existence check; it appears interleaved with normal accepts, so the packet does not show whether this refusal is expected flow or a fault.


## p0051
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-13T08:16:18.504Z
```
{"service":"redisservice1","message":"2021-08-13 08:16:18,504 | INFO | 0.0.0.1 | 172.17.0.4 | redisservice1 | 7ac275344b03fed | service refuse, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  08:16:15.443 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×5)
  08:16:15.496 [redisservice1] INFO redis write success  (×9)
  08:16:15.633 [redisservice1] INFO redis读取信息成功, status_code: 200  (×4)
  08:16:15.901 [redisservice1] INFO service accept, status_code: 200  (×2)
All services, 30 seconds either side (sampled):
  08:15:48.595 [webservice2] INFO complete information: {'uuid': '9c4d3bbc-fbcb-11eb-8e10-0242ac110004', 'user_id': 'rAmXuCJg'}  (×43)
  08:15:48.706 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×38)
  08:15:48.931 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×36)
  08:15:48.995 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×57)
  08:15:49.489 [redisservice1] INFO redis write success  (×80)
  08:15:52.406 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×41)
  08:15:55.387 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  08:15:55.539 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×29)
  08:15:58.253 [redisservice1] INFO service refuse, status_code: 200  (×17)
  08:15:59.504 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×41)
  08:16:01.285 [mobservice2] INFO info a3c7e068-fbcb-11eb-ace6-0242ac110004:rydacQUo write success
  08:16:04.732 [mobservice1] INFO info a5bb2f9c-fbcb-11eb-9144-0242ac110003:jnuiIECt write success
  08:16:07.827 [dbservice1] INFO a7639d52-fbcb-11eb-89a8-0242ac110004-jIBRSGcQ-)ERfPKel{cTt token generate success token=MTYyODgxMzc2Ny44MjY2MTk5OmE3NjM5ZDUyLWZiY2ItMTFlYi04OWE4LTAyNDJhYzE
  08:16:10.867 [mobservice2] INFO info a97960ea-fbcb-11eb-a8a2-0242ac110003:FNabDRjg write success
  08:16:13.121 [mobservice1] INFO info aac7c856-fbcb-11eb-bd8d-0242ac110004:ZPMYDESe write success
  08:16:15.601 [mobservice1] INFO info ac4ddf3a-fbcb-11eb-aa65-0242ac110004:AFDxXgnQ write success
  08:16:18.249 [dbservice1] INFO adbad1fc-fbcb-11eb-a6b4-0242ac110003-GBzXyJft-#5tr9S.2Z_EP token generate success token=MTYyODgxMzc3OC4yNDkwOTgzOmFkYmFkMWZjLWZiY2ItMTFlYi1hNmI0LTAyNDJhYzE
  08:16:20.988 [mobservice2] INFO info af7b79f6-fbcb-11eb-a194-0242ac110004:OVLDMHZf write success
  08:16:23.869 [dbservice1] INFO b0f5b7f6-fbcb-11eb-89c3-0242ac110003-bypSvsJC-Y6tx3Buhf<)p token generate success token=MTYyODgxMzc4My44NjkwMzYyOmIwZjViN2Y2LWZiY2ItMTFlYi04OWMzLTAyNDJhYzE
  08:16:26.418 [dbservice1] INFO b281d0f0-fbcb-11eb-b880-0242ac110003-LPlrKejU-L/x6%5@H{.!- token generate success token=MTYyODgxMzc4Ni40MTc2MjY5OmIyODFkMGYwLWZiY2ItMTFlYi1iODgwLTAyNDJhYzE
  08:16:29.831 [mobservice2] INFO info b4b50112-fbcb-11eb-9f37-0242ac110004:vOcCSRZA write success
  08:16:32.617 [mobservice2] INFO info b66f7780-fbcb-11eb-806f-0242ac110003:vNyVfPiM write success
  08:16:35.493 [mobservice1] INFO info b829c4f4-fbcb-11eb-b115-0242ac110004:mPzNQvtl write success
  08:16:38.098 [mobservice2] INFO info b9b3cc5c-fbcb-11eb-b769-0242ac110004:dsqULkKQ write success
  08:16:40.465 [mobservice2] INFO info bb1d6698-fbcb-11eb-a6f7-0242ac110003:pfVurBxD write success
  08:16:43.901 [mobservice1] INFO info bd32db7a-fbcb-11eb-99cf-0242ac110004:gKUmCyre write success
  08:16:47.062 [dbservice1] INFO becc9c96-fbcb-11eb-8eb1-0242ac110003-HytkEBDf-z?M!i}>8wU$F token generate success token=MTYyODgxMzgwNy4wNjE4MzQzOmJlY2M5Yzk2LWZiY2ItMTFlYi04ZWIxLTAyNDJhYzE

Reviewer A: benign (0.55): INFO 'service refuse' with status 200 looks like a normal QR-login outcome (the user declined); it appears regularly alongside 'service accept' with no errors.
Reviewer B: unsure (0.5): 'service refuse, status_code: 200' at INFO. It may be a normal user-declined QR login (the counterpart of 'service accept') or a refused service call, and the context does not settle which.


## p0824
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-08T12:12:37.429Z
```
{"timestamp":1733659957429401300,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-bkz2d","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:12:37.429  INFO 1 --- [       Thread-5] o.s.i.channel.PublishSubscribeChannel    : Channel 'ts-route-service:11178.errorChannel' has 0 subscriber(s)."}
```
Same service, the 2 minutes before (oldest first):
  12:12:32.046 [ts-route-service] 2024-12-08 12:12:32.046 INFO 1 --- [io-11178-exec-2] route.controller.RouteController : Route id: d693a2c5-ef87-4a3c-bef8-600b43f62c68  (×15)
  12:12:35.949 [ts-route-service] 2024-12-08 12:12:35.949 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: d693a2c5-ef87-4a3c-bef8-600b43f62c68  (×2)
  12:12:37.425 [ts-route-service] 2024-12-08 12:12:37.424 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  12:12:37.428 [ts-route-service] 2024-12-08 12:12:37.428 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  12:12:37.428 [ts-route-service] 2024-12-08 12:12:37.428 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
All services, 30 seconds either side (sampled):
  12:12:08.239 [ts-admin-basic-info-service] 2024-12-08 12:12:08.239 INFO 1 --- [io-18767-exec-3] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×9)
  12:12:11.823 [ts-auth-mongo] {"t":{"$date":"2024-12-08T12:12:11.823+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365993
  12:12:13.032 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-08T12:12:13.032+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365993
  12:12:13.534 [ts-price-mongo] {"t":{"$date":"2024-12-08T12:12:13.534+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365993
  12:12:13.591 [ts-basic-service] 2024-12-08 12:12:13.590 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×15)
  12:12:13.638 [ts-basic-service] 2024-12-08 12:12:13.638 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×9)
  12:12:13.693 [ts-seat-service] 2024-12-08 12:12:13.693 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×24)
  12:12:13.738 [ts-seat-service] 2024-12-08 12:12:13.738 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×23)
  12:12:13.846 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:12:13 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 343 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×15)
  12:12:14.915 [ts-travel2-service] 2024-12-08 12:12:14.915 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  12:12:15.030 [ts-seat-service] 2024-12-08 12:12:15.030 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  12:12:16.219 [ts-travel-service] 2024-12-08 12:12:16.218 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×15)
  12:12:16.373 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:12:16 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5514 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×2)
  12:12:19.072 [ts-consign-service] 2024-12-08 12:12:19.072 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] 7c8f5e53-ba3e-4f0f-a40d-
  12:12:21.392 [ts-admin-basic-info-service] 2024-12-08 12:12:21.392 INFO 1 --- [io-18767-exec-6] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×8)
  12:12:23.497 [ts-basic-service] 2024-12-08 12:12:23.497 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×2)
  12:12:23.649 [ts-seat-service] 2024-12-08 12:12:23.649 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×5)
  12:12:25.258 [ts-travel-service] 2024-12-08 12:12:25.258 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×4)
  12:12:25.313 [ts-order-service] 2024-12-08 12:12:25.313 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024  (×6)
  12:12:25.473 [ts-travel-service] 2024-12-08 12:12:25.473 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×6)
  12:12:25.536 [ts-basic-service] 2024-12-08 12:12:25.536 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : suzhouendPlaceId : shanghai
  12:12:25.590 [ts-travel-service] 2024-12-08 12:12:25.590 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan
  12:12:29.030 [ts-food-service] 2024-12-08 12:12:29.029 INFO 1 --- [io-18856-exec-6] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!  (×2)
  12:12:31.011 [ts-basic-service] 2024-12-08 12:12:31.011 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23
  12:12:37.428 [ts-route-service] 2024-12-08 12:12:37.428 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  12:12:37.446 [ts-travel-service] 2024-12-08 12:12:37.446 INFO 1 --- [io-12346-exec-1] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×3)
  12:12:38.845 [ts-admin-travel-service] org.springframework.web.client.HttpServerErrorException: 500 Internal Server Error at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Def  (×6)
  12:12:40.474 [ts-route-service] [otel.javaagent 2024-12-08 12:12:40:474 +0000] [main] INFO io.opentelemetry.javaagent.tooling.VersionLogger - opentelemetry-javaagent - version: 2.0.0 . ____ _ 
  12:13:01.263 [ts-route-service] 2024-12-08 12:13:01.263 INFO 1 --- [ main] route.RouteApplication : No active profile set, falling back to default profiles: default

Reviewer A: unsure (0.5): Spring shutdown message as ts-route-service closes its context and later restarts; the packet does not show whether this is a planned redeploy or a crash.
Reviewer B: relevant (0.55): Part of route-service's shutdown sequence (context closing, beans stopping) in the middle of live traffic. The service restarts right after and 500s appear elsewhere, which points to an unplanned restart.


## p0844
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T04:26:17.643Z
```
{"timestamp":1731903977643370800,"container_name":"adservice","pod_name":"adservice-67c9b847f4-wz6h7","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Stats enabled, but temporarily unavailable"}
```
Same service, the 2 minutes before (oldest first):
  04:26:08.247 [adservice] received ad request (context_words=[])  (×5)
  04:26:09.406 [adservice] received ad request (context_words=[decor, home])  (×2)
  04:26:09.544 [adservice] received ad request (context_words=[kitchen])  (×6)
  04:26:09.566 [adservice] received ad request (context_words=[accessories])  (×3)
  04:26:09.593 [adservice] received ad request (context_words=[clothing, tops])
  04:26:09.618 [adservice] received ad request (context_words=[hair, beauty])
  04:26:14.190 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  04:26:14.191 [adservice] *** server shut down
All services, 30 seconds either side (sampled):
  04:25:47.763 [frontend] request started  (×295)
  04:25:47.766 [frontend] home  (×36)
  04:25:47.781 [currencyservice] conversion request successful  (×717)
  04:25:48.291 [frontend] view user cart  (×71)
  04:25:48.316 [shippingservice] [GetQuote] completed request  (×83)
  04:25:48.653 [adservice] received ad request (context_words=[hair, beauty])  (×6)
  04:25:49.099 [frontend] adding to cart  (×23)
  04:25:49.164 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="TRY"  (×2)
  04:25:49.190 [checkoutservice] payment went through (transaction_id: 9f2259b1-70d3-4c82-a614-52a2c26c1bb7)  (×12)
  04:25:49.195 [cartservice] EmptyCartAsync called with userId=0ae6d9b6-4e7f-4d38-a0eb-042389dcac30  (×12)
  04:25:49.202 [frontend] order placed  (×12)
  04:25:53.896 [adservice] received ad request (context_words=[footwear])  (×4)
  04:25:58.955 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"1618","nanos":993365795},"credit_card":{"credit_card_number":"4777636584828  (×2)
  04:25:58.970 [checkoutservice] order confirmation email sent to "thomasfarmer@example.org"
  04:26:03.290 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"481","nanos":720000000},"credit_card":{"credit_card_number":"46971998707907
  04:26:03.305 [checkoutservice] order confirmation email sent to "gonzalezjessica@example.net"
  04:26:04.228 [paymentservice] Transaction processed: visa ending 4902 Amount: GBP900.148865979  (×4)
  04:26:07.877 [emailservice] A request to send order confirmation email to stephaniegregory@example.org has been received.  (×2)
  04:26:08.085 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"516","nanos":718266264},"credit_card":{"credit_card_number":"41048720965937  (×3)
  04:26:08.102 [checkoutservice] order confirmation email sent to "victor92@example.org"
  04:26:14.190 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  04:26:14.635 [frontend] failed to retrieve ads  (×96)
  04:26:17.739 [adservice] AdService starting.
  04:26:17.742 [adservice] Tracing enabled - Stackdriver exporter initialized.
  04:26:23.952 [checkoutservice] order confirmation email sent to "vegadennis@example.net"
  04:26:41.011 [emailservice] A request to send order confirmation email to vhaynes@example.org has been received.

Reviewer A: benign (0.55): Standard adservice startup message about stats exporter availability. The restart itself is visible elsewhere, and this init line adds no failure information.
Reviewer B: relevant (0.55): Startup message from adservice restarting right after an unplanned JVM shutdown, while the frontend logs 'failed to retrieve ads' (x96). The event is part of that outage/restart, and stats are reported unavailable.


## p0119
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:17:43.840Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731907063840792300,"container_name":"adservice","pod_name":"adservice-574c5fd7b4-tmkhn","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Tracing enabled but temporarily unavailable"}
```
Same service, the 2 minutes before (oldest first):
  05:17:34.960 [adservice] received ad request (context_words=[hair, beauty])  (×5)
  05:17:35.730 [adservice] received ad request (context_words=[kitchen])  (×3)
  05:17:36.105 [adservice] received ad request (context_words=[accessories])  (×2)
  05:17:37.099 [adservice] received ad request (context_words=[footwear])
  05:17:37.384 [adservice] received ad request (context_words=[clothing, tops])  (×3)
  05:17:38.820 [adservice] received ad request (context_words=[])  (×2)
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:40.213 [adservice] *** server shut down
  05:17:43.747 [adservice] AdService starting.
  05:17:43.839 [adservice] Stats enabled, but temporarily unavailable
All services, 30 seconds either side (sampled):
  05:17:14.375 [frontend] request started  (×281)
  05:17:14.382 [cartservice] GetCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×239)
  05:17:14.401 [shippingservice] [GetQuote] completed request  (×79)
  05:17:14.842 [frontend] serving product page  (×128)
  05:17:14.988 [frontend] home  (×32)
  05:17:15.286 [adservice] received ad request (context_words=[accessories])  (×10)
  05:17:16.598 [adservice] received ad request (context_words=[kitchen])  (×24)
  05:17:16.663 [frontend] placing order  (×7)
  05:17:16.693 [paymentservice] Transaction processed: visa ending 5701 Amount: TRY1792.226454698  (×4)
  05:17:16.696 [shippingservice] [ShipOrder] completed request  (×7)
  05:17:16.706 [checkoutservice] order confirmation email sent to "abowman@example.com"
  05:17:16.825 [checkoutservice] order confirmation email sent to "barbara24@example.com"
  05:17:24.080 [adservice] received ad request (context_words=[decor, home])  (×6)
  05:17:24.111 [paymentservice] Transaction processed: visa ending 1703 Amount: CAD346.438559926  (×2)
  05:17:25.127 [emailservice] A request to send order confirmation email to coxchristine@example.net has been received.
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:40.406 [frontend] failed to retrieve ads  (×84)
  05:17:43.841 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.  (×2)
  05:17:45.450 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  05:17:53.543 [adservice] Tracing enabled but temporarily unavailable
  05:17:55.262 [paymentservice] Transaction processed: visa ending 8741 Amount: EUR679.655019909
  05:18:02.298 [emailservice] A request to send order confirmation email to caseyhoward@example.com has been received.

Reviewer A: benign (0.55): Standard adservice startup message about tracing exporter availability. The crash/restart and BindException are separate events in the context.
Reviewer B: relevant (0.55): Logged while adservice restarts after an unplanned JVM shutdown, with BindException 'Address in use' and frontend 'failed to retrieve ads' (x84). The event marks the degraded restart, and tracing is reported unavailable.


## p0836
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-08T12:48:04.910Z
```
{"timestamp":1733662084910929000,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-gr58j","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:48:04.910  INFO 1 --- [       Thread-5] o.s.i.endpoint.EventDrivenConsumer       : stopped _org.springframework.integration.errorLogger"}
```
Same service, the 2 minutes before (oldest first):
  12:48:02.500 [ts-route-service] 2024-12-08 12:48:02.499 INFO 1 --- [io-11178-exec-6] route.controller.RouteController : Route id: 1367db1f-461e-4ab7-87ad-2bcc05fd9cb7  (×14)
  12:48:04.216 [ts-route-service] 2024-12-08 12:48:04.216 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×2)
  12:48:04.907 [ts-route-service] 2024-12-08 12:48:04.906 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  12:48:04.909 [ts-route-service] 2024-12-08 12:48:04.909 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  12:48:04.910 [ts-route-service] 2024-12-08 12:48:04.909 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  12:48:04.910 [ts-route-service] 2024-12-08 12:48:04.910 INFO 1 --- [ Thread-5] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-route-service:11178.errorChannel' has 0 subscriber(s).
All services, 30 seconds either side (sampled):
  12:47:36.092 [ts-admin-basic-info-service] 2024-12-08 12:47:36.092 INFO 1 --- [io-18767-exec-7] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×12)
  12:47:37.094 [ts-basic-service] 2024-12-08 12:47:37.093 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×4)
  12:47:37.162 [ts-basic-service] 2024-12-08 12:47:37.162 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×12)
  12:47:37.186 [ts-travel2-service] 2024-12-08 12:47:37.186 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×8)
  12:47:37.271 [ts-seat-service] 2024-12-08 12:47:37.271 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×15)
  12:47:37.411 [ts-travel2-service] 2024-12-08 12:47:37.411 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×8)
  12:47:39.774 [ts-auth-service] 2024-12-08 12:47:39.774 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×3)
  12:47:41.537 [ts-travel-service] 2024-12-08 12:47:41.536 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×11)
  12:47:41.581 [ts-travel-service] 2024-12-08 12:47:41.581 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×6)
  12:47:41.641 [ts-order-service] 2024-12-08 12:47:41.641 INFO 1 --- [io-12031-exec-2] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:00:00   (×3)
  12:47:41.751 [ts-travel-service] 2024-12-08 12:47:41.750 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×6)
  12:47:41.856 [ts-assurance-service] 2024-12-08 12:47:41.855 INFO 1 --- [o-18888-exec-10] a.controller.AssuranceController : [Assurances Service][Get Assurance Type]
  12:47:41.897 [ts-security-service] 2024-12-08 12:47:41.897 INFO 1 --- [io-11188-exec-2] security.controller.SecurityController : [Security Service][Check Security] Check Account Id: 4d2a46c7-71cb
  12:47:41.935 [ts-security-service] 2024-12-08 12:47:41.935 INFO 1 --- [io-11188-exec-2] security.service.SecurityServiceImpl : [Security Service] Max In One Hour: 2147483647 Max Not Use: 21474836
  12:47:41.962 [ts-preserve-service] 2024-12-08 12:47:41.962 INFO 1 --- [o-14568-exec-10] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] Check tickets num
  12:47:42.253 [ts-preserve-service] 2024-12-08 12:47:42.253 INFO 1 --- [o-14568-exec-10] preserve.service.PreserveServiceImpl : TripAllDetail:TripAllDetail(status=false, message=null, tripResponse
  12:47:42.374 [ts-seat-service] 2024-12-08 12:47:42.374 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService distributeSeat 1] The result of getTrainTypeResult is Response(
  12:47:42.398 [ts-order-service] 2024-12-08 12:47:42.398 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 50.0
  12:47:42.422 [ts-preserve-service] 2024-12-08 12:47:42.422 INFO 1 --- [o-14568-exec-10] preserve.service.PreserveServiceImpl : [Cancel Order Service][Get Order By Id]
  12:47:52.364 [ts-food-service] 2024-12-08 12:47:52.363 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  12:47:54.599 [ts-travel-service] 2024-12-08 12:47:54.599 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  12:47:56.389 [ts-basic-service] 2024-12-08 12:47:56.389 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×4)
  12:48:02.393 [ts-seat-service] 2024-12-08 12:48:02.392 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  12:48:04.919 [ts-route-mongo] {"t":{"$date":"2024-12-08T12:48:04.919+00:00"},"s":"I", "c":"NETWORK", "id":22944, "ctx":"conn52","msg":"Connection ended","attr":{"remote":"127.0.0.6:41949","u  (×5)
  12:48:10.896 [ts-route-mongo] {"t":{"$date":"2024-12-08T12:48:10.896+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366209
  12:48:12.329 [ts-preserve-mongo] {"t":{"$date":"2024-12-08T12:48:12.329+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366209
  12:48:14.000 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-08T12:48:14.000+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366209
  12:48:16.738 [ts-order-service] 2024-12-08 12:48:16.738 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 155
  12:48:20.179 [ts-food-service] 2024-12-08 12:48:20.178 ERROR 1 --- [io-18856-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with

Reviewer A: unsure (0.5): Part of an orderly shutdown of ts-route-service while it was serving traffic; the packet doesn't show whether this is a planned restart/deploy or a crash/kill.
Reviewer B: relevant (0.6): Part of ts-route-service shutting down its application context in the middle of normal traffic, with mongo connections ending. An on-call engineer should know a core service stopped, though it may have been a planned redeploy.


## p0562
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:30:15.882Z
```
{"timestamp":1733596215882113300,"container_name":"ts-auth-service","pod_name":"ts-auth-service-75dfb9459b-94tpt","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:30:15.882  INFO 1 --- [       Thread-5] org.mongodb.driver.connection            : Closed connection [connectionId{localValue:4, serverValue:17}] to ts-auth-mongo:27017 because the pool has been closed."}
```
Same service, the 2 minutes before (oldest first):
  18:30:09.450 [ts-auth-service] 2024-12-07 18:30:09.450 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  18:30:09.450 [ts-auth-service] 2024-12-07 18:30:09.450 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:30:09.661 [ts-auth-service] 2024-12-07 18:30:09.661 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×2)
  18:30:09.661 [ts-auth-service] 2024-12-07 18:30:09.661 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×2)
  18:30:10.784 [ts-auth-service] 2024-12-07 18:30:10.782 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  18:30:10.784 [ts-auth-service] 2024-12-07 18:30:10.782 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  18:30:10.967 [ts-auth-service] 2024-12-07 18:30:10.967 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  18:30:10.967 [ts-auth-service] 2024-12-07 18:30:10.967 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:30:11.191 [ts-auth-service] 2024-12-07 18:30:11.190 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI
  18:30:11.191 [ts-auth-service] 2024-12-07 18:30:11.190 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID
  18:30:15.870 [ts-auth-service] 2024-12-07 18:30:15.870 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  18:30:15.873 [ts-auth-service] 2024-12-07 18:30:15.872 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  18:30:15.874 [ts-auth-service] 2024-12-07 18:30:15.874 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  18:30:15.874 [ts-auth-service] 2024-12-07 18:30:15.874 INFO 1 --- [ Thread-5] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 0 subscriber(s).
  18:30:15.874 [ts-auth-service] 2024-12-07 18:30:15.874 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : stopped _org.springframework.integration.errorLogger
  18:30:15.877 [ts-auth-service] 2024-12-07 18:30:15.877 INFO 1 --- [ Thread-5] o.s.s.c.ThreadPoolTaskScheduler : Shutting down ExecutorService 'taskScheduler'
  18:30:15.877 [ts-auth-service] 2024-12-07 18:30:15.877 INFO 1 --- [ Thread-5] o.s.j.e.a.AnnotationMBeanExporter : Unregistering JMX-exposed beans on shutdown
  18:30:15.880 [ts-auth-service] 2024-12-07 18:30:15.880 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:16}] to ts-auth-mongo:2
All services, 30 seconds either side (sampled):
  18:29:45.882 [ts-basic-service] 2024-12-07 18:29:45.882 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×63)
  18:29:45.911 [ts-basic-service] 2024-12-07 18:29:45.911 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×9)
  18:29:45.993 [ts-travel2-service] 2024-12-07 18:29:45.993 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×111)
  18:29:46.031 [ts-seat-service] 2024-12-07 18:29:46.031 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×36)
  18:29:47.860 [ts-auth-service] 2024-12-07 18:29:47.860 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×9)
  18:29:47.919 [ts-travel-service] 2024-12-07 18:29:47.919 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×12)
  18:29:47.979 [ts-travel2-service] 2024-12-07 18:29:47.978 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×16)
  18:29:54.679 [ts-auth-service] 2024-12-07 18:29:54.679 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  18:30:00.246 [ts-basic-service] 2024-12-07 18:30:00.246 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  18:30:00.278 [ts-basic-service] 2024-12-07 18:30:00.278 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  18:30:00.379 [ts-seat-service] 2024-12-07 18:30:00.379 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×3)
  18:30:02.452 [ts-basic-service] 2024-12-07 18:30:02.452 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×24)
  18:30:02.486 [ts-basic-service] 2024-12-07 18:30:02.486 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×11)
  18:30:02.555 [ts-travel-service] 2024-12-07 18:30:02.554 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×4)
  18:30:07.196 [ts-order-other-service] 2024-12-07 18:30:07.196 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×3)
  18:30:09.590 [ts-inside-payment-service] 2024-12-07 18:30:09.588 INFO 1 --- [io-18673-exec-7] i.service.InsidePaymentServiceImpl : Out pay result: Response(status=1, msg=Pay Success, data=null)
  18:30:14.631 [ts-basic-service] 2024-12-07 18:30:14.630 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×19)
  18:30:14.739 [ts-order-service] 2024-12-07 18:30:14.739 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×5)
  18:30:14.807 [ts-seat-service] 2024-12-07 18:30:14.807 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×11)
  18:30:15.479 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:30:15 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 916 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×2)
  18:30:15.880 [ts-auth-service] 2024-12-07 18:30:15.880 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:16}] to ts-auth-mongo:2  (×3)
  18:30:17.523 [ts-travel-service] 2024-12-07 18:30:17.523 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1237
  18:30:26.260 [ts-auth-service] 2024-12-07 18:30:26.260 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default
  18:30:29.606 [ts-food-service] 2024-12-07 18:30:29.605 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  18:30:29.940 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:30:29.940+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359622
  18:30:31.939 [ts-order-service] 2024-12-07 18:30:31.939 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 
  18:30:40.512 [ts-order-other-service] 2024-12-07 18:30:40.512 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 24
  18:30:42.020 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T18:30:42.020+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359624
  18:30:44.984 [ts-travel2-service] 2024-12-07 18:30:44.983 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success

Reviewer A: unsure (0.5): ts-auth-service is shutting down gracefully and closing its Mongo connection pool, and it restarts seconds later. The packet does not show whether this is a planned rollout or a failure.
Reviewer B: benign (0.55): Graceful-shutdown INFO line closing Mongo connections while ts-auth-service stops. The service restarts under a new pod and no failure is visible in this context, so it looks like a deploy or restart.

