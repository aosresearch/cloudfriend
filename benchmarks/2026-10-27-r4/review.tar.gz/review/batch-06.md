## p0141
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T05:33:33.069Z
```
{"timestamp":1731908013069550600,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-sd8v2","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  05:33:32.779 [currencyservice] conversion request successful  (×18)
  05:33:32.938 [currencyservice] Getting supported currencies...  (×2)
All services, 30 seconds either side (sampled):
  05:33:03.579 [frontend] request started  (×335)
  05:33:03.585 [cartservice] GetCartAsync called with userId=fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a  (×280)
  05:33:03.607 [shippingservice] [GetQuote] completed request  (×74)
  05:33:04.089 [frontend] serving product page  (×172)
  05:33:04.184 [frontend] ENV_PLATFORM is: aws  (×34)
  05:33:04.841 [frontend] setting currency  (×22)
  05:33:05.519 [frontend] placing order  (×13)
  05:33:05.549 [paymentservice] Transaction processed: visa ending 8880 Amount: JPY45039.992923739
  05:33:05.553 [shippingservice] [ShipOrder] completed request  (×13)
  05:33:05.564 [checkoutservice] order confirmation email sent to "todd58@example.org"
  05:33:07.121 [adservice] received ad request (context_words=[kitchen])  (×56)
  05:33:11.125 [checkoutservice] [PlaceOrder] user_id="adf41e5f-12f6-4c40-88a0-a1bcf421e416" user_currency="TRY"  (×3)
  05:33:11.179 [emailservice] A request to send order confirmation email to gailthompson@example.net has been received.
  05:33:11.745 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="EUR"  (×3)
  05:33:11.785 [emailservice] A request to send order confirmation email to fryekylie@example.net has been received.
  05:33:14.005 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"27","nanos":711161431},"credit_card":{"credit_card_number":"453208318533795  (×2)
  05:33:14.019 [checkoutservice] order confirmation email sent to "cristina39@example.org"
  05:33:17.829 [checkoutservice] order confirmation email sent to "blackanthony@example.net"
  05:33:22.383 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"961","nanos":680000000},"credit_card":{"credit_card_number":"46505696142772  (×3)
  05:33:22.398 [checkoutservice] order confirmation email sent to "kpetty@example.org"
  05:33:33.080 [paymentservice] Transaction processed: visa ending 8831 Amount: CAD828.72329059
  05:33:38.468 [emailservice] A request to send order confirmation email to pughpatricia@example.org has been received.
  05:33:39.586 [checkoutservice] order confirmation email sent to "ghenderson@example.org"
  05:33:51.041 [emailservice] A request to send order confirmation email to whiteshannon@example.net has been received.
  05:33:53.803 [checkoutservice] order confirmation email sent to "baileytanya@example.com"
  05:33:58.459 [checkoutservice] order confirmation email sent to "rclark@example.com"

## p0161
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T05:54:53.813Z
```
{"timestamp":1731909293813698000,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-sd8v2","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  05:54:52.764 [currencyservice] conversion request successful  (×17)
  05:54:52.905 [currencyservice] Getting supported currencies...  (×3)
All services, 30 seconds either side (sampled):
  05:54:23.832 [frontend] request started  (×258)
  05:54:23.840 [cartservice] GetCartAsync called with userId=fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a  (×181)
  05:54:23.864 [adservice] received ad request (context_words=[accessories])  (×25)
  05:54:24.259 [frontend] setting currency  (×13)
  05:54:24.312 [adservice] received ad request (context_words=[])  (×21)
  05:54:24.997 [frontend] span hipstershop.CartService/AddItem failed with gRPC status 9  (×29)
  05:54:25.002 [frontend] request error  (×29)
  05:54:26.770 [frontend] view user cart  (×29)
  05:54:27.380 [adservice] received ad request (context_words=[clothing, tops])  (×15)
  05:54:27.625 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"7","nanos":952233525},"credit_card":{"credit_card_number":"4576924034666260  (×3)
  05:54:27.629 [shippingservice] [ShipOrder] received request  (×10)
  05:54:27.640 [emailservice] A request to send order confirmation email to aaron43@example.com has been received.
  05:54:32.718 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="TRY"
  05:54:32.745 [emailservice] A request to send order confirmation email to averybrenda@example.net has been received.
  05:54:35.645 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"12","nanos":30138876},"credit_card":{"credit_card_number":"4164196710120676  (×3)
  05:54:35.659 [checkoutservice] order confirmation email sent to "hayleylowe@example.com"
  05:54:37.895 [paymentservice] Transaction processed: visa ending 6463 Amount: USD8.990000000  (×2)
  05:54:39.795 [emailservice] A request to send order confirmation email to ryangregory@example.org has been received.
  05:54:46.232 [checkoutservice] order confirmation email sent to "julielopez@example.net"
  05:55:06.005 [checkoutservice] [PlaceOrder] user_id="736a09b5-665e-4823-8520-b8602b0bdbff" user_currency="GBP"
  05:55:06.032 [emailservice] A request to send order confirmation email to cdavis@example.com has been received.
  05:55:08.465 [checkoutservice] order confirmation email sent to "jmcclain@example.net"

## p0538
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T18:16:56.308Z
```
{"timestamp":1733595416308955600,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-kwkx6","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:16:56.308  INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl       : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c68  station: [taiyuan, shijiazhuang, nanjing, shanghai]"}
```
Same service, the 2 minutes before (oldest first):
  18:16:55.537 [ts-travel2-service] 2024-12-07 18:16:55.536 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×5)
  18:16:55.547 [ts-travel2-service] 2024-12-07 18:16:55.547 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×5)
  18:16:55.705 [ts-travel2-service] 2024-12-07 18:16:55.705 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  18:16:55.715 [ts-travel2-service] 2024-12-07 18:16:55.715 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  18:16:55.808 [ts-travel2-service] 2024-12-07 18:16:55.807 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  18:16:55.820 [ts-travel2-service] 2024-12-07 18:16:55.820 INFO 1 --- [io-16346-exec-4] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×2)
  18:16:55.889 [ts-travel2-service] 2024-12-07 18:16:55.889 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  18:16:56.006 [ts-travel2-service] 2024-12-07 18:16:56.006 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
All services, 30 seconds either side (sampled):
  18:16:27.046 [ts-admin-basic-info-service] 2024-12-07 18:16:27.046 INFO 1 --- [io-18767-exec-3] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×10)
  18:16:27.857 [ts-auth-service] 2024-12-07 18:16:27.856 INFO 1 --- [io-12340-exec-5] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×10)
  18:16:28.127 [ts-travel-service] 2024-12-07 18:16:28.127 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×19)
  18:16:28.235 [ts-travel2-service] 2024-12-07 18:16:28.235 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×122)
  18:16:29.753 [ts-station-mongo] {"t":{"$date":"2024-12-07T18:16:29.753+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359538
  18:16:30.750 [ts-order-mongo] {"t":{"$date":"2024-12-07T18:16:30.750+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359539
  18:16:36.387 [ts-basic-service] 2024-12-07 18:16:36.387 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×11)
  18:16:36.440 [ts-basic-service] 2024-12-07 18:16:36.440 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4  (×21)
  18:16:36.620 [ts-travel2-service] 2024-12-07 18:16:36.620 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×22)
  18:16:36.751 [ts-travel2-service] 2024-12-07 18:16:36.751 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×15)
  18:16:39.855 [ts-food-map-service] 2024-12-07 18:16:39.854 INFO 1 --- [io-18855-exec-8] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×2)
  18:16:42.752 [ts-order-other-service] 2024-12-07 18:16:42.752 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×7)
  18:16:44.493 [ts-travel2-service] 2024-12-07 18:16:44.492 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×4)
  18:16:46.058 [ts-travel-service] 2024-12-07 18:16:46.058 INFO 1 --- [io-12346-exec-6] travel.controller.TravelController : [Travel Service] Query TripResponse  (×4)
  18:16:46.254 [ts-basic-service] 2024-12-07 18:16:46.253 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×3)
  18:16:46.382 [ts-seat-service] 2024-12-07 18:16:46.382 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×4)
  18:16:46.480 [ts-order-service] 2024-12-07 18:16:46.480 INFO 1 --- [io-12031-exec-2] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×21)
  18:16:46.904 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:16:46 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 200 119 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
  18:16:46.954 [ts-security-service] 2024-12-07 18:16:46.954 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service][Get Order Num Info]
  18:16:47.019 [ts-preserve-service] 2024-12-07 18:16:47.019 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security Complete
  18:16:47.090 [ts-preserve-service] 2024-12-07 18:16:47.090 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] TripId: D1345
  18:16:47.860 [ts-preserve-service] 2024-12-07 18:16:47.860 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] Tickets Enough
  18:16:48.025 [ts-seat-service] 2024-12-07 18:16:48.025 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService distributeSeat] Use a new seat number! 1448114575
  18:16:48.097 [ts-preserve-service] 2024-12-07 18:16:48.097 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service][Add Assurance For Order]
  18:16:51.634 [ts-auth-service] 2024-12-07 18:16:51.634 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  18:16:53.443 [ts-seat-service] 2024-12-07 18:16:53.443 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×3)
  18:16:54.304 [ts-basic-service] 2024-12-07 18:16:54.304 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2  (×2)
  18:16:55.683 [ts-basic-service] 2024-12-07 18:16:55.683 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×3)
  18:17:09.436 [ts-travel-service] 2024-12-07 18:17:09.436 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan  (×2)
  18:17:24.447 [ts-basic-service] 2024-12-07 18:17:24.446 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：92708982-77

## p0192
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T06:50:58.606Z
```
{"timestamp":1731912658606683100,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  06:50:56.785 [currencyservice] Getting supported currencies...  (×8)
  06:50:56.795 [currencyservice] conversion request successful  (×12)
All services, 30 seconds either side (sampled):
  06:50:29.096 [frontend] request started  (×300)
  06:50:29.104 [cartservice] GetCartAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43  (×251)
  06:50:29.127 [adservice] received ad request (context_words=[kitchen])  (×47)
  06:50:30.795 [adservice] received ad request (context_words=[decor, home])  (×22)
  06:50:31.098 [frontend] view user cart  (×70)
  06:50:31.150 [frontend] placing order  (×9)
  06:50:31.179 [paymentservice] Transaction processed: visa ending 9403 Amount: USD1362.740000000  (×3)
  06:50:31.183 [shippingservice] [ShipOrder] completed request  (×9)
  06:50:31.199 [checkoutservice] order confirmation email sent to "zperez@example.com"
  06:50:31.318 [frontend] ENV_PLATFORM is: aws  (×27)
  06:50:33.123 [frontend] setting currency  (×17)
  06:50:45.051 [adservice] received ad request (context_words=[hair, beauty])  (×13)
  06:50:49.813 [paymentservice] Transaction processed: visa ending 2912 Amount: TRY980.60353845  (×2)
  06:50:51.179 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="GBP"  (×2)
  06:50:51.227 [emailservice] A request to send order confirmation email to egomez@example.com has been received.
  06:50:59.618 [checkoutservice] order confirmation email sent to "matthewscharles@example.com"
  06:51:04.801 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"982","nanos":237947824},"credit_card":{"credit_card_number":"49399128186385
  06:51:04.815 [checkoutservice] order confirmation email sent to "wward@example.com"
  06:51:13.062 [redis] 68:C 18 Nov 2024 06:51:13.062 * DB saved on disk
  06:51:16.549 [emailservice] A request to send order confirmation email to patriciapalmer@example.com has been received.
  06:51:23.139 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"75163","nanos":555950072},"credit_card":{"credit_card_number":"461292187757
  06:51:23.153 [checkoutservice] order confirmation email sent to "lindatownsend@example.com"
  06:51:27.891 [emailservice] A request to send order confirmation email to jamesfinley@example.com has been received.

## p0632
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T20:19:18.888Z
```
{"timestamp":1733602758888648200,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-w6jt4","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:19:18.888  INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl         : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb0ff69ad"}
```
Same service, the 2 minutes before (oldest first):
  20:19:11.859 [ts-travel-service] 2024-12-07 20:19:11.859 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×2)
  20:19:11.859 [ts-travel-service] 2024-12-07 20:19:11.859 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×2)
  20:19:11.865 [ts-travel-service] 2024-12-07 20:19:11.865 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d  (×6)
  20:19:11.874 [ts-travel-service] 2024-12-07 20:19:11.874 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×2)
  20:19:11.876 [ts-travel-service] 2024-12-07 20:19:11.875 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×2)
  20:19:12.024 [ts-travel-service] 2024-12-07 20:19:12.023 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  20:19:12.024 [ts-travel-service] 2024-12-07 20:19:12.023 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×3)
  20:19:12.038 [ts-travel-service] 2024-12-07 20:19:12.037 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
  20:19:12.055 [ts-travel-service] 2024-12-07 20:19:12.054 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
All services, 30 seconds either side (sampled):
  20:18:48.890 [ts-seat-service] 2024-12-07 20:18:48.890 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×41)
  20:18:48.933 [ts-travel2-service] 2024-12-07 20:18:48.933 INFO 1 --- [io-16346-exec-1] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234  (×25)
  20:18:48.995 [ts-seat-service] 2024-12-07 20:18:48.995 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×21)
  20:18:51.986 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:18:51 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×22)
  20:18:55.753 [ts-basic-service] 2024-12-07 20:18:55.753 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×12)
  20:18:55.785 [ts-basic-service] 2024-12-07 20:18:55.785 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4  (×20)
  20:18:55.862 [ts-seat-service] 2024-12-07 20:18:55.862 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×4)
  20:18:56.662 [ts-auth-service] 2024-12-07 20:18:56.661 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×9)
  20:18:56.969 [ts-travel-service] 2024-12-07 20:18:56.968 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×11)
  20:18:59.044 [ts-travel-service] 2024-12-07 20:18:59.044 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×6)
  20:18:59.293 [ts-order-service] 2024-12-07 20:18:59.293 INFO 1 --- [io-12031-exec-2] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 75  (×8)
  20:18:59.390 [ts-basic-service] 2024-12-07 20:18:59.390 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×11)
  20:19:00.758 [ts-travel-service] 2024-12-07 20:19:00.758 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×3)
  20:19:01.761 [ts-travel2-service] 2024-12-07 20:19:01.761 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  20:19:08.469 [ts-auth-service] 2024-12-07 20:19:08.468 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×3)
  20:19:22.273 [ts-basic-service] 2024-12-07 20:19:22.273 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing
  20:19:27.548 [ts-seat-service] 2024-12-07 20:19:27.547 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  20:19:30.929 [ts-auth-mongo] {"t":{"$date":"2024-12-07T20:19:30.929+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360277
  20:19:31.681 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:19:31.681+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360277
  20:19:34.180 [ts-travel-service] 2024-12-07 20:19:34.179 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234  (×11)
  20:19:34.668 [ts-travel-service] 2024-12-07 20:19:34.667 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×3)
  20:19:35.153 [ts-travel-service] 2024-12-07 20:19:35.153 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×2)
  20:19:35.337 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:19:35 +0800] "GET /api/v1/contactservice/contacts/account/4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f HTTP/1.1" 200 471 "-" "Mozilla/5.0 
  20:19:35.373 [ts-security-service] 2024-12-07 20:19:35.373 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Getting....
  20:19:35.400 [ts-contacts-service] 2024-12-07 20:19:35.400 INFO 1 --- [io-12347-exec-9] contacts.controller.ContactsController : [ContactsService][Contacts Id Print] d14da0ec-da93-46c3-842d-23fc3
  20:19:35.472 [ts-basic-service] 2024-12-07 20:19:35.472 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69
  20:19:35.814 [ts-preserve-service] 2024-12-07 20:19:35.814 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service][Order] Order Travel Date: Sat Dec 07 00:00:00 GMT
  20:19:35.877 [ts-order-service] 2024-12-07 20:19:35.877 INFO 1 --- [io-12031-exec-7] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at 
  20:19:35.906 [ts-preserve-service] 2024-12-07 20:19:35.906 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service][Step 6] Do not need to buy food
  20:19:40.228 [ts-order-service] 2024-12-07 20:19:40.227 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0

## p0603
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T20:04:01.169Z
```
{"timestamp":1733601841169001000,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-nsc8q","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:04:01.168  INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl             : [SeatService distributeSeat] The request seat type is confortClass and the total num is 2147483647"}
```
Same service, the 2 minutes before (oldest first):
  20:03:59.984 [ts-seat-service] 2024-12-07 20:03:59.983 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  20:03:59.992 [ts-seat-service] 2024-12-07 20:03:59.992 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  20:04:00.424 [ts-seat-service] 2024-12-07 20:04:00.423 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×2)
  20:04:00.424 [ts-seat-service] 2024-12-07 20:04:00.424 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×2)
  20:04:00.443 [ts-seat-service] 2024-12-07 20:04:00.443 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×2)
  20:04:00.459 [ts-seat-service] 2024-12-07 20:04:00.459 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  20:04:00.484 [ts-seat-service] 2024-12-07 20:04:00.484 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×2)
  20:04:00.484 [ts-seat-service] 2024-12-07 20:04:00.484 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  20:04:00.976 [ts-seat-service] 2024-12-07 20:04:00.976 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService distributeSeat] TrainNumber start with G|D
  20:04:01.055 [ts-seat-service] 2024-12-07 20:04:01.055 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService distributeSeat] The result of getRouteResult is Success
  20:04:01.081 [ts-seat-service] 2024-12-07 20:04:01.081 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : Left ticket info is : Response(status=1, msg=Success, data=LeftTicketInfo{so
  20:04:01.168 [ts-seat-service] 2024-12-07 20:04:01.168 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService distributeSeat 1] The result of getTrainTypeResult is Response(
All services, 30 seconds either side (sampled):
  20:03:31.172 [ts-travel2-service] 2024-12-07 20:03:31.172 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×115)
  20:03:31.540 [ts-auth-service] 2024-12-07 20:03:31.540 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×7)
  20:03:31.812 [ts-travel-service] 2024-12-07 20:03:31.812 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×16)
  20:03:32.217 [ts-basic-service] 2024-12-07 20:03:32.217 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×72)
  20:03:32.315 [ts-price-service] 2024-12-07 20:03:32.314 INFO 1 --- [io-16579-exec-6] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: 92708982-77af-4318-be2  (×22)
  20:03:32.352 [ts-travel-service] 2024-12-07 20:03:32.352 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×10)
  20:03:32.424 [ts-order-service] 2024-12-07 20:03:32.424 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : Left ticket info is empty  (×11)
  20:03:32.677 [ts-travel-service] 2024-12-07 20:03:32.677 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:00:00 GMT 2013  (×12)
  20:03:38.486 [ts-auth-service] 2024-12-07 20:03:38.486 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×11)
  20:03:39.085 [ts-travel2-service] 2024-12-07 20:03:39.085 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×22)
  20:03:39.148 [ts-seat-service] 2024-12-07 20:03:39.148 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×5)
  20:03:39.322 [ts-travel2-service] 2024-12-07 20:03:39.322 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×22)
  20:03:42.893 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T20:03:42.893+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360182
  20:03:44.353 [ts-order-other-service] 2024-12-07 20:03:44.353 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 54  (×2)
  20:03:48.263 [ts-food-map-service] 2024-12-07 20:03:48.263 INFO 1 --- [io-18855-exec-2] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×5)
  20:03:53.810 [ts-travel2-service] 2024-12-07 20:03:53.810 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  20:03:59.505 [ts-basic-service] 2024-12-07 20:03:59.505 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe  (×5)
  20:03:59.878 [ts-seat-service] 2024-12-07 20:03:59.877 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×3)
  20:04:00.128 [ts-preserve-service] 2024-12-07 20:04:00.128 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Other Service][Check Security] Checking....  (×2)
  20:04:00.188 [ts-security-service] 2024-12-07 20:04:00.188 INFO 1 --- [io-11188-exec-9] security.service.SecurityServiceImpl : [Security Service] Max In One Hour: 2147483647 Max Not Use: 21474836  (×2)
  20:04:00.209 [ts-preserve-service] 2024-12-07 20:04:00.209 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] TripId: D1345  (×2)
  20:04:00.980 [ts-travel-service] 2024-12-07 20:04:00.980 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×2)
  20:04:01.185 [ts-order-service] 2024-12-07 20:04:01.185 INFO 1 --- [io-12031-exec-8] order.controller.OrderController : [Order Service][Verify Login] Success
  20:04:01.235 [ts-food-service] 2024-12-07 20:04:01.235 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Try to Create a FoodOrder!
  20:04:09.656 [ts-basic-service] 2024-12-07 20:04:09.656 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  20:04:16.010 [ts-admin-basic-info-service] 2024-12-07 20:04:16.010 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  20:04:26.872 [ts-consign-service] 2024-12-07 20:04:26.872 INFO 1 --- [io-16111-exec-3] consign.service.ConsignServiceImpl : SAVE consign result : ConsignRecord(id=68f71f37-7075-4d7b-99e1-5613a2c
  20:04:30.942 [ts-food-mongo] {"t":{"$date":"2024-12-07T20:04:30.942+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360187

## p0473
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T08:14:16.059Z
```
{"timestamp":1732349656059052000,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T08:14:16.05891776Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418ed0a437380001def227 took=4.165368ms"}
```
Same service, the 2 minutes before (oldest first):
  08:14:12.532 [user] ts=2024-11-23T08:14:12.531920781Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67418ecba437380001def21e took=4.179188ms  (×6)
  08:14:12.585 [user] ts=2024-11-23T08:14:12.585614125Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418ecea437380001def221 took=4.734826ms  (×5)
  08:14:12.723 [user] ts=2024-11-23T08:14:12.722920951Z caller=middlewares.go:46 method=Register username=YYzcWROvDoaDy email=YYzcWROvDoaDy@gmail.com took=2.931453ms  (×5)
  08:14:13.848 [user] ts=2024-11-23T08:14:13.848539398Z caller=middlewares.go:157 method=Health result=2 took=2.153612ms  (×2)
  08:14:13.970 [user] ts=2024-11-23T08:14:13.970552632Z caller=middlewares.go:46 method=Register username=gkzpjDVk email=gkzpjDVk@gmail.com took=2.602683ms
  08:14:14.929 [user] ts=2024-11-23T08:14:14.928305009Z caller=middlewares.go:46 method=Register username=hJqPI email=hJqPI@gmail.com took=2.448697ms
All services, 30 seconds either side (sampled):
  08:13:46.172 [front-end] Request received with body: {}  (×60)
  08:13:46.199 [user] ts=2024-11-23T08:13:46.199138103Z caller=middlewares.go:134 method=GetCards id=67418ea9a437380001def1b9 result=1 took=1.956486ms  (×60)
  08:13:46.216 [queue-master] 2024-11-23 08:13:46.216 ERROR 7 --- [ool-6-thread-42] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×46)
  08:13:46.321 [carts] 2024-11-23 08:13:46.320 INFO [carts,846d2c432a42a58c,b188222f3d1245a3,false] 7 --- [-nio-80-exec-14] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×41)
  08:13:46.457 [front-end] POST /register 200 22.652 ms - 33  (×59)
  08:13:47.149 [front-end] Order response: {"id":"67418ebb3f77060008864fc5","customerId":"67418ea6a437380001def1b4","customer":{"id":null,"firstName":"XcwRwlebpF","lastName":"XcwRwlebpF",
  08:13:49.121 [front-end] Received response: "{\"firstName\":\"fFozCtyUTjjJv\",\"lastName\":\"fFozCtyUTjjJv\",\"username\":\"fFozCtyUTjjJv\",\"id\":\"67418eaba437380001def1c7\",\"_links\
  08:13:50.904 [front-end] Order response: {"id":"67418ebe3f77060008864fc9","customerId":"67418ea6a437380001def1b1","customer":{"id":null,"firstName":"tWhfazwUP","lastName":"tWhfazwUP","u
  08:13:52.505 [queue-master] 2024-11-23 08:13:52.505 ERROR 7 --- [pool-6-thread-3] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×9)
  08:13:54.869 [front-end] Received response: "{\"firstName\":\"tqPzhLLdw\",\"lastName\":\"tqPzhLLdw\",\"username\":\"tqPzhLLdw\",\"id\":\"67418eb0a437380001def1d8\",\"_links\":{\"address
  08:13:55.852 [front-end] Posting Customer: {"username":"tLynT","password":"KTUETCiaxo","email":"tLynT@gmail.com","firstName":"tLynT","lastName":"tLynT"}
  08:13:57.008 [user] ts=2024-11-23T08:13:57.007339432Z caller=middlewares.go:46 method=Register username=BfLBPW email=BfLBPW@gmail.com took=2.528356ms
  08:14:00.326 [front-end] Order response: {"id":"67418ec83f77060008864fd6","customerId":"67418eb6a437380001def1e8","customer":{"id":null,"firstName":"NUsJUnpKiz","lastName":"NUsJUnpKiz",
  08:14:06.161 [user] ts=2024-11-23T08:14:06.160956101Z caller=middlewares.go:46 method=Register username=Nkvkz email=Nkvkz@gmail.com took=2.161114ms
  08:14:07.459 [front-end] Received response: "{\"firstName\":\"klwekIaYwsoKBg\",\"lastName\":\"klwekIaYwsoKBg\",\"username\":\"klwekIaYwsoKBg\",\"id\":\"67418ebba437380001def1f7\",\"_lin
  08:14:09.286 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732349649284,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×5)
  08:14:11.118 [front-end] Received response: "{\"firstName\":\"tLynT\",\"lastName\":\"tLynT\",\"username\":\"tLynT\",\"id\":\"67418ec3a437380001def20a\",\"_links\":{\"addresses\":{\"href
  08:14:14.923 [front-end] Posting Customer: {"username":"hJqPI","password":"YGHOqPxMSM","email":"hJqPI@gmail.com","firstName":"hJqPI","lastName":"hJqPI"}
  08:14:20.005 [front-end] Posting Customer: {"username":"xJAJwse","password":"HXkRGtB","email":"xJAJwse@gmail.com","firstName":"xJAJwse","lastName":"xJAJwse"}
  08:14:23.210 [front-end] Posting Customer: {"username":"kSJWYveU","password":"blFgaqYS","email":"kSJWYveU@gmail.com","firstName":"kSJWYveU","lastName":"kSJWYveU"}
  08:14:25.039 [session-db] 1:M 23 Nov 2024 08:14:25.039 * 100 changes in 300 seconds. Saving...
  08:14:29.088 [user] ts=2024-11-23T08:14:29.088389335Z caller=middlewares.go:46 method=Register username=hjFZIGfA email=hjFZIGfA@gmail.com took=2.576341ms
  08:14:32.212 [front-end] Received response: "{\"firstName\":\"hPcZoGR\",\"lastName\":\"hPcZoGR\",\"username\":\"hPcZoGR\",\"id\":\"67418ed0a437380001def227\",\"_links\":{\"addresses\":{
  08:14:34.500 [front-end] Order response: {"statusCode":201,"body":{"id":"67418eea3f77060008864feb","customerId":"67418ed1a437380001def22c","customer":{"id":null,"firstName":"CPjEaKTsIzj
  08:14:37.206 [front-end] Received response: "{\"firstName\":\"EDtKtIK\",\"lastName\":\"EDtKtIK\",\"username\":\"EDtKtIK\",\"id\":\"67418ed3a437380001def230\",\"_links\":{\"addresses\":{
  08:14:38.992 [front-end] Order response: {"statusCode":201,"body":{"id":"67418eee3f77060008864ff1","customerId":"67418edca437380001def251","customer":{"id":null,"firstName":"DYVdBLexbV"
  08:14:42.165 [front-end] Received response: "{\"firstName\":\"gkzpjDVk\",\"lastName\":\"gkzpjDVk\",\"username\":\"gkzpjDVk\",\"id\":\"67418ed5a437380001def23c\",\"_links\":{\"addresses\
  08:14:44.242 [front-end] Order response: {"statusCode":201,"body":{"id":"67418ef43f77060008864ff7","customerId":"67418edca437380001def250","customer":{"id":null,"firstName":"xJAJwse","l

## p0096
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:05:51.640Z
```
{"service":"frontend","operation":"hipstershop.CheckoutService/PlaceOrder","method":"PlaceOrder","status_code":13,"duration_us":27105,"trace_id":"bfc52b9eb6fef86dcd193fc701e0f189","message":"span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13"}
```
Same service, the 2 minutes before (oldest first):
  05:05:51.099 [frontend] adding to cart  (×2)
  05:05:51.109 [frontend] request complete  (×7)
  05:05:51.113 [frontend] request started  (×6)
  05:05:51.113 [frontend] view user cart  (×2)
  05:05:51.258 [frontend] serving product page  (×2)
  05:05:51.640 [frontend] placing order
All services, 30 seconds either side (sampled):
  05:05:28.413 [frontend] request started  (×265)
  05:05:28.422 [cartservice] GetCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×218)
  05:05:28.449 [adservice] received ad request (context_words=[accessories])  (×17)
  05:05:28.458 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=1YMWWN1N4O, quantity=7  (×26)
  05:05:28.497 [shippingservice] [GetQuote] completed request  (×59)
  05:05:28.996 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="USD"  (×6)
  05:05:29.017 [checkoutservice] payment went through (transaction_id: e43c7587-0e24-4a72-8d85-16a465855b2a)  (×9)
  05:05:29.021 [cartservice] EmptyCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×9)
  05:05:29.030 [frontend] order placed  (×9)
  05:05:31.741 [adservice] received ad request (context_words=[decor, home])  (×11)
  05:05:32.748 [frontend] ENV_PLATFORM is: aws  (×39)
  05:05:33.869 [adservice] received ad request (context_words=[footwear])  (×17)
  05:05:33.972 [paymentservice] Transaction processed: visa ending 2652 Amount: CAD426.701933656
  05:05:38.673 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×4)
  05:05:46.056 [emailservice] A request to send order confirmation email to fcontreras@example.com has been received.
  05:05:51.663 [paymentservice] UnacceptedCreditCard [Error]: Sorry, we cannot process visa_electron credit cards. Only VISA or MasterCard is accepted. at charge (/usr/src/app/charge.js:74:68)
  05:05:51.667 [frontend] request error
  05:05:52.048 [redis] 47:C 18 Nov 2024 05:05:52.048 * DB saved on disk
  05:05:52.502 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="EUR"
  05:05:52.540 [emailservice] A request to send order confirmation email to vsimpson@example.net has been received.
  05:06:04.238 [checkoutservice] order confirmation email sent to "michaelacosta@example.net"
  05:06:10.954 [emailservice] A request to send order confirmation email to michael03@example.com has been received.
  05:06:12.456 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"107763","nanos":686865077},"credit_card":{"credit_card_number":"43292417215
  05:06:12.472 [checkoutservice] order confirmation email sent to "leenathaniel@example.org"

## p0046
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-13T08:05:22.502Z
```
{"service":"mobservice1","message":"2021-08-13 08:05:22,502 | INFO | 0.0.0.1 | 172.17.0.5 | mobservice1 | 21b936fd1a0debb0 | info 270df824-fbca-11eb-81ed-0242ac110004:tlangOdN write success"}
```
Same service, the 2 minutes before (oldest first):
  08:05:17.906 [mobservice1] INFO info 244a2e00-fbca-11eb-a396-0242ac110004:FAmtCcIX write success
  08:05:18.441 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  08:05:18.441 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  08:05:18.442 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '24a7c466-fbca-11eb-a52e-0242ac110003'}  (×4)
  08:05:18.486 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '24a7c466-fbca-11eb-a52e-0242ac110003', 'value': 'EJMXPwRO'}  (×4)
  08:05:18.531 [mobservice1] INFO info 24a7c466-fbca-11eb-a52e-0242ac110003:EJMXPwRO write success
  08:05:19.598 [mobservice1] INFO info 254827a8-fbca-11eb-9c82-0242ac110004:GEFNbRmp write success
  08:05:21.508 [mobservice1] INFO info 2671f4ce-fbca-11eb-af5f-0242ac110004:dsqULkKQ write success
All services, 30 seconds either side (sampled):
  08:04:52.570 [redisservice2] INFO redis读取信息成功, status_code: 200  (×49)
  08:04:52.671 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×53)
  08:04:52.818 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×47)
  08:04:53.025 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×52)
  08:04:53.227 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×40)
  08:04:53.354 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×50)
  08:04:54.039 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×55)
  08:04:54.693 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  08:04:55.162 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '16ed8036-fbca-11eb-a303-0242ac110003', 'value': '', 'ex': 10}  (×51)
  08:04:57.057 [mobservice1] INFO info 17d2439c-fbca-11eb-a3e6-0242ac110003:rGxaBlKJ write success
  08:04:59.505 [mobservice2] INFO info 1953b9da-fbca-11eb-8bd3-0242ac110004:NmlBnobg write success
  08:05:02.612 [mobservice1] INFO info 1b224830-fbca-11eb-99db-0242ac110003:Egncqoka write success
  08:05:05.481 [mobservice2] INFO info 1cd5d714-fbca-11eb-b1ff-0242ac110003:TAFqsYCb write success
  08:05:08.574 [mobservice2] INFO info 1eb2b32c-fbca-11eb-8da0-0242ac110003:OBgRIvmU write success
  08:05:11.334 [mobservice2] INFO info 2058877e-fbca-11eb-9600-0242ac110003:PFOBQRXk write success
  08:05:15.030 [mobservice2] INFO info 228f2534-fbca-11eb-af9c-0242ac110003:wrMmJDYH write success
  08:05:18.531 [mobservice1] INFO info 24a7c466-fbca-11eb-a52e-0242ac110003:EJMXPwRO write success
  08:05:21.050 [dbservice1] INFO 25d3461c-fbca-11eb-bfa7-0242ac110004-QSUqdTsv-er_ATbj}/nc7 token generate success token=MTYyODgxMzEyMS4wNTA0MDEyOjI1ZDM0NjFjLWZiY2EtMTFlYi1iZmE3LTAyNDJhYzE
  08:05:24.799 [mobservice1] INFO info 2867ad46-fbca-11eb-afe9-0242ac110004:Jcofhzdp write success
  08:05:27.498 [dbservice1] INFO 29d5f8c2-fbca-11eb-b16b-0242ac110004-PQTXyvDH-<gtzUvdoS?4) token generate success token=MTYyODgxMzEyNy40OTc4OTcxOjI5ZDVmOGMyLWZiY2EtMTFlYi1iMTZiLTAyNDJhYzE
  08:05:29.758 [dbservice1] INFO 2b339fe4-fbca-11eb-b208-0242ac110004-avTqnNxg-L$C9/.km:^B% token generate success token=MTYyODgxMzEyOS43NTgzNzY2OjJiMzM5ZmU0LWZiY2EtMTFlYi1iMjA4LTAyNDJhYzE
  08:05:33.089 [mobservice2] INFO info 2d45039a-fbca-11eb-92c1-0242ac110003:zWngqvYN write success
  08:05:36.818 [mobservice1] INFO info 2f9263b8-fbca-11eb-b34c-0242ac110004:HfPCXKQO write success
  08:05:39.467 [mobservice1] INFO info 31218aba-fbca-11eb-bd1e-0242ac110004:pxXmtnLl write success
  08:05:42.437 [dbservice1] INFO 32ae5642-fbca-11eb-93af-0242ac110004-PyWJlfep-iu/am&SCWnFx token generate success token=MTYyODgxMzE0Mi40MzcxODYyOjMyYWU1NjQyLWZiY2EtMTFlYi05M2FmLTAyNDJhYzE
  08:05:45.705 [dbservice1] INFO 347b54c0-fbca-11eb-97c4-0242ac110003-VnGSpqai-jIe*x?+nDlz> token generate success token=MTYyODgxMzE0NS43MDUxNzA2OjM0N2I1NGMwLWZiY2EtMTFlYi05N2M0LTAyNDJhYzE
  08:05:49.207 [mobservice2] INFO info 36fafe6c-fbca-11eb-bd71-0242ac110004:IlvgFiyE write success
  08:05:51.756 [mobservice1] INFO info 3871bd94-fbca-11eb-ab22-0242ac110003:lESgOeYC write success

## p0735
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service checkoutservice, 2024-11-22T12:23:09.067Z
```
{"service":"checkoutservice","operation":"hipstershop.PaymentService/Charge","method":"Charge","status_code":400,"duration_us":5131,"trace_id":"6c1a5489386d4360f0d347e428dcfed7","message":"span hipstershop.PaymentService/Charge failed with gRPC status 400"}
```
Same service, the 2 minutes before (oldest first):
  12:22:49.548 [checkoutservice] [PlaceOrder] user_id="b1978cca-deb1-4a57-89d8-dda1e4c67888" user_currency="CAD"  (×3)
  12:22:49.597 [checkoutservice] payment went through (transaction_id: 767b8471-660d-40f7-84af-b0d2944a1151)  (×6)
  12:22:49.609 [checkoutservice] order confirmation email sent to "hannah68@example.com"
  12:22:57.727 [checkoutservice] [PlaceOrder] user_id="07008eda-9426-4259-a693-c0275e226c75" user_currency="JPY"
  12:22:57.822 [checkoutservice] order confirmation email sent to "aanderson@example.org"
  12:23:00.130 [checkoutservice] order confirmation email sent to "jennifermayer@example.org"
  12:23:03.043 [checkoutservice] [PlaceOrder] user_id="8840e449-c562-4c1b-a872-f1dda11ad3bc" user_currency="GBP"  (×2)
  12:23:03.119 [checkoutservice] order confirmation email sent to "lisa64@example.net"
  12:23:04.509 [checkoutservice] order confirmation email sent to "floressteven@example.com"
  12:23:06.238 [checkoutservice] order confirmation email sent to "vrussell@example.com"
  12:23:09.038 [checkoutservice] [PlaceOrder] user_id="d01583c7-1498-45eb-a9a8-e4d2cc36d456" user_currency="TRY"
  12:23:09.038 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
All services, 30 seconds either side (sampled):
  12:22:39.445 [frontend] request started  (×352)
  12:22:39.449 [frontend] home  (×42)
  12:22:39.464 [currencyservice] conversion request successful  (×804)
  12:22:39.742 [frontend] serving product page  (×147)
  12:22:40.491 [adservice] received ad request (context_words=[accessories])  (×41)
  12:22:40.509 [frontend] view user cart  (×76)
  12:22:40.539 [shippingservice] [GetQuote] completed request  (×90)
  12:22:44.844 [adservice] received ad request (context_words=[decor, home])  (×14)
  12:22:48.106 [checkoutservice] [PlaceOrder] user_id="4685a666-2807-489a-bc47-9c225a054c9e" user_currency="TRY"  (×3)
  12:22:48.140 [checkoutservice] payment went through (transaction_id: e5517cc2-2faf-488c-a1fe-709e9c4ccf59)  (×13)
  12:22:48.149 [cartservice] EmptyCartAsync called with userId=4685a666-2807-489a-bc47-9c225a054c9e  (×13)
  12:22:48.159 [frontend] order placed  (×13)
  12:22:48.864 [paymentservice] Transaction processed: visa ending 6582 Amount: JPY11621.420610630  (×3)
  12:22:49.494 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', '6E92ZMYYFZ', '66VCHSJNUP', 'OLJCESPC7Z']  (×5)
  12:22:49.594 [paymentservice] Transaction processed: visa ending 6505 Amount: CAD2635.831529409  (×5)
  12:22:57.821 [emailservice] A request to send order confirmation email to aanderson@example.org has been received.
  12:23:00.130 [checkoutservice] order confirmation email sent to "jennifermayer@example.org"
  12:23:03.104 [paymentservice] Transaction processed: visa ending 1957 Amount: GBP67.642914637  (×2)
  12:23:04.507 [emailservice] A request to send order confirmation email to floressteven@example.com has been received.
  12:23:06.238 [checkoutservice] order confirmation email sent to "vrussell@example.com"
  12:23:09.068 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  12:23:09.073 [frontend] request error
  12:23:20.666 [emailservice] A request to send order confirmation email to imcdaniel@example.com has been received.
  12:23:24.631 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"78","nanos":681999117},"credit_card":{"credit_card_number":"405989720820570
  12:23:24.644 [checkoutservice] order confirmation email sent to "elizabeth72@example.com"
  12:23:38.654 [emailservice] A request to send order confirmation email to debbie49@example.org has been received.

## p0020
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice2, 2021-08-13T06:41:51.029Z
```
{"service":"redisservice2","message":"2021-08-13 06:41:51,029 | INFO | 0.0.0.2 | 172.17.0.4 | redisservice2 | 911bf468fd0dd041 | service accept, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  06:41:45.546 [redisservice2] INFO service accept, status_code: 200  (×4)
  06:41:45.623 [redisservice2] INFO redis读取信息成功, status_code: 200  (×4)
  06:41:47.102 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×5)
  06:41:47.190 [redisservice2] INFO redis write success  (×7)
All services, 30 seconds either side (sampled):
  06:41:21.050 [redisservice2] INFO redis write success  (×68)
  06:41:21.170 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×37)
  06:41:21.301 [redisservice2] INFO service accept, status_code: 200  (×39)
  06:41:21.623 [webservice2] INFO complete information: {'uuid': '6a862c36-fbbe-11eb-b14d-0242ac110004', 'user_id': 'XWkAGNLi'}  (×36)
  06:41:21.758 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '6a862c36-fbbe-11eb-b14d-0242ac110004', 'value': 'XWkAGNLi'}  (×44)
  06:41:22.232 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  06:41:22.405 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×38)
  06:41:22.949 [webservice1] ERROR an error occurred in the downstream service  (×4)
  06:41:23.369 [mobservice1] INFO info 6b756364-fbbe-11eb-8ddf-0242ac110004:ODxjMiJU write success
  06:41:24.423 [dbservice2] INFO 6be69962-fbbe-11eb-b9c1-0242ac110004-RUxdhMNy-/YudT7Rc_DW: token generate success token=MTYyODgwODA4NC40MjMwNjM1OjZiZTY5OTYyLWZiYmUtMTFlYi1iOWMxLTAyNDJhYzE
  06:41:26.018 [dbservice2] INFO 6cd111f4-fbbe-11eb-ab45-0242ac110004-VizMUmJR-FY?r-G0Za*AR token generate success token=MTYyODgwODA4Ni4wMTc3MTE5OjZjZDExMWY0LWZiYmUtMTFlYi1hYjQ1LTAyNDJhYzE
  06:41:28.438 [mobservice1] INFO info 6e7d7858-fbbe-11eb-bd5b-0242ac110003:efoEbcGO write success
  06:41:30.706 [dbservice1] INFO 6f9db3ce-fbbe-11eb-be84-0242ac110003-ArxCmQcb-p-n+Fy1&AjMv token generate success token=MTYyODgwODA5MC43MDY1Mjc6NmY5ZGIzY2UtZmJiZS0xMWViLWJlODQtMDI0MmFjMTE
  06:41:32.759 [mobservice2] INFO info 710aa05a-fbbe-11eb-bbc0-0242ac110004:vUsGrNAF write success
  06:41:34.824 [dbservice1] INFO 7204e330-fbbe-11eb-a520-0242ac110003-JVwBQHua-/A_5xQRM{X.J token generate success token=MTYyODgwODA5NC44MjQwMDk6NzIwNGUzMzAtZmJiZS0xMWViLWE1MjAtMDI0MmFjMTE
  06:41:42.465 [mobservice2] INFO info 76d58900-fbbe-11eb-bbcb-0242ac110003:LCiNwseu write success
  06:41:45.092 [dbservice2] INFO 782fd508-fbbe-11eb-bc31-0242ac110004-nulqIiBE-H(j2E8MvFo.w token generate success token=MTYyODgwODEwNS4wOTE3OTI6NzgyZmQ1MDgtZmJiZS0xMWViLWJjMzEtMDI0MmFjMTE
  06:41:47.203 [mobservice2] INFO info 799d5d0c-fbbe-11eb-a944-0242ac110003:bHrMSWsj write success
  06:41:49.425 [mobservice1] INFO info 7b029cac-fbbe-11eb-80d3-0242ac110003:NgkejbAm write success
  06:41:51.787 [mobservice1] INFO info 7c68bcc0-fbbe-11eb-8cc3-0242ac110004:OkyWpDvC write success
  06:41:53.860 [dbservice2] INFO 7d741178-fbbe-11eb-accc-0242ac110004-RVeouDMj-(Nah*B8-w4n1 token generate success token=MTYyODgwODExMy44NjA0NjQ4OjdkNzQxMTc4LWZiYmUtMTFlYi1hY2NjLTAyNDJhYzE
  06:41:56.309 [mobservice1] INFO info 7f15efe2-fbbe-11eb-9124-0242ac110003:TebkoQLO write success
  06:41:59.048 [mobservice1] INFO info 80c15c50-fbbe-11eb-b59e-0242ac110003:dsqULkKQ write success
  06:42:01.156 [dbservice2] INFO 81b77784-fbbe-11eb-b7bf-0242ac110003-GYgLnikZ-DR.*AP0Lv^aF token generate success token=MTYyODgwODEyMS4xNTYxMjU6ODFiNzc3ODQtZmJiZS0xMWViLWI3YmYtMDI0MmFjMTE
  06:42:07.755 [mobservice2] INFO info 85e3d0fa-fbbe-11eb-ab3b-0242ac110003:EGieKLYv write success
  06:42:13.548 [redisservice2] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400
  06:42:15.031 [dbservice2] INFO 8a110440-fbbe-11eb-8e98-0242ac110004-lykPtSEm-Uo4)Bv3.0QsS token generate success token=MTYyODgwODEzNS4wMzA5MDk4OjhhMTEwNDQwLWZiYmUtMTFlYi04ZTk4LTAyNDJhYzE
  06:42:17.076 [mobservice2] INFO info 8b7d72c8-fbbe-11eb-9b18-0242ac110003:kdncspNK write success
  06:42:19.349 [dbservice2] INFO 8ca4a806-fbbe-11eb-b9fb-0242ac110004-saJCEzRp-rVa(<KJAO=cm token generate success token=MTYyODgwODEzOS4zNDkwOTIyOjhjYTRhODA2LWZiYmUtMTFlYi1iOWZiLTAyNDJhYzE

## p0379
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-22T03:42:30.502Z
```
{"timestamp":1732246950502686200,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-nz8kk","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-22 03:42:30.502  INFO 6 --- [ool-6-thread-19] w.weave.socks.queuemaster.DockerSpawner  : Spawning new container"}
```
Same service, the 2 minutes before (oldest first):
  03:42:25.947 [queue-master] 2024-11-22 03:42:25.947 ERROR 6 --- [ool-6-thread-16] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×3)
  03:42:26.163 [queue-master] Received shipment task: 673ffd93b0df5c00019b2e7c  (×3)
  03:42:26.163 [queue-master] 2024-11-22 03:42:26.163 INFO 6 --- [ool-6-thread-17] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×2)
  03:42:26.164 [queue-master] 2024-11-22 03:42:26.164 INFO 6 --- [ool-6-thread-17] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×6)
  03:42:26.164 [queue-master] 2024-11-22 03:42:26.164 INFO 6 --- [ool-6-thread-17] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×6)
All services, 30 seconds either side (sampled):
  03:42:01.129 [front-end] Request received with body: {}  (×56)
  03:42:01.159 [orders] 2024-11-22 03:42:01.159 INFO [orders,fc3eb64af0d1c572,eebbebe0d01a6f38,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×23)
  03:42:01.177 [front-end] POST /orders 201 - ms - -  (×56)
  03:42:01.485 [front-end] POST /register 200 30.751 ms - 33  (×58)
  03:42:02.039 [front-end] Attempting to delete cart for user: 673ffd82b0df5c00019b2e4d  (×59)
  03:42:02.379 [user] ts=2024-11-22T03:42:02.379639035Z caller=middlewares.go:46 method=Register username=TnuECCeKX email=TnuECCeKX@gmail.com took=1.089731ms
  03:42:04.359 [queue-master] 2024-11-22 03:42:04.359 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×27)
  03:42:05.954 [front-end] Posting Customer: {"username":"nqEIXwdzikKDk","password":"bvCsvdMV","email":"nqEIXwdzikKDk@gmail.com","firstName":"nqEIXwdzikKDk","lastName":"nqEIXwdzikKDk"}
  03:42:08.615 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×8)
  03:42:11.287 [front-end] Posting Customer: {"username":"rxpiYCqYJg","password":"fptqDzzW","email":"rxpiYCqYJg@gmail.com","firstName":"rxpiYCqYJg","lastName":"rxpiYCqYJg"}
  03:42:12.309 [front-end] Order response: {"id":"673ffd94d94b9000069b477f","customerId":"673ffd81b0df5c00019b2e4c","customer":{"id":null,"firstName":"vSjVrawEN","lastName":"vSjVrawEN","u
  03:42:15.303 [user] ts=2024-11-22T03:42:15.303040358Z caller=middlewares.go:46 method=Register username=YrXpJfMg email=YrXpJfMg@gmail.com took=1.088524ms
  03:42:17.337 [user] ts=2024-11-22T03:42:17.337514336Z caller=middlewares.go:46 method=Register username=uhFTI email=uhFTI@gmail.com took=1.02611ms
  03:42:20.501 [front-end] Received response: "{\"firstName\":\"MofKylMnIFTBeu\",\"lastName\":\"MofKylMnIFTBeu\",\"username\":\"MofKylMnIFTBeu\",\"id\":\"673ffd87b0df5c00019b2e5b\",\"_lin
  03:42:21.663 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd9dd94b9000069b4786","customerId":"673ffd8ab0df5c00019b2e63","customer":{"id":null,"firstName":"TnuECCeKX",
  03:42:25.013 [user] ts=2024-11-22T03:42:25.013572883Z caller=middlewares.go:46 method=Register username=tQjwevqG email=tQjwevqG@gmail.com took=981.033µs
  03:42:26.168 [front-end] Order response: {"id":"673ffda2d94b9000069b478a","customerId":"673ffd93b0df5c00019b2e7c","customer":{"id":null,"firstName":"jHkZJjNnsQvHz","lastName":"jHkZJjNns
  03:42:28.225 [user] ts=2024-11-22T03:42:28.225375332Z caller=middlewares.go:46 method=Register username=zupcY email=zupcY@gmail.com took=1.101084ms
  03:42:30.916 [front-end] Order response: {"id":"673ffda6d94b9000069b478d","customerId":"673ffd8fb0df5c00019b2e70","customer":{"id":null,"firstName":"xWSocHQPIT","lastName":"xWSocHQPIT",
  03:42:33.321 [front-end] Received response: "{\"firstName\":\"oeONy\",\"lastName\":\"oeONy\",\"username\":\"oeONy\",\"id\":\"673ffd94b0df5c00019b2e7e\",\"_links\":{\"addresses\":{\"href
  03:42:35.999 [front-end] Received response: "{\"firstName\":\"qMpkYeUHCTtBm\",\"lastName\":\"qMpkYeUHCTtBm\",\"username\":\"qMpkYeUHCTtBm\",\"id\":\"673ffd97b0df5c00019b2e86\",\"_links\
  03:42:38.282 [front-end] Received response: "{\"firstName\":\"mJItTkjoJQArNj\",\"lastName\":\"mJItTkjoJQArNj\",\"username\":\"mJItTkjoJQArNj\",\"id\":\"673ffd98b0df5c00019b2e89\",\"_lin
  03:42:40.387 [front-end] Received response: "{\"firstName\":\"YXwskdSP\",\"lastName\":\"YXwskdSP\",\"username\":\"YXwskdSP\",\"id\":\"673ffd9cb0df5c00019b2e9c\",\"_links\":{\"addresses\
  03:42:43.972 [front-end] Received response: "{\"firstName\":\"SDYPDvGdi\",\"lastName\":\"SDYPDvGdi\",\"username\":\"SDYPDvGdi\",\"id\":\"673ffd9fb0df5c00019b2ea9\",\"_links\":{\"address
  03:42:48.427 [front-end] Received response: "{\"firstName\":\"zupcY\",\"lastName\":\"zupcY\",\"username\":\"zupcY\",\"id\":\"673ffda4b0df5c00019b2ebb\",\"_links\":{\"addresses\":{\"href
  03:42:49.341 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdb9d94b9000069b479f","customerId":"673ffda3b0df5c00019b2eb7","customer":{"id":null,"firstName":"XXMXxnGnNJd
  03:42:50.812 [front-end] Received response: "{\"firstName\":\"pqcqbeGDrS\",\"lastName\":\"pqcqbeGDrS\",\"username\":\"pqcqbeGDrS\",\"id\":\"673ffda4b0df5c00019b2ebc\",\"_links\":{\"addr
  03:42:52.842 [front-end] Order response: {"id":"673ffdbcd94b9000069b47a5","customerId":"673ffdafb0df5c00019b2edb","customer":{"id":null,"firstName":"dKJqEJ","lastName":"dKJqEJ","usernam
  03:42:56.414 [front-end] Posting Customer: {"username":"SvRvqJSYrXwS","password":"kKQjJt","email":"SvRvqJSYrXwS@gmail.com","firstName":"SvRvqJSYrXwS","lastName":"SvRvqJSYrXwS"}

## p0639
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T20:24:43.580Z
```
{"timestamp":1733603083580340200,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-f7tv2","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 20:24:43.580  INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl       : [Train Service] calculate time：0  time: Sat May 04 01:51:52 GMT 2013"}
```
Same service, the 2 minutes before (oldest first):
  20:24:41.900 [ts-travel2-service] 2024-12-07 20:24:41.900 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：1367db1f-461e-4ab7-87ad-2bc  (×4)
  20:24:41.907 [ts-travel2-service] 2024-12-07 20:24:41.907 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×4)
  20:24:43.280 [ts-travel2-service] 2024-12-07 20:24:43.280 INFO 1 --- [io-16346-exec-1] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  20:24:43.375 [ts-travel2-service] 2024-12-07 20:24:43.375 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  20:24:43.383 [ts-travel2-service] 2024-12-07 20:24:43.382 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  20:24:43.428 [ts-travel2-service] 2024-12-07 20:24:43.428 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  20:24:43.442 [ts-travel2-service] 2024-12-07 20:24:43.441 INFO 1 --- [io-16346-exec-2] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234  (×2)
  20:24:43.451 [ts-travel2-service] 2024-12-07 20:24:43.451 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  20:24:43.487 [ts-travel2-service] 2024-12-07 20:24:43.487 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  20:24:43.565 [ts-travel2-service] 2024-12-07 20:24:43.565 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0
All services, 30 seconds either side (sampled):
  20:24:13.743 [ts-auth-service] 2024-12-07 20:24:13.743 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×15)
  20:24:13.988 [ts-basic-service] 2024-12-07 20:24:13.988 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×107)
  20:24:14.059 [ts-price-service] 2024-12-07 20:24:14.059 INFO 1 --- [io-16579-exec-6] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×27)
  20:24:14.123 [ts-seat-service] 2024-12-07 20:24:14.123 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×7)
  20:24:14.173 [ts-seat-service] 2024-12-07 20:24:14.173 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×7)
  20:24:14.289 [ts-seat-service] 2024-12-07 20:24:14.289 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×23)
  20:24:15.140 [ts-travel-service] 2024-12-07 20:24:15.139 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×17)
  20:24:15.240 [ts-seat-service] 2024-12-07 20:24:15.240 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×11)
  20:24:15.338 [ts-travel-service] 2024-12-07 20:24:15.338 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×4)
  20:24:15.774 [ts-order-service] 2024-12-07 20:24:15.773 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is empty
  20:24:16.225 [ts-travel-service] 2024-12-07 20:24:16.225 INFO 1 --- [io-12346-exec-9] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×15)
  20:24:17.390 [ts-travel2-service] 2024-12-07 20:24:17.390 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×4)
  20:24:24.108 [ts-admin-basic-info-service] 2024-12-07 20:24:24.108 INFO 1 --- [io-18767-exec-6] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×7)
  20:24:28.354 [ts-travel-mongo] {"t":{"$date":"2024-12-07T20:24:28.354+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360306
  20:24:30.981 [ts-station-mongo] {"t":{"$date":"2024-12-07T20:24:30.981+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360307
  20:24:31.887 [ts-user-mongo] {"t":{"$date":"2024-12-07T20:24:31.886+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360307
  20:24:36.717 [ts-basic-service] 2024-12-07 20:24:36.717 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×7)
  20:24:47.644 [ts-basic-service] 2024-12-07 20:24:47.644 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×27)
  20:24:49.022 [ts-travel-service] 2024-12-07 20:24:49.021 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×3)
  20:24:57.126 [ts-consign-service] 2024-12-07 20:24:57.126 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : The handle date is 2024-12-07  (×2)
  20:24:58.465 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:24:58 +0800] "GET /api/v1/contactservice/contacts/account/4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f HTTP/1.1" 200 471 "-" "Mozilla/5.0   (×2)
  20:24:58.513 [ts-security-service] 2024-12-07 20:24:58.512 INFO 1 --- [io-11188-exec-8] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Last One Hour:
  20:24:58.603 [ts-preserve-service] 2024-12-07 20:24:58.602 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] Check tickets num
  20:24:58.899 [ts-preserve-service] 2024-12-07 20:24:58.898 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : TripAllDetail:TripAllDetail(status=false, message=null, tripResponse
  20:24:59.005 [ts-seat-service] 2024-12-07 20:24:59.005 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService distributeSeat] Use a new seat number! 1070389337
  20:24:59.043 [ts-assurance-service] 2024-12-07 20:24:59.043 INFO 1 --- [io-18888-exec-2] assurance.service.AssuranceServiceImpl : [Assurance-Add&Delete-Service][AddAssurance] Success.
  20:24:59.071 [ts-user-mongo] {"t":{"$date":"2024-12-07T20:24:59.071+00:00"},"s":"W", "c":"COMMAND", "id":5578800, "ctx":"conn12","msg":"Deprecated operation requested. The client driver may
  20:25:13.005 [ts-basic-service] 2024-12-07 20:25:13.005 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieT

## p0154
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:43:30.112Z
```
{"service":"frontend","operation":"hipstershop.CartService/AddItem","method":"AddItem","status_code":9,"duration_us":7618,"trace_id":"e9f22243ad2b61891b1f8e110ba3b29d","message":"span hipstershop.CartService/AddItem failed with gRPC status 9"}
```
Same service, the 2 minutes before (oldest first):
  05:43:28.411 [frontend] request started  (×7)
  05:43:28.411 [frontend] serving product page  (×4)
  05:43:28.431 [frontend] view user cart  (×2)
  05:43:28.446 [frontend] request complete  (×6)
  05:43:30.111 [frontend] adding to cart
All services, 30 seconds either side (sampled):
  05:43:00.113 [currencyservice] conversion request successful  (×662)
  05:43:00.133 [frontend] serving product page  (×147)
  05:43:00.154 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', 'OLJCESPC7Z', '2ZYFJ3GM2N', '66VCHSJNUP', '0PUK6V6EV0']  (×202)
  05:43:00.314 [shippingservice] [GetQuote] received request  (×56)
  05:43:00.759 [frontend] setting currency  (×24)
  05:43:00.857 [frontend] ENV_PLATFORM is: aws  (×38)
  05:43:03.387 [adservice] received ad request (context_words=[footwear])  (×10)
  05:43:03.462 [frontend] placing order  (×11)
  05:43:03.498 [paymentservice] Transaction processed: visa ending 1251 Amount: EUR1624.705882362  (×2)
  05:43:03.502 [shippingservice] [ShipOrder] completed request  (×11)
  05:43:03.513 [checkoutservice] order confirmation email sent to "sanderscorey@example.org"
  05:43:06.465 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', 'L9ECAV7KIM', 'OLJCESPC7Z', '9SIQT8TOJO']
  05:43:06.551 [paymentservice] Transaction processed: visa ending 0448 Amount: GBP1174.629288797
  05:43:09.164 [checkoutservice] [PlaceOrder] user_id="fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a" user_currency="JPY"  (×3)
  05:43:09.210 [emailservice] A request to send order confirmation email to iadams@example.com has been received.
  05:43:10.034 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"151","nanos":587002213},"credit_card":{"credit_card_number":"40485534991203  (×3)
  05:43:10.052 [checkoutservice] order confirmation email sent to "schroederlucas@example.com"
  05:43:13.621 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="USD"
  05:43:13.667 [emailservice] A request to send order confirmation email to woodariel@example.org has been received.
  05:43:23.871 [frontend] span hipstershop.CartService/GetCart failed with gRPC status 14  (×20)
  05:43:24.746 [cartservice] info: Microsoft.Hosting.Lifetime[0] Application started. Press Ctrl+C to shut down.
  05:43:27.925 [cartservice] AddItemAsync called with userId=0ae6d9b6-4e7f-4d38-a0eb-042389dcac30, productId=6E92ZMYYFZ, quantity=10000000000  (×20)
  05:43:28.344 [checkoutservice] order confirmation email sent to "zscott@example.com"
  05:43:41.859 [emailservice] A request to send order confirmation email to david03@example.com has been received.
  05:43:51.788 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"117","nanos":691959309},"credit_card":{"credit_card_number":"48435217587252
  05:43:51.801 [checkoutservice] order confirmation email sent to "jmyers@example.com"

## p0564
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T18:30:17.502Z
```
{"timestamp":1733596217502572300,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-kwkx6","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:30:17.502  INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl       : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b04  station: [shanghai, nanjing, shijiazhuang, taiyuan]"}
```
Same service, the 2 minutes before (oldest first):
  18:30:11.626 [ts-travel2-service] 2024-12-07 18:30:11.626 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×5)
  18:30:11.627 [ts-travel2-service] 2024-12-07 18:30:11.627 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：1367db1f-461e-4ab7-87ad-2bc  (×4)
  18:30:17.086 [ts-travel2-service] 2024-12-07 18:30:17.085 INFO 1 --- [io-16346-exec-9] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  18:30:17.238 [ts-travel2-service] 2024-12-07 18:30:17.238 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  18:30:17.286 [ts-travel2-service] 2024-12-07 18:30:17.286 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  18:30:17.347 [ts-travel2-service] 2024-12-07 18:30:17.346 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  18:30:17.359 [ts-travel2-service] 2024-12-07 18:30:17.359 INFO 1 --- [io-16346-exec-4] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234  (×2)
  18:30:17.366 [ts-travel2-service] 2024-12-07 18:30:17.366 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  18:30:17.401 [ts-travel2-service] 2024-12-07 18:30:17.401 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
All services, 30 seconds either side (sampled):
  18:29:47.624 [ts-auth-service] 2024-12-07 18:29:47.624 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×5)
  18:29:47.886 [ts-travel-service] 2024-12-07 18:29:47.886 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×13)
  18:29:47.951 [ts-travel-service] 2024-12-07 18:29:47.950 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×14)
  18:29:48.211 [ts-travel2-service] 2024-12-07 18:29:48.211 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×105)
  18:29:54.871 [ts-auth-service] 2024-12-07 18:29:54.870 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×2)
  18:30:00.251 [ts-basic-service] 2024-12-07 18:30:00.251 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
  18:30:00.279 [ts-basic-service] 2024-12-07 18:30:00.278 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×6)
  18:30:00.304 [ts-travel2-service] 2024-12-07 18:30:00.303 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×11)
  18:30:00.385 [ts-order-other-service] 2024-12-07 18:30:00.385 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×23)
  18:30:00.471 [ts-seat-service] 2024-12-07 18:30:00.470 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×23)
  18:30:02.384 [ts-travel2-service] 2024-12-07 18:30:02.384 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×2)
  18:30:02.475 [ts-price-service] 2024-12-07 18:30:02.475 INFO 1 --- [io-16579-exec-1] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×17)
  18:30:02.534 [ts-food-service] 2024-12-07 18:30:02.534 INFO 1 --- [io-18856-exec-6] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×3)
  18:30:02.696 [ts-travel2-service] 2024-12-07 18:30:02.696 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6  (×2)
  18:30:07.330 [ts-order-other-service] 2024-12-07 18:30:07.330 INFO 1 --- [io-12032-exec-2] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×11)
  18:30:09.590 [ts-inside-payment-service] 2024-12-07 18:30:09.588 INFO 1 --- [io-18673-exec-7] i.service.InsidePaymentServiceImpl : Out pay result: Response(status=1, msg=Pay Success, data=null)
  18:30:14.631 [ts-basic-service] 2024-12-07 18:30:14.630 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×23)
  18:30:14.739 [ts-order-service] 2024-12-07 18:30:14.739 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×6)
  18:30:14.807 [ts-seat-service] 2024-12-07 18:30:14.807 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×11)
  18:30:15.479 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:30:15 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 916 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×3)
  18:30:15.880 [ts-auth-service] 2024-12-07 18:30:15.880 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:16}] to ts-auth-mongo:2  (×4)
  18:30:17.523 [ts-travel-service] 2024-12-07 18:30:17.523 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1237
  18:30:26.260 [ts-auth-service] 2024-12-07 18:30:26.260 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default
  18:30:29.606 [ts-food-service] 2024-12-07 18:30:29.605 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  18:30:29.940 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:30:29.940+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359622
  18:30:31.939 [ts-order-service] 2024-12-07 18:30:31.939 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 
  18:30:40.512 [ts-order-other-service] 2024-12-07 18:30:40.512 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 24
  18:30:42.020 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T18:30:42.020+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359624
  18:30:44.984 [ts-travel2-service] 2024-12-07 18:30:44.983 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  18:30:47.271 [ts-seat-service] 2024-12-07 18:30:47.271 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×2)

## p0509
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:20:49.366Z
```
{"timestamp":1732353649366450000,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:20:49.366331205Z caller=middlewares.go:75 method=GetUsers id=67419e5ba437380001df10ac result=1 took=2.361018ms"}
```
Same service, the 2 minutes before (oldest first):
  09:20:45.588 [user] ts=2024-11-23T09:20:45.588501251Z caller=middlewares.go:75 method=GetUsers id=67419e5ba437380001df10ad result=1 took=2.194654ms  (×7)
  09:20:46.173 [user] ts=2024-11-23T09:20:46.173492514Z caller=middlewares.go:46 method=Register username=kkmZcfrqfSAoBz email=kkmZcfrqfSAoBz@gmail.com took=1.991038ms  (×2)
  09:20:46.612 [user] ts=2024-11-23T09:20:46.612447163Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419e66a437380001df10d1 took=5.288193ms  (×4)
  09:20:46.629 [user] ts=2024-11-23T09:20:46.628915741Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419e66a437380001df10d1 took=4.982645ms  (×4)
  09:20:46.849 [user] ts=2024-11-23T09:20:46.849056635Z caller=middlewares.go:157 method=Health result=2 took=1.689866ms  (×2)
  09:20:47.689 [user] ts=2024-11-23T09:20:47.689244202Z caller=middlewares.go:46 method=Register username=NcAFa email=NcAFa@gmail.com took=2.328416ms
All services, 30 seconds either side (sampled):
  09:20:19.528 [front-end] Posting Customer: {"username":"TMdpCMER","password":"NAYoCysKuQ","email":"TMdpCMER@gmail.com","firstName":"TMdpCMER","lastName":"TMdpCMER"}
  09:20:19.561 [front-end] Carts merged.  (×41)
  09:20:19.835 [user] ts=2024-11-23T09:20:19.835396853Z caller=middlewares.go:46 method=Register username=UPaYvPL email=UPaYvPL@gmail.com took=2.200198ms
  09:20:19.846 [front-end] GET Request to: http://user/customers/67419e45a437380001df1062/addresses  (×84)
  09:20:19.866 [orders] 2024-11-23 09:20:19.866 ERROR [orders,31e8bdbca253369c,68d81c05cd85f62c,false] 7 --- [p-nio-80-exec-3] o.s.d.r.w.RepositoryRestExceptionHandler : Could not read  (×38)
  09:20:19.869 [front-end] POST /orders 400 - ms - -  (×42)
  09:20:21.621 [front-end] Posting Customer: {"username":"vwEakAiCYlOHQ","password":"VidRC","email":"vwEakAiCYlOHQ@gmail.com","firstName":"vwEakAiCYlOHQ","lastName":"vwEakAiCYlOHQ"}
  09:20:22.411 [user] ts=2024-11-23T09:20:22.411606019Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419e4fa437380001df1083 took=4.200585ms  (×42)
  09:20:22.497 [front-end] User cart deleted with status: 202  (×42)
  09:20:22.538 [carts] 2024-11-23 09:20:22.537 INFO [carts,d11f8ea9b2d3457b,c7900938a8c7881e,false] 7 --- [-nio-80-exec-17] w.w.s.cart.controllers.ItemsController : Did not find item.  (×23)
  09:20:22.894 [front-end] Posting Customer: {"username":"pYXhnBEljpz","password":"GRaOYqRWqd","email":"pYXhnBEljpz@gmail.com","firstName":"pYXhnBEljpz","lastName":"pYXhnBEljpz"}
  09:20:24.199 [front-end] POST to carts: http://carts/carts/67419e4fa437380001df1080/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}  (×20)
  09:20:25.220 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×4)
  09:20:26.534 [user] ts=2024-11-23T09:20:26.533722457Z caller=middlewares.go:46 method=Register username=yijkhezwJ email=yijkhezwJ@gmail.com took=2.652718ms
  09:20:27.451 [user] ts=2024-11-23T09:20:27.451532224Z caller=middlewares.go:46 method=Register username=YOcBo email=YOcBo@gmail.com took=2.21776ms
  09:20:31.164 [front-end] Received response: "{\"firstName\":\"rQUBFxEFqGn\",\"lastName\":\"rQUBFxEFqGn\",\"username\":\"rQUBFxEFqGn\",\"id\":\"67419e47a437380001df106c\",\"_links\":{\"a
  09:20:33.834 [front-end] Posting Customer: {"username":"khPSja","password":"iQcFqMC","email":"khPSja@gmail.com","firstName":"khPSja","lastName":"khPSja"}
  09:20:34.752 [front-end] Received response: "{\"firstName\":\"TMdpCMER\",\"lastName\":\"TMdpCMER\",\"username\":\"TMdpCMER\",\"id\":\"67419e53a437380001df108e\",\"_links\":{\"addresses\
  09:20:36.939 [front-end] Received response: "{\"firstName\":\"cODHTlSydyPz\",\"lastName\":\"cODHTlSydyPz\",\"username\":\"cODHTlSydyPz\",\"id\":\"67419e55a437380001df1092\",\"_links\":{
  09:20:40.133 [front-end] Posting Customer: {"username":"FHtoSdtKaj","password":"bQoKXScdOx","email":"FHtoSdtKaj@gmail.com","firstName":"FHtoSdtKaj","lastName":"FHtoSdtKaj"}
  09:20:42.085 [front-end] Posting Customer: {"username":"pPdBh","password":"XmphCC","email":"pPdBh@gmail.com","firstName":"pPdBh","lastName":"pPdBh"}
  09:20:44.215 [front-end] Posting Customer: {"username":"TCXdYVbv","password":"EUxUvvk","email":"TCXdYVbv@gmail.com","firstName":"TCXdYVbv","lastName":"TCXdYVbv"}
  09:20:46.717 [catalogue] ts=2024-11-23T09:20:46Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=4.76257m
  09:20:49.359 [front-end] Received response: "{\"firstName\":\"RHwVWmPSFBHpG\",\"lastName\":\"RHwVWmPSFBHpG\",\"username\":\"RHwVWmPSFBHpG\",\"id\":\"67419e5ba437380001df10ac\",\"_links\
  09:20:52.097 [front-end] Posting Customer: {"username":"gypmmRTFaLDQE","password":"WDQJFO","email":"gypmmRTFaLDQE@gmail.com","firstName":"gypmmRTFaLDQE","lastName":"gypmmRTFaLDQE"}
  09:20:55.295 [front-end] Posting Customer: {"username":"heWtObCnBr","password":"FNTwuYVKP","email":"heWtObCnBr@gmail.com","firstName":"heWtObCnBr","lastName":"heWtObCnBr"}

## p0826
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-08T12:13:31.963Z
```
{"timestamp":1733660011963369500,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-4lplk","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:13:31.962  INFO 1 --- [           main] o.s.s.web.DefaultSecurityFilterChain     : Creating filter chain: org.springframework.security.web.util.matcher.AnyRequestMatcher@1, [org.springframework.security.web.context.request.async.WebAsyncManagerIntegrationFilter@11120583, org.springframework.security.web.context.SecurityContextPersistenceFilter@795eddda, org.springframework.security.w…"}
```
Same service, the 2 minutes before (oldest first):
  12:13:27.972 [ts-route-service] 2024-12-08 12:13:27.971 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  12:13:29.571 [ts-route-service] 2024-12-08 12:13:29.571 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/vnd.spring-boot.
  12:13:29.571 [ts-route-service] 2024-12-08 12:13:29.571 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/vnd.spring-bo
  12:13:29.572 [ts-route-service] 2024-12-08 12:13:29.572 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  12:13:29.572 [ts-route-service] 2024-12-08 12:13:29.572 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[application/vnd.sprin
  12:13:29.574 [ts-route-service] 2024-12-08 12:13:29.574 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  12:13:29.574 [ts-route-service] 2024-12-08 12:13:29.574 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  12:13:29.575 [ts-route-service] 2024-12-08 12:13:29.574 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  12:13:29.575 [ts-route-service] 2024-12-08 12:13:29.575 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/vnd.spring-
  12:13:29.575 [ts-route-service] 2024-12-08 12:13:29.575 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  12:13:29.576 [ts-route-service] 2024-12-08 12:13:29.576 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  12:13:29.577 [ts-route-service] 2024-12-08 12:13:29.576 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[application/vnd.sprin
  12:13:29.654 [ts-route-service] 2024-12-08 12:13:29.653 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  12:13:29.654 [ts-route-service] 2024-12-08 12:13:29.654 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics || /metrics.json],methods=[GET],produces=[application/vnd.s
  12:13:29.654 [ts-route-service] 2024-12-08 12:13:29.654 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/auditevents || /auditevents.json],methods=[GET],produces=[applicati
  12:13:29.655 [ts-route-service] 2024-12-08 12:13:29.655 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[application/vnd
  12:13:29.655 [ts-route-service] 2024-12-08 12:13:29.655 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces=[applicati
  12:13:29.655 [ts-route-service] 2024-12-08 12:13:29.655 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
  12:13:30.668 [ts-route-service] 2024-12-08 12:13:30.668 INFO 1 --- [ main] b.a.s.AuthenticationManagerConfiguration : 
  12:13:30.668 [ts-route-service] Using default security password: 783cfd0c-ae99-482e-93bd-2f472e4d8a11 
All services, 30 seconds either side (sampled):
  12:13:02.243 [ts-auth-service] 2024-12-08 12:13:02.242 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×2)
  12:13:02.456 [ts-travel2-service] 2024-12-08 12:13:02.450 ERROR 1 --- [o-16346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  12:13:02.584 [ts-travel-service] 2024-12-08 12:13:02.583 ERROR 1 --- [io-12346-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×13)
  12:13:07.499 [ts-basic-service] 2024-12-08 12:13:07.499 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×2)
  12:13:09.793 [ts-auth-service] 2024-12-08 12:13:09.793 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×21)
  12:13:10.260 [ts-route-service] 2024-12-08 12:13:10.259 INFO 1 --- [ main] o.s.i.config.IntegrationRegistrar : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. The
  12:13:11.866 [ts-travel-service] 2024-12-08 12:13:11.866 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=nanjing)
  12:13:12.865 [ts-route-service] Error occurred during initialization of VM  (×2)
  12:13:14.226 [ts-assurance-mongo] {"t":{"$date":"2024-12-08T12:13:14.226+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365999
  12:13:14.760 [ts-route-service] 2024-12-08 12:13:14.759 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  12:13:18.362 [ts-route-service] 2024-12-08 12:13:18.362 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43
  12:13:23.262 [ts-route-service] 2024-12-08 12:13:23.261 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-route-mongo:27017 to client view of cluster
  12:13:27.966 [ts-route-service] 2024-12-08 12:13:27.966 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{routeId}],methods=[GET]}" onto publ
  12:13:29.571 [ts-route-service] 2024-12-08 12:13:29.571 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/vnd.spring-boot.
  12:13:29.576 [ts-route-service] 2024-12-08 12:13:29.576 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  12:13:30.668 [ts-route-service] Using default security password: 783cfd0c-ae99-482e-93bd-2f472e4d8a11 
  12:13:36.761 [ts-order-other-service] 2024-12-08 12:13:36.761 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou  (×2)
  12:13:37.459 [ts-route-service] 2024-12-08 12:13:37.459 INFO 1 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  12:13:38.762 [ts-route-service] 2024-12-08 12:13:38.762 INFO 1 --- [ main] .d.s.w.r.o.CachingOperationNameGenerator : Generating unique operation named: findByPrincipalAndAfterAndTypeUsingGET_  (×24)
  12:13:40.769 [ts-route-service] 2024-12-08 12:13:40.769 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: nanjing End: shanghai  (×3)
  12:13:41.264 [ts-consign-service] 2024-12-08 12:13:41.263 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : SAVE consign info : ConsignRecord(id=090598f6-9907-4da9-8831-b03a7d19d
  12:13:52.466 [ts-route-service] 2024-12-08 12:13:52.465 INFO 1 --- [io-11178-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  12:13:54.160 [ts-route-service] 2024-12-08 12:13:54.160 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×5)
  12:13:59.068 [ts-basic-service] 2024-12-08 12:13:59.067 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
  12:13:59.137 [ts-basic-service] 2024-12-08 12:13:59.137 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing
  12:13:59.215 [ts-seat-service] 2024-12-08 12:13:59.215 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×4)
  12:13:59.285 [ts-seat-service] 2024-12-08 12:13:59.284 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×4)
  12:14:01.520 [ts-basic-service] 2024-12-08 12:14:01.520 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  12:14:01.794 [ts-travel2-service] 2024-12-08 12:14:01.794 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.

## p0659
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-11T08:00:01.462Z
```
{"service":"webservice1","message":"2021-08-11 08:00:01,462 | ERROR | 0.0.0.1 | webservice1 | web_helper.py -> web_service_resource -> 100 | 8b35939a9c94e677 | get a error [Errno 2] No such file or directory: 'resources/source_file/source_file.csv'"}
```
Same service, the 2 minutes before (oldest first):
  07:59:56.512 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×3)
  07:59:56.513 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
  07:59:58.750 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  07:59:58.751 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  07:59:58.751 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '116d4f9a-fa37-11eb-a857-0242ac110003', 'value': '', 'ex': 10}  (×3)
  07:59:58.809 [webservice1] INFO uuid: 116d4f9a-fa37-11eb-a857-0242ac110003 write redis successfully  (×3)
  07:59:58.914 [webservice1] INFO complete information: {'uuid': '116d4f9a-fa37-11eb-a857-0242ac110003', 'user_id': 'ZKnXGxAN'}  (×2)
All services, 30 seconds either side (sampled):
  07:59:31.536 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×32)
  07:59:31.690 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×34)
  07:59:31.830 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×32)
  07:59:32.009 [dbservice1] INFO 0105049a-fa37-11eb-81a6-0242ac110004-iZWtCSMp-M5*>4^fm-6c) token generate success token=MTYyODYzOTk3Mi4wMDkyNDU0OjAxMDUwNDlhLWZhMzctMTFlYi04MWE2LTAyNDJhYzE
  07:59:32.286 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×48)
  07:59:32.465 [mobservice2] INFO info 018bb2ce-fa37-11eb-877d-0242ac110004:AFDxXgnQ write success
  07:59:32.667 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×35)
  07:59:32.741 [webservice1] INFO uuid: 01e30966-fa37-11eb-ad45-0242ac110003 write redis successfully  (×42)
  07:59:33.295 [mobservice2] INFO info 020ff232-fa37-11eb-834a-0242ac110003:UFfHkLJX write success
  07:59:35.362 [dbservice1] INFO 030aa84e-fa37-11eb-a5fc-0242ac110004-bCKBvESO-X!*=wdxSZ#fO token generate success token=MTYyODYzOTk3NS4zNjI0MDUzOjAzMGFhODRlLWZhMzctMTFlYi1hNWZjLTAyNDJhYzE
  07:59:41.823 [mobservice2] INFO info 0728724e-fa37-11eb-a50e-0242ac110003:IFyHcfZd write success
  07:59:44.483 [mobservice2] INFO info 089c50e6-fa37-11eb-aed8-0242ac110004:rfqKcNpJ write success
  07:59:47.018 [mobservice2] INFO info 0a382fba-fa37-11eb-9c83-0242ac110003:VcbkjSAZ write success  (×2)
  07:59:49.076 [dbservice2] INFO 0b421a88-fa37-11eb-91c8-0242ac110003-QClFzynH-qP%6L:4dAwRi token generate success token=MTYyODYzOTk4OS4wNzU1ODk6MGI0MjFhODgtZmEzNy0xMWViLTkxYzgtMDI0MmFjMTE
  07:59:51.416 [mobservice1] INFO info 0cd77848-fa37-11eb-aeec-0242ac110004:PtpxFCHR write success
  07:59:53.210 [dbservice2] INFO 0dbb3a7e-fa37-11eb-9424-0242ac110003-EfYjQxDP-^#<7YEpfJHm/ token generate success token=MTYyODYzOTk5My4yMTAxNTg4OjBkYmIzYTdlLWZhMzctMTFlYi05NDI0LTAyNDJhYzE
  07:59:55.432 [dbservice2] INFO 0f10ee50-fa37-11eb-91c3-0242ac110004-uGrcWJOt-Qj5b<4P!%R=0 token generate success token=MTYyODYzOTk5NS40MzE0MjQ5OjBmMTBlZTUwLWZhMzctMTFlYi05MWMzLTAyNDJhYzE
  07:59:57.488 [mobservice1] INFO info 106af3ae-fa37-11eb-a100-0242ac110004:dlSUhBPw write success
  07:59:59.523 [dbservice1] INFO 116d4f9a-fa37-11eb-a857-0242ac110003-ZKnXGxAN-Z@S_<_>310Yl token generate success token=MTYyODYzOTk5OS41MjMwNDY1OjExNmQ0ZjlhLWZhMzctMTFlYi1hODU3LTAyNDJhYzE
  08:00:01.826 [dbservice2] INFO 12bd3a4a-fa37-11eb-9f3c-0242ac110004-rDnqUwke-DU5r6PxM-/u1 token generate success token=MTYyODY0MDAwMS44MjYyNzQ0OjEyYmQzYTRhLWZhMzctMTFlYi05ZjNjLTAyNDJhYzE  (×4)
  08:00:04.325 [mobservice1] INFO info 1483206a-fa37-11eb-9d7b-0242ac110004:NdFpoUqE write success
  08:00:07.547 [dbservice1] INFO 162bfdc4-fa37-11eb-af4c-0242ac110004-GYQsHOyA-RB?=8F>L}UWG token generate success token=MTYyODY0MDAwNy41NDcyNjI6MTYyYmZkYzQtZmEzNy0xMWViLWFmNGMtMDI0MmFjMTE
  08:00:10.462 [dbservice1] INFO 17ed18aa-fa37-11eb-80a3-0242ac110004-WHeAwPqY-:4l35ScB>fT1 token generate success token=MTYyODY0MDAxMC40NjIyMzI0OjE3ZWQxOGFhLWZhMzctMTFlYi04MGEzLTAyNDJhYzE
  08:00:14.373 [dbservice1] INFO 1a49e0b0-fa37-11eb-80bf-0242ac110004-iAefFjPB-pr!%)P}hszWy token generate success token=MTYyODY0MDAxNC4zNzI4MzY6MWE0OWUwYjAtZmEzNy0xMWViLTgwYmYtMDI0MmFjMTE
  08:00:18.117 [mobservice2] INFO info 1cc050ae-fa37-11eb-820f-0242ac110004:XlGeVCEy write success
  08:00:24.032 [mobservice1] INFO info 2045440a-fa37-11eb-9959-0242ac110004:ORjBsXZy write success

## p0015
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T06:27:28.834Z
```
{"service":"logservice1","message":"2021-08-13 06:27:28,834 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | cb51177e9877ec06 | request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '79f2a2a0-fbbc-11eb-9433-0242ac110004'}"}
```
Same service, the 2 minutes before (oldest first):
  06:27:19.127 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×4)
  06:27:19.127 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×4)
  06:27:19.128 [logservice1] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': '741a7b78-fbbc-11eb-b626-0242ac110004', 'user_id': 'UlXetfSn'}  (×5)
  06:27:27.942 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  06:27:27.942 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  06:27:27.942 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '796e50c2-fbbc-11eb-aed0-0242ac110003'}
  06:27:27.989 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385
  06:27:27.989 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service
All services, 30 seconds either side (sampled):
  06:26:58.871 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×43)
  06:26:59.078 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×37)
  06:26:59.221 [redisservice1] INFO service accept, status_code: 200  (×43)
  06:26:59.522 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  06:26:59.683 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×42)
  06:26:59.931 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '68b6db6e-fbbc-11eb-95dd-0242ac110004'}  (×43)
  06:27:00.245 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  06:27:01.710 [redisservice2] INFO redis读取信息成功, status_code: 200  (×31)
  06:27:02.930 [dbservice1] INFO 6a4e3abc-fbbc-11eb-b4ed-0242ac110003-rNfgkPxE-ZI78qlV2ts)U token generate success token=MTYyODgwNzIyMi45MzA1MzI3OjZhNGUzYWJjLWZiYmMtMTFlYi1iNGVkLTAyNDJhYzE
  06:27:05.580 [mobservice1] INFO info 6c347c74-fbbc-11eb-b169-0242ac110003:FHDROgPs write success
  06:27:08.003 [dbservice2] INFO 6d65d732-fbbc-11eb-b192-0242ac110003-AIKNYSvf-Ju*+9{fYn>Ti token generate success token=MTYyODgwNzIyOC4wMDMxNDk3OjZkNjVkNzMyLWZiYmMtMTFlYi1iMTkyLTAyNDJhYzE
  06:27:10.784 [dbservice2] INFO 6f0003a6-fbbc-11eb-acba-0242ac110003-dXbvhYuV-XtK?-g9HF@^i token generate success token=MTYyODgwNzIzMC43ODM4OTI2OjZmMDAwM2E2LWZiYmMtMTFlYi1hY2JhLTAyNDJhYzE
  06:27:13.341 [dbservice1] INFO 7095d4a2-fbbc-11eb-a8c6-0242ac110004-GEFNbRmp-9e0!Zzhbd3WR token generate success token=MTYyODgwNzIzMy4zNDA5MjY2OjcwOTVkNGEyLWZiYmMtMTFlYi1hOGM2LTAyNDJhYzE
  06:27:15.883 [dbservice2] INFO 7219c9dc-fbbc-11eb-b961-0242ac110004-EQWxHTiy-(_nq1GO.M5R6 token generate success token=MTYyODgwNzIzNS44ODI4NjExOjcyMTljOWRjLWZiYmMtMTFlYi1iOTYxLTAyNDJhYzE
  06:27:18.930 [mobservice2] INFO info 741a7b78-fbbc-11eb-b626-0242ac110004:UlXetfSn write success
  06:27:28.250 [dbservice1] INFO 796e50c2-fbbc-11eb-aed0-0242ac110003-SBgdrmlT-HkpM0UVa+&9- token generate success token=MTYyODgwNzI0OC4yNTA0ODM4Ojc5NmU1MGMyLWZiYmMtMTFlYi1hZWQwLTAyNDJhYzE
  06:27:30.749 [dbservice2] INFO 7af1a99e-fbbc-11eb-af92-0242ac110004-LmPAoyvh-Ay^K:tkP%L+m token generate success token=MTYyODgwNzI1MC43NDg4MzQ4OjdhZjFhOTllLWZiYmMtMTFlYi1hZjkyLTAyNDJhYzE
  06:27:33.547 [dbservice1] INFO 7c8de100-fbbc-11eb-a80d-0242ac110003-YqjgnfMZ-{EM?P_3q2!OW token generate success token=MTYyODgwNzI1My41NDY3MzMxOjdjOGRlMTAwLWZiYmMtMTFlYi1hODBkLTAyNDJhYzE
  06:27:36.621 [dbservice2] INFO 7e5132d0-fbbc-11eb-ad27-0242ac110004-fiPpWOMj-C!d)Sy_AULRK token generate success token=MTYyODgwNzI1Ni42MjE0NDg4OjdlNTEzMmQwLWZiYmMtMTFlYi1hZDI3LTAyNDJhYzE
  06:27:39.102 [dbservice1] INFO 7ff0e3e2-fbbc-11eb-82ce-0242ac110004-KvpoNGOC-2{r-4./W3G&K token generate success token=MTYyODgwNzI1OS4xMDIxNTc0OjdmZjBlM2UyLWZiYmMtMTFlYi04MmNlLTAyNDJhYzE
  06:27:41.827 [dbservice1] INFO 817f2462-fbbc-11eb-ac29-0242ac110003-SxlGNrtW-:6aQSXm@sWb3 token generate success token=MTYyODgwNzI2MS44MjY3MTk6ODE3ZjI0NjItZmJiYy0xMWViLWFjMjktMDI0MmFjMTE
  06:27:44.608 [dbservice1] INFO 8329c3ee-fbbc-11eb-812c-0242ac110003-YTchXgsi-MpkWe@KL3OmU token generate success token=MTYyODgwNzI2NC42MDgyMjA2OjgzMjljM2VlLWZiYmMtMTFlYi04MTJjLTAyNDJhYzE
  06:27:46.930 [dbservice2] INFO 84a0e7ac-fbbc-11eb-b0ac-0242ac110003-ZYabGCTS-(lz3Gc}.PBe/ token generate success token=MTYyODgwNzI2Ni45MzAyMzgyOjg0YTBlN2FjLWZiYmMtMTFlYi1iMGFjLTAyNDJhYzE
  06:27:49.643 [dbservice1] INFO 861cc70e-fbbc-11eb-b9cb-0242ac110003-cvlIGRjC-l5}dC_?m/GUr token generate success token=MTYyODgwNzI2OS42NDMwNDkyOjg2MWNjNzBlLWZiYmMtMTFlYi1iOWNiLTAyNDJhYzE
  06:27:52.054 [dbservice2] INFO 87a893dc-fbbc-11eb-b88e-0242ac110004-PFOBQRXk-VziMJs=8j.(! token generate success token=MTYyODgwNzI3Mi4wNTM5NDQ2Ojg3YTg5M2RjLWZiYmMtMTFlYi1iODhlLTAyNDJhYzE
  06:27:54.984 [dbservice2] INFO 8950d28a-fbbc-11eb-b34c-0242ac110004-UeHdKlGN-ZHxuf4*oXj?< token generate success token=MTYyODgwNzI3NC45ODM1NDMyOjg5NTBkMjhhLWZiYmMtMTFlYi1iMzRjLTAyNDJhYzE
  06:27:57.725 [mobservice2] INFO info 8b3fdec4-fbbc-11eb-a7db-0242ac110003:efoEbcGO write success

## p0593
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-07T20:01:49.292Z
```
{"timestamp":1733601709292787500,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-kh5wd","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 20:01:49.292  INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl  : [Basic Information Service][Check Station Exists] Station Name: Nan Jing"}
```
Same service, the 2 minutes before (oldest first):
  20:01:46.391 [ts-basic-service] 2024-12-07 20:01:46.391 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  20:01:46.398 [ts-basic-service] 2024-12-07 20:01:46.397 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa
  20:01:46.478 [ts-basic-service] 2024-12-07 20:01:46.477 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87
  20:01:46.489 [ts-basic-service] 2024-12-07 20:01:46.489 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  20:01:46.490 [ts-basic-service] 2024-12-07 20:01:46.490 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23
  20:01:46.503 [ts-basic-service] 2024-12-07 20:01:46.503 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  20:01:46.503 [ts-basic-service] 2024-12-07 20:01:46.503 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×4)
  20:01:46.512 [ts-basic-service] 2024-12-07 20:01:46.512 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×5)
  20:01:46.520 [ts-basic-service] 2024-12-07 20:01:46.519 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing
  20:01:46.520 [ts-basic-service] 2024-12-07 20:01:46.519 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1
  20:01:46.520 [ts-basic-service] 2024-12-07 20:01:46.519 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4
  20:01:46.721 [ts-basic-service] 2024-12-07 20:01:46.721 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha
  20:01:49.283 [ts-basic-service] 2024-12-07 20:01:49.283 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
All services, 30 seconds either side (sampled):
  20:01:34.509 [ts-admin-basic-info-service] 2024-12-07 20:01:34.508 INFO 1 --- [io-18767-exec-4] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×8)
  20:01:36.372 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:01:36 +0800] "POST /api/v1/users/login HTTP/1.1" 200 380 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×17)
  20:01:36.479 [ts-basic-service] 2024-12-07 20:01:36.478 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×11)
  20:01:36.528 [ts-price-service] 2024-12-07 20:01:36.527 INFO 1 --- [io-16579-exec-2] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×14)
  20:01:36.563 [ts-order-other-service] 2024-12-07 20:01:36.563 INFO 1 --- [io-12032-exec-4] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×9)
  20:01:36.670 [ts-travel2-service] 2024-12-07 20:01:36.670 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×17)
  20:01:36.718 [ts-travel2-service] 2024-12-07 20:01:36.718 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×14)
  20:01:37.116 [ts-route-service] 2024-12-07 20:01:37.116 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×18)
  20:01:37.328 [ts-travel2-service] 2024-12-07 20:01:37.328 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×4)
  20:01:42.734 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T20:01:42.734+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360170
  20:01:43.300 [ts-admin-travel-service] 2024-12-07 20:01:43.300 INFO 1 --- [io-16114-exec-4] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×7)
  20:01:43.399 [ts-travel-service] 2024-12-07 20:01:43.399 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×2)
  20:01:44.481 [ts-auth-service] 2024-12-07 20:01:44.481 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX
  20:01:44.596 [ts-travel-service] 2024-12-07 20:01:44.596 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×10)
  20:01:49.854 [ts-seat-service] 2024-12-07 20:01:49.854 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
  20:01:55.409 [ts-order-other-service] 2024-12-07 20:01:55.409 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou
  20:01:55.969 [ts-consign-service] 2024-12-07 20:01:55.969 INFO 1 --- [io-16111-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  20:01:57.579 [ts-consign-service] 2024-12-07 20:01:57.578 INFO 1 --- [io-16111-exec-4] org.mongodb.driver.connection : Opened connection [connectionId{localValue:2, serverValue:12}] to ts-consig
  20:01:58.488 [ts-consign-price-service] 2024-12-07 20:01:58.487 INFO 1 --- [io-16110-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization completed in 109 m
  20:02:04.737 [ts-food-service] 2024-12-07 20:02:04.737 INFO 1 --- [io-18856-exec-8] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:02:07.763 [ts-travel-service] 2024-12-07 20:02:07.762 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×14)
  20:02:07.953 [ts-travel-service] 2024-12-07 20:02:07.952 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×6)
  20:02:08.035 [ts-seat-service] 2024-12-07 20:02:08.034 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×10)
  20:02:08.417 [ts-basic-service] 2024-12-07 20:02:08.416 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: aefc
  20:02:10.072 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:02:10 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 924 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×2)
  20:02:12.912 [ts-basic-service] 2024-12-07 20:02:12.911 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2
  20:02:13.401 [ts-basic-service] 2024-12-07 20:02:13.401 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieT

## p0036
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T07:53:53.504Z
```
{"service":"logservice1","message":"2021-08-13 07:53:53,504 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | 7f03f6a4096ce7c7 | request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '8c50ecca-fbc8-11eb-a654-0242ac110004'}"}
```
Same service, the 2 minutes before (oldest first):
  07:53:51.190 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×3)
  07:53:51.191 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  07:53:51.191 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '8ae3a3fa-fbc8-11eb-b3d7-0242ac110004', 'user_id': 'EQWxHTiy'}  (×4)
  07:53:52.052 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389
  07:53:52.052 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service
  07:53:52.746 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  07:53:52.746 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  07:53:52.747 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '8bd75144-fbc8-11eb-97d5-0242ac110004'}  (×2)
All services, 30 seconds either side (sampled):
  07:53:23.510 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  07:53:23.602 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×35)
  07:53:23.867 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×39)
  07:53:24.101 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×33)
  07:53:24.241 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '7ae239e4-fbc8-11eb-8fec-0242ac110004'}  (×46)
  07:53:25.322 [dbservice2] INFO 7b562a02-fbc8-11eb-a023-0242ac110004-gtLKWOSc-hjD2_FZ_9Qmn token generate success token=MTYyODgxMjQwNS4zMjIyMjA4OjdiNTYyYTAyLWZiYzgtMTFlYi1hMDIzLTAyNDJhYzE  (×2)
  07:53:25.491 [mobservice2] INFO info 7ba3cc08-fbc8-11eb-a1e6-0242ac110004:sEtBNqcf write success
  07:53:25.780 [mobservice2] INFO info 7bd27d32-fbc8-11eb-94d7-0242ac110003:rnAReBSk write success
  07:53:27.916 [dbservice2] INFO 7ce5271a-fbc8-11eb-8191-0242ac110003-aLCdNFuD->*a5MwtuL=pF token generate success token=MTYyODgxMjQwNy45MTYyNDE6N2NlNTI3MWEtZmJjOC0xMWViLTgxOTEtMDI0MmFjMTE
  07:53:31.299 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×3)
  07:53:34.328 [mobservice1] INFO info 80e0cb26-fbc8-11eb-9e6e-0242ac110004:tdfCvYKb write success
  07:53:39.332 [mobservice2] ERROR uuid:7d56e5d0-fbc8-11eb-9453-0242ac110004 information has expired, mobile phone login is invalid
  07:53:44.486 [mobservice2] INFO info 86f9e894-fbc8-11eb-833e-0242ac110004:yHBRGerA write success
  07:53:47.016 [mobservice1] INFO info 8874290a-fbc8-11eb-b737-0242ac110003:oYbSglqf write success
  07:53:49.416 [mobservice2] INFO info 89e9a3c8-fbc8-11eb-b3b7-0242ac110004:dtzesiga write success
  07:53:51.823 [mobservice2] INFO info 8b56f7c4-fbc8-11eb-adea-0242ac110004:fErgCUsY write success
  07:53:53.794 [dbservice1] INFO 8c50ecca-fbc8-11eb-a654-0242ac110004-SYUdXTMn-#?+cKu8b!U&_ token generate success token=MTYyODgxMjQzMy43OTM3MTU1OjhjNTBlY2NhLWZiYzgtMTFlYi1hNjU0LTAyNDJhYzE
  07:53:56.484 [dbservice1] INFO 8de1e576-fbc8-11eb-84a4-0242ac110003-qwpdAUNi-j-s(4p$@1:Fo token generate success token=MTYyODgxMjQzNi40ODM2NDI4OjhkZTFlNTc2LWZiYzgtMTFlYi04NGE0LTAyNDJhYzE
  07:53:59.684 [mobservice2] INFO info 8ff87bcc-fbc8-11eb-abb2-0242ac110004:lkNrGYTL write success
  07:54:02.161 [dbservice1] INFO 914fd43e-fbc8-11eb-9b7b-0242ac110003-QUpJkdTY-+#.eHu$I(oU- token generate success token=MTYyODgxMjQ0Mi4xNjEyMjYzOjkxNGZkNDNlLWZiYzgtMTFlYi05YjdiLTAyNDJhYzE
  07:54:05.326 [mobservice2] INFO info 9362fea4-fbc8-11eb-b750-0242ac110004:IcmKxDtR write success
  07:54:08.143 [dbservice2] ERROR password in database of {user} is null, the user is not registered  (×2)
  07:54:11.142 [mobservice1] INFO info 96dae7ea-fbc8-11eb-aef0-0242ac110004:jHRvwBZi write success
  07:54:14.020 [dbservice2] INFO 985be178-fbc8-11eb-95d1-0242ac110004-ThPbGWEy-l)3uy8DdN:IG token generate success token=MTYyODgxMjQ1NC4wMTk3MDM5Ojk4NWJlMTc4LWZiYzgtMTFlYi05NWQxLTAyNDJhYzE
  07:54:17.067 [mobservice2] INFO info 9a6775ea-fbc8-11eb-a02b-0242ac110003:gSjZMlmO write success
  07:54:19.500 [mobservice2] INFO info 9bda77ec-fbc8-11eb-95db-0242ac110003:plhmCNjI write success
  07:54:22.220 [dbservice1] ERROR password in database of {user} is null, the user is not registered

## p0777
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-24T13:29:47.344Z
```
{"timestamp":1732454987344773600,"container_name":"front-end","pod_name":"front-end-f77549869-qkdxd","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /cards 200 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  13:29:46.474 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67432a40f6d875000161fbf8\",\"_links\":{\"
  13:29:46.474 [front-end] [ undefined, undefined ]
  13:29:46.474 [front-end] Posting Order: {"customer":"http://user/customers/67432a39f6d875000161fbea","address":"http://user/addresses/67432a40f6d875000161fbf6","card":"http://user/cards
  13:29:46.506 [front-end] Order response: {"statusCode":201,"body":{"id":"67432a4ac4380300078a470d","customerId":"67432a39f6d875000161fbea","customer":{"id":null,"firstName":"eKrlqyu","l
  13:29:46.506 [front-end] Order response: {"id":"67432a4ac4380300078a470d","customerId":"67432a39f6d875000161fbea","customer":{"id":null,"firstName":"eKrlqyu","lastName":"eKrlqyu","usern
  13:29:46.507 [front-end] POST /orders 201 - ms - -
  13:29:47.049 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67432a42f6d875000161fc05"}  (×2)
  13:29:47.057 [front-end] POST /addresses 200 - ms - -  (×2)
  13:29:47.062 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67432a42f6d875000161fc05"}  (×2)
  13:29:47.072 [front-end] POST /cards 200 - ms - -
  13:29:47.121 [front-end] Attempting to delete cart for user: 67432a42f6d875000161fc05
  13:29:47.141 [front-end] User cart deleted with status: 202
  13:29:47.142 [front-end] DELETE /cart 202 - ms - -
  13:29:47.150 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}
  13:29:47.158 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
  13:29:47.158 [front-end] POST to carts: http://carts/carts/67432a42f6d875000161fc05/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}
  13:29:47.198 [front-end] POST /cart 201 - ms - -
All services, 30 seconds either side (sampled):
  13:29:17.547 [front-end] Request received with body: {}  (×63)
  13:29:17.586 [orders] 2024-11-24 13:29:17.586 INFO [orders,af4b337afe1b8b98,574f044fdc7c84bd,false] 7 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Received payment re  (×47)
  13:29:17.820 [front-end] POST /addresses 200 - ms - -  (×61)
  13:29:17.960 [front-end] POST to carts: http://carts/carts/67432a27f6d875000161fbb1/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×35)
  13:29:18.112 [front-end] Sent cookies.  (×57)
  13:29:18.524 [carts] 2024-11-24 13:29:18.524 INFO [carts,1bea92cd08d57527,c96ef86cbe860386,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.ItemsController : Did not find item.  (×25)
  13:29:19.666 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×12)
  13:29:20.829 [front-end] Order response: {"statusCode":201,"body":{"id":"67432a30c4380300078a46f5","customerId":"67432a1bf6d875000161fb8f","customer":{"id":null,"firstName":"ANHdUJbBcSw
  13:29:23.925 [front-end] Order response: {"statusCode":201,"body":{"id":"67432a33c4380300078a46f6","customerId":"67432a1cf6d875000161fb91","customer":{"id":null,"firstName":"egEpPbRgbTY
  13:29:24.921 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×6)
  13:29:28.806 [payment] ts=2024-11-24T13:29:28Z caller=logging.go:29 method=Authorise result=true took=1.104µs  (×5)
  13:29:30.607 [front-end] Order response: {"id":"67432a3ac4380300078a46fd","customerId":"67432a29f6d875000161fbb3","customer":{"id":null,"firstName":"egHxCaW","lastName":"egHxCaW","usern
  13:29:33.054 [front-end] Posting Customer: {"username":"MecsXPjzWiylAd","password":"JGVHcB","email":"MecsXPjzWiylAd@gmail.com","firstName":"MecsXPjzWiylAd","lastName":"MecsXPjzWiylAd"}
  13:29:35.664 [front-end] Received response: "{\"firstName\":\"NjOEz\",\"lastName\":\"NjOEz\",\"username\":\"NjOEz\",\"id\":\"67432a28f6d875000161fbb2\",\"_links\":{\"addresses\":{\"href
  13:29:38.326 [front-end] Received response: "{\"firstName\":\"bJXpBg\",\"lastName\":\"bJXpBg\",\"username\":\"bJXpBg\",\"id\":\"67432a33f6d875000161fbd5\",\"_links\":{\"addresses\":{\"h
  13:29:40.947 [front-end] Received response: "{\"firstName\":\"XSvCQmZE\",\"lastName\":\"XSvCQmZE\",\"username\":\"XSvCQmZE\",\"id\":\"67432a2af6d875000161fbb8\",\"_links\":{\"addresses\
  13:29:44.490 [front-end] Posting Customer: {"username":"BrlsOHZXUUzwazq","password":"oBdGZxT","email":"BrlsOHZXUUzwazq@gmail.com","firstName":"BrlsOHZXUUzwazq","lastName":"BrlsOHZXUUzwa
  13:29:46.335 [front-end] Order response: {"statusCode":201,"body":{"id":"67432a4ac4380300078a470c","customerId":"67432a38f6d875000161fbe5","customer":{"id":null,"firstName":"dKfgDQVqIPf
  13:29:48.411 [front-end] Order response: {"statusCode":201,"body":{"id":"67432a4cc4380300078a470f","customerId":"67432a3af6d875000161fbeb","customer":{"id":null,"firstName":"UfhscCZPuGA
  13:29:51.260 [front-end] Received response: "{\"firstName\":\"mhfWoaTNSlYosYP\",\"lastName\":\"mhfWoaTNSlYosYP\",\"username\":\"mhfWoaTNSlYosYP\",\"id\":\"67432a40f6d875000161fbf3\",\"_
  13:29:53.477 [front-end] Order response: {"id":"67432a51c4380300078a4711","customerId":"67432a40f6d875000161fbf4","customer":{"id":null,"firstName":"oqTrGjlkq","lastName":"oqTrGjlkq","u
  13:29:55.564 [front-end] Order response: {"id":"67432a53c4380300078a4714","customerId":"67432a3df6d875000161fbf1","customer":{"id":null,"firstName":"kHKfZIXgcgQnMKw","lastName":"kHKfZIX
  13:29:59.394 [front-end] Posting Customer: {"username":"WwHwqTIWaKXzc","password":"VwoeRQ","email":"WwHwqTIWaKXzc@gmail.com","firstName":"WwHwqTIWaKXzc","lastName":"WwHwqTIWaKXzc"}
  13:30:04.737 [front-end] Order response: {"statusCode":201,"body":{"id":"67432a5cc4380300078a4719","customerId":"67432a48f6d875000161fc13","customer":{"id":null,"firstName":"BrlsOHZXUUz
  13:30:06.885 [front-end] Posting Customer: {"username":"UjtVXmmbwOk","password":"gWvlSu","email":"UjtVXmmbwOk@gmail.com","firstName":"UjtVXmmbwOk","lastName":"UjtVXmmbwOk"}
  13:30:09.203 [front-end] Order response: {"statusCode":201,"body":{"id":"67432a61c4380300078a471f","customerId":"67432a49f6d875000161fc17","customer":{"id":null,"firstName":"VFqKmhHSw",
  13:30:10.328 [front-end] Order response: {"statusCode":201,"body":{"id":"67432a62c4380300078a4723","customerId":"67432a50f6d875000161fc2d","customer":{"id":null,"firstName":"vywaxozy","
  13:30:14.558 [user] ts=2024-11-24T13:30:14.558343901Z caller=middlewares.go:46 method=Register username=fvPKpPth email=fvPKpPth@gmail.com took=1.902582ms
  13:30:16.026 [front-end] Posting Customer: {"username":"sTQZRRRfPnKGbWx","password":"JeaZUyKa","email":"sTQZRRRfPnKGbWx@gmail.com","firstName":"sTQZRRRfPnKGbWx","lastName":"sTQZRRRfPnKG

## p0470
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T08:13:02.728Z
```
{"timestamp":1732349582728908500,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T08:13:02.728630455Z caller=middlewares.go:75 method=GetUsers id=67418e75a437380001def120 result=1 took=1.979106ms"}
```
Same service, the 2 minutes before (oldest first):
  08:13:01.388 [user] ts=2024-11-23T08:13:01.388760509Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418e88a437380001def165 took=4.647392ms  (×3)
  08:13:01.406 [user] ts=2024-11-23T08:13:01.40592974Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67418e88a437380001def165 took=4.06913ms  (×3)
  08:13:01.848 [user] ts=2024-11-23T08:13:01.848761945Z caller=middlewares.go:157 method=Health result=2 took=2.231741ms  (×2)
  08:13:02.105 [user] ts=2024-11-23T08:13:02.105415194Z caller=middlewares.go:75 method=GetUsers id=67418e79a437380001def129 result=1 took=2.114461ms  (×8)
  08:13:02.130 [user] ts=2024-11-23T08:13:02.129903654Z caller=middlewares.go:134 method=GetCards id=67418e7ea437380001def142 result=1 took=2.389954ms  (×2)
  08:13:02.130 [user] ts=2024-11-23T08:13:02.129917589Z caller=middlewares.go:104 method=GetAddresses id=67418e7ea437380001def141 result=1 took=2.335761ms  (×2)
All services, 30 seconds either side (sampled):
  08:12:32.935 [catalogue] ts=2024-11-23T08:12:32Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.502142ms  (×64)
  08:12:33.087 [front-end] POST /register 200 24.414 ms - 33  (×64)
  08:12:33.509 [front-end] User cart deleted with status: 202  (×59)
  08:12:34.137 [user] ts=2024-11-23T08:12:34.136878428Z caller=middlewares.go:75 method=GetUsers id=67418e5aa437380001def0d5 result=1 took=2.25755ms  (×227)
  08:12:34.169 [orders] 2024-11-23 08:12:34.169 INFO [orders,73526afd9f423f47,15bd49407336304f,false] 8 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Received payment re  (×51)
  08:12:34.307 [front-end] Order response: {"statusCode":201,"body":{"id":"67418e723f77060008864f86","customerId":"67418e59a437380001def0cb","customer":{"id":null,"firstName":"ZzSpGlUJId"
  08:12:35.570 [front-end] Received response: "{\"firstName\":\"FvaTZ\",\"lastName\":\"FvaTZ\",\"username\":\"FvaTZ\",\"id\":\"67418e5da437380001def0e0\",\"_links\":{\"addresses\":{\"href
  08:12:38.510 [front-end] Received response: "{\"firstName\":\"XYmmodxtKDAXu\",\"lastName\":\"XYmmodxtKDAXu\",\"username\":\"XYmmodxtKDAXu\",\"id\":\"67418e59a437380001def0cc\",\"_links\
  08:12:40.301 [user] ts=2024-11-23T08:12:40.300577299Z caller=middlewares.go:46 method=Register username=fPLAVX email=fPLAVX@gmail.com took=2.506112ms
  08:12:41.217 [front-end] Order response: {"statusCode":201,"body":{"id":"67418e793f77060008864f8b","customerId":"67418e62a437380001def0f4","customer":{"id":null,"firstName":"iPAScbOlgcB
  08:12:43.709 [front-end] Order response: {"id":"67418e7b3f77060008864f8c","customerId":"67418e6ca437380001def10a","customer":{"id":null,"firstName":"wiQKFhUFjhyG","lastName":"wiQKFhUFjh
  08:12:45.415 [front-end] Order response: {"id":"67418e7d3f77060008864f8f","customerId":"67418e60a437380001def0e9","customer":{"id":null,"firstName":"mxoWW","lastName":"mxoWW","username"
  08:12:48.367 [front-end] Posting Customer: {"username":"NhFru","password":"azFHdaNzB","email":"NhFru@gmail.com","firstName":"NhFru","lastName":"NhFru"}
  08:12:51.235 [front-end] Posting Customer: {"username":"KHfKzcdRgeZYbrk","password":"IzMuiRjW","email":"KHfKzcdRgeZYbrk@gmail.com","firstName":"KHfKzcdRgeZYbrk","lastName":"KHfKzcdRgeZY
  08:12:53.993 [user] ts=2024-11-23T08:12:53.993108224Z caller=middlewares.go:46 method=Register username=IisOAo email=IisOAo@gmail.com took=2.441327ms
  08:12:56.896 [user] ts=2024-11-23T08:12:56.896511736Z caller=middlewares.go:46 method=Register username=wanUWFGCf email=wanUWFGCf@gmail.com took=2.190999ms
  08:12:59.956 [front-end] Order response: {"id":"67418e8b3f77060008864f96","customerId":"67418e78a437380001def126","customer":{"id":null,"firstName":"ikDCBiEyA","lastName":"ikDCBiEyA","u
  08:13:02.735 [front-end] Received response: "{\"firstName\":\"rMGxCvPen\",\"lastName\":\"rMGxCvPen\",\"username\":\"rMGxCvPen\",\"id\":\"67418e75a437380001def120\",\"_links\":{\"address
  08:13:03.043 [front-end] Received response: "{\"firstName\":\"mCyRuJkdqQIEYAX\",\"lastName\":\"mCyRuJkdqQIEYAX\",\"username\":\"mCyRuJkdqQIEYAX\",\"id\":\"67418e77a437380001def122\",\"_
  08:13:04.261 [front-end] Order response: {"id":"67418e903f77060008864f9d","customerId":"67418e79a437380001def127","customer":{"id":null,"firstName":"VEvIJ","lastName":"VEvIJ","username"
  08:13:08.182 [front-end] Order response: {"id":"67418e943f77060008864fa0","customerId":"67418e7da437380001def13c","customer":{"id":null,"firstName":"wSDbBKrzR","lastName":"wSDbBKrzR","u
  08:13:09.046 [front-end] Order response: {"statusCode":201,"body":{"id":"67418e953f77060008864fa4","customerId":"67418e81a437380001def147","customer":{"id":null,"firstName":"udNjazilLJo
  08:13:12.514 [front-end] Posting Customer: {"username":"HDiNt","password":"cCKjDj","email":"HDiNt@gmail.com","firstName":"HDiNt","lastName":"HDiNt"}
  08:13:15.108 [front-end] Order response: {"statusCode":201,"body":{"id":"67418e9b3f77060008864fa9","customerId":"67418e81a437380001def148","customer":{"id":null,"firstName":"IKppyTYkPpi
  08:13:18.144 [user] ts=2024-11-23T08:13:18.144274573Z caller=middlewares.go:46 method=Register username=krHxnU email=krHxnU@gmail.com took=2.112091ms
  08:13:19.561 [front-end] Received response: "{\"firstName\":\"QULMUkvXYM\",\"lastName\":\"QULMUkvXYM\",\"username\":\"QULMUkvXYM\",\"id\":\"67418e8ca437380001def170\",\"_links\":{\"addr
  08:13:20.878 [user] ts=2024-11-23T08:13:20.878351378Z caller=middlewares.go:46 method=Register username=AiGsCQ email=AiGsCQ@gmail.com took=2.170137ms
  08:13:24.742 [front-end] Received response: "{\"firstName\":\"KlmrCNBrxwX\",\"lastName\":\"KlmrCNBrxwX\",\"username\":\"KlmrCNBrxwX\",\"id\":\"67418e95a437380001def18a\",\"_links\":{\"a
  08:13:28.818 [front-end] Posting Customer: {"username":"WPTYuWhKMFCyPmK","password":"mLseLfdPwF","email":"WPTYuWhKMFCyPmK@gmail.com","firstName":"WPTYuWhKMFCyPmK","lastName":"WPTYuWhKMF
  08:13:31.386 [front-end] Order response: {"statusCode":201,"body":{"id":"67418eab3f77060008864fb5","customerId":"67418e95a437380001def18b","customer":{"id":null,"firstName":"YcNPcauOJ",

## p0306
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:20:17.846Z
```
{"timestamp":1732245617846531000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Card: {\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"userID\":\"673ff86bb0df5c00019b1ec4\"}"}
```
Same service, the 2 minutes before (oldest first):
  03:20:17.238 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
  03:20:17.238 [front-end] POST to carts: http://carts/carts/673ff86ab0df5c00019b1ec0/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}
  03:20:17.242 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:20:17.242 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff861b0df5c00019b1e9d\",\"_links\":{\"
  03:20:17.242 [front-end] [ undefined, undefined ]
  03:20:17.242 [front-end] Posting Order: {"customer":"http://user/customers/673ff859b0df5c00019b1e8a","address":"http://user/addresses/673ff860b0df5c00019b1e9c","card":"http://user/cards
  03:20:17.277 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245617275,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:20:17.277 [front-end] Order response: {"timestamp":1732245617275,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:20:17.280 [front-end] POST /orders 500 - ms - -
  03:20:17.318 [front-end] POST /cart 500 86.122 ms - 64
  03:20:17.365 [front-end] Posting Customer: {"username":"JPLuxMxilULRS","password":"WnbUsNRmg","email":"JPLuxMxilULRS@gmail.com","firstName":"JPLuxMxilULRS","lastName":"JPLuxMxilULRS"}
  03:20:17.372 [front-end] { id: '673ff871b0df5c00019b1eda' }
  03:20:17.372 [front-end] 673ff871b0df5c00019b1eda
  03:20:17.372 [front-end] Merging carts for customer id: 673ff871b0df5c00019b1eda and session id: sJ5Vhf4A1CfEEunLMTP74DmBK3I7V4T_
  03:20:17.428 [front-end] Carts merged.
  03:20:17.428 [front-end] set cookie673ff871b0df5c00019b1eda
  03:20:17.428 [front-end] Sent cookies.
  03:20:17.430 [front-end] POST /register 200 62.774 ms - 33
  03:20:17.831 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff86bb0df5c00019b1ec4"}
  03:20:17.841 [front-end] POST /addresses 200 - ms - -
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×27)
  03:20:06.543 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff854b0df5c00019b1e7f\",\"_links\":{\"  (×44)
  03:20:06.586 [orders] 2024-11-22 03:20:06.586 ERROR [orders,,,] 6 --- [p-nio-80-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×26)
  03:20:06.649 [user] ts=2024-11-22T03:20:06.649242768Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff861b0df5c00019b1e9e took=1.734848ms  (×44)
  03:20:06.769 [front-end] User cart deleted with status: 503  (×44)
  03:20:06.803 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×7)
  03:20:07.186 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×9)
  03:20:08.469 [front-end] Posting Customer: {"username":"HNCLfJfsnW","password":"sSvsy","email":"HNCLfJfsnW@gmail.com","firstName":"HNCLfJfsnW","lastName":"HNCLfJfsnW"}
  03:20:08.498 [front-end] Carts merged.  (×35)
  03:20:09.093 [user] ts=2024-11-22T03:20:09.093533288Z caller=middlewares.go:46 method=Register username=CBhyKd email=CBhyKd@gmail.com took=1.350871ms
  03:20:09.192 [carts] 2024-11-22 03:20:09.192 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  03:20:10.049 [front-end] Posting Customer: {"username":"lPEGqahDSutlQTj","password":"AoWWVDzGsz","email":"lPEGqahDSutlQTj@gmail.com","firstName":"lPEGqahDSutlQTj","lastName":"lPEGqahDSu
  03:20:12.002 [front-end] Received response: "{\"firstName\":\"oVuSYHHeDcohK\",\"lastName\":\"oVuSYHHeDcohK\",\"username\":\"oVuSYHHeDcohK\",\"id\":\"673ff855b0df5c00019b1e85\",\"_links\
  03:20:14.429 [front-end] Posting Customer: {"username":"LWbxoNrjdrYfe","password":"dgukoXmQfq","email":"LWbxoNrjdrYfe@gmail.com","firstName":"LWbxoNrjdrYfe","lastName":"LWbxoNrjdrYfe"}
  03:20:16.376 [front-end] Posting Customer: {"username":"zCHyJV","password":"DBVYLG","email":"zCHyJV@gmail.com","firstName":"zCHyJV","lastName":"zCHyJV"}
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:20.340 [front-end] Posting Customer: {"username":"BBYdunXrngQk","password":"jbihHjN","email":"BBYdunXrngQk@gmail.com","firstName":"BBYdunXrngQk","lastName":"BBYdunXrngQk"}
  03:20:23.473 [front-end] Received response: "{\"firstName\":\"AIHRSQU\",\"lastName\":\"AIHRSQU\",\"username\":\"AIHRSQU\",\"id\":\"673ff863b0df5c00019b1ea2\",\"_links\":{\"addresses\":{
  03:20:26.017 [front-end] Posting Customer: {"username":"HLNoIPafm","password":"sBlBYfK","email":"HLNoIPafm@gmail.com","firstName":"HLNoIPafm","lastName":"HLNoIPafm"}
  03:20:28.421 [front-end] Posting Customer: {"username":"MoGml","password":"PJpiau","email":"MoGml@gmail.com","firstName":"MoGml","lastName":"MoGml"}
  03:20:30.252 [front-end] Posting Customer: {"username":"MKGIsEbVYi","password":"VhFAQhsXw","email":"MKGIsEbVYi@gmail.com","firstName":"MKGIsEbVYi","lastName":"MKGIsEbVYi"}
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.186 [front-end] Received response: "{\"firstName\":\"kgzVKACfUvkHp\",\"lastName\":\"kgzVKACfUvkHp\",\"username\":\"kgzVKACfUvkHp\",\"id\":\"673ff869b0df5c00019b1ebd\",\"_links\
  03:20:36.109 [front-end] Posting Customer: {"username":"HWsmCvxoMrNqX","password":"MJvuU","email":"HWsmCvxoMrNqX@gmail.com","firstName":"HWsmCvxoMrNqX","lastName":"HWsmCvxoMrNqX"}
  03:20:38.070 [session-db] 1:M 22 Nov 2024 03:20:38.070 * Background saving started by pid 32
  03:20:39.079 [user] ts=2024-11-22T03:20:39.079141282Z caller=middlewares.go:46 method=Register username=ELXzX email=ELXzX@gmail.com took=1.044635ms
  03:20:42.525 [front-end] Posting Customer: {"username":"jVIVRgJfOAq","password":"zWZXxq","email":"jVIVRgJfOAq@gmail.com","firstName":"jVIVRgJfOAq","lastName":"jVIVRgJfOAq"}
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:20:43.391 [carts] 2024-11-22 03:20:43.391 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:20:47.743 [front-end] Received response: "{\"firstName\":\"MoGml\",\"lastName\":\"MoGml\",\"username\":\"MoGml\",\"id\":\"673ff87cb0df5c00019b1efd\",\"_links\":{\"addresses\":{\"href

## p0256
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:11.657Z
```
{"timestamp":1732242491657423400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"_embedded\\\":{\\\"card\\\":[{\\\"longNum\\\":\\\"123123321\\\",\\\"expires\\\":\\\"1232\\\",\\\"ccv\\\":\\\"123\\\",\\\"id\\\":\\\"673fec31b0df5c00019af95a\\\",\\\"_links\\\":{\\\"card\\\":{\\\"href\\\":\\\"http://user/cards/673fec31b0df5c00019af95a\\\"},\\\"self\\\":{\\\"href\\\":\\\"http://user/cards/673fec31b0df5c00019af95a\\\"}}}]}}\\n\""}
```
Same service, the 2 minutes before (oldest first):
  02:28:11.347 [front-end] DELETE /cart 503 - ms - -  (×2)
  02:28:11.355 [front-end] Attempting to add to cart: {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","quantity":1}  (×2)
  02:28:11.364 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  02:28:11.364 [front-end] POST to carts: http://carts/carts/673fec32b0df5c00019af95c/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}
  02:28:11.397 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec35b0df5c00019af969"}
  02:28:11.406 [front-end] POST /addresses 200 - ms - -
  02:28:11.408 [front-end] POST /cart 500 51.010 ms - 64  (×2)
  02:28:11.456 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec35b0df5c00019af969"}
  02:28:11.466 [front-end] POST /cards 200 - ms - -
  02:28:11.516 [front-end] Attempting to delete cart for user: 673fec35b0df5c00019af969
  02:28:11.561 [front-end] User cart deleted with status: 503
  02:28:11.579 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
  02:28:11.579 [front-end] POST to carts: http://carts/carts/673fec35b0df5c00019af969/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}
  02:28:11.642 [front-end] Request received with body: {}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:11.650 [front-end] GET Request to: http://user/customers/673fec2ab0df5c00019af942/addresses  (×2)
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×38)
  02:28:03.122 [front-end] GET /catalogue 200 - ms - -  (×43)
  02:28:03.196 [front-end] Received response: "{\"firstName\":\"FbddLnzSA\",\"lastName\":\"FbddLnzSA\",\"username\":\"FbddLnzSA\",\"id\":\"673fec21b0df5c00019af922\",\"_links\":{\"address
  02:28:03.245 [orders] 2024-11-22 02:28:03.244 ERROR [orders,,,] 6 --- [p-nio-80-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×16)
  02:28:03.391 [user] ts=2024-11-22T02:28:03.390808559Z caller=middlewares.go:46 method=Register username=kMzzAppFcYY email=kMzzAppFcYY@gmail.com took=958.317µs  (×5)
  02:28:03.523 [user] ts=2024-11-22T02:28:03.52331003Z caller=middlewares.go:46 method=Register username=sgQXbZQ email=sgQXbZQ@gmail.com took=1.065166ms
  02:28:05.055 [user] ts=2024-11-22T02:28:05.055011754Z caller=middlewares.go:104 method=GetAddresses id=673fec25b0df5c00019af92f result=1 took=781.934µs  (×18)
  02:28:06.796 [front-end] Posting Customer: {"username":"oyShDJ","password":"sWqvpeFZPy","email":"oyShDJ@gmail.com","firstName":"oyShDJ","lastName":"oyShDJ"}
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.451 [carts] 2024-11-22 02:28:10.451 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.377 [front-end] Received response: "{\"firstName\":\"vtFUiCYPGkr\",\"lastName\":\"vtFUiCYPGkr\",\"username\":\"vtFUiCYPGkr\",\"id\":\"673fec2bb0df5c00019af944\",\"_links\":{\"a
  02:28:19.135 [carts] 2024-11-22 02:28:18.940 INFO [carts,cb305558d352107b,fbb223eea295e77c,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×15)
  02:28:21.967 [front-end] Posting Customer: {"username":"PDQejFz","password":"UItpfuss","email":"PDQejFz@gmail.com","firstName":"PDQejFz","lastName":"PDQejFz"}
  02:28:23.046 [orders] 2024-11-22 02:28:23.045 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×8)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.870 [front-end] Received response: "{\"firstName\":\"sgQXbZQ\",\"lastName\":\"sgQXbZQ\",\"username\":\"sgQXbZQ\",\"id\":\"673fec33b0df5c00019af963\",\"_links\":{\"addresses\":{
  02:28:25.536 [carts] 2024-11-22 02:28:25.536 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.ItemsController : Did not find item.  (×12)
  02:28:26.351 [queue-master] Received shipment task: 673fec2db0df5c00019af953  (×18)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39cf","customerId":"673fec36b0df5c00019af96c","customer":{"id":null,"firstName":"oyShDJ","lastName":"oyShDJ","usernam
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.065 [front-end] Order response: {"id":"673fec4ad94b9000069b39d4","customerId":"673fec33b0df5c00019af963","customer":{"id":null,"firstName":"sgQXbZQ","lastName":"sgQXbZQ","usern
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket
  02:28:33.840 [front-end] Posting Customer: {"username":"MywYMGzyoIdhsgg","password":"SiEqM","email":"MywYMGzyoIdhsgg@gmail.com","firstName":"MywYMGzyoIdhsgg","lastName":"MywYMGzyoIdhsgg
  02:28:38.668 [front-end] Received response: "{\"firstName\":\"PDQejFz\",\"lastName\":\"PDQejFz\",\"username\":\"PDQejFz\",\"id\":\"673fec45b0df5c00019af990\",\"_links\":{\"addresses\":{
  02:28:40.321 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR",

## p0148
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service recommendationservice, 2024-11-18T05:37:35.035Z
```
{"timestamp":1731908255035122700,"container_name":"recommendationservice","pod_name":"recommendationservice-fdf57f545-q8t5v","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"[Recv ListRecommendations] product_ids=['0PUK6V6EV0', '6E92ZMYYFZ', '66VCHSJNUP', '1YMWWN1N4O', '2ZYFJ3GM2N']"}
```
Same service, the 2 minutes before (oldest first):
  05:37:28.947 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', 'OLJCESPC7Z', '9SIQT8TOJO', '0PUK6V6EV0', '66VCHSJNUP']  (×20)
All services, 30 seconds either side (sampled):
  05:37:05.084 [frontend] request started  (×353)
  05:37:05.092 [cartservice] GetCartAsync called with userId=fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a  (×286)
  05:37:05.116 [adservice] received ad request (context_words=[accessories])  (×40)
  05:37:05.574 [frontend] view user cart  (×74)
  05:37:05.599 [shippingservice] [GetQuote] received request  (×91)
  05:37:06.001 [cartservice] AddItemAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0, productId=1YMWWN1N4O, quantity=10  (×47)
  05:37:06.088 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"2001","nanos":530296335},"credit_card":{"credit_card_number":"4156463422675  (×3)
  05:37:06.092 [shippingservice] [ShipOrder] received request  (×17)
  05:37:06.101 [emailservice] A request to send order confirmation email to kathyyoung@example.org has been received.
  05:37:06.852 [adservice] received ad request (context_words=[decor, home])  (×19)
  05:37:08.146 [adservice] received ad request (context_words=[kitchen])  (×56)
  05:37:09.575 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"2222","nanos":930000000},"credit_card":{"credit_card_number":"4736978349268  (×4)
  05:37:09.591 [checkoutservice] order confirmation email sent to "kevinmartin@example.com"
  05:37:11.865 [emailservice] A request to send order confirmation email to epayne@example.net has been received.
  05:37:13.899 [emailservice] A request to send order confirmation email to pamrogers@example.net has been received.
  05:37:15.864 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="CAD"  (×4)
  05:37:15.915 [emailservice] A request to send order confirmation email to dominguezderek@example.org has been received.
  05:37:20.381 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"75","nanos":270328173},"credit_card":{"credit_card_number":"465030332486195  (×5)
  05:37:20.398 [checkoutservice] order confirmation email sent to "thomas37@example.net"
  05:37:25.560 [checkoutservice] order confirmation email sent to "lisa20@example.com"
  05:37:32.244 [emailservice] A request to send order confirmation email to cherylrandall@example.org has been received.
  05:37:43.030 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"12287","nanos":801857708},"credit_card":{"credit_card_number":"447183341690
  05:37:43.043 [checkoutservice] order confirmation email sent to "nicole74@example.org"  (×2)
  05:37:45.737 [emailservice] A request to send order confirmation email to alexander26@example.net has been received.
  05:37:53.367 [checkoutservice] order confirmation email sent to "watkinskelli@example.net"
  05:38:02.135 [emailservice] A request to send order confirmation email to liunicholas@example.com has been received.

## p0006
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-13T01:00:31.559Z
```
{"service":"mobservice1","message":"2021-08-13 01:00:31,559 | ERROR | 0.0.0.1 | mobservice1 | mob_helper.py -> mob_info_to_redis -> 88 | b35f8795a1f4686e | uuid:c6aa7df8-fb8e-11eb-b1c5-0242ac110004 information has expired, mobile phone login is invalid"}
```
Same service, the 2 minutes before (oldest first):
  01:00:23.241 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  01:00:23.241 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'c8575360-fb8e-11eb-aadd-0242ac110003'}  (×5)
  01:00:23.286 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'c8575360-fb8e-11eb-aadd-0242ac110003', 'value': 'tWMvxnLr'}  (×3)
  01:00:23.331 [mobservice1] INFO info c8575360-fb8e-11eb-aadd-0242ac110003:tWMvxnLr write success
  01:00:24.946 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  01:00:25.063 [mobservice1] INFO info c9593f08-fb8e-11eb-a834-0242ac110004:GxrcRlDj write success
  01:00:30.907 [mobservice1] INFO info ccd7cd66-fb8e-11eb-81ad-0242ac110003:Xkwacyxi write success
All services, 30 seconds either side (sampled):
  01:00:01.561 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×35)
  01:00:01.890 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  01:00:02.109 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  01:00:02.393 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×35)
  01:00:02.681 [webservice1] ERROR an error occurred in the downstream service
  01:00:02.961 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  01:00:03.329 [redisservice2] INFO redis读取信息成功, status_code: 200  (×42)
  01:00:03.486 [dbservice2] INFO query = select passwards from username_table where user_name='sjignBZH'  (×39)
  01:00:05.658 [mobservice2] INFO info bdcb51a8-fb8e-11eb-b7cd-0242ac110004:rDnqUwke write success
  01:00:08.147 [mobservice1] INFO info bf4807e2-fb8e-11eb-a34f-0242ac110003:AnasJGMP write success
  01:00:10.662 [mobservice1] INFO info c0bf6c32-fb8e-11eb-9216-0242ac110004:wKjLqdJi write success
  01:00:13.037 [mobservice1] INFO info c2322e56-fb8e-11eb-bf61-0242ac110004:cUsPLdAz write success
  01:00:15.496 [mobservice2] INFO info c3a3423e-fb8e-11eb-a22d-0242ac110003:EAoGeZwV write success
  01:00:18.192 [mobservice1] INFO info c5396b0a-fb8e-11eb-9ec5-0242ac110003:riyTUAVs write success
  01:00:22.041 [dbservice1] INFO c74ba32c-fb8e-11eb-972e-0242ac110004-XUtTqLre-dtbi.SgcZV?! token generate success token=MTYyODc4NzYyMi4wNDEzODczOmM3NGJhMzJjLWZiOGUtMTFlYi05NzJlLTAyNDJhYzE
  01:00:25.468 [dbservice2] INFO c9593f08-fb8e-11eb-a834-0242ac110004-GxrcRlDj-Lw{tNT75j/%g token generate success token=MTYyODc4NzYyNS40Njc1MzAzOmM5NTkzZjA4LWZiOGUtMTFlYi1hODM0LTAyNDJhYzE
  01:00:32.046 [dbservice2] INFO cd445fa8-fb8e-11eb-9212-0242ac110004-TebkoQLO-YN(rC/LgHR*? token generate success token=MTYyODc4NzYzMi4wNDYzMTc4OmNkNDQ1ZmE4LWZiOGUtMTFlYi05MjEyLTAyNDJhYzE
  01:00:34.483 [dbservice1] INFO cec3bb8a-fb8e-11eb-8eaf-0242ac110003-ZQXfBztT-3J}/s50kecn{ token generate success token=MTYyODc4NzYzNC40ODM0MTI3OmNlYzNiYjhhLWZiOGUtMTFlYi04ZWFmLTAyNDJhYzE  (×2)
  01:00:37.123 [mobservice1] INFO info d08b5c2a-fb8e-11eb-8b77-0242ac110003:UfMpdlBq write success
  01:00:39.924 [mobservice1] INFO info d2397156-fb8e-11eb-9b8a-0242ac110003:tdfCvYKb write success
  01:00:42.745 [mobservice2] INFO info d3df3e46-fb8e-11eb-b4ec-0242ac110004:xgpqRfCn write success
  01:00:45.420 [mobservice1] INFO info d56e84c4-fb8e-11eb-b4db-0242ac110003:RcoJYnsh write success
  01:00:48.517 [mobservice2] INFO info d7582790-fb8e-11eb-977e-0242ac110003:aFPAvDqO write success
  01:00:51.457 [mobservice2] INFO info d9129db8-fb8e-11eb-ad4b-0242ac110004:iOlErWzF write success
  01:00:54.215 [mobservice1] INFO info dabe5472-fb8e-11eb-950f-0242ac110003:UVDQSlfP write success
  01:00:56.596 [mobservice2] INFO info dc28e7dc-fb8e-11eb-bf11-0242ac110003:CyQWkovZ write success
  01:00:59.922 [mobservice1] INFO info de272c7e-fb8e-11eb-8cb7-0242ac110004:GOhWXRIV write success

## p0252
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:05.340Z
```
{"timestamp":1732242485340055000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Customer: {\"username\":\"vuOxCKL\",\"password\":\"bIsUMRFIu\",\"email\":\"vuOxCKL@gmail.com\",\"firstName\":\"vuOxCKL\",\"lastName\":\"vuOxCKL\"}"}
```
Same service, the 2 minutes before (oldest first):
  02:28:05.097 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:05.097 [front-end] Order response: {"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:05.100 [front-end] POST /orders 500 - ms - -
  02:28:05.146 [front-end] POST /cart 500 72.021 ms - 64
  02:28:05.160 [front-end] Request received with body: {}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:05.166 [front-end] GET Request to: http://user/customers/673fec20b0df5c00019af91e/addresses  (×2)
  02:28:05.172 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:05.172 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec29b0df5c00019af941\",\"_links\":{\"
  02:28:05.172 [front-end] [ undefined, undefined ]
  02:28:05.172 [front-end] Posting Order: {"customer":"http://user/customers/673fec20b0df5c00019af91e","address":"http://user/addresses/673fec29b0df5c00019af940","card":"http://user/cards
  02:28:05.175 [front-end] Posting Customer: {"username":"vvgsHcY","password":"qfZoo","email":"vvgsHcY@gmail.com","firstName":"vvgsHcY","lastName":"vvgsHcY"}
  02:28:05.183 [front-end] { id: '673fec35b0df5c00019af968' }
  02:28:05.183 [front-end] 673fec35b0df5c00019af968
  02:28:05.183 [front-end] Merging carts for customer id: 673fec35b0df5c00019af968 and session id: jnISKiTRaFwdCJHUn8WYbMXUHWIOX3JL
  02:28:05.241 [front-end] Carts merged.
  02:28:05.241 [front-end] set cookie673fec35b0df5c00019af968
  02:28:05.242 [front-end] Sent cookies.
  02:28:05.245 [front-end] POST /register 200 66.927 ms - 33
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×32)
  02:28:03.118 [catalogue] ts=2024-11-22T02:28:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.040202ms  (×36)
  02:28:03.190 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af953/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×18)
  02:28:03.211 [user] ts=2024-11-22T02:28:03.211690554Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=1.207621ms  (×36)
  02:28:03.252 [front-end] POST /orders 500 - ms - -  (×30)
  02:28:03.410 [front-end] Carts merged.  (×31)
  02:28:04.929 [front-end] Posting Customer: {"username":"JGQXvUjPbFrtK","password":"HtglbTyNG","email":"JGQXvUjPbFrtK@gmail.com","firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPbFrtK"}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:07.408 [front-end] Received response: "{\"firstName\":\"iTdzWTHcUAJJ\",\"lastName\":\"iTdzWTHcUAJJ\",\"username\":\"iTdzWTHcUAJJ\",\"id\":\"673fec22b0df5c00019af923\",\"_links\":{
  02:28:09.014 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×4)
  02:28:10.451 [carts] 2024-11-22 02:28:10.451 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  02:28:11.653 [user] ts=2024-11-22T02:28:11.653746097Z caller=middlewares.go:75 method=GetUsers id=673fec2ab0df5c00019af942 result=1 took=692µs
  02:28:14.311 [front-end] Posting Customer: {"username":"AIwPgMB","password":"ciKTe","email":"AIwPgMB@gmail.com","firstName":"AIwPgMB","lastName":"AIwPgMB"}
  02:28:16.228 [front-end] Posting Customer: {"username":"yTFoonPwqaY","password":"UsabiUKuuH","email":"yTFoonPwqaY@gmail.com","firstName":"yTFoonPwqaY","lastName":"yTFoonPwqaY"}
  02:28:17.978 [front-end] Posting Customer: {"username":"XaRPipq","password":"IPVIE","email":"XaRPipq@gmail.com","firstName":"XaRPipq","lastName":"XaRPipq"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.114 [front-end] Received response: "{\"firstName\":\"bCCZHBaYc\",\"lastName\":\"bCCZHBaYc\",\"username\":\"bCCZHBaYc\",\"id\":\"673fec31b0df5c00019af95b\",\"_links\":{\"address
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=673ns  (×9)
  02:28:23.749 [front-end] Posting Customer: {"username":"bhZuEQ","password":"CYefrd","email":"bhZuEQ@gmail.com","firstName":"bhZuEQ","lastName":"bhZuEQ"}
  02:28:24.870 [front-end] Received response: "{\"firstName\":\"sgQXbZQ\",\"lastName\":\"sgQXbZQ\",\"username\":\"sgQXbZQ\",\"id\":\"673fec33b0df5c00019af963\",\"_links\":{\"addresses\":{
  02:28:25.471 [front-end] Received response: "{\"firstName\":\"TcTuIokN\",\"lastName\":\"TcTuIokN\",\"username\":\"TcTuIokN\",\"id\":\"673fec32b0df5c00019af95c\",\"_links\":{\"addresses\
  02:28:25.838 [carts] 2024-11-22 02:28:25.837 INFO [carts,041812a6e38b1a0d,28fc13fb8146605a,false] 7 --- [-nio-80-exec-10] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×8)
  02:28:26.670 [orders-db] {"t":{"$date":"2024-11-22T02:28:26.670+00:00"},"s":"I", "c":"STORAGE", "id":20279, "ctx":"conn2","msg":"Conflicted creating a collection","attr":{"namespace":"d
  02:28:26.957 [front-end] Order response: {"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","lastName":"vuOxCKL","usern
  02:28:26.962 [front-end] Order response: {"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPb
  02:28:27.060 [front-end] Order response: {"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","lastName":"HFHBXn","usernam
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.842 [front-end] Posting Customer: {"username":"UsfOoRUlayKw","password":"RviRN","email":"UsfOoRUlayKw@gmail.com","firstName":"UsfOoRUlayKw","lastName":"UsfOoRUlayKw"}
  02:28:32.341 [queue-master] Caused by: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket
  02:28:32.649 [queue-master] 2024-11-22 02:28:32.649 ERROR 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×4)

## p0174
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T06:35:16.047Z
```
{"timestamp":1731911716047435500,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  06:35:15.091 [currencyservice] Getting supported currencies...  (×6)
  06:35:15.117 [currencyservice] conversion request successful  (×14)
All services, 30 seconds either side (sampled):
  06:34:46.568 [frontend] request started  (×286)
  06:34:46.572 [currencyservice] Getting supported currencies...  (×239)
  06:34:46.583 [currencyservice] conversion request successful  (×622)
  06:34:46.601 [adservice] received ad request (context_words=[footwear])  (×17)
  06:34:46.794 [frontend] view user cart  (×68)
  06:34:46.821 [shippingservice] [GetQuote] completed request  (×77)
  06:34:46.871 [adservice] received ad request (context_words=[decor, home])  (×14)
  06:34:47.595 [frontend] home  (×30)
  06:34:47.647 [adservice] received ad request (context_words=[])  (×30)
  06:34:49.047 [emailservice] starting the email service in dummy mode.  (×3)
  06:34:49.127 [adservice] received ad request (context_words=[kitchen])  (×41)
  06:34:49.143 [emailservice] AttributeError: '_Server' object has no attribute 'Check'  (×3)
  06:34:49.554 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=0PUK6V6EV0, quantity=4  (×27)
  06:34:49.615 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="JPY"  (×4)
  06:34:49.641 [paymentservice] Transaction processed: visa ending 0084 Amount: JPY9498.168952016  (×4)
  06:34:49.645 [shippingservice] [ShipOrder] received request  (×9)
  06:34:49.648 [cartservice] EmptyCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×9)
  06:34:49.784 [checkoutservice] failed to send order confirmation to "jeffrey34@example.net": rpc error: code = Unavailable desc = no healthy upstream
  06:34:50.400 [adservice] received ad request (context_words=[hair, beauty])  (×12)
  06:35:05.867 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"393","nanos":836504204},"credit_card":{"credit_card_number":"44537599818589
  06:35:05.877 [checkoutservice] failed to send order confirmation to "andrewbryant@example.com": rpc error: code = Unavailable desc = no healthy upstream
  06:35:21.980 [checkoutservice] failed to send order confirmation to "glyons@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:35:30.632 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="EUR"  (×2)
  06:35:30.655 [paymentservice] Transaction processed: visa ending 8984 Amount: EUR139.690402479  (×2)
  06:35:33.509 [checkoutservice] [PlaceOrder] user_id="acc735c5-72d0-48e6-b237-46a63eac4c4d" user_currency="TRY"  (×2)
  06:35:33.533 [paymentservice] Transaction processed: visa ending 1536 Amount: TRY1077.524620100  (×2)
  06:35:35.069 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', 'OLJCESPC7Z', 'LS4PSXUNUM']
  06:35:40.196 [checkoutservice] failed to send order confirmation to "schwartzjoan@example.net": rpc error: code = Unavailable desc = no healthy upstream

## p0491
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:01:02.472Z
```
{"timestamp":1732352462472806400,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:01:02.472474154Z caller=middlewares.go:75 method=GetUsers id=674199baa437380001df0252 result=1 took=2.551458ms"}
```
Same service, the 2 minutes before (oldest first):
  09:00:59.334 [user] ts=2024-11-23T09:00:59.334181157Z caller=middlewares.go:46 method=Register username=AAFbsvqZLHR email=AAFbsvqZLHR@gmail.com took=2.775594ms  (×3)
  09:00:59.765 [user] ts=2024-11-23T09:00:59.765151571Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=674199c3a437380001df0269 took=4.010169ms
  09:00:59.780 [user] ts=2024-11-23T09:00:59.780525298Z caller=middlewares.go:118 method=PostCard card=*****3321 user=674199c3a437380001df0269 took=4.459842ms
  09:01:00.533 [user] ts=2024-11-23T09:01:00.533528024Z caller=middlewares.go:46 method=Register username=lxdMY email=lxdMY@gmail.com took=1.84629ms
  09:01:01.849 [user] ts=2024-11-23T09:01:01.848981695Z caller=middlewares.go:157 method=Health result=2 took=2.000008ms  (×2)
  09:01:02.032 [user] ts=2024-11-23T09:01:02.032035046Z caller=middlewares.go:75 method=GetUsers id=674199bba437380001df0256 result=1 took=2.604774ms  (×7)
  09:01:02.063 [user] ts=2024-11-23T09:01:02.063187473Z caller=middlewares.go:134 method=GetCards id=674199c4a437380001df026c result=1 took=2.34789ms  (×2)
  09:01:02.063 [user] ts=2024-11-23T09:01:02.063313736Z caller=middlewares.go:104 method=GetAddresses id=674199c4a437380001df026b result=1 took=2.77632ms  (×2)
  09:01:02.444 [user] ts=2024-11-23T09:01:02.444282738Z caller=middlewares.go:46 method=Register username=gHYGCL email=gHYGCL@gmail.com took=2.030655ms
All services, 30 seconds either side (sampled):
  09:00:32.476 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741999fa437380001df0200\",\"_links\":{\"  (×62)
  09:00:32.499 [front-end] POST /orders 406 - ms - -  (×62)
  09:00:33.031 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×9)
  09:00:33.909 [front-end] 674199b1a437380001df023a  (×61)
  09:00:35.049 [front-end] Request received with body: {}  (×61)
  09:00:35.753 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×14)
  09:00:37.610 [front-end] Order response: {"id":"674199b53f77060008865449","customerId":"6741999fa437380001df01ff","customer":{"id":null,"firstName":"fdxXHRsCcF","lastName":"fdxXHRsCcF",
  09:00:39.922 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×4)
  09:00:42.760 [front-end] Order response: {"statusCode":201,"body":{"id":"674199ba3f7706000886544e","customerId":"674199a3a437380001df0211","customer":{"id":null,"firstName":"EhYqkOrnxRV
  09:00:46.140 [front-end] Order response: {"id":"674199be3f7706000886544f","customerId":"674199a7a437380001df0222","customer":{"id":null,"firstName":"kNkSi","lastName":"kNkSi","username"
  09:00:48.243 [front-end] Posting Customer: {"username":"SBvlOMWEuLX","password":"xOnJQhnu","email":"SBvlOMWEuLX@gmail.com","firstName":"SBvlOMWEuLX","lastName":"SBvlOMWEuLX"}
  09:00:50.689 [front-end] Received response: "{\"firstName\":\"EfzGTns\",\"lastName\":\"EfzGTns\",\"username\":\"EfzGTns\",\"id\":\"674199aea437380001df022f\",\"_links\":{\"addresses\":{
  09:00:52.743 [front-end] Order response: {"statusCode":201,"body":{"id":"674199c43f77060008865457","customerId":"674199ada437380001df022e","customer":{"id":null,"firstName":"NRsNViUk","
  09:00:55.868 [front-end] Order response: {"id":"674199c73f77060008865459","customerId":"674199aca437380001df022d","customer":{"id":null,"firstName":"iaJWQZLpVBVFO","lastName":"iaJWQZLpV
  09:00:58.229 [front-end] Order response: {"id":"674199ca3f7706000886545b","customerId":"674199b6a437380001df024c","customer":{"id":null,"firstName":"QnugZL","lastName":"QnugZL","usernam
  09:01:02.039 [front-end] Received response: "{\"firstName\":\"eFmDJijNAo\",\"lastName\":\"eFmDJijNAo\",\"username\":\"eFmDJijNAo\",\"id\":\"674199bba437380001df0256\",\"_links\":{\"addr
  09:01:04.962 [front-end] Posting Customer: {"username":"oShHMP","password":"KwWJU","email":"oShHMP@gmail.com","firstName":"oShHMP","lastName":"oShHMP"}
  09:01:07.368 [front-end] Received response: "{\"firstName\":\"MGzSyikafd\",\"lastName\":\"MGzSyikafd\",\"username\":\"MGzSyikafd\",\"id\":\"674199bfa437380001df025c\",\"_links\":{\"addr
  09:01:08.638 [front-end] Order response: {"statusCode":201,"body":{"id":"674199d43f77060008865463","customerId":"674199c0a437380001df0262","customer":{"id":null,"firstName":"PNiRZeXiYaL
  09:01:09.468 [front-end] Received response: "{\"firstName\":\"USbKvnAYL\",\"lastName\":\"USbKvnAYL\",\"username\":\"USbKvnAYL\",\"id\":\"674199c5a437380001df026d\",\"_links\":{\"address
  09:01:10.488 [front-end] Order response: {"id":"674199d63f77060008865468","customerId":"674199c4a437380001df026a","customer":{"id":null,"firstName":"vZeWnotmPJh","lastName":"vZeWnotmPJh
  09:01:13.742 [front-end] Posting Customer: {"username":"vHBEKVQfX","password":"ZvGUiL","email":"vHBEKVQfX@gmail.com","firstName":"vHBEKVQfX","lastName":"vHBEKVQfX"}
  09:01:18.007 [front-end] Received response: "{\"firstName\":\"dNHLyb\",\"lastName\":\"dNHLyb\",\"username\":\"dNHLyb\",\"id\":\"674199caa437380001df0289\",\"_links\":{\"addresses\":{\"h
  09:01:21.290 [front-end] Received response: "{\"firstName\":\"DOcBy\",\"lastName\":\"DOcBy\",\"username\":\"DOcBy\",\"id\":\"674199cba437380001df028a\",\"_links\":{\"addresses\":{\"href
  09:01:24.200 [front-end] Received response: "{\"firstName\":\"IkaJHdkEukozfZ\",\"lastName\":\"IkaJHdkEukozfZ\",\"username\":\"IkaJHdkEukozfZ\",\"id\":\"674199cba437380001df0292\",\"_lin
  09:01:25.160 [front-end] Order response: {"statusCode":201,"body":{"id":"674199e53f77060008865478","customerId":"674199cba437380001df0291","customer":{"id":null,"firstName":"HByQVpdYlTN
  09:01:25.877 [user] ts=2024-11-23T09:01:25.877108686Z caller=middlewares.go:46 method=Register username=ohIZbLd email=ohIZbLd@gmail.com took=2.98653ms
  09:01:29.805 [front-end] Posting Customer: {"username":"NAzvYcCKRdCt","password":"MzkOtnR","email":"NAzvYcCKRdCt@gmail.com","firstName":"NAzvYcCKRdCt","lastName":"NAzvYcCKRdCt"}
  09:01:32.301 [front-end] Posting Customer: {"username":"VmfoNyPOT","password":"KHJEPFlQBg","email":"VmfoNyPOT@gmail.com","firstName":"VmfoNyPOT","lastName":"VmfoNyPOT"}

## p0106
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:09:37.662Z
```
{"timestamp":1731906577662555100,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  05:09:36.721 [frontend] serving product page  (×3)
  05:09:36.721 [frontend] request started  (×6)
  05:09:36.721 [frontend] adding to cart  (×2)
  05:09:36.730 [frontend] request complete  (×7)
  05:09:36.732 [frontend] view user cart  (×2)
All services, 30 seconds either side (sampled):
  05:09:08.005 [frontend] request started  (×319)
  05:09:08.020 [cartservice] GetCartAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add  (×261)
  05:09:08.047 [adservice] received ad request (context_words=[accessories])  (×32)
  05:09:08.566 [adservice] received ad request (context_words=[kitchen])  (×36)
  05:09:11.550 [frontend] home  (×35)
  05:09:12.018 [frontend] view user cart  (×71)
  05:09:12.465 [adservice] received ad request (context_words=[footwear])  (×21)
  05:09:14.680 [cartservice] AddItemAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53, productId=OLJCESPC7Z, quantity=2  (×39)
  05:09:17.920 [frontend] placing order  (×14)
  05:09:17.948 [paymentservice] Transaction processed: visa ending 3846 Amount: CAD316.972079616  (×5)
  05:09:17.951 [shippingservice] [ShipOrder] completed request  (×13)
  05:09:17.962 [checkoutservice] order confirmation email sent to "christinaware@example.net"
  05:09:18.724 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"258141","nanos":112782864},"credit_card":{"credit_card_number":"44867658366  (×4)
  05:09:18.740 [checkoutservice] order confirmation email sent to "dconner@example.com"
  05:09:20.431 [emailservice] A request to send order confirmation email to garciajessica@example.com has been received.
  05:09:28.202 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"205","nanos":210123835},"credit_card":{"credit_card_number":"48097360046457
  05:09:28.217 [checkoutservice] order confirmation email sent to "edwardslarry@example.com"
  05:09:30.671 [frontend] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
  05:09:30.692 [paymentservice] }
  05:09:31.202 [emailservice] A request to send order confirmation email to kramerkatherine@example.com has been received.
  05:09:39.812 [checkoutservice] order confirmation email sent to "janice63@example.net"
  05:09:46.382 [paymentservice] Transaction processed: visa ending 6282 Amount: EUR2592.65457790  (×2)
  05:09:46.446 [emailservice] A request to send order confirmation email to richard26@example.net has been received.
  05:09:49.026 [emailservice] A request to send order confirmation email to erin73@example.org has been received.
  05:09:52.127 [paymentservice] Transaction processed: visa ending 4346 Amount: USD673.830000000
  05:10:03.124 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '6E92ZMYYFZ']  (×2)

## p0741
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service paymentservice, 2024-11-23T12:54:21.908Z
```
{"service":"paymentservice","operation":"grpc.hipstershop.PaymentService/Charge","method":"Charge","status_code":400,"duration_us":887,"trace_id":"15e4d840d1a942f238acb67ec5cdeee6","message":"span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400"}
```
Same service, the 2 minutes before (oldest first):
  12:53:37.501 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"1568","nanos":942994241},"credit_card":{"credit_card_number":"4156145366884  (×3)
  12:53:37.501 [paymentservice] Transaction processed: visa ending 4838 Amount: GBP1568.942994241  (×3)
  12:53:43.045 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"35","nanos":960000000},"credit_card":{"credit_card_number":"453332005144021  (×3)
  12:53:43.045 [paymentservice] Transaction processed: visa ending 0212 Amount: USD35.960000000  (×3)
  12:53:55.800 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"131","nanos":729323311},"credit_card":{"credit_card_number":"45454017957548  (×2)
  12:53:55.800 [paymentservice] Transaction processed: visa ending 4849 Amount: EUR131.729323311  (×2)
  12:54:14.122 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"152175","nanos":313579492},"credit_card":{"credit_card_number":"42833216059
  12:54:14.122 [paymentservice] Transaction processed: visa ending 7172 Amount: JPY152175.313579492
  12:54:16.618 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"698","nanos":502937650},"credit_card":{"credit_card_number":"44377804832301
  12:54:16.618 [paymentservice] Transaction processed: visa ending 0126 Amount: TRY698.502937650
All services, 30 seconds either side (sampled):
  12:53:51.908 [checkoutservice] payment went through (transaction_id: e17ef8b9-6931-4774-9dc9-fbd45a868dfb)  (×12)
  12:53:51.912 [cartservice] EmptyCartAsync called with userId=931a1dee-a1ff-459e-84f4-7a7d7e884cd2  (×12)
  12:53:51.920 [frontend] order placed  (×12)
  12:53:51.943 [frontend] request complete  (×326)
  12:53:52.232 [cartservice] GetCartAsync called with userId=e0a6797b-7b87-4f32-b2dd-31c00e8def69  (×266)
  12:53:52.409 [adservice] received ad request (context_words=[decor, home])  (×14)
  12:53:52.643 [cartservice] AddItemAsync called with userId=5610460a-814f-43e0-96b6-68f36171d3ca, productId=L9ECAV7KIM, quantity=2  (×37)
  12:53:52.676 [shippingservice] [GetQuote] completed request  (×78)
  12:53:52.724 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"378","nanos":370000000},"credit_card":{"credit_card_number":"40197025623414  (×2)
  12:53:52.740 [checkoutservice] order confirmation email sent to "mariahzuniga@example.com"
  12:53:53.152 [adservice] received ad request (context_words=[clothing, tops])  (×21)
  12:53:53.958 [frontend] ENV_PLATFORM is: aws  (×34)
  12:53:55.057 [redis] 1:M 23 Nov 2024 12:53:55.056 * Background saving started by pid 32
  12:53:55.111 [adservice] received ad request (context_words=[hair, beauty])  (×14)
  12:53:55.205 [checkoutservice] order confirmation email sent to "brent81@example.net"
  12:53:55.800 [paymentservice] Transaction processed: visa ending 4849 Amount: EUR131.729323311  (×3)
  12:53:57.531 [checkoutservice] [PlaceOrder] user_id="706f37f6-1c4e-4686-b19d-4ff2d2c889ad" user_currency="GBP"  (×2)
  12:53:57.561 [emailservice] A request to send order confirmation email to jimmylowe@example.org has been received.
  12:54:08.026 [emailservice] A request to send order confirmation email to cartertheresa@example.org has been received.
  12:54:14.122 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"152175","nanos":313579492},"credit_card":{"credit_card_number":"42833216059  (×3)
  12:54:14.136 [checkoutservice] order confirmation email sent to "tracy54@example.org"
  12:54:16.618 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"698","nanos":502937650},"credit_card":{"credit_card_number":"44377804832301
  12:54:16.632 [checkoutservice] order confirmation email sent to "julie54@example.com"
  12:54:21.910 [paymentservice] UnacceptedCreditCard [Error]: Sorry, we cannot process visa_electron credit cards. Only VISA or MasterCard is accepted. at charge (/usr/src/app/charge.js:74:68)
  12:54:22.123 [checkoutservice] [PlaceOrder] user_id="931a1dee-a1ff-459e-84f4-7a7d7e884cd2" user_currency="CAD"
  12:54:22.149 [emailservice] A request to send order confirmation email to paulskinner@example.net has been received.
  12:54:41.548 [checkoutservice] order confirmation email sent to "zgarner@example.com"
  12:54:48.896 [emailservice] A request to send order confirmation email to websterchristopher@example.org has been received.

## p0241
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T08:03:28.680Z
```
{"timestamp":1731917008680135000,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-svrwm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"AddItemAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add, productId=1YMWWN1N4O, quantity=3"}
```
Same service, the 2 minutes before (oldest first):
  08:03:25.702 [cartservice] GetCartAsync called with userId=736a09b5-665e-4823-8520-b8602b0bdbff  (×18)
  08:03:26.194 [cartservice] AddItemAsync called with userId=c216dec4-2181-4773-8cc5-aa587ee59fcc, productId=66VCHSJNUP, quantity=5
  08:03:26.272 [cartservice] EmptyCartAsync called with userId=c216dec4-2181-4773-8cc5-aa587ee59fcc
All services, 30 seconds either side (sampled):
  08:02:59.377 [frontend] request started  (×289)
  08:02:59.386 [cartservice] GetCartAsync called with userId=adf41e5f-12f6-4c40-88a0-a1bcf421e416  (×238)
  08:02:59.410 [adservice] received ad request (context_words=[accessories])  (×39)
  08:02:59.554 [shippingservice] [GetQuote] received request  (×68)
  08:02:59.944 [adservice] received ad request (context_words=[clothing, tops])  (×18)
  08:03:00.787 [adservice] received ad request (context_words=[footwear])  (×18)
  08:03:03.131 [frontend] setting currency  (×17)
  08:03:03.182 [adservice] received ad request (context_words=[])  (×22)
  08:03:03.776 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"1082","nanos":888134474},"credit_card":{"credit_card_number":"4659929168492  (×3)
  08:03:03.779 [shippingservice] [ShipOrder] received request  (×12)
  08:03:03.787 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 13  (×14)
  08:03:03.791 [frontend] order placed  (×12)
  08:03:07.102 [paymentservice] Transaction processed: visa ending 2022 Amount: JPY85956.472358486  (×2)
  08:03:08.309 [checkoutservice] [PlaceOrder] user_id="c216dec4-2181-4773-8cc5-aa587ee59fcc" user_currency="CAD"  (×3)
  08:03:08.341 [emailservice] A request to send order confirmation email to terrelltroy@example.org has been received.
  08:03:09.007 [checkoutservice] failed to send order confirmation to "christina07@example.net": rpc error: code = Internal desc = Failed to serialize response!
  08:03:13.310 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"534","nanos":458873944},"credit_card":{"credit_card_number":"49975461912480
  08:03:13.325 [checkoutservice] failed to send order confirmation to "johnbaker@example.org": rpc error: code = Internal desc = Failed to serialize response!
  08:03:16.755 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"299","nanos":734630697},"credit_card":{"credit_card_number":"47769812394152  (×2)
  08:03:16.769 [checkoutservice] failed to send order confirmation to "garciajohn@example.org": rpc error: code = Internal desc = Failed to serialize response!
  08:03:20.972 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="USD"  (×2)
  08:03:21.031 [emailservice] A request to send order confirmation email to krichards@example.org has been received.
  08:03:21.536 [checkoutservice] failed to send order confirmation to "landerson@example.net": rpc error: code = Internal desc = Failed to serialize response!
  08:03:26.280 [emailservice] A request to send order confirmation email to chloe15@example.com has been received.
  08:03:39.894 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  08:03:39.898 [frontend] request error

## p0831
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-other-service, 2024-12-08T12:22:47.502Z
```
{"timestamp":1733660567502944500,"container_name":"ts-order-other-service","pod_name":"ts-order-other-service-746fccc88f-swlz4","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-08 12:22:47.502  INFO 1 --- [io-12032-exec-9] other.service.OrderOtherServiceImpl      : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=1787818851, startStation=shanghai, destStation=nanjing), Ticket(seatNo=1286473797, startStation=shanghai, destStation=nanjing), Ticket(seatNo=535388438, startStation=shanghai, destStation=nanjing), Ticket(seatNo=462074083, startStation=shan…"}
```
Same service, the 2 minutes before (oldest first):
  12:22:31.302 [ts-order-other-service] 2024-12-08 12:22:31.302 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×9)
  12:22:31.800 [ts-order-other-service] 2024-12-08 12:22:31.800 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:0  (×4)
  12:22:31.806 [ts-order-other-service] 2024-12-08 12:22:31.806 INFO 1 --- [io-12032-exec-5] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 102  (×4)
  12:22:31.898 [ts-order-other-service] 2024-12-08 12:22:31.898 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=178781  (×2)
  12:22:37.577 [ts-order-other-service] 2024-12-08 12:22:37.577 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Security Info Get]
All services, 30 seconds either side (sampled):
  12:22:17.505 [ts-travel2-service] 2024-12-08 12:22:17.505 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×136)
  12:22:17.568 [ts-travel2-service] 2024-12-08 12:22:17.568 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sun Dec 08 00:00:00 GMT 2024,   (×27)
  12:22:18.386 [ts-admin-basic-info-service] 2024-12-08 12:22:18.386 INFO 1 --- [io-18767-exec-4] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×8)
  12:22:18.826 [ts-travel-service] 2024-12-08 12:22:18.826 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×12)
  12:22:19.677 [ts-travel-service] 2024-12-08 12:22:19.677 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Travel Service] Query TripResponse  (×3)
  12:22:19.751 [ts-basic-service] 2024-12-08 12:22:19.751 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270
  12:22:19.782 [ts-order-service] 2024-12-08 12:22:19.782 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×9)
  12:22:19.855 [ts-seat-service] 2024-12-08 12:22:19.854 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×3)
  12:22:20.004 [ts-basic-service] 2024-12-08 12:22:20.004 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：a3f256c1-0e  (×2)
  12:22:20.257 [ts-basic-service] 2024-12-08 12:22:20.257 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0848  (×2)
  12:22:31.189 [ts-basic-service] 2024-12-08 12:22:31.188 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×14)
  12:22:31.291 [ts-travel2-service] 2024-12-08 12:22:31.291 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×3)
  12:22:31.999 [ts-seat-service] 2024-12-08 12:22:31.999 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×3)
  12:22:37.155 [ts-basic-service] 2024-12-08 12:22:37.155 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×4)
  12:22:37.437 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:22:37 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 200 119 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)  (×2)
  12:22:37.544 [ts-preserve-service] 2024-12-08 12:22:37.544 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Other Service][Check Security] Checking....
  12:22:37.592 [ts-preserve-service] 2024-12-08 12:22:37.592 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security Complete
  12:22:37.616 [ts-travel-service] 2024-12-08 12:22:37.616 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  12:22:38.043 [ts-seat-service] 2024-12-08 12:22:38.042 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService distributeSeat 1] The result of getTrainTypeResult is Response(  (×2)
  12:22:38.063 [ts-preserve-service] 2024-12-08 12:22:38.063 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Service][Add Assurance For Order]
  12:22:38.121 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:22:38 +0800] "POST /api/v1/preserveservice/preserve HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWeb
  12:22:56.828 [ts-price-service] 2024-12-08 12:22:56.827 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: a3f256c1-0e43-4f7d-9c2  (×2)
  12:23:00.410 [ts-consign-service] 2024-12-08 12:23:00.410 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : Order ID is :0f7a8d36-9231-4306-9881-3248475c3cd3
  12:23:01.615 [ts-travel2-service] 2024-12-08 12:23:01.615 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0
  12:23:01.766 [ts-preserve-other-service] 2024-12-08 12:23:01.766 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Step 2] Complete
  12:23:02.119 [ts-preserve-other-service] 2024-12-08 12:23:02.118 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : TripAllDetail : TripAllDetail(status=false, message=null, tripResponse
  12:23:02.254 [ts-order-other-service] 2024-12-08 12:23:02.253 INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController : [Order Other Service][Verify Login] Success
  12:23:10.672 [ts-route-mongo] {"t":{"$date":"2024-12-08T12:23:10.671+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366059
  12:23:12.176 [ts-order-other-mongo] {"t":{"$date":"2024-12-08T12:23:12.175+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366059
  12:23:14.909 [ts-order-other-service] 2024-12-08 12:23:14.909 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:0

## p0216
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:42:05.688Z
```
{"timestamp":1731915725688695600,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  07:42:04.035 [frontend] request started  (×7)
  07:42:04.035 [frontend] placing order
  07:42:04.072 [frontend] order placed
  07:42:04.088 [frontend] request complete  (×5)
  07:42:04.688 [frontend] serving product page
  07:42:04.722 [frontend] adding to cart
  07:42:04.735 [frontend] view user cart
  07:42:05.671 [frontend] setting currency  (×2)
  07:42:05.675 [frontend] home
All services, 30 seconds either side (sampled):
  07:41:36.044 [frontend] request started  (×288)
  07:41:36.053 [cartservice] GetCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03  (×238)
  07:41:36.077 [adservice] received ad request (context_words=[kitchen])  (×42)
  07:41:37.117 [adservice] received ad request (context_words=[accessories])  (×31)
  07:41:38.130 [shippingservice] [GetQuote] completed request  (×68)
  07:41:40.851 [adservice] received ad request (context_words=[])  (×34)
  07:41:43.615 [frontend] adding to cart  (×24)
  07:41:43.888 [frontend] placing order  (×10)
  07:41:43.911 [paymentservice] Transaction processed: visa ending 8401 Amount: GBP223.453558601  (×3)
  07:41:43.917 [shippingservice] [ShipOrder] completed request  (×10)
  07:41:43.928 [checkoutservice] order confirmation email sent to "nicoleanderson@example.com"
  07:41:45.192 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"1042","nanos":326559925},"credit_card":{"credit_card_number":"4491744647902  (×2)
  07:41:45.209 [emailservice] A request to send order confirmation email to nicholasduran@example.org has been received.
  07:41:49.165 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"563","nanos":200000000},"credit_card":{"credit_card_number":"46908371996340
  07:41:49.178 [checkoutservice] order confirmation email sent to "ramseyjustin@example.net"
  07:41:59.384 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"50196","nanos":620964324},"credit_card":{"credit_card_number":"484715869460
  07:41:59.398 [checkoutservice] order confirmation email sent to "hardykelli@example.org"
  07:42:02.021 [paymentservice] Transaction processed: visa ending 8949 Amount: TRY1602.932321100  (×2)
  07:42:04.068 [emailservice] A request to send order confirmation email to nthomas@example.com has been received.
  07:42:06.184 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"1172","nanos":613887675},"credit_card":{"credit_card_number":"4745989261184
  07:42:06.198 [checkoutservice] order confirmation email sent to "charles74@example.org"
  07:42:08.669 [emailservice] A request to send order confirmation email to mooreraymond@example.net has been received.
  07:42:26.679 [checkoutservice] order confirmation email sent to "schultzkim@example.net"

## p0285
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T02:33:52.150Z
```
{"timestamp":1732242832150885600,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T02:33:52.150644723Z caller=middlewares.go:46 method=Register username=zChpPcvAuCjkHis email=zChpPcvAuCjkHis@gmail.com took=982.788µs"}
```
Same service, the 2 minutes before (oldest first):
  02:33:51.093 [user] ts=2024-11-22T02:33:51.093670162Z caller=middlewares.go:157 method=Health result=2 took=727.586µs  (×2)
  02:33:51.161 [user] ts=2024-11-22T02:33:51.160784869Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673fed85b0df5c00019afd5b took=1.582853ms  (×3)
  02:33:51.175 [user] ts=2024-11-22T02:33:51.175305711Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673fed85b0df5c00019afd5b took=1.498119ms  (×3)
  02:33:51.688 [user] ts=2024-11-22T02:33:51.688393808Z caller=middlewares.go:75 method=GetUsers id=673fed77b0df5c00019afd2d result=1 took=967.145µs  (×8)
  02:33:51.704 [user] ts=2024-11-22T02:33:51.704083558Z caller=middlewares.go:104 method=GetAddresses id=673fed80b0df5c00019afd45 result=1 took=689.234µs
  02:33:51.704 [user] ts=2024-11-22T02:33:51.704441334Z caller=middlewares.go:134 method=GetCards id=673fed80b0df5c00019afd46 result=1 took=909.87µs
  02:33:51.920 [user] ts=2024-11-22T02:33:51.920325704Z caller=middlewares.go:104 method=GetAddresses id=673fed82b0df5c00019afd4c result=1 took=1.229669ms
  02:33:51.922 [user] ts=2024-11-22T02:33:51.922700941Z caller=middlewares.go:134 method=GetCards id=673fed82b0df5c00019afd4d result=1 took=2.194054ms
All services, 30 seconds either side (sampled):
  02:33:22.177 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fed6bb0df5c00019afd0d"}  (×58)
  02:33:22.303 [front-end] POST /cart 201 - ms - -  (×57)
  02:33:22.617 [catalogue] ts=2024-11-22T02:33:22Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.060225ms  (×68)
  02:33:23.997 [user] ts=2024-11-22T02:33:23.997310374Z caller=middlewares.go:134 method=GetCards id=673fed67b0df5c00019afd01 result=1 took=831.16µs  (×30)
  02:33:24.022 [front-end] POST /orders 201 - ms - -  (×57)
  02:33:24.583 [front-end] POST to carts: http://carts/carts/673fed6eb0df5c00019afd18/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}  (×25)
  02:33:26.080 [carts] 2024-11-22 02:33:26.080 INFO [carts,2c292cd188c2aac0,3d3020544a2aa19b,false] 7 --- [p-nio-80-exec-9] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×26)
  02:33:28.529 [front-end] Received response: "{\"firstName\":\"uGgJitWyTQR\",\"lastName\":\"uGgJitWyTQR\",\"username\":\"uGgJitWyTQR\",\"id\":\"673fed63b0df5c00019afcf1\",\"_links\":{\"a
  02:33:30.860 [front-end] Order response: {"id":"673fed7ad94b9000069b3aee","customerId":"673fed64b0df5c00019afcf9","customer":{"id":null,"firstName":"uEKlrt","lastName":"uEKlrt","usernam
  02:33:32.367 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed7cd94b9000069b3af1","customerId":"673fed6bb0df5c00019afd0d","customer":{"id":null,"firstName":"RoQVUJK","l
  02:33:34.164 [front-end] Order response: {"id":"673fed7ed94b9000069b3af3","customerId":"673fed69b0df5c00019afd06","customer":{"id":null,"firstName":"geLOLRZuTesCDI","lastName":"geLOLRZu
  02:33:37.522 [user] ts=2024-11-22T02:33:37.522510543Z caller=middlewares.go:46 method=Register username=RlEnPQXB email=RlEnPQXB@gmail.com took=939.327µs
  02:33:41.121 [front-end] Posting Customer: {"username":"kSDTntBA","password":"uscMSIry","email":"kSDTntBA@gmail.com","firstName":"kSDTntBA","lastName":"kSDTntBA"}
  02:33:43.153 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed87d94b9000069b3af7","customerId":"673fed70b0df5c00019afd1d","customer":{"id":null,"firstName":"JNJrQ","las
  02:33:46.282 [front-end] Posting Customer: {"username":"nDjMmwhGKSAv","password":"fEEAifN","email":"nDjMmwhGKSAv@gmail.com","firstName":"nDjMmwhGKSAv","lastName":"nDjMmwhGKSAv"}
  02:33:47.326 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed8bd94b9000069b3afb","customerId":"673fed7db0df5c00019afd3d","customer":{"id":null,"firstName":"JQQRJtvdb",
  02:33:49.888 [front-end] Received response: "{\"firstName\":\"DzwGC\",\"lastName\":\"DzwGC\",\"username\":\"DzwGC\",\"id\":\"673fed7eb0df5c00019afd41\",\"_links\":{\"addresses\":{\"href
  02:33:52.146 [front-end] Posting Customer: {"username":"zChpPcvAuCjkHis","password":"IcSNuwSXm","email":"zChpPcvAuCjkHis@gmail.com","firstName":"zChpPcvAuCjkHis","lastName":"zChpPcvAuCj
  02:33:56.203 [front-end] Received response: "{\"firstName\":\"MrneIKw\",\"lastName\":\"MrneIKw\",\"username\":\"MrneIKw\",\"id\":\"673fed85b0df5c00019afd5a\",\"_links\":{\"addresses\":{
  02:33:59.003 [user] ts=2024-11-22T02:33:59.003322536Z caller=middlewares.go:46 method=Register username=mHHzjq email=mHHzjq@gmail.com took=1.022618ms
  02:34:01.175 [front-end] Order response: {"id":"673fed99d94b9000069b3b07","customerId":"673fed87b0df5c00019afd62","customer":{"id":null,"firstName":"KtDORbMQrXFgMTT","lastName":"KtDORbM
  02:34:04.063 [front-end] Order response: {"id":"673fed9cd94b9000069b3b0a","customerId":"673fed84b0df5c00019afd59","customer":{"id":null,"firstName":"XBkBDNMeahrbK","lastName":"XBkBDNMea
  02:34:06.745 [front-end] Received response: "{\"firstName\":\"fquUlXT\",\"lastName\":\"fquUlXT\",\"username\":\"fquUlXT\",\"id\":\"673fed87b0df5c00019afd5f\",\"_links\":{\"addresses\":{
  02:34:07.891 [front-end] Posting Customer: {"username":"FPDfkHHcUzTE","password":"QIQUZF","email":"FPDfkHHcUzTE@gmail.com","firstName":"FPDfkHHcUzTE","lastName":"FPDfkHHcUzTE"}
  02:34:11.950 [front-end] Order response: {"id":"673feda3d94b9000069b3b13","customerId":"673fed8ab0df5c00019afd64","customer":{"id":null,"firstName":"uLMznMqh","lastName":"uLMznMqh","use
  02:34:16.625 [front-end] Posting Customer: {"username":"nZgxrZdrCbMnJ","password":"FfUBlyxJ","email":"nZgxrZdrCbMnJ@gmail.com","firstName":"nZgxrZdrCbMnJ","lastName":"nZgxrZdrCbMnJ"}
  02:34:18.444 [front-end] Order response: {"id":"673fedaad94b9000069b3b17","customerId":"673fed9ab0df5c00019afd9a","customer":{"id":null,"firstName":"ARfXRutv","lastName":"ARfXRutv","use
  02:34:19.777 [front-end] Posting Customer: {"username":"fATjtrPxZ","password":"FELWXyOpp","email":"fATjtrPxZ@gmail.com","firstName":"fATjtrPxZ","lastName":"fATjtrPxZ"}
  02:34:21.784 [user] ts=2024-11-22T02:34:21.784392125Z caller=middlewares.go:46 method=Register username=KFkABcT email=KFkABcT@gmail.com took=1.032053ms

## p0676
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-11T16:00:49.504Z
```
{"service":"dbservice1","message":"2021-08-11 16:00:49,504 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | e839fada58e7965a | 3d555c7c-fa7a-11eb-aafe-0242ac110004-uZrYXDKb-MT}4%L2EhXFS token generate success token=MTYyODY2ODg0OS41MDM5MTMyOjNkNTU1YzdjLWZhN2EtMTFlYi1hYWZlLTAyNDJhYzExMDAwNHVacllYREtiTVR9NCVMMkVoWEZTOjE2Mjg2Njg5MDkuNTAzOTI0OmQyZDA1YjI1YmE1NWQ5NWVlZjQxZjZlOGUxYWE5MzEy"}
```
Same service, the 2 minutes before (oldest first):
  16:00:38.066 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  16:00:40.820 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  16:00:40.820 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  16:00:40.864 [dbservice1] INFO query = select passwards from username_table where user_name='CzojFELq'  (×5)
  16:00:40.947 [dbservice1] INFO 383e5608-fa7a-11eb-b728-0242ac110004-CzojFELq-MU6*h.QSdBWf token generate success token=MTYyODY2ODg0MC45NDY2NTU6MzgzZTU2MDgtZmE3YS0xMWViLWI3MjgtMDI0MmFjMTE
  16:00:42.839 [dbservice1] INFO 3969fce4-fa7a-11eb-bb97-0242ac110004-HkLmPgZU-^/Kv(%ND.k0T token generate success token=MTYyODY2ODg0Mi44Mzk0OTYxOjM5NjlmY2U0LWZhN2EtMTFlYi1iYjk3LTAyNDJhYzE
  16:00:43.791 [dbservice1] INFO 39e47fc8-fa7a-11eb-9d9f-0242ac110003-WyKqhlJd-S5&.)N$_Qvw> token generate success token=MTYyODY2ODg0My43OTA4MzkyOjM5ZTQ3ZmM4LWZhN2EtMTFlYi05ZDlmLTAyNDJhYzE
  16:00:44.679 [dbservice1] INFO 3a746746-fa7a-11eb-ba6a-0242ac110003-DQJsnMlT-Nc3Z_Ei.#d7& token generate success token=MTYyODY2ODg0NC42NzkyMjY5OjNhNzQ2NzQ2LWZhN2EtMTFlYi1iYTZhLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  16:00:19.515 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×35)
  16:00:19.646 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  16:00:19.755 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×43)
  16:00:19.858 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×41)
  16:00:20.058 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×42)
  16:00:20.448 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×40)
  16:00:20.711 [dbservice1] INFO 2c24ebac-fa7a-11eb-bf3b-0242ac110003-QSUqdTsv-er_ATbj}/nc7 token generate success token=MTYyODY2ODgyMC43MTA5MDI1OjJjMjRlYmFjLWZhN2EtMTFlYi1iZjNiLTAyNDJhYzE
  16:00:21.425 [mobservice1] INFO info 2cd75e68-fa7a-11eb-a299-0242ac110003:BLOHhDzM write success
  16:00:22.588 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×41)
  16:00:23.016 [mobservice1] INFO info 2dc5d64c-fa7a-11eb-8340-0242ac110004:kyxZCaug write success
  16:00:25.024 [dbservice2] INFO 2ed69472-fa7a-11eb-ac50-0242ac110004-jDuLxAwt-4Z=}YxLyb1Sp token generate success token=MTYyODY2ODgyNS4wMjQyNTM2OjJlZDY5NDcyLWZhN2EtMTFlYi1hYzUwLTAyNDJhYzE
  16:00:27.334 [mobservice1] INFO info 306422d2-fa7a-11eb-b04a-0242ac110004:lebfEIwL write success
  16:00:29.478 [dbservice1] INFO 315abf34-fa7a-11eb-9970-0242ac110003-yODGvlBa-{p4DPGKq%>18 token generate success token=MTYyODY2ODgyOS40NzgxMTY1OjMxNWFiZjM0LWZhN2EtMTFlYi05OTcwLTAyNDJhYzE
  16:00:32.053 [dbservice1] INFO 32e60728-fa7a-11eb-819e-0242ac110003-mFYdOIbz-A}O9cl-$UaIV token generate success token=MTYyODY2ODgzMi4wNTI4NDY3OjMyZTYwNzI4LWZhN2EtMTFlYi04MTllLTAyNDJhYzE
  16:00:34.562 [mobservice1] INFO info 34b12696-fa7a-11eb-b968-0242ac110003:GrAcpCvX write success
  16:00:36.930 [dbservice1] INFO 35b65886-fa7a-11eb-9b0f-0242ac110003-rnAReBSk-Wjgud#1.N>^z token generate success token=MTYyODY2ODgzNi45Mjk3NDc6MzViNjU4ODYtZmE3YS0xMWViLTliMGYtMDI0MmFjMTE
  16:00:40.063 [dbservice2] INFO 37a3d8a8-fa7a-11eb-a57a-0242ac110003-rYEevjPt-9g@Kz:0PJDTN token generate success token=MTYyODY2ODg0MC4wNjMzMjQ3OjM3YTNkOGE4LWZhN2EtMTFlYi1hNTdhLTAyNDJhYzE
  16:00:42.839 [dbservice1] INFO 3969fce4-fa7a-11eb-bb97-0242ac110004-HkLmPgZU-^/Kv(%ND.k0T token generate success token=MTYyODY2ODg0Mi44Mzk0OTYxOjM5NjlmY2U0LWZhN2EtMTFlYi1iYjk3LTAyNDJhYzE
  16:00:45.407 [dbservice2] INFO 3afaf040-fa7a-11eb-994f-0242ac110004-XWkAGNLi-ZF0Q*-Nk7xJ< token generate success token=MTYyODY2ODg0NS40MDcxNjU1OjNhZmFmMDQwLWZhN2EtMTFlYi05OTRmLTAyNDJhYzE
  16:00:48.042 [mobservice2] INFO info 3cb5916a-fa7a-11eb-bfa3-0242ac110003:SxlGNrtW write success
  16:00:51.019 [mobservice1] INFO info 3e82e40c-fa7a-11eb-8a7f-0242ac110004:PyWJlfep write success
  16:00:53.078 [dbservice1] INFO 3f8515c8-fa7a-11eb-a202-0242ac110003-TURfmxwe-30x($j9LcmY? token generate success token=MTYyODY2ODg1My4wNzc2Mjg6M2Y4NTE1YzgtZmE3YS0xMWViLWEyMDItMDI0MmFjMTE
  16:00:55.300 [dbservice2] INFO 40c183f4-fa7a-11eb-abfc-0242ac110004-iZWtCSMp-M5*>4^fm-6c) token generate success token=MTYyODY2ODg1NS4zMDAxMDg0OjQwYzE4M2Y0LWZhN2EtMTFlYi1hYmZjLTAyNDJhYzE
  16:00:57.773 [mobservice1] INFO info 42847a34-fa7a-11eb-ba78-0242ac110003:saHAJjFe write success
  16:01:00.490 [dbservice1] INFO 43e0281a-fa7a-11eb-b746-0242ac110003-pKxfZBio-*wUb}zXdlquF token generate success token=MTYyODY2ODg2MC40ODk3NTk3OjQzZTAyODFhLWZhN2EtMTFlYi1iNzQ2LTAyNDJhYzE
  16:01:02.854 [dbservice2] INFO 45633038-fa7a-11eb-9a25-0242ac110003-WVPTmDGM-P+m#ZGgNRh3= token generate success token=MTYyODY2ODg2Mi44NTQyMjI4OjQ1NjMzMDM4LWZhN2EtMTFlYi05YTI1LTAyNDJhYzE
  16:01:06.133 [mobservice1] INFO info 4784ed52-fa7a-11eb-a259-0242ac110004:zLGEjrhw write success
  16:01:08.175 [dbservice1] INFO 488adfe0-fa7a-11eb-a52e-0242ac110003-GKtJXRfS-m0M9zQiR3ea( token generate success token=MTYyODY2ODg2OC4xNzU0NTE6NDg4YWRmZTAtZmE3YS0xMWViLWE1MmUtMDI0MmFjMTE
  16:01:13.157 [dbservice1] INFO 4b5e301e-fa7a-11eb-adf3-0242ac110004-URMboZjf-a!7vBu@Ms{3G token generate success token=MTYyODY2ODg3My4xNTc0MDM1OjRiNWUzMDFlLWZhN2EtMTFlYi1hZGYzLTAyNDJhYzE
  16:01:18.313 [dbservice1] INFO 4e8b8480-fa7a-11eb-904a-0242ac110004-tBueHCAS-:8Y<_S=dT!{e token generate success token=MTYyODY2ODg3OC4zMTMxNTk6NGU4Yjg0ODAtZmE3YS0xMWViLTkwNGEtMDI0MmFjMTE

## p0034
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-13T07:53:39.332Z
```
{"service":"mobservice2","message":"2021-08-13 07:53:39,332 | ERROR | 0.0.0.4 | mobservice2 | mob_helper.py -> mob_info_to_redis -> 88 | 94302efe6f18271 | uuid:7d56e5d0-fbc8-11eb-9453-0242ac110004 information has expired, mobile phone login is invalid"}
```
Same service, the 2 minutes before (oldest first):
  07:53:28.316 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '7d5e06c6-fbc8-11eb-b1fa-0242ac110003', 'value': 'zxoeJtIu'}  (×4)
  07:53:28.367 [mobservice2] INFO info 7d5e06c6-fbc8-11eb-b1fa-0242ac110003:zxoeJtIu write success
  07:53:29.099 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  07:53:29.099 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  07:53:29.100 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '7de0a428-fbc8-11eb-862b-0242ac110003'}  (×4)
  07:53:29.202 [mobservice2] INFO info 7de0a428-fbc8-11eb-862b-0242ac110003:GNqpIFum write success
  07:53:31.754 [mobservice2] INFO info 7f642e78-fbc8-11eb-b764-0242ac110003:tRLZzuQg write success
  07:53:36.812 [mobservice2] INFO info 8267eaf6-fbc8-11eb-9fb0-0242ac110004:jSevQlNq write success
All services, 30 seconds either side (sampled):
  07:53:09.393 [redisservice1] INFO redis write success  (×77)
  07:53:09.625 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×35)
  07:53:09.835 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×32)
  07:53:09.973 [redisservice2] INFO service accept, status_code: 200  (×45)
  07:53:10.395 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '72b54090-fbc8-11eb-aba8-0242ac110004'}  (×49)
  07:53:11.197 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×49)
  07:53:11.406 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×42)
  07:53:12.124 [webservice1] INFO uuid: 73d70bf2-fbc8-11eb-a1b3-0242ac110003 write redis successfully  (×41)
  07:53:13.925 [mobservice1] INFO info 74c27178-fbc8-11eb-95ac-0242ac110004:QSUqdTsv write success
  07:53:16.180 [mobservice2] INFO info 7620fa76-fbc8-11eb-92f1-0242ac110003:xgKipZPG write success
  07:53:18.499 [mobservice2] INFO info 777d886c-fbc8-11eb-a15b-0242ac110004:iBnyvbLP write success
  07:53:20.915 [mobservice2] INFO info 78ef63d2-fbc8-11eb-9543-0242ac110003:IcmKxDtR write success  (×2)
  07:53:23.455 [mobservice1] INFO info 7a71bc46-fbc8-11eb-ba06-0242ac110003:zwDGqUsI write success
  07:53:26.154 [dbservice2] INFO 7bd27d32-fbc8-11eb-94d7-0242ac110003-rnAReBSk-Wjgud#1.N>^z token generate success token=MTYyODgxMjQwNi4xNTQzMzM0OjdiZDI3ZDMyLWZiYzgtMTFlYi05NGQ3LTAyNDJhYzE
  07:53:29.599 [dbservice1] INFO 7de0a428-fbc8-11eb-862b-0242ac110003-GNqpIFum-6p{Revl/Jr90 token generate success token=MTYyODgxMjQwOS41OTg3NzU5OjdkZTBhNDI4LWZiYzgtMTFlYi04NjJiLTAyNDJhYzE
  07:53:32.661 [mobservice1] INFO info 7fe4ffd0-fbc8-11eb-ac16-0242ac110003:THZxeBPz write success
  07:53:36.063 [mobservice1] INFO info 81e81e5c-fbc8-11eb-8d9c-0242ac110003:nAxhWmpD write success
  07:53:42.326 [dbservice2] INFO 856f7cbe-fbc8-11eb-8136-0242ac110003-tJwGvlrd-_X.0m+hp>Z-/ token generate success token=MTYyODgxMjQyMi4zMjY1MDQ1Ojg1NmY3Y2JlLWZiYzgtMTFlYi04MTM2LTAyNDJhYzE
  07:53:46.116 [mobservice2] INFO info 87f2fae2-fbc8-11eb-afa4-0242ac110004:edQqtaui write success
  07:53:48.657 [mobservice1] INFO info 8976f59e-fbc8-11eb-954b-0242ac110003:jliMGRSf write success
  07:53:51.025 [mobservice2] INFO info 8ae3a3fa-fbc8-11eb-b3d7-0242ac110004:EQWxHTiy write success
  07:53:53.507 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×2)
  07:53:56.119 [mobservice1] INFO info 8de1e576-fbc8-11eb-84a4-0242ac110003:qwpdAUNi write success
  07:53:58.941 [mobservice2] INFO info 8f8ba7cc-fbc8-11eb-8d4e-0242ac110003:rfqKcNpJ write success
  07:54:01.821 [mobservice2] INFO info 914fd43e-fbc8-11eb-9b7b-0242ac110003:QUpJkdTY write success
  07:54:04.676 [mobservice1] INFO info 930292f8-fbc8-11eb-a82d-0242ac110003:QYryCKLk write success
  07:54:08.143 [dbservice2] ERROR password in database of {user} is null, the user is not registered

## p0465
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T08:08:44.998Z
```
{"timestamp":1732349324998954000,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T08:08:44.998743212Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67418d87a437380001deee55 took=4.278194ms"}
```
Same service, the 2 minutes before (oldest first):
  08:08:42.757 [user] ts=2024-11-23T08:08:42.756789098Z caller=middlewares.go:75 method=GetUsers id=67418d76a437380001deee1e result=1 took=1.974253ms  (×4)
  08:08:42.780 [user] ts=2024-11-23T08:08:42.780053887Z caller=middlewares.go:104 method=GetAddresses id=67418d80a437380001deee3d result=1 took=1.583835ms
  08:08:42.780 [user] ts=2024-11-23T08:08:42.780374773Z caller=middlewares.go:134 method=GetCards id=67418d80a437380001deee3e result=1 took=2.019033ms
  08:08:42.957 [user] ts=2024-11-23T08:08:42.957730226Z caller=middlewares.go:46 method=Register username=BvoLLnU email=BvoLLnU@gmail.com took=2.451112ms
  08:08:42.957 [user] ts=2024-11-23T08:08:42.957739783Z caller=middlewares.go:46 method=Register username=oJeLVf email=oJeLVf@gmail.com took=2.308984ms
  08:08:43.487 [user] ts=2024-11-23T08:08:43.48696771Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418d82a437380001deee45 took=5.528236ms  (×5)
  08:08:43.503 [user] ts=2024-11-23T08:08:43.503025255Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67418d82a437380001deee45 took=4.351241ms  (×4)
  08:08:43.548 [user] ts=2024-11-23T08:08:43.547978397Z caller=middlewares.go:46 method=Register username=NFZvBQYjJMLA email=NFZvBQYjJMLA@gmail.com took=2.831504ms
  08:08:43.849 [user] ts=2024-11-23T08:08:43.849068018Z caller=middlewares.go:157 method=Health result=2 took=1.610504ms  (×2)
All services, 30 seconds either side (sampled):
  08:08:15.001 [front-end] Attempting to add to cart: {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","quantity":1}  (×66)
  08:08:15.327 [front-end] POST /cards 200 - ms - -  (×65)
  08:08:15.551 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418  (×66)
  08:08:15.584 [queue-master] 2024-11-23 08:08:15.584 INFO 7 --- [ool-6-thread-44] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×144)
  08:08:15.705 [front-end] Carts merged.  (×62)
  08:08:16.429 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×9)
  08:08:18.556 [front-end] Received response: "{\"firstName\":\"dfcBGnHCKo\",\"lastName\":\"dfcBGnHCKo\",\"username\":\"dfcBGnHCKo\",\"id\":\"67418d5fa437380001deedd7\",\"_links\":{\"addr
  08:08:22.504 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732349302502,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×9)
  08:08:24.302 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d783f77060008864e9e","customerId":"67418d61a437380001deeddc","customer":{"id":null,"firstName":"IrAHbNtAxV"
  08:08:25.896 [queue-master] 2024-11-23 08:08:25.896 ERROR 7 --- [pool-6-thread-3] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×9)
  08:08:27.122 [front-end] Order response: {"id":"67418d7b3f77060008864ea3","customerId":"67418d69a437380001deeded","customer":{"id":null,"firstName":"sZmftoq","lastName":"sZmftoq","usern
  08:08:28.533 [front-end] Order response: {"id":"67418d7c3f77060008864ea5","customerId":"67418d6ba437380001deedf5","customer":{"id":null,"firstName":"xzXDHDXrvCDI","lastName":"xzXDHDXrvC
  08:08:31.852 [front-end] Posting Customer: {"username":"pkJGbEGKsAbFF","password":"mTSUcwib","email":"pkJGbEGKsAbFF@gmail.com","firstName":"pkJGbEGKsAbFF","lastName":"pkJGbEGKsAbFF"}
  08:08:34.735 [front-end] Posting Customer: {"username":"WrpsfFOmjbenda","password":"lgRCMou","email":"WrpsfFOmjbenda@gmail.com","firstName":"WrpsfFOmjbenda","lastName":"WrpsfFOmjbenda"}
  08:08:37.727 [front-end] Received response: "{\"firstName\":\"ystQcWrZZKmUA\",\"lastName\":\"ystQcWrZZKmUA\",\"username\":\"ystQcWrZZKmUA\",\"id\":\"67418d71a437380001deee0d\",\"_links\
  08:08:39.447 [front-end] Received response: "{\"firstName\":\"afBVtCoCbIbqxV\",\"lastName\":\"afBVtCoCbIbqxV\",\"username\":\"afBVtCoCbIbqxV\",\"id\":\"67418d75a437380001deee1b\",\"_lin
  08:08:41.441 [user] ts=2024-11-23T08:08:41.441743137Z caller=middlewares.go:46 method=Register username=zueuJ email=zueuJ@gmail.com took=2.10998ms
  08:08:42.952 [front-end] Posting Customer: {"username":"BvoLLnU","password":"lJIHDlA","email":"BvoLLnU@gmail.com","firstName":"BvoLLnU","lastName":"BvoLLnU"}
  08:08:47.150 [front-end] Received response: "{\"firstName\":\"kXWivMa\",\"lastName\":\"kXWivMa\",\"username\":\"kXWivMa\",\"id\":\"67418d7da437380001deee35\",\"_links\":{\"addresses\":{
  08:08:50.587 [front-end] Received response: "{\"firstName\":\"LfcOjMwJvBPrdSs\",\"lastName\":\"LfcOjMwJvBPrdSs\",\"username\":\"LfcOjMwJvBPrdSs\",\"id\":\"67418d7ba437380001deee2e\",\"_
  08:08:53.801 [front-end] Order response: {"id":"67418d953f77060008864eb9","customerId":"67418d82a437380001deee46","customer":{"id":null,"firstName":"ZeaRS","lastName":"ZeaRS","username"
  08:08:57.283 [front-end] Posting Customer: {"username":"lLJuyio","password":"xdbAbmxB","email":"lLJuyio@gmail.com","firstName":"lLJuyio","lastName":"lLJuyio"}
  08:08:58.197 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d9a3f77060008864ebf","customerId":"67418d86a437380001deee53","customer":{"id":null,"firstName":"JjHlhWXKjCs
  08:09:01.769 [front-end] Order response: {"id":"67418d9d3f77060008864ec1","customerId":"67418d89a437380001deee5b","customer":{"id":null,"firstName":"zueuJ","lastName":"zueuJ","username"
  08:09:03.281 [front-end] Received response: "{\"firstName\":\"GCXSEYDNrdhjmP\",\"lastName\":\"GCXSEYDNrdhjmP\",\"username\":\"GCXSEYDNrdhjmP\",\"id\":\"67418d8fa437380001deee77\",\"_lin
  08:09:05.634 [front-end] Order response: {"id":"67418da13f77060008864ec6","customerId":"67418d8ea437380001deee72","customer":{"id":null,"firstName":"xOptU","lastName":"xOptU","username"
  08:09:06.608 [front-end] Order response: {"statusCode":201,"body":{"id":"67418da23f77060008864ec9","customerId":"67418d90a437380001deee78","customer":{"id":null,"firstName":"QTaAWbwnlhl
  08:09:08.554 [front-end] Posting Customer: {"username":"YMqLahy","password":"ysvNzY","email":"YMqLahy@gmail.com","firstName":"YMqLahy","lastName":"YMqLahy"}
  08:09:12.756 [front-end] Order response: {"statusCode":201,"body":{"id":"67418da83f77060008864ecf","customerId":"67418d8da437380001deee6e","customer":{"id":null,"firstName":"HpBqOyp","l

## p0626
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-07T20:17:52.765Z
```
{"timestamp":1733602672765063000,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-9ll65","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:17:52.764  INFO 1 --- [           main] o.s.b.a.e.mvc.EndpointHandlerMapping     : Mapped \"{[/heapdump || /heapdump.json],methods=[GET],produces=[application/octet-stream]}\" onto public void org.springframework.boot.actuate.endpoint.mvc.HeapdumpMvcEndpoint.invoke(boolean,javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse) throws java.io.IOException,javax.ser…"}
```
Same service, the 2 minutes before (oldest first):
  20:17:51.168 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/v2/api-docs],methods=[GET],produces=[application/json || applic
  20:17:51.171 [ts-route-service] 2024-12-07 20:17:51.170 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/swagger-resources]}" onto org.springframework.http.ResponseEnti
  20:17:51.172 [ts-route-service] 2024-12-07 20:17:51.171 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/configuration/ui]}" onto org.springframework.http.ResponseEntit
  20:17:51.172 [ts-route-service] 2024-12-07 20:17:51.172 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/configuration/security]}" onto org.springframework.http.Respons
  20:17:51.174 [ts-route-service] 2024-12-07 20:17:51.173 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  20:17:51.174 [ts-route-service] 2024-12-07 20:17:51.174 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  20:17:52.757 [ts-route-service] 2024-12-07 20:17:52.757 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  20:17:52.758 [ts-route-service] 2024-12-07 20:17:52.757 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics || /metrics.json],methods=[GET],produces=[application/vnd.s
  20:17:52.758 [ts-route-service] 2024-12-07 20:17:52.758 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[application/vnd.sprin
  20:17:52.759 [ts-route-service] 2024-12-07 20:17:52.759 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/vnd.spring-
  20:17:52.759 [ts-route-service] 2024-12-07 20:17:52.759 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[application/vnd.sprin
  20:17:52.760 [ts-route-service] 2024-12-07 20:17:52.760 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  20:17:52.761 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  20:17:52.761 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  20:17:52.761 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  20:17:52.762 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/auditevents || /auditevents.json],methods=[GET],produces=[applicati
  20:17:52.762 [ts-route-service] 2024-12-07 20:17:52.762 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  20:17:52.764 [ts-route-service] 2024-12-07 20:17:52.763 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[application/vnd
  20:17:52.764 [ts-route-service] 2024-12-07 20:17:52.763 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces=[applicati
  20:17:52.764 [ts-route-service] 2024-12-07 20:17:52.764 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
All services, 30 seconds either side (sampled):
  20:17:23.281 [ts-auth-service] 2024-12-07 20:17:23.281 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×11)
  20:17:23.515 [ts-travel2-service] 2024-12-07 20:17:23.515 ERROR 1 --- [io-16346-exec-9] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×7)
  20:17:26.824 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:26 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×28)
  20:17:27.217 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:27 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×10)
  20:17:29.352 [ts-travel-service] 2024-12-07 20:17:29.352 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×3)
  20:17:30.910 [ts-station-mongo] {"t":{"$date":"2024-12-07T20:17:30.910+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:31.663 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:17:31.663+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:36.133 [ts-order-service] 2024-12-07 20:17:36.132 INFO 1 --- [io-12031-exec-3] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-4cf1-
  20:17:36.472 [ts-inside-payment-service] 2024-12-07 20:17:36.471 INFO 1 --- [io-18673-exec-6] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.  (×2)
  20:17:38.748 [ts-food-service] 2024-12-07 20:17:38.748 INFO 1 --- [io-18856-exec-5] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  20:17:40.715 [ts-admin-basic-info-service] 2024-12-07 20:17:40.714 INFO 1 --- [o-18767-exec-10] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×2)
  20:17:43.214 [ts-payment-mongo] {"t":{"$date":"2024-12-07T20:17:43.214+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360266
  20:17:46.954 [ts-route-service] 2024-12-07 20:17:46.954 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:24}] to ts-route-
  20:17:51.168 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/v2/api-docs],methods=[GET],produces=[application/json || applic
  20:17:52.759 [ts-route-service] 2024-12-07 20:17:52.759 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/vnd.spring-
  20:17:52.764 [ts-route-service] 2024-12-07 20:17:52.763 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces=[applicati
  20:17:55.260 [ts-route-service] 2024-12-07 20:17:55.260 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  20:18:00.870 [ts-route-service] 2024-12-07 20:18:00.870 INFO 1 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  20:18:03.064 [ts-route-service] 2024-12-07 20:18:03.064 INFO 1 --- [ main] .d.s.w.r.o.CachingOperationNameGenerator : Generating unique operation named: valueUsingGET_1
  20:18:04.554 [ts-route-service] 2024-12-07 20:18:04.554 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: suzhou End: shanghai
  20:18:09.861 [ts-travel-service] 2024-12-07 20:18:09.861 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×10)
  20:18:10.565 [ts-travel2-service] 2024-12-07 20:18:10.564 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×35)
  20:18:11.797 [ts-price-service] 2024-12-07 20:18:11.796 INFO 1 --- [io-16579-exec-4] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×3)
  20:18:11.878 [ts-travel2-service] 2024-12-07 20:18:11.878 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×6)
  20:18:11.927 [ts-seat-service] 2024-12-07 20:18:11.927 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:18:12.013 [ts-seat-service] 2024-12-07 20:18:12.012 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×5)
  20:18:15.187 [ts-order-other-service] 2024-12-07 20:18:15.187 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-
  20:18:21.318 [ts-basic-service] 2024-12-07 20:18:21.318 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×2)
  20:18:22.755 [ts-order-service] 2024-12-07 20:18:22.755 INFO 1 --- [io-12031-exec-5] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00 

## p0721
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-14T15:39:58.596Z
```
{"service":"dbservice2","message":"2021-08-14 15:39:58,596 | ERROR | 0.0.0.2 | dbservice2 | db_helper.py -> sql_ano_prob -> 93 | 5286613583639fb | (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)"}
```
Same service, the 2 minutes before (oldest first):
  15:39:51.968 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×6)
  15:39:51.968 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×6)
  15:39:52.119 [dbservice2] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  15:39:52.913 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  15:39:54.512 [dbservice2] INFO query = select passwards from username_table where user_name='ZadRMLrA'  (×3)
  15:39:54.592 [dbservice2] INFO d0a814f6-fcd2-11eb-b944-0242ac110003-ZadRMLrA-qU=K:N/SjTlv token generate success token=MTYyODkyNjc5NC41OTE5Njg1OmQwYTgxNGY2LWZjZDItMTFlYi1iOTQ0LTAyNDJhYzE
  15:39:56.214 [dbservice2] INFO d19bbd9a-fcd2-11eb-9e9f-0242ac110003-JTPZbGUX-owRC0.<$@!D) token generate success token=MTYyODkyNjc5Ni4yMTM4NTg4OmQxOWJiZDlhLWZjZDItMTFlYi05ZTlmLTAyNDJhYzE
  15:39:56.989 [dbservice2] ERROR password in database of {user} is null, the user is not registered
All services, 30 seconds either side (sampled):
  15:39:28.613 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×44)
  15:39:28.830 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×49)
  15:39:28.957 [dbservice1] INFO query = select passwards from username_table where user_name='PadWlNwG'  (×45)
  15:39:29.291 [webservice1] INFO complete information: {'uuid': 'c1e46a82-fcd2-11eb-b2d8-0242ac110003', 'user_id': 'ERSdWpfg'}  (×47)
  15:39:29.794 [redisservice1] INFO service accept, status_code: 200  (×43)
  15:39:30.245 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×46)
  15:39:30.612 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'c26fde32-fcd2-11eb-89c1-0242ac110004'}  (×46)
  15:39:30.858 [dbservice2] INFO query = select passwards from username_table where user_name='GKtJXRfS'  (×42)
  15:39:33.286 [dbservice1] INFO c3fe45fe-fcd2-11eb-a4b2-0242ac110004-mTjXOuZo-G/o^jX*g(<l9 token generate success token=MTYyODkyNjc3My4yODU1OTg1OmMzZmU0NWZlLWZjZDItMTFlYi1hNGIyLTAyNDJhYzE  (×2)
  15:39:35.326 [mobservice1] INFO info c56e7bc0-fcd2-11eb-a973-0242ac110004:QghyctJY write success
  15:39:37.510 [dbservice1] INFO c673a8ec-fcd2-11eb-ae4d-0242ac110003-mVtTqAor-@bx5fml._>_I token generate success token=MTYyODkyNjc3Ny41MDk4MzA3OmM2NzNhOGVjLWZjZDItMTFlYi1hZTRkLTAyNDJhYzE
  15:39:40.027 [dbservice1] INFO c7ec35a4-fcd2-11eb-a0f2-0242ac110003-ZvJLFkob-F)N_C?>R{@=O token generate success token=MTYyODkyNjc4MC4wMjcyMjQzOmM3ZWMzNWE0LWZjZDItMTFlYi1hMGYyLTAyNDJhYzE
  15:39:42.479 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  15:39:45.329 [mobservice2] INFO info cb5c4418-fcd2-11eb-b6d3-0242ac110003:glaSXZGO write success
  15:39:48.103 [dbservice2] INFO ccd58c1e-fcd2-11eb-b084-0242ac110004-dFRVcSCY-l=sf9C-mUi?> token generate success token=MTYyODkyNjc4OC4xMDMwMjg6Y2NkNThjMWUtZmNkMi0xMWViLWIwODQtMDI0MmFjMTE
  15:39:50.673 [mobservice2] INFO info ce832a62-fcd2-11eb-9fb3-0242ac110003:OVhMJowB write success
  15:39:52.913 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  15:39:55.402 [dbservice1] INFO d11ead28-fcd2-11eb-9bb9-0242ac110003-xomaJMly-EYTm8(4?5G7B token generate success token=MTYyODkyNjc5NS40MDE5ODE6ZDExZWFkMjgtZmNkMi0xMWViLTliYjktMDI0MmFjMTE
  15:39:57.747 [dbservice1] INFO d28d37f6-fcd2-11eb-a81b-0242ac110003-GNrVKoRp-0-vCU}g!.qKN token generate success token=MTYyODkyNjc5Ny43NDcyOTM3OmQyOGQzN2Y2LWZjZDItMTFlYi1hODFiLTAyNDJhYzE
  15:40:00.613 [mobservice1] INFO info d479a40a-fcd2-11eb-afd1-0242ac110004:cvBGfCKh write success
  15:40:03.177 [mobservice1] INFO info d5f816b8-fcd2-11eb-add4-0242ac110003:mGjRECnP write success
  15:40:05.838 [dbservice2] INFO d74ebfc6-fcd2-11eb-bca2-0242ac110003-TKNpsvwU--BNr6&D1Xzn5 token generate success token=MTYyODkyNjgwNS44MzgxMzA1OmQ3NGViZmM2LWZjZDItMTFlYi1iY2EyLTAyNDJhYzE
  15:40:08.536 [dbservice2] INFO d8ead5ae-fcd2-11eb-b7e5-0242ac110003-iuYCeOZW-p{tZFI_a$DRk token generate success token=MTYyODkyNjgwOC41MzYzOTY1OmQ4ZWFkNWFlLWZjZDItMTFlYi1iN2U1LTAyNDJhYzE
  15:40:11.283 [mobservice2] INFO info dacaaf16-fcd2-11eb-a550-0242ac110003:gKPfDFAT write success
  15:40:13.935 [mobservice2] INFO info dc6aa13c-fcd2-11eb-becd-0242ac110004:piekgYwo write success
  15:40:16.691 [mobservice2] INFO info de064f0a-fcd2-11eb-8613-0242ac110003:NFBuWbaS write success
  15:40:19.303 [dbservice1] INFO df5102f6-fcd2-11eb-856c-0242ac110003-ISmxpnEs--5/4Hwoa@2dU token generate success token=MTYyODkyNjgxOS4zMDM0MzM6ZGY1MTAyZjYtZmNkMi0xMWViLTg1NmMtMDI0MmFjMTE
  15:40:22.027 [dbservice2] INFO e0f507b0-fcd2-11eb-8ce2-0242ac110004-jnAxEKot-^>lh?1b+3#G* token generate success token=MTYyODkyNjgyMi4wMjY3MTM0OmUwZjUwN2IwLWZjZDItMTFlYi04Y2UyLTAyNDJhYzE
  15:40:24.558 [dbservice1] INFO e2793e4e-fcd2-11eb-856e-0242ac110003-tBDHvTdf--r!uKC9qw1f: token generate success token=MTYyODkyNjgyNC41NTgzMDM6ZTI3OTNlNGUtZmNkMi0xMWViLTg1NmUtMDI0MmFjMTE
  15:40:27.208 [dbservice2] INFO e408e476-fcd2-11eb-ae0f-0242ac110003-aRNnXZPl-Eq0%L#J(4Boe token generate success token=MTYyODkyNjgyNy4yMDgwMTY2OmU0MDhlNDc2LWZjZDItMTFlYi1hZTBmLTAyNDJhYzE

## p0003
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T00:58:54.757Z
```
{"service":"dbservice1","message":"2021-08-13 00:58:54,757 | ERROR | 0.0.0.4 | dbservice1 | db_helper.py -> sql_ano_prob -> 92 | 94427191c953bdee | (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)"}
```
Same service, the 2 minutes before (oldest first):
  00:58:49.601 [dbservice1] INFO query = select passwards from username_table where user_name='gZxMbovT'  (×5)
  00:58:49.677 [dbservice1] INFO 9023ea26-fb8e-11eb-b9bb-0242ac110003-gZxMbovT-6)_=b$i/Ye}A token generate success token=MTYyODc4NzUyOS42NzcyODE0OjkwMjNlYTI2LWZiOGUtMTFlYi1iOWJiLTAyNDJhYzE
  00:58:51.303 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  00:58:51.303 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  00:58:51.396 [dbservice1] INFO 914cea38-fb8e-11eb-83f7-0242ac110003-EVBLhgrm-9os/__E:hq47 token generate success token=MTYyODc4NzUzMS4zOTYzMjc3OjkxNGNlYTM4LWZiOGUtMTFlYi04M2Y3LTAyNDJhYzE
  00:58:52.190 [dbservice1] INFO 91ccf782-fb8e-11eb-87e4-0242ac110003-rapsGDTF-+o8Wb{j4#H@n token generate success token=MTYyODc4NzUzMi4xOTAwMjk2OjkxY2NmNzgyLWZiOGUtMTFlYi04N2U0LTAyNDJhYzE
  00:58:52.715 [dbservice1] INFO 921370e0-fb8e-11eb-9344-0242ac110004-YDlFxnqQ-iMP+NGt?ac=y token generate success token=MTYyODc4NzUzMi43MTU1MTYzOjkyMTM3MGUwLWZiOGUtMTFlYi05MzQ0LTAyNDJhYzE
  00:58:53.079 [dbservice1] INFO 92472bc4-fb8e-11eb-8c3d-0242ac110004-AkMRXwoH-{X3w%&jNaR_s token generate success token=MTYyODc4NzUzMy4wNzg5ODU3OjkyNDcyYmM0LWZiOGUtMTFlYi04YzNkLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  00:58:24.777 [redisservice1] INFO redis write success  (×89)
  00:58:25.005 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×40)
  00:58:25.192 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '81d68e38-fb8e-11eb-a626-0242ac110004', 'user_id': 'PNmIMWHV'}  (×83)
  00:58:25.349 [redisservice1] INFO service accept, status_code: 200  (×37)
  00:58:25.712 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×44)
  00:58:25.965 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  00:58:26.302 [dbservice2] INFO 8251ca6c-fb8e-11eb-babc-0242ac110003-AmhGSJRK-dWueNw!<8>i6 token generate success token=MTYyODc4NzUwNi4zMDE3MzM3OjgyNTFjYTZjLWZiOGUtMTFlYi1iYWJjLTAyNDJhYzE
  00:58:26.907 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×45)
  00:58:29.563 [webservice1] ERROR an error occurred in the downstream service  (×5)
  00:58:37.647 [mobservice2] INFO info 8957cfbe-fb8e-11eb-b8a5-0242ac110003:pXfjsTOr write success
  00:58:39.984 [dbservice2] INFO 8a80ea1a-fb8e-11eb-b5fc-0242ac110003-IKAZGYCc-njNx6uZ3V<P_ token generate success token=MTYyODc4NzUxOS45ODQxOTo4YTgwZWExYS1mYjhlLTExZWItYjVmYy0wMjQyYWMxMTA
  00:58:42.886 [dbservice2] INFO 8c3a4aa4-fb8e-11eb-b821-0242ac110004-JUlvPnIe-31q#+(J%zy_> token generate success token=MTYyODc4NzUyMi44ODYwNDEyOjhjM2E0YWE0LWZiOGUtMTFlYi1iODIxLTAyNDJhYzE
  00:58:45.400 [webservice2] ERROR an error occurred in the downstream service  (×2)
  00:58:47.554 [mobservice1] INFO info 8f3f8e80-fb8e-11eb-8324-0242ac110003:yWbZXEez write success
  00:58:50.170 [mobservice2] INFO info 90c792d4-fb8e-11eb-be8b-0242ac110004:CfHjswnr write success
  00:58:52.715 [dbservice1] INFO 921370e0-fb8e-11eb-9344-0242ac110004-YDlFxnqQ-iMP+NGt?ac=y token generate success token=MTYyODc4NzUzMi43MTU1MTYzOjkyMTM3MGUwLWZiOGUtMTFlYi05MzQ0LTAyNDJhYzE
  00:58:57.042 [mobservice2] INFO info 94e6e32e-fb8e-11eb-aaa9-0242ac110003:zepqgvua write success
  00:58:59.539 [mobservice2] INFO info 96601a04-fb8e-11eb-ab3b-0242ac110004:FHDROgPs write success
  00:59:02.200 [mobservice1] INFO info 97fb46ea-fb8e-11eb-92db-0242ac110003:AZDazHog write success
  00:59:04.719 [mobservice2] INFO info 99764fa6-fb8e-11eb-8b80-0242ac110004:rsGCqSOE write success
  00:59:07.607 [dbservice1] INFO 9aeaaf8a-fb8e-11eb-91dd-0242ac110004-HodXCbQS--LKmMs#j<Ed2 token generate success token=MTYyODc4NzU0Ny42MDY4NTU5OjlhZWFhZjhhLWZiOGUtMTFlYi05MWRkLTAyNDJhYzE
  00:59:09.971 [dbservice1] INFO 9c5708d2-fb8e-11eb-8db9-0242ac110004-JKhDNmCb-yMn!G#EL?u18 token generate success token=MTYyODc4NzU0OS45NzEyNzE1OjljNTcwOGQyLWZiOGUtMTFlYi04ZGI5LTAyNDJhYzE
  00:59:12.759 [mobservice1] INFO info 9e43efb6-fb8e-11eb-a328-0242ac110003:LMSlzvKp write success
  00:59:15.726 [dbservice1] INFO 9fc554f6-fb8e-11eb-b907-0242ac110004-AMFryZUz-jrK#m*:OpaoS token generate success token=MTYyODc4NzU1NS43MjYzNzM6OWZjNTU0ZjYtZmI4ZS0xMWViLWI5MDctMDI0MmFjMTE
  00:59:18.147 [mobservice1] INFO info a17ed038-fb8e-11eb-b4b0-0242ac110003:CMzFsYZh write success
  00:59:20.832 [mobservice1] INFO info a31a5458-fb8e-11eb-a9d8-0242ac110003:YTchXgsi write success
  00:59:23.384 [mobservice1] INFO info a4947958-fb8e-11eb-a504-0242ac110004:LmHpecgO write success

## p0269
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:17.880Z
```
{"timestamp":1732242497880929000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"{ id: '673fec41b0df5c00019af98c' }"}
```
Same service, the 2 minutes before (oldest first):
  02:28:17.014 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec38b0df5c00019af971"}
  02:28:17.022 [front-end] POST /addresses 200 - ms - -
  02:28:17.028 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec38b0df5c00019af971"}
  02:28:17.035 [front-end] POST /cards 200 - ms - -
  02:28:17.084 [front-end] Attempting to delete cart for user: 673fec38b0df5c00019af971
  02:28:17.339 [front-end] GET /catalogue 200 - ms - -  (×2)
  02:28:17.369 [front-end] Request received with body: {}
  02:28:17.377 [front-end] Received response: "{\"firstName\":\"vtFUiCYPGkr\",\"lastName\":\"vtFUiCYPGkr\",\"username\":\"vtFUiCYPGkr\",\"id\":\"673fec2bb0df5c00019af944\",\"_links\":{\"a
  02:28:17.377 [front-end] GET Request to: http://user/customers/673fec2bb0df5c00019af944/addresses  (×2)
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec33b0df5c00019af961\",\"_links\":{\"
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:17.383 [front-end] [ undefined, undefined ]
  02:28:17.383 [front-end] Posting Order: {"customer":"http://user/customers/673fec2bb0df5c00019af944","address":"http://user/addresses/673fec33b0df5c00019af960","card":"http://user/cards
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:17.558 [front-end] { id: '673fec41b0df5c00019af98b' }
  02:28:17.558 [front-end] 673fec41b0df5c00019af98b
  02:28:17.558 [front-end] Merging carts for customer id: 673fec41b0df5c00019af98b and session id: DJgh-aP7GXWW3SFEl2AnBT8Zgj4ojU2q
  02:28:17.875 [front-end] Posting Customer: {"username":"QGHrdp","password":"lxLAJGrqCj","email":"QGHrdp@gmail.com","firstName":"QGHrdp","lastName":"QGHrdp"}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×44)
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -  (×44)
  02:28:03.203 [front-end] [ undefined, undefined ]  (×45)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×3)
  02:28:07.445 [orders] 2024-11-22 02:28:07.445 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
  02:28:10.277 [front-end] Posting Customer: {"username":"opFqwUnVow","password":"habyXFSF","email":"opFqwUnVow@gmail.com","firstName":"opFqwUnVow","lastName":"opFqwUnVow"}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
  02:28:23.301 [front-end] Received response: "{\"firstName\":\"HFHBXn\",\"lastName\":\"HFHBXn\",\"username\":\"HFHBXn\",\"id\":\"673fec34b0df5c00019af967\",\"_links\":{\"addresses\":{\"h
  02:28:24.999 [rabbitmq] 
  02:28:25.743 [carts] 2024-11-22 02:28:25.743 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×13)
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39d0","customerId":"673fec31b0df5c00019af95b","customer":{"id":null,"firstName":"bCCZHBaYc","lastName":"bCCZHBaYc","u
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×51)
  02:28:37.548 [user] ts=2024-11-22T02:28:37.548591Z caller=middlewares.go:46 method=Register username=OeZpiPZUn email=OeZpiPZUn@gmail.com took=1.009704ms
  02:28:40.321 [front-end] Order response: {"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR","lastName":"nbZCdAQyR","u
  02:28:42.162 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732242522152,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde
  02:28:44.338 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec5cd94b9000069b39e2","customerId":"673fec3ab0df5c00019af974","customer":{"id":null,"firstName":"opFqwUnVow"
  02:28:45.405 [front-end] Posting Customer: {"username":"crSMtAKNWrXaJJx","password":"TlwWXSanSW","email":"crSMtAKNWrXaJJx@gmail.com","firstName":"crSMtAKNWrXaJJx","lastName":"crSMtAKNWr
  02:28:47.575 [front-end] Received response: "{\"firstName\":\"QGHrdp\",\"lastName\":\"QGHrdp\",\"username\":\"QGHrdp\",\"id\":\"673fec41b0df5c00019af98c\",\"_links\":{\"addresses\":{\"h

## p0825
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-08T12:13:29.572Z
```
{"timestamp":1733660009572246000,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-4lplk","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:13:29.572  INFO 1 --- [           main] o.s.b.a.e.mvc.EndpointHandlerMapping     : Mapped \"{[/heapdump || /heapdump.json],methods=[GET],produces=[application/octet-stream]}\" onto public void org.springframework.boot.actuate.endpoint.mvc.HeapdumpMvcEndpoint.invoke(boolean,javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse) throws java.io.IOException,javax.ser…"}
```
Same service, the 2 minutes before (oldest first):
  12:13:20.772 [ts-route-service] 2024-12-08 12:13:20.772 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  12:13:23.262 [ts-route-service] 2024-12-08 12:13:23.261 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-route-mongo:27017], mode=MULTIPLE, requiredClus
  12:13:23.262 [ts-route-service] 2024-12-08 12:13:23.261 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-route-mongo:27017 to client view of cluster
  12:13:23.871 [ts-route-service] 2024-12-08 12:13:23.871 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:47}] to ts-route-
  12:13:23.876 [ts-route-service] 2024-12-08 12:13:23.876 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip
  12:13:23.956 [ts-route-service] 2024-12-08 12:13:23.954 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  12:13:27.965 [ts-route-service] 2024-12-08 12:13:27.964 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{routeId}],methods=[DELETE]}" onto p
  12:13:27.966 [ts-route-service] 2024-12-08 12:13:27.966 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{startId}/{terminalId}],methods=[GET
  12:13:27.966 [ts-route-service] 2024-12-08 12:13:27.966 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes],methods=[POST]}" onto public org.sp
  12:13:27.966 [ts-route-service] 2024-12-08 12:13:27.966 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{routeId}],methods=[GET]}" onto publ
  12:13:27.966 [ts-route-service] 2024-12-08 12:13:27.966 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes],methods=[GET]}" onto public org.spr
  12:13:27.966 [ts-route-service] 2024-12-08 12:13:27.966 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/welcome],methods=[GET]}" onto public java.l
  12:13:27.967 [ts-route-service] 2024-12-08 12:13:27.967 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/v2/api-docs],methods=[GET],produces=[application/json || applic
  12:13:27.968 [ts-route-service] 2024-12-08 12:13:27.968 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/configuration/ui]}" onto org.springframework.http.ResponseEntit
  12:13:27.969 [ts-route-service] 2024-12-08 12:13:27.969 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/swagger-resources]}" onto org.springframework.http.ResponseEnti
  12:13:27.970 [ts-route-service] 2024-12-08 12:13:27.969 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/configuration/security]}" onto org.springframework.http.Respons
  12:13:27.971 [ts-route-service] 2024-12-08 12:13:27.971 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  12:13:27.972 [ts-route-service] 2024-12-08 12:13:27.971 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  12:13:29.571 [ts-route-service] 2024-12-08 12:13:29.571 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/vnd.spring-boot.
  12:13:29.571 [ts-route-service] 2024-12-08 12:13:29.571 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/vnd.spring-bo
All services, 30 seconds either side (sampled):
  12:13:00.315 [ts-auth-service] 2024-12-08 12:13:00.315 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×11)
  12:13:00.541 [ts-travel2-service] 2024-12-08 12:13:00.540 ERROR 1 --- [io-16346-exec-8] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×11)
  12:13:01.961 [ts-route-service] 2024-12-08 12:13:01.960 INFO 1 --- [ main] ationConfigEmbeddedWebApplicationContext : Refreshing org.springframework.boot.context.embedded.AnnotationConfigEmbed
  12:13:02.554 [ts-food-service] 2024-12-08 12:13:02.554 INFO 1 --- [io-18856-exec-2] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×4)
  12:13:02.597 [ts-food-service] org.springframework.web.client.HttpServerErrorException: 500 Internal Server Error at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Def  (×4)
  12:13:09.579 [ts-auth-service] 2024-12-08 12:13:09.579 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×10)
  12:13:11.478 [ts-train-mongo] {"t":{"$date":"2024-12-08T12:13:11.478+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365999
  12:13:12.038 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-08T12:13:12.037+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365999
  12:13:12.970 [ts-route-service] 2024-12-08 12:13:12.970 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'taskScheduler' has been explicitly defined. Therefore, a de
  12:13:14.467 [ts-route-service] 2024-12-08 12:13:14.467 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.configuration.ObjectP
  12:13:15.075 [ts-route-service] 2024-12-08 12:13:15.075 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact
  12:13:20.762 [ts-route-service] 2024-12-08 12:13:20.760 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricsFilter' to: [/*]  (×8)
  12:13:23.956 [ts-route-service] 2024-12-08 12:13:23.954 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  12:13:27.969 [ts-route-service] 2024-12-08 12:13:27.969 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/swagger-resources]}" onto org.springframework.http.ResponseEnti
  12:13:29.575 [ts-route-service] 2024-12-08 12:13:29.574 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  12:13:29.655 [ts-route-service] 2024-12-08 12:13:29.655 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces=[applicati
  12:13:32.468 [ts-route-service] 2024-12-08 12:13:32.467 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.boot.actuate.autoconfigure.Manageme
  12:13:36.936 [ts-order-other-service] 2024-12-08 12:13:36.936 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Get Order By Id] Order Id: 7e9097ab-1df1-4163
  12:13:37.958 [ts-route-service] 2024-12-08 12:13:37.958 INFO 1 --- [ main] d.s.w.p.DocumentationPluginsBootstrapper : Context refreshed
  12:13:40.658 [ts-route-service] 2024-12-08 12:13:40.658 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: nanjing End: beijing
  12:13:41.242 [ts-consign-service] 2024-12-08 12:13:41.242 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : Order ID is :a9ba52a3-3bfc-4ebd-92e2-f200386fee79
  12:13:44.101 [ts-auth-service] 2024-12-08 12:13:44.101 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  12:13:53.959 [ts-travel-service] 2024-12-08 12:13:53.959 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×3)
  12:13:54.378 [ts-admin-travel-service] 2024-12-08 12:13:54.378 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)
  12:13:59.116 [ts-price-service] 2024-12-08 12:13:59.115 INFO 1 --- [io-16579-exec-5] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: 0b23bd3e-876a-4af3-b92
  12:13:59.154 [ts-travel2-service] 2024-12-08 12:13:59.154 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  12:13:59.257 [ts-seat-service] 2024-12-08 12:13:59.257 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)

## p0788
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T20:38:06.524Z
```
{"timestamp":1732394286524582700,"container_name":"front-end","pod_name":"front-end-f77549869-gbrgw","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"Merging carts for customer id: 67423d2e48485600016b4a31 and session id: cHWjvkqXep-lu0mgSIbaZIZflZI5mruA"}
```
Same service, the 2 minutes before (oldest first):
  20:38:06.073 [front-end] GET Request to: http://user/customers/67423d1948485600016b49f3/addresses  (×2)
  20:38:06.075 [front-end] Posting Customer: {"username":"whPbcOnsZxCUV","password":"FzIDJGmrk","email":"whPbcOnsZxCUV@gmail.com","firstName":"whPbcOnsZxCUV","lastName":"whPbcOnsZxCUV"}
  20:38:06.085 [front-end] { id: '67423d2e48485600016b4a30' }  (×2)
  20:38:06.085 [front-end] 67423d2e48485600016b4a30  (×2)
  20:38:06.085 [front-end] Merging carts for customer id: 67423d2e48485600016b4a30 and session id: L8-6c8rH5ecQRBb9tylzYuAvO08DPOLs
  20:38:06.090 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67423
  20:38:06.090 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67423d1f48485600016b4a06\",\"_links\":{\"
  20:38:06.090 [front-end] [ undefined, undefined ]
  20:38:06.090 [front-end] Posting Order: {"customer":"http://user/customers/67423d1948485600016b49f3","address":"http://user/addresses/67423d1f48485600016b4a05","card":"http://user/cards
  20:38:06.107 [front-end] Carts merged.
  20:38:06.107 [front-end] set cookie67423d2e48485600016b4a30
  20:38:06.107 [front-end] Sent cookies.
  20:38:06.108 [front-end] POST /register 200 31.754 ms - 33
  20:38:06.125 [front-end] Order response: {"statusCode":201,"body":{"id":"67423d2e4ca85a00070c6106","customerId":"67423d1948485600016b49f3","customer":{"id":null,"firstName":"fxONFRFOpHz
  20:38:06.125 [front-end] Order response: {"id":"67423d2e4ca85a00070c6106","customerId":"67423d1948485600016b49f3","customer":{"id":null,"firstName":"fxONFRFOpHzroKD","lastName":"fxONFRF
  20:38:06.126 [front-end] POST /orders 201 - ms - -
  20:38:06.515 [front-end] Posting Customer: {"username":"YhgeF","password":"OPsTI","email":"YhgeF@gmail.com","firstName":"YhgeF","lastName":"YhgeF"}
All services, 30 seconds either side (sampled):
  20:37:36.851 [front-end] Request received with body: {}  (×60)
  20:37:36.904 [payment] ts=2024-11-23T20:37:36Z caller=logging.go:29 method=Authorise result=false took=8.397µs  (×12)
  20:37:37.141 [front-end] 67423d1148485600016b49dc  (×62)
  20:37:37.536 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67423d0948485600016b49c6"}  (×58)
  20:37:37.651 [carts] 2024-11-23 20:37:37.651 INFO [carts,635e96fe5e388758,a3da50a38ce52fcb,false] 6 --- [p-nio-80-exec-8] w.w.s.cart.controllers.ItemsController : Did not find item.  (×37)
  20:37:38.307 [queue-master] 2024-11-23 20:37:38.307 INFO 7 --- [pool-6-thread-7] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×18)
  20:37:39.792 [front-end] Posting Customer: {"username":"EYTbZTBHrEu","password":"upURQm","email":"EYTbZTBHrEu@gmail.com","firstName":"EYTbZTBHrEu","lastName":"EYTbZTBHrEu"}
  20:37:42.262 [front-end] Received response: "{\"firstName\":\"KdlQaWaiAtwGK\",\"lastName\":\"KdlQaWaiAtwGK\",\"username\":\"KdlQaWaiAtwGK\",\"id\":\"67423d0048485600016b49aa\",\"_links\
  20:37:43.002 [front-end] Posting Customer: {"username":"XFqRxx","password":"KlcWxAHz","email":"XFqRxx@gmail.com","firstName":"XFqRxx","lastName":"XFqRxx"}
  20:37:45.848 [front-end] Posting Customer: {"username":"fxONFRFOpHzroKD","password":"tYDGBAG","email":"fxONFRFOpHzroKD@gmail.com","firstName":"fxONFRFOpHzroKD","lastName":"fxONFRFOpHzro
  20:37:48.189 [front-end] Order response: {"statusCode":201,"body":{"id":"67423d1c4ca85a00070c60f7","customerId":"67423d0348485600016b49b8","customer":{"id":null,"firstName":"FmqQaRnE","
  20:37:52.739 [front-end] Order response: {"id":"67423d204ca85a00070c60f9","customerId":"67423d0948485600016b49c6","customer":{"id":null,"firstName":"NAvExXh","lastName":"NAvExXh","usern
  20:37:54.643 [user] ts=2024-11-23T20:37:54.643261952Z caller=middlewares.go:46 method=Register username=mlzzhjS email=mlzzhjS@gmail.com took=5.199331ms
  20:37:58.010 [front-end] Received response: "{\"firstName\":\"EYTbZTBHrEu\",\"lastName\":\"EYTbZTBHrEu\",\"username\":\"EYTbZTBHrEu\",\"id\":\"67423d1348485600016b49e2\",\"_links\":{\"a
  20:38:00.442 [front-end] Order response: {"statusCode":201,"body":{"id":"67423d284ca85a00070c6100","customerId":"67423d1148485600016b49dc","customer":{"id":null,"firstName":"NWGwcceKV",
  20:38:02.052 [front-end] Posting Customer: {"username":"tZkcLNYTwzLPN","password":"gasQtxFskQ","email":"tZkcLNYTwzLPN@gmail.com","firstName":"tZkcLNYTwzLPN","lastName":"tZkcLNYTwzLPN"}
  20:38:04.413 [front-end] Order response: {"id":"67423d2c4ca85a00070c6105","customerId":"67423d1348485600016b49e1","customer":{"id":null,"firstName":"YZCfKqQiceCg","lastName":"YZCfKqQice
  20:38:06.523 [user] ts=2024-11-23T20:38:06.523584796Z caller=middlewares.go:46 method=Register username=YhgeF email=YhgeF@gmail.com took=4.955515ms
  20:38:08.341 [front-end] Order response: {"id":"67423d304ca85a00070c6109","customerId":"67423d1848485600016b49f0","customer":{"id":null,"firstName":"MuYCREweCjSR","lastName":"MuYCREweCj
  20:38:11.627 [user] ts=2024-11-23T20:38:11.62759714Z caller=middlewares.go:46 method=Register username=EyuJmZcaj email=EyuJmZcaj@gmail.com took=3.966089ms
  20:38:13.922 [front-end] Order response: {"statusCode":201,"body":{"id":"67423d354ca85a00070c610e","customerId":"67423d1b48485600016b49f9","customer":{"id":null,"firstName":"MDDiDDY","l
  20:38:15.903 [front-end] Order response: {"statusCode":201,"body":{"id":"67423d374ca85a00070c6110","customerId":"67423d2248485600016b4a11","customer":{"id":null,"firstName":"mlzzhjS","l
  20:38:17.014 [front-end] Received response: "{\"firstName\":\"iLZuqkEWDh\",\"lastName\":\"iLZuqkEWDh\",\"username\":\"iLZuqkEWDh\",\"id\":\"67423d2a48485600016b4a2c\",\"_links\":{\"addr
  20:38:18.824 [front-end] Order response: {"statusCode":201,"body":{"id":"67423d3a4ca85a00070c6115","customerId":"67423d2748485600016b4a21","customer":{"id":null,"firstName":"xwoktcfHJqI
  20:38:25.589 [front-end] Posting Customer: {"username":"brOmiEW","password":"WLTpv","email":"brOmiEW@gmail.com","firstName":"brOmiEW","lastName":"brOmiEW"}
  20:38:26.779 [front-end] Order response: {"id":"67423d424ca85a00070c6119","customerId":"67423d2748485600016b4a20","customer":{"id":null,"firstName":"AfQsHpQEgCBi","lastName":"AfQsHpQEgC
  20:38:29.969 [front-end] Order response: {"id":"67423d454ca85a00070c611a","customerId":"67423d2d48485600016b4a2e","customer":{"id":null,"firstName":"trmpDC","lastName":"trmpDC","usernam
  20:38:32.657 [front-end] Posting Customer: {"username":"TkqPdv","password":"oNRKkQSW","email":"TkqPdv@gmail.com","firstName":"TkqPdv","lastName":"TkqPdv"}
  20:38:34.115 [front-end] Received response: "{\"firstName\":\"QpVCw\",\"lastName\":\"QpVCw\",\"username\":\"QpVCw\",\"id\":\"67423d3748485600016b4a53\",\"_links\":{\"addresses\":{\"href
