## p0700
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-12T20:02:55.502Z
```
{"service":"webservice1","message":"2021-08-12 20:02:55,502 | INFO | 0.0.0.1 | 172.17.0.3 | webservice1 | 2d9182855d3b0562 | now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  20:02:51.851 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  20:02:51.851 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '3838d598-fb65-11eb-a96a-0242ac110003', 'value': '', 'ex': 10}  (×4)
  20:02:51.903 [webservice1] INFO uuid: 3838d598-fb65-11eb-a96a-0242ac110003 write redis successfully  (×4)
  20:02:51.970 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  20:02:52.005 [webservice1] ERROR get a error [Errno 2] No such file or directory: 'resources/source_file/source_file.csv'  (×4)
All services, 30 seconds either side (sampled):
  20:02:27.539 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×56)
  20:02:27.745 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×55)
  20:02:27.856 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '29bb76ba-fb65-11eb-aabb-0242ac110004', 'value': 'jDuLxAwt'}  (×22)
  20:02:28.040 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×34)
  20:02:28.140 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×28)
  20:02:30.767 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×54)
  20:02:30.947 [redisservice1] INFO redis write success  (×76)
  20:02:31.116 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×20)
  20:02:31.227 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '2bc50610-fb65-11eb-8982-0242ac110004'}  (×32)
  20:02:31.681 [dbservice2] INFO 2bc50610-fb65-11eb-8982-0242ac110004-edQqtaui-Nyq_U<Q^_uRZ token generate success token=MTYyODc2OTc1MS42ODA4NDc6MmJjNTA2MTAtZmI2NS0xMWViLTg5ODItMDI0MmFjMTE
  20:02:33.758 [mobservice1] INFO info 2d3af1c6-fb65-11eb-b276-0242ac110004:frspTAey write success
  20:02:36.328 [mobservice1] INFO info 2ec4dc64-fb65-11eb-b3e1-0242ac110004:VvLhTogZ write success
  20:02:37.876 [mobservice1] INFO info 2fab39de-fb65-11eb-ac11-0242ac110004:aZMCtwXA write success
  20:02:39.850 [dbservice1] INFO 309063ce-fb65-11eb-99ed-0242ac110004-HfPCXKQO-ko9a.361RV:P token generate success token=MTYyODc2OTc1OS44NTA0MDc6MzA5MDYzY2UtZmI2NS0xMWViLTk5ZWQtMDI0MmFjMTE
  20:02:43.060 [dbservice1] INFO 329e92ee-fb65-11eb-b13d-0242ac110004-dneSsIED-8P7mNRZk<p&e token generate success token=MTYyODc2OTc2My4wNTk4NzYyOjMyOWU5MmVlLWZiNjUtMTFlYi1iMTNkLTAyNDJhYzE
  20:02:44.884 [dbservice1] INFO 33b247d4-fb65-11eb-9e86-0242ac110004-JHvRWiIh-03FsPx=C681p token generate success token=MTYyODc2OTc2NC44ODQwODY2OjMzYjI0N2Q0LWZiNjUtMTFlYi05ZTg2LTAyNDJhYzE  (×2)
  20:02:47.446 [mobservice1] INFO info 356729c8-fb65-11eb-bc23-0242ac110004:IhzyCpmU write success
  20:02:49.919 [dbservice1] INFO 3689bd84-fb65-11eb-9c22-0242ac110004-kWcbAndl-+K)#TtAh_eL$ token generate success token=MTYyODc2OTc2OS45MTk1NjI4OjM2ODliZDg0LWZiNjUtMTFlYi05YzIyLTAyNDJhYzE
  20:02:52.963 [dbservice2] INFO 388a06e8-fb65-11eb-8baf-0242ac110004-hpcKRNdx-E5o4m%SA(zhR token generate success token=MTYyODc2OTc3Mi45NjI3NDQ3OjM4OGEwNmU4LWZiNjUtMTFlYi04YmFmLTAyNDJhYzE
  20:02:54.714 [dbservice2] INFO 398988b6-fb65-11eb-bbe6-0242ac110004-aolWDIFH-Z(_kMcNp^guh token generate success token=MTYyODc2OTc3NC43MTQ0MzM0OjM5ODk4OGI2LWZiNjUtMTFlYi1iYmU2LTAyNDJhYzE
  20:02:57.969 [dbservice1] INFO 3b7e9b8e-fb65-11eb-9a58-0242ac110004-qwpdAUNi-j-s(4p$@1:Fo token generate success token=MTYyODc2OTc3Ny45NjkyNzIxOjNiN2U5YjhlLWZiNjUtMTFlYi05YTU4LTAyNDJhYzE
  20:03:00.068 [dbservice2] INFO 3ca4d960-fb65-11eb-a14c-0242ac110004-aILTSXwD-f&zLjS!6@gY{ token generate success token=MTYyODc2OTc4MC4wNjgzODE1OjNjYTRkOTYwLWZiNjUtMTFlYi1hMTRjLTAyNDJhYzE
  20:03:02.623 [dbservice1] INFO 3e31b654-fb65-11eb-b773-0242ac110004-GsgASzin-v47{KN&<nj-h token generate success token=MTYyODc2OTc4Mi42MjMyNzM2OjNlMzFiNjU0LWZiNjUtMTFlYi1iNzczLTAyNDJhYzE
  20:03:05.124 [mobservice2] INFO info 3fde602e-fb65-11eb-b4e6-0242ac110004:JvrVBhsk write success
  20:03:07.773 [mobservice2] INFO info 417fdbc4-fb65-11eb-a427-0242ac110004:guYIhUdp write success
  20:03:11.561 [dbservice2] INFO 439cca84-fb65-11eb-a230-0242ac110004-pvNdAbhE-_lLqsG{hr5MT token generate success token=MTYyODc2OTc5MS41NjEwMjIzOjQzOWNjYTg0LWZiNjUtMTFlYi1hMjMwLTAyNDJhYzE
  20:03:24.086 [redisservice1] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400

## p0315
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:20:33.924Z
```
{"timestamp":1732245633924187100,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:20:33.923926201Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff87bb0df5c00019b1efc took=1.872085ms"}
```
Same service, the 2 minutes before (oldest first):
  03:20:32.750 [user] ts=2024-11-22T03:20:32.75034249Z caller=middlewares.go:75 method=GetUsers id=673ff86eb0df5c00019b1ed1 result=1 took=927.516µs  (×8)
  03:20:32.766 [user] ts=2024-11-22T03:20:32.766787601Z caller=middlewares.go:104 method=GetAddresses id=673ff873b0df5c00019b1ee3 result=1 took=867.176µs  (×2)
  03:20:32.767 [user] ts=2024-11-22T03:20:32.76714134Z caller=middlewares.go:134 method=GetCards id=673ff873b0df5c00019b1ee4 result=1 took=875.909µs  (×2)
  03:20:33.094 [user] ts=2024-11-22T03:20:33.094037776Z caller=middlewares.go:157 method=Health result=2 took=808.783µs  (×2)
  03:20:33.167 [user] ts=2024-11-22T03:20:33.16718284Z caller=middlewares.go:75 method=GetUsers id=673ff869b0df5c00019b1ebe result=1 took=2.426629ms  (×4)
  03:20:33.193 [user] ts=2024-11-22T03:20:33.19372525Z caller=middlewares.go:104 method=GetAddresses id=673ff872b0df5c00019b1ee1 result=1 took=3.113712ms
  03:20:33.195 [user] ts=2024-11-22T03:20:33.194647649Z caller=middlewares.go:134 method=GetCards id=673ff872b0df5c00019b1ee2 result=1 took=1.600841ms
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×34)
  03:20:06.550 [user] ts=2024-11-22T03:20:06.549939822Z caller=middlewares.go:104 method=GetAddresses id=673ff854b0df5c00019b1e7e result=1 took=839.732µs  (×30)
  03:20:06.660 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff861b0df5c00019b1e9e"}  (×60)
  03:20:06.803 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×10)
  03:20:08.182 [front-end] GET /catalogue 200 - ms - -  (×54)
  03:20:08.498 [front-end] Sent cookies.  (×59)
  03:20:09.192 [carts] 2024-11-22 03:20:09.192 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  03:20:11.559 [user] ts=2024-11-22T03:20:11.558844653Z caller=middlewares.go:46 method=Register username=xQhxkcD email=xQhxkcD@gmail.com took=1.123618ms
  03:20:14.697 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×6)
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:21.876 [front-end] Received response: "{\"firstName\":\"GSlyQdwsNkS\",\"lastName\":\"GSlyQdwsNkS\",\"username\":\"GSlyQdwsNkS\",\"id\":\"673ff862b0df5c00019b1ea1\",\"_links\":{\"a
  03:20:26.469 [front-end] Received response: "{\"firstName\":\"tbhaDXI\",\"lastName\":\"tbhaDXI\",\"username\":\"tbhaDXI\",\"id\":\"673ff865b0df5c00019b1ea5\",\"_links\":{\"addresses\":{
  03:20:30.252 [front-end] Posting Customer: {"username":"MKGIsEbVYi","password":"VhFAQhsXw","email":"MKGIsEbVYi@gmail.com","firstName":"MKGIsEbVYi","lastName":"MKGIsEbVYi"}
  03:20:32.913 [front-end] Received response: "{\"firstName\":\"xQhxkcD\",\"lastName\":\"xQhxkcD\",\"username\":\"xQhxkcD\",\"id\":\"673ff86bb0df5c00019b1ec3\",\"_links\":{\"addresses\":{
  03:20:36.743 [front-end] Received response: "{\"firstName\":\"UzagwCTnbpaXVzA\",\"lastName\":\"UzagwCTnbpaXVzA\",\"username\":\"UzagwCTnbpaXVzA\",\"id\":\"673ff86fb0df5c00019b1ed4\",\"_
  03:20:39.079 [user] ts=2024-11-22T03:20:39.079141282Z caller=middlewares.go:46 method=Register username=ELXzX email=ELXzX@gmail.com took=1.044635ms
  03:20:43.387 [carts] 2024-11-22 03:20:43.386 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[DE
  03:20:46.389 [carts] 2024-11-22 03:20:46.389 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.ac
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.sp
  03:20:51.502 [front-end] Received response: "{\"firstName\":\"znIVGAMLgnSste\",\"lastName\":\"znIVGAMLgnSste\",\"username\":\"znIVGAMLgnSste\",\"id\":\"673ff880b0df5c00019b1f04\",\"_lin
  03:20:55.766 [front-end] Posting Customer: {"username":"PvCLeeg","password":"pTqmeIPqX","email":"PvCLeeg@gmail.com","firstName":"PvCLeeg","lastName":"PvCLeeg"}
  03:20:59.100 [user] ts=2024-11-22T03:20:59.100482586Z caller=middlewares.go:46 method=Register username=mLiQP email=mLiQP@gmail.com took=1.31638ms
  03:20:59.689 [carts] 2024-11-22 03:20:59.689 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[applicati
  03:20:59.787 [carts] 2024-11-22 03:20:59.786 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[DE
  03:20:59.886 [carts] 2024-11-22 03:20:59.886 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http.
  03:21:02.584 [front-end] Posting Customer: {"username":"sQAAadzpZlKDfq","password":"reYll","email":"sQAAadzpZlKDfq@gmail.com","firstName":"sQAAadzpZlKDfq","lastName":"sQAAadzpZlKDfq"}
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.s
  03:21:03.285 [carts] 2024-11-22 03:21:03.285 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/

## p0664
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-11T08:10:28.461Z
```
{"service":"webservice1","message":"2021-08-11 08:10:28,461 | ERROR | 0.0.0.1 | 172.17.0.3 | webservice1 | 661addbd63d50968 | an error occurred in the downstream service"}
```
Same service, the 2 minutes before (oldest first):
  08:10:25.034 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  08:10:25.035 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '86b89452-fa38-11eb-a435-0242ac110003', 'value': '', 'ex': 10}  (×3)
  08:10:25.088 [webservice1] INFO uuid: 86b89452-fa38-11eb-a435-0242ac110003 write redis successfully  (×3)
  08:10:25.146 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  08:10:25.194 [webservice1] INFO complete information: {'uuid': '86b89452-fa38-11eb-a435-0242ac110003', 'user_id': 'EvQlkbnz'}  (×3)
  08:10:25.204 [webservice1] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×3)
  08:10:25.204 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
All services, 30 seconds either side (sampled):
  08:09:58.461 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×40)
  08:09:58.605 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '76b0685a-fa38-11eb-b294-0242ac110004', 'user_id': 'jhoAGDST'}  (×90)
  08:09:58.773 [dbservice1] INFO query = select passwards from username_table where user_name='jhoAGDST'  (×46)
  08:09:59.137 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×42)
  08:09:59.296 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×50)
  08:09:59.529 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×49)
  08:09:59.769 [redisservice1] INFO service accept, status_code: 200  (×45)
  08:10:00.554 [webservice1] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×47)
  08:10:02.338 [mobservice2] INFO info 78f6cb40-fa38-11eb-8099-0242ac110003:GqOpyFdr write success
  08:10:05.240 [mobservice2] INFO info 7ab6b77e-fa38-11eb-b57e-0242ac110003:BWwoGkgb write success
  08:10:08.216 [dbservice1] INFO 7c1f4e8c-fa38-11eb-941a-0242ac110004-KOZoDVJh-B8f#M%=K4gVj token generate success token=MTYyODY0MDYwOC4yMTY1OTI6N2MxZjRlOGMtZmEzOC0xMWViLTk0MWEtMDI0MmFjMTE
  08:10:10.837 [dbservice1] INFO 7dc248d4-fa38-11eb-bbb1-0242ac110004-BLOHhDzM-{i4jP}N/rmt9 token generate success token=MTYyODY0MDYxMC44MzY3NjQ4OjdkYzI0OGQ0LWZhMzgtMTFlYi1iYmIxLTAyNDJhYzE
  08:10:13.547 [dbservice2] INFO 7f6ed454-fa38-11eb-9e52-0242ac110003-VkYhsQXg-wW@U3A6^R4)_ token generate success token=MTYyODY0MDYxMy41NDY5MjQ4OjdmNmVkNDU0LWZhMzgtMTFlYi05ZTUyLTAyNDJhYzE
  08:10:16.227 [dbservice2] INFO 810c3eb4-fa38-11eb-9a29-0242ac110003-TEzNtqXJ-hX%YBAgR(yzj token generate success token=MTYyODY0MDYxNi4yMjY1OTg3OjgxMGMzZWI0LWZhMzgtMTFlYi05YTI5LTAyNDJhYzE
  08:10:18.687 [dbservice2] INFO 82880eb2-fa38-11eb-8cf5-0242ac110004-AfSqKhsi->emTu&{%^-K? token generate success token=MTYyODY0MDYxOC42ODY1OTgzOjgyODgwZWIyLWZhMzgtMTFlYi04Y2Y1LTAyNDJhYzE
  08:10:21.234 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  08:10:23.522 [mobservice1] INFO info 858aa200-fa38-11eb-a02a-0242ac110004:UDVbonul write success
  08:10:26.337 [mobservice1] INFO info 87385cfa-fa38-11eb-8c62-0242ac110004:PwhZOREl write success
  08:10:28.877 [mobservice2] INFO info 88c6ae78-fa38-11eb-bf8b-0242ac110004:tJwGvlrd write success
  08:10:32.552 [mobservice2] INFO info 8b02971a-fa38-11eb-b2d0-0242ac110003:JZinoGDa write success
  08:10:35.846 [mobservice1] INFO info 8ce93f5c-fa38-11eb-85e3-0242ac110004:jIBRSGcQ write success
  08:10:38.871 [dbservice1] INFO 8e7f82ae-fa38-11eb-a912-0242ac110003-kxDurOQh-6s{Tqo7ky*W9 token generate success token=MTYyODY0MDYzOC44NzExMDI4OjhlN2Y4MmFlLWZhMzgtMTFlYi1hOTEyLTAyNDJhYzE
  08:10:41.737 [dbservice1] INFO 902995ae-fa38-11eb-845f-0242ac110004-ItWBCNrc-GUJ7{#*fP2/g token generate success token=MTYyODY0MDY0MS43MzY2NTc0OjkwMjk5NWFlLWZhMzgtMTFlYi04NDVmLTAyNDJhYzE
  08:10:45.941 [mobservice1] INFO info 92eeccfa-fa38-11eb-b281-0242ac110003:gFNpOQjC write success
  08:10:49.087 [mobservice1] INFO info 94d740c4-fa38-11eb-8855-0242ac110003:xjYUMcml write success
  08:10:51.470 [mobservice2] INFO info 9647b894-fa38-11eb-ada2-0242ac110003:ZYabGCTS write success
  08:10:53.894 [mobservice1] INFO info 97ab02a4-fa38-11eb-ab46-0242ac110004:HBUrWkyb write success
  08:10:56.556 [mobservice2] INFO info 99482f74-fa38-11eb-9094-0242ac110004:wzNVdLGu write success

## p0100
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:05:51.667Z
```
{"timestamp":1731906351667741200,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request error"}
```
Same service, the 2 minutes before (oldest first):
  05:05:51.109 [frontend] request complete  (×7)
  05:05:51.113 [frontend] request started  (×6)
  05:05:51.113 [frontend] view user cart  (×2)
  05:05:51.258 [frontend] serving product page  (×2)
  05:05:51.581 [frontend] adding to cart
  05:05:51.640 [frontend] placing order
  05:05:51.640 [frontend] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
All services, 30 seconds either side (sampled):
  05:05:28.413 [frontend] request started  (×265)
  05:05:28.422 [cartservice] GetCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×218)
  05:05:28.449 [adservice] received ad request (context_words=[accessories])  (×17)
  05:05:28.458 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=1YMWWN1N4O, quantity=7  (×26)
  05:05:28.497 [shippingservice] [GetQuote] completed request  (×59)
  05:05:28.996 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="USD"  (×6)
  05:05:29.017 [checkoutservice] payment went through (transaction_id: e43c7587-0e24-4a72-8d85-16a465855b2a)  (×9)
  05:05:29.021 [cartservice] EmptyCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×9)
  05:05:29.030 [frontend] order placed  (×9)
  05:05:31.741 [adservice] received ad request (context_words=[decor, home])  (×11)
  05:05:32.748 [frontend] ENV_PLATFORM is: aws  (×39)
  05:05:33.869 [adservice] received ad request (context_words=[footwear])  (×17)
  05:05:33.972 [paymentservice] Transaction processed: visa ending 2652 Amount: CAD426.701933656
  05:05:38.673 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×4)
  05:05:46.056 [emailservice] A request to send order confirmation email to fcontreras@example.com has been received.
  05:05:51.642 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13  (×2)
  05:05:51.663 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  05:05:52.048 [redis] 47:C 18 Nov 2024 05:05:52.048 * DB saved on disk
  05:05:52.502 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="EUR"
  05:05:52.540 [emailservice] A request to send order confirmation email to vsimpson@example.net has been received.
  05:06:04.238 [checkoutservice] order confirmation email sent to "michaelacosta@example.net"
  05:06:10.954 [emailservice] A request to send order confirmation email to michael03@example.com has been received.
  05:06:12.456 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"107763","nanos":686865077},"credit_card":{"credit_card_number":"43292417215
  05:06:12.472 [checkoutservice] order confirmation email sent to "leenathaniel@example.org"

## p0235
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service shippingservice, 2024-11-18T07:57:22.063Z
```
{"timestamp":1731916642063318300,"container_name":"shippingservice","pod_name":"shippingservice-547ddf469c-vjbwz","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"[GetQuote] completed request"}
```
Same service, the 2 minutes before (oldest first):
  07:57:15.546 [shippingservice] [GetQuote] completed request  (×9)
  07:57:15.552 [shippingservice] [GetQuote] received request  (×9)
  07:57:18.926 [shippingservice] [ShipOrder] received request
  07:57:18.926 [shippingservice] [ShipOrder] completed request
All services, 30 seconds either side (sampled):
  07:56:52.550 [frontend] request started  (×350)
  07:56:52.557 [cartservice] GetCartAsync called with userId=c216dec4-2181-4773-8cc5-aa587ee59fcc  (×284)
  07:56:52.582 [adservice] received ad request (context_words=[decor, home])  (×16)
  07:56:52.698 [frontend] adding to cart  (×51)
  07:56:52.725 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', '9SIQT8TOJO', '2ZYFJ3GM2N', 'OLJCESPC7Z']  (×8)
  07:56:52.974 [frontend] home  (×27)
  07:56:53.884 [adservice] received ad request (context_words=[kitchen])  (×51)
  07:56:54.170 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="JPY"  (×2)
  07:56:54.190 [checkoutservice] payment went through (transaction_id: f2637468-a149-42be-92c1-c63a9be5c317)  (×14)
  07:56:54.195 [cartservice] EmptyCartAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add  (×14)
  07:56:54.201 [checkoutservice] failed to send order confirmation to "orozcosteven@example.net": rpc error: code = Internal desc = Failed to serialize response!
  07:56:54.657 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', 'L9ECAV7KIM', '66VCHSJNUP']
  07:56:54.755 [paymentservice] Transaction processed: visa ending 2949 Amount: EUR1154.117647067  (×3)
  07:56:55.731 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="GBP"
  07:56:55.765 [emailservice] A request to send order confirmation email to courtneyreilly@example.net has been received.
  07:56:57.327 [adservice] received ad request (context_words=[clothing, tops])  (×22)
  07:57:05.056 [emailservice] A request to send order confirmation email to bradshawbrandon@example.net has been received.
  07:57:05.323 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"64","nanos":460000000},"credit_card":{"credit_card_number":"456351993503912  (×3)
  07:57:05.336 [checkoutservice] failed to send order confirmation to "crosbylarry@example.net": rpc error: code = Internal desc = Failed to serialize response!
  07:57:18.923 [paymentservice] Transaction processed: visa ending 1951 Amount: TRY11310.568276911  (×5)
  07:57:23.298 [emailservice] A request to send order confirmation email to xsoto@example.net has been received.
  07:57:23.747 [checkoutservice] failed to send order confirmation to "margaret86@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:57:28.786 [emailservice] A request to send order confirmation email to allenmaria@example.net has been received.
  07:57:44.766 [checkoutservice] failed to send order confirmation to "sjordan@example.net": rpc error: code = Internal desc = Failed to serialize response!
  07:57:49.273 [emailservice] A request to send order confirmation email to troychang@example.net has been received.

## p0642
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-other-service, 2024-12-07T20:27:05.334Z
```
{"timestamp":1733603225334431500,"container_name":"ts-order-other-service","pod_name":"ts-order-other-service-746fccc88f-4npbx","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 20:27:05.334  INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController    : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024"}
```
Same service, the 2 minutes before (oldest first):
  20:26:45.117 [ts-order-other-service] 2024-12-07 20:26:45.117 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×6)
  20:26:50.568 [ts-order-other-service] 2024-12-07 20:26:50.568 INFO 1 --- [io-12032-exec-6] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×2)
  20:26:50.571 [ts-order-other-service] 2024-12-07 20:26:50.571 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 62  (×2)
  20:26:50.640 [ts-order-other-service] 2024-12-07 20:26:50.640 INFO 1 --- [io-12032-exec-8] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=594119  (×3)
  20:26:57.892 [ts-order-other-service] 2024-12-07 20:26:57.892 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0
  20:26:57.894 [ts-order-other-service] 2024-12-07 20:26:57.894 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0
  20:26:59.099 [ts-order-other-service] 2024-12-07 20:26:59.099 INFO 1 --- [io-12032-exec-1] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-
  20:26:59.102 [ts-order-other-service] 2024-12-07 20:26:59.102 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou
  20:26:59.102 [ts-order-other-service] 2024-12-07 20:26:59.102 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 68
  20:26:59.342 [ts-order-other-service] 2024-12-07 20:26:59.342 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : Stations name list is : Response(status=1, msg=Success, data=[Shang H
  20:26:59.361 [ts-order-other-service] 2024-12-07 20:26:59.361 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Get Order By Id] Order Id: 1f1f879c-bbef-4b89
All services, 30 seconds either side (sampled):
  20:26:38.094 [ts-auth-service] 2024-12-07 20:26:38.094 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×13)
  20:26:38.306 [ts-route-service] 2024-12-07 20:26:38.306 INFO 1 --- [io-11178-exec-5] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×223)
  20:26:38.365 [ts-travel-service] 2024-12-07 20:26:38.364 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×15)
  20:26:38.487 [ts-route-service] 2024-12-07 20:26:38.486 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 1367db1f-461e-4ab7-87ad-2bcc05fd9cb7  (×25)
  20:26:39.700 [ts-travel-service] 2024-12-07 20:26:39.700 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×3)
  20:26:40.560 [ts-admin-travel-service] 2024-12-07 20:26:40.560 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)
  20:26:43.303 [ts-payment-mongo] {"t":{"$date":"2024-12-07T20:26:43.302+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360320
  20:26:44.877 [ts-basic-service] 2024-12-07 20:26:44.876 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×70)
  20:26:44.947 [ts-basic-service] 2024-12-07 20:26:44.947 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×6)
  20:26:44.971 [ts-travel2-service] 2024-12-07 20:26:44.970 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×12)
  20:26:45.025 [ts-seat-service] 2024-12-07 20:26:45.025 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×23)
  20:26:45.060 [ts-seat-service] 2024-12-07 20:26:45.060 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×16)
  20:26:50.280 [ts-auth-service] 2024-12-07 20:26:50.280 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×11)
  20:26:50.572 [ts-travel2-service] 2024-12-07 20:26:50.572 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  20:26:50.694 [ts-seat-service] 2024-12-07 20:26:50.694 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×3)
  20:26:50.753 [ts-travel2-service] 2024-12-07 20:26:50.753 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×2)
  20:26:59.344 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:26:59 +0800] "POST /api/v1/orderOtherService/orderOther/refresh HTTP/1.1" 200 28137 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10
  20:27:03.406 [ts-travel-service] 2024-12-07 20:27:03.406 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×7)
  20:27:03.487 [ts-travel-service] 2024-12-07 20:27:03.487 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×3)
  20:27:03.540 [ts-seat-service] 2024-12-07 20:27:03.540 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×5)
  20:27:03.996 [ts-basic-service] 2024-12-07 20:27:03.996 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：a3f256c1-0e
  20:27:08.404 [ts-food-service] 2024-12-07 20:27:08.404 INFO 1 --- [io-18856-exec-5] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×4)
  20:27:09.038 [ts-travel2-service] 2024-12-07 20:27:09.038 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234  (×2)
  20:27:16.672 [ts-basic-service] 2024-12-07 20:27:16.672 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693
  20:27:28.385 [ts-travel-mongo] {"t":{"$date":"2024-12-07T20:27:28.385+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360324
  20:27:31.239 [ts-food-mongo] {"t":{"$date":"2024-12-07T20:27:31.237+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360325
  20:27:31.757 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:27:31.757+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360325

## p0346
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:26:04.073Z
```
{"timestamp":1732245964073071400,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:26:04.072867157Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff9c5b0df5c00019b22e5 took=1.781165ms"}
```
Same service, the 2 minutes before (oldest first):
  03:26:01.518 [user] ts=2024-11-22T03:26:01.518098017Z caller=middlewares.go:104 method=GetAddresses id=673ff9b7b0df5c00019b22ae result=1 took=1.218989ms
  03:26:01.800 [user] ts=2024-11-22T03:26:01.800069229Z caller=middlewares.go:75 method=GetUsers id=673ff9b6b0df5c00019b22ad result=1 took=973.968µs  (×7)
  03:26:01.817 [user] ts=2024-11-22T03:26:01.81747472Z caller=middlewares.go:134 method=GetCards id=673ff9bdb0df5c00019b22cc result=1 took=935.919µs
  03:26:01.817 [user] ts=2024-11-22T03:26:01.817631129Z caller=middlewares.go:104 method=GetAddresses id=673ff9bdb0df5c00019b22ca result=1 took=926.994µs  (×2)
  03:26:01.896 [user] ts=2024-11-22T03:26:01.896386639Z caller=middlewares.go:46 method=Register username=SDAdRBTG email=SDAdRBTG@gmail.com took=987.608µs
  03:26:02.045 [user] ts=2024-11-22T03:26:02.045056884Z caller=middlewares.go:46 method=Register username=NDdGdkpxMdxFxES email=NDdGdkpxMdxFxES@gmail.com took=994.831µs
  03:26:02.420 [user] ts=2024-11-22T03:26:02.419846349Z caller=middlewares.go:75 method=GetUsers id=673ff9b2b0df5c00019b22a0 result=1 took=1.011367ms
  03:26:02.420 [user] ts=2024-11-22T03:26:02.419994832Z caller=middlewares.go:134 method=GetCards id=673ff9b8b0df5c00019b22b5 result=1 took=1.158738ms
  03:26:03.094 [user] ts=2024-11-22T03:26:03.093971613Z caller=middlewares.go:157 method=Health result=2 took=819.191µs  (×2)
  03:26:03.128 [user] ts=2024-11-22T03:26:03.128207188Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff9c6b0df5c00019b22e9 took=1.833756ms
  03:26:03.143 [user] ts=2024-11-22T03:26:03.143552197Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff9c6b0df5c00019b22e9 took=1.852415ms
  03:26:03.911 [user] ts=2024-11-22T03:26:03.911386968Z caller=middlewares.go:46 method=Register username=pTSbjqeCtT email=pTSbjqeCtT@gmail.com took=1.063053ms
All services, 30 seconds either side (sampled):
  03:25:34.261 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff9a6b0df5c00019b2276"}  (×62)
  03:25:34.365 [front-end] POST to carts: http://carts/carts/673ff9a6b0df5c00019b2276/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}  (×27)
  03:25:34.960 [front-end] Sent cookies.  (×67)
  03:25:36.085 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff9a5b0df5c00019b2275\",\"_links\":{\"  (×66)
  03:25:36.114 [queue-master] 2024-11-22 03:25:36.114 INFO 6 --- [ool-6-thread-26] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×51)
  03:25:36.596 [front-end] Order response: {"id":"673ff9b0d94b9000069b4474","customerId":"673ff99fb0df5c00019b2265","customer":{"id":null,"firstName":"XtaOIHjxX","lastName":"XtaOIHjxX","u
  03:25:38.406 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732245938404,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×6)
  03:25:39.211 [front-end] Order response: {"id":"673ff9b3d94b9000069b4476","customerId":"673ff9a4b0df5c00019b2270","customer":{"id":null,"firstName":"DBRfviyDTFmbq","lastName":"DBRfviyDT
  03:25:40.614 [front-end] Received response: "{\"firstName\":\"KePXAo\",\"lastName\":\"KePXAo\",\"username\":\"KePXAo\",\"id\":\"673ff9a1b0df5c00019b2269\",\"_links\":{\"addresses\":{\"h
  03:25:44.370 [front-end] Posting Customer: {"username":"qKMkYJc","password":"zWvZpleOaO","email":"qKMkYJc@gmail.com","firstName":"qKMkYJc","lastName":"qKMkYJc"}
  03:25:46.100 [user] ts=2024-11-22T03:25:46.100401102Z caller=middlewares.go:46 method=Register username=MudicL email=MudicL@gmail.com took=1.118839ms
  03:25:47.854 [catalogue] ts=2024-11-22T03:25:47Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=4.89093m  (×9)
  03:25:52.333 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9c0d94b9000069b4480","customerId":"673ff9a9b0df5c00019b2281","customer":{"id":null,"firstName":"zZxwTs","la
  03:25:54.725 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9c2d94b9000069b4483","customerId":"673ff9b2b0df5c00019b229f","customer":{"id":null,"firstName":"tRxwrNcsoZj
  03:25:57.502 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9c5d94b9000069b4485","customerId":"673ff9b6b0df5c00019b22ac","customer":{"id":null,"firstName":"srZNODABzO"
  03:25:58.529 [front-end] Posting Customer: {"username":"LJNDKHTUFzaG","password":"HSTcz","email":"LJNDKHTUFzaG@gmail.com","firstName":"LJNDKHTUFzaG","lastName":"LJNDKHTUFzaG"}
  03:26:01.542 [queue-master] 2024-11-22 03:26:01.542 INFO 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×9)
  03:26:02.447 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9cad94b9000069b448e","customerId":"673ff9b2b0df5c00019b22a0","customer":{"id":null,"firstName":"FSwvlC","la
  03:26:06.183 [front-end] Order response: {"id":"673ff9ced94b9000069b4491","customerId":"673ff9bdb0df5c00019b22ce","customer":{"id":null,"firstName":"UkkTYbzvjpJWy","lastName":"UkkTYbzvj
  03:26:08.617 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9d0d94b9000069b4495","customerId":"673ff9b8b0df5c00019b22b2","customer":{"id":null,"firstName":"qKMkYJc","l
  03:26:12.056 [user] ts=2024-11-22T03:26:12.056011593Z caller=middlewares.go:46 method=Register username=DwMuq email=DwMuq@gmail.com took=998.936µs
  03:26:15.272 [front-end] Received response: "{\"firstName\":\"jAFfmUPlFhwfTlG\",\"lastName\":\"jAFfmUPlFhwfTlG\",\"username\":\"jAFfmUPlFhwfTlG\",\"id\":\"673ff9bdb0df5c00019b22c7\",\"_
  03:26:18.926 [front-end] Received response: "{\"firstName\":\"quAhd\",\"lastName\":\"quAhd\",\"username\":\"quAhd\",\"id\":\"673ff9c8b0df5c00019b22f0\",\"_links\":{\"addresses\":{\"href
  03:26:20.364 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9dcd94b9000069b44a1","customerId":"673ff9c6b0df5c00019b22e9","customer":{"id":null,"firstName":"PiqKAbknNyR
  03:26:23.423 [front-end] Posting Customer: {"username":"pwGqvq","password":"jWRkr","email":"pwGqvq@gmail.com","firstName":"pwGqvq","lastName":"pwGqvq"}
  03:26:26.910 [front-end] Order response: {"id":"673ff9e2d94b9000069b44a5","customerId":"673ff9d2b0df5c00019b230e","customer":{"id":null,"firstName":"hithHmB","lastName":"hithHmB","usern
  03:26:29.149 [front-end] Posting Customer: {"username":"rmkuBEoreHDHSf","password":"pAWMasMCq","email":"rmkuBEoreHDHSf@gmail.com","firstName":"rmkuBEoreHDHSf","lastName":"rmkuBEoreHDHSf
  03:26:31.779 [front-end] Posting Customer: {"username":"XBHfsWYmDq","password":"eeKVhnLjZ","email":"XBHfsWYmDq@gmail.com","firstName":"XBHfsWYmDq","lastName":"XBHfsWYmDq"}
  03:26:33.576 [user] ts=2024-11-22T03:26:33.576250405Z caller=middlewares.go:46 method=Register username=WTNaLS email=WTNaLS@gmail.com took=1.045979ms

## p0103
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service recommendationservice, 2024-11-18T05:06:41.740Z
```
{"timestamp":1731906401740960500,"container_name":"recommendationservice","pod_name":"recommendationservice-fdf57f545-q8t5v","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"[Recv ListRecommendations] product_ids=['9SIQT8TOJO', '2ZYFJ3GM2N', '66VCHSJNUP', 'L9ECAV7KIM', '0PUK6V6EV0']"}
```
Same service, the 2 minutes before (oldest first):
  05:06:33.873 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', 'L9ECAV7KIM', 'OLJCESPC7Z', '0PUK6V6EV0', '9SIQT8TOJO']  (×20)
All services, 30 seconds either side (sampled):
  05:06:12.281 [frontend] request started  (×322)
  05:06:12.289 [cartservice] GetCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×264)
  05:06:12.313 [adservice] received ad request (context_words=[kitchen])  (×59)
  05:06:12.372 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=LS4PSXUNUM, quantity=10  (×36)
  05:06:12.409 [shippingservice] [GetQuote] completed request  (×80)
  05:06:12.456 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"107763","nanos":686865077},"credit_card":{"credit_card_number":"43292417215  (×2)
  05:06:12.459 [shippingservice] [ShipOrder] received request  (×9)
  05:06:12.471 [emailservice] A request to send order confirmation email to leenathaniel@example.org has been received.
  05:06:12.862 [frontend] home  (×37)
  05:06:13.294 [frontend] setting currency  (×22)
  05:06:15.023 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', '66VCHSJNUP', 'OLJCESPC7Z']  (×5)
  05:06:17.789 [adservice] received ad request (context_words=[decor, home])  (×12)
  05:06:22.106 [paymentservice] Transaction processed: visa ending 2002 Amount: USD301.360000000  (×4)
  05:06:22.736 [adservice] received ad request (context_words=[accessories])  (×21)
  05:06:25.480 [emailservice] A request to send order confirmation email to jjones@example.net has been received.
  05:06:41.863 [checkoutservice] order confirmation email sent to "luke34@example.net"
  05:06:45.100 [paymentservice] Transaction processed: visa ending 4792 Amount: EUR688.474126498
  05:06:49.284 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="TRY"
  05:06:49.327 [emailservice] A request to send order confirmation email to suzannerush@example.net has been received.
  05:06:49.497 [checkoutservice] order confirmation email sent to "doconnell@example.net"
  05:07:06.768 [paymentservice] Transaction processed: visa ending 2818 Amount: CAD2968.875018134

## p0336
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:21:19.192Z
```
{"timestamp":1732245679192128800,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:21:19.191 ERROR [carts,,,] 7 --- [-nio-80-exec-21] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.util.ConcurrentModificationException] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  03:21:18.290 [carts] 2024-11-22 03:21:18.290 INFO [carts,fb7913950d676f18,6e117eba14b3663e,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{reposi  (×20)
All services, 30 seconds either side (sampled):
  03:20:49.209 [front-end] User cart deleted with status: 503  (×62)
  03:20:49.812 [user] ts=2024-11-22T03:20:49.812751686Z caller=middlewares.go:46 method=Register username=YwTYsSUGcmNRsJY email=YwTYsSUGcmNRsJY@gmail.com took=1.047817ms  (×25)
  03:20:51.499 [user] ts=2024-11-22T03:20:51.499248244Z caller=middlewares.go:75 method=GetUsers id=673ff880b0df5c00019b1f04 result=1 took=993.546µs  (×170)
  03:20:51.552 [front-end] POST /addresses 200 - ms - -  (×61)
  03:20:51.970 [front-end] Posting Customer: {"username":"nPklGOsvzh","password":"YuEpn","email":"nPklGOsvzh@gmail.com","firstName":"nPklGOsvzh","lastName":"nPklGOsvzh"}
  03:20:54.954 [orders] 2024-11-22 03:20:54.954 ERROR [orders,,,] 6 --- [-nio-80-exec-15] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×8)
  03:20:59.100 [user] ts=2024-11-22T03:20:59.100482586Z caller=middlewares.go:46 method=Register username=mLiQP email=mLiQP@gmail.com took=1.31638ms
  03:20:59.690 [carts] 2024-11-22 03:20:59.690 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[OPTIONS],produces=[application/
  03:20:59.789 [carts] 2024-11-22 03:20:59.789 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces=
  03:21:02.119 [front-end] Posting Customer: {"username":"gKGbBfBuFal","password":"jTPEzN","email":"gKGbBfBuFal@gmail.com","firstName":"gKGbBfBuFal","lastName":"gKGbBfBuFal"}
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  03:21:03.503 [front-end] Posting Customer: {"username":"gxEQQKdgPqad","password":"JuVTj","email":"gxEQQKdgPqad@gmail.com","firstName":"gxEQQKdgPqad","lastName":"gxEQQKdgPqad"}
  03:21:08.309 [front-end] Posting Customer: {"username":"MszyyqkjNcAvcB","password":"ooieHc","email":"MszyyqkjNcAvcB@gmail.com","firstName":"MszyyqkjNcAvcB","lastName":"MszyyqkjNcAvcB"}
  03:21:09.807 [front-end] Received response: "{\"firstName\":\"URVWiLVbByzZ\",\"lastName\":\"URVWiLVbByzZ\",\"username\":\"URVWiLVbByzZ\",\"id\":\"673ff889b0df5c00019b1f1d\",\"_links\":{
  03:21:13.089 [carts] 2024-11-22 03:21:13.089 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 139.303 seconds (JVM running for 144.3
  03:21:15.774 [front-end] Posting Customer: {"username":"eSafJJOuc","password":"LrXrl","email":"eSafJJOuc@gmail.com","firstName":"eSafJJOuc","lastName":"eSafJJOuc"}
  03:21:18.113 [orders] java.util.concurrent.TimeoutException: null at java.util.concurrent.FutureTask.get(FutureTask.java:205) ~[na:1.8.0_131] at works.weave.socks.orders.controllers.  (×2)
  03:21:18.613 [queue-master] 2024-11-22 03:21:18.612 INFO 6 --- [ool-6-thread-44] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×72)
  03:21:18.854 [front-end] Received response: "{\"firstName\":\"sQAAadzpZlKDfq\",\"lastName\":\"sQAAadzpZlKDfq\",\"username\":\"sQAAadzpZlKDfq\",\"id\":\"673ff89eb0df5c00019b1f58\",\"_lin
  03:21:19.502 [front-end] Order response: {"id":"673ff8afd94b9000069b4392","customerId":"673ff89eb0df5c00019b1f58","customer":{"id":null,"firstName":"sQAAadzpZlKDfq","lastName":"sQAAadzp
  03:21:20.407 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b0d94b9000069b4396","customerId":"673ff893b0df5c00019b1f31","customer":{"id":null,"firstName":"nPklGOsvzh"
  03:21:21.636 [user] ts=2024-11-22T03:21:21.636419176Z caller=middlewares.go:46 method=Register username=XaQgsgBGh email=XaQgsgBGh@gmail.com took=1.069756ms
  03:21:26.558 [user] ts=2024-11-22T03:21:26.558433542Z caller=middlewares.go:46 method=Register username=ZaeWmQ email=ZaeWmQ@gmail.com took=1.00428ms
  03:21:29.663 [user] ts=2024-11-22T03:21:29.663548471Z caller=middlewares.go:46 method=Register username=QoPcWQ email=QoPcWQ@gmail.com took=1.079037ms
  03:21:34.256 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8bed94b9000069b439f","customerId":"673ff8a8b0df5c00019b1f85","customer":{"id":null,"firstName":"yXmVwShR","
  03:21:36.190 [front-end] Posting Customer: {"username":"DXXEAuEZfGxuPq","password":"zJmqdnrGmo","email":"DXXEAuEZfGxuPq@gmail.com","firstName":"DXXEAuEZfGxuPq","lastName":"DXXEAuEZfGxuP
  03:21:38.477 [user] ts=2024-11-22T03:21:38.477181232Z caller=middlewares.go:46 method=Register username=otqrpqrI email=otqrpqrI@gmail.com took=1.018878ms
  03:21:42.175 [front-end] Posting Customer: {"username":"aQnXDQax","password":"zSTTcvaI","email":"aQnXDQax@gmail.com","firstName":"aQnXDQax","lastName":"aQnXDQax"}
  03:21:44.658 [front-end] Posting Customer: {"username":"uJQuaCc","password":"YlkPMNT","email":"uJQuaCc@gmail.com","firstName":"uJQuaCc","lastName":"uJQuaCc"}

## p0147
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T05:37:25.548Z
```
{"timestamp":1731908245548992000,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-sd8v2","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  05:37:25.298 [currencyservice] conversion request successful  (×16)
  05:37:25.433 [currencyservice] Getting supported currencies...  (×4)
All services, 30 seconds either side (sampled):
  05:36:55.574 [frontend] request started  (×351)
  05:36:55.580 [cartservice] GetCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×289)
  05:36:55.598 [shippingservice] [GetQuote] received request  (×88)
  05:36:55.615 [frontend] request complete  (×351)
  05:36:55.984 [frontend] adding to cart  (×43)
  05:36:57.187 [adservice] received ad request (context_words=[kitchen])  (×56)
  05:36:57.567 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="TRY"
  05:36:57.594 [checkoutservice] payment went through (transaction_id: c712978c-3436-4e4f-a176-361b7edf4c71)  (×16)
  05:36:57.598 [cartservice] EmptyCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×16)
  05:36:57.607 [frontend] order placed  (×16)
  05:37:01.398 [frontend] home  (×27)
  05:37:01.678 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="CAD"  (×3)
  05:37:01.717 [emailservice] A request to send order confirmation email to deanserrano@example.org has been received.
  05:37:06.088 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"2001","nanos":530296335},"credit_card":{"credit_card_number":"4156463422675  (×3)
  05:37:06.102 [checkoutservice] order confirmation email sent to "kathyyoung@example.org"
  05:37:09.575 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"2222","nanos":930000000},"credit_card":{"credit_card_number":"4736978349268  (×4)
  05:37:09.591 [checkoutservice] order confirmation email sent to "kevinmartin@example.com"
  05:37:11.865 [emailservice] A request to send order confirmation email to epayne@example.net has been received.
  05:37:13.901 [checkoutservice] order confirmation email sent to "pamrogers@example.net"
  05:37:20.360 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="GBP"  (×4)
  05:37:20.396 [emailservice] A request to send order confirmation email to thomas37@example.net has been received.
  05:37:25.560 [emailservice] A request to send order confirmation email to lisa20@example.com has been received.
  05:37:25.562 [checkoutservice] order confirmation email sent to "thompsonmark@example.org"
  05:37:43.005 [checkoutservice] [PlaceOrder] user_id="33421b66-55b6-413b-9ba9-3230c85c58dc" user_currency="JPY"
  05:37:43.043 [emailservice] A request to send order confirmation email to nicole74@example.org has been received.
  05:37:43.389 [checkoutservice] order confirmation email sent to "christopher66@example.org"
  05:37:53.367 [emailservice] A request to send order confirmation email to watkinskelli@example.net has been received.

## p0781
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-24T13:36:42.907Z
```
{"timestamp":1732455402907131400,"container_name":"carts","pod_name":"carts-6cdcbc6cd7-7p6bw","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-24 13:36:42.907  INFO [carts,700aa8fd700730c3,cb3d49d6e243a0fc,false] 7 --- [p-nio-80-exec-9] o.s.d.r.w.RepositoryRestHandlerMapping   : Mapped \"{[/{repository}],methods=[POST],produces=[application/hal+json || application/json || application/*+json;charset=UTF-8]}\" onto public org.springframework.http.ResponseEntity<org.springframework.hateoas.ResourceSupport> org.springframework.data.res…"}
```
Same service, the 2 minutes before (oldest first):
  13:36:40.602 [carts] 2024-11-24 13:36:40.401 INFO [carts,3b0727ec8a3420e8,0c8952e1b699d02e,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.controllers.CartsController : Merge carts reques  (×3)
  13:36:41.306 [carts] 2024-11-24 13:36:41.298 INFO [carts,700aa8fd700730c3,cb3d49d6e243a0fc,false] 7 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  13:36:41.501 [carts] 2024-11-24 13:36:41.403 INFO [carts,6f98f71e509de74e,d87c1ff942a13e1e,false] 7 --- [-nio-80-exec-11] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  13:36:42.900 [carts] 2024-11-24 13:36:42.900 INFO [carts,700aa8fd700730c3,cb3d49d6e243a0fc,false] 7 --- [p-nio-80-exec-9] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],m  (×3)
  13:36:42.906 [carts] 2024-11-24 13:36:42.906 INFO [carts,700aa8fd700730c3,cb3d49d6e243a0fc,false] 7 --- [p-nio-80-exec-9] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{reposi
All services, 30 seconds either side (sampled):
  13:36:12.972 [front-end] Posting Customer: {"username":"blTnwPsX","password":"yhIhPiW","email":"blTnwPsX@gmail.com","firstName":"blTnwPsX","lastName":"blTnwPsX"}
  13:36:13.037 [front-end] Carts merged.  (×62)
  13:36:13.546 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×5)
  13:36:14.090 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×26)
  13:36:14.299 [carts] 2024-11-24 13:36:14.299 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.spring
  13:36:16.681 [user] ts=2024-11-24T13:36:16.681684992Z caller=middlewares.go:46 method=Register username=OrJwcJa email=OrJwcJa@gmail.com took=1.950199ms
  13:36:18.510 [carts] 2024-11-24 13:36:18.509 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/browser/**] onto handler of type [class org.sp
  13:36:22.697 [front-end] Posting Customer: {"username":"fhMvxmx","password":"yNeXEb","email":"fhMvxmx@gmail.com","firstName":"fhMvxmx","lastName":"fhMvxmx"}
  13:36:27.302 [carts] 2024-11-24 13:36:27.302 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.actu
  13:36:27.600 [carts] 2024-11-24 13:36:27.600 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[DELETE],produces=[applicat
  13:36:27.699 [carts] 2024-11-24 13:36:27.699 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applicati  (×2)
  13:36:29.806 [carts] 2024-11-24 13:36:29.806 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  13:36:29.810 [carts] 2024-11-24 13:36:29.810 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  13:36:32.715 [front-end] Posting Customer: {"username":"DKYXaCb","password":"PhswqJtvQ","email":"DKYXaCb@gmail.com","firstName":"DKYXaCb","lastName":"DKYXaCb"}
  13:36:35.399 [carts] 2024-11-24 13:36:35.310 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server as  (×2)
  13:36:37.884 [front-end] Posting Customer: {"username":"GwuPVBfNeyREcB","password":"WkwzDtOs","email":"GwuPVBfNeyREcB@gmail.com","firstName":"GwuPVBfNeyREcB","lastName":"GwuPVBfNeyREcB"
  13:36:41.042 [front-end] Received response: "{\"firstName\":\"OrJwcJa\",\"lastName\":\"OrJwcJa\",\"username\":\"OrJwcJa\",\"id\":\"67432bd0f6d87500016200bf\",\"_links\":{\"addresses\":{
  13:36:42.921 [queue-master] 2024-11-24 13:36:42.921 INFO 7 --- [pool-6-thread-2] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×27)
  13:36:43.309 [orders] 2024-11-24 13:36:43.309 INFO [orders,e7f0334956330e8d,a9b7cd545316999f,false] 7 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×8)
  13:36:45.105 [front-end] POST /cart 201 - ms - -  (×40)
  13:36:49.663 [front-end] Posting Customer: {"username":"VJXvtVFIFkF","password":"aZnptxpjQF","email":"VJXvtVFIFkF@gmail.com","firstName":"VJXvtVFIFkF","lastName":"VJXvtVFIFkF"}
  13:36:52.130 [front-end] Received response: "{\"firstName\":\"HaBgbUvp\",\"lastName\":\"HaBgbUvp\",\"username\":\"HaBgbUvp\",\"id\":\"67432bdff6d87500016200e8\",\"_links\":{\"addresses\
  13:36:54.672 [front-end] Order response: {"id":"67432bf6c4380300078a4825","customerId":"67432be5f6d87500016200fa","customer":{"id":null,"firstName":"UZOsx","lastName":"UZOsx","username"
  13:36:56.081 [front-end] Posting Customer: {"username":"YxiiULC","password":"TNChmGNbFO","email":"YxiiULC@gmail.com","firstName":"YxiiULC","lastName":"YxiiULC"}
  13:36:59.493 [user] ts=2024-11-24T13:36:59.492851485Z caller=middlewares.go:46 method=Register username=IyVcn email=IyVcn@gmail.com took=1.758292ms
  13:37:01.999 [front-end] Order response: {"id":"67432bfdc4380300078a482d","customerId":"67432be7f6d8750001620104","customer":{"id":null,"firstName":"RndGzoV","lastName":"RndGzoV","usern
  13:37:05.075 [front-end] Posting Customer: {"username":"GIlmNTige","password":"ffAgNLYBv","email":"GIlmNTige@gmail.com","firstName":"GIlmNTige","lastName":"GIlmNTige"}
  13:37:06.741 [front-end] Received response: "{\"firstName\":\"GwuPVBfNeyREcB\",\"lastName\":\"GwuPVBfNeyREcB\",\"username\":\"GwuPVBfNeyREcB\",\"id\":\"67432be5f6d87500016200fb\",\"_lin
  13:37:10.048 [front-end] Received response: "{\"firstName\":\"gvrYRCwYe\",\"lastName\":\"gvrYRCwYe\",\"username\":\"gvrYRCwYe\",\"id\":\"67432beff6d8750001620119\",\"_links\":{\"address
  13:37:11.827 [front-end] Order response: {"id":"67432c07c4380300078a4839","customerId":"67432bfbf6d8750001620145","customer":{"id":null,"firstName":"IyVcn","lastName":"IyVcn","username"

## p0304
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:20:13.898Z
```
{"timestamp":1732245613898809300,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"_embedded\\\":{\\\"card\\\":[{\\\"longNum\\\":\\\"123123321\\\",\\\"expires\\\":\\\"1232\\\",\\\"ccv\\\":\\\"123\\\",\\\"id\\\":\\\"673ff866b0df5c00019b1eae\\\",\\\"_links\\\":{\\\"card\\\":{\\\"href\\\":\\\"http://user/cards/673ff866b0df5c00019b1eae\\\"},\\\"self\\\":{\\\"href\\\":\\\"http://user/cards/673ff866b0df5c00019b1eae\\\"}}}]}}\\n\""}
```
Same service, the 2 minutes before (oldest first):
  03:20:13.642 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×2)
  03:20:13.650 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
  03:20:13.650 [front-end] POST to carts: http://carts/carts/673ff868b0df5c00019b1eb9/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}  (×2)
  03:20:13.678 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff864b0df5c00019b1ea4"}
  03:20:13.688 [front-end] POST /addresses 200 - ms - -
  03:20:13.694 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff864b0df5c00019b1ea4"}
  03:20:13.703 [front-end] POST /cards 200 - ms - -
  03:20:13.703 [front-end] POST /cart 500 59.209 ms - 64  (×2)
  03:20:13.749 [front-end] Attempting to delete cart for user: 673ff864b0df5c00019b1ea4
  03:20:13.786 [front-end] User cart deleted with status: 503
  03:20:13.789 [front-end] DELETE /cart 503 - ms - -
  03:20:13.804 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  03:20:13.883 [front-end] Request received with body: {}
  03:20:13.891 [front-end] Received response: "{\"firstName\":\"pnVaCbN\",\"lastName\":\"pnVaCbN\",\"username\":\"pnVaCbN\",\"id\":\"673ff860b0df5c00019b1e9b\",\"_links\":{\"addresses\":{
  03:20:13.891 [front-end] GET Request to: http://user/customers/673ff860b0df5c00019b1e9b/addresses  (×2)
  03:20:13.898 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×25)
  03:20:06.543 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff854b0df5c00019b1e7f\",\"_links\":{\"  (×40)
  03:20:06.586 [orders] 2024-11-22 03:20:06.586 ERROR [orders,,,] 6 --- [p-nio-80-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×24)
  03:20:06.649 [user] ts=2024-11-22T03:20:06.649242768Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff861b0df5c00019b1e9e took=1.734848ms  (×42)
  03:20:06.769 [front-end] User cart deleted with status: 503  (×42)
  03:20:06.803 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×6)
  03:20:07.186 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×9)
  03:20:08.469 [front-end] Posting Customer: {"username":"HNCLfJfsnW","password":"sSvsy","email":"HNCLfJfsnW@gmail.com","firstName":"HNCLfJfsnW","lastName":"HNCLfJfsnW"}
  03:20:08.498 [front-end] Carts merged.  (×34)
  03:20:09.093 [user] ts=2024-11-22T03:20:09.093533288Z caller=middlewares.go:46 method=Register username=CBhyKd email=CBhyKd@gmail.com took=1.350871ms
  03:20:09.192 [carts] 2024-11-22 03:20:09.192 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  03:20:10.049 [front-end] Posting Customer: {"username":"lPEGqahDSutlQTj","password":"AoWWVDzGsz","email":"lPEGqahDSutlQTj@gmail.com","firstName":"lPEGqahDSutlQTj","lastName":"lPEGqahDSu
  03:20:12.002 [front-end] Received response: "{\"firstName\":\"oVuSYHHeDcohK\",\"lastName\":\"oVuSYHHeDcohK\",\"username\":\"oVuSYHHeDcohK\",\"id\":\"673ff855b0df5c00019b1e85\",\"_links\
  03:20:14.429 [front-end] Posting Customer: {"username":"LWbxoNrjdrYfe","password":"dgukoXmQfq","email":"LWbxoNrjdrYfe@gmail.com","firstName":"LWbxoNrjdrYfe","lastName":"LWbxoNrjdrYfe"}
  03:20:16.376 [front-end] Posting Customer: {"username":"zCHyJV","password":"DBVYLG","email":"zCHyJV@gmail.com","firstName":"zCHyJV","lastName":"zCHyJV"}
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:20.340 [front-end] Posting Customer: {"username":"BBYdunXrngQk","password":"jbihHjN","email":"BBYdunXrngQk@gmail.com","firstName":"BBYdunXrngQk","lastName":"BBYdunXrngQk"}
  03:20:23.473 [front-end] Received response: "{\"firstName\":\"AIHRSQU\",\"lastName\":\"AIHRSQU\",\"username\":\"AIHRSQU\",\"id\":\"673ff863b0df5c00019b1ea2\",\"_links\":{\"addresses\":{
  03:20:26.017 [front-end] Posting Customer: {"username":"HLNoIPafm","password":"sBlBYfK","email":"HLNoIPafm@gmail.com","firstName":"HLNoIPafm","lastName":"HLNoIPafm"}
  03:20:28.421 [front-end] Posting Customer: {"username":"MoGml","password":"PJpiau","email":"MoGml@gmail.com","firstName":"MoGml","lastName":"MoGml"}
  03:20:30.252 [front-end] Posting Customer: {"username":"MKGIsEbVYi","password":"VhFAQhsXw","email":"MKGIsEbVYi@gmail.com","firstName":"MKGIsEbVYi","lastName":"MKGIsEbVYi"}
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.186 [front-end] Received response: "{\"firstName\":\"kgzVKACfUvkHp\",\"lastName\":\"kgzVKACfUvkHp\",\"username\":\"kgzVKACfUvkHp\",\"id\":\"673ff869b0df5c00019b1ebd\",\"_links\
  03:20:36.109 [front-end] Posting Customer: {"username":"HWsmCvxoMrNqX","password":"MJvuU","email":"HWsmCvxoMrNqX@gmail.com","firstName":"HWsmCvxoMrNqX","lastName":"HWsmCvxoMrNqX"}
  03:20:38.070 [session-db] 1:M 22 Nov 2024 03:20:38.070 * Background saving started by pid 32
  03:20:39.079 [user] ts=2024-11-22T03:20:39.079141282Z caller=middlewares.go:46 method=Register username=ELXzX email=ELXzX@gmail.com took=1.044635ms
  03:20:42.525 [front-end] Posting Customer: {"username":"jVIVRgJfOAq","password":"zWZXxq","email":"jVIVRgJfOAq@gmail.com","firstName":"jVIVRgJfOAq","lastName":"jVIVRgJfOAq"}
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:20:43.391 [carts] 2024-11-22 03:20:43.391 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon

## p0151
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T05:41:36.134Z
```
{"timestamp":1731908496134841000,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-sd8v2","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Getting supported currencies..."}
```
Same service, the 2 minutes before (oldest first):
  05:41:35.653 [currencyservice] conversion request successful  (×17)
  05:41:35.963 [currencyservice] Getting supported currencies...  (×3)
All services, 30 seconds either side (sampled):
  05:41:06.139 [emailservice] A request to send order confirmation email to gcook@example.com has been received.
  05:41:06.147 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '0PUK6V6EV0', '66VCHSJNUP', 'L9ECAV7KIM', '6E92ZMYYFZ']  (×239)
  05:41:06.341 [frontend] request started  (×318)
  05:41:06.355 [currencyservice] conversion request successful  (×634)
  05:41:06.670 [adservice] received ad request (context_words=[footwear])  (×15)
  05:41:07.007 [adservice] received ad request (context_words=[accessories])  (×38)
  05:41:07.029 [frontend] view user cart  (×72)
  05:41:07.071 [frontend] placing order  (×17)
  05:41:07.093 [paymentservice] Transaction processed: visa ending 9695 Amount: EUR25.634674923  (×10)
  05:41:07.098 [shippingservice] [ShipOrder] completed request  (×17)
  05:41:07.107 [checkoutservice] order confirmation email sent to "cheryl84@example.com"
  05:41:09.069 [checkoutservice] [PlaceOrder] user_id="fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a" user_currency="TRY"  (×3)
  05:41:09.111 [emailservice] A request to send order confirmation email to susanhicks@example.org has been received.
  05:41:16.004 [adservice] received ad request (context_words=[hair, beauty])  (×13)
  05:41:20.537 [emailservice] A request to send order confirmation email to glen11@example.net has been received.
  05:41:20.577 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"1493","nanos":760000000},"credit_card":{"credit_card_number":"4085613636325  (×2)
  05:41:20.619 [checkoutservice] order confirmation email sent to "davidrichards@example.net"
  05:41:23.659 [emailservice] A request to send order confirmation email to jonathan91@example.com has been received.
  05:41:27.755 [checkoutservice] order confirmation email sent to "amber29@example.com"
  05:41:36.103 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"2451","nanos":819916844},"credit_card":{"credit_card_number":"4238309350010
  05:41:36.118 [checkoutservice] order confirmation email sent to "robin52@example.org"
  05:41:44.484 [emailservice] A request to send order confirmation email to pward@example.org has been received.
  05:41:46.381 [checkoutservice] order confirmation email sent to "tom93@example.org"
  05:41:59.489 [emailservice] A request to send order confirmation email to zlarson@example.org has been received.
  05:42:01.539 [checkoutservice] order confirmation email sent to "xcampbell@example.com"
  05:42:02.964 [paymentservice] Transaction processed: visa ending 3679 Amount: JPY121738.685538158
  05:42:04.310 [emailservice] A request to send order confirmation email to jonathan87@example.net has been received.

## p0110
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:12:24.799Z
```
{"timestamp":1731906744799529200,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  05:12:23.607 [frontend] request started  (×6)
  05:12:23.607 [frontend] home
  05:12:23.611 [frontend] request complete  (×6)
  05:12:23.613 [frontend] view user cart
  05:12:23.649 [frontend] placing order
  05:12:23.652 [frontend] ENV_PLATFORM is: aws
  05:12:23.685 [frontend] order placed
  05:12:24.346 [frontend] serving product page  (×2)
  05:12:24.790 [frontend] adding to cart
All services, 30 seconds either side (sampled):
  05:11:54.813 [frontend] request started  (×338)
  05:11:54.824 [cartservice] GetCartAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432  (×268)
  05:11:54.849 [adservice] received ad request (context_words=[kitchen])  (×56)
  05:11:55.424 [frontend] setting currency  (×32)
  05:11:55.479 [adservice] received ad request (context_words=[])  (×39)
  05:11:55.795 [shippingservice] [GetQuote] completed request  (×80)
  05:11:56.875 [cartservice] AddItemAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0, productId=6E92ZMYYFZ, quantity=5  (×37)
  05:11:56.947 [checkoutservice] [PlaceOrder] user_id="0727db9d-83b9-44b7-acab-68a4f8f289c0" user_currency="CAD"
  05:11:56.993 [checkoutservice] payment went through (transaction_id: 07e2d54f-1ca8-4229-a04a-420c22f39d4d)  (×16)
  05:11:56.997 [cartservice] EmptyCartAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0  (×16)
  05:11:57.005 [frontend] order placed  (×16)
  05:11:58.840 [checkoutservice] [PlaceOrder] user_id="b63bea0e-d05f-4589-be71-8fef43557432" user_currency="TRY"  (×5)
  05:11:58.875 [emailservice] A request to send order confirmation email to leecarl@example.net has been received.
  05:12:03.750 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="EUR"  (×5)
  05:12:03.787 [emailservice] A request to send order confirmation email to henry98@example.com has been received.
  05:12:05.440 [checkoutservice] order confirmation email sent to "elizabeth31@example.com"
  05:12:11.851 [emailservice] A request to send order confirmation email to leejanet@example.org has been received.
  05:12:18.983 [checkoutservice] order confirmation email sent to "ewilliams@example.com"
  05:12:25.184 [emailservice] A request to send order confirmation email to nicole36@example.net has been received.
  05:12:32.799 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"1717","nanos":612919048},"credit_card":{"credit_card_number":"4826779178266  (×2)
  05:12:32.815 [checkoutservice] order confirmation email sent to "paul20@example.com"
  05:12:38.778 [emailservice] A request to send order confirmation email to veronica23@example.org has been received.
  05:12:41.586 [checkoutservice] order confirmation email sent to "btorres@example.net"
  05:12:44.474 [paymentservice] Transaction processed: visa ending 0124 Amount: USD460.790000000  (×3)
  05:12:44.832 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', '0PUK6V6EV0']
  05:12:52.211 [emailservice] A request to send order confirmation email to stephen33@example.net has been received.

## p0486
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T08:57:01.169Z
```
{"timestamp":1732352221169447400,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:57:01.169  INFO [carts,5c538ec146e63634,7af536729a4b5cfd,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.controllers.CartsController   : Merge carts request received for ids: 674198dda437380001deffa9 and TZNgz3mW9tte1h8xdLRCQ0RrilJ6ni-v"}
```
Same service, the 2 minutes before (oldest first):
  08:56:59.506 [carts] 2024-11-23 08:56:59.506 INFO [carts,d9cfb38bd61f40a7,5f4c0d10fefd923d,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.ItemsController : Did not find item.
  08:56:59.512 [carts] 2024-11-23 08:56:59.512 INFO [carts,d9cfb38bd61f40a7,5f4c0d10fefd923d,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.cart.CartContentsResource : Adding for user: Car
  08:57:01.066 [carts] 2024-11-23 08:57:01.066 INFO [carts,b76309bd2270af6a,d0af7f0322dd666c,false] 7 --- [-nio-80-exec-17] w.w.s.cart.controllers.ItemsController : Did not find item.
  08:57:01.072 [carts] 2024-11-23 08:57:01.072 INFO [carts,b76309bd2270af6a,d0af7f0322dd666c,false] 7 --- [-nio-80-exec-17] w.w.s.cart.cart.CartContentsResource : Adding for user: Car
All services, 30 seconds either side (sampled):
  08:56:58.007 [catalogue] ts=2024-11-23T08:56:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.869902ms  (×36)
  08:56:58.018 [orders] 2024-11-23 08:56:58.018 INFO [orders,6baef7816fdf67ff,4dc9cbe9bd6cff45,false] 8 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Received payment re  (×26)
  08:56:58.029 [front-end] Order response: {"statusCode":201,"body":{"id":"674198da3f77060008865384","customerId":"674198bfa437380001deff45","customer":{"id":null,"firstName":"ztfESzW","l
  08:56:59.388 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674198d3a437380001deff98"}  (×31)
  08:56:59.483 [catalogue] ts=2024-11-23T08:56:59Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.990138  (×28)
  08:57:00.720 [front-end] Request received with body: {}  (×27)
  08:57:00.744 [front-end] Posting Order: {"customer":"http://user/customers/674198caa437380001deff7c","address":"http://user/addresses/674198d0a437380001deff90","card":"http://user/cards  (×27)
  08:57:01.048 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  08:57:01.165 [front-end] 674198dda437380001deffa9  (×34)
  08:57:02.817 [payment] ts=2024-11-23T08:57:02Z caller=logging.go:29 method=Authorise result=false took=6.651µs  (×4)
  08:57:03.057 [front-end] Order response: {"statusCode":201,"body":{"id":"674198df3f77060008865387","customerId":"674198caa437380001deff7e","customer":{"id":null,"firstName":"qzkCXXFW","
  08:57:04.140 [front-end] Received response: "{\"firstName\":\"TlHaLWqJVqW\",\"lastName\":\"TlHaLWqJVqW\",\"username\":\"TlHaLWqJVqW\",\"id\":\"674198d0a437380001deff92\",\"_links\":{\"a
  08:57:05.392 [orders] 2024-11-23 08:57:05.392 INFO [orders,3c526066b205402a,acb1c0fc61191c83,false] 8 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×2)
  08:57:07.035 [front-end] Order response: {"statusCode":201,"body":{"id":"674198e33f7706000886538a","customerId":"674198caa437380001deff7d","customer":{"id":null,"firstName":"vidoaLMiMZn
  08:57:08.980 [queue-master] 2024-11-23 08:57:08.980 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×51)
  08:57:09.152 [front-end] Order response: {"id":"674198e53f7706000886538c","customerId":"674198d2a437380001deff95","customer":{"id":null,"firstName":"zUGYrCgol","lastName":"zUGYrCgol","u
  08:57:11.533 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×6)
  08:57:13.005 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  08:57:14.121 [front-end] Posting Customer: {"username":"JCYeKSjM","password":"MYIoBCiY","email":"JCYeKSjM@gmail.com","firstName":"JCYeKSjM","lastName":"JCYeKSjM"}
  08:57:15.678 [front-end] Order response: {"id":"674198eb3f7706000886538f","customerId":"674198cfa437380001deff8c","customer":{"id":null,"firstName":"FygEtnQmntW","lastName":"FygEtnQmntW
  08:57:18.424 [user] ts=2024-11-23T08:57:18.424838811Z caller=middlewares.go:46 method=Register username=bqLFOFtK email=bqLFOFtK@gmail.com took=2.548455ms
  08:57:19.305 [front-end] Received response: "{\"firstName\":\"aXWRmKRnN\",\"lastName\":\"aXWRmKRnN\",\"username\":\"aXWRmKRnN\",\"id\":\"674198d9a437380001deffa4\",\"_links\":{\"address
  08:57:22.096 [front-end] Posting Customer: {"username":"ErqkMC","password":"qwrMe","email":"ErqkMC@gmail.com","firstName":"ErqkMC","lastName":"ErqkMC"}
  08:57:24.110 [front-end] Order response: {"id":"674198f43f77060008865392","customerId":"674198dfa437380001deffad","customer":{"id":null,"firstName":"wqgJPHku","lastName":"wqgJPHku","use
  08:57:25.404 [front-end] Order response: {"id":"674198f53f77060008865393","customerId":"674198e2a437380001deffb0","customer":{"id":null,"firstName":"tVFCKe","lastName":"tVFCKe","usernam
  08:57:26.581 [front-end] Received response: "{\"firstName\":\"aQTVfKPpOQTV\",\"lastName\":\"aQTVfKPpOQTV\",\"username\":\"aQTVfKPpOQTV\",\"id\":\"674198e5a437380001deffb4\",\"_links\":{
  08:57:27.415 [front-end] Order response: {"statusCode":201,"body":{"id":"674198f73f77060008865398","customerId":"674198dda437380001deffa9","customer":{"id":null,"firstName":"eWMmgZPhWLI
  08:57:30.058 [front-end] Order response: {"id":"674198fa3f77060008865399","customerId":"674198e7a437380001deffbe","customer":{"id":null,"firstName":"bVfUCqC","lastName":"bVfUCqC","usern
  08:57:30.866 [front-end] Order response: {"statusCode":201,"body":{"id":"674198fa3f7706000886539b","customerId":"674198e9a437380001deffc1","customer":{"id":null,"firstName":"KHUge","las

## p0841
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-08T12:54:59.642Z
```
{"timestamp":1733662499642725600,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-glwxh","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-08 12:54:59.642  INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl         : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-53c8-4438-87c8-0321a4d09917, stations=[suzhou, shanghai], distances=[0, 50], startStationId=suzhou, terminalStationId=shanghai})"}
```
Same service, the 2 minutes before (oldest first):
  12:54:52.609 [ts-travel-service] 2024-12-08 12:54:52.609 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Route is: Route{id='aefcef3f-3f42-46e8-afd7-6cb2a928bd3d', stations=[nan  (×5)
  12:54:52.617 [ts-travel-service] 2024-12-08 12:54:52.617 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：a3f256c1-0e43-4f7d-9c21-121bf  (×7)
  12:54:52.622 [ts-travel-service] 2024-12-08 12:54:52.621 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×2)
  12:54:52.633 [ts-travel-service] 2024-12-08 12:54:52.633 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  12:54:52.633 [ts-travel-service] 2024-12-08 12:54:52.633 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  12:54:52.644 [ts-travel-service] 2024-12-08 12:54:52.644 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  12:54:52.644 [ts-travel-service] 2024-12-08 12:54:52.644 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha
  12:54:59.592 [ts-travel-service] 2024-12-08 12:54:59.592 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  12:54:59.609 [ts-travel-service] 2024-12-08 12:54:59.609 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
All services, 30 seconds either side (sampled):
  12:54:30.054 [ts-admin-basic-info-service] 2024-12-08 12:54:30.054 INFO 1 --- [io-18767-exec-3] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×12)
  12:54:32.245 [ts-route-service] 2024-12-08 12:54:32.244 INFO 1 --- [io-11178-exec-7] route.controller.RouteController : Route id: f3d4d4ef-693b-4456-8eed-59c0d717dd08  (×234)
  12:54:36.797 [ts-route-service] 2024-12-08 12:54:36.796 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×26)
  12:54:36.889 [ts-auth-service] 2024-12-08 12:54:36.888 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×9)
  12:54:37.386 [ts-basic-service] 2024-12-08 12:54:37.386 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×19)
  12:54:37.417 [ts-order-other-service] 2024-12-08 12:54:37.417 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:0  (×12)
  12:54:37.497 [ts-order-other-service] 2024-12-08 12:54:37.496 INFO 1 --- [io-12032-exec-9] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=178781  (×9)
  12:54:37.949 [ts-auth-service] 2024-12-08 12:54:37.949 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×3)
  12:54:40.762 [ts-admin-travel-service] 2024-12-08 12:54:40.761 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×4)
  12:54:40.853 [ts-basic-service] 2024-12-08 12:54:40.853 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：92708982-77
  12:54:40.893 [ts-order-service] 2024-12-08 12:54:40.893 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×8)
  12:54:41.015 [ts-order-service] 2024-12-08 12:54:41.015 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024  (×3)
  12:54:41.345 [ts-basic-service] 2024-12-08 12:54:41.345 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieT
  12:54:41.556 [ts-travel-service] 2024-12-08 12:54:41.556 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×2)
  12:54:50.824 [ts-travel2-service] 2024-12-08 12:54:50.824 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×6)
  12:54:59.843 [ts-basic-service] 2024-12-08 12:54:59.843 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou  (×4)
  12:55:00.599 [ts-seat-service] 2024-12-08 12:55:00.599 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×2)
  12:55:11.770 [ts-order-mongo] {"t":{"$date":"2024-12-08T12:55:11.770+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366251
  12:55:12.520 [ts-order-other-mongo] {"t":{"$date":"2024-12-08T12:55:12.520+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366251
  12:55:14.732 [ts-assurance-mongo] {"t":{"$date":"2024-12-08T12:55:14.732+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366251
  12:55:17.919 [ts-basic-service] 2024-12-08 12:55:17.919 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f
  12:55:23.476 [ts-preserve-service] 2024-12-08 12:55:23.476 INFO 1 --- [io-14568-exec-6] preserve.controller.PreserveController : [Preserve Service][Preserve] Account order from Shang Hai -----> S
  12:55:23.520 [ts-security-service] 2024-12-08 12:55:23.519 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Last One Hour:
  12:55:23.540 [ts-preserve-service] 2024-12-08 12:55:23.540 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service][Step 2] Complete
  12:55:23.847 [ts-preserve-service] 2024-12-08 12:55:23.847 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Station Name]  (×2)
  12:55:23.974 [ts-order-service] 2024-12-08 12:55:23.974 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at 
  12:55:24.002 [ts-food-service] 2024-12-08 12:55:24.001 INFO 1 --- [io-18856-exec-5] foodsearch.service.FoodServiceImpl : [Food-Service][AddFoodOrder] Success.
  12:55:26.209 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:55:26 +0800] "POST /api/v1/orderOtherService/orderOther/refresh HTTP/1.1" 200 51561 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10

## p0742
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service paymentservice, 2024-11-23T12:54:21.910Z
```
{"timestamp":1732366461910756400,"container_name":"paymentservice","pod_name":"paymentservice-856946df7c-bvqd6","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"UnacceptedCreditCard [Error]: Sorry, we cannot process visa_electron credit cards. Only VISA or MasterCard is accepted.\n    at charge (/usr/src/app/charge.js:74:68)\n    at HipsterShopServer.ChargeServiceHandler (/usr/src/app/server.js:44:24)\n    at clientStreamAndUnaryHandler (/usr/src/app/node_modules/@opentelemetry/instrumentation-grpc/build/src/serverUtils.js:97:21)\n    at Object.handleServerFu…"}
```
Same service, the 2 minutes before (oldest first):
  12:53:43.045 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"35","nanos":960000000},"credit_card":{"credit_card_number":"453332005144021  (×3)
  12:53:43.045 [paymentservice] Transaction processed: visa ending 0212 Amount: USD35.960000000  (×3)
  12:53:51.905 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"289","nanos":651599291},"credit_card":{"credit_card_number":"43606788402827  (×2)
  12:53:51.905 [paymentservice] Transaction processed: visa ending 2759 Amount: GBP289.651599291  (×2)
  12:53:55.800 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"131","nanos":729323311},"credit_card":{"credit_card_number":"45454017957548  (×2)
  12:53:55.800 [paymentservice] Transaction processed: visa ending 4849 Amount: EUR131.729323311  (×2)
  12:54:14.122 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"152175","nanos":313579492},"credit_card":{"credit_card_number":"42833216059  (×2)
  12:54:14.122 [paymentservice] Transaction processed: visa ending 7172 Amount: JPY152175.313579492
  12:54:16.618 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"698","nanos":502937650},"credit_card":{"credit_card_number":"44377804832301
  12:54:16.618 [paymentservice] Transaction processed: visa ending 0126 Amount: TRY698.502937650
  12:54:21.908 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
All services, 30 seconds either side (sampled):
  12:53:51.912 [cartservice] EmptyCartAsync called with userId=931a1dee-a1ff-459e-84f4-7a7d7e884cd2  (×12)
  12:53:51.920 [frontend] order placed  (×12)
  12:53:51.943 [frontend] request complete  (×326)
  12:53:52.232 [cartservice] GetCartAsync called with userId=e0a6797b-7b87-4f32-b2dd-31c00e8def69  (×266)
  12:53:52.409 [adservice] received ad request (context_words=[decor, home])  (×14)
  12:53:52.643 [cartservice] AddItemAsync called with userId=5610460a-814f-43e0-96b6-68f36171d3ca, productId=L9ECAV7KIM, quantity=2  (×37)
  12:53:52.676 [shippingservice] [GetQuote] completed request  (×78)
  12:53:52.724 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"378","nanos":370000000},"credit_card":{"credit_card_number":"40197025623414  (×2)
  12:53:52.729 [shippingservice] [ShipOrder] received request  (×11)
  12:53:52.740 [checkoutservice] order confirmation email sent to "mariahzuniga@example.com"
  12:53:53.152 [adservice] received ad request (context_words=[clothing, tops])  (×21)
  12:53:53.958 [frontend] ENV_PLATFORM is: aws  (×34)
  12:53:55.057 [redis] 1:M 23 Nov 2024 12:53:55.056 * Background saving started by pid 32
  12:53:55.111 [adservice] received ad request (context_words=[hair, beauty])  (×14)
  12:53:55.205 [checkoutservice] order confirmation email sent to "brent81@example.net"
  12:53:55.800 [paymentservice] Transaction processed: visa ending 4849 Amount: EUR131.729323311  (×3)
  12:53:57.531 [checkoutservice] [PlaceOrder] user_id="706f37f6-1c4e-4686-b19d-4ff2d2c889ad" user_currency="GBP"  (×2)
  12:53:57.561 [emailservice] A request to send order confirmation email to jimmylowe@example.org has been received.
  12:54:08.026 [emailservice] A request to send order confirmation email to cartertheresa@example.org has been received.
  12:54:14.122 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"152175","nanos":313579492},"credit_card":{"credit_card_number":"42833216059  (×3)
  12:54:14.136 [checkoutservice] order confirmation email sent to "tracy54@example.org"
  12:54:16.618 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"698","nanos":502937650},"credit_card":{"credit_card_number":"44377804832301
  12:54:16.632 [checkoutservice] order confirmation email sent to "julie54@example.com"
  12:54:21.908 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  12:54:22.123 [checkoutservice] [PlaceOrder] user_id="931a1dee-a1ff-459e-84f4-7a7d7e884cd2" user_currency="CAD"
  12:54:22.149 [emailservice] A request to send order confirmation email to paulskinner@example.net has been received.
  12:54:41.548 [checkoutservice] order confirmation email sent to "zgarner@example.com"
  12:54:48.896 [emailservice] A request to send order confirmation email to websterchristopher@example.org has been received.

## p0251
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:05.175Z
```
{"timestamp":1732242485175703800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Customer: {\"username\":\"vvgsHcY\",\"password\":\"qfZoo\",\"email\":\"vvgsHcY@gmail.com\",\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\"}"}
```
Same service, the 2 minutes before (oldest first):
  02:28:05.047 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec25b0df5c00019af930\",\"_links\":{\"  (×2)
  02:28:05.047 [front-end] [ undefined, undefined ]  (×2)
  02:28:05.047 [front-end] Posting Order: {"customer":"http://user/customers/673fec1db0df5c00019af90f","address":"http://user/addresses/673fec25b0df5c00019af92f","card":"http://user/cards  (×2)
  02:28:05.062 [front-end] User cart deleted with status: 503
  02:28:05.065 [front-end] DELETE /cart 503 - ms - -
  02:28:05.071 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  02:28:05.078 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af952/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  02:28:05.097 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:05.097 [front-end] Order response: {"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:05.100 [front-end] POST /orders 500 - ms - -
  02:28:05.146 [front-end] POST /cart 500 72.021 ms - 64
  02:28:05.160 [front-end] Request received with body: {}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:05.166 [front-end] GET Request to: http://user/customers/673fec20b0df5c00019af91e/addresses  (×2)
  02:28:05.172 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×32)
  02:28:03.118 [catalogue] ts=2024-11-22T02:28:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.040202ms  (×36)
  02:28:03.190 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af953/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×18)
  02:28:03.211 [user] ts=2024-11-22T02:28:03.211690554Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=1.207621ms  (×36)
  02:28:03.252 [front-end] POST /orders 500 - ms - -  (×30)
  02:28:03.410 [front-end] Carts merged.  (×31)
  02:28:04.929 [front-end] Posting Customer: {"username":"JGQXvUjPbFrtK","password":"HtglbTyNG","email":"JGQXvUjPbFrtK@gmail.com","firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPbFrtK"}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:07.408 [front-end] Received response: "{\"firstName\":\"iTdzWTHcUAJJ\",\"lastName\":\"iTdzWTHcUAJJ\",\"username\":\"iTdzWTHcUAJJ\",\"id\":\"673fec22b0df5c00019af923\",\"_links\":{
  02:28:09.014 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×4)
  02:28:10.451 [carts] 2024-11-22 02:28:10.451 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  02:28:11.653 [user] ts=2024-11-22T02:28:11.653746097Z caller=middlewares.go:75 method=GetUsers id=673fec2ab0df5c00019af942 result=1 took=692µs
  02:28:14.311 [front-end] Posting Customer: {"username":"AIwPgMB","password":"ciKTe","email":"AIwPgMB@gmail.com","firstName":"AIwPgMB","lastName":"AIwPgMB"}
  02:28:16.228 [front-end] Posting Customer: {"username":"yTFoonPwqaY","password":"UsabiUKuuH","email":"yTFoonPwqaY@gmail.com","firstName":"yTFoonPwqaY","lastName":"yTFoonPwqaY"}
  02:28:17.978 [front-end] Posting Customer: {"username":"XaRPipq","password":"IPVIE","email":"XaRPipq@gmail.com","firstName":"XaRPipq","lastName":"XaRPipq"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.114 [front-end] Received response: "{\"firstName\":\"bCCZHBaYc\",\"lastName\":\"bCCZHBaYc\",\"username\":\"bCCZHBaYc\",\"id\":\"673fec31b0df5c00019af95b\",\"_links\":{\"address
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=673ns  (×9)
  02:28:23.749 [front-end] Posting Customer: {"username":"bhZuEQ","password":"CYefrd","email":"bhZuEQ@gmail.com","firstName":"bhZuEQ","lastName":"bhZuEQ"}
  02:28:24.870 [front-end] Received response: "{\"firstName\":\"sgQXbZQ\",\"lastName\":\"sgQXbZQ\",\"username\":\"sgQXbZQ\",\"id\":\"673fec33b0df5c00019af963\",\"_links\":{\"addresses\":{
  02:28:25.471 [front-end] Received response: "{\"firstName\":\"TcTuIokN\",\"lastName\":\"TcTuIokN\",\"username\":\"TcTuIokN\",\"id\":\"673fec32b0df5c00019af95c\",\"_links\":{\"addresses\
  02:28:25.838 [carts] 2024-11-22 02:28:25.837 INFO [carts,041812a6e38b1a0d,28fc13fb8146605a,false] 7 --- [-nio-80-exec-10] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×8)
  02:28:26.670 [orders-db] {"t":{"$date":"2024-11-22T02:28:26.670+00:00"},"s":"I", "c":"STORAGE", "id":20279, "ctx":"conn2","msg":"Conflicted creating a collection","attr":{"namespace":"d
  02:28:26.957 [front-end] Order response: {"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","lastName":"vuOxCKL","usern
  02:28:26.962 [front-end] Order response: {"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPb
  02:28:27.060 [front-end] Order response: {"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","lastName":"HFHBXn","usernam
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.842 [front-end] Posting Customer: {"username":"UsfOoRUlayKw","password":"RviRN","email":"UsfOoRUlayKw@gmail.com","firstName":"UsfOoRUlayKw","lastName":"UsfOoRUlayKw"}
  02:28:32.341 [queue-master] Caused by: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket
  02:28:32.649 [queue-master] 2024-11-22 02:28:32.649 ERROR 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×4)

## p0617
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-07T20:16:57.625Z
```
{"timestamp":1733602617625460000,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-67hjc","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 20:16:57.625  INFO 1 --- [       Thread-5] o.s.c.support.DefaultLifecycleProcessor  : Stopping beans in phase 0"}
```
Same service, the 2 minutes before (oldest first):
  20:16:49.040 [ts-route-service] 2024-12-07 20:16:49.039 INFO 1 --- [io-11178-exec-5] route.controller.RouteController : Route id: 1367db1f-461e-4ab7-87ad-2bcc05fd9cb7  (×17)
  20:16:53.863 [ts-route-service] 2024-12-07 20:16:53.863 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 084837bb-53c8-4438-87c8-0321a4d09917  (×2)
  20:16:57.621 [ts-route-service] 2024-12-07 20:16:57.621 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
All services, 30 seconds either side (sampled):
  20:16:27.706 [ts-auth-service] 2024-12-07 20:16:27.706 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×12)
  20:16:27.967 [ts-auth-service] 2024-12-07 20:16:27.967 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×27)
  20:16:28.023 [ts-travel2-service] 2024-12-07 20:16:28.023 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×68)
  20:16:28.066 [ts-price-service] 2024-12-07 20:16:28.065 INFO 1 --- [io-16579-exec-5] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×4)
  20:16:28.085 [ts-order-other-service] 2024-12-07 20:16:28.085 INFO 1 --- [io-12032-exec-1] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×4)
  20:16:28.145 [ts-travel2-service] 2024-12-07 20:16:28.145 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×8)
  20:16:28.174 [ts-travel-service] 2024-12-07 20:16:28.173 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×49)
  20:16:28.209 [ts-travel-service] 2024-12-07 20:16:28.209 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×8)
  20:16:28.247 [ts-seat-service] 2024-12-07 20:16:28.247 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×4)
  20:16:28.324 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:28 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×8)
  20:16:30.117 [ts-basic-service] 2024-12-07 20:16:30.117 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×4)
  20:16:30.290 [ts-order-other-service] 2024-12-07 20:16:30.290 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×2)
  20:16:30.901 [ts-auth-mongo] {"t":{"$date":"2024-12-07T20:16:30.901+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360259
  20:16:31.291 [ts-order-other-service] 2024-12-07 20:16:31.291 INFO 1 --- [io-12032-exec-9] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 60
  20:16:31.556 [ts-consign-service] 2024-12-07 20:16:31.556 INFO 1 --- [io-16111-exec-1] consign.service.ConsignServiceImpl : The handle date is 2024-12-07  (×2)
  20:16:31.653 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:16:31.653+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360259
  20:16:31.816 [ts-travel2-service] 2024-12-07 20:16:31.816 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  20:16:32.958 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:32 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 5994 "-" "Mozilla/5.0 (Macintosh;  (×2)
  20:16:40.693 [ts-auth-service] 2024-12-07 20:16:40.693 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×2)
  20:16:42.649 [ts-basic-service] 2024-12-07 20:16:42.649 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  20:16:42.675 [ts-basic-service] 2024-12-07 20:16:42.675 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3
  20:16:46.989 [ts-order-service] 2024-12-07 20:16:46.988 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-4cf1-
  20:16:48.369 [ts-food-service] 2024-12-07 20:16:48.369 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:16:57.626 [ts-route-service] 2024-12-07 20:16:57.625 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  20:16:58.394 [ts-travel-service] 2024-12-07 20:16:58.394 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×2)
  20:17:02.705 [ts-admin-travel-service] 2024-12-07 20:17:02.705 ERROR 1 --- [io-16114-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×7)
  20:17:24.657 [ts-route-service] 2024-12-07 20:17:24.562 INFO 1 --- [ main] route.RouteApplication : Starting RouteApplication v1.0 on ts-route-service-6f78466fb7-9ll65 with PID 1 (/app/ts-rout

## p0823
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-08T12:12:23.664Z
```
{"timestamp":1733659943664675800,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-hq66v","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-08 12:12:23.664  INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl             : [SeatService getLeftTicketOfInterval] The request seat type is confortClass and the total num is 2147483647"}
```
Same service, the 2 minutes before (oldest first):
  12:12:18.785 [ts-seat-service] 2024-12-08 12:12:18.785 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  12:12:21.988 [ts-seat-service] 2024-12-08 12:12:21.988 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×3)
  12:12:21.988 [ts-seat-service] 2024-12-08 12:12:21.988 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×3)
  12:12:22.003 [ts-seat-service] 2024-12-08 12:12:22.003 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×3)
  12:12:22.013 [ts-seat-service] 2024-12-08 12:12:22.012 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×2)
  12:12:22.033 [ts-seat-service] 2024-12-08 12:12:22.033 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×3)
  12:12:22.034 [ts-seat-service] 2024-12-08 12:12:22.033 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  12:12:22.115 [ts-seat-service] 2024-12-08 12:12:22.115 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
  12:12:23.649 [ts-seat-service] 2024-12-08 12:12:23.649 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
All services, 30 seconds either side (sampled):
  12:11:55.409 [ts-admin-basic-info-service] 2024-12-08 12:11:55.409 INFO 1 --- [io-18767-exec-6] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×9)
  12:11:57.250 [ts-basic-service] 2024-12-08 12:11:57.249 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×65)
  12:11:57.314 [ts-basic-service] 2024-12-08 12:11:57.314 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×4)
  12:11:57.353 [ts-order-other-service] 2024-12-08 12:11:57.353 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 101  (×9)
  12:11:57.433 [ts-order-other-service] 2024-12-08 12:11:57.433 INFO 1 --- [io-12032-exec-8] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×23)
  12:11:57.564 [ts-travel2-service] 2024-12-08 12:11:57.563 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×11)
  12:12:00.048 [ts-travel-service] 2024-12-08 12:12:00.048 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×10)
  12:12:00.617 [ts-order-service] 2024-12-08 12:12:00.617 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Query Order][Step 1] Get Orders Number of Account: 135  (×2)
  12:12:02.142 [ts-travel2-service] 2024-12-08 12:12:02.142 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×12)
  12:12:02.367 [ts-travel2-service] 2024-12-08 12:12:02.367 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  12:12:04.565 [ts-travel-service] 2024-12-08 12:12:04.564 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×17)
  12:12:04.674 [ts-travel-service] 2024-12-08 12:12:04.674 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, tr  (×13)
  12:12:04.785 [ts-seat-service] 2024-12-08 12:12:04.785 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  12:12:04.856 [ts-seat-service] 2024-12-08 12:12:04.856 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×10)
  12:12:05.382 [ts-basic-service] 2024-12-08 12:12:05.382 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：a3f256c1-0e
  12:12:11.648 [ts-station-mongo] {"t":{"$date":"2024-12-08T12:12:11.648+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365993
  12:12:12.493 [ts-travel2-mongo] {"t":{"$date":"2024-12-08T12:12:12.493+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365993
  12:12:14.209 [ts-assurance-mongo] {"t":{"$date":"2024-12-08T12:12:14.209+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365993
  12:12:15.025 [ts-seat-service] 2024-12-08 12:12:15.024 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  12:12:19.100 [ts-consign-service] 2024-12-08 12:12:19.099 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : SAVE consign result : ConsignRecord(id=7949984a-4804-4a17-9c94-43aeeb2
  12:12:25.492 [ts-basic-service] 2024-12-08 12:12:25.492 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×3)
  12:12:25.536 [ts-basic-service] 2024-12-08 12:12:25.536 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : route.getDistances().size : 3  (×2)
  12:12:29.048 [ts-travel-service] 2024-12-08 12:12:29.047 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  12:12:37.358 [ts-basic-service] 2024-12-08 12:12:37.358 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69
  12:12:37.436 [ts-route-service] 2024-12-08 12:12:37.435 INFO 1 --- [ Thread-5] o.s.j.e.a.AnnotationMBeanExporter : Unregistering JMX-exposed beans on shutdown
  12:12:38.823 [ts-admin-travel-service] 2024-12-08 12:12:38.822 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]
  12:12:39.774 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:12:39 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 500 265 "-" "Mozilla/5.0 (Macintosh; 

## p0640
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T20:25:02.502Z
```
{"timestamp":1733603102502747400,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-w6jt4","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:25:02.502  INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl         : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainNumber='D1345', startStation='shanghai', destStation='suzhou', seatType=3}"}
```
Same service, the 2 minutes before (oldest first):
  20:25:02.204 [ts-travel-service] 2024-12-07 20:25:02.204 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
  20:25:02.204 [ts-travel-service] 2024-12-07 20:25:02.204 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan
  20:25:02.204 [ts-travel-service] 2024-12-07 20:25:02.204 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：084837bb-53c8-4438-87c8-0321a  (×3)
  20:25:02.260 [ts-travel-service] 2024-12-07 20:25:02.260 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  20:25:02.260 [ts-travel-service] 2024-12-07 20:25:02.260 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  20:25:02.265 [ts-travel-service] 2024-12-07 20:25:02.265 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×2)
  20:25:02.265 [ts-travel-service] 2024-12-07 20:25:02.265 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×2)
  20:25:02.316 [ts-travel-service] 2024-12-07 20:25:02.316 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s
  20:25:02.325 [ts-travel-service] 2024-12-07 20:25:02.325 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat
  20:25:02.339 [ts-travel-service] 2024-12-07 20:25:02.338 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×2)
  20:25:02.353 [ts-travel-service] 2024-12-07 20:25:02.353 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×2)
  20:25:02.353 [ts-travel-service] 2024-12-07 20:25:02.353 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr
  20:25:02.360 [ts-travel-service] 2024-12-07 20:25:02.359 INFO 1 --- [io-12346-exec-4] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  20:25:02.473 [ts-travel-service] 2024-12-07 20:25:02.473 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter
All services, 30 seconds either side (sampled):
  20:24:33.231 [ts-auth-service] 2024-12-07 20:24:33.231 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×12)
  20:24:33.439 [ts-travel2-service] 2024-12-07 20:24:33.438 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×131)
  20:24:33.489 [ts-basic-service] 2024-12-07 20:24:33.489 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×67)
  20:24:33.539 [ts-food-map-service] 2024-12-07 20:24:33.538 INFO 1 --- [io-18855-exec-8] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×4)
  20:24:33.558 [ts-travel2-service] 2024-12-07 20:24:33.558 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236
  20:24:33.600 [ts-seat-service] 2024-12-07 20:24:33.600 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×7)
  20:24:33.682 [ts-seat-service] 2024-12-07 20:24:33.682 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×51)
  20:24:36.697 [ts-basic-service] 2024-12-07 20:24:36.697 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×3)
  20:24:36.839 [ts-seat-service] 2024-12-07 20:24:36.839 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×27)
  20:24:37.592 [ts-admin-basic-info-service] 2024-12-07 20:24:37.592 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin 
  20:24:43.290 [ts-order-other-mongo] {"t":{"$date":"2024-12-07T20:24:43.290+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360308
  20:24:47.636 [ts-travel-service] 2024-12-07 20:24:47.636 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×25)
  20:24:47.789 [ts-order-service] 2024-12-07 20:24:47.789 INFO 1 --- [io-12031-exec-8] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×13)
  20:24:47.938 [ts-travel-service] 2024-12-07 20:24:47.938 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×18)
  20:24:49.022 [ts-travel-service] 2024-12-07 20:24:49.022 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×5)
  20:24:57.126 [ts-consign-service] 2024-12-07 20:24:57.126 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] 307e4f63-7344-411b-b441-  (×3)
  20:24:58.460 [ts-contacts-service] 2024-12-07 20:24:58.460 INFO 1 --- [io-12347-exec-7] contacts.controller.ContactsController : [Contacts Service][Find Contacts By Account Id: 4d2a46c7-71cb-4cf1  (×2)
  20:24:58.493 [ts-order-service] 2024-12-07 20:24:58.493 INFO 1 --- [io-12031-exec-6] order.controller.OrderController : [Order Other Service][Security Info Get] 4d2a46c7-71cb-4cf1-b5bb-b68406d  (×2)
  20:24:58.585 [ts-preserve-service] 2024-12-07 20:24:58.585 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Getting....  (×2)
  20:24:58.641 [ts-travel-service] 2024-12-07 20:24:58.641 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×10)
  20:24:58.899 [ts-preserve-service] 2024-12-07 20:24:58.899 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Station Name]  (×4)
  20:24:59.014 [ts-order-service] 2024-12-07 20:24:59.014 INFO 1 --- [io-12031-exec-5] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at   (×2)
  20:24:59.046 [ts-preserve-service] 2024-12-07 20:24:59.046 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Food Service]!!!!!!!!!!!!!!!foodstore= 2 Su Zhou Roman Holiday  (×2)
  20:24:59.077 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:24:59 +0800] "POST /api/v1/preserveservice/preserve HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWeb  (×2)
  20:25:10.125 [ts-seat-service] 2024-12-07 20:25:10.125 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:25:12.561 [ts-basic-service] 2024-12-07 20:25:12.561 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270  (×5)
  20:25:12.813 [ts-order-service] 2024-12-07 20:25:12.813 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×3)
  20:25:13.641 [ts-travel-service] 2024-12-07 20:25:13.641 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  20:25:28.263 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T20:25:28.263+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360312
  20:25:31.292 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T20:25:31.292+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360313

## p0047
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T08:05:33.441Z
```
{"service":"dbservice2","message":"2021-08-13 08:05:33,441 | ERROR | 0.0.0.2 | dbservice2 | db_helper.py -> db_login_methods -> 42 | 5763954341187494 | dbservice2 access redis service denied"}
```
Same service, the 2 minutes before (oldest first):
  08:05:23.433 [dbservice2] ERROR dbservice2 access redis service denied  (×5)
  08:05:25.538 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:05:25.538 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  08:05:25.553 [dbservice2] ERROR service refuse  (×5)
All services, 30 seconds either side (sampled):
  08:05:03.452 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×53)
  08:05:03.543 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×53)
  08:05:03.633 [dbservice2] ERROR dbservice2 access redis service denied  (×43)
  08:05:03.912 [webservice1] INFO complete information: {'uuid': '1c0e4d5c-fbca-11eb-b934-0242ac110003', 'user_id': 'afgSwRro'}  (×51)
  08:05:04.016 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '1c0e4d5c-fbca-11eb-b934-0242ac110003', 'value': 'afgSwRro'}  (×42)
  08:05:04.524 [webservice2] INFO complete information: {'uuid': '1c6b6b2c-fbca-11eb-b413-0242ac110004', 'user_id': 'rDnqUwke'}  (×45)
  08:05:04.936 [webservice2] ERROR an error occurred in the downstream service  (×20)
  08:05:05.525 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  08:05:05.766 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×58)
  08:05:07.498 [mobservice2] INFO info 1e1b7c96-fbca-11eb-9d19-0242ac110004:LEFinroh write success
  08:05:09.358 [mobservice2] INFO info 1f3700f0-fbca-11eb-90a1-0242ac110003:rnAReBSk write success
  08:05:12.615 [mobservice1] INFO info 212207e8-fbca-11eb-82d8-0242ac110004:LEFinroh write success
  08:05:16.357 [mobservice1] INFO info 236187cc-fbca-11eb-ad0e-0242ac110004:ISmxpnEs write success
  08:05:19.598 [mobservice1] INFO info 254827a8-fbca-11eb-9c82-0242ac110004:GEFNbRmp write success
  08:05:22.042 [dbservice1] INFO 2671f4ce-fbca-11eb-af5f-0242ac110004-dsqULkKQ-zLV!t_x^6AM( token generate success token=MTYyODgxMzEyMi4wNDIxMDYyOjI2NzFmNGNlLWZiY2EtMTFlYi1hZjVmLTAyNDJhYzE
  08:05:24.799 [mobservice1] INFO info 2867ad46-fbca-11eb-afe9-0242ac110004:Jcofhzdp write success
  08:05:27.498 [dbservice1] INFO 29d5f8c2-fbca-11eb-b16b-0242ac110004-PQTXyvDH-<gtzUvdoS?4) token generate success token=MTYyODgxMzEyNy40OTc4OTcxOjI5ZDVmOGMyLWZiY2EtMTFlYi1iMTZiLTAyNDJhYzE
  08:05:29.758 [dbservice1] INFO 2b339fe4-fbca-11eb-b208-0242ac110004-avTqnNxg-L$C9/.km:^B% token generate success token=MTYyODgxMzEyOS43NTgzNzY2OjJiMzM5ZmU0LWZiY2EtMTFlYi1iMjA4LTAyNDJhYzE
  08:05:32.479 [dbservice1] INFO 2c98ea42-fbca-11eb-b638-0242ac110003-aRNnXZPl-Eq0%L#J(4Boe token generate success token=MTYyODgxMzEzMi40NzkxNTI3OjJjOThlYTQyLWZiY2EtMTFlYi1iNjM4LTAyNDJhYzE
  08:05:36.296 [mobservice1] INFO info 2f3ac7ca-fbca-11eb-9ca7-0242ac110003:pkiwOTAa write success
  08:05:38.987 [mobservice2] INFO info 30d880f4-fbca-11eb-a64c-0242ac110003:IYcJLxjh write success
  08:05:42.166 [mobservice1] INFO info 32b557bc-fbca-11eb-89d3-0242ac110004:GxrcRlDj write success
  08:05:45.145 [mobservice1] INFO info 347b54c0-fbca-11eb-97c4-0242ac110003:VnGSpqai write success
  08:05:48.624 [mobservice2] INFO info 369fbcb4-fbca-11eb-9e05-0242ac110004:lrWJDxNP write success
  08:05:51.267 [dbservice1] INFO 37cdf5ba-fbca-11eb-af12-0242ac110003-pUwNWoxq-_C3N12wp$FLv token generate success token=MTYyODgxMzE1MS4yNjcwMDg4OjM3Y2RmNWJhLWZiY2EtMTFlYi1hZjEyLTAyNDJhYzE
  08:05:54.041 [dbservice1] INFO 3979664c-fbca-11eb-a1bb-0242ac110003-SZKcrGIR-xPE^X0ln_KYI token generate success token=MTYyODgxMzE1NC4wNDE1OTA1OjM5Nzk2NjRjLWZiY2EtMTFlYi1hMWJiLTAyNDJhYzE
  08:05:57.032 [dbservice1] INFO 3b50b8bc-fbca-11eb-ab62-0242ac110004-aejQpHvi-63rjB42m(_JT token generate success token=MTYyODgxMzE1Ny4wMzIxMjQ1OjNiNTBiOGJjLWZiY2EtMTFlYi1hYjYyLTAyNDJhYzE
  08:05:59.493 [dbservice1] INFO 3ceaef94-fbca-11eb-8055-0242ac110004-DtNVdFIW-^*x0{Xp?zMmG token generate success token=MTYyODgxMzE1OS40OTI1NDI1OjNjZWFlZjk0LWZiY2EtMTFlYi04MDU1LTAyNDJhYzE
  08:06:02.285 [mobservice1] INFO info 3ebd4eb6-fbca-11eb-b9a6-0242ac110004:hpcKRNdx write success

## p0623
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-07T20:17:46.368Z
```
{"timestamp":1733602666368827400,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-9ll65","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:17:46.368  INFO 1 --- [           main] org.mongodb.driver.cluster               : Cluster created with settings {hosts=[ts-route-mongo:27017], mode=MULTIPLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}"}
```
Same service, the 2 minutes before (oldest first):
  20:17:37.571 [ts-route-service] 2024-12-07 20:17:37.570 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.access.expression.method.DefaultMethodS
  20:17:37.577 [ts-route-service] 2024-12-07 20:17:37.577 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.method.configuration.
  20:17:37.664 [ts-route-service] 2024-12-07 20:17:37.664 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  20:17:38.176 [ts-route-service] 2024-12-07 20:17:38.176 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact
  20:17:38.178 [ts-route-service] 2024-12-07 20:17:38.178 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [java.util.Properties] is not e
  20:17:41.056 [ts-route-service] 2024-12-07 20:17:41.055 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 11178 (http)
  20:17:41.268 [ts-route-service] 2024-12-07 20:17:41.268 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  20:17:41.268 [ts-route-service] 2024-12-07 20:17:41.268 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43
  20:17:42.177 [ts-route-service] 2024-12-07 20:17:42.176 INFO 1 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  20:17:42.177 [ts-route-service] 2024-12-07 20:17:42.176 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 16914 ms
  20:17:43.865 [ts-route-service] 2024-12-07 20:17:43.864 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricsFilter' to: [/*]  (×8)
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] .s.DelegatingFilterProxyRegistrationBean : Mapping filter: 'springSecurityFilterChain' to: [/*]
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
All services, 30 seconds either side (sampled):
  20:17:17.642 [ts-admin-basic-info-service] 2024-12-07 20:17:17.642 INFO 1 --- [io-18767-exec-7] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×14)
  20:17:18.177 [ts-basic-service] 2024-12-07 20:17:18.177 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×18)
  20:17:19.310 [ts-admin-travel-service] 2024-12-07 20:17:19.309 INFO 1 --- [io-16114-exec-7] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×14)
  20:17:21.435 [ts-travel2-service] 2024-12-07 20:17:21.434 ERROR 1 --- [io-16346-exec-6] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×8)
  20:17:27.209 [ts-travel-service] 2024-12-07 20:17:27.209 ERROR 1 --- [o-12346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  20:17:29.352 [ts-travel-service] 2024-12-07 20:17:29.352 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×2)
  20:17:31.156 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T20:17:31.156+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:32.254 [ts-order-mongo] {"t":{"$date":"2024-12-07T20:17:32.253+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:36.164 [ts-route-service] 2024-12-07 20:17:36.163 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def
  20:17:37.568 [ts-route-service] 2024-12-07 20:17:37.568 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'objectPostProcessor' of type [org.springframework.security.config.an
  20:17:38.763 [ts-food-service] 2024-12-07 20:17:38.763 INFO 1 --- [io-18856-exec-5] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:17:41.268 [ts-route-service] 2024-12-07 20:17:41.268 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] .s.DelegatingFilterProxyRegistrationBean : Mapping filter: 'springSecurityFilterChain' to: [/*]
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.165 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{startId}/{terminalId}],methods=[GET
  20:17:51.174 [ts-route-service] 2024-12-07 20:17:51.173 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  20:17:52.761 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  20:17:52.765 [ts-route-service] 2024-12-07 20:17:52.765 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/vnd.spring-bo
  20:17:57.960 [ts-basic-service] 2024-12-07 20:17:57.959 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su 
  20:18:01.659 [ts-route-service] 2024-12-07 20:18:01.657 INFO 1 --- [ main] d.s.w.p.DocumentationPluginsBootstrapper : Found 1 custom documentation plugin(s)
  20:18:04.265 [ts-route-service] 2024-12-07 20:18:04.265 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: taiyuan End: shanghai
  20:18:09.561 [ts-route-service] 2024-12-07 20:18:09.560 INFO 1 --- [io-11178-exec-3] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×41)
  20:18:10.466 [ts-travel-service] 2024-12-07 20:18:10.465 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×3)
  20:18:11.789 [ts-basic-service] 2024-12-07 20:18:11.789 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×2)
  20:18:11.820 [ts-order-other-service] 2024-12-07 20:18:11.820 INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×2)
  20:18:11.911 [ts-seat-service] 2024-12-07 20:18:11.911 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  20:18:11.988 [ts-seat-service] 2024-12-07 20:18:11.988 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×3)
  20:18:12.051 [ts-travel2-service] 2024-12-07 20:18:12.051 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×4)
  20:18:15.448 [ts-order-other-service] 2024-12-07 20:18:15.448 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Get Order By Id] Order Id: 0326c0cb-84c6-4b7b

## p0592
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-admin-travel-service, 2024-12-07T18:43:40.089Z
```
{"timestamp":1733597020089744100,"container_name":"ts-admin-travel-service","pod_name":"ts-admin-travel-service-5c866595d6-ml89r","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 18:43:40.089 ERROR 1 --- [io-16114-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception\n"}
```
Same service, the 2 minutes before (oldest first):
  18:43:07.353 [ts-admin-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×7)
  18:43:10.194 [ts-admin-travel-service] 2024-12-07 18:43:10.194 ERROR 1 --- [io-16114-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×7)
  18:43:10.195 [ts-admin-travel-service] 2024-12-07 18:43:10.195 ERROR 1 --- [io-16114-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×6)
All services, 30 seconds either side (sampled):
  18:43:10.181 [ts-auth-service] 2024-12-07 18:43:10.181 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×26)
  18:43:10.194 [ts-admin-travel-service] 2024-12-07 18:43:10.194 ERROR 1 --- [io-16114-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×14)
  18:43:10.197 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:43:10 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 500 233 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×14)
  18:43:12.206 [ts-admin-basic-info-service] 2024-12-07 18:43:12.205 ERROR 1 --- [io-18767-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×24)
  18:43:12.209 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:43:12 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 500 238 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_  (×13)
  18:43:16.966 [ts-auth-service] 2024-12-07 18:43:16.965 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:43:17.186 [ts-travel2-service] 2024-12-07 18:43:17.186 ERROR 1 --- [io-16346-exec-6] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×14)
  18:43:17.189 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:43:17 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 500 228 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×14)
  18:43:20.617 [ts-auth-service] 2024-12-07 18:43:20.617 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×13)
  18:43:21.806 [ts-travel-service] 2024-12-07 18:43:21.806 ERROR 1 --- [io-12346-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  18:43:24.196 [ts-food-service] 2024-12-07 18:43:24.195 ERROR 1 --- [io-18856-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:43:24.199 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:43:24 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 500 259 "-" "Mozilla/5.0 (Macintosh;   (×2)
  18:43:24.483 [ts-order-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  18:43:27.510 [ts-travel-mongo] {"t":{"$date":"2024-12-07T18:43:27.509+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359700
  18:43:27.675 [ts-config-mongo] {"t":{"$date":"2024-12-07T18:43:27.674+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359700
  18:43:29.983 [ts-food-mongo] {"t":{"$date":"2024-12-07T18:43:29.983+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359700
  18:43:30.013 [ts-station-mongo] {"t":{"$date":"2024-12-07T18:43:30.013+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359701
  18:43:30.636 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T18:43:30.636+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359701
  18:43:30.845 [ts-notification-mongo] {"t":{"$date":"2024-12-07T18:43:30.844+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359701
  18:43:42.115 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T18:43:42.115+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359702
  18:43:42.311 [ts-order-other-mongo] {"t":{"$date":"2024-12-07T18:43:42.311+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359702
  18:43:50.213 [ts-order-other-service] 2024-12-07 18:43:50.212 ERROR 1 --- [io-12032-exec-9] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  18:43:52.077 [ts-auth-service] 2024-12-07 18:43:52.077 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null
  18:43:55.091 [ts-food-service] 2024-12-07 18:43:55.091 ERROR 1 --- [o-18856-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 

## p0647
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice2, 2021-08-11T01:23:06.380Z
```
{"service":"logservice2","message":"2021-08-11 01:23:06,380 | ERROR | 0.0.0.2 | logservice2 | login_helper.py -> login_query_methods_model -> 93 | 3e578c499cfad9bd | get information failed, fail code: 400"}
```
Same service, the 2 minutes before (oldest first):
  01:22:54.612 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '98da04ec-f9ff-11eb-b1c1-0242ac110004', 'user_id': 'DhKfSuMF'}  (×5)
  01:22:56.573 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×3)
  01:22:56.574 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×3)
  01:23:04.922 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  01:23:04.922 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  01:23:04.923 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '9f103c8c-f9ff-11eb-abcb-0242ac110003'}  (×2)
  01:23:04.994 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384
  01:23:04.994 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service
  01:23:06.379 [logservice2] ERROR uuid expired, invalid phone request
All services, 30 seconds either side (sampled):
  01:22:36.454 [redisservice2] INFO redis write success  (×74)
  01:22:36.566 [redisservice1] INFO service accept, status_code: 200  (×37)
  01:22:36.673 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×39)
  01:22:36.859 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×36)
  01:22:37.176 [dbservice1] INFO 8e436bd6-f9ff-11eb-9d07-0242ac110004-AwlIqmHD-pyw@uEvW-irk token generate success token=MTYyODYxNjE1Ny4xNzU5NTM5OjhlNDM2YmQ2LWY5ZmYtMTFlYi05ZDA3LTAyNDJhYzE
  01:22:37.443 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×31)
  01:22:37.833 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×33)
  01:22:38.875 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×27)
  01:22:39.329 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×31)
  01:22:42.063 [mobservice1] INFO info 9174a248-f9ff-11eb-b8df-0242ac110004:MDLxpWSd write success
  01:22:48.764 [dbservice1] INFO 952cc9ce-f9ff-11eb-9af0-0242ac110003-PNmIMWHV-^@.oySAnw2TX token generate success token=MTYyODYxNjE2OC43NjM5MDE1Ojk1MmNjOWNlLWY5ZmYtMTFlYi05YWYwLTAyNDJhYzE
  01:22:50.926 [dbservice2] INFO 968121f8-f9ff-11eb-b851-0242ac110003-saHAJjFe-$p8NUBRnq{X< token generate success token=MTYyODYxNjE3MC45MjU3ODMyOjk2ODEyMWY4LWY5ZmYtMTFlYi1iODUxLTAyNDJhYzE
  01:22:53.603 [mobservice2] INFO info 9843cd88-f9ff-11eb-8205-0242ac110003:HkLmPgZU write success
  01:22:59.300 [mobservice1] INFO info 9ba8f5d4-f9ff-11eb-a6c5-0242ac110004:ERSdWpfg write success
  01:23:06.267 [mobservice2] ERROR uuid:99535acc-f9ff-11eb-8718-0242ac110003 information has expired, mobile phone login is invalid
  01:23:08.039 [dbservice2] INFO a0af0e4c-f9ff-11eb-9994-0242ac110003-XWkAGNLi-ZF0Q*-Nk7xJ< token generate success token=MTYyODYxNjE4OC4wMzk0MDg0OmEwYWYwZTRjLWY5ZmYtMTFlYi05OTk0LTAyNDJhYzE
  01:23:10.282 [dbservice2] INFO a213d466-f9ff-11eb-8ecb-0242ac110003-fjEOpuqm-<9>^jfG#2%K@ token generate success token=MTYyODYxNjE5MC4yODE5NTQ4OmEyMTNkNDY2LWY5ZmYtMTFlYi04ZWNiLTAyNDJhYzE
  01:23:12.350 [mobservice2] INFO info a3803290-f9ff-11eb-b1fc-0242ac110004:YTchXgsi write success
  01:23:14.208 [dbservice2] INFO a46b4ee2-f9ff-11eb-976e-0242ac110003-HkuCdjLo-($XWb3R2Lr.6 token generate success token=MTYyODYxNjE5NC4yMDgyMzg6YTQ2YjRlZTItZjlmZi0xMWViLTk3NmUtMDI0MmFjMTE
  01:23:16.490 [dbservice2] INFO a5b6a8d2-f9ff-11eb-8756-0242ac110003-BLOHhDzM-{i4jP}N/rmt9 token generate success token=MTYyODYxNjE5Ni40ODk5NzA3OmE1YjZhOGQyLWY5ZmYtMTFlYi04NzU2LTAyNDJhYzE
  01:23:19.007 [mobservice2] INFO info a76d4096-f9ff-11eb-adb7-0242ac110004:APxbpyWu write success
  01:23:21.639 [mobservice1] INFO info a8f9c236-f9ff-11eb-9b84-0242ac110004:glaSXZGO write success
  01:23:24.327 [mobservice1] INFO info aaa42dce-f9ff-11eb-b826-0242ac110003:AJgiBDVM write success
  01:23:27.243 [dbservice2] ERROR password in database of {user} is null, the user is not registered
  01:23:29.490 [mobservice2] INFO info adb0772a-f9ff-11eb-b0b5-0242ac110004:bLKvfOjH write success
  01:23:31.483 [dbservice2] INFO aeaecd5c-f9ff-11eb-b212-0242ac110004-WcUSzNAM-4Tvi5PF$026m token generate success token=MTYyODYxNjIxMS40ODMyMzY4OmFlYWVjZDVjLWY5ZmYtMTFlYi1iMjEyLTAyNDJhYzE
  01:23:33.955 [dbservice2] INFO b012c892-f9ff-11eb-ba04-0242ac110004-uloJcsne-s12=_60+_kX- token generate success token=MTYyODYxNjIxMy45NTQ1MTk3OmIwMTJjODkyLWY5ZmYtMTFlYi1iYTA0LTAyNDJhYzE

## p0553
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T18:22:20.204Z
```
{"timestamp":1733595740204522200,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-ndkkb","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 18:22:20.204  INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl             : Get Order tickets result is : <200,Response(status=1, msg=Success, data=LeftTicketInfo{soldTickets=[Ticket(seatNo=1273928112, startStation=shanghai, destStation=nanjing), Ticket(seatNo=1280096130, startStation=shanghai, destStation=nanjing), Ticket(seatNo=511229046, startStation=shanghai, destStation=n…"}
```
Same service, the 2 minutes before (oldest first):
  18:22:14.437 [ts-seat-service] 2024-12-07 18:22:14.437 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×3)
  18:22:14.437 [ts-seat-service] 2024-12-07 18:22:14.437 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  18:22:14.447 [ts-seat-service] 2024-12-07 18:22:14.446 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  18:22:14.486 [ts-seat-service] 2024-12-07 18:22:14.486 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×3)
  18:22:14.486 [ts-seat-service] 2024-12-07 18:22:14.486 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×3)
  18:22:14.498 [ts-seat-service] 2024-12-07 18:22:14.498 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×3)
  18:22:14.508 [ts-seat-service] 2024-12-07 18:22:14.508 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  18:22:14.522 [ts-seat-service] 2024-12-07 18:22:14.522 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
All services, 30 seconds either side (sampled):
  18:21:50.637 [ts-admin-basic-info-service] 2024-12-07 18:21:50.637 INFO 1 --- [io-18767-exec-1] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×9)
  18:21:52.907 [ts-travel-service] 2024-12-07 18:21:52.906 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×7)
  18:21:53.077 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:21:53 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×10)
  18:21:55.984 [ts-basic-service] 2024-12-07 18:21:55.984 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×6)
  18:21:56.140 [ts-travel2-service] 2024-12-07 18:21:56.140 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×34)
  18:21:56.303 [ts-travel2-service] 2024-12-07 18:21:56.303 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×34)
  18:21:56.694 [ts-travel2-service] 2024-12-07 18:21:56.694 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×12)
  18:21:57.572 [ts-basic-service] 2024-12-07 18:21:57.571 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87
  18:21:59.048 [ts-travel-service] 2024-12-07 18:21:59.048 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×10)
  18:21:59.104 [ts-basic-service] 2024-12-07 18:21:59.104 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×2)
  18:21:59.188 [ts-travel-service] 2024-12-07 18:21:59.188 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×7)
  18:21:59.348 [ts-travel-service] 2024-12-07 18:21:59.348 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×6)
  18:21:59.406 [ts-security-service] 2024-12-07 18:21:59.405 INFO 1 --- [io-11188-exec-9] security.controller.SecurityController : [Security Service][Check Security] Check Account Id: 4d2a46c7-71cb  (×2)
  18:21:59.462 [ts-preserve-service] 2024-12-07 18:21:59.462 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Find contacts  (×2)
  18:21:59.596 [ts-basic-service] 2024-12-07 18:21:59.596 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe  (×3)
  18:22:00.177 [ts-seat-service] 2024-12-07 18:22:00.176 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService distributeSeat] TrainNumber start with G|D
  18:22:00.294 [ts-order-service] 2024-12-07 18:22:00.294 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Order Create] Success.
  18:22:01.343 [ts-preserve-other-service] 2024-12-07 18:22:01.342 INFO 1 --- [io-14569-exec-8] p.controller.PreserveOtherController : [Preserve Other Service][Preserve] Account order from Shang Hai ----
  18:22:01.388 [ts-security-service] 2024-12-07 18:22:01.388 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service][Get Security Config Info]
  18:22:01.437 [ts-order-other-service] 2024-12-07 18:22:01.436 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 23
  18:22:01.779 [ts-preserve-other-service] 2024-12-07 18:22:01.778 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Step 2] Complete
  18:22:02.241 [ts-preserve-other-service] 2024-12-07 18:22:02.240 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order] Order Travel Date: Sat Dec 07 00:00:00
  18:22:02.311 [ts-preserve-other-service] 2024-12-07 18:22:02.311 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Service][Add Assurance Type For Order]
  18:22:03.530 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:22:03 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 200 14819 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) App  (×2)
  18:22:17.869 [ts-admin-basic-info-service] 2024-12-07 18:22:17.869 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  18:22:25.302 [ts-auth-service] 2024-12-07 18:22:25.301 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×2)
  18:22:29.766 [ts-food-mongo] {"t":{"$date":"2024-12-07T18:22:29.766+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359574
  18:22:30.844 [ts-order-mongo] {"t":{"$date":"2024-12-07T18:22:30.843+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359575
  18:22:35.972 [ts-travel-service] 2024-12-07 18:22:35.972 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234
  18:22:42.123 [ts-order-other-mongo] {"t":{"$date":"2024-12-07T18:22:42.123+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359576

## p0690
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-12T06:46:06.500Z
```
{"service":"dbservice1","message":"2021-08-12 06:46:06,500 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 78d92776c32b7d35 | e9830cf8-faf5-11eb-a012-0242ac110003-hfWmCetl-sU3(RxISVqF_ token generate success token=MTYyODcyMTk2Ni41MDAzMDU3OmU5ODMwY2Y4LWZhZjUtMTFlYi1hMDEyLTAyNDJhYzExMDAwM2hmV21DZXRsc1UzKFJ4SVNWcUZfOjE2Mjg3MjIwMjYuNTAwMzE2NjpiY2NlMWM2NGRkYTRkMTkwNzU1ZTdiMmM0NmY5MTgxOA=="}
```
Same service, the 2 minutes before (oldest first):
  06:45:57.729 [dbservice1] INFO e45175bc-faf5-11eb-98cc-0242ac110003-IfmxlhUD-(EG)!n_@/CPS token generate success token=MTYyODcyMTk1Ny43Mjk2MjQ3OmU0NTE3NWJjLWZhZjUtMTFlYi05OGNjLTAyNDJhYzE
  06:46:00.373 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  06:46:00.373 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  06:46:00.430 [dbservice1] INFO query = select passwards from username_table where user_name='jHYceNBX'  (×5)
  06:46:00.506 [dbservice1] INFO e6067fc4-faf5-11eb-8fb9-0242ac110003-jHYceNBX-P4kgXJlU1L>S token generate success token=MTYyODcyMTk2MC41MDU4MTU3OmU2MDY3ZmM0LWZhZjUtMTFlYi04ZmI5LTAyNDJhYzE
  06:46:03.097 [dbservice1] INFO e7904780-faf5-11eb-a467-0242ac110003-bJsneyVk-I0LUye#3x)Wa token generate success token=MTYyODcyMTk2My4wOTY4NzQ6ZTc5MDQ3ODAtZmFmNS0xMWViLWE0NjctMDI0MmFjMTE
  06:46:03.330 [dbservice1] INFO e7adda0c-faf5-11eb-8374-0242ac110003-HNmhtWzM-u-}_4oB7AmID token generate success token=MTYyODcyMTk2My4zMjk3MzIyOmU3YWRkYTBjLWZhZjUtMTFlYi04Mzc0LTAyNDJhYzE
  06:46:04.765 [dbservice1] INFO e8814b62-faf5-11eb-a322-0242ac110004-OkyWpDvC-YSR3f{z?a:H/ token generate success token=MTYyODcyMTk2NC43NjUyMTk6ZTg4MTRiNjItZmFmNS0xMWViLWEzMjItMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  06:45:36.506 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  06:45:36.750 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×50)
  06:45:36.972 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×40)
  06:45:37.128 [logservice2] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': 'd822a4a0-faf5-11eb-8e84-0242ac110004', 'user_id': 'vdlbugLI'}  (×85)
  06:45:37.307 [dbservice2] INFO d822a4a0-faf5-11eb-8e84-0242ac110004-vdlbugLI-X:rBpPT2Yg&A token generate success token=MTYyODcyMTkzNy4zMDY4MTQ3OmQ4MjJhNGEwLWZhZjUtMTFlYi04ZTg0LTAyNDJhYzE
  06:45:37.532 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×45)
  06:45:38.890 [dbservice2] INFO d9261224-faf5-11eb-ad51-0242ac110004-JkvHOUxm-rOwA5m{>N7*E token generate success token=MTYyODcyMTkzOC44OTAxOTE2OmQ5MjYxMjI0LWZhZjUtMTFlYi1hZDUxLTAyNDJhYzE
  06:45:39.381 [mobservice2] INFO info d99f5436-faf5-11eb-8bce-0242ac110003:NPtZUmhc write success
  06:45:40.623 [dbservice2] INFO da27f8e0-faf5-11eb-aa84-0242ac110003-wzuckBhX-M8t1WKXj9vHT token generate success token=MTYyODcyMTk0MC42MjI5NTE6ZGEyN2Y4ZTAtZmFmNS0xMWViLWFhODQtMDI0MmFjMTE  (×4)
  06:45:43.109 [dbservice1] INFO db98e0cc-faf5-11eb-912d-0242ac110003-SNyDIdeO-%$BE{6JCn?Hd token generate success token=MTYyODcyMTk0My4xMDk1MDI4OmRiOThlMGNjLWZhZjUtMTFlYi05MTJkLTAyNDJhYzE
  06:45:45.325 [mobservice2] INFO info dd2b429a-faf5-11eb-b46d-0242ac110003:GVawnFOc write success
  06:45:47.840 [mobservice1] INFO info dea29c7c-faf5-11eb-8719-0242ac110003:bJsneyVk write success  (×2)
  06:45:50.289 [mobservice1] INFO info e0245068-faf5-11eb-835c-0242ac110004:AMFryZUz write success  (×2)
  06:45:53.493 [mobservice1] INFO info e2067136-faf5-11eb-8fbd-0242ac110004:uZlYkfgS write success
  06:45:56.283 [dbservice1] INFO e37ef63c-faf5-11eb-9c29-0242ac110004-GNqpIFum-6p{Revl/Jr90 token generate success token=MTYyODcyMTk1Ni4yODMzMjk6ZTM3ZWY2M2MtZmFmNS0xMWViLTljMjktMDI0MmFjMTE
  06:46:03.850 [dbservice2] INFO e805caaa-faf5-11eb-9761-0242ac110004-NZDQOdvq-GS:wohYiTEre token generate success token=MTYyODcyMTk2My44NDk2NzMzOmU4MDVjYWFhLWZhZjUtMTFlYi05NzYxLTAyNDJhYzE
  06:46:06.984 [mobservice1] INFO info ea0f3df4-faf5-11eb-b37d-0242ac110003:IZrFSezD write success
  06:46:09.633 [mobservice2] INFO info eba3dd78-faf5-11eb-a929-0242ac110003:bCKBvESO write success
  06:46:12.216 [mobservice2] INFO info ed254a92-faf5-11eb-b19b-0242ac110004:ALRXkDds write success
  06:46:14.916 [mobservice1] INFO info eec9af82-faf5-11eb-aece-0242ac110003:NEhHktDw write success
  06:46:17.869 [dbservice2] INFO f04df840-faf5-11eb-8136-0242ac110003-DQJsnMlT-Nc3Z_Ei.#d7& token generate success token=MTYyODcyMTk3Ny44NjkwNzk4OmYwNGRmODQwLWZhZjUtMTFlYi04MTM2LTAyNDJhYzE
  06:46:20.654 [dbservice1] INFO f2037eee-faf5-11eb-bd68-0242ac110004-HMKVRZeu-Kw&{bqcPf=xI token generate success token=MTYyODcyMTk4MC42NTQxMDE4OmYyMDM3ZWVlLWZhZjUtMTFlYi1iZDY4LTAyNDJhYzE
  06:46:23.085 [mobservice2] INFO info f3a9c190-faf5-11eb-85db-0242ac110003:ycKvOJwP write success
  06:46:26.068 [mobservice1] INFO info f568dd04-faf5-11eb-b0dd-0242ac110004:vtpXmFKe write success
  06:46:28.894 [mobservice2] INFO info f7170d4c-faf5-11eb-ba7b-0242ac110004:aFPAvDqO write success
  06:46:31.771 [dbservice2] INFO f8a10fa0-faf5-11eb-802a-0242ac110003-WdLJXtHG-UZY)^Efxi>LV token generate success token=MTYyODcyMTk5MS43NzA5MzcyOmY4YTEwZmEwLWZhZjUtMTFlYi04MDJhLTAyNDJhYzE
  06:46:34.186 [dbservice1] INFO fa100508-faf5-11eb-903b-0242ac110004-PzgvQsFL-V%GQ*R{1naw@ token generate success token=MTYyODcyMTk5NC4xODYxNjY1OmZhMTAwNTA4LWZhZjUtMTFlYi05MDNiLTAyNDJhYzE

## p0045
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T08:04:18.188Z
```
{"service":"dbservice1","message":"2021-08-13 08:04:18,188 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 91fc867270da2cc5 | 007c8446-fbca-11eb-b1d7-0242ac110004-PMIwlKZi-7A>JsQ{2D}&1 token generate success token=MTYyODgxMzA1OC4xODgyNTI6MDA3Yzg0NDYtZmJjYS0xMWViLWIxZDctMDI0MmFjMTEwMDA0UE1Jd2xLWmk3QT5Kc1F7MkR9JjE6MTYyODgxMzExOC4xODgyNjI1OjA4MmYwNTkxODFiODQ0MmVlNzFiZGZhYWUxOWM3NjY5"}
```
Same service, the 2 minutes before (oldest first):
  08:04:06.629 [dbservice1] INFO f9881c0e-fbc9-11eb-98a3-0242ac110003-ZadRMLrA-qU=K:N/SjTlv token generate success token=MTYyODgxMzA0Ni42MjkwNDI2OmY5ODgxYzBlLWZiYzktMTFlYi05OGEzLTAyNDJhYzE
  08:04:08.036 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:04:08.037 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  08:04:08.052 [dbservice1] INFO query = select passwards from username_table where user_name='ItWBCNrc'  (×5)
  08:04:08.130 [dbservice1] INFO fa89b93c-fbc9-11eb-ac24-0242ac110004-ItWBCNrc-GUJ7{#*fP2/g token generate success token=MTYyODgxMzA0OC4xMjk5Nzk2OmZhODliOTNjLWZiYzktMTFlYi1hYzI0LTAyNDJhYzE
  08:04:09.133 [dbservice1] INFO fb117c3c-fbc9-11eb-aaf0-0242ac110003-GNqpIFum-6p{Revl/Jr90 token generate success token=MTYyODgxMzA0OS4xMzI5MDc2OmZiMTE3YzNjLWZiYzktMTFlYi1hYWYwLTAyNDJhYzE
  08:04:15.835 [dbservice1] INFO ff109d04-fbc9-11eb-bb7d-0242ac110004-ArxCmQcb-p-n+Fy1&AjMv token generate success token=MTYyODgxMzA1NS44MzU0Nzc4OmZmMTA5ZDA0LWZiYzktMTFlYi1iYjdkLTAyNDJhYzE
  08:04:17.631 [dbservice1] INFO 0015411e-fbca-11eb-9f46-0242ac110003-sNQUnOaq-YXf&B76#)l(Z token generate success token=MTYyODgxMzA1Ny42MzE0MzowMDE1NDExZS1mYmNhLTExZWItOWY0Ni0wMjQyYWMxMTA
All services, 30 seconds either side (sampled):
  08:03:48.954 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  08:03:49.123 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×46)
  08:03:49.377 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  08:03:49.497 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×44)
  08:03:49.625 [dbservice1] INFO ef7560dc-fbc9-11eb-93a6-0242ac110004-GSgbqoFw-Y_*N-71D.6+R token generate success token=MTYyODgxMzAyOS42MjQ3NjIzOmVmNzU2MGRjLWZiYzktMTFlYi05M2E2LTAyNDJhYzE
  08:03:51.940 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×42)
  08:03:52.351 [redisservice2] INFO service refuse, status_code: 200  (×27)
  08:03:54.012 [logservice1] ERROR get information failed, fail code: 400
  08:03:54.620 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  08:03:54.778 [mobservice1] INFO info f2c0266e-fbc9-11eb-85cd-0242ac110004:HBlmbePk write success
  08:03:57.590 [mobservice1] INFO info f45c8b48-fbc9-11eb-a491-0242ac110003:rwmAxZUJ write success
  08:03:59.910 [mobservice2] INFO info f5ca361a-fbc9-11eb-9da0-0242ac110003:oJvuskDK write success
  08:04:03.063 [mobservice2] INFO info f7a1fd2e-fbc9-11eb-ae83-0242ac110003:jKNlhwnV write success
  08:04:06.241 [mobservice2] INFO info f9881c0e-fbc9-11eb-98a3-0242ac110003:ZadRMLrA write success
  08:04:09.133 [dbservice1] INFO fb117c3c-fbc9-11eb-aaf0-0242ac110003-GNqpIFum-6p{Revl/Jr90 token generate success token=MTYyODgxMzA0OS4xMzI5MDc2OmZiMTE3YzNjLWZiYzktMTFlYi1hYWYwLTAyNDJhYzE
  08:04:13.280 [mobservice2] INFO info fdc3c3ae-fbc9-11eb-bdc6-0242ac110003:elIAhJnr write success
  08:04:17.152 [mobservice1] INFO info 00151a4a-fbca-11eb-989e-0242ac110003:XdvDclow write success
  08:04:19.811 [dbservice1] INFO 0172cac2-fbca-11eb-b4dc-0242ac110003-eNWPvrgG-5p=qVbStYAN^ token generate success token=MTYyODgxMzA1OS44MTE0NzA3OjAxNzJjYWMyLWZiY2EtMTFlYi1iNGRjLTAyNDJhYzE
  08:04:22.922 [mobservice1] INFO info 0384cce8-fbca-11eb-a96d-0242ac110004:qepNbChc write success
  08:04:25.632 [mobservice2] INFO info 051f5898-fbca-11eb-8e84-0242ac110004:ZYabGCTS write success
  08:04:28.398 [mobservice2] INFO info 06c9f8f6-fbca-11eb-a7d7-0242ac110003:qYMpFKOS write success
  08:04:31.108 [mobservice1] INFO info 0860b11e-fbca-11eb-872a-0242ac110004:IKAZGYCc write success
  08:04:34.289 [dbservice1] INFO 0a0be380-fbca-11eb-be1b-0242ac110004-NuWOPqyE-V&aT?AIJu217 token generate success token=MTYyODgxMzA3NC4yODg3MTU2OjBhMGJlMzgwLWZiY2EtMTFlYi1iZTFiLTAyNDJhYzE
  08:04:36.859 [mobservice1] INFO info 0bcd8c64-fbca-11eb-a94f-0242ac110003:hRGCgxwP write success  (×2)
  08:04:40.177 [mobservice2] INFO info 0dc82f92-fbca-11eb-8438-0242ac110004:uHrsPUfR write success
  08:04:42.961 [dbservice1] INFO 0f3c2d42-fbca-11eb-b116-0242ac110004-LcHJSWVC-F0&dSO2HbJD> token generate success token=MTYyODgxMzA4Mi45NjEyODQ6MGYzYzJkNDItZmJjYS0xMWViLWIxMTYtMDI0MmFjMTE
  08:04:45.867 [dbservice1] INFO 10f0938a-fbca-11eb-84df-0242ac110004-PYaoLpfS-bW9F%P+AUv_Q token generate success token=MTYyODgxMzA4NS44Njc0NTIxOjEwZjA5MzhhLWZiY2EtMTFlYi04NGRmLTAyNDJhYzE

## p0298
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T02:43:24.155Z
```
{"timestamp":1732243404155262200,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T02:43:24.155060597Z caller=middlewares.go:75 method=GetUsers id=673fefb4b0df5c00019b0415 result=1 took=761.096µs"}
```
Same service, the 2 minutes before (oldest first):
  02:43:23.103 [user] ts=2024-11-22T02:43:23.103794454Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673fefc5b0df5c00019b043b took=1.840556ms
  02:43:23.109 [user] ts=2024-11-22T02:43:23.10915868Z caller=middlewares.go:46 method=Register username=TdruQB email=TdruQB@gmail.com took=783.499µs
  02:43:23.115 [user] ts=2024-11-22T02:43:23.114937709Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673fefc5b0df5c00019b043b took=1.610256ms
  02:43:23.148 [user] ts=2024-11-22T02:43:23.148046016Z caller=middlewares.go:75 method=GetUsers id=673fefb5b0df5c00019b041f result=1 took=953.496µs  (×8)
  02:43:23.164 [user] ts=2024-11-22T02:43:23.164131988Z caller=middlewares.go:134 method=GetCards id=673fefbab0df5c00019b042b result=1 took=849.722µs  (×2)
  02:43:23.164 [user] ts=2024-11-22T02:43:23.164187996Z caller=middlewares.go:104 method=GetAddresses id=673fefbab0df5c00019b042a result=1 took=953.754µs  (×2)
  02:43:23.832 [user] ts=2024-11-22T02:43:23.831749424Z caller=middlewares.go:46 method=Register username=SFsSUIfSnFrD email=SFsSUIfSnFrD@gmail.com took=978.037µs  (×2)
  02:43:24.093 [user] ts=2024-11-22T02:43:24.093664005Z caller=middlewares.go:157 method=Health result=2 took=733.94µs  (×2)
  02:43:24.103 [user] ts=2024-11-22T02:43:24.103421127Z caller=middlewares.go:75 method=GetUsers id=673fefbbb0df5c00019b042c result=1 took=1.246223ms
All services, 30 seconds either side (sampled):
  02:42:54.168 [front-end] Posting Customer: {"username":"uQKMLLncSPT","password":"xkSypNmb","email":"uQKMLLncSPT@gmail.com","firstName":"uQKMLLncSPT","lastName":"uQKMLLncSPT"}
  02:42:54.391 [orders] 2024-11-22 02:42:54.391 INFO [orders,4880ceea52fff49c,ea1bfbcd06047d8a,false] 6 --- [-nio-80-exec-11] w.w.s.o.controllers.OrdersController : Received payment re  (×28)
  02:42:54.421 [front-end] Received response: "{\"firstName\":\"IVtQPzbzUqEgWw\",\"lastName\":\"IVtQPzbzUqEgWw\",\"username\":\"IVtQPzbzUqEgWw\",\"id\":\"673fef94b0df5c00019b03a3\",\"_lin
  02:42:54.606 [front-end] Order response: {"statusCode":201,"body":{"id":"673fefaed94b9000069b3c69","customerId":"673fef94b0df5c00019b03a3","customer":{"id":null,"firstName":"IVtQPzbzUqE
  02:42:55.352 [catalogue] ts=2024-11-22T02:42:55Z caller=logging.go:85 method=Health result=2 took=36.478µs  (×40)
  02:42:55.914 [catalogue] ts=2024-11-22T02:42:55Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=5.664255  (×58)
  02:42:58.085 [carts] 2024-11-22 02:42:58.084 WARN [carts,54634664683e4380,54634664683e4380,false] 7 --- [-nio-80-exec-29] o.s.web.servlet.PageNotFound : Request method 'POST' not su  (×41)
  02:43:00.192 [front-end] Posting Customer: {"username":"QnMobOvGYdI","password":"FNpKihKfSj","email":"QnMobOvGYdI@gmail.com","firstName":"QnMobOvGYdI","lastName":"QnMobOvGYdI"}
  02:43:02.911 [front-end] Order response: {"statusCode":201,"body":{"id":"673fefb6d94b9000069b3c6f","customerId":"673fefa2b0df5c00019b03d4","customer":{"id":null,"firstName":"hksGHBI","l
  02:43:04.902 [front-end] Order response: {"statusCode":201,"body":{"id":"673fefb8d94b9000069b3c73","customerId":"673fefa0b0df5c00019b03cd","customer":{"id":null,"firstName":"DCwRD","las
  02:43:07.776 [user] ts=2024-11-22T02:43:07.776417012Z caller=middlewares.go:46 method=Register username=nGImalq email=nGImalq@gmail.com took=959.547µs
  02:43:09.811 [front-end] Order response: {"id":"673fefbdd94b9000069b3c78","customerId":"673fefa9b0df5c00019b03f5","customer":{"id":null,"firstName":"VhzkkclCw","lastName":"VhzkkclCw","u
  02:43:11.260 [front-end] Received response: "{\"firstName\":\"dpbCMzCbxA\",\"lastName\":\"dpbCMzCbxA\",\"username\":\"dpbCMzCbxA\",\"id\":\"673fefa4b0df5c00019b03d9\",\"_links\":{\"addr
  02:43:12.104 [front-end] Order response: {"id":"673fefc0d94b9000069b3c7f","customerId":"673fef9cb0df5c00019b03bc","customer":{"id":null,"firstName":"hfeGTearAjg","lastName":"hfeGTearAjg
  02:43:13.673 [front-end] Posting Customer: {"username":"JHdrjfSujun","password":"KWRBBp","email":"JHdrjfSujun@gmail.com","firstName":"JHdrjfSujun","lastName":"JHdrjfSujun"}
  02:43:16.754 [front-end] Received response: "{\"firstName\":\"fTeojPA\",\"lastName\":\"fTeojPA\",\"username\":\"fTeojPA\",\"id\":\"673fefb2b0df5c00019b0405\",\"_links\":{\"addresses\":{
  02:43:20.150 [front-end] Received response: "{\"firstName\":\"dnQbkoTqm\",\"lastName\":\"dnQbkoTqm\",\"username\":\"dnQbkoTqm\",\"id\":\"673fefa3b0df5c00019b03d8\",\"_links\":{\"address
  02:43:22.864 [front-end] Posting Customer: {"username":"CKAfaE","password":"XQfvNaZOnR","email":"CKAfaE@gmail.com","firstName":"CKAfaE","lastName":"CKAfaE"}
  02:43:24.130 [front-end] Order response: {"id":"673fefccd94b9000069b3c8c","customerId":"673fefbbb0df5c00019b042c","customer":{"id":null,"firstName":"nGImalq","lastName":"nGImalq","usern
  02:43:26.415 [front-end] Order response: {"statusCode":201,"body":{"id":"673fefced94b9000069b3c8f","customerId":"673fefbdb0df5c00019b042f","customer":{"id":null,"firstName":"DpcznocHqpc
  02:43:30.649 [front-end] Posting Customer: {"username":"NDvXRPbPx","password":"oMhLY","email":"NDvXRPbPx@gmail.com","firstName":"NDvXRPbPx","lastName":"NDvXRPbPx"}
  02:43:34.465 [front-end] Received response: "{\"firstName\":\"xExslhJmSuPBKV\",\"lastName\":\"xExslhJmSuPBKV\",\"username\":\"xExslhJmSuPBKV\",\"id\":\"673fefbcb0df5c00019b042e\",\"_lin
  02:43:36.936 [front-end] Order response: {"id":"673fefd8d94b9000069b3c94","customerId":"673fefc1b0df5c00019b0435","customer":{"id":null,"firstName":"JHdrjfSujun","lastName":"JHdrjfSujun
  02:43:38.993 [front-end] Order response: {"statusCode":201,"body":{"id":"673fefdad94b9000069b3c97","customerId":"673fefc7b0df5c00019b0440","customer":{"id":null,"firstName":"XfGGTLHHjnD
  02:43:43.321 [front-end] Order response: {"statusCode":201,"body":{"id":"673fefdfd94b9000069b3c9a","customerId":"673fefcab0df5c00019b0449","customer":{"id":null,"firstName":"CKAfaE","la
  02:43:45.191 [front-end] Order response: {"statusCode":201,"body":{"id":"673fefe1d94b9000069b3c9d","customerId":"673fefcbb0df5c00019b044d","customer":{"id":null,"firstName":"SFsSUIfSnFr
  02:43:47.359 [front-end] Posting Customer: {"username":"wEZOGADfepoZaE","password":"NoQCLN","email":"wEZOGADfepoZaE@gmail.com","firstName":"wEZOGADfepoZaE","lastName":"wEZOGADfepoZaE"}
  02:43:50.050 [front-end] Order response: {"id":"673fefe6d94b9000069b3ca4","customerId":"673fefd0b0df5c00019b0458","customer":{"id":null,"firstName":"bZHeRwupypY","lastName":"bZHeRwupypY
  02:43:52.080 [front-end] Posting Customer: {"username":"uBTBay","password":"TNeFcG","email":"uBTBay@gmail.com","firstName":"uBTBay","lastName":"uBTBay"}

## p0191
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service recommendationservice, 2024-11-18T06:48:47.294Z
```
{"timestamp":1731912527294779000,"container_name":"recommendationservice","pod_name":"recommendationservice-fdf57f545-q8t5v","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"[Recv ListRecommendations] product_ids=['OLJCESPC7Z', '0PUK6V6EV0', 'L9ECAV7KIM', '1YMWWN1N4O', '66VCHSJNUP']"}
```
Same service, the 2 minutes before (oldest first):
  06:48:39.819 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', 'LS4PSXUNUM', '1YMWWN1N4O', '9SIQT8TOJO', '66VCHSJNUP']  (×20)
All services, 30 seconds either side (sampled):
  06:48:24.473 [frontend] request started  (×262)
  06:48:24.477 [currencyservice] Getting supported currencies...  (×219)
  06:48:24.488 [currencyservice] conversion request successful  (×544)
  06:48:24.504 [adservice] received ad request (context_words=[decor, home])  (×11)
  06:48:24.556 [adservice] received ad request (context_words=[accessories])  (×25)
  06:48:24.564 [cartservice] AddItemAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03, productId=OLJCESPC7Z, quantity=1  (×23)
  06:48:24.603 [shippingservice] [GetQuote] received request  (×57)
  06:48:25.170 [adservice] received ad request (context_words=[kitchen])  (×46)
  06:48:26.158 [frontend] setting currency  (×20)
  06:48:26.211 [frontend] ENV_PLATFORM is: aws  (×26)
  06:48:26.901 [adservice] received ad request (context_words=[clothing, tops])  (×15)
  06:48:27.795 [adservice] received ad request (context_words=[hair, beauty])  (×22)
  06:48:30.014 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="JPY"  (×2)
  06:48:30.051 [paymentservice] Transaction processed: visa ending 4133 Amount: JPY147999.249890397  (×2)
  06:48:30.054 [shippingservice] [ShipOrder] received request  (×4)
  06:48:30.057 [cartservice] EmptyCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03  (×4)
  06:48:30.063 [checkoutservice] order confirmation email sent to "mccoymelissa@example.net"
  06:48:32.337 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="GBP"
  06:48:32.374 [paymentservice] Transaction processed: visa ending 3003 Amount: GBP1238.66859775
  06:48:32.389 [checkoutservice] order confirmation email sent to "ericlewis@example.org"
  06:49:03.817 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"4644","nanos":749271146},"credit_card":{"credit_card_number":"4729064398329
  06:49:03.833 [emailservice] A request to send order confirmation email to kelsey33@example.com has been received.
  06:49:08.994 [emailservice] A request to send order confirmation email to odonnelljeffrey@example.net has been received.

## p0307
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-22T03:20:17.954Z
```
{"timestamp":1732245617954985000,"container_name":"orders","pod_name":"orders-5fd66f9688-2x7kx","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-22 03:20:17.954 ERROR [orders,,,] 6 --- [p-nio-80-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalStateException: Unable to create order due to unspecified IO error.] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  03:20:06.586 [orders] 2024-11-22 03:20:06.586 ERROR [orders,,,] 6 --- [p-nio-80-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×6)
  03:20:06.587 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×10)
  03:20:09.137 [orders] 2024-11-22 03:20:09.137 ERROR [orders,,,] 6 --- [-nio-80-exec-14] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×4)
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×27)
  03:20:06.543 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff854b0df5c00019b1e7f\",\"_links\":{\"  (×44)
  03:20:06.586 [orders] 2024-11-22 03:20:06.586 ERROR [orders,,,] 6 --- [p-nio-80-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×25)
  03:20:06.649 [user] ts=2024-11-22T03:20:06.649242768Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff861b0df5c00019b1e9e took=1.734848ms  (×44)
  03:20:06.769 [front-end] User cart deleted with status: 503  (×44)
  03:20:06.803 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×7)
  03:20:07.186 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×9)
  03:20:08.469 [front-end] Posting Customer: {"username":"HNCLfJfsnW","password":"sSvsy","email":"HNCLfJfsnW@gmail.com","firstName":"HNCLfJfsnW","lastName":"HNCLfJfsnW"}
  03:20:08.498 [front-end] Carts merged.  (×35)
  03:20:09.093 [user] ts=2024-11-22T03:20:09.093533288Z caller=middlewares.go:46 method=Register username=CBhyKd email=CBhyKd@gmail.com took=1.350871ms
  03:20:09.192 [carts] 2024-11-22 03:20:09.192 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  03:20:10.049 [front-end] Posting Customer: {"username":"lPEGqahDSutlQTj","password":"AoWWVDzGsz","email":"lPEGqahDSutlQTj@gmail.com","firstName":"lPEGqahDSutlQTj","lastName":"lPEGqahDSu
  03:20:12.002 [front-end] Received response: "{\"firstName\":\"oVuSYHHeDcohK\",\"lastName\":\"oVuSYHHeDcohK\",\"username\":\"oVuSYHHeDcohK\",\"id\":\"673ff855b0df5c00019b1e85\",\"_links\
  03:20:14.429 [front-end] Posting Customer: {"username":"LWbxoNrjdrYfe","password":"dgukoXmQfq","email":"LWbxoNrjdrYfe@gmail.com","firstName":"LWbxoNrjdrYfe","lastName":"LWbxoNrjdrYfe"}
  03:20:16.376 [front-end] Posting Customer: {"username":"zCHyJV","password":"DBVYLG","email":"zCHyJV@gmail.com","firstName":"zCHyJV","lastName":"zCHyJV"}
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:20.340 [front-end] Posting Customer: {"username":"BBYdunXrngQk","password":"jbihHjN","email":"BBYdunXrngQk@gmail.com","firstName":"BBYdunXrngQk","lastName":"BBYdunXrngQk"}
  03:20:23.473 [front-end] Received response: "{\"firstName\":\"AIHRSQU\",\"lastName\":\"AIHRSQU\",\"username\":\"AIHRSQU\",\"id\":\"673ff863b0df5c00019b1ea2\",\"_links\":{\"addresses\":{
  03:20:26.017 [front-end] Posting Customer: {"username":"HLNoIPafm","password":"sBlBYfK","email":"HLNoIPafm@gmail.com","firstName":"HLNoIPafm","lastName":"HLNoIPafm"}
  03:20:28.421 [front-end] Posting Customer: {"username":"MoGml","password":"PJpiau","email":"MoGml@gmail.com","firstName":"MoGml","lastName":"MoGml"}
  03:20:30.252 [front-end] Posting Customer: {"username":"MKGIsEbVYi","password":"VhFAQhsXw","email":"MKGIsEbVYi@gmail.com","firstName":"MKGIsEbVYi","lastName":"MKGIsEbVYi"}
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.186 [front-end] Received response: "{\"firstName\":\"kgzVKACfUvkHp\",\"lastName\":\"kgzVKACfUvkHp\",\"username\":\"kgzVKACfUvkHp\",\"id\":\"673ff869b0df5c00019b1ebd\",\"_links\
  03:20:36.109 [front-end] Posting Customer: {"username":"HWsmCvxoMrNqX","password":"MJvuU","email":"HWsmCvxoMrNqX@gmail.com","firstName":"HWsmCvxoMrNqX","lastName":"HWsmCvxoMrNqX"}
  03:20:38.070 [session-db] 1:M 22 Nov 2024 03:20:38.070 * Background saving started by pid 32
  03:20:39.079 [user] ts=2024-11-22T03:20:39.079141282Z caller=middlewares.go:46 method=Register username=ELXzX email=ELXzX@gmail.com took=1.044635ms
  03:20:42.525 [front-end] Posting Customer: {"username":"jVIVRgJfOAq","password":"zWZXxq","email":"jVIVRgJfOAq@gmail.com","firstName":"jVIVRgJfOAq","lastName":"jVIVRgJfOAq"}
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:20:43.391 [carts] 2024-11-22 03:20:43.391 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:20:47.743 [front-end] Received response: "{\"firstName\":\"MoGml\",\"lastName\":\"MoGml\",\"username\":\"MoGml\",\"id\":\"673ff87cb0df5c00019b1efd\",\"_links\":{\"addresses\":{\"href

## p0111
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T05:12:32.767Z
```
{"timestamp":1731906752767081200,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-m2ddm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03"}
```
Same service, the 2 minutes before (oldest first):
  05:12:28.822 [cartservice] GetCartAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add  (×16)
  05:12:28.857 [cartservice] AddItemAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add, productId=L9ECAV7KIM, quantity=5  (×4)
All services, 30 seconds either side (sampled):
  05:12:03.170 [frontend] request started  (×348)
  05:12:03.177 [cartservice] GetCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×276)
  05:12:03.202 [adservice] received ad request (context_words=[kitchen])  (×57)
  05:12:03.692 [adservice] received ad request (context_words=[decor, home])  (×11)
  05:12:03.708 [frontend] view user cart  (×67)
  05:12:03.749 [frontend] placing order  (×16)
  05:12:03.772 [paymentservice] Transaction processed: visa ending 7312 Amount: EUR175.931003985  (×6)
  05:12:03.775 [shippingservice] [ShipOrder] completed request  (×16)
  05:12:03.788 [checkoutservice] order confirmation email sent to "henry98@example.com"
  05:12:04.381 [frontend] setting currency  (×31)
  05:12:04.436 [adservice] received ad request (context_words=[])  (×42)
  05:12:06.333 [emailservice] A request to send order confirmation email to fhernandez@example.org has been received.
  05:12:09.281 [adservice] received ad request (context_words=[clothing, tops])  (×24)
  05:12:11.837 [paymentservice] Transaction processed: visa ending 1111 Amount: TRY357.350917299  (×4)
  05:12:18.982 [emailservice] A request to send order confirmation email to ewilliams@example.com has been received.
  05:12:23.685 [checkoutservice] order confirmation email sent to "curtis08@example.com"
  05:12:28.706 [adservice] received ad request (context_words=[hair, beauty])  (×11)
  05:12:32.799 [paymentservice] Transaction processed: visa ending 6592 Amount: GBP1717.612919048  (×2)
  05:12:33.389 [emailservice] A request to send order confirmation email to bellsarah@example.net has been received.
  05:12:38.779 [checkoutservice] order confirmation email sent to "veronica23@example.org"
  05:12:44.450 [checkoutservice] [PlaceOrder] user_id="c216dec4-2181-4773-8cc5-aa587ee59fcc" user_currency="USD"  (×4)
  05:12:44.487 [emailservice] A request to send order confirmation email to alexandria09@example.net has been received.
  05:12:51.845 [emailservice] A request to send order confirmation email to bethany14@example.com has been received.
  05:12:52.212 [checkoutservice] order confirmation email sent to "stephen33@example.net"
  05:13:02.183 [emailservice] A request to send order confirmation email to wilsondeborah@example.com has been received.

## p0539
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T18:17:14.804Z
```
{"timestamp":1733595434804202800,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-894nw","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:17:14.803  INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl         : Routes Response is : Response(status=1, msg=Success, data={id=92708982-77af-4318-be25-57ccb0ff69ad, stations=[nanjing, zhenjiang, wuxi, suzhou, shanghai], distances=[0, 100, 150, 200, 250], startStationId=nanjing, terminalStationId=shanghai})"}
```
Same service, the 2 minutes before (oldest first):
  18:17:14.382 [ts-travel-service] 2024-12-07 18:17:14.382 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×7)
  18:17:14.389 [ts-travel-service] 2024-12-07 18:17:14.389 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  18:17:14.389 [ts-travel-service] 2024-12-07 18:17:14.389 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×3)
  18:17:14.410 [ts-travel-service] 2024-12-07 18:17:14.409 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
  18:17:14.484 [ts-travel-service] 2024-12-07 18:17:14.483 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
  18:17:14.501 [ts-travel-service] 2024-12-07 18:17:14.501 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  18:17:14.501 [ts-travel-service] 2024-12-07 18:17:14.501 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  18:17:14.517 [ts-travel-service] 2024-12-07 18:17:14.516 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×2)
  18:17:14.577 [ts-travel-service] 2024-12-07 18:17:14.577 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×2)
  18:17:14.679 [ts-travel-service] 2024-12-07 18:17:14.678 INFO 1 --- [io-12346-exec-6] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
All services, 30 seconds either side (sampled):
  18:16:44.870 [ts-seat-service] 2024-12-07 18:16:44.869 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×5)
  18:16:44.992 [ts-seat-service] 2024-12-07 18:16:44.992 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  18:16:45.168 [ts-seat-service] 2024-12-07 18:16:45.168 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×25)
  18:16:46.178 [ts-travel-service] 2024-12-07 18:16:46.177 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×23)
  18:16:46.235 [ts-order-other-service] 2024-12-07 18:16:46.234 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou  (×2)
  18:16:46.281 [ts-travel-service] 2024-12-07 18:16:46.281 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×14)
  18:16:46.422 [ts-travel-service] 2024-12-07 18:16:46.422 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×2)
  18:16:46.522 [ts-food-service] 2024-12-07 18:16:46.522 INFO 1 --- [io-18856-exec-4] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×3)
  18:16:46.915 [ts-contacts-service] 2024-12-07 18:16:46.915 INFO 1 --- [io-12347-exec-8] contacts.controller.ContactsController : [Contacts Service][Find Contacts By Account Id: 4d2a46c7-71cb-4cf1  (×2)
  18:16:46.954 [ts-security-service] 2024-12-07 18:16:46.954 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service][Get Order Num Info]  (×2)
  18:16:47.019 [ts-preserve-service] 2024-12-07 18:16:47.019 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Contacts Id: d14da0ec-da93-46c3-842d-23f
  18:16:47.126 [ts-auth-service] 2024-12-07 18:16:47.125 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×11)
  18:16:47.612 [ts-order-other-service] 2024-12-07 18:16:47.612 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×11)
  18:16:47.962 [ts-seat-service] 2024-12-07 18:16:47.962 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService distributeSeat] TrainNumber start with G|D
  18:16:48.093 [ts-order-service] 2024-12-07 18:16:48.093 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Order Create] Success.
  18:16:51.634 [ts-auth-service] 2024-12-07 18:16:51.633 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  18:16:53.316 [ts-basic-service] 2024-12-07 18:16:53.315 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：92708982-77  (×3)
  18:16:53.730 [ts-basic-service] 2024-12-07 18:16:53.730 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f  (×2)
  18:16:55.606 [ts-basic-service] 2024-12-07 18:16:55.605 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693
  18:17:01.436 [ts-travel2-service] 2024-12-07 18:17:01.436 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×17)
  18:17:09.203 [ts-price-service] 2024-12-07 18:17:09.203 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: a3f256c1-0e43-4f7d-9c2  (×2)
  18:17:14.601 [ts-food-map-service] 2024-12-07 18:17:14.601 INFO 1 --- [io-18855-exec-6] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×2)
  18:17:27.141 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:17:27.140+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359544
  18:17:29.736 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T18:17:29.736+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359544
  18:17:31.204 [ts-seat-service] 2024-12-07 18:17:31.203 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  18:17:39.495 [ts-preserve-other-service] 2024-12-07 18:17:39.495 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security
  18:17:40.424 [ts-travel2-service] 2024-12-07 18:17:40.424 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [TravelService] [getTripAllDetailInfo] endPlaceID: nanjing
  18:17:41.391 [ts-seat-service] 2024-12-07 18:17:41.391 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService distributeSeat] The request seat type is economyClass and the t
  18:17:41.680 [ts-preserve-other-service] 2024-12-07 18:17:41.680 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 5] Preserve Buy Assurance Success
  18:17:42.070 [ts-order-other-mongo] {"t":{"$date":"2024-12-07T18:17:42.070+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359546

## p0238
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service paymentservice, 2024-11-18T08:01:43.033Z
```
{"timestamp":1731916903033157000,"container_name":"paymentservice","pod_name":"paymentservice-856946df7c-dtzmh","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"UnacceptedCreditCard [Error]: Sorry, we cannot process visa_electron credit cards. Only VISA or MasterCard is accepted.\n    at charge (/usr/src/app/charge.js:74:68)\n    at HipsterShopServer.ChargeServiceHandler (/usr/src/app/server.js:44:24)\n    at clientStreamAndUnaryHandler (/usr/src/app/node_modules/@opentelemetry/instrumentation-grpc/build/src/serverUtils.js:97:21)\n    at Object.handleServerFu…"}
```
Same service, the 2 minutes before (oldest first):
  08:01:09.161 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"36","nanos":90416628},"credit_card":{"credit_card_number":"4962801018226422  (×2)
  08:01:09.161 [paymentservice] Transaction processed: visa ending 6422 Amount: CAD36.90416628  (×2)
  08:01:17.064 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"5183","nanos":538669657},"credit_card":{"credit_card_number":"4693056249261  (×4)
  08:01:17.064 [paymentservice] Transaction processed: visa ending 1658 Amount: TRY5183.538669657  (×4)
  08:01:19.638 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"78","nanos":681999117},"credit_card":{"credit_card_number":"416404450620327  (×3)
  08:01:19.638 [paymentservice] Transaction processed: visa ending 3274 Amount: EUR78.681999117  (×3)
  08:01:43.032 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"52370","nanos":186643605},"credit_card":{"credit_card_number":"450880959968
  08:01:43.032 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
All services, 30 seconds either side (sampled):
  08:01:13.212 [frontend] request started  (×346)
  08:01:13.219 [cartservice] GetCartAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0  (×284)
  08:01:13.243 [adservice] received ad request (context_words=[decor, home])  (×16)
  08:01:13.252 [cartservice] AddItemAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0, productId=0PUK6V6EV0, quantity=3  (×42)
  08:01:13.285 [shippingservice] [GetQuote] completed request  (×88)
  08:01:13.658 [adservice] received ad request (context_words=[kitchen])  (×51)
  08:01:14.257 [adservice] received ad request (context_words=[])  (×32)
  08:01:17.031 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="TRY"  (×4)
  08:01:17.067 [checkoutservice] payment went through (transaction_id: 69263f3c-754e-4af4-9c7a-016cf77056e0)  (×12)
  08:01:17.072 [cartservice] EmptyCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×12)
  08:01:17.080 [checkoutservice] failed to send order confirmation to "alexanderbaker@example.com": rpc error: code = Internal desc = Failed to serialize response!
  08:01:17.671 [emailservice] A request to send order confirmation email to tedwards@example.org has been received.
  08:01:19.626 [frontend] setting currency  (×20)
  08:01:19.650 [emailservice] A request to send order confirmation email to stoneveronica@example.org has been received.
  08:01:26.970 [emailservice] A request to send order confirmation email to benjamin28@example.net has been received.
  08:01:27.063 [redis] 1:M 18 Nov 2024 08:01:27.063 * Background saving started by pid 82
  08:01:27.164 [redis] 1:M 18 Nov 2024 08:01:27.164 * Background saving terminated with success
  08:01:34.680 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '2ZYFJ3GM2N', '0PUK6V6EV0']  (×4)
  08:01:42.042 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="CAD"  (×4)
  08:01:42.074 [emailservice] A request to send order confirmation email to spencer71@example.com has been received.
  08:01:42.110 [checkoutservice] failed to send order confirmation to "stanleyhorn@example.com": rpc error: code = Internal desc = Failed to serialize response!
  08:01:43.032 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"52370","nanos":186643605},"credit_card":{"credit_card_number":"450880959968
  08:01:43.036 [frontend] request error
  08:01:59.400 [emailservice] A request to send order confirmation email to jsanchez@example.org has been received.
  08:02:01.038 [checkoutservice] failed to send order confirmation to "jessicamanning@example.net": rpc error: code = Internal desc = Failed to serialize response!

## p0454
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-23T08:06:25.406Z
```
{"timestamp":1732349185406519300,"container_name":"orders","pod_name":"orders-7fff6698cb-rlq5k","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:25.406 ERROR [orders,,,] 8 --- [p-nio-80-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalStateException: Unable to create order due to unspecified IO error.] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  08:06:16.810 [orders] 2024-11-23 08:06:16.810 ERROR [orders,,,] 8 --- [p-nio-80-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×9)
  08:06:16.810 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×10)
  08:06:21.980 [orders] 2024-11-23 08:06:21.980 ERROR [orders,,,] 8 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
All services, 30 seconds either side (sampled):
  08:05:55.473 [front-end] Request received with body: {}  (×63)
  08:05:55.655 [user] ts=2024-11-23T08:05:55.655255774Z caller=middlewares.go:46 method=Register username=LeJTlhMOCH email=LeJTlhMOCH@gmail.com took=2.397295ms  (×34)
  08:05:56.539 [front-end] POST /addresses 200 - ms - -  (×62)
  08:05:57.198 [shipping] 2024-11-23 08:05:57.110 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.cont
  08:05:59.478 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×4)
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}/merge],methods=[GET]}" onto publi
  08:06:05.306 [carts] 2024-11-23 08:06:05.305 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springfram
  08:06:07.003 [shipping] 2024-11-23 08:06:07.003 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[applic
  08:06:07.100 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],pro
  08:06:10.127 [front-end] Posting Customer: {"username":"SPVlWNNsjeesK","password":"GJzTi","email":"SPVlWNNsjeesK@gmail.com","firstName":"SPVlWNNsjeesK","lastName":"SPVlWNNsjeesK"}
  08:06:14.307 [shipping] 2024-11-23 08:06:14.306 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetec
  08:06:15.799 [carts] 2024-11-23 08:06:15.799 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/hal+  (×2)
  08:06:15.810 [carts] 2024-11-23 08:06:15.810 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[GET],produces=[  (×2)
  08:06:16.474 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×2)
  08:06:19.008 [carts] 2024-11-23 08:06:19.008 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public j
  08:06:20.059 [front-end] Received response: "{\"firstName\":\"RKNDdSk\",\"lastName\":\"RKNDdSk\",\"username\":\"RKNDdSk\",\"id\":\"67418ce7a437380001deec7c\",\"_links\":{\"addresses\":{
  08:06:24.200 [carts] 2024-11-23 08:06:24.200 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  08:06:26.651 [user] ts=2024-11-23T08:06:26.651741419Z caller=middlewares.go:46 method=Register username=spaWHNsfk email=spaWHNsfk@gmail.com took=2.544731ms
  08:06:29.091 [front-end] Posting Customer: {"username":"cuFLCUGugozmeyi","password":"nwyWXtdv","email":"cuFLCUGugozmeyi@gmail.com","firstName":"cuFLCUGugozmeyi","lastName":"cuFLCUGugozm
  08:06:31.811 [carts-db] {"t":{"$date":"2024-11-23T08:06:31.811+00:00"},"s":"I", "c":"STORAGE", "id":20279, "ctx":"conn12","msg":"Conflicted creating a collection","attr":{"namespace":"  (×13)
  08:06:33.281 [front-end] Posting Customer: {"username":"HotpHJJrtTu","password":"ejnRG","email":"HotpHJJrtTu@gmail.com","firstName":"HotpHJJrtTu","lastName":"HotpHJJrtTu"}
  08:06:35.457 [front-end] Posting Customer: {"username":"KarxuPo","password":"sUyEQyb","email":"KarxuPo@gmail.com","firstName":"KarxuPo","lastName":"KarxuPo"}
  08:06:36.203 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d0c3f77060008864e41","customerId":"67418cf9a437380001deeca9","customer":{"id":null,"firstName":"WPDZdEO","l
  08:06:40.821 [queue-master] org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket-factory-20
  08:06:42.150 [user] ts=2024-11-23T08:06:42.149893938Z caller=middlewares.go:46 method=Register username=Wnzho email=Wnzho@gmail.com took=1.902749ms
  08:06:43.922 [front-end] Order response: {"id":"67418d133f77060008864e45","customerId":"67418cf8a437380001deeca7","customer":{"id":null,"firstName":"GXUtAA","lastName":"GXUtAA","usernam
  08:06:48.326 [front-end] Posting Customer: {"username":"BmPHiTV","password":"skksJp","email":"BmPHiTV@gmail.com","firstName":"BmPHiTV","lastName":"BmPHiTV"}
  08:06:49.893 [front-end] Order response: {"id":"67418d193f77060008864e4f","customerId":"67418d01a437380001deecbe","customer":{"id":null,"firstName":"HRFgUBgyU","lastName":"HRFgUBgyU","u
  08:06:53.483 [front-end] Order response: {"id":"67418d1d3f77060008864e54","customerId":"67418d09a437380001deecda","customer":{"id":null,"firstName":"HotpHJJrtTu","lastName":"HotpHJJrtTu

## p0802
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-08T08:42:06.503Z
```
{"timestamp":1733647326503306200,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-7kts9","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-08 08:42:06.502  INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl       : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f   USER ID"}
```
Same service, the 2 minutes before (oldest first):
  08:41:55.009 [ts-auth-service] 2024-12-08 08:41:55.009 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : 4c7ef37c-e8cb-4d29-aaca-62bd7a8da985 USER ID  (×5)
  08:42:03.563 [ts-auth-service] 2024-12-08 08:42:03.561 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×4)
  08:42:03.563 [ts-auth-service] 2024-12-08 08:42:03.561 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×4)
  08:42:03.886 [ts-auth-service] 2024-12-08 08:42:03.885 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×5)
  08:42:06.273 [ts-auth-service] 2024-12-08 08:42:06.272 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null
  08:42:06.273 [ts-auth-service] 2024-12-08 08:42:06.273 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
All services, 30 seconds either side (sampled):
  08:41:36.811 [ts-admin-basic-info-service] 2024-12-08 08:41:36.811 ERROR 1 --- [io-18767-exec-9] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×31)
  08:41:36.821 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:41:36 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 500 238 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_  (×17)
  08:41:37.937 [ts-order-other-service] 2024-12-08 08:41:37.937 ERROR 1 --- [o-12032-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  08:41:38.803 [ts-auth-service] 2024-12-08 08:41:38.803 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×11)
  08:41:39.003 [ts-auth-service] 2024-12-08 08:41:39.002 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×26)
  08:41:39.018 [ts-travel2-service] 2024-12-08 08:41:39.018 ERROR 1 --- [io-16346-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×9)
  08:41:40.915 [ts-auth-service] 2024-12-08 08:41:40.914 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×16)
  08:41:41.123 [ts-admin-travel-service] 2024-12-08 08:41:41.123 ERROR 1 --- [io-16114-exec-9] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×15)
  08:41:42.029 [ts-food-service] 2024-12-08 08:41:42.029 ERROR 1 --- [io-18856-exec-1] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×4)
  08:41:42.039 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:41:42 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 500 259 "-" "Mozilla/5.0 (Macintosh;   (×5)
  08:41:48.934 [ts-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×2)
  08:41:50.417 [ts-travel2-service] 2024-12-08 08:41:50.416 ERROR 1 --- [o-16346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  08:41:55.425 [ts-order-service] 2024-12-08 08:41:55.425 ERROR 1 --- [io-12031-exec-1] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×2)
  08:41:55.429 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:41:55 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 500 229 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Apple  (×2)
  08:42:08.642 [ts-route-mongo] {"t":{"$date":"2024-12-08T08:42:08.641+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364732
  08:42:09.713 [ts-contacts-mongo] {"t":{"$date":"2024-12-08T08:42:09.713+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364732
  08:42:09.783 [ts-user-mongo] {"t":{"$date":"2024-12-08T08:42:09.782+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364732
  08:42:09.931 [ts-station-mongo] {"t":{"$date":"2024-12-08T08:42:09.931+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364732
  08:42:10.001 [ts-config-mongo] {"t":{"$date":"2024-12-08T08:42:10.000+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364733
  08:42:11.461 [ts-security-mongo] {"t":{"$date":"2024-12-08T08:42:11.461+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364733
  08:42:11.871 [ts-payment-mongo] {"t":{"$date":"2024-12-08T08:42:11.870+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364733
  08:42:12.521 [ts-consign-price-mongo] {"t":{"$date":"2024-12-08T08:42:12.521+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364733
  08:42:34.915 [ts-food-service] 2024-12-08 08:42:34.915 ERROR 1 --- [o-18856-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt

## p0492
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:10:15.852Z
```
{"timestamp":1732353015852296000,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:10:15.852203989Z caller=middlewares.go:75 method=GetUsers id=67419be4a437380001df090f result=1 took=2.252457ms"}
```
Same service, the 2 minutes before (oldest first):
  09:10:11.355 [user] ts=2024-11-23T09:10:11.355069404Z caller=middlewares.go:75 method=GetUsers id=67419bd9a437380001df08e5 result=1 took=2.306512ms  (×12)
  09:10:12.129 [user] ts=2024-11-23T09:10:12.129500965Z caller=middlewares.go:46 method=Register username=SLrgdKUbWHBo email=SLrgdKUbWHBo@gmail.com took=2.651856ms  (×3)
  09:10:12.360 [user] ts=2024-11-23T09:10:12.359795705Z caller=middlewares.go:46 method=Register username=aqJlxrRC email=aqJlxrRC@gmail.com took=2.316594ms
  09:10:13.352 [user] ts=2024-11-23T09:10:13.352265856Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419befa437380001df0934 took=4.024898ms
  09:10:13.366 [user] ts=2024-11-23T09:10:13.366299041Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419befa437380001df0934 took=3.139254ms
  09:10:13.850 [user] ts=2024-11-23T09:10:13.850106147Z caller=middlewares.go:157 method=Health result=2 took=2.23302ms  (×2)
All services, 30 seconds either side (sampled):
  09:09:45.855 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67419bcfa437380001df08c4"}  (×65)
  09:09:45.971 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×11)
  09:09:46.308 [front-end] Posting Customer: {"username":"xtxPLLWuWnpjQF","password":"RiNSMR","email":"xtxPLLWuWnpjQF@gmail.com","firstName":"xtxPLLWuWnpjQF","lastName":"xtxPLLWuWnpjQF"}
  09:09:46.883 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×10)
  09:09:47.114 [front-end] Order response: "upstream connect error or disconnect/reset before headers. retried and the latest reset reason: remote connection failure, transport failure re  (×51)
  09:09:48.250 [orders] 2024-11-23 09:09:48.250 INFO [orders,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  09:09:50.985 [front-end] Posting Customer: {"username":"wZawFqWVlWDE","password":"wUssT","email":"wZawFqWVlWDE@gmail.com","firstName":"wZawFqWVlWDE","lastName":"wZawFqWVlWDE"}
  09:09:53.864 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×10)
  09:09:57.646 [front-end] Received response: "{\"firstName\":\"jEsCW\",\"lastName\":\"jEsCW\",\"username\":\"jEsCW\",\"id\":\"67419bd1a437380001df08c8\",\"_links\":{\"addresses\":{\"href
  09:10:01.527 [front-end] Posting Customer: {"username":"SyUWOSkBafKaPUW","password":"TPGpUuBj","email":"SyUWOSkBafKaPUW@gmail.com","firstName":"SyUWOSkBafKaPUW","lastName":"SyUWOSkBafKa
  09:10:04.594 [front-end] Received response: "{\"firstName\":\"nnezb\",\"lastName\":\"nnezb\",\"username\":\"nnezb\",\"id\":\"67419bd7a437380001df08dd\",\"_links\":{\"addresses\":{\"href
  09:10:10.465 [front-end] Posting Customer: {"username":"hZzUAUPzUL","password":"aJIfU","email":"hZzUAUPzUL@gmail.com","firstName":"hZzUAUPzUL","lastName":"hZzUAUPzUL"}
  09:10:12.348 [front-end] Posting Customer: {"username":"aqJlxrRC","password":"QZTHeAG","email":"aqJlxrRC@gmail.com","firstName":"aqJlxrRC","lastName":"aqJlxrRC"}
  09:10:15.452 [orders] 2024-11-23 09:10:15.452 INFO [orders,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/**] onto handler of type [class org.
  09:10:17.479 [front-end] Received response: "{\"firstName\":\"DaesKhcrGFoJWqE\",\"lastName\":\"DaesKhcrGFoJWqE\",\"username\":\"DaesKhcrGFoJWqE\",\"id\":\"67419be9a437380001df091f\",\"_
  09:10:20.474 [front-end] Posting Customer: {"username":"sEUvKWWDBpK","password":"qqvOkiR","email":"sEUvKWWDBpK@gmail.com","firstName":"sEUvKWWDBpK","lastName":"sEUvKWWDBpK"}
  09:10:23.049 [orders] 2024-11-23 09:10:23.048 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/ha
  09:10:23.137 [orders] 2024-11-23 09:10:23.137 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT |
  09:10:23.145 [orders] 2024-11-23 09:10:23.145 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[OPTIONS],produces=[appl
  09:10:24.569 [user] ts=2024-11-23T09:10:24.56947986Z caller=middlewares.go:46 method=Register username=weoLGLUsT email=weoLGLUsT@gmail.com took=2.004024ms
  09:10:25.439 [orders] 2024-11-23 09:10:25.439 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applicati
  09:10:25.538 [orders] 2024-11-23 09:10:25.538 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produce
  09:10:29.544 [orders] 2024-11-23 09:10:29.543 INFO [orders,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  09:10:29.939 [orders] 2024-11-23 09:10:29.939 INFO [orders,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering w
  09:10:32.937 [orders] 2024-11-23 09:10:32.937 INFO [orders,,,] 7 --- [p-nio-80-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comple
  09:10:34.757 [front-end] Order response: {"statusCode":400,"body":{"cause":{"cause":{"cause":null,"message":"Conflicting setter definitions for property \"items\": works.weave.socks.ord  (×13)
  09:10:37.459 [user] ts=2024-11-23T09:10:37.458805618Z caller=middlewares.go:46 method=Register username=XFeeVfI email=XFeeVfI@gmail.com took=3.037121ms
  09:10:41.963 [user] ts=2024-11-23T09:10:41.963544694Z caller=middlewares.go:46 method=Register username=JuJgbb email=JuJgbb@gmail.com took=2.427958ms

## p0226
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service checkoutservice, 2024-11-18T07:52:03.946Z
```
{"timestamp":1731916323946608000,"container_name":"checkoutservice","pod_name":"checkoutservice-7ff8db989f-zrkdv","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"failed to send order confirmation to \"roachjames@example.net\": rpc error: code = Internal desc = Failed to serialize response!"}
```
Same service, the 2 minutes before (oldest first):
  07:50:58.106 [checkoutservice] payment went through (transaction_id: cdafb61a-935a-4e15-b4e0-5c7c8ef06258)  (×7)
  07:50:58.116 [checkoutservice] order confirmation email sent to "marcwilliams@example.net"
  07:51:05.034 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="JPY"
  07:51:05.095 [checkoutservice] order confirmation email sent to "xclark@example.net"
  07:51:10.580 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="GBP"
  07:51:10.620 [checkoutservice] order confirmation email sent to "mccoyheather@example.com"
  07:51:19.511 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="CAD"
  07:51:19.562 [checkoutservice] order confirmation email sent to "sshah@example.org"
  07:51:46.135 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="USD"
  07:51:46.178 [checkoutservice] order confirmation email sent to "cjoseph@example.org"
  07:51:57.628 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="TRY"
  07:51:57.671 [checkoutservice] order confirmation email sent to "brucemitchell@example.org"
  07:52:03.888 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="EUR"
  07:52:03.923 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 13
All services, 30 seconds either side (sampled):
  07:51:34.234 [frontend] request started  (×320)
  07:51:34.241 [cartservice] GetCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121  (×266)
  07:51:34.265 [adservice] received ad request (context_words=[kitchen])  (×55)
  07:51:34.272 [cartservice] AddItemAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121, productId=LS4PSXUNUM, quantity=2  (×30)
  07:51:34.307 [shippingservice] [GetQuote] completed request  (×80)
  07:51:36.564 [adservice] received ad request (context_words=[hair, beauty])  (×14)
  07:51:36.814 [frontend] ENV_PLATFORM is: aws  (×32)
  07:51:40.300 [adservice] received ad request (context_words=[footwear])  (×13)
  07:51:46.165 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"634","nanos":320000000},"credit_card":{"credit_card_number":"43957631712654  (×4)
  07:51:46.169 [shippingservice] [ShipOrder] received request  (×11)
  07:51:46.177 [emailservice] A request to send order confirmation email to cjoseph@example.org has been received.
  07:51:48.870 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '66VCHSJNUP']  (×3)
  07:51:57.658 [paymentservice] Transaction processed: visa ending 9776 Amount: TRY11302.658447622
  07:52:00.558 [emailservice] starting the email service in dummy mode.
  07:52:03.888 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="EUR"  (×2)
  07:52:03.923 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 13  (×9)
  07:52:05.455 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"98","nanos":944212294},"credit_card":{"credit_card_number":"403844449262696  (×3)
  07:52:05.470 [checkoutservice] failed to send order confirmation to "ccraig@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:52:16.642 [emailservice] A request to send order confirmation email to cardenasjennifer@example.com has been received.
  07:52:17.897 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"74792","nanos":350287706},"credit_card":{"credit_card_number":"447982288529
  07:52:17.913 [checkoutservice] failed to send order confirmation to "karenmueller@example.net": rpc error: code = Internal desc = Failed to serialize response!
  07:52:24.904 [emailservice] A request to send order confirmation email to maryanthony@example.net has been received.
  07:52:26.986 [checkoutservice] failed to send order confirmation to "julie62@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:52:33.589 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N']

## p0704
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-12T22:31:05.504Z
```
{"service":"webservice2","message":"2021-08-12 22:31:05,504 | INFO | 0.0.0.3 | webservice2 | web_helper.py -> web_service_resource -> 69 | ae31b67da2ea71f0 | now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  22:31:02.899 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  22:31:02.899 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  22:31:02.900 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'ebb378bc-fb79-11eb-becc-0242ac110004', 'value': '', 'ex': 10}  (×3)
  22:31:02.990 [webservice2] INFO uuid: ebb378bc-fb79-11eb-becc-0242ac110004 write redis successfully  (×3)
  22:31:03.095 [webservice2] INFO complete information: {'uuid': 'ebb378bc-fb79-11eb-becc-0242ac110004', 'user_id': 'rfqKcNpJ'}  (×3)
  22:31:03.102 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×2)
  22:31:03.102 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×2)
All services, 30 seconds either side (sampled):
  22:30:35.508 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×45)
  22:30:35.705 [redisservice1] INFO redis write success  (×88)
  22:30:35.867 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×49)
  22:30:36.182 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  22:30:36.462 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  22:30:36.999 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×44)
  22:30:37.980 [dbservice2] INFO dc70cfd0-fb79-11eb-9a2d-0242ac110004-AOMaRpbl-TzUn?{3BhA#u token generate success token=MTYyODc3ODYzNy45Nzk5ODg4OmRjNzBjZmQwLWZiNzktMTFlYi05YTJkLTAyNDJhYzE
  22:30:38.333 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×40)
  22:30:39.482 [webservice2] ERROR an error occurred in the downstream service  (×2)
  22:30:41.903 [dbservice1] INFO dec18194-fb79-11eb-9887-0242ac110003-CqkgPMzS-WeqwoNsm=)Tb token generate success token=MTYyODc3ODY0MS45MDMxNTk6ZGVjMTgxOTQtZmI3OS0xMWViLTk4ODctMDI0MmFjMTE
  22:30:44.310 [dbservice1] INFO e03aa50a-fb79-11eb-be94-0242ac110003-vtpXmFKe-o%tl^Y:5g8X) token generate success token=MTYyODc3ODY0NC4zMDk3NDU2OmUwM2FhNTBhLWZiNzktMTFlYi1iZTk0LTAyNDJhYzE
  22:30:47.230 [mobservice1] INFO info e2276916-fb79-11eb-872d-0242ac110003:HfPCXKQO write success
  22:30:49.454 [mobservice1] INFO info e372ef66-fb79-11eb-92db-0242ac110003:CWflULak write success
  22:30:52.190 [dbservice2] INFO e4e51d56-fb79-11eb-81c3-0242ac110004-SxqMsOuL-:2a1uw?dZf4s token generate success token=MTYyODc3ODY1Mi4xOTAxNTAzOmU0ZTUxZDU2LWZiNzktMTFlYi04MWMzLTAyNDJhYzE
  22:30:54.835 [dbservice1] INFO e67e49e4-fb79-11eb-8a89-0242ac110004-APxbpyWu-<Fk%s3dztCD} token generate success token=MTYyODc3ODY1NC44MzUyNjE6ZTY3ZTQ5ZTQtZmI3OS0xMWViLThhODktMDI0MmFjMTE
  22:30:57.453 [mobservice2] INFO info e8389a0a-fb79-11eb-bced-0242ac110003:jliMGRSf write success
  22:31:00.286 [dbservice2] INFO e9b41cc4-fb79-11eb-90e1-0242ac110004-VxubFBRX-Qgr73J_$>S}{ token generate success token=MTYyODc3ODY2MC4yODU5MTQ0OmU5YjQxY2M0LWZiNzktMTFlYi05MGUxLTAyNDJhYzE
  22:31:03.090 [mobservice1] INFO info eb8c9bc0-fb79-11eb-9d35-0242ac110003:cqyYsFCP write success
  22:31:05.242 [dbservice1] INFO ecaddcc6-fb79-11eb-a265-0242ac110003-ocYXAMHN-9(D$TR<G6AB# token generate success token=MTYyODc3ODY2NS4yNDE3OTI3OmVjYWRkY2M2LWZiNzktMTFlYi1hMjY1LTAyNDJhYzE
  22:31:07.783 [dbservice2] INFO ee2b570e-fb79-11eb-8bd7-0242ac110003-wHINnpBP-:ReXuAG#4}Vk token generate success token=MTYyODc3ODY2Ny43ODI4Nzg2OmVlMmI1NzBlLWZiNzktMTFlYi04YmQ3LTAyNDJhYzE
  22:31:10.106 [dbservice2] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  22:31:13.345 [dbservice2] INFO f18e180a-fb79-11eb-8e66-0242ac110003-SqZIftDu-2viZseq}_$Ql token generate success token=MTYyODc3ODY3My4zNDU0MjczOmYxOGUxODBhLWZiNzktMTFlYi04ZTY2LTAyNDJhYzE
  22:31:15.749 [dbservice1] INFO f2f59ca4-fb79-11eb-a71b-0242ac110004-zHhwQRUN-@szSJB:VtK-0 token generate success token=MTYyODc3ODY3NS43NDk1MjgyOmYyZjU5Y2E0LWZiNzktMTFlYi1hNzFiLTAyNDJhYzE
  22:31:18.118 [dbservice1] INFO f45fc45c-fb79-11eb-9aa2-0242ac110004-HygISCUR-nDh8._Bb7*Ce token generate success token=MTYyODc3ODY3OC4xMTgwMTU1OmY0NWZjNDVjLWZiNzktMTFlYi05YWEyLTAyNDJhYzE
  22:31:24.617 [dbservice1] INFO f83e20aa-fb79-11eb-80be-0242ac110004-dlSUhBPw-hiF@GvoORl3% token generate success token=MTYyODc3ODY4NC42MTczMzE3OmY4M2UyMGFhLWZiNzktMTFlYi04MGJlLTAyNDJhYzE
  22:31:26.978 [dbservice2] INFO f9a9fcca-fb79-11eb-821e-0242ac110003-IMzHpvSY-bhtqgr.x2AfF token generate success token=MTYyODc3ODY4Ni45Nzc3MTY6ZjlhOWZjY2EtZmI3OS0xMWViLTgyMWUtMDI0MmFjMTE
  22:31:29.332 [dbservice1] INFO fb06290e-fb79-11eb-b1fd-0242ac110004-TPLgkydZ-JzLaE1$ZSh<= token generate success token=MTYyODc3ODY4OS4zMzE3NjIzOmZiMDYyOTBlLWZiNzktMTFlYi1iMWZkLTAyNDJhYzE
  22:31:31.776 [dbservice1] INFO fc744294-fb79-11eb-af5f-0242ac110004-CyDlcYMP-RIuS(51-$4.P token generate success token=MTYyODc3ODY5MS43NzYwNjczOmZjNzQ0Mjk0LWZiNzktMTFlYi1hZjVmLTAyNDJhYzE
  22:31:34.544 [dbservice2] INFO fe219556-fb79-11eb-85d0-0242ac110003-CkWFaQYZ-7JwrWYRM-C^D token generate success token=MTYyODc3ODY5NC41NDM5ODg3OmZlMjE5NTU2LWZiNzktMTFlYi04NWQwLTAyNDJhYzE

## p0423
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T04:08:22.177Z
```
{"timestamp":1732248502177992000,"container_name":"front-end","pod_name":"front-end-ccbbfbf7f-szg8d","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"_embedded\\\":{\\\"address\\\":[{\\\"street\\\":\\\"123\\\",\\\"number\\\":\\\"123\\\",\\\"country\\\":\\\"123\\\",\\\"city\\\":\\\"123\\\",\\\"postcode\\\":\\\"123\\\",\\\"id\\\":\\\"674003abb0df5c00019b4131\\\",\\\"_links\\\":{\\\"address\\\":{\\\"href\\\":\\\"http://user/addresses/674003abb0df5c00019b4131\\\"},\\\"self\\\":{\\\"href\\\":\\\"http://user/addresses/674003abb0df5c00019b4131\\\"}}}]}}\\n\""}
```
Same service, the 2 minutes before (oldest first):
  04:08:21.833 [front-end] Attempting to delete cart for user: 674003adb0df5c00019b4139  (×2)
  04:08:21.854 [front-end] User cart deleted with status: 202  (×2)
  04:08:21.855 [front-end] DELETE /cart 202 - ms - -  (×2)
  04:08:21.860 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674003adb0df5c00019b4138"}
  04:08:21.862 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×2)
  04:08:21.869 [front-end] POST /cards 200 - ms - -
  04:08:21.872 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
  04:08:21.872 [front-end] POST to carts: http://carts/carts/674003adb0df5c00019b4139/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}  (×2)
  04:08:21.921 [front-end] POST /cart 500 57.790 ms - 70  (×2)
  04:08:21.956 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  04:08:22.163 [front-end] Request received with body: {}
  04:08:22.171 [front-end] Received response: "{\"firstName\":\"CrgKatnF\",\"lastName\":\"CrgKatnF\",\"username\":\"CrgKatnF\",\"id\":\"674003a3b0df5c00019b4112\",\"_links\":{\"addresses\
  04:08:22.171 [front-end] GET Request to: http://user/customers/674003a3b0df5c00019b4112/addresses  (×2)
All services, 30 seconds either side (sampled):
  04:07:52.187 [front-end] Request received with body: {}  (×63)
  04:07:52.226 [payment] ts=2024-11-22T04:07:52Z caller=logging.go:29 method=Authorise result=true took=1.017µs  (×18)
  04:07:52.393 [catalogue] ts=2024-11-22T04:07:52Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.506759ms  (×67)
  04:07:53.037 [front-end] POST /register 200 32.967 ms - 33  (×58)
  04:07:54.099 [front-end] POST /addresses 200 - ms - -  (×54)
  04:07:54.227 [carts] 2024-11-22 04:07:54.227 INFO [carts,1361c6d576f1a028,fc1a810401108ca5,false] 7 --- [-nio-80-exec-20] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×40)
  04:07:54.606 [carts] 2024-11-22 04:07:54.606 INFO [carts,6abc81d6b51b5490,0e05b4b9d5e884b2,false] 7 --- [-nio-80-exec-23] w.w.s.cart.controllers.CartsController : Merge carts reques  (×37)
  04:07:56.553 [front-end] Order response: {"statusCode":201,"body":{"id":"6740039cd94b9000069b4c53","customerId":"67400382b0df5c00019b40b1","customer":{"id":null,"firstName":"mvmWidiR","
  04:07:58.403 [front-end] Received response: "{\"firstName\":\"GDqspo\",\"lastName\":\"GDqspo\",\"username\":\"GDqspo\",\"id\":\"6740038eb0df5c00019b40df\",\"_links\":{\"addresses\":{\"h
  04:08:02.019 [user] ts=2024-11-22T04:08:02.019610281Z caller=middlewares.go:46 method=Register username=PeYmis email=PeYmis@gmail.com took=1.068313ms
  04:08:04.224 [front-end] Order response: {"statusCode":201,"body":{"id":"674003a4d94b9000069b4c59","customerId":"6740038eb0df5c00019b40e0","customer":{"id":null,"firstName":"oRGAeskxzcD
  04:08:07.389 [front-end] Order response: {"statusCode":201,"body":{"id":"674003a7d94b9000069b4c5a","customerId":"67400390b0df5c00019b40e3","customer":{"id":null,"firstName":"bPueE","las
  04:08:09.464 [user] ts=2024-11-22T04:08:09.463919875Z caller=middlewares.go:46 method=Register username=RJvvrtNb email=RJvvrtNb@gmail.com took=1.074306ms
  04:08:11.747 [user] ts=2024-11-22T04:08:11.746729949Z caller=middlewares.go:46 method=Register username=qFeBgqG email=qFeBgqG@gmail.com took=1.108526ms
  04:08:13.299 [front-end] Order response: {"statusCode":201,"body":{"id":"674003add94b9000069b4c60","customerId":"67400399b0df5c00019b40f7","customer":{"id":null,"firstName":"KjEuuALysjr
  04:08:17.188 [user] ts=2024-11-22T04:08:17.188273548Z caller=middlewares.go:46 method=Register username=zgqwDgZ email=zgqwDgZ@gmail.com took=1.003037ms
  04:08:19.878 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×4)
  04:08:21.732 [front-end] Received response: "{\"firstName\":\"DbigCh\",\"lastName\":\"DbigCh\",\"username\":\"DbigCh\",\"id\":\"674003a3b0df5c00019b4111\",\"_links\":{\"addresses\":{\"h
  04:08:24.143 [front-end] Posting Customer: {"username":"pqXCREkDHHahPFk","password":"IEOJMABb","email":"pqXCREkDHHahPFk@gmail.com","firstName":"pqXCREkDHHahPFk","lastName":"pqXCREkDHHah
  04:08:27.587 [front-end] Received response: "{\"firstName\":\"SOJro\",\"lastName\":\"SOJro\",\"username\":\"SOJro\",\"id\":\"674003a3b0df5c00019b4110\",\"_links\":{\"addresses\":{\"href
  04:08:29.100 [front-end] Order response: {"id":"674003bdd94b9000069b4c70","customerId":"674003adb0df5c00019b4138","customer":{"id":null,"firstName":"VjqVALl","lastName":"VjqVALl","usern
  04:08:30.858 [front-end] Received response: "{\"firstName\":\"ZhqZKdoOwO\",\"lastName\":\"ZhqZKdoOwO\",\"username\":\"ZhqZKdoOwO\",\"id\":\"674003acb0df5c00019b4133\",\"_links\":{\"addr
  04:08:34.372 [front-end] Received response: "{\"firstName\":\"iZHjaAfG\",\"lastName\":\"iZHjaAfG\",\"username\":\"iZHjaAfG\",\"id\":\"674003aab0df5c00019b4128\",\"_links\":{\"addresses\
  04:08:35.937 [front-end] Order response: {"id":"674003c3d94b9000069b4c7a","customerId":"674003b0b0df5c00019b4145","customer":{"id":null,"firstName":"doOYdMhAIMudoV","lastName":"doOYdMhA
  04:08:39.404 [front-end] Received response: "{\"firstName\":\"pqXCREkDHHahPFk\",\"lastName\":\"pqXCREkDHHahPFk\",\"username\":\"pqXCREkDHHahPFk\",\"id\":\"674003b8b0df5c00019b4161\",\"_
  04:08:45.091 [front-end] Order response: {"statusCode":201,"body":{"id":"674003cdd94b9000069b4c7f","customerId":"674003b4b0df5c00019b414f","customer":{"id":null,"firstName":"ILWOEKIzKoE
  04:08:49.523 [front-end] Posting Customer: {"username":"mTJSUzkPOBuwIv","password":"iPwRIYdI","email":"mTJSUzkPOBuwIv@gmail.com","firstName":"mTJSUzkPOBuwIv","lastName":"mTJSUzkPOBuwIv"
  04:08:51.552 [front-end] Received response: "{\"firstName\":\"DnIfyapiTyEZEXK\",\"lastName\":\"DnIfyapiTyEZEXK\",\"username\":\"DnIfyapiTyEZEXK\",\"id\":\"674003c4b0df5c00019b417e\",\"_

## p0513
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:40:52.146Z
```
{"timestamp":1732358452146468600,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"6741b134a437380001df4a8f"}
```
Same service, the 2 minutes before (oldest first):
  10:40:51.353 [front-end] POST /orders 503 - ms - -
  10:40:51.625 [front-end] Posting Customer: {"username":"PMMsVPkCBtB","password":"SgIrFoXQv","email":"PMMsVPkCBtB@gmail.com","firstName":"PMMsVPkCBtB","lastName":"PMMsVPkCBtB"}
  10:40:51.634 [front-end] { id: '6741b133a437380001df4a8d' }  (×3)
  10:40:51.634 [front-end] 6741b133a437380001df4a8d  (×2)
  10:40:51.634 [front-end] Merging carts for customer id: 6741b133a437380001df4a8d and session id: foGo7VwQrS0UE_Fi0K-LForTyddTphsx  (×2)
  10:40:51.658 [front-end] Posting Customer: {"username":"FoMnUsWRwtr","password":"ONCxQmw","email":"FoMnUsWRwtr@gmail.com","firstName":"FoMnUsWRwtr","lastName":"FoMnUsWRwtr"}
  10:40:51.671 [front-end] Carts merged.  (×2)
  10:40:51.671 [front-end] set cookie6741b133a437380001df4a8d  (×2)
  10:40:51.672 [front-end] Sent cookies.  (×2)
  10:40:51.672 [front-end] POST /register 200 47.303 ms - 33  (×2)
  10:40:52.009 [front-end] GET /catalogue 200 - ms - -
  10:40:52.138 [front-end] Posting Customer: {"username":"YBQIvbmr","password":"BPOxjQ","email":"YBQIvbmr@gmail.com","firstName":"YBQIvbmr","lastName":"YBQIvbmr"}
All services, 30 seconds either side (sampled):
  10:40:51.001 [user] ts=2024-11-23T10:40:51.001253583Z caller=middlewares.go:75 method=GetUsers id=6741b123a437380001df4a67 result=1 took=2.561807ms  (×127)
  10:40:51.057 [front-end] Request received with body: {}  (×34)
  10:40:51.115 [front-end] POST /cards 200 - ms - -  (×35)
  10:40:51.243 [carts] 2024-11-23 10:40:51.243 INFO [carts,d2c2e6abee6853ca,7c11b7f04a005886,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×16)
  10:40:51.650 [carts] 2024-11-23 10:40:51.644 INFO [carts,ce28dad27a7f1e73,b550dd7d93e87a62,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×20)
  10:40:52.715 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×4)
  10:40:54.042 [carts] 2024-11-23 10:40:54.042 INFO [carts,55279b5e8192e632,8c77ccf18a9ceab9,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.ItemsController : Did not find item.  (×19)
  10:40:55.439 [front-end] Posting Customer: {"username":"RWEKCzZbyoL","password":"eCgDEu","email":"RWEKCzZbyoL@gmail.com","firstName":"RWEKCzZbyoL","lastName":"RWEKCzZbyoL"}
  10:40:57.337 [orders] 2024-11-23 10:40:57.337 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+jso
  10:40:57.345 [orders] 2024-11-23 10:40:57.345 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[applicatio
  10:40:57.435 [orders] 2024-11-23 10:40:57.435 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicat
  10:40:57.546 [orders] 2024-11-23 10:40:57.546 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http
  10:40:58.821 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  10:40:59.450 [orders] 2024-11-23 10:40:59.450 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=
  10:40:59.540 [orders] 2024-11-23 10:40:59.540 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[app
  10:41:02.850 [front-end] Posting Customer: {"username":"oljxrbkvgRPchx","password":"KICnrSMycj","email":"oljxrbkvgRPchx@gmail.com","firstName":"oljxrbkvgRPchx","lastName":"oljxrbkvgRPch
  10:41:04.149 [orders] 2024-11-23 10:41:04.149 INFO [orders,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering w
  10:41:06.939 [orders] 2024-11-23 10:41:06.843 INFO [orders,,,] 7 --- [p-nio-80-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization starte
  10:41:08.897 [front-end] Received response: "{\"firstName\":\"FoMnUsWRwtr\",\"lastName\":\"FoMnUsWRwtr\",\"username\":\"FoMnUsWRwtr\",\"id\":\"6741b133a437380001df4a8e\",\"_links\":{\"a
  10:41:09.781 [front-end] Posting Customer: {"username":"gzAwltOvrAOlwZ","password":"mvbfevmrG","email":"gzAwltOvrAOlwZ@gmail.com","firstName":"gzAwltOvrAOlwZ","lastName":"gzAwltOvrAOlwZ
  10:41:10.346 [queue-master] 2024-11-23 10:41:10.346 INFO 7 --- [ool-6-thread-24] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×18)
  10:41:10.951 [orders-db] {"t":{"$date":"2024-11-23T10:41:10.951+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:4145  (×10)
  10:41:11.658 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b14601dd390007094dcc","customerId":"6741b12ea437380001df4a7f","customer":{"id":null,"firstName":"vDSVmUfFkYR
  10:41:11.740 [front-end] Order response: {"id":"6741b14601dd390007094dcb","customerId":"6741b135a437380001df4a95","customer":{"id":null,"firstName":"oMOnLjzHZXUV","lastName":"oMOnLjzHZX
  10:41:11.746 [front-end] Order response: {"id":"6741b14601dd390007094dcd","customerId":"6741b133a437380001df4a8d","customer":{"id":null,"firstName":"PMMsVPkCBtB","lastName":"PMMsVPkCBtB
  10:41:13.508 [user] ts=2024-11-23T10:41:13.508595513Z caller=middlewares.go:46 method=Register username=AQxdn email=AQxdn@gmail.com took=2.184408ms
  10:41:15.043 [front-end] Order response: {"id":"6741b14a01dd390007094dd4","customerId":"6741b132a437380001df4a8a","customer":{"id":null,"firstName":"mfkgXqTHaTye","lastName":"mfkgXqTHaT
  10:41:17.757 [front-end] Received response: "{\"firstName\":\"RPAyWJFRkAtx\",\"lastName\":\"RPAyWJFRkAtx\",\"username\":\"RPAyWJFRkAtx\",\"id\":\"6741b138a437380001df4aa1\",\"_links\":{
  10:41:20.018 [front-end] Received response: "{\"firstName\":\"qqkRVDrhVVQ\",\"lastName\":\"qqkRVDrhVVQ\",\"username\":\"qqkRVDrhVVQ\",\"id\":\"6741b138a437380001df4aa2\",\"_links\":{\"a

## p0610
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T20:10:55.631Z
```
{"timestamp":1733602255631885000,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-w6jt4","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:10:55.631  INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl         : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nanjing, suzhou, shanghai], distances=[0, 200, 250], startStationId='nanjing', terminalStationId='shanghai'}"}
```
Same service, the 2 minutes before (oldest first):
  20:10:47.522 [ts-travel-service] 2024-12-07 20:10:47.522 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：aefcef3f-3f42-46e8-afd7-6cb2a  (×7)
  20:10:47.529 [ts-travel-service] 2024-12-07 20:10:47.528 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×2)
  20:10:47.529 [ts-travel-service] 2024-12-07 20:10:47.529 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='aefcef3f-3f42-46e8-afd7-6cb2a928bd3d', stations=[nan  (×4)
  20:10:47.547 [ts-travel-service] 2024-12-07 20:10:47.546 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×2)
  20:10:47.559 [ts-travel-service] 2024-12-07 20:10:47.558 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  20:10:47.559 [ts-travel-service] 2024-12-07 20:10:47.559 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  20:10:47.571 [ts-travel-service] 2024-12-07 20:10:47.571 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  20:10:47.572 [ts-travel-service] 2024-12-07 20:10:47.571 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha
  20:10:55.604 [ts-travel-service] 2024-12-07 20:10:55.604 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
All services, 30 seconds either side (sampled):
  20:10:26.370 [ts-auth-service] 2024-12-07 20:10:26.369 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×9)
  20:10:26.702 [ts-travel-service] 2024-12-07 20:10:26.702 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×23)
  20:10:26.771 [ts-travel2-service] 2024-12-07 20:10:26.771 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×139)
  20:10:26.900 [ts-basic-service] 2024-12-07 20:10:26.900 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×33)
  20:10:26.931 [ts-order-other-service] 2024-12-07 20:10:26.931 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×13)
  20:10:27.080 [ts-seat-service] 2024-12-07 20:10:27.080 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×59)
  20:10:27.552 [ts-admin-basic-info-service] 2024-12-07 20:10:27.552 INFO 1 --- [io-18767-exec-9] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×9)
  20:10:28.396 [ts-travel2-service] 2024-12-07 20:10:28.395 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×2)
  20:10:29.855 [ts-basic-service] 2024-12-07 20:10:29.855 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×8)
  20:10:31.116 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T20:10:31.116+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360223
  20:10:33.320 [ts-seat-service] 2024-12-07 20:10:33.319 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×7)
  20:10:33.651 [ts-travel-service] 2024-12-07 20:10:33.651 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×41)
  20:10:33.764 [ts-travel-service] 2024-12-07 20:10:33.764 INFO 1 --- [io-12346-exec-5] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234  (×29)
  20:10:33.956 [ts-basic-service] 2024-12-07 20:10:33.956 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2  (×4)
  20:10:39.607 [ts-travel-service] 2024-12-07 20:10:39.607 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=nanjing)  (×7)
  20:10:41.087 [ts-auth-service] 2024-12-07 20:10:41.087 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×2)
  20:10:43.221 [ts-travel-service] 2024-12-07 20:10:43.221 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×9)
  20:10:55.801 [ts-basic-service] 2024-12-07 20:10:55.801 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe  (×4)
  20:10:57.896 [ts-order-other-service] 2024-12-07 20:10:57.896 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×2)
  20:10:58.660 [ts-consign-service] 2024-12-07 20:10:58.660 INFO 1 --- [o-16111-exec-10] consign.service.ConsignServiceImpl : The handle date is 2024-12-07
  20:11:00.101 [ts-basic-service] 2024-12-07 20:11:00.101 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  20:11:12.975 [ts-travel-service] 2024-12-07 20:11:12.975 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s
  20:11:13.209 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:11:13 +0800] "GET /api/v1/contactservice/contacts/account/4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f HTTP/1.1" 200 471 "-" "Mozilla/5.0 
  20:11:13.252 [ts-order-other-service] 2024-12-07 20:11:13.252 INFO 1 --- [io-12032-exec-1] other.controller.OrderOtherController : [Order Other Service][Security Info Get]
  20:11:13.297 [ts-contacts-service] 2024-12-07 20:11:13.297 INFO 1 --- [io-12347-exec-2] contacts.service.ContactsServiceImpl : FIND CONTACTS BY ID: d14da0ec-da93-46c3-842d-23fc37f2c919
  20:11:13.585 [ts-preserve-service] 2024-12-07 20:11:13.585 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 4] Do Order
  20:11:13.707 [ts-preserve-service] 2024-12-07 20:11:13.706 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Creating....
  20:11:13.748 [ts-preserve-service] 2024-12-07 20:11:13.748 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service][Step 6] Do not need to buy food

## p0480
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:17:54.567Z
```
{"timestamp":1732349874567558000,"container_name":"front-end","pod_name":"front-end-75d5fbb45c-9hvqh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"GET Request to: http://user/customers/67418f9ca437380001def49a/cards"}
```
Same service, the 2 minutes before (oldest first):
  08:17:53.946 [front-end] GET Request to: http://user/customers/67418f9da437380001def49e/addresses  (×3)
  08:17:53.960 [front-end] Received response: "{\"_embedded\":{\"address\":[]}}\n"
  08:17:53.960 [front-end] Received response: "{\"_embedded\":{\"card\":[]}}\n"
  08:17:53.960 [front-end] [ undefined, undefined ]
  08:17:53.960 [front-end] Posting Order: {"customer":"http://user/customers/67418f9da437380001def49e","address":null,"card":null,"items":"http://carts/carts/67418f9da437380001def49e/item
  08:17:54.086 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418faaa437380001def4bd"}
  08:17:54.099 [front-end] POST /addresses 200 - ms - -
  08:17:54.106 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67418faaa437380001def4bd"}
  08:17:54.117 [front-end] POST /cards 200 - ms - -
  08:17:54.164 [front-end] Attempting to delete cart for user: 67418faaa437380001def4bd
  08:17:54.181 [front-end] User cart deleted with status: 202
  08:17:54.183 [front-end] DELETE /cart 202 - ms - -
  08:17:54.188 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  08:17:54.198 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  08:17:54.198 [front-end] POST to carts: http://carts/carts/67418faaa437380001def4bd/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  08:17:54.234 [front-end] POST /cart 201 - ms - -
  08:17:54.553 [front-end] Request received with body: {}
  08:17:54.567 [front-end] Received response: "{\"firstName\":\"ZdKuoRXTXm\",\"lastName\":\"ZdKuoRXTXm\",\"username\":\"ZdKuoRXTXm\",\"id\":\"67418f9ca437380001def49a\",\"_links\":{\"addr
All services, 30 seconds either side (sampled):
  08:17:24.567 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418  (×45)
  08:17:24.589 [catalogue] ts=2024-11-23T08:17:24Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.312477ms  (×32)
  08:17:24.604 [front-end] POST /orders 201 - ms - -  (×17)
  08:17:24.901 [front-end] Order response: {"id":"67418f943f77060008865090","customerId":"67418f7ca437380001def439","customer":{"id":null,"firstName":"hDADdujiVgp","lastName":"hDADdujiVgp
  08:17:24.959 [front-end] POST /register 200 26.192 ms - 33  (×47)
  08:17:25.133 [front-end] Attempting to delete cart for user: 67418f8ca437380001def472  (×49)
  08:17:25.849 [user] ts=2024-11-23T08:17:25.849595249Z caller=middlewares.go:157 method=Health result=2 took=1.965935ms  (×40)
  08:17:27.589 [front-end] Received response: "{\"firstName\":\"OelSpAAhXlE\",\"lastName\":\"OelSpAAhXlE\",\"username\":\"OelSpAAhXlE\",\"id\":\"67418f81a437380001def44b\",\"_links\":{\"a
  08:17:28.101 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f983f77060008865093","customerId":"67418f85a437380001def45e","customer":{"id":null,"firstName":"YtbOkEhM","
  08:17:28.253 [front-end] npm timing config:load:env Completed in 81ms  (×2)
  08:17:28.254 [front-end] npm timing npm:load:configload Completed in 93ms  (×2)
  08:17:28.261 [front-end] npm timing npm:load:logFile Completed in 7ms  (×2)
  08:17:29.112 [queue-master] 2024-11-23 08:17:29.112 ERROR 7 --- [pool-6-thread-3] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×8)
  08:17:30.484 [front-end] Order response: {"id":"67418f9a3f77060008865095","customerId":"67418f8ca437380001def46c","customer":{"id":null,"firstName":"jWwyhL","lastName":"jWwyhL","usernam
  08:17:32.781 [front-end] Received response: "{\"firstName\":\"pOdFHAXyWrS\",\"lastName\":\"pOdFHAXyWrS\",\"username\":\"pOdFHAXyWrS\",\"id\":\"67418f83a437380001def45a\",\"_links\":{\"a
  08:17:34.673 [front-end] Received response: "{\"firstName\":\"aVGPN\",\"lastName\":\"aVGPN\",\"username\":\"aVGPN\",\"id\":\"67418f8ba437380001def466\",\"_links\":{\"addresses\":{\"href
  08:17:35.764 [front-end] Received response: "{\"firstName\":\"AiPHcDe\",\"lastName\":\"AiPHcDe\",\"username\":\"AiPHcDe\",\"id\":\"67418f86a437380001def45f\",\"_links\":{\"addresses\":{
  08:17:38.122 [front-end] Received response: "{\"firstName\":\"zUlKpfPGQF\",\"lastName\":\"zUlKpfPGQF\",\"username\":\"zUlKpfPGQF\",\"id\":\"67418f87a437380001def463\",\"_links\":{\"addr
  08:17:39.685 [front-end] Posting Customer: {"username":"rcVKMpvyC","password":"NpReA","email":"rcVKMpvyC@gmail.com","firstName":"rcVKMpvyC","lastName":"rcVKMpvyC"}
  08:17:40.902 [front-end] npm verb stack at ChildProcess.<anonymous> (/usr/local/lib/node_modules/npm/node_modules/@npmcli/promise-spawn/lib/index.js:63:27)  (×2)
  08:17:40.904 [front-end] npm ERR! command failed  (×2)
  08:17:47.418 [front-end] Received response: "{\"firstName\":\"uoYYofNDKuLv\",\"lastName\":\"uoYYofNDKuLv\",\"username\":\"uoYYofNDKuLv\",\"id\":\"67418f99a437380001def491\",\"_links\":{
  08:17:52.022 [front-end] Received response: "{\"_embedded\":{\"address\":[]}}\n"  (×6)
  08:17:55.126 [front-end] Received response: "{\"firstName\":\"YDOyD\",\"lastName\":\"YDOyD\",\"username\":\"YDOyD\",\"id\":\"67418f9da437380001def49f\",\"_links\":{\"addresses\":{\"href
  08:18:01.126 [front-end] Received response: "{\"firstName\":\"hEJoPjrFkbY\",\"lastName\":\"hEJoPjrFkbY\",\"username\":\"hEJoPjrFkbY\",\"id\":\"67418fa2a437380001def4b2\",\"_links\":{\"a
  08:18:03.023 [front-end] Posting Customer: {"username":"twUzFipHuvKB","password":"lPYnrh","email":"twUzFipHuvKB@gmail.com","firstName":"twUzFipHuvKB","lastName":"twUzFipHuvKB"}
  08:18:08.990 [front-end] Posting Customer: {"username":"LybJWagwVrBn","password":"AlVjtOpHi","email":"LybJWagwVrBn@gmail.com","firstName":"LybJWagwVrBn","lastName":"LybJWagwVrBn"}
  08:18:14.138 [front-end] Received response: "{\"firstName\":\"gvhokO\",\"lastName\":\"gvhokO\",\"username\":\"gvhokO\",\"id\":\"67418fafa437380001def4cc\",\"_links\":{\"addresses\":{\"h
  08:18:19.388 [front-end] Received response: "{\"firstName\":\"ainjYe\",\"lastName\":\"ainjYe\",\"username\":\"ainjYe\",\"id\":\"67418fb8a437380001def4d8\",\"_links\":{\"addresses\":{\"h

## p0039
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T07:58:25.503Z
```
{"service":"dbservice1","message":"2021-08-13 07:58:25,503 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 3cf5f898e44adb9d | query = select passwards from username_table where user_name='kWcbAndl'"}
```
Same service, the 2 minutes before (oldest first):
  07:58:14.467 [dbservice1] INFO query = select passwards from username_table where user_name='jhoAGDST'  (×5)
  07:58:14.543 [dbservice1] INFO 27c38d0c-fbc9-11eb-aff9-0242ac110004-jhoAGDST-%RJ/0?B1fm4L token generate success token=MTYyODgxMjY5NC41NDMzMzoyN2MzOGQwYy1mYmM5LTExZWItYWZmOS0wMjQyYWMxMTA
  07:58:15.622 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  07:58:15.623 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  07:58:15.754 [dbservice1] INFO 287b7868-fbc9-11eb-854b-0242ac110003-FGqxBRpZ-}9s_LQ?u>hzS token generate success token=MTYyODgxMjY5NS43NTQzMzc1OjI4N2I3ODY4LWZiYzktMTFlYi04NTRiLTAyNDJhYzE
  07:58:16.507 [dbservice1] INFO 28f38b96-fbc9-11eb-9b74-0242ac110004-UvLPSsVD-.<G1NWlu%(J2 token generate success token=MTYyODgxMjY5Ni41MDcwNDg2OjI4ZjM4Yjk2LWZiYzktMTFlYi05Yjc0LTAyNDJhYzE
  07:58:18.101 [dbservice1] INFO 29e18b02-fbc9-11eb-93dc-0242ac110004-WPyTrmsx-aR#!4rDc<gC6 token generate success token=MTYyODgxMjY5OC4xMDA2Mjg0OjI5ZTE4YjAyLWZiYzktMTFlYi05M2RjLTAyNDJhYzE
  07:58:20.079 [dbservice1] INFO 2b10489c-fbc9-11eb-9ec4-0242ac110003-ySjkNPYT-D^=b(51nchk< token generate success token=MTYyODgxMjcwMC4wNzkwOTk0OjJiMTA0ODljLWZiYzktMTFlYi05ZWM0LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  07:57:55.520 [dbservice2] INFO 1c6ce750-fbc9-11eb-aea4-0242ac110003-AaVSnOsU-SjgU+V3dBavi token generate success token=MTYyODgxMjY3NS41MjAzNDA3OjFjNmNlNzUwLWZiYzktMTFlYi1hZWE0LTAyNDJhYzE
  07:57:55.799 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×31)
  07:57:55.950 [mobservice2] INFO info 1cdabe38-fbc9-11eb-a4ff-0242ac110004:DjVLApUI write success  (×2)
  07:57:56.109 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '1cdabe38-fbc9-11eb-a4ff-0242ac110004', 'user_id': 'DjVLApUI'}  (×61)
  07:57:56.257 [dbservice2] INFO query = select passwards from username_table where user_name='DjVLApUI'  (×33)
  07:57:57.079 [dbservice2] INFO 1d55fc74-fbc9-11eb-84d4-0242ac110004-AizeDahx-tuI.iH2^:?Z7 token generate success token=MTYyODgxMjY3Ny4wNzkxODc5OjFkNTVmYzc0LWZiYzktMTFlYi04NGQ0LTAyNDJhYzE
  07:57:57.409 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×32)
  07:57:57.685 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×37)
  07:57:57.884 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×27)
  07:57:59.268 [mobservice2] INFO info 1ed82f18-fbc9-11eb-9af1-0242ac110004:bhmAUvxt write success
  07:58:06.211 [dbservice2] INFO 22d0c67a-fbc9-11eb-baaf-0242ac110003-mCkaEIVe-%4QxON(snAYv token generate success token=MTYyODgxMjY4Ni4yMTA0MTg1OjIyZDBjNjdhLWZiYzktMTFlYi1iYWFmLTAyNDJhYzE
  07:58:10.856 [mobservice1] INFO info 25b9af3c-fbc9-11eb-b6eb-0242ac110004:rREWnpxD write success
  07:58:12.512 [mobservice2] INFO info 26c23732-fbc9-11eb-833e-0242ac110003:ifjIWOde write success
  07:58:14.306 [dbservice1] INFO 27a3c4f4-fbc9-11eb-a9d6-0242ac110003-YXLKvufE-RlNLZm@n6u!V token generate success token=MTYyODgxMjY5NC4zMDYzODg6MjdhM2M0ZjQtZmJjOS0xMWViLWE5ZDYtMDI0MmFjMTE
  07:58:16.507 [dbservice1] INFO 28f38b96-fbc9-11eb-9b74-0242ac110004-UvLPSsVD-.<G1NWlu%(J2 token generate success token=MTYyODgxMjY5Ni41MDcwNDg2OjI4ZjM4Yjk2LWZiYzktMTFlYi05Yjc0LTAyNDJhYzE
  07:58:18.528 [mobservice2] INFO info 2a5606a8-fbc9-11eb-ad20-0242ac110004:ceZjduVy write success
  07:58:22.812 [dbservice2] INFO 2cb4337a-fbc9-11eb-93ed-0242ac110003-XdvDclow-.6V*l<n+>x/B token generate success token=MTYyODgxMjcwMi44MTIyMzk0OjJjYjQzMzdhLWZiYzktMTFlYi05M2VkLTAyNDJhYzE
  07:58:31.013 [mobservice1] INFO info 31b662da-fbc9-11eb-9d9e-0242ac110003:QClFzynH write success
  07:58:32.297 [mobservice2] INFO info 3287a0ac-fbc9-11eb-991a-0242ac110004:ITinMyWu write success
  07:58:34.328 [dbservice2] INFO 33826e6a-fbc9-11eb-b892-0242ac110003-PFOBQRXk-VziMJs=8j.(! token generate success token=MTYyODgxMjcxNC4zMjc3NTI0OjMzODI2ZTZhLWZiYzktMTFlYi1iODkyLTAyNDJhYzE
  07:58:36.836 [mobservice2] INFO info 35383c4e-fbc9-11eb-aea4-0242ac110003:mCkaEIVe write success
  07:58:39.331 [dbservice2] INFO 367dfd3c-fbc9-11eb-826c-0242ac110003-YDlrGqAK-=_&yCx+0Rj}p token generate success token=MTYyODgxMjcxOS4zMzA4ODY2OjM2N2RmZDNjLWZiYzktMTFlYi04MjZjLTAyNDJhYzE
  07:58:41.343 [mobservice1] INFO info 37eaac24-fbc9-11eb-9255-0242ac110004:GRzjnWha write success
  07:58:43.313 [dbservice2] INFO 38e0d48c-fbc9-11eb-9de8-0242ac110003-NmlBnobg-j#0G_yxTVq.% token generate success token=MTYyODgxMjcyMy4zMTMzMzY0OjM4ZTBkNDhjLWZiYzktMTFlYi05ZGU4LTAyNDJhYzE
  07:58:46.038 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  07:58:48.615 [dbservice2] INFO 3bfb679a-fbc9-11eb-91d5-0242ac110004-DhKfSuMF-Vc<a5J!Q>m{2 token generate success token=MTYyODgxMjcyOC42MTQ5NDg6M2JmYjY3OWEtZmJjOS0xMWViLTkxZDUtMDI0MmFjMTE

## p0699
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-12T17:59:14.504Z
```
{"service":"dbservice1","message":"2021-08-12 17:59:14,504 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 7061cce000afdb3d | f2b8c4c6-fb53-11eb-9cc5-0242ac110004-tpRwcUuS-!3hEKu1y{sDW token generate success token=MTYyODc2MjM1NC41MDQxNzc4OmYyYjhjNGM2LWZiNTMtMTFlYi05Y2M1LTAyNDJhYzExMDAwNHRwUndjVXVTITNoRUt1MXl7c0RXOjE2Mjg3NjI0MTQuNTA0MTg5MzphZjBhM2FmMDQxMGY2NjA5ZjQ4MTNlYjZkNzY2Zjg5ZA=="}
```
Same service, the 2 minutes before (oldest first):
  17:59:09.549 [dbservice1] INFO query = select passwards from username_table where user_name='eNWPvrgG'  (×5)
  17:59:09.637 [dbservice1] INFO efcc9710-fb53-11eb-a217-0242ac110003-eNWPvrgG-5p=qVbStYAN^ token generate success token=MTYyODc2MjM0OS42MzY2NTg0OmVmY2M5NzEwLWZiNTMtMTFlYi1hMjE3LTAyNDJhYzE
  17:59:09.833 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  17:59:09.833 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  17:59:10.207 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  17:59:11.253 [dbservice1] INFO f0c89650-fb53-11eb-8395-0242ac110003-hlZNRKOv-VAn+:K$t4qsB token generate success token=MTYyODc2MjM1MS4yNTM2MTYzOmYwYzg5NjUwLWZiNTMtMTFlYi04Mzk1LTAyNDJhYzE
  17:59:13.145 [dbservice1] INFO f1da5b32-fb53-11eb-aa7c-0242ac110003-AmhGSJRK-dWueNw!<8>i6 token generate success token=MTYyODc2MjM1My4xNDU1NDg6ZjFkYTViMzItZmI1My0xMWViLWFhN2MtMDI0MmFjMTE
  17:59:13.716 [dbservice1] INFO f23c565c-fb53-11eb-bb8f-0242ac110004-lGPfCvhn-%)&.w4tO>XjE token generate success token=MTYyODc2MjM1My43MTY1OTQ1OmYyM2M1NjVjLWZiNTMtMTFlYi1iYjhmLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  17:58:44.526 [webservice1] INFO uuid: e13c5ff0-fb53-11eb-b297-0242ac110003 write redis successfully  (×46)
  17:58:44.642 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×46)
  17:58:44.751 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'e13c5ff0-fb53-11eb-b297-0242ac110003', 'value': 'kmPegpXw'}  (×43)
  17:58:44.916 [redisservice2] INFO redis读取信息成功, status_code: 200  (×34)
  17:58:44.977 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×43)
  17:58:45.049 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×44)
  17:58:45.637 [mobservice1] INFO info e1c16dda-fb53-11eb-acd2-0242ac110003:rREWnpxD write success
  17:58:46.263 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'e22af3ae-fb53-11eb-a100-0242ac110003'}  (×44)
  17:58:48.025 [dbservice1] INFO e2e1ed16-fb53-11eb-a2ac-0242ac110004-etgkwBmP-D<TlS9enGxsY token generate success token=MTYyODc2MjMyOC4wMjUzMjA4OmUyZTFlZDE2LWZiNTMtMTFlYi1hMmFjLTAyNDJhYzE
  17:58:51.325 [mobservice2] INFO info e524e9f2-fb53-11eb-84d6-0242ac110004:QgokVGXf write success
  17:58:54.228 [mobservice1] INFO info e6dc2d1e-fb53-11eb-94a8-0242ac110003:cmBuyeUK write success
  17:58:58.084 [dbservice1] INFO e8e85a06-fb53-11eb-8013-0242ac110004-nuXjsHUb-@8.+B_ezYn70 token generate success token=MTYyODc2MjMzOC4wODM5MzM2OmU4ZTg1YTA2LWZiNTMtMTFlYi04MDEzLTAyNDJhYzE
  17:59:01.309 [mobservice2] INFO info eb08a87c-fb53-11eb-99ea-0242ac110004:FASeJGor write success
  17:59:02.572 [dbservice2] INFO eb92d484-fb53-11eb-b037-0242ac110003-cvBGfCKh-Jf.l:ogU&-se token generate success token=MTYyODc2MjM0Mi41NzIxNjMzOmViOTJkNDg0LWZiNTMtMTFlYi1iMDM3LTAyNDJhYzE
  17:59:05.057 [webservice2] ERROR an error occurred in the downstream service  (×3)
  17:59:08.806 [dbservice2] INFO ef29c03a-fb53-11eb-bbd8-0242ac110004-WtfwAnYv-3$J!b^5TtWGE token generate success token=MTYyODc2MjM0OC44MDYwOTU0OmVmMjljMDNhLWZiNTMtMTFlYi1iYmQ4LTAyNDJhYzE
  17:59:11.253 [dbservice1] INFO f0c89650-fb53-11eb-8395-0242ac110003-hlZNRKOv-VAn+:K$t4qsB token generate success token=MTYyODc2MjM1MS4yNTM2MTYzOmYwYzg5NjUwLWZiNTMtMTFlYi04Mzk1LTAyNDJhYzE
  17:59:13.716 [dbservice1] INFO f23c565c-fb53-11eb-bb8f-0242ac110004-lGPfCvhn-%)&.w4tO>XjE token generate success token=MTYyODc2MjM1My43MTY1OTQ1OmYyM2M1NjVjLWZiNTMtMTFlYi1iYjhmLTAyNDJhYzE
  17:59:16.496 [mobservice2] INFO info f421afc6-fb53-11eb-929a-0242ac110004:uiZfvcTY write success
  17:59:19.090 [mobservice1] INFO info f5b15efe-fb53-11eb-8521-0242ac110004:JXejhiMl write success
  17:59:21.795 [dbservice1] INFO f707ca2c-fb53-11eb-996d-0242ac110003-ucXDZIio-})1EO<#nT*!K token generate success token=MTYyODc2MjM2MS43OTUxOTk2OmY3MDdjYTJjLWZiNTMtMTFlYi05OTZkLTAyNDJhYzE
  17:59:24.805 [dbservice2] INFO f8ca8804-fb53-11eb-9d0e-0242ac110003-WaxSUkLu-sVXvoU?M1dhS token generate success token=MTYyODc2MjM2NC44MDQ1OTUyOmY4Y2E4ODA0LWZiNTMtMTFlYi05ZDBlLTAyNDJhYzE
  17:59:28.573 [dbservice1] INFO faca3a78-fb53-11eb-b801-0242ac110004-TFXYPaBZ-MDCmaJ3rOls# token generate success token=MTYyODc2MjM2OC41NzMwNjk6ZmFjYTNhNzgtZmI1My0xMWViLWI4MDEtMDI0MmFjMTE
  17:59:31.332 [mobservice2] INFO info fcf31d60-fb53-11eb-916e-0242ac110003:vUsGrNAF write success
  17:59:34.364 [dbservice1] INFO fe90230c-fb53-11eb-a112-0242ac110003-ValqHbfM-ZN?%l#y!8{m9 token generate success token=MTYyODc2MjM3NC4zNjM3MTU6ZmU5MDIzMGMtZmI1My0xMWViLWExMTItMDI0MmFjMTE
  17:59:38.158 [mobservice1] INFO info 00ff0770-fb54-11eb-a319-0242ac110003:FpcKvnCm write success
  17:59:41.019 [dbservice2] INFO 028adf10-fb54-11eb-b903-0242ac110003-tAuqKoTw-yCN:@jA43dVi token generate success token=MTYyODc2MjM4MS4wMTg5NTIxOjAyOGFkZjEwLWZiNTQtMTFlYi1iOTAzLTAyNDJhYzE
  17:59:43.391 [dbservice1] INFO 03eef206-fb54-11eb-866a-0242ac110004-FTkscPog-!K5SR?}hnJW> token generate success token=MTYyODc2MjM4My4zOTEzMjAyOjAzZWVmMjA2LWZiNTQtMTFlYi04NjZhLTAyNDJhYzE
