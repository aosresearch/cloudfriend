## p0356
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:31:32.603Z
```
{"timestamp":1732246292603824400,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:31:32.603614942Z caller=middlewares.go:75 method=GetUsers id=673ffafeb0df5c00019b268d result=1 took=898.257µs"}
```
Same service, the 2 minutes before (oldest first):
  03:31:31.230 [user] ts=2024-11-22T03:31:31.229907956Z caller=middlewares.go:75 method=GetUsers id=673ffb01b0df5c00019b2696 result=1 took=967.324µs  (×9)
  03:31:31.230 [user] ts=2024-11-22T03:31:31.229923662Z caller=middlewares.go:134 method=GetCards id=673ffb07b0df5c00019b26ae result=1 took=609.307µs  (×3)
  03:31:31.549 [user] ts=2024-11-22T03:31:31.549065897Z caller=middlewares.go:46 method=Register username=lOBxrXHLsr email=lOBxrXHLsr@gmail.com took=1.087827ms  (×2)
  03:31:31.897 [user] ts=2024-11-22T03:31:31.897079008Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffb09b0df5c00019b26b9 took=2.367474ms
  03:31:31.909 [user] ts=2024-11-22T03:31:31.909571975Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffb09b0df5c00019b26b9 took=1.795072ms
  03:31:32.413 [user] ts=2024-11-22T03:31:32.41372971Z caller=middlewares.go:104 method=GetAddresses id=673ffb07b0df5c00019b26af result=1 took=995.119µs  (×2)
  03:31:32.428 [user] ts=2024-11-22T03:31:32.428471566Z caller=middlewares.go:75 method=GetUsers id=673ffafeb0df5c00019b268c result=1 took=1.030808ms  (×2)
All services, 30 seconds either side (sampled):
  03:31:02.607 [user] ts=2024-11-22T03:31:02.607052932Z caller=middlewares.go:104 method=GetAddresses id=673ffaecb0df5c00019b265e result=1 took=959.517µs  (×42)
  03:31:02.628 [queue-master] 2024-11-22 03:31:02.628 ERROR 6 --- [ool-6-thread-23] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×42)
  03:31:02.704 [front-end] Posting Order: {"customer":"http://user/customers/673ffae0b0df5c00019b263b","address":"http://user/addresses/673ffae9b0df5c00019b264f","card":"http://user/cards  (×59)
  03:31:03.118 [user] ts=2024-11-22T03:31:03.118735436Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffaefb0df5c00019b2663 took=1.621942ms  (×60)
  03:31:03.220 [front-end] POST to carts: http://carts/carts/673ffaefb0df5c00019b2663/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}  (×35)
  03:31:04.163 [front-end] set cookie673ffaf8b0df5c00019b267d  (×57)
  03:31:04.502 [front-end] POST to carts: http://carts/carts/673ffaf1b0df5c00019b266d/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}  (×25)
  03:31:06.787 [front-end] Order response: {"id":"673ffafad94b9000069b45a1","customerId":"673ffae4b0df5c00019b2642","customer":{"id":null,"firstName":"BWHMinDB","lastName":"BWHMinDB","use
  03:31:09.526 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×6)
  03:31:11.429 [front-end] Posting Customer: {"username":"WtgyPsWScmmG","password":"qwAOJo","email":"WtgyPsWScmmG@gmail.com","firstName":"WtgyPsWScmmG","lastName":"WtgyPsWScmmG"}
  03:31:13.392 [front-end] Posting Customer: {"username":"EKOiVWQx","password":"KtayVoU","email":"EKOiVWQx@gmail.com","firstName":"EKOiVWQx","lastName":"EKOiVWQx"}
  03:31:15.317 [front-end] Posting Customer: {"username":"yWeHxoecCrW","password":"IXqHWThgZ","email":"yWeHxoecCrW@gmail.com","firstName":"yWeHxoecCrW","lastName":"yWeHxoecCrW"}
  03:31:15.864 [user] ts=2024-11-22T03:31:15.864621633Z caller=middlewares.go:46 method=Register username=FvCWU email=FvCWU@gmail.com took=1.111958ms
  03:31:18.447 [user] ts=2024-11-22T03:31:18.446926423Z caller=middlewares.go:46 method=Register username=emQbpJnCZ email=emQbpJnCZ@gmail.com took=765.111µs
  03:31:21.998 [front-end] Received response: "{\"firstName\":\"IlkSNTSkO\",\"lastName\":\"IlkSNTSkO\",\"username\":\"IlkSNTSkO\",\"id\":\"673ffaf1b0df5c00019b266e\",\"_links\":{\"address
  03:31:25.590 [front-end] Received response: "{\"firstName\":\"SBJijuN\",\"lastName\":\"SBJijuN\",\"username\":\"SBJijuN\",\"id\":\"673ffaf3b0df5c00019b2675\",\"_links\":{\"addresses\":{
  03:31:28.590 [orders-db] {"t":{"$date":"2024-11-22T03:31:28.589+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224628
  03:31:30.436 [front-end] Posting Customer: {"username":"uBPmvyVkhAmg","password":"wpFRV","email":"uBPmvyVkhAmg@gmail.com","firstName":"uBPmvyVkhAmg","lastName":"uBPmvyVkhAmg"}
  03:31:32.640 [front-end] Received response: "{\"firstName\":\"WtgyPsWScmmG\",\"lastName\":\"WtgyPsWScmmG\",\"username\":\"WtgyPsWScmmG\",\"id\":\"673ffaffb0df5c00019b2690\",\"_links\":{
  03:31:34.332 [front-end] Order response: {"id":"673ffb16d94b9000069b45b7","customerId":"673ffafeb0df5c00019b268b","customer":{"id":null,"firstName":"MPxtY","lastName":"MPxtY","username"
  03:31:35.456 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffb17d94b9000069b45b9","customerId":"673ffafbb0df5c00019b2685","customer":{"id":null,"firstName":"gPROFlG","l
  03:31:37.889 [front-end] Received response: "{\"firstName\":\"pDUAcBY\",\"lastName\":\"pDUAcBY\",\"username\":\"pDUAcBY\",\"id\":\"673ffb03b0df5c00019b269e\",\"_links\":{\"addresses\":{
  03:31:39.725 [front-end] Received response: "{\"firstName\":\"eFvKLklZExYVdO\",\"lastName\":\"eFvKLklZExYVdO\",\"username\":\"eFvKLklZExYVdO\",\"id\":\"673ffb00b0df5c00019b2695\",\"_lin
  03:31:43.288 [front-end] Received response: "{\"firstName\":\"CswuDVCdWISj\",\"lastName\":\"CswuDVCdWISj\",\"username\":\"CswuDVCdWISj\",\"id\":\"673ffb0bb0df5c00019b26be\",\"_links\":{
  03:31:47.280 [front-end] Order response: {"id":"673ffb23d94b9000069b45c0","customerId":"673ffb08b0df5c00019b26b8","customer":{"id":null,"firstName":"RFgpCcDGC","lastName":"RFgpCcDGC","u
  03:31:51.730 [front-end] Order response: {"id":"673ffb27d94b9000069b45c1","customerId":"673ffb16b0df5c00019b26db","customer":{"id":null,"firstName":"vqPgCqqxVDZl","lastName":"vqPgCqqxVD
  03:31:53.758 [user] ts=2024-11-22T03:31:53.758455312Z caller=middlewares.go:46 method=Register username=pgVHJpb email=pgVHJpb@gmail.com took=908.457µs
  03:31:54.889 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffb2ad94b9000069b45c7","customerId":"673ffb1bb0df5c00019b26e6","customer":{"id":null,"firstName":"eHcHzwgAZKJ
  03:31:58.261 [front-end] Received response: "{\"firstName\":\"HIZlqUqmK\",\"lastName\":\"HIZlqUqmK\",\"username\":\"HIZlqUqmK\",\"id\":\"673ffb16b0df5c00019b26d8\",\"_links\":{\"address
  03:32:00.639 [front-end] Received response: "{\"firstName\":\"YVdsb\",\"lastName\":\"YVdsb\",\"username\":\"YVdsb\",\"id\":\"673ffb19b0df5c00019b26e1\",\"_links\":{\"addresses\":{\"href

## p0748
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service emailservice, 2024-11-22T13:42:15.587Z
```
{"timestamp":1732282935587876900,"container_name":"emailservice","pod_name":"emailservice-6b6bbffbcb-2n4dd","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"Traceback (most recent call last):\n  File \"/email_server/email_server.py\", line 199, in <module>\n    start(dummy_mode = True)\n  File \"/email_server/email_server.py\", line 127, in start\n    health_pb2_grpc.add_HealthServicer_to_server(server, service)\n  File \"/usr/local/lib/python3.12/site-packages/grpc_health/v1/health_pb2_grpc.py\", line 65, in add_HealthServicer_to_server\n    servicer.Check,\n    …"}
```
Same service, the 2 minutes before (oldest first):
  13:40:45.786 [emailservice] A request to send order confirmation email to timothy08@example.org has been received.
  13:40:53.214 [emailservice] A request to send order confirmation email to amanda24@example.net has been received.
  13:41:09.814 [emailservice] A request to send order confirmation email to jennifer01@example.org has been received.
  13:41:11.455 [emailservice] A request to send order confirmation email to robertwhitehead@example.com has been received.
  13:41:17.549 [emailservice] A request to send order confirmation email to anne50@example.net has been received.
  13:41:20.514 [emailservice] A request to send order confirmation email to khill@example.com has been received.
  13:41:33.350 [emailservice] A request to send order confirmation email to allendylan@example.org has been received.
  13:41:34.725 [emailservice] A request to send order confirmation email to anna12@example.com has been received.
  13:41:37.327 [emailservice] A request to send order confirmation email to nancy28@example.com has been received.
  13:41:37.385 [emailservice] A request to send order confirmation email to fross@example.com has been received.
  13:41:39.176 [emailservice] A request to send order confirmation email to jacksondebra@example.org has been received.
  13:41:46.564 [emailservice] A request to send order confirmation email to aaronhumphrey@example.org has been received.
  13:41:48.180 [emailservice] A request to send order confirmation email to tchung@example.org has been received.
  13:41:52.562 [emailservice] A request to send order confirmation email to rhodesjacqueline@example.net has been received.
  13:42:04.442 [emailservice] A request to send order confirmation email to connor53@example.com has been received.
  13:42:05.462 [emailservice] A request to send order confirmation email to simmonsbrian@example.net has been received.
  13:42:06.155 [emailservice] A request to send order confirmation email to ahenry@example.org has been received.
  13:42:12.924 [emailservice] A request to send order confirmation email to phenry@example.net has been received.
  13:42:15.487 [emailservice] starting the email service in dummy mode.
  13:42:15.487 [emailservice] Profiler disabled.
All services, 30 seconds either side (sampled):
  13:41:45.854 [frontend] request started  (×334)
  13:41:45.863 [cartservice] GetCartAsync called with userId=d300d765-9eb3-497b-b103-4d092587d553  (×269)
  13:41:45.890 [adservice] received ad request (context_words=[kitchen])  (×52)
  13:41:46.458 [frontend] adding to cart  (×40)
  13:41:46.469 [frontend] view user cart  (×75)
  13:41:46.506 [frontend] ENV_PLATFORM is: aws  (×37)
  13:41:46.522 [checkoutservice] [PlaceOrder] user_id="85c06a3e-35d2-4fb8-a638-39a4504f3364" user_currency="JPY"  (×4)
  13:41:46.554 [checkoutservice] payment went through (transaction_id: 9cc8c181-cf6c-454c-a83a-ba23b24a407c)  (×13)
  13:41:46.557 [cartservice] EmptyCartAsync called with userId=85c06a3e-35d2-4fb8-a638-39a4504f3364  (×13)
  13:41:46.567 [frontend] order placed  (×13)
  13:41:48.130 [checkoutservice] [PlaceOrder] user_id="0df00aa0-01ea-4b89-a0b5-66f7ef3991d7" user_currency="EUR"  (×2)
  13:41:48.180 [emailservice] A request to send order confirmation email to tchung@example.org has been received.
  13:41:52.562 [emailservice] A request to send order confirmation email to rhodesjacqueline@example.net has been received.
  13:41:54.112 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '9SIQT8TOJO']
  13:42:04.410 [checkoutservice] [PlaceOrder] user_id="28cd5e72-c08c-44c7-8f37-d6de6cba1e4f" user_currency="CAD"  (×4)
  13:42:04.442 [emailservice] A request to send order confirmation email to connor53@example.com has been received.
  13:42:05.463 [checkoutservice] order confirmation email sent to "simmonsbrian@example.net"
  13:42:06.144 [paymentservice] Transaction processed: visa ending 8926 Amount: GBP23.536236177
  13:42:11.776 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', '9SIQT8TOJO', 'L9ECAV7KIM', '1YMWWN1N4O']  (×5)
  13:42:15.487 [emailservice] starting the email service in dummy mode.  (×3)
  13:42:17.038 [checkoutservice] [PlaceOrder] user_id="4685a666-2807-489a-bc47-9c225a054c9e" user_currency="TRY"  (×2)
  13:42:17.079 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 14  (×6)
  13:42:23.786 [emailservice] Traceback (most recent call last): File "/email_server/email_server.py", line 199, in <module> start(dummy_mode = True) File "/email_server/email_server.py", li  (×2)
  13:42:32.209 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '6E92ZMYYFZ', '9SIQT8TOJO']

## p0657
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-11T07:23:04.503Z
```
{"service":"redisservice1","message":"2021-08-11 07:23:04,503 | INFO | 0.0.0.1 | 172.17.0.4 | redisservice1 | 466927ae12b0d74c | redis读取信息成功, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  07:22:55.561 [redisservice1] INFO redis write success  (×9)
  07:22:55.801 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×4)
  07:22:55.850 [redisservice1] INFO redis读取信息成功, status_code: 200  (×4)
  07:22:56.071 [redisservice1] INFO service accept, status_code: 200  (×3)
All services, 30 seconds either side (sampled):
  07:22:34.512 [mobservice2] INFO info d7876388-fa31-11eb-9957-0242ac110004:roAFtIPD write success
  07:22:34.691 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×36)
  07:22:34.793 [redisservice2] INFO service accept, status_code: 200  (×35)
  07:22:35.064 [webservice1] INFO uuid: d80bd55a-fa31-11eb-92a2-0242ac110003 write redis successfully  (×41)
  07:22:35.377 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×43)
  07:22:35.545 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×35)
  07:22:35.787 [redisservice2] INFO redis读取信息成功, status_code: 200  (×36)
  07:22:35.969 [dbservice2] INFO query = select passwards from username_table where user_name='jyYHLuNM'  (×38)
  07:22:36.776 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'd91b2310-fa31-11eb-831e-0242ac110004', 'value': '', 'ex': 10}  (×39)
  07:22:37.983 [mobservice1] INFO info d9944858-fa31-11eb-bb1a-0242ac110003:hLXtpSzb write success
  07:22:40.045 [dbservice1] INFO daa20b7c-fa31-11eb-9595-0242ac110003-QKmUlJOs-VtH(T*{y+/P@ token generate success token=MTYyODYzNzc2MC4wNDUzMTQzOmRhYTIwYjdjLWZhMzEtMTFlYi05NTk1LTAyNDJhYzE
  07:22:42.295 [mobservice2] INFO info dc375280-fa31-11eb-9c6b-0242ac110004:JjOStLkT write success
  07:22:44.679 [dbservice2] INFO dd5c43f0-fa31-11eb-b86d-0242ac110003-FyPTBMJg-Zjy9.L?*GlNe token generate success token=MTYyODYzNzc2NC42Nzg5ODQ0OmRkNWM0M2YwLWZhMzEtMTFlYi1iODZkLTAyNDJhYzE
  07:22:46.963 [mobservice1] INFO info defbe760-fa31-11eb-9bb4-0242ac110003:cNyGSbzR write success
  07:22:48.821 [dbservice2] INFO dfefb444-fa31-11eb-a5cf-0242ac110004-bCtvogcT-z9vf?iYtU=2( token generate success token=MTYyODYzNzc2OC44MjEwODM6ZGZlZmI0NDQtZmEzMS0xMWViLWE1Y2YtMDI0MmFjMTE
  07:22:50.836 [mobservice2] INFO info e14f33dc-fa31-11eb-bb9b-0242ac110003:HmUeFxBl write success
  07:22:52.870 [mobservice2] INFO info e27e026a-fa31-11eb-af27-0242ac110004:UlXetfSn write success
  07:22:55.396 [dbservice2] INFO e3cb53b6-fa31-11eb-bb39-0242ac110003-qhdLCnSU-I!Hg(Dukw}{) token generate success token=MTYyODYzNzc3NS4zOTU5NTU2OmUzY2I1M2I2LWZhMzEtMTFlYi1iYjM5LTAyNDJhYzE
  07:22:57.342 [mobservice2] INFO info e537810c-fa31-11eb-87ed-0242ac110004:eNErJOHG write success
  07:22:59.262 [dbservice1] INFO e610203e-fa31-11eb-bff6-0242ac110003-PUILkhrM-B)Vg2.}sad:K token generate success token=MTYyODYzNzc3OS4yNjI0NDI0OmU2MTAyMDNlLWZhMzEtMTFlYi1iZmY2LTAyNDJhYzE
  07:23:07.619 [dbservice2] INFO eb0b208e-fa31-11eb-a738-0242ac110003-aZMCtwXA-S!NRjF$n*AB_ token generate success token=MTYyODYzNzc4Ny42MTkyNzplYjBiMjA4ZS1mYTMxLTExZWItYTczOC0wMjQyYWMxMTA
  07:23:11.341 [mobservice1] INFO info ed809844-fa31-11eb-a1c5-0242ac110004:NGJTlZWq write success
  07:23:14.323 [dbservice2] INFO ef1502bc-fa31-11eb-84a2-0242ac110003-tAuqKoTw-yCN:@jA43dVi token generate success token=MTYyODYzNzc5NC4zMjMxMTk2OmVmMTUwMmJjLWZhMzEtMTFlYi04NGEyLTAyNDJhYzE
  07:23:16.587 [mobservice2] INFO info f0a7e81a-fa31-11eb-86f8-0242ac110003:oJIvjPYZ write success
  07:23:19.126 [dbservice1] INFO f1e2f5c6-fa31-11eb-8172-0242ac110003-NChObWPp-ABNnZD}T2zO{ token generate success token=MTYyODYzNzc5OS4xMjYwNjMzOmYxZTJmNWM2LWZhMzEtMTFlYi04MTcyLTAyNDJhYzE
  07:23:21.700 [mobservice1] INFO info f3a22468-fa31-11eb-976f-0242ac110003:sOldejxN write success
  07:23:23.905 [dbservice1] INFO f4c4f424-fa31-11eb-acfb-0242ac110004-lqFmKxHv-(E%bNa0f83I5 token generate success token=MTYyODYzNzgwMy45MDUyNzY4OmY0YzRmNDI0LWZhMzEtMTFlYi1hY2ZiLTAyNDJhYzE
  07:23:26.911 [mobservice1] INFO info f6ca3bee-fa31-11eb-894f-0242ac110004:FTkscPog write success
  07:23:30.296 [mobservice2] INFO info f8cafe10-fa31-11eb-8452-0242ac110003:gstLzvnZ write success
  07:23:33.624 [mobservice1] INFO info fac791ba-fa31-11eb-ae0c-0242ac110004:mVtTqAor write success

## p0551
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-07T18:21:59.632Z
```
{"timestamp":1733595719632092400,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-srqkn","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 18:21:59.631  INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl  : indexStart : 0 __ indexEnd : 1"}
```
Same service, the 2 minutes before (oldest first):
  18:21:59.125 [ts-basic-service] 2024-12-07 18:21:59.125 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su 
  18:21:59.129 [ts-basic-service] 2024-12-07 18:21:59.129 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
  18:21:59.129 [ts-basic-service] 2024-12-07 18:21:59.129 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1
  18:21:59.129 [ts-basic-service] 2024-12-07 18:21:59.129 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : route.getDistances().size : 2
  18:21:59.151 [ts-basic-service] 2024-12-07 18:21:59.151 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×4)
  18:21:59.167 [ts-basic-service] 2024-12-07 18:21:59.166 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×4)
  18:21:59.586 [ts-basic-service] 2024-12-07 18:21:59.586 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×2)
  18:21:59.596 [ts-basic-service] 2024-12-07 18:21:59.596 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe
  18:21:59.606 [ts-basic-service] 2024-12-07 18:21:59.605 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69
  18:21:59.611 [ts-basic-service] 2024-12-07 18:21:59.610 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  18:21:59.611 [ts-basic-service] 2024-12-07 18:21:59.611 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4
  18:21:59.620 [ts-basic-service] 2024-12-07 18:21:59.619 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  18:21:59.632 [ts-basic-service] 2024-12-07 18:21:59.631 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
All services, 30 seconds either side (sampled):
  18:21:29.733 [ts-consign-mongo] {"t":{"$date":"2024-12-07T18:21:29.733+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359568
  18:21:30.186 [ts-admin-travel-service] 2024-12-07 18:21:30.185 INFO 1 --- [io-16114-exec-6] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×13)
  18:21:30.278 [ts-admin-travel-service] 2024-12-07 18:21:30.278 INFO 1 --- [io-16114-exec-6] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×26)
  18:21:30.431 [ts-travel-service] 2024-12-07 18:21:30.431 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×14)
  18:21:32.388 [ts-admin-basic-info-service] 2024-12-07 18:21:32.388 INFO 1 --- [io-18767-exec-3] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×12)
  18:21:39.457 [ts-basic-service] 2024-12-07 18:21:39.457 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×14)
  18:21:39.516 [ts-basic-service] 2024-12-07 18:21:39.515 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3  (×16)
  18:21:39.603 [ts-seat-service] 2024-12-07 18:21:39.603 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×2)
  18:21:39.707 [ts-travel2-service] 2024-12-07 18:21:39.707 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×12)
  18:21:42.083 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T18:21:42.083+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359570
  18:21:43.763 [ts-basic-service] 2024-12-07 18:21:43.763 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  18:21:43.814 [ts-travel-service] 2024-12-07 18:21:43.813 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×9)
  18:21:43.944 [ts-travel-service] 2024-12-07 18:21:43.944 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr  (×12)
  18:21:46.099 [ts-basic-service] 2024-12-07 18:21:46.099 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×2)
  18:21:46.494 [ts-order-service] 2024-12-07 18:21:46.493 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00 
  18:21:56.583 [ts-basic-service] 2024-12-07 18:21:56.583 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×9)
  18:21:59.129 [ts-basic-service] 2024-12-07 18:21:59.129 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
  18:21:59.390 [ts-preserve-service] 2024-12-07 18:21:59.390 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Other Service][Check Security] Checking....
  18:21:59.462 [ts-preserve-service] 2024-12-07 18:21:59.462 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security Complete
  18:21:59.481 [ts-travel-service] 2024-12-07 18:21:59.481 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  18:22:00.225 [ts-seat-service] 2024-12-07 18:22:00.225 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService distributeSeat 1] The result of getTrainTypeResult is Response(  (×2)
  18:22:00.297 [ts-preserve-service] 2024-12-07 18:22:00.296 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service][Add Assurance For Order]
  18:22:01.343 [ts-preserve-other-service] 2024-12-07 18:22:01.342 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Check Account Security] Checking....
  18:22:01.397 [ts-preserve-other-service] 2024-12-07 18:22:01.397 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 2] Find contacts
  18:22:01.543 [ts-consign-service] 2024-12-07 18:22:01.543 INFO 1 --- [io-16111-exec-1] consign.service.ConsignServiceImpl : [Consign servie] [ Update consign record]
  18:22:01.779 [ts-preserve-other-service] 2024-12-07 18:22:01.779 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting....
  18:22:02.293 [ts-preserve-other-service] 2024-12-07 18:22:02.292 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order Price] Price is: 350.0
  18:22:02.330 [ts-preserve-other-service] 2024-12-07 18:22:02.330 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 7] Do not need to consign
  18:22:03.557 [ts-inside-payment-service] 2024-12-07 18:22:03.556 INFO 1 --- [io-18673-exec-6] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.  (×2)
  18:22:21.276 [ts-food-service] 2024-12-07 18:22:21.276 INFO 1 --- [io-18856-exec-4] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345

## p0391
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:26.409Z
```
{"timestamp":1732247186409034800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"673ffe92b0df5c00019b318e"}
```
Same service, the 2 minutes before (oldest first):
  03:46:25.698 [front-end] POST /register 200 52.053 ms - 33  (×2)
  03:46:25.988 [front-end] Posting Customer: {"username":"jAAETa","password":"IwsrY","email":"jAAETa@gmail.com","firstName":"jAAETa","lastName":"jAAETa"}
  03:46:25.993 [front-end] { id: '673ffe91b0df5c00019b318c' }  (×3)
  03:46:25.993 [front-end] 673ffe91b0df5c00019b318c  (×2)
  03:46:25.993 [front-end] Merging carts for customer id: 673ffe91b0df5c00019b318c and session id: OE_o-NswilhBSSbFFISRYSnr3JqEBGyW  (×2)
  03:46:26.006 [front-end] GET /catalogue 200 - ms - -
  03:46:26.044 [front-end] Carts merged.
  03:46:26.044 [front-end] set cookie673ffe91b0df5c00019b318c
  03:46:26.045 [front-end] Sent cookies.
  03:46:26.373 [front-end] Posting Customer: {"username":"HSRfpVFfwJppXn","password":"XmBVu","email":"HSRfpVFfwJppXn@gmail.com","firstName":"HSRfpVFfwJppXn","lastName":"HSRfpVFfwJppXn"}
  03:46:26.396 [front-end] Request received with body: {}
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:26.404 [front-end] Received response: "{\"firstName\":\"VaPxY\",\"lastName\":\"VaPxY\",\"username\":\"VaPxY\",\"id\":\"673ffe84b0df5c00019b3164\",\"_links\":{\"addresses\":{\"href
  03:46:26.404 [front-end] GET Request to: http://user/customers/673ffe84b0df5c00019b3164/addresses  (×2)
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×27)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×44)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×58)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×47)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×47)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×45)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×45)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×45)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h

## p0004
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T00:59:25.384Z
```
{"service":"dbservice1","message":"2021-08-13 00:59:25,384 | ERROR | 0.0.0.4 | dbservice1 | db_helper.py -> sql_ano_prob -> 92 | 74a2b9c5be14caa9 | (pymysql.err.OperationalError) (1054, \"Unknown column 'system_data_time' in 'field list'\")[SQL: select service_name, system_data_time, system_cpu_utilization, system_memory_usage,system_disk_usage, disk_io_read_count, disk_io_write_count,system_network, network_io_read_count, network_io…"}
```
Same service, the 2 minutes before (oldest first):
  00:59:18.042 [dbservice1] INFO query = select passwards from username_table where user_name='KrCJbket'  (×5)
  00:59:18.120 [dbservice1] INFO a13f7690-fb8e-11eb-bd69-0242ac110003-KrCJbket-SDY(Ra?xklfj token generate success token=MTYyODc4NzU1OC4xMTk2ODg6YTEzZjc2OTAtZmI4ZS0xMWViLWJkNjktMDI0MmFjMTE
  00:59:18.360 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  00:59:18.360 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  00:59:18.452 [dbservice1] INFO a17ed038-fb8e-11eb-b4b0-0242ac110003-CMzFsYZh-4nfMZxAl(ko0 token generate success token=MTYyODc4NzU1OC40NTE2ODg4OmExN2VkMDM4LWZiOGUtMTFlYi1iNGIwLTAyNDJhYzE
  00:59:18.930 [dbservice1] INFO a1be4baa-fb8e-11eb-b416-0242ac110003-jFTtOqPD-V5xAt:Q*{qep token generate success token=MTYyODc4NzU1OC45Mjk4Mjg0OmExYmU0YmFhLWZiOGUtMTFlYi1iNDE2LTAyNDJhYzE
  00:59:20.423 [dbservice1] INFO a2a25d4a-fb8e-11eb-94a7-0242ac110004-PyWJlfep-iu/am&SCWnFx token generate success token=MTYyODc4NzU2MC40MjM0MjY2OmEyYTI1ZDRhLWZiOGUtMTFlYi05NGE3LTAyNDJhYzE
  00:59:21.250 [dbservice1] INFO a31a5458-fb8e-11eb-a9d8-0242ac110003-YTchXgsi-MpkWe@KL3OmU token generate success token=MTYyODc4NzU2MS4yNTA0NDI1OmEzMWE1NDU4LWZiOGUtMTFlYi1hOWQ4LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  00:58:55.391 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×35)
  00:58:55.453 [redisservice1] INFO redis读取信息成功, status_code: 200  (×34)
  00:58:55.512 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×45)
  00:58:55.689 [redisservice2] INFO service accept, status_code: 200  (×38)
  00:58:55.891 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '946a32ac-fb8e-11eb-b24a-0242ac110004', 'value': '', 'ex': 10}  (×38)
  00:58:56.124 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×44)
  00:58:56.707 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×41)
  00:58:56.915 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×34)
  00:58:58.104 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×35)
  00:58:58.644 [mobservice2] INFO info 95d996c8-fb8e-11eb-9217-0242ac110004:maWzwvqu write success
  00:59:01.326 [dbservice1] INFO 972ef252-fb8e-11eb-89e5-0242ac110003-DLQYKJTg-?vaXQ#PZAoRN token generate success token=MTYyODc4NzU0MS4zMjYwNzQ2Ojk3MmVmMjUyLWZiOGUtMTFlYi04OWU1LTAyNDJhYzE
  00:59:03.806 [mobservice2] INFO info 98eb8da8-fb8e-11eb-a84d-0242ac110003:WyKqhlJd write success
  00:59:05.900 [dbservice1] INFO 99f5f0d0-fb8e-11eb-93c4-0242ac110003-xgMQOjrh-{:H$4CY!l1#_ token generate success token=MTYyODc4NzU0NS45MDAwOTc0Ojk5ZjVmMGQwLWZiOGUtMTFlYi05M2M0LTAyNDJhYzE
  00:59:08.456 [dbservice1] INFO 9b79753a-fb8e-11eb-9e52-0242ac110004-kuaemYbD-V+Pt4A(Fk2ui token generate success token=MTYyODc4NzU0OC40NTYwMDY4OjliNzk3NTNhLWZiOGUtMTFlYi05ZTUyLTAyNDJhYzE
  00:59:10.389 [mobservice1] INFO info 9cdd7552-fb8e-11eb-905d-0242ac110003:GVawnFOc write success
  00:59:12.759 [mobservice1] INFO info 9e43efb6-fb8e-11eb-a328-0242ac110003:LMSlzvKp write success
  00:59:15.253 [mobservice1] INFO info 9fc554f6-fb8e-11eb-b907-0242ac110004:AMFryZUz write success
  00:59:17.310 [dbservice1] INFO a0c5f66c-fb8e-11eb-af99-0242ac110003-XtQAmVaq-fU}q@<msQnpj token generate success token=MTYyODc4NzU1Ny4zMTAxNDIzOmEwYzVmNjZjLWZiOGUtMTFlYi1hZjk5LTAyNDJhYzE
  00:59:19.336 [mobservice1] INFO info a23637be-fb8e-11eb-b9c1-0242ac110003:PQTXyvDH write success
  00:59:21.365 [dbservice2] INFO a3229f14-fb8e-11eb-97f6-0242ac110003-oneLisuW-Pro9K=*$vW>g token generate success token=MTYyODc4NzU2MS4zNjUxOTM6YTMyMjlmMTQtZmI4ZS0xMWViLTk3ZjYtMDI0MmFjMTE
  00:59:23.798 [dbservice2] INFO a4947958-fb8e-11eb-a504-0242ac110004-LmHpecgO-{$XO7}iZEDzn token generate success token=MTYyODc4NzU2My43OTgxMTA3OmE0OTQ3OTU4LWZiOGUtMTFlYi1hNTA0LTAyNDJhYzE
  00:59:26.495 [mobservice1] INFO info a67486c8-fb8e-11eb-a83c-0242ac110003:dXbvhYuV write success
  00:59:37.666 [dbservice2] INFO acd9200a-fb8e-11eb-9a41-0242ac110004-yAHjfLsg-1.I*O7X>)8Wu token generate success token=MTYyODc4NzU3Ny42NjYzNDM3OmFjZDkyMDBhLWZiOGUtMTFlYi05YTQxLTAyNDJhYzE
  00:59:40.299 [mobservice2] ERROR uuid:a81baec0-fb8e-11eb-b5e7-0242ac110004 information has expired, mobile phone login is invalid
  00:59:40.769 [dbservice1] INFO aeaf85ea-fb8e-11eb-8ff2-0242ac110003-rhVoyqAc-:LnRb/Hg2fzY token generate success token=MTYyODc4NzU4MC43Njk0ODU1OmFlYWY4NWVhLWZiOGUtMTFlYi04ZmYyLTAyNDJhYzE
  00:59:43.236 [dbservice2] INFO b0222c0c-fb8e-11eb-b6e9-0242ac110004-yaVPzdET--.P$:@2DE53H token generate success token=MTYyODc4NzU4My4yMzYxMzg2OmIwMjIyYzBjLWZiOGUtMTFlYi1iNmU5LTAyNDJhYzE
  00:59:46.081 [dbservice1] INFO b1e6aab8-fb8e-11eb-b84a-0242ac110003-pDXcZzKl-bio?.5l/_(h3 token generate success token=MTYyODc4NzU4Ni4wODEwOTpiMWU2YWFiOC1mYjhlLTExZWItYjg0YS0wMjQyYWMxMTA
  00:59:48.623 [mobservice1] INFO info b39d3f7a-fb8e-11eb-9258-0242ac110004:ImYCctrK write success
  00:59:51.369 [mobservice1] INFO info b53f68bc-fb8e-11eb-be32-0242ac110004:TKNpsvwU write success
  00:59:54.273 [dbservice1] INFO b6cb8e2c-fb8e-11eb-a3d7-0242ac110003-JlhnBpUR-McC7l$J/9BT@ token generate success token=MTYyODc4NzU5NC4yNzMzNzQ2OmI2Y2I4ZTJjLWZiOGUtMTFlYi1hM2Q3LTAyNDJhYzE

## p0080
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T13:05:24.955Z
```
{"service":"logservice1","message":"2021-08-13 13:05:24,955 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | 274d73fad5fc2c41 | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  13:05:21.685 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  13:05:21.685 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '0f38fdd2-fbf4-11eb-9c9a-0242ac110003', 'user_id': 'CzojFELq'}  (×5)
  13:05:22.076 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×2)
  13:05:22.076 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×2)
  13:05:22.486 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  13:05:22.486 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  13:05:22.487 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '0fc89398-fbf4-11eb-b4fe-0242ac110004'}  (×2)
  13:05:22.542 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×2)
All services, 30 seconds either side (sampled):
  13:04:55.001 [redisservice2] INFO redis读取信息成功, status_code: 200  (×42)
  13:04:55.099 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×39)
  13:04:55.592 [redisservice1] INFO redis write success  (×92)
  13:04:55.813 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×47)
  13:04:56.069 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×51)
  13:04:56.706 [mobservice2] INFO info 007712f2-fbf4-11eb-9a47-0242ac110003:DBUWXtFp write success
  13:04:57.274 [webservice2] INFO uuid: 00fd58bc-fbf4-11eb-908d-0242ac110004 write redis successfully  (×44)
  13:04:57.859 [mobservice2] INFO info 01268174-fbf4-11eb-86f1-0242ac110004:NSiQolUW write success
  13:04:58.951 [dbservice2] INFO 017dbc78-fbf4-11eb-9cdf-0242ac110003-OMLuHZEe-zUGYQa}urZJ/ token generate success token=MTYyODgzMTA5OC45NTA2ODE0OjAxN2RiYzc4LWZiZjQtMTFlYi05Y2RmLTAyNDJhYzE
  13:05:01.402 [dbservice2] INFO 031132f4-fbf4-11eb-9414-0242ac110004-nNFECVbW-Ydhf$1eKym8X token generate success token=MTYyODgzMTEwMS40MDIyNDg5OjAzMTEzMmY0LWZiZjQtMTFlYi05NDE0LTAyNDJhYzE
  13:05:04.618 [dbservice1] INFO 048317f6-fbf4-11eb-b534-0242ac110003-lmvshOqT-%2#uLB3dNKSs token generate success token=MTYyODgzMTEwNC42MTc3NDQ0OjA0ODMxN2Y2LWZiZjQtMTFlYi1iNTM0LTAyNDJhYzE
  13:05:07.219 [dbservice1] INFO 065c34fe-fbf4-11eb-b71d-0242ac110003-lAeMCLWx-cz5%VZBN6h-A token generate success token=MTYyODgzMTEwNy4yMTk1NzczOjA2NWMzNGZlLWZiZjQtMTFlYi1iNzFkLTAyNDJhYzE
  13:05:10.100 [mobservice2] INFO info 086d906c-fbf4-11eb-80ec-0242ac110003:rEZWRTXD write success
  13:05:13.439 [dbservice1] INFO 0a1a7f92-fbf4-11eb-9746-0242ac110003-vOcCSRZA-s/FAM$t>D)ox token generate success token=MTYyODgzMTExMy40Mzk0MTk3OjBhMWE3ZjkyLWZiZjQtMTFlYi05NzQ2LTAyNDJhYzE
  13:05:16.214 [dbservice1] INFO 0bde6a3c-fbf4-11eb-af51-0242ac110004-HkuCdjLo-($XWb3R2Lr.6 token generate success token=MTYyODgzMTExNi4yMTQxMzI6MGJkZTZhM2MtZmJmNC0xMWViLWFmNTEtMDI0MmFjMTE
  13:05:19.017 [mobservice1] INFO info 0dcb64c6-fbf4-11eb-8f9a-0242ac110004:ThPbGWEy write success
  13:05:21.859 [mobservice1] INFO info 0f68e510-fbf4-11eb-9806-0242ac110003:NGJTlZWq write success
  13:05:24.391 [dbservice2] INFO 10c908d6-fbf4-11eb-9973-0242ac110004-AnasJGMP-Q?)$%dAI{qjZ token generate success token=MTYyODgzMTEyNC4zOTA1NjM1OjEwYzkwOGQ2LWZiZjQtMTFlYi05OTczLTAyNDJhYzE  (×2)
  13:05:26.786 [dbservice1] INFO 1237eb24-fbf4-11eb-9571-0242ac110003-UEASdwYn-lX/Z%YE&xQ5: token generate success token=MTYyODgzMTEyNi43ODY0MjY6MTIzN2ViMjQtZmJmNC0xMWViLTk1NzEtMDI0MmFjMTE
  13:05:29.970 [dbservice1] INFO 140db8de-fbf4-11eb-95c9-0242ac110004-OBgRIvmU-{eaD^f2GlVBk token generate success token=MTYyODgzMTEyOS45NzAyOTQ1OjE0MGRiOGRlLWZiZjQtMTFlYi05NWM5LTAyNDJhYzE
  13:05:32.666 [dbservice1] INFO 15a61542-fbf4-11eb-a026-0242ac110004-eRTPmDsV-Q!>Vw29I<Kh& token generate success token=MTYyODgzMTEzMi42NjU4MzQ0OjE1YTYxNTQyLWZiZjQtMTFlYi1hMDI2LTAyNDJhYzE
  13:05:35.667 [mobservice2] INFO info 17b40088-fbf4-11eb-97a6-0242ac110003:RspMxJbz write success
  13:05:38.476 [mobservice1] INFO info 1963ba68-fbf4-11eb-87b9-0242ac110003:tLUwrBsD write success
  13:05:40.912 [mobservice1] INFO info 1ad10b9e-fbf4-11eb-a601-0242ac110003:ohjceMiy write success
  13:05:43.536 [mobservice1] INFO info 1c64b618-fbf4-11eb-a3e2-0242ac110003:tdfCvYKb write success
  13:05:46.788 [mobservice1] INFO info 1e529e22-fbf4-11eb-b307-0242ac110003:DtNVdFIW write success
  13:05:49.203 [mobservice2] INFO info 1fc4c50a-fbf4-11eb-b81b-0242ac110004:ThPbGWEy write success
  13:05:52.013 [mobservice1] INFO info 2173dac6-fbf4-11eb-8dcf-0242ac110004:GYQsHOyA write success
  13:05:54.370 [mobservice1] INFO info 22df7a78-fbf4-11eb-8d12-0242ac110003:cmBuyeUK write success

## p0701
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-12T20:07:45.502Z
```
{"service":"webservice1","message":"2021-08-12 20:07:45,502 | INFO | 0.0.0.1 | 172.17.0.3 | webservice1 | c165c14fb034db10 | uuid: e7399302-fb65-11eb-8370-0242ac110003 write redis successfully"}
```
Same service, the 2 minutes before (oldest first):
  20:07:42.368 [webservice1] INFO uuid: e5599d0c-fb65-11eb-86a1-0242ac110003 write redis successfully  (×4)
  20:07:42.469 [webservice1] ERROR get a error [Errno 2] No such file or directory: 'resources/source_file/source_file.csv'  (×4)
  20:07:42.711 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  20:07:42.711 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  20:07:42.712 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'e596aa4e-fb65-11eb-9fb2-0242ac110003', 'value': '', 'ex': 10}  (×4)
All services, 30 seconds either side (sampled):
  20:07:15.527 [mobservice1] INFO info d527d03e-fb65-11eb-9a1a-0242ac110004:lebfEIwL write success
  20:07:15.632 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×30)
  20:07:15.757 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×35)
  20:07:16.090 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'd5b80abe-fb65-11eb-8bfa-0242ac110003', 'value': '', 'ex': 10}  (×60)
  20:07:16.612 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×63)
  20:07:16.855 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×33)
  20:07:17.253 [redisservice1] INFO service accept, status_code: 200  (×35)
  20:07:17.806 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'd685ba0e-fb65-11eb-afd5-0242ac110004', 'value': 'JlhnBpUR'}  (×29)
  20:07:18.271 [dbservice2] INFO d685ba0e-fb65-11eb-afd5-0242ac110004-JlhnBpUR-McC7l$J/9BT@ token generate success token=MTYyODc3MDAzOC4yNzEyMTY2OmQ2ODViYTBlLWZiNjUtMTFlYi1hZmQ1LTAyNDJhYzE
  20:07:20.412 [dbservice2] INFO d7c9f3d0-fb65-11eb-b25f-0242ac110004-jHYceNBX-P4kgXJlU1L>S token generate success token=MTYyODc3MDA0MC40MTIzNTA0OmQ3YzlmM2QwLWZiNjUtMTFlYi1iMjVmLTAyNDJhYzE
  20:07:22.935 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'd9833308-fb65-11eb-9715-0242ac110004'}  (×33)
  20:07:24.266 [mobservice2] INFO info da5c5822-fb65-11eb-a745-0242ac110004:BLOHhDzM write success
  20:07:26.462 [mobservice2] INFO info dbb0d068-fb65-11eb-8993-0242ac110004:MZHWTqUt write success
  20:07:35.047 [dbservice2] INFO e087c560-fb65-11eb-bc40-0242ac110004-bykmrCDS-$1Q.o+}H3K@R token generate success token=MTYyODc3MDA1NS4wNDY2ODA3OmUwODdjNTYwLWZiNjUtMTFlYi1iYzQwLTAyNDJhYzE
  20:07:37.627 [dbservice2] INFO e20d5120-fb65-11eb-bc15-0242ac110004-GxrcRlDj-Lw{tNT75j/%g token generate success token=MTYyODc3MDA1Ny42MjY5MDI2OmUyMGQ1MTIwLWZiNjUtMTFlYi1iYzE1LTAyNDJhYzE
  20:07:40.009 [dbservice2] INFO e388b5ee-fb65-11eb-bd34-0242ac110004-laBJUtSP-E8m<2RIzvG_e token generate success token=MTYyODc3MDA2MC4wMDg5MTI6ZTM4OGI1ZWUtZmI2NS0xMWViLWJkMzQtMDI0MmFjMTE
  20:07:41.782 [dbservice2] INFO e49275ce-fb65-11eb-9008-0242ac110004-DHpIOPcr--ZJF#vtu)<Ez token generate success token=MTYyODc3MDA2MS43ODE4Nzg1OmU0OTI3NWNlLWZiNjUtMTFlYi05MDA4LTAyNDJhYzE
  20:07:45.272 [mobservice1] INFO info e6e6d8ce-fb65-11eb-b4b0-0242ac110004:AnasJGMP write success
  20:07:47.898 [dbservice1] INFO e83fd892-fb65-11eb-af66-0242ac110004-jIBRSGcQ-)ERfPKel{cTt token generate success token=MTYyODc3MDA2Ny44OTc5MzY2OmU4M2ZkODkyLWZiNjUtMTFlYi1hZjY2LTAyNDJhYzE
  20:07:50.547 [mobservice2] INFO info e9f3a6fa-fb65-11eb-b99c-0242ac110004:KCqMeUmB write success
  20:07:53.006 [dbservice2] INFO eb579880-fb65-11eb-bed8-0242ac110004-mgJapjfn-_y)3.7z{26^$ token generate success token=MTYyODc3MDA3My4wMDU1NjM1OmViNTc5ODgwLWZiNjUtMTFlYi1iZWQ4LTAyNDJhYzE
  20:07:54.789 [dbservice2] INFO ec5ecb7c-fb65-11eb-8d2c-0242ac110004-PvCnuEHJ-a<IPE/Kuy=io token generate success token=MTYyODc3MDA3NC43ODg2NzY6ZWM1ZWNiN2MtZmI2NS0xMWViLThkMmMtMDI0MmFjMTE
  20:07:56.870 [dbservice1] INFO ed960546-fb65-11eb-8470-0242ac110004-rEZWRTXD-UKb{HBlMXzm2 token generate success token=MTYyODc3MDA3Ni44Njk3NDQzOmVkOTYwNTQ2LWZiNjUtMTFlYi04NDcwLTAyNDJhYzE
  20:07:59.285 [mobservice1] INFO info ef3cbb9c-fb65-11eb-97af-0242ac110004:cmBuyeUK write success
  20:08:02.091 [mobservice1] INFO info f0f1e250-fb65-11eb-ab24-0242ac110004:hsWGAMiu write success
  20:08:05.321 [mobservice2] INFO info f2cd6f2c-fb65-11eb-a409-0242ac110004:pGnBPZOX write success
  20:08:07.167 [mobservice1] INFO info f3f3f2e0-fb65-11eb-b1ea-0242ac110004:ulnvrqij write success
  20:08:09.461 [mobservice1] INFO info f55729b8-fb65-11eb-bb0d-0242ac110004:PJMibIFO write success
  20:08:11.534 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  20:08:14.678 [mobservice1] INFO info f8707f32-fb65-11eb-a276-0242ac110004:mTbzBuLd write success

## p0201
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:57:29.742Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731913049742320000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"home"}
```
Same service, the 2 minutes before (oldest first):
  06:57:28.953 [frontend] serving product page  (×2)
  06:57:28.994 [frontend] request complete  (×7)
  06:57:29.511 [frontend] request started  (×6)
  06:57:29.511 [frontend] setting currency
  06:57:29.514 [frontend] home
  06:57:29.558 [frontend] adding to cart
  06:57:29.561 [frontend] ENV_PLATFORM is: aws
  06:57:29.569 [frontend] view user cart
All services, 30 seconds either side (sampled):
  06:56:59.935 [frontend] request started  (×303)
  06:56:59.944 [cartservice] GetCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×247)
  06:56:59.968 [adservice] received ad request (context_words=[clothing, tops])  (×21)
  06:56:59.976 [cartservice] AddItemAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55, productId=66VCHSJNUP, quantity=9  (×35)
  06:57:00.013 [shippingservice] [GetQuote] completed request  (×70)
  06:57:00.060 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"1283","nanos":288535186},"credit_card":{"credit_card_number":"4609084153549  (×3)
  06:57:00.063 [shippingservice] [ShipOrder] received request  (×9)
  06:57:00.072 [emailservice] A request to send order confirmation email to rschwartz@example.net has been received.
  06:57:00.911 [adservice] received ad request (context_words=[kitchen])  (×54)
  06:57:02.277 [frontend] home  (×28)
  06:57:02.359 [adservice] received ad request (context_words=[])  (×29)
  06:57:06.597 [adservice] received ad request (context_words=[accessories])  (×22)
  06:57:09.338 [emailservice] A request to send order confirmation email to xgrant@example.net has been received.
  06:57:09.363 [paymentservice] Transaction processed: visa ending 6567 Amount: JPY252244.309599874  (×2)
  06:57:10.213 [emailservice] A request to send order confirmation email to paulhernandez@example.com has been received.
  06:57:35.238 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="GBP"
  06:57:35.288 [emailservice] A request to send order confirmation email to lindarasmussen@example.net has been received.
  06:57:40.760 [checkoutservice] order confirmation email sent to "paulamitchell@example.org"
  06:57:50.701 [paymentservice] Transaction processed: visa ending 0224 Amount: CAD575.104870416
  06:57:51.552 [checkoutservice] [PlaceOrder] user_id="b63bea0e-d05f-4589-be71-8fef43557432" user_currency="USD"  (×2)
  06:57:51.601 [emailservice] A request to send order confirmation email to ljones@example.net has been received.
  06:57:59.414 [checkoutservice] order confirmation email sent to "john72@example.com"

## p0267
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:17.558Z
```
{"timestamp":1732242497558262300,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"673fec41b0df5c00019af98b"}
```
Same service, the 2 minutes before (oldest first):
  02:28:16.238 [front-end] Merging carts for customer id: 673fec40b0df5c00019af988 and session id: -7CzSWzmZrMmDK5B1dmO1fprYUPKidbH
  02:28:16.536 [front-end] GET /catalogue 200 - ms - -  (×4)
  02:28:17.014 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec38b0df5c00019af971"}
  02:28:17.022 [front-end] POST /addresses 200 - ms - -
  02:28:17.028 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec38b0df5c00019af971"}
  02:28:17.035 [front-end] POST /cards 200 - ms - -
  02:28:17.084 [front-end] Attempting to delete cart for user: 673fec38b0df5c00019af971
  02:28:17.369 [front-end] Request received with body: {}
  02:28:17.377 [front-end] Received response: "{\"firstName\":\"vtFUiCYPGkr\",\"lastName\":\"vtFUiCYPGkr\",\"username\":\"vtFUiCYPGkr\",\"id\":\"673fec2bb0df5c00019af944\",\"_links\":{\"a
  02:28:17.377 [front-end] GET Request to: http://user/customers/673fec2bb0df5c00019af944/addresses  (×2)
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec33b0df5c00019af961\",\"_links\":{\"
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:17.383 [front-end] [ undefined, undefined ]
  02:28:17.383 [front-end] Posting Order: {"customer":"http://user/customers/673fec2bb0df5c00019af944","address":"http://user/addresses/673fec33b0df5c00019af960","card":"http://user/cards
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:17.558 [front-end] { id: '673fec41b0df5c00019af98b' }
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×44)
  02:28:03.174 [front-end] User cart deleted with status: 503  (×43)
  02:28:03.202 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×43)
  02:28:03.249 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×17)
  02:28:03.410 [front-end] Carts merged.  (×44)
  02:28:04.973 [front-end] Posting Customer: {"username":"HFHBXn","password":"EOgUhihln","email":"HFHBXn@gmail.com","firstName":"HFHBXn","lastName":"HFHBXn"}
  02:28:05.351 [user] ts=2024-11-22T02:28:05.351787827Z caller=middlewares.go:46 method=Register username=vuOxCKL email=vuOxCKL@gmail.com took=4.581531ms
  02:28:08.095 [front-end] Received response: "{\"firstName\":\"RsyjMQXEZqDOIBa\",\"lastName\":\"RsyjMQXEZqDOIBa\",\"username\":\"RsyjMQXEZqDOIBa\",\"id\":\"673fec1eb0df5c00019af912\",\"_
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×6)
  02:28:15.136 [carts] 2024-11-22 02:28:15.041 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 160.989 seconds (JVM running for 167.0
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:22.317 [front-end] Received response: "{\"firstName\":\"JGQXvUjPbFrtK\",\"lastName\":\"JGQXvUjPbFrtK\",\"username\":\"JGQXvUjPbFrtK\",\"id\":\"673fec34b0df5c00019af964\",\"_links\
  02:28:23.143 [orders] 2024-11-22 02:28:23.143 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×10)
  02:28:24.588 [shipping] Adding shipment to queue...  (×25)
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:26.156 [front-end] POST /cart 201 - ms - -  (×28)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d8","customerId":"673fec2cb0df5c00019af949","customer":{"id":null,"firstName":"KoWsmDtUqsE
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:30.547 [front-end] Received response: "{\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\",\"username\":\"vvgsHcY\",\"id\":\"673fec35b0df5c00019af968\",\"_links\":{\"addresses\":{
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.645 [queue-master] 2024-11-22 02:28:32.645 INFO 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×16)
  02:28:37.005 [user] ts=2024-11-22T02:28:37.005380807Z caller=middlewares.go:46 method=Register username=XTqSaA email=XTqSaA@gmail.com took=624.562µs
  02:28:40.136 [front-end] Order response: {"id":"673fec58d94b9000069b39dc","customerId":"673fec41b0df5c00019af98b","customer":{"id":null,"firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe",
  02:28:41.723 [user] ts=2024-11-22T02:28:41.723279742Z caller=middlewares.go:46 method=Register username=yaELjpCD email=yaELjpCD@gmail.com took=1.302265ms
  02:28:43.812 [front-end] Order response: {"id":"673fec5bd94b9000069b39e0","customerId":"673fec47b0df5c00019af996","customer":{"id":null,"firstName":"bhZuEQ","lastName":"bhZuEQ","usernam
  02:28:45.163 [front-end] Received response: "{\"firstName\":\"oqYeDriHaX\",\"lastName\":\"oqYeDriHaX\",\"username\":\"oqYeDriHaX\",\"id\":\"673fec49b0df5c00019af999\",\"_links\":{\"addr
  02:28:46.749 [front-end] Posting Customer: {"username":"kSaYlXePgdj","password":"miJFSQiUAg","email":"kSaYlXePgdj@gmail.com","firstName":"kSaYlXePgdj","lastName":"kSaYlXePgdj"}

## p0481
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-23T08:56:58.026Z
```
{"timestamp":1732352218026500900,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-zmfhr","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:56:58.026  INFO 7 --- [pool-6-thread-1] o.apache.http.impl.execchain.RetryExec   : Retrying request to {}->unix://localhost:80"}
```
Same service, the 2 minutes before (oldest first):
  08:56:58.025 [queue-master] Received shipment task: 674198bfa437380001deff45
  08:56:58.025 [queue-master] 2024-11-23 08:56:58.025 INFO 7 --- [pool-6-thread-1] w.weave.socks.queuemaster.DockerSpawner : Spawning new container
  08:56:58.026 [queue-master] 2024-11-23 08:56:58.026 INFO 7 --- [pool-6-thread-1] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×3)
  08:56:58.026 [queue-master] 2024-11-23 08:56:58.026 INFO 7 --- [pool-6-thread-1] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×2)
All services, 30 seconds either side (sampled):
  08:56:58.007 [catalogue] ts=2024-11-23T08:56:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.869902ms  (×34)
  08:56:58.018 [orders] 2024-11-23 08:56:58.018 INFO [orders,6baef7816fdf67ff,4dc9cbe9bd6cff45,false] 8 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Received payment re  (×24)
  08:56:58.029 [front-end] Order response: {"statusCode":201,"body":{"id":"674198da3f77060008865384","customerId":"674198bfa437380001deff45","customer":{"id":null,"firstName":"ztfESzW","l
  08:56:59.388 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674198d3a437380001deff98"}  (×26)
  08:56:59.483 [catalogue] ts=2024-11-23T08:56:59Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.990138  (×24)
  08:57:00.720 [front-end] Request received with body: {}  (×24)
  08:57:00.744 [front-end] Posting Order: {"customer":"http://user/customers/674198caa437380001deff7c","address":"http://user/addresses/674198d0a437380001deff90","card":"http://user/cards  (×24)
  08:57:01.048 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  08:57:01.165 [front-end] 674198dda437380001deffa9  (×30)
  08:57:02.787 [front-end] Received response: "{\"firstName\":\"iEYCUjoH\",\"lastName\":\"iEYCUjoH\",\"username\":\"iEYCUjoH\",\"id\":\"674198c5a437380001deff67\",\"_links\":{\"addresses\
  08:57:03.057 [front-end] Order response: {"statusCode":201,"body":{"id":"674198df3f77060008865387","customerId":"674198caa437380001deff7e","customer":{"id":null,"firstName":"qzkCXXFW","
  08:57:04.140 [front-end] Received response: "{\"firstName\":\"TlHaLWqJVqW\",\"lastName\":\"TlHaLWqJVqW\",\"username\":\"TlHaLWqJVqW\",\"id\":\"674198d0a437380001deff92\",\"_links\":{\"a
  08:57:05.392 [orders] 2024-11-23 08:57:05.392 INFO [orders,3c526066b205402a,acb1c0fc61191c83,false] 8 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req
  08:57:07.035 [front-end] Order response: {"statusCode":201,"body":{"id":"674198e33f7706000886538a","customerId":"674198caa437380001deff7d","customer":{"id":null,"firstName":"vidoaLMiMZn
  08:57:08.980 [queue-master] 2024-11-23 08:57:08.980 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×42)
  08:57:09.152 [front-end] Order response: {"id":"674198e53f7706000886538c","customerId":"674198d2a437380001deff95","customer":{"id":null,"firstName":"zUGYrCgol","lastName":"zUGYrCgol","u
  08:57:11.533 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×6)
  08:57:13.005 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  08:57:14.121 [front-end] Posting Customer: {"username":"JCYeKSjM","password":"MYIoBCiY","email":"JCYeKSjM@gmail.com","firstName":"JCYeKSjM","lastName":"JCYeKSjM"}
  08:57:15.678 [front-end] Order response: {"id":"674198eb3f7706000886538f","customerId":"674198cfa437380001deff8c","customer":{"id":null,"firstName":"FygEtnQmntW","lastName":"FygEtnQmntW
  08:57:18.424 [user] ts=2024-11-23T08:57:18.424838811Z caller=middlewares.go:46 method=Register username=bqLFOFtK email=bqLFOFtK@gmail.com took=2.548455ms
  08:57:19.305 [front-end] Received response: "{\"firstName\":\"aXWRmKRnN\",\"lastName\":\"aXWRmKRnN\",\"username\":\"aXWRmKRnN\",\"id\":\"674198d9a437380001deffa4\",\"_links\":{\"address
  08:57:22.096 [front-end] Posting Customer: {"username":"ErqkMC","password":"qwrMe","email":"ErqkMC@gmail.com","firstName":"ErqkMC","lastName":"ErqkMC"}
  08:57:24.110 [front-end] Order response: {"id":"674198f43f77060008865392","customerId":"674198dfa437380001deffad","customer":{"id":null,"firstName":"wqgJPHku","lastName":"wqgJPHku","use
  08:57:25.404 [front-end] Order response: {"id":"674198f53f77060008865393","customerId":"674198e2a437380001deffb0","customer":{"id":null,"firstName":"tVFCKe","lastName":"tVFCKe","usernam
  08:57:26.581 [front-end] Received response: "{\"firstName\":\"aQTVfKPpOQTV\",\"lastName\":\"aQTVfKPpOQTV\",\"username\":\"aQTVfKPpOQTV\",\"id\":\"674198e5a437380001deffb4\",\"_links\":{
  08:57:27.415 [front-end] Order response: {"statusCode":201,"body":{"id":"674198f73f77060008865398","customerId":"674198dda437380001deffa9","customer":{"id":null,"firstName":"eWMmgZPhWLI

## p0446
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T08:06:06.402Z
```
{"timestamp":1732349166402026800,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:06.401  INFO [carts,,,] 7 --- [           main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframework.boot.actuate.autoconfigure.EndpointWebMvcHypermediaManagementContextConfiguration$ActuatorEndpointLinksAdvice"}
```
Same service, the 2 minutes before (oldest first):
  08:05:45.411 [carts] 2024-11-23 08:05:45.411 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  08:06:00.413 [carts] 2024-11-23 08:06:00.413 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  08:06:00.500 [carts] 2024-11-23 08:06:00.500 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[DE
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[GET],produces=
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}/merge],methods=[GET]}" onto publi
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[GET],produces=[applicat
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.spring
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  08:06:03.410 [carts] 2024-11-23 08:06:03.409 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  08:06:03.602 [carts] 2024-11-23 08:06:03.600 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.ac
  08:06:05.306 [carts] 2024-11-23 08:06:05.304 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.sp
  08:06:05.306 [carts] 2024-11-23 08:06:05.305 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springfram
  08:06:05.306 [carts] 2024-11-23 08:06:05.306 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/browser/**] onto handler of type [class org.sp
  08:06:05.306 [carts] 2024-11-23 08:06:05.306 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr
  08:06:05.306 [carts] 2024-11-23 08:06:05.306 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/**] onto handler of type [class org.s
  08:06:06.402 [carts] 2024-11-23 08:06:06.401 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionHa
All services, 30 seconds either side (sampled):
  08:05:36.411 [front-end] Order response: {"statusCode":503,"body":"upstream connect error or disconnect/reset before headers. retried and the latest reset reason: remote connection fail  (×13)
  08:05:36.620 [user] ts=2024-11-23T08:05:36.620436853Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418cc9a437380001deec1a took=3.572043ms  (×59)
  08:05:37.558 [user] ts=2024-11-23T08:05:37.55870177Z caller=middlewares.go:46 method=Register username=QTNxlk email=QTNxlk@gmail.com took=2.268833ms
  08:05:39.084 [orders] 2024-11-23 08:05:38.992 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.act
  08:05:39.193 [orders] 2024-11-23 08:05:39.193 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[DELETE],produc
  08:05:39.388 [orders] 2024-11-23 08:05:39.388 INFO [orders,,,] 8 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionH
  08:05:41.192 [orders] 2024-11-23 08:05:41.192 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json
  08:05:44.157 [front-end] Posting Customer: {"username":"zFrpP","password":"lvSXmE","email":"zFrpP@gmail.com","firstName":"zFrpP","lastName":"zFrpP"}
  08:05:46.020 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×2)
  08:05:49.233 [front-end] Posting Customer: {"username":"psXVPVgRfTd","password":"byGXeUSnN","email":"psXVPVgRfTd@gmail.com","firstName":"psXVPVgRfTd","lastName":"psXVPVgRfTd"}
  08:05:51.461 [front-end] Posting Customer: {"username":"JfkloKMY","password":"BAlPTCaswY","email":"JfkloKMY@gmail.com","firstName":"JfkloKMY","lastName":"JfkloKMY"}
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto publi
  08:05:57.198 [shipping] 2024-11-23 08:05:57.110 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.cont
  08:06:00.060 [front-end] Received response: "{\"firstName\":\"VGvhEBXruush\",\"lastName\":\"VGvhEBXruush\",\"username\":\"VGvhEBXruush\",\"id\":\"67418cd5a437380001deec3f\",\"_links\":{
  08:06:04.542 [front-end] Received response: "{\"firstName\":\"yeVOXGwCs\",\"lastName\":\"yeVOXGwCs\",\"username\":\"yeVOXGwCs\",\"id\":\"67418cd3a437380001deec3b\",\"_links\":{\"address
  08:06:07.002 [shipping] 2024-11-23 08:06:07.002 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[HEAD],produces=[applica
  08:06:07.099 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[GET],produce  (×2)
  08:06:10.340 [front-end] Posting Customer: {"username":"djVRqry","password":"CJLHmVgJ","email":"djVRqry@gmail.com","firstName":"djVRqry","lastName":"djVRqry"}
  08:06:14.400 [shipping] 2024-11-23 08:06:14.400 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX ser
  08:06:15.802 [carts] 2024-11-23 08:06:15.802 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[applicati
  08:06:15.906 [carts] 2024-11-23 08:06:15.904 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframewor
  08:06:19.002 [carts] 2024-11-23 08:06:19.001 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]
  08:06:19.274 [front-end] Posting Customer: {"username":"ctDNRPS","password":"kZNuA","email":"ctDNRPS@gmail.com","firstName":"ctDNRPS","lastName":"ctDNRPS"}
  08:06:24.199 [carts] 2024-11-23 08:06:24.199 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposur  (×2)
  08:06:26.760 [front-end] Posting Customer: {"username":"KGcCpZnH","password":"FAILN","email":"KGcCpZnH@gmail.com","firstName":"KGcCpZnH","lastName":"KGcCpZnH"}
  08:06:30.125 [front-end] Posting Customer: {"username":"dRUZXQgdp","password":"cwnWjNOrJ","email":"dRUZXQgdp@gmail.com","firstName":"dRUZXQgdp","lastName":"dRUZXQgdp"}
  08:06:32.706 [carts] 2024-11-23 08:06:32.705 INFO [carts,2647ced1ca3ed2a8,2ee10f17902bcac4,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],m  (×3)
  08:06:34.501 [carts] 2024-11-23 08:06:34.501 INFO [carts,1e903490db126ed7,0f10e1096f3be1bd,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)
  08:06:35.986 [orders-db] {"t":{"$date":"2024-11-23T08:06:35.986+00:00"},"s":"I", "c":"STORAGE", "id":20320, "ctx":"conn5","msg":"createCollection","attr":{"namespace":"data.customerOrde  (×5)

## p0421
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T04:07:21.928Z
```
{"timestamp":1732248441928833500,"container_name":"front-end","pod_name":"front-end-ccbbfbf7f-szg8d","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"Attempting to add to cart: {\"id\":\"03fef6ac-1896-4ce8-bd69-b798f85c6e0b\",\"quantity\":1}"}
```
Same service, the 2 minutes before (oldest first):
  04:07:21.260 [front-end] POST to carts: http://carts/carts/67400371b0df5c00019b4077/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}  (×2)
  04:07:21.302 [front-end] POST /cart 500 52.345 ms - 70  (×2)
  04:07:21.721 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6740036fb0df5c00019b4071"}  (×2)
  04:07:21.729 [front-end] POST /addresses 200 - ms - -  (×2)
  04:07:21.734 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"6740036fb0df5c00019b4071"}  (×2)
  04:07:21.742 [front-end] POST /cards 200 - ms - -  (×2)
  04:07:21.788 [front-end] Attempting to delete cart for user: 6740036fb0df5c00019b4071  (×2)
  04:07:21.809 [front-end] User cart deleted with status: 202  (×2)
  04:07:21.810 [front-end] DELETE /cart 202 - ms - -  (×2)
  04:07:21.815 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  04:07:21.824 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
All services, 30 seconds either side (sampled):
  04:06:51.953 [front-end] Posting Customer: {"username":"ipJkRGhgGPtHCik","password":"Jjwxm","email":"ipJkRGhgGPtHCik@gmail.com","firstName":"ipJkRGhgGPtHCik","lastName":"ipJkRGhgGPtHCik
  04:06:52.020 [front-end] Received response: "{\"firstName\":\"VMacAfAb\",\"lastName\":\"VMacAfAb\",\"username\":\"VMacAfAb\",\"id\":\"67400346b0df5c00019b3feb\",\"_links\":{\"addresses\
  04:06:52.056 [queue-master] Received shipment task: 67400346b0df5c00019b3feb  (×52)
  04:06:52.455 [user] ts=2024-11-22T04:06:52.455367263Z caller=middlewares.go:134 method=GetCards id=6740034fb0df5c00019b4006 result=1 took=1.026235ms  (×17)
  04:06:53.059 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67400353b0df5c00019b4012"}  (×67)
  04:06:53.217 [front-end] POST to carts: http://carts/carts/67400353b0df5c00019b4012/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}  (×37)
  04:06:53.649 [front-end] Received response: "{\"firstName\":\"xXhoXEnXNtAXaLb\",\"lastName\":\"xXhoXEnXNtAXaLb\",\"username\":\"xXhoXEnXNtAXaLb\",\"id\":\"6740034eb0df5c00019b4002\",\"_
  04:06:54.367 [user] ts=2024-11-22T04:06:54.367668447Z caller=middlewares.go:46 method=Register username=PQuUWJa email=PQuUWJa@gmail.com took=1.054096ms
  04:06:58.542 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×4)
  04:07:01.573 [front-end] Order response: {"statusCode":201,"body":{"id":"67400365d94b9000069b4c21","customerId":"6740034fb0df5c00019b4008","customer":{"id":null,"firstName":"TjMPrYdTd",
  04:07:04.048 [front-end] Order response: {"statusCode":201,"body":{"id":"67400368d94b9000069b4c23","customerId":"67400350b0df5c00019b400c","customer":{"id":null,"firstName":"GJHfBaUQpOH
  04:07:05.497 [front-end] Order response: {"statusCode":201,"body":{"id":"67400369d94b9000069b4c26","customerId":"67400356b0df5c00019b401c","customer":{"id":null,"firstName":"xsIEJz","la
  04:07:08.480 [front-end] Received response: "{\"firstName\":\"FdvmzLhgGonpAi\",\"lastName\":\"FdvmzLhgGonpAi\",\"username\":\"FdvmzLhgGonpAi\",\"id\":\"67400358b0df5c00019b4029\",\"_lin
  04:07:10.193 [user] ts=2024-11-22T04:07:10.193418615Z caller=middlewares.go:46 method=Register username=XHzdVxaE email=XHzdVxaE@gmail.com took=942.68µs
  04:07:11.680 [front-end] Posting Customer: {"username":"nAjAbNBaYmZOK","password":"ruDqgR","email":"nAjAbNBaYmZOK@gmail.com","firstName":"nAjAbNBaYmZOK","lastName":"nAjAbNBaYmZOK"}
  04:07:13.765 [front-end] Order response: {"id":"67400371d94b9000069b4c30","customerId":"6740035db0df5c00019b403a","customer":{"id":null,"firstName":"GMCfGvRogkTCGWI","lastName":"GMCfGvR
  04:07:16.010 [front-end] Order response: {"statusCode":201,"body":{"id":"67400374d94b9000069b4c34","customerId":"67400360b0df5c00019b4045","customer":{"id":null,"firstName":"eFxTPbGUIak
  04:07:20.320 [front-end] Posting Customer: {"username":"vkdwObuFZQnry","password":"bpzJmAP","email":"vkdwObuFZQnry@gmail.com","firstName":"vkdwObuFZQnry","lastName":"vkdwObuFZQnry"}
  04:07:24.825 [front-end] Order response: {"id":"6740037cd94b9000069b4c36","customerId":"67400364b0df5c00019b4053","customer":{"id":null,"firstName":"YdvJlnFQc","lastName":"YdvJlnFQc","u
  04:07:28.446 [front-end] Order response: {"statusCode":201,"body":{"id":"67400380d94b9000069b4c38","customerId":"6740036fb0df5c00019b406e","customer":{"id":null,"firstName":"tEbvvE","la
  04:07:31.210 [front-end] Received response: "{\"firstName\":\"RksWvtcHDOiIR\",\"lastName\":\"RksWvtcHDOiIR\",\"username\":\"RksWvtcHDOiIR\",\"id\":\"6740036db0df5c00019b406c\",\"_links\
  04:07:32.945 [front-end] Posting Customer: {"username":"hOIhSGwo","password":"PAXSSkDFMn","email":"hOIhSGwo@gmail.com","firstName":"hOIhSGwo","lastName":"hOIhSGwo"}
  04:07:34.405 [front-end] Order response: {"statusCode":201,"body":{"id":"67400386d94b9000069b4c3d","customerId":"67400371b0df5c00019b4077","customer":{"id":null,"firstName":"bKUJFztdrgd
  04:07:36.272 [user] ts=2024-11-22T04:07:36.272772785Z caller=middlewares.go:46 method=Register username=Qyygx email=Qyygx@gmail.com took=1.004693ms
  04:07:40.523 [front-end] Posting Customer: {"username":"RZtYFwPzLXPiVCY","password":"ahmvAHzsQ","email":"RZtYFwPzLXPiVCY@gmail.com","firstName":"RZtYFwPzLXPiVCY","lastName":"RZtYFwPzLXP
  04:07:43.328 [front-end] Order response: {"id":"6740038fd94b9000069b4c44","customerId":"6740037bb0df5c00019b4099","customer":{"id":null,"firstName":"pNTYVzreyyJPR","lastName":"pNTYVzrey
  04:07:45.663 [front-end] Order response: {"id":"67400391d94b9000069b4c47","customerId":"67400378b0df5c00019b408f","customer":{"id":null,"firstName":"vkdwObuFZQnry","lastName":"vkdwObuFZ
  04:07:49.623 [front-end] Order response: {"statusCode":201,"body":{"id":"67400395d94b9000069b4c4a","customerId":"67400384b0df5c00019b40b9","customer":{"id":null,"firstName":"nfJmvf","la
  04:07:51.772 [front-end] Order response: {"id":"67400397d94b9000069b4c4d","customerId":"67400380b0df5c00019b40a9","customer":{"id":null,"firstName":"BeCNniBylyaSKGr","lastName":"BeCNniB

## p0092
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-13T20:41:41.504Z
```
{"service":"mobservice1","message":"2021-08-13 20:41:41,504 | INFO | 0.0.0.1 | 172.17.0.5 | mobservice1 | 6832fce5a08a2ff6 | info ceff42ea-fc33-11eb-be68-0242ac110004:SxCJORXF write success"}
```
Same service, the 2 minutes before (oldest first):
  20:41:37.877 [mobservice1] INFO info ccd1db54-fc33-11eb-b4ca-0242ac110003:YXLKvufE write success
  20:41:38.564 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  20:41:38.564 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  20:41:38.565 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'cd581c82-fc33-11eb-826b-0242ac110003'}  (×4)
  20:41:38.652 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'cd581c82-fc33-11eb-826b-0242ac110003', 'value': 'FAmtCcIX'}  (×4)
  20:41:38.713 [mobservice1] INFO info cd581c82-fc33-11eb-826b-0242ac110003:FAmtCcIX write success
  20:41:40.652 [mobservice1] INFO info ce6615de-fc33-11eb-af57-0242ac110004:mHwMQugd write success
  20:41:40.911 [mobservice1] INFO info ce94723a-fc33-11eb-87c5-0242ac110003:xUAQKIOl write success
All services, 30 seconds either side (sampled):
  20:41:11.553 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×32)
  20:41:11.738 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×33)
  20:41:11.872 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×33)
  20:41:12.062 [dbservice1] INFO bd31399c-fc33-11eb-a908-0242ac110003-WVPTmDGM-P+m#ZGgNRh3= token generate success token=MTYyODg1ODQ3Mi4wNjIyNDY6YmQzMTM5OWMtZmMzMy0xMWViLWE5MDgtMDI0MmFjMTE
  20:41:12.467 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×45)
  20:41:12.638 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×37)
  20:41:12.956 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'be02866e-fc33-11eb-b579-0242ac110004', 'value': 'mMWStTBy'}  (×45)
  20:41:13.201 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×35)
  20:41:13.499 [webservice1] INFO uuid: be789278-fc33-11eb-9ff1-0242ac110003 write redis successfully  (×40)
  20:41:14.674 [mobservice2] INFO info bef98e1e-fc33-11eb-9f66-0242ac110003:wKjLqdJi write success
  20:41:16.392 [mobservice2] INFO info c008bc9e-fc33-11eb-8218-0242ac110004:chfTZIqp write success
  20:41:18.170 [mobservice1] INFO info c11f0304-fc33-11eb-a2ee-0242ac110004:OiYedVug write success
  20:41:20.792 [mobservice2] INFO info c294965e-fc33-11eb-a17a-0242ac110004:XutwzNHs write success
  20:41:23.272 [mobservice2] INFO info c419300c-fc33-11eb-9a1c-0242ac110003:IYcJLxjh write success
  20:41:25.482 [dbservice1] INFO c5383168-fc33-11eb-ba1c-0242ac110004-dUFBYtEJ-L:#7fucXYzK- token generate success token=MTYyODg1ODQ4NS40ODE4NDY2OmM1MzgzMTY4LWZjMzMtMTFlYi1iYTFjLTAyNDJhYzE
  20:41:27.590 [mobservice2] INFO info c6bc6806-fc33-11eb-a9a2-0242ac110004:bAuaLHTx write success
  20:41:29.599 [dbservice1] INFO c7a8fc16-fc33-11eb-b573-0242ac110003-lyRPLEHD-<.x92hGQ1Zm! token generate success token=MTYyODg1ODQ4OS41OTg5NDM6YzdhOGZjMTYtZmMzMy0xMWViLWI1NzMtMDI0MmFjMTE
  20:41:32.065 [mobservice1] INFO info c95c6a70-fc33-11eb-826f-0242ac110004:plhmCNjI write success
  20:41:34.550 [dbservice1] INFO ca99cbb2-fc33-11eb-8c2e-0242ac110004-zoYxJZbF-qI)V<HmnWMk} token generate success token=MTYyODg1ODQ5NC41NDk3MzM6Y2E5OWNiYjItZmMzMy0xMWViLThjMmUtMDI0MmFjMTE
  20:41:36.843 [mobservice2] INFO info cc29ee30-fc33-11eb-ace8-0242ac110003:VizMUmJR write success
  20:41:39.076 [dbservice1] INFO cd581c82-fc33-11eb-826b-0242ac110003-FAmtCcIX-WbpwIhFy&DB@ token generate success token=MTYyODg1ODQ5OS4wNzYyMDQ1OmNkNTgxYzgyLWZjMzMtMTFlYi04MjZiLTAyNDJhYzE
  20:41:41.897 [dbservice2] INFO ceff42ea-fc33-11eb-be68-0242ac110004-SxCJORXF-_oJOhD?@jN*( token generate success token=MTYyODg1ODUwMS44OTY1MjczOmNlZmY0MmVhLWZjMzMtMTFlYi1iZTY4LTAyNDJhYzE
  20:41:44.046 [dbservice2] INFO d054ec8a-fc33-11eb-a2a1-0242ac110004-OLjFmMzt-PV-{&M5cFaDl token generate success token=MTYyODg1ODUwNC4wNDU5ODY6ZDA1NGVjOGEtZmMzMy0xMWViLWEyYTEtMDI0MmFjMTE
  20:41:46.477 [mobservice2] INFO info d1fae526-fc33-11eb-bae1-0242ac110003:vUGVxSct write success
  20:41:49.262 [mobservice2] INFO info d39289fc-fc33-11eb-8e57-0242ac110004:dlznWOTR write success
  20:41:51.334 [dbservice1] INFO d4a4adac-fc33-11eb-b40e-0242ac110003-lizwZLCr-o2cBiG3V#50_ token generate success token=MTYyODg1ODUxMS4zMzQwNDQ3OmQ0YTRhZGFjLWZjMzMtMTFlYi1iNDBlLTAyNDJhYzE
  20:41:53.356 [mobservice2] INFO info d612c44e-fc33-11eb-aa87-0242ac110003:UIkWCbjA write success
  20:41:55.353 [dbservice1] INFO d703dfb4-fc33-11eb-9da4-0242ac110003-HxQpIWMr-prs7#j4K0Dz1 token generate success token=MTYyODg1ODUxNS4zNTMzMzQyOmQ3MDNkZmI0LWZjMzMtMTFlYi05ZGE0LTAyNDJhYzE
  20:41:58.312 [dbservice1] INFO d8b95802-fc33-11eb-8c22-0242ac110004-hBdYEDwt-ji?=FL!1P:b> token generate success token=MTYyODg1ODUxOC4zMTIwMjQ4OmQ4Yjk1ODAyLWZjMzMtMTFlYi04YzIyLTAyNDJhYzE
  20:42:03.539 [mobservice1] INFO info dc24abcc-fc33-11eb-a70a-0242ac110003:fjEOpuqm write success

## p0283
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:33:34.127Z
```
{"timestamp":1732242814127890400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"firstName\\\":\\\"geLOLRZuTesCDI\\\",\\\"lastName\\\":\\\"geLOLRZuTesCDI\\\",\\\"username\\\":\\\"geLOLRZuTesCDI\\\",\\\"id\\\":\\\"673fed69b0df5c00019afd06\\\",\\\"_links\\\":{\\\"addresses\\\":{\\\"href\\\":\\\"http://user/customers/673fed69b0df5c00019afd06/addresses\\\"},\\\"cards\\\":{\\\"href\\\":\\\"http://user/customers/673fed69b0df5c00019afd06/cards\\\"},\\\"customer\\\":{\\\"href\\\":\\\"http://user/customers/673fed69b0df5c00019afd0…"}
```
Same service, the 2 minutes before (oldest first):
  02:33:33.197 [front-end] Merging carts for customer id: 673fed7db0df5c00019afd3f and session id: cO62M9UVCOuvJ1O5mBAsYIgXKpWqDQZY
  02:33:33.213 [front-end] GET /catalogue 200 - ms - -  (×3)
  02:33:33.216 [front-end] Carts merged.
  02:33:33.216 [front-end] set cookie673fed7db0df5c00019afd3f
  02:33:33.217 [front-end] Sent cookies.
  02:33:33.219 [front-end] POST /register 200 24.998 ms - 33
  02:33:33.482 [front-end] Request received with body: {}  (×2)
  02:33:33.489 [front-end] Received response: "{\"firstName\":\"vCIFUFNIR\",\"lastName\":\"vCIFUFNIR\",\"username\":\"vCIFUFNIR\",\"id\":\"673fed61b0df5c00019afce7\",\"_links\":{\"address
  02:33:33.489 [front-end] GET Request to: http://user/customers/673fed61b0df5c00019afce7/addresses  (×2)
  02:33:33.495 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fed6bb0df5c00019afd0f\",\"_links\":{\"
  02:33:33.495 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:33:33.495 [front-end] [ undefined, undefined ]
  02:33:33.495 [front-end] Posting Order: {"customer":"http://user/customers/673fed61b0df5c00019afce7","address":"http://user/addresses/673fed6bb0df5c00019afd0e","card":"http://user/cards
  02:33:33.527 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed7dd94b9000069b3af2","customerId":"673fed61b0df5c00019afce7","customer":{"id":null,"firstName":"vCIFUFNIR",
  02:33:33.527 [front-end] Order response: {"id":"673fed7dd94b9000069b3af2","customerId":"673fed61b0df5c00019afce7","customer":{"id":null,"firstName":"vCIFUFNIR","lastName":"vCIFUFNIR","u
  02:33:33.530 [front-end] POST /orders 201 - ms - -
All services, 30 seconds either side (sampled):
  02:33:04.129 [catalogue] ts=2024-11-22T02:33:04Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=5.031286  (×59)
  02:33:04.384 [front-end] POST /cards 200 - ms - -  (×66)
  02:33:04.718 [front-end] Merging carts for customer id: 673fed60b0df5c00019afce4 and session id: UW5Io034Te5hXqlrbxVnbKgoGVPV11xp  (×58)
  02:33:05.561 [front-end] POST to carts: http://carts/carts/673fed58b0df5c00019afcc3/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×36)
  02:33:05.735 [front-end] Posting Order: {"customer":"http://user/customers/673fed4db0df5c00019afca1","address":"http://user/addresses/673fed52b0df5c00019afcb0","card":"http://user/cards  (×66)
  02:33:05.775 [queue-master] 2024-11-22 02:33:05.769 INFO 6 --- [pool-6-thread-7] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×33)
  02:33:06.828 [user] ts=2024-11-22T02:33:06.828653678Z caller=middlewares.go:46 method=Register username=NsmNklVC email=NsmNklVC@gmail.com took=945.204µs
  02:33:08.338 [queue-master] 2024-11-22 02:33:08.338 ERROR 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×49)
  02:33:10.939 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed66d94b9000069b3ad4","customerId":"673fed4cb0df5c00019afca0","customer":{"id":null,"firstName":"XFaBIZUsdEF
  02:33:12.799 [front-end] Posting Customer: {"username":"abGZf","password":"DyVPtvRa","email":"abGZf@gmail.com","firstName":"abGZf","lastName":"abGZf"}
  02:33:14.174 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed6ad94b9000069b3ada","customerId":"673fed54b0df5c00019afcbc","customer":{"id":null,"firstName":"BNKZT","las
  02:33:16.210 [payment] ts=2024-11-22T02:33:16Z caller=logging.go:29 method=Authorise result=false took=6.901µs  (×6)
  02:33:17.917 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed6dd94b9000069b3adf","customerId":"673fed59b0df5c00019afcca","customer":{"id":null,"firstName":"WokLCvgJysz
  02:33:19.249 [front-end] Order response: {"id":"673fed6fd94b9000069b3ae2","customerId":"673fed5bb0df5c00019afcd3","customer":{"id":null,"firstName":"JFbNAEVlTUW","lastName":"JFbNAEVlTUW
  02:33:20.927 [user] ts=2024-11-22T02:33:20.926783692Z caller=middlewares.go:46 method=Register username=JNJrQ email=JNJrQ@gmail.com took=995.2µs
  02:33:22.589 [front-end] Posting Customer: {"username":"VqiVbr","password":"qOylC","email":"VqiVbr@gmail.com","firstName":"VqiVbr","lastName":"VqiVbr"}
  02:33:25.089 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed75d94b9000069b3aeb","customerId":"673fed62b0df5c00019afcee","customer":{"id":null,"firstName":"NsmNklVC","
  02:33:28.569 [front-end] Order response: {"id":"673fed78d94b9000069b3aec","customerId":"673fed63b0df5c00019afcf1","customer":{"id":null,"firstName":"uGgJitWyTQR","lastName":"uGgJitWyTQR
  02:33:31.670 [front-end] Posting Customer: {"username":"ToRXRKgrmH","password":"muzhRtPN","email":"ToRXRKgrmH@gmail.com","firstName":"ToRXRKgrmH","lastName":"ToRXRKgrmH"}
  02:33:33.126 [front-end] Posting Customer: {"username":"FtxLPSEMJw","password":"bcfBlxHjJQ","email":"FtxLPSEMJw@gmail.com","firstName":"FtxLPSEMJw","lastName":"FtxLPSEMJw"}
  02:33:36.601 [front-end] Received response: "{\"firstName\":\"vNajkcWqDqkPe\",\"lastName\":\"vNajkcWqDqkPe\",\"username\":\"vNajkcWqDqkPe\",\"id\":\"673fed6bb0df5c00019afd10\",\"_links\
  02:33:40.842 [front-end] Posting Customer: {"username":"XBkBDNMeahrbK","password":"cMiar","email":"XBkBDNMeahrbK@gmail.com","firstName":"XBkBDNMeahrbK","lastName":"XBkBDNMeahrbK"}
  02:33:43.153 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed87d94b9000069b3af7","customerId":"673fed70b0df5c00019afd1d","customer":{"id":null,"firstName":"JNJrQ","las
  02:33:46.282 [front-end] Posting Customer: {"username":"nDjMmwhGKSAv","password":"fEEAifN","email":"nDjMmwhGKSAv@gmail.com","firstName":"nDjMmwhGKSAv","lastName":"nDjMmwhGKSAv"}
  02:33:48.033 [front-end] Posting Customer: {"username":"qbouxqfSuoIwurm","password":"mNOkpW","email":"qbouxqfSuoIwurm@gmail.com","firstName":"qbouxqfSuoIwurm","lastName":"qbouxqfSuoIwur
  02:33:51.034 [front-end] Posting Customer: {"username":"gKeAgMwCYLjti","password":"MBCdzhXeF","email":"gKeAgMwCYLjti@gmail.com","firstName":"gKeAgMwCYLjti","lastName":"gKeAgMwCYLjti"}
  02:33:54.456 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed92d94b9000069b3b01","customerId":"673fed7db0df5c00019afd3e","customer":{"id":null,"firstName":"FtxLPSEMJw"
  02:33:56.422 [front-end] Order response: {"id":"673fed94d94b9000069b3b04","customerId":"673fed7db0df5c00019afd3f","customer":{"id":null,"firstName":"RGmZXukDiZaHklv","lastName":"RGmZXuk
  02:33:59.941 [front-end] Posting Customer: {"username":"KubBfcoksN","password":"UZVnTs","email":"KubBfcoksN@gmail.com","firstName":"KubBfcoksN","lastName":"KubBfcoksN"}
  02:34:02.206 [front-end] Posting Customer: {"username":"ARfXRutv","password":"ujpSvFJcsy","email":"ARfXRutv@gmail.com","firstName":"ARfXRutv","lastName":"ARfXRutv"}

## p0243
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:03.189Z, and 26 identical event(s) in the same minute
```
{"timestamp":1732242483189214000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Request received with body: {}"}
```
Same service, the 2 minutes before (oldest first):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×2)
  02:28:03.053 [front-end] POST /addresses 200 - ms - -  (×2)
  02:28:03.059 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec2db0df5c00019af953"}  (×2)
  02:28:03.068 [front-end] POST /cards 200 - ms - -
  02:28:03.112 [front-end] Attempting to delete cart for user: 673fec2db0df5c00019af953
  02:28:03.122 [front-end] GET /catalogue 200 - ms - -
  02:28:03.174 [front-end] User cart deleted with status: 503
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -
  02:28:03.182 [front-end] Attempting to add to cart: {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","quantity":1}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×29)
  02:28:03.118 [catalogue] ts=2024-11-22T02:28:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.040202ms  (×32)
  02:28:03.194 [user] ts=2024-11-22T02:28:03.193809039Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=776.856µs  (×83)
  02:28:03.212 [user] ts=2024-11-22T02:28:03.211913045Z caller=middlewares.go:104 method=GetAddresses id=673fec28b0df5c00019af93a result=1 took=1.62825ms  (×15)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×3)
  02:28:03.410 [front-end] set cookie673fec33b0df5c00019af962  (×30)
  02:28:04.933 [user] ts=2024-11-22T02:28:04.933089482Z caller=middlewares.go:46 method=Register username=JGQXvUjPbFrtK email=JGQXvUjPbFrtK@gmail.com took=1.129271ms  (×10)
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:06.800 [user] ts=2024-11-22T02:28:06.800234478Z caller=middlewares.go:46 method=Register username=oyShDJ email=oyShDJ@gmail.com took=993.111µs
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.197 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×3)
  02:28:16.205 [front-end] Received response: "{\"firstName\":\"WiHheQzgSpJzgy\",\"lastName\":\"WiHheQzgSpJzgy\",\"username\":\"WiHheQzgSpJzgy\",\"id\":\"673fec2db0df5c00019af952\",\"_lin
  02:28:17.879 [user] ts=2024-11-22T02:28:17.879034554Z caller=middlewares.go:46 method=Register username=QGHrdp email=QGHrdp@gmail.com took=1.008054ms
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:21.971 [user] ts=2024-11-22T02:28:21.971606392Z caller=middlewares.go:46 method=Register username=PDQejFz email=PDQejFz@gmail.com took=1.195014ms
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=1.213µs  (×4)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.819 [front-end] Received response: "{\"firstName\":\"KoWsmDtUqsE\",\"lastName\":\"KoWsmDtUqsE\",\"username\":\"KoWsmDtUqsE\",\"id\":\"673fec2cb0df5c00019af949\",\"_links\":{\"a
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:25.786 [shipping] 2024-11-22 02:28:25.786 INFO [shipping,fb98be28dae5ea9a,b566bc7933720160,false] 7 --- [p-nio-80-exec-6] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.957 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","l
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFr
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:27.463 [orders-db] {"t":{"$date":"2024-11-22T02:28:27.462+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: java.lang.RuntimeException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock) at com.google.commo
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×12)

## p0464
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T08:08:37.078Z
```
{"timestamp":1732349317078988800,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T08:08:37.078789528Z caller=middlewares.go:75 method=GetUsers id=67418d70a437380001deee0b result=1 took=2.192993ms"}
```
Same service, the 2 minutes before (oldest first):
  08:08:34.934 [user] ts=2024-11-23T08:08:34.93451596Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418d7da437380001deee35 took=4.424254ms  (×3)
  08:08:34.951 [user] ts=2024-11-23T08:08:34.951120133Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67418d7da437380001deee35 took=4.428237ms  (×3)
  08:08:35.714 [user] ts=2024-11-23T08:08:35.714076655Z caller=middlewares.go:75 method=GetUsers id=67418d6da437380001deedfd result=1 took=3.155028ms  (×9)
  08:08:35.738 [user] ts=2024-11-23T08:08:35.738227714Z caller=middlewares.go:134 method=GetCards id=67418d76a437380001deee20 result=1 took=2.738244ms  (×2)
  08:08:35.738 [user] ts=2024-11-23T08:08:35.738240767Z caller=middlewares.go:104 method=GetAddresses id=67418d76a437380001deee1f result=1 took=2.145565ms  (×2)
  08:08:36.639 [user] ts=2024-11-23T08:08:36.639668477Z caller=middlewares.go:46 method=Register username=YVvTLelAHmgGd email=YVvTLelAHmgGd@gmail.com took=2.272137ms
All services, 30 seconds either side (sampled):
  08:08:07.085 [front-end] Attempting to delete cart for user: 67418d5ca437380001deedd5  (×64)
  08:08:07.852 [user] ts=2024-11-23T08:08:07.852122419Z caller=middlewares.go:157 method=Health result=2 took=4.835426ms  (×40)
  08:08:08.583 [user] ts=2024-11-23T08:08:08.582920911Z caller=middlewares.go:75 method=GetUsers id=67418d50a437380001deedb3 result=1 took=2.312599ms  (×251)
  08:08:08.622 [shipping] Adding shipment to queue...  (×53)
  08:08:09.383 [catalogue] ts=2024-11-23T08:08:09Z caller=logging.go:85 method=Health result=2 took=21.339µs  (×40)
  08:08:10.839 [user] ts=2024-11-23T08:08:10.838681435Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418d62a437380001deede0 took=5.159442ms  (×63)
  08:08:11.216 [carts] 2024-11-23 08:08:11.216 INFO [carts,68eb555f4ca3583f,0be99287cc7b09cf,false] 7 --- [-nio-80-exec-19] w.w.s.cart.controllers.ItemsController : Did not find item.  (×40)
  08:08:12.738 [front-end] Posting Customer: {"username":"bnDcvNpLex","password":"izlxMxXPmx","email":"bnDcvNpLex@gmail.com","firstName":"bnDcvNpLex","lastName":"bnDcvNpLex"}
  08:08:15.586 [front-end] Order response: {"id":"67418d6f3f77060008864e99","customerId":"67418d55a437380001deedc6","customer":{"id":null,"firstName":"sBltl","lastName":"sBltl","username"
  08:08:18.556 [front-end] Received response: "{\"firstName\":\"dfcBGnHCKo\",\"lastName\":\"dfcBGnHCKo\",\"username\":\"dfcBGnHCKo\",\"id\":\"67418d5fa437380001deedd7\",\"_links\":{\"addr
  08:08:23.111 [carts-db] {"t":{"$date":"2024-11-23T08:08:23.111+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173234930
  08:08:25.626 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d793f77060008864e9f","customerId":"67418d66a437380001deede6","customer":{"id":null,"firstName":"QvqEOSzLHru
  08:08:26.416 [front-end] Order response: {"id":"67418d7a3f77060008864ea1","customerId":"67418d69a437380001deedec","customer":{"id":null,"firstName":"CCDNavUFFLkbCuy","lastName":"CCDNavU
  08:08:27.826 [user] ts=2024-11-23T08:08:27.826713418Z caller=middlewares.go:46 method=Register username=JsZkpwTMC email=JsZkpwTMC@gmail.com took=2.114704ms
  08:08:29.827 [front-end] Order response: {"id":"67418d7d3f77060008864ea7","customerId":"67418d65a437380001deede5","customer":{"id":null,"firstName":"JXuYeaZNbme","lastName":"JXuYeaZNbme
  08:08:34.378 [front-end] Order response: {"id":"67418d823f77060008864ea9","customerId":"67418d6ca437380001deedf7","customer":{"id":null,"firstName":"dSmuN","lastName":"dSmuN","username"
  08:08:36.634 [front-end] Posting Customer: {"username":"YVvTLelAHmgGd","password":"gbFZh","email":"YVvTLelAHmgGd@gmail.com","firstName":"YVvTLelAHmgGd","lastName":"YVvTLelAHmgGd"}
  08:08:39.054 [front-end] Received response: "{\"firstName\":\"SPKkYqF\",\"lastName\":\"SPKkYqF\",\"username\":\"SPKkYqF\",\"id\":\"67418d71a437380001deee0f\",\"_links\":{\"addresses\":{
  08:08:40.768 [front-end] Order response: {"id":"67418d883f77060008864eb0","customerId":"67418d70a437380001deee0a","customer":{"id":null,"firstName":"VbDJrGoyFwn","lastName":"VbDJrGoyFwn
  08:08:42.349 [front-end] Posting Customer: {"username":"YIXWhPBdZWqnnVw","password":"gdiFJxtrh","email":"YIXWhPBdZWqnnVw@gmail.com","firstName":"YIXWhPBdZWqnnVw","lastName":"YIXWhPBdZWq
  08:08:46.359 [user] ts=2024-11-23T08:08:46.35938694Z caller=middlewares.go:46 method=Register username=xOptU email=xOptU@gmail.com took=2.528ms
  08:08:49.218 [front-end] Posting Customer: {"username":"EAZSSAQAHOt","password":"lLwUvLs","email":"EAZSSAQAHOt@gmail.com","firstName":"EAZSSAQAHOt","lastName":"EAZSSAQAHOt"}
  08:08:53.064 [front-end] Received response: "{\"firstName\":\"JsZkpwTMC\",\"lastName\":\"JsZkpwTMC\",\"username\":\"JsZkpwTMC\",\"id\":\"67418d7ba437380001deee2f\",\"_links\":{\"address
  08:08:57.026 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d993f77060008864ebb","customerId":"67418d82a437380001deee47","customer":{"id":null,"firstName":"WrpsfFOmjbe
  08:08:57.720 [front-end] Order response: {"id":"67418d993f77060008864ebd","customerId":"67418d86a437380001deee51","customer":{"id":null,"firstName":"PvGUf","lastName":"PvGUf","username"
  08:08:58.873 [front-end] Order response: {"id":"67418d9a3f77060008864ec0","customerId":"67418d86a437380001deee52","customer":{"id":null,"firstName":"PPcuOhJnkh","lastName":"PPcuOhJnkh",
  08:09:02.928 [front-end] Posting Customer: {"username":"duOsEgu","password":"TZGjR","email":"duOsEgu@gmail.com","firstName":"duOsEgu","lastName":"duOsEgu"}
  08:09:04.609 [front-end] Posting Customer: {"username":"OZypdwngfo","password":"qAcSdguMQp","email":"OZypdwngfo@gmail.com","firstName":"OZypdwngfo","lastName":"OZypdwngfo"}
  08:09:06.158 [front-end] Posting Customer: {"username":"oQylUZky","password":"lhZLkVYoRG","email":"oQylUZky@gmail.com","firstName":"oQylUZky","lastName":"oQylUZky"}

## p0287
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:34:21.134Z
```
{"timestamp":1732242861134449400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Order: {\"customer\":\"http://user/customers/673fed97b0df5c00019afd93\",\"address\":\"http://user/addresses/673fed9db0df5c00019afda3\",\"card\":\"http://user/cards/673fed9db0df5c00019afda4\",\"items\":\"http://carts/carts/673fed97b0df5c00019afd93/items\"}"}
```
Same service, the 2 minutes before (oldest first):
  02:34:20.852 [front-end] 673fedacb0df5c00019afdd0
  02:34:20.852 [front-end] Merging carts for customer id: 673fedacb0df5c00019afdd0 and session id: 5MFRQt0dGFAbll0r_htUwq3-fdBBEO-j
  02:34:20.873 [front-end] Carts merged.
  02:34:20.873 [front-end] set cookie673fedacb0df5c00019afdd0
  02:34:20.873 [front-end] Sent cookies.
  02:34:20.875 [front-end] POST /register 200 27.420 ms - 33
  02:34:20.879 [front-end] Attempting to delete cart for user: 673feda3b0df5c00019afdb1
  02:34:20.896 [front-end] User cart deleted with status: 202
  02:34:20.899 [front-end] DELETE /cart 202 - ms - -
  02:34:20.904 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}
  02:34:20.912 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
  02:34:20.912 [front-end] POST to carts: http://carts/carts/673feda3b0df5c00019afdb1/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}
  02:34:20.960 [front-end] POST /cart 201 - ms - -
  02:34:21.121 [front-end] Request received with body: {}
  02:34:21.128 [front-end] Received response: "{\"firstName\":\"KubBfcoksN\",\"lastName\":\"KubBfcoksN\",\"username\":\"KubBfcoksN\",\"id\":\"673fed97b0df5c00019afd93\",\"_links\":{\"addr
  02:34:21.128 [front-end] GET Request to: http://user/customers/673fed97b0df5c00019afd93/addresses  (×2)
  02:34:21.134 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:34:21.134 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fed9db0df5c00019afda4\",\"_links\":{\"
  02:34:21.134 [front-end] [ undefined, undefined ]
All services, 30 seconds either side (sampled):
  02:33:51.156 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fed85b0df5c00019afd5b"}  (×65)
  02:33:51.265 [front-end] POST to carts: http://carts/carts/673fed85b0df5c00019afd5b/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}  (×38)
  02:33:51.698 [front-end] Posting Order: {"customer":"http://user/customers/673fed77b0df5c00019afd2d","address":"http://user/addresses/673fed80b0df5c00019afd45","card":"http://user/cards  (×59)
  02:33:51.729 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed8fd94b9000069b3aff","customerId":"673fed77b0df5c00019afd2d","customer":{"id":null,"firstName":"QKjxTFJhRpp
  02:33:52.150 [user] ts=2024-11-22T02:33:52.150644723Z caller=middlewares.go:46 method=Register username=zChpPcvAuCjkHis email=zChpPcvAuCjkHis@gmail.com took=982.788µs  (×19)
  02:33:52.351 [catalogue] ts=2024-11-22T02:33:52Z caller=logging.go:85 method=Health result=2 took=24.599µs  (×40)
  02:33:54.431 [user] ts=2024-11-22T02:33:54.43135638Z caller=middlewares.go:75 method=GetUsers id=673fed7db0df5c00019afd3e result=1 took=1.087221ms  (×57)
  02:33:56.242 [queue-master] 2024-11-22 02:33:56.240 INFO 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×44)
  02:33:57.827 [front-end] Posting Customer: {"username":"HzDSw","password":"aOHOeLcUfL","email":"HzDSw@gmail.com","firstName":"HzDSw","lastName":"HzDSw"}
  02:33:59.941 [front-end] Posting Customer: {"username":"KubBfcoksN","password":"UZVnTs","email":"KubBfcoksN@gmail.com","firstName":"KubBfcoksN","lastName":"KubBfcoksN"}
  02:34:02.206 [front-end] Posting Customer: {"username":"ARfXRutv","password":"ujpSvFJcsy","email":"ARfXRutv@gmail.com","firstName":"ARfXRutv","lastName":"ARfXRutv"}
  02:34:04.983 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed9cd94b9000069b3b0c","customerId":"673fed85b0df5c00019afd5c","customer":{"id":null,"firstName":"HFlyxx","la
  02:34:07.115 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed9fd94b9000069b3b0f","customerId":"673fed8eb0df5c00019afd75","customer":{"id":null,"firstName":"NlbqBUAHbYo
  02:34:09.269 [front-end] Order response: {"id":"673feda1d94b9000069b3b12","customerId":"673fed8cb0df5c00019afd6a","customer":{"id":null,"firstName":"qbouxqfSuoIwurm","lastName":"qbouxqf
  02:34:14.336 [front-end] Received response: "{\"firstName\":\"zChpPcvAuCjkHis\",\"lastName\":\"zChpPcvAuCjkHis\",\"username\":\"zChpPcvAuCjkHis\",\"id\":\"673fed90b0df5c00019afd7d\",\"_
  02:34:16.974 [front-end] Posting Customer: {"username":"jtIeOQWzyjetgD","password":"AuBPVVJ","email":"jtIeOQWzyjetgD@gmail.com","firstName":"jtIeOQWzyjetgD","lastName":"jtIeOQWzyjetgD"}
  02:34:19.050 [front-end] Order response: {"statusCode":201,"body":{"id":"673fedabd94b9000069b3b18","customerId":"673fed95b0df5c00019afd8d","customer":{"id":null,"firstName":"HzDSw","las
  02:34:19.885 [front-end] Posting Customer: {"username":"FMACMHB","password":"TQjDvacm","email":"FMACMHB@gmail.com","firstName":"FMACMHB","lastName":"FMACMHB"}
  02:34:22.192 [front-end] Received response: "{\"firstName\":\"mHHzjq\",\"lastName\":\"mHHzjq\",\"username\":\"mHHzjq\",\"id\":\"673fed97b0df5c00019afd90\",\"_links\":{\"addresses\":{\"h
  02:34:24.219 [front-end] Posting Customer: {"username":"qVHYCkx","password":"uvZLZbGCgA","email":"qVHYCkx@gmail.com","firstName":"qVHYCkx","lastName":"qVHYCkx"}
  02:34:27.949 [front-end] Received response: "{\"firstName\":\"WYeuzqdoaYGr\",\"lastName\":\"WYeuzqdoaYGr\",\"username\":\"WYeuzqdoaYGr\",\"id\":\"673feda0b0df5c00019afdac\",\"_links\":{
  02:34:32.081 [front-end] Order response: {"statusCode":201,"body":{"id":"673fedb8d94b9000069b3b23","customerId":"673feda3b0df5c00019afdb1","customer":{"id":null,"firstName":"nsNtBCDgvtS
  02:34:34.001 [front-end] Posting Customer: {"username":"HKOlrOouRTEY","password":"QqkySzTAh","email":"HKOlrOouRTEY@gmail.com","firstName":"HKOlrOouRTEY","lastName":"HKOlrOouRTEY"}
  02:34:37.466 [front-end] Order response: {"statusCode":201,"body":{"id":"673fedbdd94b9000069b3b29","customerId":"673feda9b0df5c00019afdbf","customer":{"id":null,"firstName":"EzpEUge","l
  02:34:39.142 [front-end] Order response: {"id":"673fedbfd94b9000069b3b2c","customerId":"673feda8b0df5c00019afdbd","customer":{"id":null,"firstName":"bmjwCJ","lastName":"bmjwCJ","usernam
  02:34:40.601 [front-end] Order response: {"statusCode":201,"body":{"id":"673fedc0d94b9000069b3b30","customerId":"673fedacb0df5c00019afdcd","customer":{"id":null,"firstName":"DXJcDAQoagj
  02:34:42.020 [front-end] Posting Customer: {"username":"CcdpZzWdgXfyrD","password":"sQlxpCTieo","email":"CcdpZzWdgXfyrD@gmail.com","firstName":"CcdpZzWdgXfyrD","lastName":"CcdpZzWdgXfyr
  02:34:44.959 [front-end] Order response: {"id":"673fedc4d94b9000069b3b34","customerId":"673fedb0b0df5c00019afdde","customer":{"id":null,"firstName":"TuyCLmp","lastName":"TuyCLmp","usern
  02:34:47.639 [front-end] Order response: {"id":"673fedc7d94b9000069b3b36","customerId":"673fedb0b0df5c00019afddd","customer":{"id":null,"firstName":"qVHYCkx","lastName":"qVHYCkx","usern

## p0722
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-14T17:17:55.503Z
```
{"service":"dbservice1","message":"2021-08-14 17:17:55,503 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | f0c220b086162250 | 81e6ba8a-fce0-11eb-b570-0242ac110003-TpPSMOEF-P)x}eV<WmgRs token generate success token=MTYyODkzMjY3NS41MDM1MjA3OjgxZTZiYThhLWZjZTAtMTFlYi1iNTcwLTAyNDJhYzExMDAwM1RwUFNNT0VGUCl4fWVWPFdtZ1JzOjE2Mjg5MzI3MzUuNTAzNTMyMjpkODEzYzZiYjJlOGIzY2Q0NWQ4NTNkZmUzZDY0MjVlMw=="}
```
Same service, the 2 minutes before (oldest first):
  17:17:49.127 [dbservice1] INFO 7e219b5e-fce0-11eb-b45f-0242ac110003-ITinMyWu-yv/ef>@J!O?L token generate success token=MTYyODkzMjY2OS4xMjcyNjc6N2UyMTliNWUtZmNlMC0xMWViLWI0NWYtMDI0MmFjMTE
  17:17:50.268 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  17:17:50.268 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  17:17:50.325 [dbservice1] INFO query = select passwards from username_table where user_name='aCdZXfNn'  (×5)
  17:17:50.402 [dbservice1] INFO 7eddf862-fce0-11eb-8c8e-0242ac110003-aCdZXfNn-HVB*h$/mtRAv token generate success token=MTYyODkzMjY3MC40MDIxNzQyOjdlZGRmODYyLWZjZTAtMTFlYi04YzhlLTAyNDJhYzE
  17:17:50.736 [dbservice1] INFO 7f15776a-fce0-11eb-b26c-0242ac110004-CxaURntJ-FQ4_E#@RDnS. token generate success token=MTYyODkzMjY3MC43MzYxMDE6N2YxNTc3NmEtZmNlMC0xMWViLWIyNmMtMDI0MmFjMTE
  17:17:51.491 [dbservice1] INFO 7f918634-fce0-11eb-b3b5-0242ac110003-HNmhtWzM-u-}_4oB7AmID token generate success token=MTYyODkzMjY3MS40OTA4MDE6N2Y5MTg2MzQtZmNlMC0xMWViLWIzYjUtMDI0MmFjMTE
  17:17:53.822 [dbservice1] INFO 80f08700-fce0-11eb-bfc3-0242ac110003-PtzZjByh-wNej}mCt+)JY token generate success token=MTYyODkzMjY3My44MjE3NjY0OjgwZjA4NzAwLWZjZTAtMTFlYi1iZmMzLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  17:17:25.571 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×40)
  17:17:25.731 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×51)
  17:17:25.933 [logservice2] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '705ea8fe-fce0-11eb-bf4d-0242ac110004', 'user_id': 'ZPMYDESe'}  (×94)
  17:17:26.144 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '70ddfd02-fce0-11eb-b56d-0242ac110003', 'value': '', 'ex': 10}  (×52)
  17:17:26.621 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  17:17:26.700 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×43)
  17:17:26.862 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×56)
  17:17:27.348 [dbservice2] INFO query = select passwards from username_table where user_name='yHoAlkMd'  (×44)
  17:17:29.297 [dbservice2] INFO 724d0e3a-fce0-11eb-9075-0242ac110004-WzpeuShd-5!tKC3VBUbex token generate success token=MTYyODkzMjY0OS4yOTc0MjQzOjcyNGQwZTNhLWZjZTAtMTFlYi05MDc1LTAyNDJhYzE
  17:17:31.550 [mobservice1] INFO info 73d62476-fce0-11eb-b203-0242ac110004:UfMpdlBq write success
  17:17:34.508 [dbservice2] INFO 756ec838-fce0-11eb-9a99-0242ac110003-WHeAwPqY-:4l35ScB>fT1 token generate success token=MTYyODkzMjY1NC41MDc3NjcyOjc1NmVjODM4LWZjZTAtMTFlYi05YTk5LTAyNDJhYzE
  17:17:36.830 [dbservice2] INFO 76cf9aae-fce0-11eb-b3bd-0242ac110003-PJMibIFO-5U{+BxgJH$VY token generate success token=MTYyODkzMjY1Ni44Mjk5ODU0Ojc2Y2Y5YWFlLWZjZTAtMTFlYi1iM2JkLTAyNDJhYzE
  17:17:39.350 [dbservice1] INFO 784d1f5a-fce0-11eb-9afd-0242ac110004-HTNvoKmL-kb7d.AGJ+n32 token generate success token=MTYyODkzMjY1OS4zNTA1NjI4Ojc4NGQxZjVhLWZjZTAtMTFlYi05YWZkLTAyNDJhYzE
  17:17:41.790 [dbservice2] INFO 79b10f8c-fce0-11eb-836a-0242ac110004-eNWPvrgG-5p=qVbStYAN^ token generate success token=MTYyODkzMjY2MS43OTAxODE5Ojc5YjEwZjhjLWZjZTAtMTFlYi04MzZhLTAyNDJhYzE
  17:17:44.503 [mobservice1] INFO info 7b9b89d0-fce0-11eb-8239-0242ac110004:EQWxHTiy write success
  17:17:47.053 [mobservice1] INFO info 7d0b34a0-fce0-11eb-86fd-0242ac110004:sSHyNrVB write success
  17:17:50.005 [mobservice2] INFO info 7eddf862-fce0-11eb-8c8e-0242ac110003:aCdZXfNn write success
  17:17:52.658 [mobservice1] INFO info 8076a49e-fce0-11eb-b68f-0242ac110004:OxCTRwMa write success
  17:17:55.109 [mobservice2] INFO info 81e6ba8a-fce0-11eb-b570-0242ac110003:TpPSMOEF write success
  17:17:57.917 [dbservice2] INFO 83566050-fce0-11eb-a835-0242ac110003-GEFNbRmp-9e0!Zzhbd3WR token generate success token=MTYyODkzMjY3Ny45MTY2MTI2OjgzNTY2MDUwLWZjZTAtMTFlYi1hODM1LTAyNDJhYzE
  17:18:00.300 [dbservice1] INFO 84d336a6-fce0-11eb-a638-0242ac110003-suCOBkmp-=SHq@W8nJ7Me token generate success token=MTYyODkzMjY4MC4zMDAwMjgzOjg0ZDMzNmE2LWZjZTAtMTFlYi1hNjM4LTAyNDJhYzE
  17:18:03.026 [dbservice1] INFO 8646e4a6-fce0-11eb-a34b-0242ac110003-lYAOPtMm-rw)X>-}nmF+E token generate success token=MTYyODkzMjY4My4wMjU2OTc3Ojg2NDZlNGE2LWZjZTAtMTFlYi1hMzRiLTAyNDJhYzE
  17:18:05.937 [mobservice2] INFO info 885c7382-fce0-11eb-ab8b-0242ac110004:rEZWRTXD write success
  17:18:08.579 [mobservice2] INFO info 89f3dfbe-fce0-11eb-8c67-0242ac110003:BVmEhIvD write success
  17:18:10.975 [mobservice1] INFO info 8b5fce94-fce0-11eb-8a0d-0242ac110004:zLGEjrhw write success
  17:18:13.552 [mobservice1] INFO info 8ce15670-fce0-11eb-b759-0242ac110004:dIHpsMvT write success
  17:18:16.186 [mobservice1] INFO info 8e7dc3ce-fce0-11eb-b226-0242ac110003:aSkwezTX write success
  17:18:18.809 [dbservice2] INFO 8fc3c666-fce0-11eb-b611-0242ac110004-bHxAGyOk-FAxou7R(_OT- token generate success token=MTYyODkzMjY5OC43NzQ4OTAyOjhmYzNjNjY2LWZjZTAtMTFlYi1iNjExLTAyNDJhYzE
  17:18:21.304 [dbservice1] INFO 9147f034-fce0-11eb-9462-0242ac110004-cNyGSbzR-+7>ux(b)B80C token generate success token=MTYyODkzMjcwMS4zMDM2ODMzOjkxNDdmMDM0LWZjZTAtMTFlYi05NDYyLTAyNDJhYzE
  17:18:24.058 [mobservice1] INFO info 932d5aec-fce0-11eb-af10-0242ac110003:tLUwrBsD write success

## p0371
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:38:32.727Z
```
{"timestamp":1732246712727287800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST to carts: http://carts/carts/673ffcafb0df5c00019b2bb9/items body: {\"itemId\":\"03fef6ac-1896-4ce8-bd69-b798f85c6e0b\",\"unitPrice\":99.99}"}
```
Same service, the 2 minutes before (oldest first):
  03:38:31.996 [front-end] Received response: "{\"firstName\":\"rhxPYq\",\"lastName\":\"rhxPYq\",\"username\":\"rhxPYq\",\"id\":\"673ffca5b0df5c00019b2b98\",\"_links\":{\"addresses\":{\"h
  03:38:31.996 [front-end] GET Request to: http://user/customers/673ffca5b0df5c00019b2b98/addresses  (×2)
  03:38:32.003 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:38:32.003 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffcaab0df5c00019b2bab\",\"_links\":{\"
  03:38:32.003 [front-end] [ undefined, undefined ]
  03:38:32.003 [front-end] Posting Order: {"customer":"http://user/customers/673ffca5b0df5c00019b2b98","address":"http://user/addresses/673ffcaab0df5c00019b2baa","card":"http://user/cards
  03:38:32.037 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffcb8d94b9000069b46af","customerId":"673ffca5b0df5c00019b2b98","customer":{"id":null,"firstName":"rhxPYq","la
  03:38:32.037 [front-end] Order response: {"id":"673ffcb8d94b9000069b46af","customerId":"673ffca5b0df5c00019b2b98","customer":{"id":null,"firstName":"rhxPYq","lastName":"rhxPYq","usernam
  03:38:32.040 [front-end] POST /orders 201 - ms - -
  03:38:32.394 [front-end] GET /catalogue 200 - ms - -
  03:38:32.622 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffcafb0df5c00019b2bb9"}
  03:38:32.630 [front-end] POST /addresses 200 - ms - -
  03:38:32.637 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffcafb0df5c00019b2bb9"}
  03:38:32.645 [front-end] POST /cards 200 - ms - -
  03:38:32.691 [front-end] Attempting to delete cart for user: 673ffcafb0df5c00019b2bb9
  03:38:32.711 [front-end] User cart deleted with status: 202
  03:38:32.714 [front-end] DELETE /cart 202 - ms - -
  03:38:32.720 [front-end] Attempting to add to cart: {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","quantity":1}
  03:38:32.727 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
All services, 30 seconds either side (sampled):
  03:38:02.937 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffc93b0df5c00019b2b65"}  (×62)
  03:38:03.043 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×8)
  03:38:03.380 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffc8cb0df5c00019b2b56\",\"_links\":{\"  (×59)
  03:38:03.409 [shipping] Adding shipment to queue...  (×51)
  03:38:03.612 [front-end] Posting Customer: {"username":"DTFqNBDIZiPYFic","password":"yMXBqYHKJu","email":"DTFqNBDIZiPYFic@gmail.com","firstName":"DTFqNBDIZiPYFic","lastName":"DTFqNBDIZi
  03:38:03.988 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×8)
  03:38:06.641 [front-end] Posting Customer: {"username":"OJgnCtuobF","password":"llCAVRdcE","email":"OJgnCtuobF@gmail.com","firstName":"OJgnCtuobF","lastName":"OJgnCtuobF"}
  03:38:08.309 [front-end] Order response: {"timestamp":1732246688307,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×8)
  03:38:10.145 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffca2d94b9000069b469b","customerId":"673ffc90b0df5c00019b2b5d","customer":{"id":null,"firstName":"YkbhnZpVSCf
  03:38:14.052 [front-end] Posting Customer: {"username":"zMHzdKPvjiwJiCS","password":"sfyGVcDg","email":"zMHzdKPvjiwJiCS@gmail.com","firstName":"zMHzdKPvjiwJiCS","lastName":"zMHzdKPvjiwJ
  03:38:15.097 [front-end] Posting Customer: {"username":"XozAcwFdouKxUqo","password":"yaFloqUS","email":"XozAcwFdouKxUqo@gmail.com","firstName":"XozAcwFdouKxUqo","lastName":"XozAcwFdouKx
  03:38:16.151 [front-end] Order response: {"id":"673ffca8d94b9000069b46a2","customerId":"673ffc93b0df5c00019b2b65","customer":{"id":null,"firstName":"gAZObtnvyColDn","lastName":"gAZObtnv
  03:38:19.318 [front-end] Order response: {"id":"673ffcabd94b9000069b46a3","customerId":"673ffc98b0df5c00019b2b73","customer":{"id":null,"firstName":"jJjbWSJZKgj","lastName":"jJjbWSJZKgj
  03:38:22.660 [user] ts=2024-11-22T03:38:22.660705702Z caller=middlewares.go:46 method=Register username=CEvESMc email=CEvESMc@gmail.com took=944.22µs
  03:38:24.587 [front-end] Order response: {"id":"673ffcb0d94b9000069b46a7","customerId":"673ffc94b0df5c00019b2b66","customer":{"id":null,"firstName":"nroitNhvO","lastName":"nroitNhvO","u
  03:38:26.604 [front-end] Posting Customer: {"username":"vUBthXMaBTfZkT","password":"PeZrXKHFf","email":"vUBthXMaBTfZkT@gmail.com","firstName":"vUBthXMaBTfZkT","lastName":"vUBthXMaBTfZkT
  03:38:28.711 [orders-db] {"t":{"$date":"2024-11-22T03:38:28.711+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224670
  03:38:30.081 [front-end] Posting Customer: {"username":"faMoaEE","password":"YFfdoprDQJ","email":"faMoaEE@gmail.com","firstName":"faMoaEE","lastName":"faMoaEE"}
  03:38:35.129 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffcbbd94b9000069b46b0","customerId":"673ffca9b0df5c00019b2ba6","customer":{"id":null,"firstName":"XkjlRreAZzB
  03:38:37.680 [user] ts=2024-11-22T03:38:37.680263539Z caller=middlewares.go:46 method=Register username=wQWOub email=wQWOub@gmail.com took=1.005142ms
  03:38:38.858 [front-end] Received response: "{\"firstName\":\"CEvESMc\",\"lastName\":\"CEvESMc\",\"username\":\"CEvESMc\",\"id\":\"673ffcaeb0df5c00019b2bb2\",\"_links\":{\"addresses\":{
  03:38:41.376 [front-end] Order response: {"id":"673ffcc1d94b9000069b46b6","customerId":"673ffca9b0df5c00019b2ba4","customer":{"id":null,"firstName":"ZcHwBRmTpkjOyy","lastName":"ZcHwBRmT
  03:38:43.602 [front-end] Order response: {"id":"673ffcc3d94b9000069b46b9","customerId":"673ffcb4b0df5c00019b2bca","customer":{"id":null,"firstName":"wFBAOCxwq","lastName":"wFBAOCxwq","u
  03:38:45.732 [front-end] Posting Customer: {"username":"COljsmrGTdcvb","password":"VnjelWHVYD","email":"COljsmrGTdcvb@gmail.com","firstName":"COljsmrGTdcvb","lastName":"COljsmrGTdcvb"}
  03:38:48.930 [front-end] Posting Customer: {"username":"UpTtzGVHzP","password":"mXCAWlDnhb","email":"UpTtzGVHzP@gmail.com","firstName":"UpTtzGVHzP","lastName":"UpTtzGVHzP"}
  03:38:51.310 [front-end] Received response: "{\"firstName\":\"vjzcBsgVtlSlp\",\"lastName\":\"vjzcBsgVtlSlp\",\"username\":\"vjzcBsgVtlSlp\",\"id\":\"673ffcb5b0df5c00019b2bce\",\"_links\
  03:38:52.380 [front-end] Order response: {"id":"673ffcccd94b9000069b46c3","customerId":"673ffcbab0df5c00019b2bda","customer":{"id":null,"firstName":"zQnfal","lastName":"zQnfal","usernam
  03:38:54.753 [front-end] Posting Customer: {"username":"LgzIXcydGODQdyM","password":"whAAdDDU","email":"LgzIXcydGODQdyM@gmail.com","firstName":"LgzIXcydGODQdyM","lastName":"LgzIXcydGODQ
  03:38:58.465 [front-end] Posting Customer: {"username":"ocjfXAAQWYmCix","password":"kobWD","email":"ocjfXAAQWYmCix@gmail.com","firstName":"ocjfXAAQWYmCix","lastName":"ocjfXAAQWYmCix"}
  03:39:00.955 [front-end] Posting Customer: {"username":"uIStcnpVfzbWd","password":"fdqPanvd","email":"uIStcnpVfzbWd@gmail.com","firstName":"uIStcnpVfzbWd","lastName":"uIStcnpVfzbWd"}

## p0653
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-11T02:48:18.503Z
```
{"service":"mobservice1","message":"2021-08-11 02:48:18,503 | INFO | 0.0.0.1 | 172.17.0.5 | mobservice1 | 163547a6b75e05a3 | request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '870f9bb2-fa0b-11eb-b03c-0242ac110004'}"}
```
Same service, the 2 minutes before (oldest first):
  02:48:12.214 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '834ce66a-fa0b-11eb-9408-0242ac110003'}  (×4)
  02:48:12.276 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '834ce66a-fa0b-11eb-9408-0242ac110003', 'value': 'tdfCvYKb'}  (×4)
  02:48:12.349 [mobservice1] INFO info 834ce66a-fa0b-11eb-9408-0242ac110003:tdfCvYKb write success
  02:48:15.414 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  02:48:15.415 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  02:48:15.535 [mobservice1] INFO info 8537f85c-fa0b-11eb-9149-0242ac110004:HfckUWDQ write success
  02:48:17.117 [mobservice1] INFO info 86293140-fa0b-11eb-a879-0242ac110003:mgvTPLKy write success
  02:48:17.885 [mobservice1] INFO info 86a3748c-fa0b-11eb-ae60-0242ac110004:bTPjsUVJ write success
All services, 30 seconds either side (sampled):
  02:47:48.513 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  02:47:48.621 [redisservice1] INFO redis write success  (×91)
  02:47:48.718 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×44)
  02:47:48.791 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×45)
  02:47:48.905 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '75601716-fa0b-11eb-b0b3-0242ac110004', 'value': 'VaMiodsE'}  (×44)
  02:47:49.078 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '75abea06-fa0b-11eb-9975-0242ac110003', 'value': '', 'ex': 10}  (×45)
  02:47:49.261 [webservice1] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×45)
  02:47:49.587 [dbservice2] INFO query = select passwards from username_table where user_name='gWaJIfYM'  (×46)
  02:47:51.818 [mobservice1] INFO info 770ef550-fa0b-11eb-9a15-0242ac110004:LmHpecgO write success
  02:47:54.523 [dbservice1] INFO 7885cb70-fa0b-11eb-b9bb-0242ac110004-IREbBVhM-dHJS-+VlW)C? token generate success token=MTYyODYyMTI3NC41MjMwOTg1Ojc4ODVjYjcwLWZhMGItMTFlYi1iOWJiLTAyNDJhYzE
  02:47:56.809 [dbservice2] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c  (×2)
  02:47:58.929 [mobservice2] INFO info 7b5a8eee-fa0b-11eb-a1b4-0242ac110003:dNpfZrzW write success
  02:48:01.301 [mobservice2] INFO info 7cbfd58c-fa0b-11eb-90cb-0242ac110004:EJMXPwRO write success
  02:48:03.689 [mobservice2] INFO info 7e24485e-fa0b-11eb-aea8-0242ac110004:rxiVPwZL write success
  02:48:06.282 [dbservice2] INFO 7f85a544-fa0b-11eb-8e62-0242ac110003-YDlFxnqQ-iMP+NGt?ac=y token generate success token=MTYyODYyMTI4Ni4yODE2Nzg3OjdmODVhNTQ0LWZhMGItMTFlYi04ZTYyLTAyNDJhYzE
  02:48:08.720 [dbservice1] INFO 80fc7e2a-fa0b-11eb-86dc-0242ac110003-ucXDZIio-})1EO<#nT*!K token generate success token=MTYyODYyMTI4OC43MjAyODQ6ODBmYzdlMmEtZmEwYi0xMWViLTg2ZGMtMDI0MmFjMTE
  02:48:11.435 [mobservice2] INFO info 82c587e2-fa0b-11eb-baa3-0242ac110004:HBlmbePk write success
  02:48:13.899 [mobservice2] INFO info 8447afdc-fa0b-11eb-be77-0242ac110004:AayKrPBU write success
  02:48:16.298 [mobservice2] INFO info 85b61516-fa0b-11eb-8db5-0242ac110003:MXIwargu write success
  02:48:18.592 [mobservice1] INFO info 870f9bb2-fa0b-11eb-b03c-0242ac110004:UoOtrWnu write success
  02:48:20.882 [mobservice1] INFO info 886aaeac-fa0b-11eb-894f-0242ac110004:EufWiDjO write success
  02:48:23.240 [mobservice2] INFO info 89cbe720-fa0b-11eb-88d1-0242ac110003:vtpXmFKe write success
  02:48:26.146 [dbservice2] INFO 8b5ddecc-fa0b-11eb-b977-0242ac110003-McHWnbKA-<V&r%^nqCeZ* token generate success token=MTYyODYyMTMwNi4xNDYyNDAyOjhiNWRkZWNjLWZhMGItMTFlYi1iOTc3LTAyNDJhYzE
  02:48:28.776 [dbservice1] INFO 8ceeaf6e-fa0b-11eb-864d-0242ac110003-yeMqQbFt-RxWUf5S1}=a4 token generate success token=MTYyODYyMTMwOC43NzYxNzc0OjhjZWVhZjZlLWZhMGItMTFlYi04NjRkLTAyNDJhYzE
  02:48:32.661 [mobservice1] INFO info 8f6bbcc8-fa0b-11eb-82a9-0242ac110004:XUtTqLre write success
  02:48:39.914 [mobservice2] INFO info 93b79784-fa0b-11eb-906f-0242ac110004:xYHiSMPL write success
  02:48:42.781 [mobservice2] INFO info 9578a90a-fa0b-11eb-a029-0242ac110003:nlMAOLaH write success
  02:48:45.525 [dbservice1] INFO 96de6fbe-fa0b-11eb-8c70-0242ac110003-ocwNidgD-vr7adT}&{R=! token generate success token=MTYyODYyMTMyNS41MjUyNDA0Ojk2ZGU2ZmJlLWZhMGItMTFlYi04YzcwLTAyNDJhYzE
  02:48:47.903 [dbservice1] INFO 984fba7e-fa0b-11eb-8740-0242ac110004-gfWraMPC-=@%?+Z9iR0SY token generate success token=MTYyODYyMTMyNy45MDMzMjEzOjk4NGZiYTdlLWZhMGItMTFlYi04NzQwLTAyNDJhYzE

## p0392
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:26.418Z
```
{"timestamp":1732247186418455800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"set cookie673ffe92b0df5c00019b318d"}
```
Same service, the 2 minutes before (oldest first):
  03:46:26.044 [front-end] set cookie673ffe91b0df5c00019b318c
  03:46:26.045 [front-end] Sent cookies.
  03:46:26.048 [front-end] POST /register 200 56.931 ms - 33
  03:46:26.373 [front-end] Posting Customer: {"username":"HSRfpVFfwJppXn","password":"XmBVu","email":"HSRfpVFfwJppXn@gmail.com","firstName":"HSRfpVFfwJppXn","lastName":"HSRfpVFfwJppXn"}
  03:46:26.379 [front-end] { id: '673ffe92b0df5c00019b318d' }  (×2)
  03:46:26.379 [front-end] 673ffe92b0df5c00019b318d  (×2)
  03:46:26.379 [front-end] Merging carts for customer id: 673ffe92b0df5c00019b318d and session id: d0fyODfgmoMPZCz_fr2CxWlmdbrKeQQ1  (×2)
  03:46:26.396 [front-end] Request received with body: {}
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:26.404 [front-end] Received response: "{\"firstName\":\"VaPxY\",\"lastName\":\"VaPxY\",\"username\":\"VaPxY\",\"id\":\"673ffe84b0df5c00019b3164\",\"_links\":{\"addresses\":{\"href
  03:46:26.404 [front-end] GET Request to: http://user/customers/673ffe84b0df5c00019b3164/addresses  (×2)
  03:46:26.410 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:46:26.410 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe8ab0df5c00019b3179\",\"_links\":{\"
  03:46:26.410 [front-end] [ undefined, undefined ]
  03:46:26.410 [front-end] Posting Order: {"customer":"http://user/customers/673ffe84b0df5c00019b3164","address":"http://user/addresses/673ffe8ab0df5c00019b3177","card":"http://user/cards
  03:46:26.418 [front-end] Carts merged.
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×27)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×44)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×58)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×47)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×47)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×45)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×45)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×45)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h

## p0620
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T20:17:29.360Z
```
{"timestamp":1733602649360485400,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-w6jt4","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable\n\tat org.springframework.web.client.DefaultResponseErrorHandler.handleError(DefaultResponseErrorHandler.java:111) ~[spring-web-4.3.25.RELEASE.jar!/:4.3.25.RELEASE]\n\tat org.springframework.web.client.RestTemplate.handleResponse(RestTemplate.java:709) ~[spring-web-4.3.25.RELEASE.jar!/:4.3.25.RELEASE]\n\tat org.springframew…"}
```
Same service, the 2 minutes before (oldest first):
  20:17:12.613 [ts-travel-service] 2024-12-07 20:17:12.613 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×5)
  20:17:12.616 [ts-travel-service] 2024-12-07 20:17:12.616 ERROR 1 --- [io-12346-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×5)
  20:17:12.616 [ts-travel-service] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×5)
  20:17:27.206 [ts-travel-service] 2024-12-07 20:17:27.205 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb
  20:17:27.209 [ts-travel-service] 2024-12-07 20:17:27.209 ERROR 1 --- [o-12346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  20:17:29.319 [ts-travel-service] 2024-12-07 20:17:29.318 INFO 1 --- [io-12346-exec-8] travel.controller.TravelController : [Travel Service] Query TripResponse
  20:17:29.339 [ts-travel-service] 2024-12-07 20:17:29.339 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=nanjing)
  20:17:29.352 [ts-travel-service] 2024-12-07 20:17:29.352 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)
All services, 30 seconds either side (sampled):
  20:16:59.504 [ts-admin-basic-info-service] 2024-12-07 20:16:59.503 INFO 1 --- [io-18767-exec-6] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×16)
  20:17:02.465 [ts-auth-service] 2024-12-07 20:17:02.465 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×3)
  20:17:02.686 [ts-admin-travel-service] 2024-12-07 20:17:02.686 INFO 1 --- [io-16114-exec-1] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×16)
  20:17:02.716 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:02 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×17)
  20:17:04.888 [ts-auth-service] 2024-12-07 20:17:04.888 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×12)
  20:17:05.146 [ts-travel2-service] 2024-12-07 20:17:05.145 ERROR 1 --- [io-16346-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×9)
  20:17:18.199 [ts-travel2-service] 2024-12-07 20:17:18.199 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×2)
  20:17:24.657 [ts-route-service] 2024-12-07 20:17:24.657 INFO 1 --- [ main] route.RouteApplication : No active profile set, falling back to default profiles: default
  20:17:28.295 [ts-travel-mongo] {"t":{"$date":"2024-12-07T20:17:28.295+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360264
  20:17:29.339 [ts-travel-service] 2024-12-07 20:17:29.339 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=nanjing)
  20:17:31.156 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T20:17:31.156+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:31.663 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:17:31.663+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:36.133 [ts-order-service] 2024-12-07 20:17:36.132 INFO 1 --- [io-12031-exec-3] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-4cf1-
  20:17:36.448 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:36 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 200 31992 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) App
  20:17:37.568 [ts-route-service] 2024-12-07 20:17:37.568 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'objectPostProcessor' of type [org.springframework.security.config.an
  20:17:38.748 [ts-food-service] 2024-12-07 20:17:38.748 INFO 1 --- [io-18856-exec-5] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  20:17:38.802 [ts-food-service] org.springframework.web.client.HttpServerErrorException: 500 Internal Server Error at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Def
  20:17:42.177 [ts-route-service] 2024-12-07 20:17:42.176 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 16914 ms
  20:17:43.865 [ts-route-service] 2024-12-07 20:17:43.864 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricsFilter' to: [/*]  (×8)
  20:17:46.767 [ts-route-mongo] {"t":{"$date":"2024-12-07T20:17:46.767+00:00"},"s":"I", "c":"NETWORK", "id":51800, "ctx":"conn24","msg":"client metadata","attr":{"remote":"127.0.0.6:46279","cl
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{routeId}],methods=[DELETE]}" onto p
  20:17:51.172 [ts-route-service] 2024-12-07 20:17:51.171 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/configuration/ui]}" onto org.springframework.http.ResponseEntit
  20:17:52.758 [ts-route-service] 2024-12-07 20:17:52.758 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[application/vnd.sprin
  20:17:52.761 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  20:17:52.765 [ts-route-service] 2024-12-07 20:17:52.764 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  20:17:55.472 [ts-route-service] 2024-12-07 20:17:55.472 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.springframewo
  20:17:57.968 [ts-travel-service] 2024-12-07 20:17:57.968 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)

## p0786
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:43:31.439Z
```
{"timestamp":1732351411439847400,"container_name":"front-end","pod_name":"front-end-f77549869-fh46p","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"npm ERR! signal SIGTERM"}
```
Same service, the 2 minutes before (oldest first):
  08:43:30.781 [front-end] GET /catalogue 200 - ms - -
  08:43:31.431 [front-end] npm timing command:run-script Completed in 819270ms
  08:43:31.432 [front-end] npm timing command:start Completed in 819274ms
  08:43:31.432 [front-end] npm notice   (×2)
  08:43:31.432 [front-end] npm notice New major version of npm available! 8.19.4 -> 10.9.1
  08:43:31.432 [front-end] npm notice Changelog: <https://github.com/npm/cli/releases/tag/v10.9.1>
  08:43:31.432 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!
  08:43:31.434 [front-end] npm verb stack Error: command failed
  08:43:31.434 [front-end] npm verb stack at ChildProcess.<anonymous> (/usr/local/lib/node_modules/npm/node_modules/@npmcli/promise-spawn/lib/index.js:63:27)
  08:43:31.434 [front-end] npm verb stack at ChildProcess.emit (node:events:513:28)
  08:43:31.434 [front-end] npm verb stack at maybeClose (node:internal/child_process:1100:16)
  08:43:31.434 [front-end] npm verb stack at Process.ChildProcess._handle.onexit (node:internal/child_process:304:5)
  08:43:31.439 [front-end] npm verb pkgid microservices-demo-front-end@0.0.1
  08:43:31.439 [front-end] npm verb cwd /usr/src/app
  08:43:31.439 [front-end] npm verb Linux 5.10.227-219.884.amzn2.x86_64
  08:43:31.439 [front-end] npm verb node v16.20.2
  08:43:31.439 [front-end] npm verb npm v8.19.4
  08:43:31.439 [front-end] npm ERR! path /usr/src/app
  08:43:31.439 [front-end] npm ERR! command failed
All services, 30 seconds either side (sampled):
  08:43:01.574 [catalogue] ts=2024-11-23T08:43:01Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.120099ms  (×45)
  08:43:02.003 [user] ts=2024-11-23T08:43:02.003248176Z caller=middlewares.go:104 method=GetAddresses id=67419589a437380001defe29 result=1 took=2.452319ms  (×29)
  08:43:02.022 [front-end] Order response: {"statusCode":201,"body":{"id":"674195963f7706000886534b","customerId":"67419583a437380001defe16","customer":{"id":null,"firstName":"kOAxFHlONns
  08:43:02.535 [front-end] Sent cookies.  (×51)
  08:43:02.892 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}  (×55)
  08:43:03.630 [front-end] Posting Customer: {"username":"OsNYqfzZRaMW","password":"izyKK","email":"OsNYqfzZRaMW@gmail.com","firstName":"OsNYqfzZRaMW","lastName":"OsNYqfzZRaMW"}
  08:43:04.804 [front-end] Order response: {"id":"674195983f7706000886534c","customerId":"67419587a437380001defe24","customer":{"id":null,"firstName":"XcAQaDJCWNfQJ","lastName":"XcAQaDJCW
  08:43:07.065 [front-end] Order response: {"timestamp":1732351387063,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×4)
  08:43:08.747 [front-end] Posting Customer: {"username":"atjnaEuCr","password":"YeayP","email":"atjnaEuCr@gmail.com","firstName":"atjnaEuCr","lastName":"atjnaEuCr"}
  08:43:10.781 [front-end] Posting Customer: {"username":"RgzxpfsTAiQ","password":"MpdymG","email":"RgzxpfsTAiQ@gmail.com","firstName":"RgzxpfsTAiQ","lastName":"RgzxpfsTAiQ"}
  08:43:11.764 [front-end] Order response: {"id":"6741959f3f77060008865352","customerId":"6741958fa437380001defe3a","customer":{"id":null,"firstName":"tXOnd","lastName":"tXOnd","username"
  08:43:14.237 [front-end] npm timing config:load:cli Completed in 3ms  (×2)
  08:43:14.238 [front-end] npm timing npm:load:configload Completed in 103ms  (×2)
  08:43:14.246 [front-end] npm timing npm:load:logFile Completed in 7ms  (×2)
  08:43:14.578 [front-end] Received response: "{\"firstName\":\"BIRJKPIoxpSLPc\",\"lastName\":\"BIRJKPIoxpSLPc\",\"username\":\"BIRJKPIoxpSLPc\",\"id\":\"6741958ea437380001defe37\",\"_lin
  08:43:16.133 [front-end] Order response: {"id":"674195a43f77060008865355","customerId":"67419593a437380001defe44","customer":{"id":null,"firstName":"CfYLelSE","lastName":"CfYLelSE","use
  08:43:19.655 [front-end] Order response: {"id":"674195a73f77060008865357","customerId":"6741958ba437380001defe2d","customer":{"id":null,"firstName":"FuTpsQAV","lastName":"FuTpsQAV","use
  08:43:22.050 [front-end] Received response: "{\"firstName\":\"YyimhmvssZ\",\"lastName\":\"YyimhmvssZ\",\"username\":\"YyimhmvssZ\",\"id\":\"67419599a437380001defe5a\",\"_links\":{\"addr
  08:43:23.805 [front-end] Order response: {"id":"674195ab3f7706000886535c","customerId":"6741959aa437380001defe5d","customer":{"id":null,"firstName":"sQDhmFmoIZwIYDG","lastName":"sQDhmFm
  08:43:26.197 [front-end] Posting Customer: {"username":"flEFTXC","password":"etSAPItUy","email":"flEFTXC@gmail.com","firstName":"flEFTXC","lastName":"flEFTXC"}
  08:43:27.706 [front-end] Order response: {"statusCode":201,"body":{"id":"674195af3f77060008865361","customerId":"67419598a437380001defe55","customer":{"id":null,"firstName":"gOgYQtJy","
  08:43:30.102 [front-end] Order response: {"statusCode":201,"body":{"id":"674195b23f77060008865363","customerId":"6741959ca437380001defe64","customer":{"id":null,"firstName":"atjnaEuCr",
  08:43:31.434 [front-end] npm verb stack Error: command failed  (×2)
  08:43:31.439 [front-end] npm ERR! command failed  (×2)
  08:43:36.462 [front-end] Received response: "{\"firstName\":\"FBOLvYflPzcEwLv\",\"lastName\":\"FBOLvYflPzcEwLv\",\"username\":\"FBOLvYflPzcEwLv\",\"id\":\"674195a2a437380001defe79\",\"_
  08:43:40.775 [front-end] Received response: "{\"firstName\":\"xlkVGcv\",\"lastName\":\"xlkVGcv\",\"username\":\"xlkVGcv\",\"id\":\"674195a7a437380001defe84\",\"_links\":{\"addresses\":{
  08:43:45.655 [front-end] Posting Customer: {"username":"PHSmla","password":"chOsruk","email":"PHSmla@gmail.com","firstName":"PHSmla","lastName":"PHSmla"}
  08:43:48.791 [front-end] Received response: "{\"firstName\":\"BJjqqW\",\"lastName\":\"BJjqqW\",\"username\":\"BJjqqW\",\"id\":\"674195aea437380001defe9c\",\"_links\":{\"addresses\":{\"h
  08:43:57.303 [front-end] Received response: "{\"firstName\":\"bSIxNayRKIFiLC\",\"lastName\":\"bSIxNayRKIFiLC\",\"username\":\"bSIxNayRKIFiLC\",\"id\":\"674195bfa437380001defec0\",\"_lin

## p0765
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T19:14:25.888Z
```
{"timestamp":1732389265888742400,"container_name":"carts","pod_name":"carts-78d749cf8c-wdv6t","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-23 19:14:25.888  INFO [carts,,,] 7 --- [           main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped \"{[/error],produces=[text/html]}\" onto public org.springframework.web.servlet.ModelAndView org.springframework.boot.autoconfigure.web.BasicErrorController.errorHtml(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)"}
```
Same service, the 2 minutes before (oldest first):
  19:13:53.084 [carts] 2024-11-23 19:13:53.084 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:49}] t
  19:13:53.188 [carts] 2024-11-23 19:13:53.188 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  19:14:08.888 [carts] 2024-11-23 19:14:08.888 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  19:14:25.792 [carts] 2024-11-23 19:14:25.792 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  19:14:25.883 [carts] 2024-11-23 19:14:25.883 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[DE
  19:14:25.883 [carts] 2024-11-23 19:14:25.883 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[GET],produces=
  19:14:25.883 [carts] 2024-11-23 19:14:25.883 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  19:14:25.884 [carts] 2024-11-23 19:14:25.883 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  19:14:25.884 [carts] 2024-11-23 19:14:25.884 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  19:14:25.885 [carts] 2024-11-23 19:14:25.885 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}/merge],methods=[GET]}" onto publi
  19:14:25.885 [carts] 2024-11-23 19:14:25.885 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[GET],produces=[applicat
  19:14:25.885 [carts] 2024-11-23 19:14:25.885 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
All services, 30 seconds either side (sampled):
  19:13:55.978 [catalogue] ts=2024-11-23T19:13:55Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.098395ms  (×63)
  19:13:56.616 [front-end] POST /register 200 64.716 ms - 33  (×62)
  19:13:57.549 [user] ts=2024-11-23T19:13:57.5495338Z caller=middlewares.go:104 method=GetAddresses id=6742296748485600016b0de4 result=1 took=4.285279ms  (×59)
  19:13:57.743 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"6742296f48485600016b0e00"}  (×62)
  19:13:57.908 [front-end] POST /cart 500 27.963 ms - 64  (×61)
  19:13:59.414 [front-end] Received response: "{\"firstName\":\"DQjuFbhEgvAtgAn\",\"lastName\":\"DQjuFbhEgvAtgAn\",\"username\":\"DQjuFbhEgvAtgAn\",\"id\":\"6742296a48485600016b0def\",\"_
  19:14:02.809 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  19:14:04.884 [user] ts=2024-11-23T19:14:04.884307282Z caller=middlewares.go:46 method=Register username=oyLTUx email=oyLTUx@gmail.com took=13.709825ms
  19:14:07.283 [front-end] Posting Customer: {"username":"DtnphSirVimUP","password":"PfiwvFtUKq","email":"DtnphSirVimUP@gmail.com","firstName":"DtnphSirVimUP","lastName":"DtnphSirVimUP"}
  19:14:09.184 [front-end] Received response: "{\"firstName\":\"TccvZmbGlG\",\"lastName\":\"TccvZmbGlG\",\"username\":\"TccvZmbGlG\",\"id\":\"6742296548485600016b0de2\",\"_links\":{\"addr
  19:14:13.104 [user] ts=2024-11-23T19:14:13.104809943Z caller=middlewares.go:46 method=Register username=batsCY email=batsCY@gmail.com took=4.476463ms
  19:14:14.575 [user] ts=2024-11-23T19:14:14.574992423Z caller=middlewares.go:46 method=Register username=ZygJED email=ZygJED@gmail.com took=4.850015ms
  19:14:17.772 [front-end] Posting Customer: {"username":"PavHY","password":"SRMNvxlzg","email":"PavHY@gmail.com","firstName":"PavHY","lastName":"PavHY"}
  19:14:25.510 [front-end] Posting Customer: {"username":"WTOXMMLklZFhP","password":"BtRQwIVdn","email":"WTOXMMLklZFhP@gmail.com","firstName":"WTOXMMLklZFhP","lastName":"WTOXMMLklZFhP"}
  19:14:25.888 [carts] 2024-11-23 19:14:25.888 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  19:14:29.914 [front-end] Received response: "{\"firstName\":\"ZygJED\",\"lastName\":\"ZygJED\",\"username\":\"ZygJED\",\"id\":\"6742298648485600016b0e51\",\"_links\":{\"addresses\":{\"h
  19:14:32.388 [carts] 2024-11-23 19:14:32.388 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframewo  (×2)
  19:14:35.142 [front-end] Received response: "{\"firstName\":\"fuPttuhWMvQd\",\"lastName\":\"fuPttuhWMvQd\",\"username\":\"fuPttuhWMvQd\",\"id\":\"6742298148485600016b0e3e\",\"_links\":{
  19:14:38.175 [front-end] Posting Customer: {"username":"rHJlsKTOqtx","password":"wpOCJs","email":"rHJlsKTOqtx@gmail.com","firstName":"rHJlsKTOqtx","lastName":"rHJlsKTOqtx"}
  19:14:42.787 [carts] 2024-11-23 19:14:42.787 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+json
  19:14:42.887 [carts] 2024-11-23 19:14:42.887 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/hal+  (×2)
  19:14:42.985 [carts] 2024-11-23 19:14:42.985 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],produc
  19:14:43.680 [front-end] Posting Customer: {"username":"nBpvAHX","password":"upagInVre","email":"nBpvAHX@gmail.com","firstName":"nBpvAHX","lastName":"nBpvAHX"}
  19:14:45.788 [user] ts=2024-11-23T19:14:45.788047522Z caller=middlewares.go:46 method=Register username=npuuaMjck email=npuuaMjck@gmail.com took=5.514537ms
  19:14:46.386 [carts] 2024-11-23 19:14:46.386 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  19:14:46.483 [carts] 2024-11-23 19:14:46.483 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  19:14:48.817 [front-end] Received response: "{\"firstName\":\"WTOXMMLklZFhP\",\"lastName\":\"WTOXMMLklZFhP\",\"username\":\"WTOXMMLklZFhP\",\"id\":\"6742299148485600016b0e76\",\"_links\
  19:14:51.863 [user] ts=2024-11-23T19:14:51.863673918Z caller=middlewares.go:46 method=Register username=NUhot email=NUhot@gmail.com took=3.863653ms
  19:14:53.287 [carts] 2024-11-23 19:14:53.287 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as MB

## p0246
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:05.146Z
```
{"timestamp":1732242485146170000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /cart 500 72.021 ms - 64"}
```
Same service, the 2 minutes before (oldest first):
  02:28:05.022 [front-end] Carts merged.
  02:28:05.022 [front-end] set cookie673fec34b0df5c00019af967
  02:28:05.024 [front-end] Sent cookies.
  02:28:05.027 [front-end] POST /register 200 51.463 ms - 33
  02:28:05.027 [front-end] Request received with body: {}
  02:28:05.033 [front-end] Received response: "{\"firstName\":\"NWbwBHv\",\"lastName\":\"NWbwBHv\",\"username\":\"NWbwBHv\",\"id\":\"673fec1db0df5c00019af90f\",\"_links\":{\"addresses\":{
  02:28:05.033 [front-end] GET Request to: http://user/customers/673fec1db0df5c00019af90f/addresses  (×2)
  02:28:05.047 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:05.047 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec25b0df5c00019af930\",\"_links\":{\"
  02:28:05.047 [front-end] [ undefined, undefined ]
  02:28:05.047 [front-end] Posting Order: {"customer":"http://user/customers/673fec1db0df5c00019af90f","address":"http://user/addresses/673fec25b0df5c00019af92f","card":"http://user/cards
  02:28:05.062 [front-end] User cart deleted with status: 503
  02:28:05.065 [front-end] DELETE /cart 503 - ms - -
  02:28:05.071 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  02:28:05.078 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af952/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  02:28:05.097 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:05.097 [front-end] Order response: {"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:05.100 [front-end] POST /orders 500 - ms - -
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×32)
  02:28:03.118 [catalogue] ts=2024-11-22T02:28:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.040202ms  (×36)
  02:28:03.190 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af953/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×18)
  02:28:03.211 [user] ts=2024-11-22T02:28:03.211690554Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=1.207621ms  (×36)
  02:28:03.252 [front-end] POST /orders 500 - ms - -  (×30)
  02:28:03.410 [front-end] Carts merged.  (×31)
  02:28:04.929 [front-end] Posting Customer: {"username":"JGQXvUjPbFrtK","password":"HtglbTyNG","email":"JGQXvUjPbFrtK@gmail.com","firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPbFrtK"}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:06.800 [user] ts=2024-11-22T02:28:06.800234478Z caller=middlewares.go:46 method=Register username=oyShDJ email=oyShDJ@gmail.com took=993.111µs
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.197 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×4)
  02:28:16.205 [front-end] Received response: "{\"firstName\":\"WiHheQzgSpJzgy\",\"lastName\":\"WiHheQzgSpJzgy\",\"username\":\"WiHheQzgSpJzgy\",\"id\":\"673fec2db0df5c00019af952\",\"_lin
  02:28:17.879 [user] ts=2024-11-22T02:28:17.879034554Z caller=middlewares.go:46 method=Register username=QGHrdp email=QGHrdp@gmail.com took=1.008054ms
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:21.971 [user] ts=2024-11-22T02:28:21.971606392Z caller=middlewares.go:46 method=Register username=PDQejFz email=PDQejFz@gmail.com took=1.195014ms
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=1.213µs  (×4)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.819 [front-end] Received response: "{\"firstName\":\"KoWsmDtUqsE\",\"lastName\":\"KoWsmDtUqsE\",\"username\":\"KoWsmDtUqsE\",\"id\":\"673fec2cb0df5c00019af949\",\"_links\":{\"a
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:25.786 [shipping] 2024-11-22 02:28:25.786 INFO [shipping,fb98be28dae5ea9a,b566bc7933720160,false] 7 --- [p-nio-80-exec-6] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.957 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","l
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFr
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:27.463 [orders-db] {"t":{"$date":"2024-11-22T02:28:27.462+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: java.lang.RuntimeException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock) at com.google.commo
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×12)

## p0611
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T20:12:49.883Z
```
{"timestamp":1733602369883888400,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-w6jt4","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:12:49.883  INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl         : Query for Station id is: Response(status=1, msg=Success, data=shanghai)"}
```
Same service, the 2 minutes before (oldest first):
  20:12:46.512 [ts-travel-service] 2024-12-07 20:12:46.512 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr
  20:12:46.520 [ts-travel-service] 2024-12-07 20:12:46.520 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1237
  20:12:46.523 [ts-travel-service] 2024-12-07 20:12:46.523 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：084837bb-53c8-4438-87c8-0321a  (×2)
  20:12:46.530 [ts-travel-service] 2024-12-07 20:12:46.530 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  20:12:46.530 [ts-travel-service] 2024-12-07 20:12:46.530 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  20:12:46.563 [ts-travel-service] 2024-12-07 20:12:46.563 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter
  20:12:46.569 [ts-travel-service] 2024-12-07 20:12:46.569 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Sat May 04 00:00:00 GMT 2013  (×2)
  20:12:46.569 [ts-travel-service] 2024-12-07 20:12:46.569 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d
  20:12:46.575 [ts-travel-service] 2024-12-07 20:12:46.575 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  20:12:46.575 [ts-travel-service] 2024-12-07 20:12:46.575 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha
  20:12:49.738 [ts-travel-service] 2024-12-07 20:12:49.738 INFO 1 --- [io-12346-exec-1] travel.controller.TravelController : [Travel Service] Query TripResponse
  20:12:49.754 [ts-travel-service] 2024-12-07 20:12:49.753 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=nanjing)  (×2)
  20:12:49.766 [ts-travel-service] 2024-12-07 20:12:49.766 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)
  20:12:49.776 [ts-travel-service] 2024-12-07 20:12:49.776 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  20:12:49.776 [ts-travel-service] 2024-12-07 20:12:49.776 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan
  20:12:49.846 [ts-travel-service] 2024-12-07 20:12:49.845 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s
  20:12:49.853 [ts-travel-service] 2024-12-07 20:12:49.853 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat
All services, 30 seconds either side (sampled):
  20:12:20.859 [ts-admin-basic-info-service] 2024-12-07 20:12:20.859 INFO 1 --- [io-18767-exec-4] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×8)
  20:12:23.306 [ts-basic-service] 2024-12-07 20:12:23.306 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×90)
  20:12:23.360 [ts-price-service] 2024-12-07 20:12:23.360 INFO 1 --- [io-16579-exec-3] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: 0b23bd3e-876a-4af3-b92  (×29)
  20:12:23.386 [ts-order-other-service] 2024-12-07 20:12:23.386 INFO 1 --- [io-12032-exec-5] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 52  (×16)
  20:12:23.466 [ts-order-other-service] 2024-12-07 20:12:23.465 INFO 1 --- [io-12032-exec-6] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×26)
  20:12:23.606 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:12:23 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 356 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×16)
  20:12:25.637 [ts-travel-service] 2024-12-07 20:12:25.636 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×4)
  20:12:26.649 [ts-travel-service] 2024-12-07 20:12:26.648 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×16)
  20:12:26.696 [ts-basic-service] 2024-12-07 20:12:26.696 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×39)
  20:12:26.750 [ts-order-service] 2024-12-07 20:12:26.749 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×16)
  20:12:26.923 [ts-travel-service] 2024-12-07 20:12:26.923 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×6)
  20:12:27.843 [ts-travel2-service] 2024-12-07 20:12:27.842 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×28)
  20:12:28.253 [ts-travel-mongo] {"t":{"$date":"2024-12-07T20:12:28.253+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360234
  20:12:28.759 [ts-seat-service] 2024-12-07 20:12:28.759 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×5)
  20:12:31.152 [ts-consign-mongo] {"t":{"$date":"2024-12-07T20:12:31.152+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360235
  20:12:31.976 [ts-basic-service] 2024-12-07 20:12:31.976 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270
  20:12:32.213 [ts-basic-service] 2024-12-07 20:12:32.213 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×8)
  20:12:35.716 [ts-food-service] 2024-12-07 20:12:35.715 INFO 1 --- [io-18856-exec-9] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×4)
  20:12:40.663 [ts-food-service] 2024-12-07 20:12:40.662 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:12:42.852 [ts-seat-service] 2024-12-07 20:12:42.852 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345
  20:12:43.013 [ts-contacts-service] 2024-12-07 20:12:43.013 INFO 1 --- [io-12347-exec-5] contacts.service.ContactsServiceImpl : [Contacts-Query-Service][Query-Contacts] Result Size: 2
  20:12:43.049 [ts-security-service] 2024-12-07 20:12:43.049 INFO 1 --- [io-11188-exec-9] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Getting....
  20:12:43.079 [ts-contacts-service] 2024-12-07 20:12:43.079 INFO 1 --- [io-12347-exec-6] contacts.controller.ContactsController : [ContactsService][VerifyLogin] Success.
  20:12:43.159 [ts-basic-service] 2024-12-07 20:12:43.159 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4
  20:12:43.587 [ts-seat-service] 2024-12-07 20:12:43.587 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService distributeSeat] TrainNumber start with G|D
  20:12:43.638 [ts-order-service] 2024-12-07 20:12:43.638 INFO 1 --- [io-12031-exec-8] order.service.OrderServiceImpl : [Order Service][Create Order] Ready Create Order.
  20:12:43.667 [ts-preserve-service] 2024-12-07 20:12:43.666 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service][Step 7] Do not need to consign
  20:12:45.674 [ts-order-other-service] 2024-12-07 20:12:45.674 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Get Order By Id] Order Id: a9341af4-10f4-4bc5  (×2)
  20:12:46.206 [ts-seat-service] 2024-12-07 20:12:46.206 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da
  20:13:13.674 [ts-order-service] 2024-12-07 20:13:13.674 INFO 1 --- [io-12031-exec-5] order.controller.OrderController : [Order Other Service][Get Order By Id] Order Id: 811def46-1ca0-4971-91cf

## p0030
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T07:51:29.589Z
```
{"service":"dbservice2","message":"2021-08-13 07:51:29,589 | ERROR | 0.0.0.2 | dbservice2 | db_helper.py -> sql_ano_prob -> 93 | b245b3e3290bafa0 | (pymysql.err.OperationalError) (1054, \"Unknown column 'system_data_time' in 'field list'\")[SQL: select service_name, system_data_time, system_cpu_utilization, system_memory_usage,system_disk_usage, disk_io_read_count, disk_io_write_count,system_network, network_io_read_count, network_io…"}
```
Same service, the 2 minutes before (oldest first):
  07:51:23.566 [dbservice2] INFO query = select passwards from username_table where user_name='cvwxUkHZ'  (×5)
  07:51:23.643 [dbservice2] INFO 32d9b302-fbc8-11eb-a8f4-0242ac110004-cvwxUkHZ-GQ=maK<n.t:_ token generate success token=MTYyODgxMjI4My42NDI5NzUzOjMyZDliMzAyLWZiYzgtMTFlYi1hOGY0LTAyNDJhYzE
  07:51:25.211 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  07:51:25.212 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  07:51:25.347 [dbservice2] INFO 33c052c6-fbc8-11eb-80a2-0242ac110003-VMivmOPL-_z$IfwVSs+#T token generate success token=MTYyODgxMjI4NS4zNDY1MjMzOjMzYzA1MmM2LWZiYzgtMTFlYi04MGEyLTAyNDJhYzE
  07:51:25.465 [dbservice2] INFO 33cb9a64-fbc8-11eb-8466-0242ac110003-OzKQAVJF-y0PH2h:lM}5T token generate success token=MTYyODgxMjI4NS40NjQ0NjU6MzNjYjlhNjQtZmJjOC0xMWViLTg0NjYtMDI0MmFjMTE
  07:51:27.042 [dbservice2] INFO 34d13d1a-fbc8-11eb-862c-0242ac110004-GmfKwAOM-)X4PM9QtBES/ token generate success token=MTYyODgxMjI4Ny4wNDIwNzk6MzRkMTNkMWEtZmJjOC0xMWViLTg2MmMtMDI0MmFjMTE
  07:51:28.200 [dbservice2] INFO 358fd48c-fbc8-11eb-92e0-0242ac110004-pdAkGNZq-7sD/*Q(>%?OT token generate success token=MTYyODgxMjI4OC4xOTk1OTk1OjM1OGZkNDhjLWZiYzgtMTFlYi05MmUwLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  07:50:59.604 [redisservice2] INFO redis读取信息成功, status_code: 200  (×37)
  07:50:59.637 [dbservice2] INFO query = select passwards from username_table where user_name='mIgaboME'  (×29)
  07:50:59.968 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×35)
  07:51:00.129 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×35)
  07:51:00.357 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  07:51:01.023 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×32)
  07:51:01.876 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×35)
  07:51:02.050 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×35)
  07:51:02.495 [redisservice1] INFO redis读取信息成功, status_code: 200  (×32)
  07:51:03.303 [mobservice1] INFO info 26d49b26-fbc8-11eb-80ca-0242ac110004:npqwesLI write success
  07:51:05.621 [dbservice2] INFO 280f042c-fbc8-11eb-bf4d-0242ac110004-ZRAoufan-@?BJFA*^Cha_ token generate success token=MTYyODgxMjI2NS42MjA2NjQ6MjgwZjA0MmMtZmJjOC0xMWViLWJmNGQtMDI0MmFjMTE
  07:51:08.153 [mobservice1] INFO info 29bedaae-fbc8-11eb-99a3-0242ac110003:hUmNCczf write success
  07:51:10.558 [dbservice2] INFO 2b07437e-fbc8-11eb-8124-0242ac110004-iAefFjPB-pr!%)P}hszWy token generate success token=MTYyODgxMjI3MC41NTc1MzUyOjJiMDc0MzdlLWZiYzgtMTFlYi04MTI0LTAyNDJhYzE
  07:51:19.336 [mobservice1] INFO info 3072d436-fbc8-11eb-b3fb-0242ac110003:zLGEjrhw write success
  07:51:22.188 [webservice2] ERROR an error occurred in the downstream service  (×3)
  07:51:24.406 [dbservice1] INFO 334d6f86-fbc8-11eb-b215-0242ac110003-VsFjlvRZ-5_Pi.<x+C=0T token generate success token=MTYyODgxMjI4NC40MDYwNTYyOjMzNGQ2Zjg2LWZiYzgtMTFlYi1iMjE1LTAyNDJhYzE
  07:51:26.702 [mobservice2] INFO info 34d13d1a-fbc8-11eb-862c-0242ac110004:GmfKwAOM write success
  07:51:28.774 [dbservice1] INFO 35d9cc9a-fbc8-11eb-b347-0242ac110004-UOwaWosV-_2b:uq<KZh0F token generate success token=MTYyODgxMjI4OC43NzM4NjQ3OjM1ZDljYzlhLWZiYzgtMTFlYi1iMzQ3LTAyNDJhYzE
  07:51:31.108 [dbservice2] INFO 37449f9c-fbc8-11eb-9644-0242ac110004-CFlfasov-eI{xh-iNd}j& token generate success token=MTYyODgxMjI5MS4xMDgwMDY1OjM3NDQ5ZjljLWZiYzgtMTFlYi05NjQ0LTAyNDJhYzE
  07:51:33.731 [dbservice2] INFO 38c1f680-fbc8-11eb-9bb1-0242ac110003-iOlErWzF-X$zLG%<H6fR9 token generate success token=MTYyODgxMjI5My43MzEyNDE1OjM4YzFmNjgwLWZiYzgtMTFlYi05YmIxLTAyNDJhYzE
  07:51:36.203 [dbservice1] INFO 3a459084-fbc8-11eb-bd86-0242ac110003-QYryCKLk-@51x7Dd$-e=8 token generate success token=MTYyODgxMjI5Ni4yMDM0NTg1OjNhNDU5MDg0LWZiYzgtMTFlYi1iZDg2LTAyNDJhYzE
  07:51:38.472 [mobservice2] INFO info 3bd09296-fbc8-11eb-a01f-0242ac110004:dtzesiga write success
  07:51:40.701 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  07:51:47.796 [mobservice1] INFO info 416a2ad2-fbc8-11eb-bc48-0242ac110003:mVtTqAor write success
  07:51:51.152 [dbservice2] INFO 4341207c-fbc8-11eb-8c58-0242ac110004-wzQhcEjW-&q(Z_ECc)a<V token generate success token=MTYyODgxMjMxMS4xNTIwMzc5OjQzNDEyMDdjLWZiYzgtMTFlYi04YzU4LTAyNDJhYzE
  07:51:53.400 [mobservice2] INFO info 44c3e830-fbc8-11eb-ade3-0242ac110003:JtGfaIFA write success
  07:51:55.666 [dbservice1] INFO 45ea5fd2-fbc8-11eb-a077-0242ac110004-VvLhTogZ-c=V#H@AY&IQ4 token generate success token=MTYyODgxMjMxNS42NjYzNzU5OjQ1ZWE1ZmQyLWZiYzgtMTFlYi1hMDc3LTAyNDJhYzE
  07:51:57.719 [mobservice2] INFO info 47575168-fbc8-11eb-9ca4-0242ac110004:pvNdAbhE write success

## p0597
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T20:03:10.322Z
```
{"timestamp":1733601790322782500,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-f7tv2","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 20:03:10.322  INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl       : Ticket info  is: Response(status=1, msg=Success, data=TravelResult(status=true, percent=1.0, trainType=TrainType(id=ZhiDa, economyClass=2147483647, confortClass=2147483647, averageSpeed=120), prices={confortClass=350.0, economyClass=112.0}))"}
```
Same service, the 2 minutes before (oldest first):
  20:03:09.848 [ts-travel2-service] 2024-12-07 20:03:09.847 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024, 
  20:03:09.859 [ts-travel2-service] 2024-12-07 20:03:09.858 INFO 1 --- [io-16346-exec-6] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236
  20:03:09.861 [ts-travel2-service] 2024-12-07 20:03:09.861 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×6)
  20:03:09.869 [ts-travel2-service] 2024-12-07 20:03:09.868 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×6)
  20:03:09.869 [ts-travel2-service] 2024-12-07 20:03:09.869 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  20:03:09.968 [ts-travel2-service] 2024-12-07 20:03:09.967 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int
  20:03:09.968 [ts-travel2-service] 2024-12-07 20:03:09.967 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6
  20:03:09.975 [ts-travel2-service] 2024-12-07 20:03:09.974 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×2)
  20:03:10.187 [ts-travel2-service] 2024-12-07 20:03:10.187 INFO 1 --- [io-16346-exec-9] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
All services, 30 seconds either side (sampled):
  20:02:41.219 [ts-admin-basic-info-service] 2024-12-07 20:02:41.219 INFO 1 --- [io-18767-exec-2] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×8)
  20:02:42.313 [ts-basic-service] 2024-12-07 20:02:42.313 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×100)
  20:02:42.399 [ts-basic-service] 2024-12-07 20:02:42.399 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×26)
  20:02:42.444 [ts-order-other-service] 2024-12-07 20:02:42.444 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 48  (×15)
  20:02:42.562 [ts-order-other-service] 2024-12-07 20:02:42.562 INFO 1 --- [io-12032-exec-8] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×18)
  20:02:42.915 [ts-travel2-service] 2024-12-07 20:02:42.915 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×26)
  20:02:47.213 [ts-travel-service] 2024-12-07 20:02:47.213 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×17)
  20:02:48.459 [ts-travel-service] 2024-12-07 20:02:48.459 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Travel Service] Query TripResponse  (×5)
  20:02:48.614 [ts-order-service] 2024-12-07 20:02:48.614 INFO 1 --- [io-12031-exec-2] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×12)
  20:02:48.927 [ts-travel-service] 2024-12-07 20:02:48.927 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×18)
  20:02:49.589 [ts-basic-service] 2024-12-07 20:02:49.589 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieT  (×2)
  20:02:53.516 [ts-basic-service] 2024-12-07 20:02:53.516 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×6)
  20:02:53.930 [ts-food-service] 2024-12-07 20:02:53.930 INFO 1 --- [io-18856-exec-7] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×3)
  20:03:00.264 [ts-basic-service] 2024-12-07 20:03:00.264 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×2)
  20:03:00.530 [ts-travel2-service] 2024-12-07 20:03:00.530 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×3)
  20:03:06.982 [ts-travel-service] 2024-12-07 20:03:06.982 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×3)
  20:03:11.517 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:03:11 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 200 119 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
  20:03:12.091 [ts-preserve-service] 2024-12-07 20:03:12.091 INFO 1 --- [io-14568-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization completed in 102 m
  20:03:13.925 [ts-security-service] 2024-12-07 20:03:13.925 INFO 1 --- [io-11188-exec-3] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Getting....
  20:03:14.104 [ts-contacts-service] 2024-12-07 20:03:14.104 INFO 1 --- [io-12347-exec-7] contacts.controller.ContactsController : [ContactsService][VerifyLogin] Success.
  20:03:15.369 [ts-order-service] 2024-12-07 20:03:15.369 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160, 
  20:03:15.623 [ts-seat-service] 2024-12-07 20:03:15.622 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService distributeSeat 1] The result of getTrainTypeResult is Response(
  20:03:15.757 [ts-preserve-service] 2024-12-07 20:03:15.757 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 4] Do Order Complete
  20:03:16.479 [ts-food-service] 2024-12-07 20:03:16.479 INFO 1 --- [io-18856-exec-3] foodsearch.service.FoodServiceImpl : [Food-Service][AddFoodOrder] Success.
  20:03:18.429 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:03:18 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 200 28285 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) App
  20:03:22.635 [ts-admin-basic-info-service] 2024-12-07 20:03:22.635 INFO 1 --- [o-18767-exec-10] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult] 
  20:03:30.785 [ts-auth-mongo] {"t":{"$date":"2024-12-07T20:03:30.784+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360181
  20:03:31.680 [ts-user-mongo] {"t":{"$date":"2024-12-07T20:03:31.680+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360181

## p0516
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T10:42:19.953Z
```
{"timestamp":1732358539953847600,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T10:42:19.95376244Z caller=middlewares.go:46 method=Register username=RIAVrKz email=RIAVrKz@gmail.com took=2.264977ms"}
```
Same service, the 2 minutes before (oldest first):
  10:42:17.758 [user] ts=2024-11-23T10:42:17.758772061Z caller=middlewares.go:75 method=GetUsers id=6741b174a437380001df4b5d result=1 took=1.938249ms  (×6)
  10:42:17.784 [user] ts=2024-11-23T10:42:17.784205244Z caller=middlewares.go:134 method=GetCards id=6741b17aa437380001df4b6c result=1 took=9.406779ms  (×2)
  10:42:17.784 [user] ts=2024-11-23T10:42:17.784458315Z caller=middlewares.go:104 method=GetAddresses id=6741b17aa437380001df4b6b result=1 took=7.449009ms  (×2)
  10:42:19.022 [user] ts=2024-11-23T10:42:19.022533609Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=6741b184a437380001df4b84 took=4.548918ms  (×3)
  10:42:19.041 [user] ts=2024-11-23T10:42:19.040671225Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6741b184a437380001df4b84 took=5.37863ms  (×3)
  10:42:19.792 [user] ts=2024-11-23T10:42:19.792634707Z caller=middlewares.go:46 method=Register username=mOsUajmTCOuD email=mOsUajmTCOuD@gmail.com took=2.442598ms
  10:42:19.849 [user] ts=2024-11-23T10:42:19.849302955Z caller=middlewares.go:157 method=Health result=2 took=2.073133ms  (×2)
  10:42:19.943 [user] ts=2024-11-23T10:42:19.943121505Z caller=middlewares.go:46 method=Register username=SlOUiiS email=SlOUiiS@gmail.com took=2.643677ms
All services, 30 seconds either side (sampled):
  10:41:49.961 [catalogue] ts=2024-11-23T10:41:49Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.160667ms  (×57)
  10:41:50.066 [session-db] 50:C 23 Nov 2024 10:41:50.066 * Fork CoW for RDB: current 0 MB, peak 0 MB, average 0 MB
  10:41:50.197 [front-end] Request received with body: {}  (×57)
  10:41:50.244 [orders] 2024-11-23 10:41:50.244 INFO [orders,e18e708728efb8b9,d8f87c65d6ace17e,false] 7 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Sending payment req  (×42)
  10:41:50.268 [front-end] POST /orders 201 - ms - -  (×57)
  10:41:50.978 [front-end] Order response: {"id":"6741b16e01dd390007094deb","customerId":"6741b154a437380001df4af2","customer":{"id":null,"firstName":"MICYQy","lastName":"MICYQy","usernam
  10:41:51.225 [front-end] Order response: {"id":"6741b16f01dd390007094ded","customerId":"6741b161a437380001df4b19","customer":{"id":null,"firstName":"KPLVPuSnOQeNvh","lastName":"KPLVPuSn
  10:41:52.247 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b17001dd390007094dee","customerId":"6741b160a437380001df4b18","customer":{"id":null,"firstName":"YszLU","las
  10:41:54.852 [front-end] Received response: "{\"firstName\":\"lTyDxVi\",\"lastName\":\"lTyDxVi\",\"username\":\"lTyDxVi\",\"id\":\"6741b15fa437380001df4b14\",\"_links\":{\"addresses\":{
  10:41:55.759 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×11)
  10:41:57.157 [front-end] Order response: {"id":"6741b17501dd390007094df4","customerId":"6741b15ca437380001df4b07","customer":{"id":null,"firstName":"VkjiwmTiXIs","lastName":"VkjiwmTiXIs
  10:42:00.355 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b17801dd390007094df6","customerId":"6741b165a437380001df4b2c","customer":{"id":null,"firstName":"VHERO","las
  10:42:02.282 [front-end] Order response: {"id":"6741b17a01dd390007094df8","customerId":"6741b163a437380001df4b1e","customer":{"id":null,"firstName":"AsWOJvoKNL","lastName":"AsWOJvoKNL",
  10:42:05.001 [front-end] Received response: "{\"firstName\":\"sjfrIBFtnOMwhK\",\"lastName\":\"sjfrIBFtnOMwhK\",\"username\":\"sjfrIBFtnOMwhK\",\"id\":\"6741b16aa437380001df4b3a\",\"_lin
  10:42:06.357 [front-end] Posting Customer: {"username":"DjEHXcoqHgWxYbC","password":"dYGzfOac","email":"DjEHXcoqHgWxYbC@gmail.com","firstName":"DjEHXcoqHgWxYbC","lastName":"DjEHXcoqHgWx
  10:42:08.984 [payment] ts=2024-11-23T10:42:08Z caller=logging.go:29 method=Authorise result=false took=7.002µs  (×4)
  10:42:13.530 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b18501dd390007094e02","customerId":"6741b16fa437380001df4b4a","customer":{"id":null,"firstName":"DSAgaYnbcBN
  10:42:17.181 [front-end] Received response: "{\"firstName\":\"BBoDQLZVQIzI\",\"lastName\":\"BBoDQLZVQIzI\",\"username\":\"BBoDQLZVQIzI\",\"id\":\"6741b176a437380001df4b64\",\"_links\":{
  10:42:18.245 [front-end] Order response: {"id":"6741b18a01dd390007094e08","customerId":"6741b175a437380001df4b60","customer":{"id":null,"firstName":"vqiGwzuJlekI","lastName":"vqiGwzuJle
  10:42:24.050 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19001dd390007094e0a","customerId":"6741b17ba437380001df4b72","customer":{"id":null,"firstName":"jGtfmTYFLF"
  10:42:25.828 [front-end] Received response: "{\"firstName\":\"FLiqlpA\",\"lastName\":\"FLiqlpA\",\"username\":\"FLiqlpA\",\"id\":\"6741b17ba437380001df4b71\",\"_links\":{\"addresses\":{
  10:42:27.156 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19301dd390007094e0e","customerId":"6741b17da437380001df4b73","customer":{"id":null,"firstName":"KHdmtS","la
  10:42:29.295 [front-end] Posting Customer: {"username":"VSfGH","password":"GRRpKDX","email":"VSfGH@gmail.com","firstName":"VSfGH","lastName":"VSfGH"}
  10:42:32.549 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19801dd390007094e11","customerId":"6741b183a437380001df4b7f","customer":{"id":null,"firstName":"fMqkVIscpJA
  10:42:34.942 [front-end] Order response: {"id":"6741b19a01dd390007094e14","customerId":"6741b186a437380001df4b87","customer":{"id":null,"firstName":"OePlWpOYf","lastName":"OePlWpOYf","u
  10:42:39.036 [front-end] Received response: "{\"firstName\":\"mOsUajmTCOuD\",\"lastName\":\"mOsUajmTCOuD\",\"username\":\"mOsUajmTCOuD\",\"id\":\"6741b18ba437380001df4b91\",\"_links\":{
  10:42:41.809 [front-end] Received response: "{\"firstName\":\"EwfSFA\",\"lastName\":\"EwfSFA\",\"username\":\"EwfSFA\",\"id\":\"6741b192a437380001df4b9e\",\"_links\":{\"addresses\":{\"h
  10:42:43.701 [front-end] Posting Customer: {"username":"oahRzcTiF","password":"hOQXbW","email":"oahRzcTiF@gmail.com","firstName":"oahRzcTiF","lastName":"oahRzcTiF"}
  10:42:45.675 [front-end] Posting Customer: {"username":"kGBLWWwRWdyKM","password":"MLNzikkf","email":"kGBLWWwRWdyKM@gmail.com","firstName":"kGBLWWwRWdyKM","lastName":"kGBLWWwRWdyKM"}
  10:42:47.188 [user] ts=2024-11-23T10:42:47.188515662Z caller=middlewares.go:46 method=Register username=EuaRkWCg email=EuaRkWCg@gmail.com took=1.836672ms

## p0217
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T07:46:05.130Z
```
{"timestamp":1731915965130806300,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-svrwm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432"}
```
Same service, the 2 minutes before (oldest first):
  07:46:02.810 [cartservice] AddItemAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4, productId=0PUK6V6EV0, quantity=5  (×4)
  07:46:02.810 [cartservice] GetCartAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add  (×14)
  07:46:02.890 [cartservice] EmptyCartAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4  (×2)
All services, 30 seconds either side (sampled):
  07:45:35.134 [cartservice] GetCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×259)
  07:45:35.176 [adservice] received ad request (context_words=[])  (×39)
  07:45:35.547 [frontend] serving product page  (×150)
  07:45:35.580 [adservice] received ad request (context_words=[clothing, tops])  (×12)
  07:45:36.190 [shippingservice] [GetQuote] completed request  (×71)
  07:45:37.172 [frontend] adding to cart  (×32)
  07:45:38.087 [frontend] setting currency  (×26)
  07:45:42.134 [frontend] placing order  (×10)
  07:45:42.171 [paymentservice] Transaction processed: visa ending 0936 Amount: USD1898.90000000  (×3)
  07:45:42.174 [shippingservice] [ShipOrder] completed request  (×10)
  07:45:42.185 [checkoutservice] order confirmation email sent to "steelekaren@example.net"
  07:45:43.620 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="EUR"  (×2)
  07:45:43.652 [emailservice] A request to send order confirmation email to jerome78@example.net has been received.
  07:45:44.774 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"76126","nanos":230872014},"credit_card":{"credit_card_number":"483436557588
  07:45:44.787 [checkoutservice] order confirmation email sent to "joseph73@example.net"
  07:45:46.110 [paymentservice] Transaction processed: visa ending 8142 Amount: CAD159.215341883  (×3)
  07:45:50.307 [emailservice] A request to send order confirmation email to joshuagomez@example.com has been received.
  07:46:02.898 [checkoutservice] order confirmation email sent to "martinezchristopher@example.net"
  07:46:08.607 [emailservice] A request to send order confirmation email to crystallee@example.net has been received.
  07:46:17.271 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"40","nanos":235937193},"credit_card":{"credit_card_number":"441464901948199
  07:46:17.285 [checkoutservice] order confirmation email sent to "george88@example.org"
  07:46:24.093 [redis] 79:C 18 Nov 2024 07:46:24.093 * DB saved on disk
  07:46:28.496 [emailservice] A request to send order confirmation email to arogers@example.com has been received.

## p0220
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service checkoutservice, 2024-11-18T07:49:08.318Z
```
{"timestamp":1731916148318448600,"container_name":"checkoutservice","pod_name":"checkoutservice-7ff8db989f-zrkdv","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"order confirmation email sent to \"jessemarshall@example.com\""}
```
Same service, the 2 minutes before (oldest first):
  07:48:26.386 [checkoutservice] [PlaceOrder] user_id="5e004f2d-a61a-45b2-840d-6bfd47a2be43" user_currency="TRY"
  07:48:26.414 [checkoutservice] payment went through (transaction_id: cac92084-9473-4e34-9e27-6175ad81903b)  (×7)
  07:48:26.426 [checkoutservice] order confirmation email sent to "elizabeth31@example.com"
  07:48:47.572 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="EUR"  (×5)
  07:48:47.609 [checkoutservice] order confirmation email sent to "xmitchell@example.com"
  07:48:51.076 [checkoutservice] [PlaceOrder] user_id="b63bea0e-d05f-4589-be71-8fef43557432" user_currency="USD"
  07:48:51.137 [checkoutservice] order confirmation email sent to "ybrown@example.org"
  07:49:00.561 [checkoutservice] order confirmation email sent to "erik67@example.com"
  07:49:05.971 [checkoutservice] order confirmation email sent to "kimrodriguez@example.com"
  07:49:07.264 [checkoutservice] order confirmation email sent to "karenli@example.org"
All services, 30 seconds either side (sampled):
  07:48:38.417 [frontend] request started  (×334)
  07:48:38.420 [currencyservice] Getting supported currencies...  (×278)
  07:48:38.431 [currencyservice] conversion request successful  (×778)
  07:48:38.448 [adservice] received ad request (context_words=[hair, beauty])  (×20)
  07:48:38.628 [adservice] received ad request (context_words=[accessories])  (×41)
  07:48:38.803 [frontend] home  (×40)
  07:48:38.848 [adservice] received ad request (context_words=[])  (×39)
  07:48:39.692 [adservice] received ad request (context_words=[footwear])  (×14)
  07:48:41.057 [frontend] view user cart  (×66)
  07:48:41.080 [shippingservice] [GetQuote] completed request  (×77)
  07:48:45.221 [frontend] adding to cart  (×35)
  07:48:47.571 [frontend] placing order  (×11)
  07:48:47.594 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"196","nanos":284829723},"credit_card":{"credit_card_number":"42762508717595  (×8)
  07:48:47.597 [checkoutservice] payment went through (transaction_id: d9d7b769-ac77-4ede-ac4f-8608835462b3)  (×11)
  07:48:47.599 [shippingservice] [ShipOrder] completed request  (×11)
  07:48:47.607 [emailservice] A request to send order confirmation email to xmitchell@example.com has been received.
  07:48:47.610 [frontend] order placed  (×11)
  07:48:51.030 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', 'OLJCESPC7Z']
  07:48:51.121 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"1679","nanos":890000000},"credit_card":{"credit_card_number":"4996980677738  (×2)
  07:48:51.134 [emailservice] A request to send order confirmation email to ybrown@example.org has been received.
  07:49:00.560 [emailservice] A request to send order confirmation email to erik67@example.com has been received.
  07:49:05.969 [emailservice] A request to send order confirmation email to kimrodriguez@example.com has been received.
  07:49:07.262 [emailservice] A request to send order confirmation email to karenli@example.org has been received.
  07:49:08.317 [emailservice] A request to send order confirmation email to jessemarshall@example.com has been received.
  07:49:16.625 [checkoutservice] order confirmation email sent to "richardsondawn@example.net"
  07:49:18.547 [checkoutservice] order confirmation email sent to "johnhill@example.com"
  07:49:23.762 [checkoutservice] order confirmation email sent to "jordan06@example.org"
  07:49:23.995 [checkoutservice] order confirmation email sent to "travis83@example.org"
  07:49:36.095 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"314","nanos":305711620},"credit_card":{"credit_card_number":"43999166534280
  07:49:36.109 [emailservice] A request to send order confirmation email to aaron90@example.net has been received.

## p0389
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:22.964Z
```
{"timestamp":1732247182964892400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Merging carts for customer id: 673ffe8eb0df5c00019b3183 and session id: kVNzcKAQpyXXiy5pJznW9b0tV4KJ_7pO"}
```
Same service, the 2 minutes before (oldest first):
  03:46:22.432 [front-end] User cart deleted with status: 503
  03:46:22.434 [front-end] DELETE /cart 503 - ms - -
  03:46:22.441 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  03:46:22.448 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  03:46:22.448 [front-end] POST to carts: http://carts/carts/673ffe89b0df5c00019b3175/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  03:46:22.508 [front-end] POST /cart 500 65.236 ms - 64
  03:46:22.572 [front-end] Request received with body: {}
  03:46:22.579 [front-end] Received response: "{\"firstName\":\"QLKMQlrIaMu\",\"lastName\":\"QLKMQlrIaMu\",\"username\":\"QLKMQlrIaMu\",\"id\":\"673ffe75b0df5c00019b3139\",\"_links\":{\"a
  03:46:22.579 [front-end] GET Request to: http://user/customers/673ffe75b0df5c00019b3139/addresses  (×2)
  03:46:22.586 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:46:22.586 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe7db0df5c00019b314e\",\"_links\":{\"
  03:46:22.586 [front-end] [ undefined, undefined ]
  03:46:22.586 [front-end] Posting Order: {"customer":"http://user/customers/673ffe75b0df5c00019b3139","address":"http://user/addresses/673ffe7db0df5c00019b314d","card":"http://user/cards
  03:46:22.650 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732247182647,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:46:22.650 [front-end] Order response: {"timestamp":1732247182647,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:46:22.652 [front-end] POST /orders 500 - ms - -
  03:46:22.958 [front-end] Posting Customer: {"username":"YNeGDXzX","password":"QOvRtAHj","email":"YNeGDXzX@gmail.com","firstName":"YNeGDXzX","lastName":"YNeGDXzX"}
  03:46:22.964 [front-end] { id: '673ffe8eb0df5c00019b3183' }
  03:46:22.964 [front-end] 673ffe8eb0df5c00019b3183
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×25)
  03:46:10.147 [front-end] 673ffe82b0df5c00019b315b  (×40)
  03:46:10.351 [catalogue] ts=2024-11-22T03:46:10Z caller=logging.go:85 method=Health result=2 took=27.37µs  (×30)
  03:46:10.817 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe78b0df5c00019b3141\",\"_links\":{\"  (×44)
  03:46:10.843 [payment] ts=2024-11-22T03:46:10Z caller=logging.go:40 method=Health result=1 took=7.196µs  (×30)
  03:46:10.940 [front-end] Received response: "{\"firstName\":\"jnTZDLVwW\",\"lastName\":\"jnTZDLVwW\",\"username\":\"jnTZDLVwW\",\"id\":\"673ffe65b0df5c00019b3100\",\"_links\":{\"address
  03:46:11.161 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffe79b0df5c00019b3143"}  (×43)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×43)
  03:46:11.318 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  03:46:12.141 [user] ts=2024-11-22T03:46:12.141108416Z caller=middlewares.go:46 method=Register username=VaPxY email=VaPxY@gmail.com took=1.01883ms
  03:46:12.669 [orders] 2024-11-22 03:46:12.668 ERROR [orders,,,] 6 --- [p-nio-80-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×25)
  03:46:14.786 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  03:46:15.206 [user] ts=2024-11-22T03:46:15.206068871Z caller=middlewares.go:46 method=Register username=GIUFZZyI email=GIUFZZyI@gmail.com took=1.199135ms
  03:46:16.945 [user] ts=2024-11-22T03:46:16.945426009Z caller=middlewares.go:46 method=Register username=ANUgD email=ANUgD@gmail.com took=1.061751ms
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:22.962 [user] ts=2024-11-22T03:46:22.961891483Z caller=middlewares.go:46 method=Register username=YNeGDXzX email=YNeGDXzX@gmail.com took=1.087598ms
  03:46:25.991 [user] ts=2024-11-22T03:46:25.991686067Z caller=middlewares.go:46 method=Register username=jAAETa email=jAAETa@gmail.com took=1.020993ms
  03:46:26.921 [user] ts=2024-11-22T03:46:26.921445594Z caller=middlewares.go:46 method=Register username=SGNMlFJX email=SGNMlFJX@gmail.com took=998.659µs
  03:46:28.865 [orders-db] {"t":{"$date":"2024-11-22T03:46:28.864+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224718
  03:46:30.040 [user] ts=2024-11-22T03:46:30.040199562Z caller=middlewares.go:46 method=Register username=hCQLZMhz email=hCQLZMhz@gmail.com took=1.097772ms
  03:46:30.678 [front-end] Received response: "{\"firstName\":\"jwQwxgI\",\"lastName\":\"jwQwxgI\",\"username\":\"jwQwxgI\",\"id\":\"673ffe80b0df5c00019b315a\",\"_links\":{\"addresses\":{
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.099 [front-end] Posting Customer: {"username":"THBqBDDcBz","password":"PRiYTiQkw","email":"THBqBDDcBz@gmail.com","firstName":"THBqBDDcBz","lastName":"THBqBDDcBz"}
  03:46:40.280 [front-end] Posting Customer: {"username":"GFexg","password":"iTpJx","email":"GFexg@gmail.com","firstName":"GFexg","lastName":"GFexg"}
  03:46:42.343 [front-end] Posting Customer: {"username":"PscIdXcmCyQHmMr","password":"qvNYdZI","email":"PscIdXcmCyQHmMr@gmail.com","firstName":"PscIdXcmCyQHmMr","lastName":"PscIdXcmCyQHm
  03:46:47.377 [front-end] Received response: "{\"firstName\":\"hCQLZMhz\",\"lastName\":\"hCQLZMhz\",\"username\":\"hCQLZMhz\",\"id\":\"673ffe96b0df5c00019b3197\",\"_links\":{\"addresses\
  03:46:50.786 [front-end] Received response: "{\"firstName\":\"WrRpd\",\"lastName\":\"WrRpd\",\"username\":\"WrRpd\",\"id\":\"673ffe94b0df5c00019b3193\",\"_links\":{\"addresses\":{\"href
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.601 [front-end] Posting Customer: {"username":"KouXEnVz","password":"MiSvBqizUW","email":"KouXEnVz@gmail.com","firstName":"KouXEnVz","lastName":"KouXEnVz"}

## p0654
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-11T05:23:11.658Z
```
{"service":"dbservice1","message":"2021-08-11 05:23:11,658 | ERROR | 0.0.0.4 | dbservice1 | db_helper.py -> sql_ano_prob -> 92 | dfa2a2a1e85ae05e | (pymysql.err.ProgrammingError) (1146, \"Table 'cloudwise_micross.system_metric_datas' doesn't exist\")[SQL: select service_names, system_data_time, system_cpu_utilization, system_memory_usage,system_disk_usage, disk_io_read_count, disk_io_write_count,system_network, network_io_read_count,…"}
```
Same service, the 2 minutes before (oldest first):
  05:23:08.071 [dbservice1] INFO query = select passwards from username_table where user_name='NrfVcbxl'  (×5)
  05:23:08.147 [dbservice1] INFO 27d06288-fa21-11eb-a295-0242ac110004-NrfVcbxl-^1P/2B4Y7TWc token generate success token=MTYyODYzMDU4OC4xNDcyNTM1OjI3ZDA2Mjg4LWZhMjEtMTFlYi1hMjk1LTAyNDJhYzE
  05:23:08.498 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  05:23:08.498 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  05:23:08.631 [dbservice1] INFO 280b6e6e-fa21-11eb-95e0-0242ac110004-QkrTBEJI-_!2b7K&HzsM_ token generate success token=MTYyODYzMDU4OC42MzA3Mjc1OjI4MGI2ZTZlLWZhMjEtMTFlYi05NWUwLTAyNDJhYzE
  05:23:08.975 [dbservice1] INFO 28522fde-fa21-11eb-abc8-0242ac110004-TKNpsvwU--BNr6&D1Xzn5 token generate success token=MTYyODYzMDU4OC45NzQ4NTU0OjI4NTIyZmRlLWZhMjEtMTFlYi1hYmM4LTAyNDJhYzE
  05:23:09.842 [dbservice1] INFO 28d3cf80-fa21-11eb-acd6-0242ac110003-rJHuqoXG-(HeVo%G8a5v/ token generate success token=MTYyODYzMDU4OS44NDE3ODM4OjI4ZDNjZjgwLWZhMjEtMTFlYi1hY2Q2LTAyNDJhYzE
  05:23:10.688 [dbservice1] INFO 2957a206-fa21-11eb-9675-0242ac110003-rREWnpxD-21*NMiag8RwC token generate success token=MTYyODYzMDU5MC42ODgxNTg6Mjk1N2EyMDYtZmEyMS0xMWViLTk2NzUtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  05:22:42.170 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×37)
  05:22:42.356 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×35)
  05:22:42.553 [mobservice1] INFO info 18c9755e-fa21-11eb-8901-0242ac110004:ZQXfBztT write success
  05:22:42.655 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '18c9755e-fa21-11eb-8901-0242ac110004', 'user_id': 'ZQXfBztT'}  (×67)
  05:22:42.757 [dbservice2] INFO query = select passwards from username_table where user_name='ZQXfBztT'  (×27)
  05:22:45.109 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×33)
  05:22:45.416 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×37)
  05:22:45.621 [dbservice1] INFO 1a6c870c-fa21-11eb-b53b-0242ac110003-SNyDIdeO-%$BE{6JCn?Hd token generate success token=MTYyODYzMDU2NS42MjE0MTA2OjFhNmM4NzBjLWZhMjEtMTFlYi1iNTNiLTAyNDJhYzE
  05:22:48.479 [dbservice1] INFO 1c1894b0-fa21-11eb-9972-0242ac110004-iZWtCSMp-M5*>4^fm-6c) token generate success token=MTYyODYzMDU2OC40NzkxOTk6MWMxODk0YjAtZmEyMS0xMWViLTk5NzItMDI0MmFjMTE
  05:22:52.849 [dbservice2] INFO 1eba75c6-fa21-11eb-bb0d-0242ac110004-kHIDhMnd-h+i/nz=N}69% token generate success token=MTYyODYzMDU3Mi44NDg1Mjk6MWViYTc1YzYtZmEyMS0xMWViLWJiMGQtMDI0MmFjMTE
  05:22:55.474 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat  (×3)
  05:22:57.161 [dbservice2] INFO 21459320-fa21-11eb-a95b-0242ac110003-nulqIiBE-H(j2E8MvFo.w token generate success token=MTYyODYzMDU3Ny4xNjA5NzkzOjIxNDU5MzIwLWZhMjEtMTFlYi1hOTViLTAyNDJhYzE
  05:22:59.829 [dbservice1] INFO 22d032cc-fa21-11eb-a5c7-0242ac110004-FyPTBMJg-Zjy9.L?*GlNe token generate success token=MTYyODYzMDU3OS44Mjk0NDI3OjIyZDAzMmNjLWZhMjEtMTFlYi1hNWM3LTAyNDJhYzE
  05:23:02.217 [dbservice2] INFO 244f1e06-fa21-11eb-85b9-0242ac110004-CxaURntJ-FQ4_E#@RDnS. token generate success token=MTYyODYzMDU4Mi4yMTY1OTM3OjI0NGYxZTA2LWZhMjEtMTFlYi04NWI5LTAyNDJhYzE
  05:23:04.397 [mobservice1] INFO info 25cc04b0-fa21-11eb-9530-0242ac110003:HMKVRZeu write success
  05:23:06.991 [mobservice2] INFO info 275bfe20-fa21-11eb-b9d1-0242ac110003:WuXJGtdQ write success
  05:23:08.975 [dbservice1] INFO 28522fde-fa21-11eb-abc8-0242ac110004-TKNpsvwU--BNr6&D1Xzn5 token generate success token=MTYyODYzMDU4OC45NzQ4NTU0OjI4NTIyZmRlLWZhMjEtMTFlYi1hYmM4LTAyNDJhYzE
  05:23:11.720 [dbservice2] INFO 29d9680e-fa21-11eb-9446-0242ac110004-BrtsWueY-U<o(drDvlHsR token generate success token=MTYyODYzMDU5MS43MTk2NzoyOWQ5NjgwZS1mYTIxLTExZWItOTQ0Ni0wMjQyYWMxMTA
  05:23:14.277 [dbservice1] INFO 2b75130c-fa21-11eb-90dc-0242ac110004-zfawCciR-dF$Y@Is}SMDa token generate success token=MTYyODYzMDU5NC4yNzY5MDc3OjJiNzUxMzBjLWZhMjEtMTFlYi05MGRjLTAyNDJhYzE
  05:23:16.608 [dbservice2] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c  (×2)
  05:23:18.816 [mobservice2] INFO info 2e712d2a-fa21-11eb-ba1b-0242ac110003:TAFqsYCb write success
  05:23:25.773 [mobservice1] INFO info 328b7dfc-fa21-11eb-b6c2-0242ac110004:NSiQolUW write success
  05:23:32.197 [logservice1] ERROR uuid expired, invalid phone request
  05:23:34.377 [mobservice1] INFO info 37a3d05a-fa21-11eb-93dd-0242ac110004:FqaTIXhn write success
  05:23:36.800 [mobservice2] INFO info 39202550-fa21-11eb-b124-0242ac110004:tLUwrBsD write success
  05:23:38.911 [dbservice2] INFO 3a3063d8-fa21-11eb-817e-0242ac110003-KXtHNvbZ-Qh<MIBE8TJ9i token generate success token=MTYyODYzMDYxOC45MTEwMTg6M2EzMDYzZDgtZmEyMS0xMWViLTgxN2UtMDI0MmFjMTE
  05:23:41.122 [mobservice1] INFO info 3bb01a00-fa21-11eb-b56a-0242ac110003:GKtJXRfS write success

## p0199
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:54:42.221Z
```
{"timestamp":1731912882221268700,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  06:54:40.626 [frontend] view user cart  (×3)
  06:54:40.672 [frontend] request complete  (×7)
  06:54:40.844 [frontend] request started  (×6)
  06:54:40.844 [frontend] serving product page  (×3)
  06:54:41.543 [frontend] adding to cart
All services, 30 seconds either side (sampled):
  06:54:12.754 [frontend] request started  (×349)
  06:54:12.762 [cartservice] GetCartAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0  (×282)
  06:54:12.786 [adservice] received ad request (context_words=[hair, beauty])  (×21)
  06:54:12.794 [cartservice] AddItemAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0, productId=2ZYFJ3GM2N, quantity=2  (×44)
  06:54:12.832 [shippingservice] [GetQuote] received request  (×94)
  06:54:12.922 [frontend] home  (×34)
  06:54:13.018 [frontend] ENV_PLATFORM is: aws  (×34)
  06:54:13.040 [paymentservice] Transaction processed: visa ending 9554 Amount: JPY67520.297213815  (×3)
  06:54:13.044 [shippingservice] [ShipOrder] completed request  (×17)
  06:54:13.055 [checkoutservice] order confirmation email sent to "devon86@example.org"
  06:54:14.089 [adservice] received ad request (context_words=[decor, home])  (×17)
  06:54:14.163 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"88","nanos":265624061},"credit_card":{"credit_card_number":"427183441806829  (×3)
  06:54:14.176 [checkoutservice] order confirmation email sent to "qgriffin@example.net"
  06:54:15.875 [adservice] received ad request (context_words=[footwear])  (×14)
  06:54:16.054 [paymentservice] Transaction processed: visa ending 6565 Amount: TRY1169.354487400
  06:54:17.194 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', '2ZYFJ3GM2N', '1YMWWN1N4O', 'LS4PSXUNUM']  (×5)
  06:54:21.960 [paymentservice] Transaction processed: visa ending 4719 Amount: EUR976.329057947  (×5)
  06:54:24.380 [adservice] received ad request (context_words=[clothing, tops])  (×18)
  06:54:29.310 [paymentservice] Transaction processed: visa ending 6127 Amount: GBP1600.129457757
  06:54:31.744 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z']  (×3)
  06:54:34.096 [paymentservice] Transaction processed: visa ending 2236 Amount: USD667.130000000  (×4)
  06:54:34.293 [emailservice] A request to send order confirmation email to teresakelly@example.net has been received.
  06:54:45.159 [emailservice] A request to send order confirmation email to kimberlystrickland@example.com has been received.
  06:54:47.051 [checkoutservice] order confirmation email sent to "maureenburke@example.org"
  06:55:00.192 [emailservice] A request to send order confirmation email to phillipslouis@example.net has been received.
  06:55:00.426 [checkoutservice] order confirmation email sent to "melissa97@example.org"
  06:55:05.234 [emailservice] A request to send order confirmation email to cowandiana@example.org has been received.
  06:55:07.659 [checkoutservice] order confirmation email sent to "youngcrystal@example.com"

## p0437
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-23T08:05:53.086Z
```
{"timestamp":1732349153086466000,"container_name":"orders","pod_name":"orders-7fff6698cb-rlq5k","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable\n\tat org.springframework.web.client.DefaultResponseErrorHandler.handleError(DefaultResponseErrorHandler.java:94) ~[spring-web-4.3.6.RELEASE.jar!/:4.3.6.RELEASE]\n\tat org.springframework.web.client.RestTemplate.handleResponse(RestTemplate.java:700) ~[spring-web-4.3.6.RELEASE.jar!/:4.3.6.RELEASE]\n\tat org.springframework.w…"}
```
Same service, the 2 minutes before (oldest first):
  08:05:49.888 [orders] 2024-11-23 08:05:49.888 INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repos  (×15)
  08:05:51.293 [orders] 2024-11-23 08:05:51.289 ERROR [orders,,,] 8 --- [p-nio-80-exec-6] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×3)
  08:05:51.293 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×2)
All services, 30 seconds either side (sampled):
  08:05:23.140 [front-end] POST /cart 500 89.546 ms - 64  (×62)
  08:05:23.574 [front-end] set cookie67418cc3a437380001deec02  (×59)
  08:05:24.453 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×10)
  08:05:26.507 [queue-master] 2024-11-23 08:05:26.507 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/x-spring-data-c
  08:05:26.611 [queue-master] 2024-11-23 08:05:26.611 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[OPTIONS],produces=[application/hal+
  08:05:27.703 [queue-master] 2024-11-23 08:05:27.703 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]}" onto pub
  08:05:27.912 [carts] 2024-11-23 08:05:27.912 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  08:05:30.210 [carts] 2024-11-23 08:05:30.209 INFO [carts,,,] 7 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[carts-db:27017], mode=SINGLE, requiredC
  08:05:31.806 [carts] 2024-11-23 08:05:31.806 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  08:05:34.107 [queue-master] 2024-11-23 08:05:34.106 INFO 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:05:37.773 [front-end] Posting Customer: {"username":"uOuKqLBUeqm","password":"fYyuRQl","email":"uOuKqLBUeqm@gmail.com","firstName":"uOuKqLBUeqm","lastName":"uOuKqLBUeqm"}
  08:05:39.190 [orders] 2024-11-23 08:05:39.189 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[OPTIONS],produces=[applic
  08:05:39.285 [orders] 2024-11-23 08:05:39.285 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applicat  (×2)
  08:05:41.191 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java
  08:05:43.566 [user] ts=2024-11-23T08:05:43.565925822Z caller=middlewares.go:46 method=Register username=lRmvkfemO email=lRmvkfemO@gmail.com took=2.334851ms
  08:05:45.706 [front-end] Received response: "{\"firstName\":\"TUwwDhCkvEuN\",\"lastName\":\"TUwwDhCkvEuN\",\"username\":\"TUwwDhCkvEuN\",\"id\":\"67418cc5a437380001deec07\",\"_links\":{
  08:05:49.486 [orders] 2024-11-23 08:05:49.394 ERROR [orders,,,] 8 --- [p-nio-80-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×35)
  08:05:51.464 [user] ts=2024-11-23T08:05:51.464834006Z caller=middlewares.go:46 method=Register username=JfkloKMY email=JfkloKMY@gmail.com took=1.963924ms
  08:05:54.910 [shipping] 2024-11-23 08:05:54.910 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[applicati
  08:05:57.302 [shipping] 2024-11-23 08:05:57.301 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot
  08:06:00.402 [shipping] 2024-11-23 08:06:00.402 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class
  08:06:04.742 [front-end] Received response: "{\"firstName\":\"HppTvuW\",\"lastName\":\"HppTvuW\",\"username\":\"HppTvuW\",\"id\":\"67418cd0a437380001deec2d\",\"_links\":{\"addresses\":{
  08:06:07.002 [shipping] 2024-11-23 08:06:07.002 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[HEAD],produces=[applica
  08:06:07.099 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[GET],produce  (×2)
  08:06:10.340 [front-end] Posting Customer: {"username":"djVRqry","password":"CJLHmVgJ","email":"djVRqry@gmail.com","firstName":"djVRqry","lastName":"djVRqry"}
  08:06:14.400 [shipping] 2024-11-23 08:06:14.400 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX ser
  08:06:15.802 [carts] 2024-11-23 08:06:15.802 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[applicati
  08:06:15.906 [carts] 2024-11-23 08:06:15.904 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframewor
  08:06:19.002 [carts] 2024-11-23 08:06:19.001 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  08:06:19.279 [user] ts=2024-11-23T08:06:19.279512453Z caller=middlewares.go:46 method=Register username=ctDNRPS email=ctDNRPS@gmail.com took=2.189149ms

## p0082
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T13:39:05.036Z
```
{"service":"logservice1","message":"2021-08-13 13:39:05,036 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | f653f33ff942cb3 | the list of all available services are logservice2: http://0.0.0.2:9385"}
```
Same service, the 2 minutes before (oldest first):
  13:39:02.433 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  13:39:02.433 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'c3cc312a-fbf8-11eb-befa-0242ac110003'}  (×3)
  13:39:02.492 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×2)
  13:39:02.493 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×2)
  13:39:02.493 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': 'c3cc312a-fbf8-11eb-befa-0242ac110003', 'user_id': 'lwqgfHWY'}  (×4)
  13:39:03.234 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×2)
  13:39:03.234 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×2)
  13:39:03.299 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
All services, 30 seconds either side (sampled):
  13:38:35.108 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  13:38:35.324 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×56)
  13:38:35.532 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'b3bef4de-fbf8-11eb-9f04-0242ac110003'}  (×46)
  13:38:35.693 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×50)
  13:38:35.907 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'b438abc6-fbf8-11eb-abf1-0242ac110004', 'value': '', 'ex': 10}  (×43)
  13:38:36.109 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'b438abc6-fbf8-11eb-abf1-0242ac110004'}  (×35)
  13:38:36.945 [mobservice2] INFO info b49fdecc-fbf8-11eb-ac9c-0242ac110004:RIklYufT write success
  13:38:38.751 [mobservice2] INFO info b5b9cd9a-fbf8-11eb-b334-0242ac110004:vOcCSRZA write success
  13:38:39.121 [dbservice2] INFO b5b9cd9a-fbf8-11eb-b334-0242ac110004-vOcCSRZA-s/FAM$t>D)ox token generate success token=MTYyODgzMzExOS4xMjA2NTk4OmI1YjljZDlhLWZiZjgtMTFlYi1iMzM0LTAyNDJhYzE
  13:38:41.917 [dbservice1] INFO b75f5d54-fbf8-11eb-8423-0242ac110003-lqFmKxHv-(E%bNa0f83I5 token generate success token=MTYyODgzMzEyMS45MTc0NjE5OmI3NWY1ZDU0LWZiZjgtMTFlYi04NDIzLTAyNDJhYzE
  13:38:45.100 [mobservice2] INFO info b9859d6e-fbf8-11eb-b682-0242ac110004:tBDHvTdf write success
  13:38:47.663 [mobservice1] INFO info bb08e4ac-fbf8-11eb-8dd5-0242ac110003:fwiKVRsI write success
  13:38:50.262 [mobservice2] INFO info bc98cae4-fbf8-11eb-94c7-0242ac110003:kpLnyIUm write success
  13:38:52.727 [mobservice2] INFO info be0e18ac-fbf8-11eb-918a-0242ac110004:NvzARtmh write success
  13:38:55.754 [dbservice2] INFO bf9c646c-fbf8-11eb-b94a-0242ac110004-xhUTVXnF-Zmk_pM}XYJ>= token generate success token=MTYyODgzMzEzNS43NTM3NTEzOmJmOWM2NDZjLWZiZjgtMTFlYi1iOTRhLTAyNDJhYzE
  13:38:58.353 [dbservice1] INFO c1202558-fbf8-11eb-abb2-0242ac110003-TFaxVQiG-bQrY_.{J3<U+ token generate success token=MTYyODgzMzEzOC4zNTM1Mzk1OmMxMjAyNTU4LWZiZjgtMTFlYi1hYmIyLTAyNDJhYzE
  13:39:01.112 [dbservice1] INFO c2cecd0a-fbf8-11eb-9df1-0242ac110004-NnLPEQzC-}wlJNKU3ythV token generate success token=MTYyODgzMzE0MS4xMTE5MjQ2OmMyY2VjZDBhLWZiZjgtMTFlYi05ZGYxLTAyNDJhYzE
  13:39:03.549 [dbservice1] INFO c4497a22-fbf8-11eb-ada2-0242ac110003-Wwkmbphn-+MclZ6B=^/:C token generate success token=MTYyODgzMzE0My41NDkxNTMzOmM0NDk3YTIyLWZiZjgtMTFlYi1hZGEyLTAyNDJhYzE
  13:39:06.672 [dbservice1] INFO c5f13efa-fbf8-11eb-9492-0242ac110003-cvBGfCKh-Jf.l:ogU&-se token generate success token=MTYyODgzMzE0Ni42NzE3Njg0OmM1ZjEzZWZhLWZiZjgtMTFlYi05NDkyLTAyNDJhYzE
  13:39:09.265 [mobservice2] INFO info c7ea2a3c-fbf8-11eb-844e-0242ac110004:bypSvsJC write success
  13:39:12.040 [mobservice2] INFO info c984f084-fbf8-11eb-b4c7-0242ac110004:RcoJYnsh write success
  13:39:14.997 [dbservice1] INFO cb0636c0-fbf8-11eb-b663-0242ac110003-ropVRsqh-hActS-H+f9_x token generate success token=MTYyODgzMzE1NC45OTY5MjYzOmNiMDYzNmMwLWZiZjgtMTFlYi1iNjYzLTAyNDJhYzE  (×3)
  13:39:18.177 [mobservice2] INFO info cd2500f8-fbf8-11eb-81a1-0242ac110003:eyfiDUCK write success
  13:39:20.848 [mobservice2] INFO info ced2f19e-fbf8-11eb-b06b-0242ac110004:hPlvogHR write success
  13:39:23.417 [mobservice2] INFO info d0489ef2-fbf8-11eb-9d03-0242ac110004:rXbZtUoM write success
  13:39:25.950 [mobservice2] INFO info d1d6eb16-fbf8-11eb-9910-0242ac110003:nuUlzgDr write success
  13:39:29.550 [mobservice1] INFO info d3e2f6fc-fbf8-11eb-b787-0242ac110004:wzQhcEjW write success
  13:39:32.168 [mobservice1] INFO info d58b0c06-fbf8-11eb-acd5-0242ac110003:LxiphWgj write success

## p0607
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T20:10:20.856Z
```
{"timestamp":1733602220856869400,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-nsc8q","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:10:20.856  INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl             : Get Order tickets result is : <200,Response(status=1, msg=Success, data=LeftTicketInfo{soldTickets=[Ticket(seatNo=1273928112, startStation=shanghai, destStation=nanjing), Ticket(seatNo=362936645, startStation=shanghai, destStation=nanjing), Ticket(seatNo=511229046, startStation=shanghai, destStation=na…"}
```
Same service, the 2 minutes before (oldest first):
  20:10:07.138 [ts-seat-service] 2024-12-07 20:10:07.138 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×2)
  20:10:07.138 [ts-seat-service] 2024-12-07 20:10:07.138 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  20:10:07.146 [ts-seat-service] 2024-12-07 20:10:07.146 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×2)
  20:10:07.197 [ts-seat-service] 2024-12-07 20:10:07.196 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×2)
  20:10:07.197 [ts-seat-service] 2024-12-07 20:10:07.196 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×2)
  20:10:07.212 [ts-seat-service] 2024-12-07 20:10:07.211 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×2)
  20:10:07.222 [ts-seat-service] 2024-12-07 20:10:07.222 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:10:07.240 [ts-seat-service] 2024-12-07 20:10:07.240 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
  20:10:20.742 [ts-seat-service] 2024-12-07 20:10:20.742 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN
  20:10:20.742 [ts-seat-service] 2024-12-07 20:10:20.742 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
  20:10:20.757 [ts-seat-service] 2024-12-07 20:10:20.757 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  20:10:20.766 [ts-seat-service] 2024-12-07 20:10:20.766 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:10:20.780 [ts-seat-service] 2024-12-07 20:10:20.780 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re
  20:10:20.780 [ts-seat-service] 2024-12-07 20:10:20.780 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  20:10:20.788 [ts-seat-service] 2024-12-07 20:10:20.788 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri
All services, 30 seconds either side (sampled):
  20:09:50.875 [ts-admin-basic-info-service] 2024-12-07 20:09:50.875 INFO 1 --- [io-18767-exec-2] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×9)
  20:09:51.673 [ts-travel-service] 2024-12-07 20:09:51.672 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×92)
  20:09:51.702 [ts-travel-service] 2024-12-07 20:09:51.702 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×17)
  20:09:51.742 [ts-basic-service] 2024-12-07 20:09:51.742 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  20:09:51.764 [ts-basic-service] 2024-12-07 20:09:51.764 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
  20:09:51.812 [ts-travel-service] 2024-12-07 20:09:51.811 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr  (×26)
  20:09:51.833 [ts-seat-service] 2024-12-07 20:09:51.833 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×23)
  20:09:51.867 [ts-travel-service] 2024-12-07 20:09:51.866 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×26)
  20:09:52.713 [ts-food-map-service] 2024-12-07 20:09:52.713 INFO 1 --- [io-18855-exec-9] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×3)
  20:09:56.894 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:09:56 +0800] "POST /api/v1/users/login HTTP/1.1" 200 380 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×24)
  20:09:56.967 [ts-basic-service] 2024-12-07 20:09:56.966 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×14)
  20:09:56.997 [ts-food-service] 2024-12-07 20:09:56.997 INFO 1 --- [io-18856-exec-2] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×3)
  20:09:57.014 [ts-order-other-service] 2024-12-07 20:09:57.013 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×14)
  20:09:57.105 [ts-seat-service] 2024-12-07 20:09:57.104 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×25)
  20:09:57.280 [ts-travel2-service] 2024-12-07 20:09:57.280 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×26)
  20:09:57.607 [ts-travel2-service] 2024-12-07 20:09:57.606 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×12)
  20:09:59.386 [ts-basic-service] 2024-12-07 20:09:59.386 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270  (×6)
  20:09:59.541 [ts-seat-service] 2024-12-07 20:09:59.540 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×6)
  20:09:59.725 [ts-basic-service] 2024-12-07 20:09:59.724 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: aefc  (×2)
  20:10:00.332 [ts-travel-service] 2024-12-07 20:10:00.332 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan  (×8)
  20:10:09.643 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:10:09 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×10)
  20:10:15.778 [ts-admin-basic-info-service] 2024-12-07 20:10:15.778 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×2)
  20:10:23.177 [ts-auth-service] 2024-12-07 20:10:23.177 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  20:10:28.352 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-07T20:10:28.352+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360222
  20:10:28.586 [ts-travel2-service] 2024-12-07 20:10:28.586 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6
  20:10:31.127 [ts-consign-mongo] {"t":{"$date":"2024-12-07T20:10:31.127+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360223
  20:10:32.148 [ts-order-mongo] {"t":{"$date":"2024-12-07T20:10:32.148+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360223
  20:10:42.948 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T20:10:42.948+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360224

## p0656
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-11T05:38:19.502Z
```
{"service":"dbservice2","message":"2021-08-11 05:38:19,502 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | 7cc85a122d33c17 | 47041d3c-fa23-11eb-813d-0242ac110003-YCHLRfzD-Z.9yQOv:xC5- token generate success token=MTYyODYzMTQ5OS41MDIwNDk0OjQ3MDQxZDNjLWZhMjMtMTFlYi04MTNkLTAyNDJhYzExMDAwM1lDSExSZnpEWi45eVFPdjp4QzUtOjE2Mjg2MzE1NTkuNTAyMDYwNzo3MGE0NTNmMDVhYmExMWRkNWRiNjdjNzAzNjMwYjBlYw=="}
```
Same service, the 2 minutes before (oldest first):
  05:38:11.696 [dbservice2] INFO query = select passwards from username_table where user_name='cdoHPZSl'  (×5)
  05:38:11.773 [dbservice2] INFO 427c09d2-fa23-11eb-9fd9-0242ac110003-cdoHPZSl-/OVTg(a<^w_o token generate success token=MTYyODYzMTQ5MS43NzMwNjo0MjdjMDlkMi1mYTIzLTExZWItOWZkOS0wMjQyYWMxMTA
  05:38:13.535 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  05:38:13.535 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  05:38:13.686 [dbservice2] INFO 43791884-fa23-11eb-b433-0242ac110004-NpSktBQI-ZNc-73/n1Rbm token generate success token=MTYyODYzMTQ5My42ODYxNzE1OjQzNzkxODg0LWZhMjMtMTFlYi1iNDMzLTAyNDJhYzE
  05:38:16.263 [dbservice2] INFO 450cfbe8-fa23-11eb-b20d-0242ac110004-VbMWntAq-T2bc)3h}>4-M token generate success token=MTYyODYzMTQ5Ni4yNjI1MjI3OjQ1MGNmYmU4LWZhMjMtMTFlYi1iMjBkLTAyNDJhYzE
  05:38:16.632 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  05:38:18.909 [dbservice2] INFO 46a88206-fa23-11eb-ad84-0242ac110003-OkyWpDvC-YSR3f{z?a:H/ token generate success token=MTYyODYzMTQ5OC45MDkzMjE6NDZhODgyMDYtZmEyMy0xMWViLWFkODQtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  05:37:49.503 [dbservice2] INFO 3521150c-fa23-11eb-9809-0242ac110004-KaeOhoMc-C8w@bIBzX{A$ token generate success token=MTYyODYzMTQ2OS41MDMzNDM2OjM1MjExNTBjLWZhMjMtMTFlYi05ODA5LTAyNDJhYzE
  05:37:49.781 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×44)
  05:37:50.063 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×51)
  05:37:50.136 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '35a92992-fa23-11eb-811d-0242ac110004', 'user_id': 'tAOPYVGh'}  (×82)
  05:37:50.299 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×31)
  05:37:50.426 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  05:37:50.520 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '36346cc8-fa23-11eb-bd83-0242ac110003', 'value': '', 'ex': 10}  (×39)
  05:37:51.957 [dbservice2] INFO 36a7ac38-fa23-11eb-b981-0242ac110004-isocSGgr-!p.z:Xl7gqf5 token generate success token=MTYyODYzMTQ3MS45NTc1MTQzOjM2YTdhYzM4LWZhMjMtMTFlYi1iOTgxLTAyNDJhYzE
  05:37:53.123 [mobservice2] INFO info 37907bfc-fa23-11eb-97e9-0242ac110003:hUmNCczf write success
  05:37:55.728 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  05:37:57.799 [mobservice2] INFO info 3a4ffbb0-fa23-11eb-855d-0242ac110004:VUzqydWL write success
  05:38:00.402 [mobservice2] INFO info 3bddbf62-fa23-11eb-8c7a-0242ac110003:LXQegUZS write success
  05:38:07.315 [mobservice2] INFO info 3feddd8a-fa23-11eb-b1e8-0242ac110003:IwBSEYcZ write success
  05:38:09.842 [mobservice2] INFO info 417e5a1c-fa23-11eb-bd34-0242ac110004:MZHWTqUt write success
  05:38:12.634 [dbservice1] INFO 42edb7e4-fa23-11eb-a2fd-0242ac110003-SxlGNrtW-:6aQSXm@sWb3 token generate success token=MTYyODYzMTQ5Mi42MzQxNTk2OjQyZWRiN2U0LWZhMjMtMTFlYi1hMmZkLTAyNDJhYzE
  05:38:15.871 [mobservice2] INFO info 450cfbe8-fa23-11eb-b20d-0242ac110004:VbMWntAq write success
  05:38:18.517 [mobservice1] INFO info 46a88206-fa23-11eb-ad84-0242ac110003:OkyWpDvC write success
  05:38:21.390 [dbservice2] INFO 482913b6-fa23-11eb-99de-0242ac110004-qexisTfm-Y+xh-f@!yaE& token generate success token=MTYyODYzMTUwMS4zOTAwMjE4OjQ4MjkxM2I2LWZhMjMtMTFlYi05OWRlLTAyNDJhYzE
  05:38:24.222 [dbservice1] INFO 49c6daf0-fa23-11eb-ada2-0242ac110004-xYHiSMPL-Gx3@4LTvA_5z token generate success token=MTYyODYzMTUwNC4yMjIzNjczOjQ5YzZkYWYwLWZhMjMtMTFlYi1hZGEyLTAyNDJhYzE
  05:38:27.318 [mobservice2] INFO info 4bec0774-fa23-11eb-a168-0242ac110004:GTqJKEWv write success
  05:38:30.140 [mobservice2] INFO info 4d9b936e-fa23-11eb-bb62-0242ac110004:iBnyvbLP write success
  05:38:32.741 [mobservice1] INFO info 4f2375bc-fa23-11eb-91b0-0242ac110003:vPhcKXLl write success
  05:38:35.339 [mobservice1] INFO info 50b049fa-fa23-11eb-b839-0242ac110003:PBSphkoz write success
  05:38:38.347 [dbservice1] INFO 522f6856-fa23-11eb-a0b4-0242ac110004-vEGoarin-aD/}1_Q-2%xq token generate success token=MTYyODYzMTUxOC4zNDc1Mjc3OjUyMmY2ODU2LWZhMjMtMTFlYi1hMGI0LTAyNDJhYzE
  05:38:41.121 [dbservice1] INFO 53dd12c0-fa23-11eb-864e-0242ac110004-GVawnFOc-VvLan.=:lYq> token generate success token=MTYyODYzMTUyMS4xMjE1OTU2OjUzZGQxMmMwLWZhMjMtMTFlYi04NjRlLTAyNDJhYzE
  05:38:44.888 [mobservice2] INFO info 56672594-fa23-11eb-8719-0242ac110003:OvVHWlKe write success
  05:38:48.641 [dbservice2] INFO 585a6500-fa23-11eb-b0b2-0242ac110004-KrEDTxFN-^PywX8viK>=D token generate success token=MTYyODYzMTUyOC42NDEzNzk0OjU4NWE2NTAwLWZhMjMtMTFlYi1iMGIyLTAyNDJhYzE

## p0065
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T08:56:41.715Z
```
{"service":"dbservice1","message":"2021-08-13 08:56:41,715 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 50a0b30d8299704 | 52202b84-fbd1-11eb-882b-0242ac110003-HSRAIxlj-CuIYqAwN&?x) token generate success token=MTYyODgxNjIwMS43MTUxMTc1OjUyMjAyYjg0LWZiZDEtMTFlYi04ODJiLTAyNDJhYzExMDAwM0hTUkFJeGxqQ3VJWXFBd04mP3gpOjE2Mjg4MTYyNjEuNzE1MTI4Nzo4OGZmZWQxYzVlNzBkN2E5ZDZjNDNiN2ZlZGZkM2Y4Ng=="}
```
Same service, the 2 minutes before (oldest first):
  08:56:33.042 [dbservice1] INFO query = select passwards from username_table where user_name='OMLuHZEe'  (×5)
  08:56:33.341 [dbservice1] INFO 4cfe53c4-fbd1-11eb-88dd-0242ac110003-OMLuHZEe-zUGYQa}urZJ/ token generate success token=MTYyODgxNjE5My4zNDA5NzI6NGNmZTUzYzQtZmJkMS0xMWViLTg4ZGQtMDI0MmFjMTE
  08:56:34.967 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:56:34.967 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  08:56:35.100 [dbservice1] INFO 4e319c6a-fbd1-11eb-87fd-0242ac110004-IToaCVWE-}<7sLbog{2vF token generate success token=MTYyODgxNjE5NS4xMDA0MTc5OjRlMzE5YzZhLWZiZDEtMTFlYi04N2ZkLTAyNDJhYzE
  08:56:35.657 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  08:56:39.435 [dbservice1] INFO 50c64ade-fbd1-11eb-a9a0-0242ac110003-xjYUMcml-^4(_{v<kmK}e token generate success token=MTYyODgxNjE5OS40MzUxNzM3OjUwYzY0YWRlLWZiZDEtMTFlYi1hOWEwLTAyNDJhYzE
  08:56:40.632 [dbservice1] INFO 517a85da-fbd1-11eb-8af5-0242ac110004-mMWStTBy-K=7!ICE-naiw token generate success token=MTYyODgxNjIwMC42MzE5NjI6NTE3YTg1ZGEtZmJkMS0xMWViLThhZjUtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  08:56:11.744 [webservice1] INFO complete information: {'uuid': '409e2eba-fbd1-11eb-a65f-0242ac110003', 'user_id': 'hRGCgxwP'}  (×52)
  08:56:11.893 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×44)
  08:56:12.050 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×49)
  08:56:12.166 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×49)
  08:56:12.216 [dbservice2] ERROR dbservice2 access redis service denied  (×52)
  08:56:12.370 [mobservice1] INFO info 40da9f26-fbd1-11eb-a6b0-0242ac110003:cUsPLdAz write success
  08:56:12.528 [webservice2] INFO complete information: {'uuid': '410efb5e-fbd1-11eb-823a-0242ac110004', 'user_id': 'QkrTBEJI'}  (×49)
  08:56:12.981 [redisservice1] INFO service refuse, status_code: 200  (×27)
  08:56:14.255 [mobservice1] INFO info 41f82040-fbd1-11eb-b7a2-0242ac110003:UoOtrWnu write success
  08:56:15.530 [dbservice1] INFO 427bfbcc-fbd1-11eb-bd05-0242ac110003-NLUGYXBI-Lmw1G?kYO}b^ token generate success token=MTYyODgxNjE3NS41MzAxNDo0MjdiZmJjYy1mYmQxLTExZWItYmQwNS0wMjQyYWMxMTA
  08:56:18.097 [mobservice1] INFO info 44486512-fbd1-11eb-a47f-0242ac110003:xgpqRfCn write success
  08:56:21.855 [mobservice1] INFO info 46905cbc-fbd1-11eb-8421-0242ac110004:OSENDWPb write success
  08:56:25.581 [mobservice2] INFO info 48bc2bf6-fbd1-11eb-857a-0242ac110003:JyiQVplP write success
  08:56:28.984 [mobservice1] INFO info 4acbfa52-fbd1-11eb-be61-0242ac110004:saHAJjFe write success
  08:56:31.369 [dbservice1] INFO 4bf6e77a-fbd1-11eb-bec3-0242ac110004-MGhzxsST-cYbH0S^hJFm* token generate success token=MTYyODgxNjE5MS4zNjk0NDMyOjRiZjZlNzdhLWZiZDEtMTFlYi1iZWMzLTAyNDJhYzE
  08:56:34.518 [mobservice2] INFO info 4e08fd00-fbd1-11eb-a07f-0242ac110003:CAQfZdjo write success
  08:56:37.471 [mobservice1] INFO info 4fe03a4e-fbd1-11eb-8665-0242ac110004:spFyrBHI write success
  08:56:40.632 [dbservice1] INFO 517a85da-fbd1-11eb-8af5-0242ac110004-mMWStTBy-K=7!ICE-naiw token generate success token=MTYyODgxNjIwMC42MzE5NjI6NTE3YTg1ZGEtZmJkMS0xMWViLThhZjUtMDI0MmFjMTE
  08:56:43.582 [mobservice2] INFO info 53783b8e-fbd1-11eb-bf73-0242ac110004:spFyrBHI write success
  08:56:46.411 [dbservice1] INFO 54d5cf78-fbd1-11eb-b347-0242ac110003-zLGEjrhw-D*Rm7c>0WY.N token generate success token=MTYyODgxNjIwNi40MTEwMzg2OjU0ZDVjZjc4LWZiZDEtMTFlYi1iMzQ3LTAyNDJhYzE
  08:56:50.152 [dbservice1] INFO 573230fe-fbd1-11eb-a5cf-0242ac110004-dMOcrJWb-_!QcK%2x(ubj token generate success token=MTYyODgxNjIxMC4xNTI0MjI6NTczMjMwZmUtZmJkMS0xMWViLWE1Y2YtMDI0MmFjMTE
  08:56:52.097 [mobservice1] INFO info 58956f06-fbd1-11eb-873d-0242ac110003:HfPCXKQO write success
  08:56:55.224 [dbservice1] INFO 5a37b378-fbd1-11eb-90d5-0242ac110003-AnasJGMP-Q?)$%dAI{qjZ token generate success token=MTYyODgxNjIxNS4yMjQyMzYyOjVhMzdiMzc4LWZiZDEtMTFlYi05MGQ1LTAyNDJhYzE
  08:56:57.813 [mobservice1] INFO info 5bfa7614-fbd1-11eb-a3ec-0242ac110003:gEUZdcKS write success
  08:57:00.289 [dbservice1] INFO 5d37c87e-fbd1-11eb-b35e-0242ac110003-OKolGsUM-3O<dZWJ%EuD4 token generate success token=MTYyODgxNjIyMC4yODkwMzk6NWQzN2M4N2UtZmJkMS0xMWViLWIzNWUtMDI0MmFjMTE
  08:57:02.900 [mobservice1] INFO info 5f006c42-fbd1-11eb-b58f-0242ac110003:igXqQZLm write success
  08:57:05.769 [mobservice1] INFO info 60b7affa-fbd1-11eb-b363-0242ac110004:XhnipBWc write success
  08:57:08.595 [mobservice2] INFO info 62577e62-fbd1-11eb-86a2-0242ac110004:GmfKwAOM write success
  08:57:11.166 [mobservice1] INFO info 63eeb27c-fbd1-11eb-99d4-0242ac110003:czZrNOFs write success

## p0463
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:08:01.468Z
```
{"timestamp":1732349281468200000,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"[ undefined, undefined ]"}
```
Same service, the 2 minutes before (oldest first):
  08:08:01.110 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d613f77060008864e90","customerId":"67418d43a437380001deed7e","customer":{"id":null,"firstName":"LTJjUQVL","
  08:08:01.110 [front-end] Order response: {"id":"67418d613f77060008864e90","customerId":"67418d43a437380001deed7e","customer":{"id":null,"firstName":"LTJjUQVL","lastName":"LTJjUQVL","use
  08:08:01.113 [front-end] POST /orders 201 - ms - -  (×2)
  08:08:01.220 [front-end] Request received with body: {}  (×2)
  08:08:01.230 [front-end] Received response: "{\"firstName\":\"ecdYIiITFrTOAd\",\"lastName\":\"ecdYIiITFrTOAd\",\"username\":\"ecdYIiITFrTOAd\",\"id\":\"67418d52a437380001deedbf\",\"_lin
  08:08:01.230 [front-end] GET Request to: http://user/customers/67418d52a437380001deedbf/addresses  (×4)
  08:08:01.239 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418  (×2)
  08:08:01.239 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418d5aa437380001deedd0\",\"_links\":{\"  (×2)
  08:08:01.240 [front-end] [ undefined, undefined ]
  08:08:01.240 [front-end] Posting Order: {"customer":"http://user/customers/67418d52a437380001deedbf","address":"http://user/addresses/67418d59a437380001deedcf","card":"http://user/cards
  08:08:01.285 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d613f77060008864e91","customerId":"67418d52a437380001deedbf","customer":{"id":null,"firstName":"ecdYIiITFrT
  08:08:01.285 [front-end] Order response: {"id":"67418d613f77060008864e91","customerId":"67418d52a437380001deedbf","customer":{"id":null,"firstName":"ecdYIiITFrTOAd","lastName":"ecdYIiIT
  08:08:01.457 [front-end] Received response: "{\"firstName\":\"SpTWPxoZydf\",\"lastName\":\"SpTWPxoZydf\",\"username\":\"SpTWPxoZydf\",\"id\":\"67418d4ea437380001deeda8\",\"_links\":{\"a
All services, 30 seconds either side (sampled):
  08:07:31.691 [catalogue] ts=2024-11-23T08:07:31Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.249578ms  (×62)
  08:07:31.761 [orders] 2024-11-23 08:07:31.761 INFO [orders,c72ea5be08ef1767,38638870dda4924e,false] 8 --- [p-nio-80-exec-7] w.w.s.o.controllers.OrdersController : Sending payment req  (×55)
  08:07:31.795 [queue-master] Received shipment task: 67418d28a437380001deed2d  (×53)
  08:07:31.850 [user] ts=2024-11-23T08:07:31.849862288Z caller=middlewares.go:157 method=Health result=2 took=2.461075ms  (×40)
  08:07:32.334 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×7)
  08:07:32.837 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d443f77060008864e75","customerId":"67418d34a437380001deed56","customer":{"id":null,"firstName":"LgJQTCBCpHY
  08:07:33.324 [front-end] Order response: {"timestamp":1732349253321,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×9)
  08:07:35.729 [front-end] Received response: "{\"firstName\":\"MPhzMatdLY\",\"lastName\":\"MPhzMatdLY\",\"username\":\"MPhzMatdLY\",\"id\":\"67418d2fa437380001deed47\",\"_links\":{\"addr
  08:07:36.922 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×7)
  08:07:39.202 [front-end] Posting Customer: {"username":"CJuDVJLw","password":"QeyTygQ","email":"CJuDVJLw@gmail.com","firstName":"CJuDVJLw","lastName":"CJuDVJLw"}
  08:07:42.658 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d4e3f77060008864e7c","customerId":"67418d40a437380001deed78","customer":{"id":null,"firstName":"jymMgFv","l
  08:07:45.178 [front-end] Order response: {"id":"67418d513f77060008864e7f","customerId":"67418d3ca437380001deed6d","customer":{"id":null,"firstName":"ZUieOH","lastName":"ZUieOH","usernam
  08:07:49.245 [front-end] Received response: "{\"firstName\":\"bRucIekCtFCItEH\",\"lastName\":\"bRucIekCtFCItEH\",\"username\":\"bRucIekCtFCItEH\",\"id\":\"67418d3ea437380001deed77\",\"_
  08:07:50.928 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×6)
  08:07:54.705 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d5a3f77060008864e86","customerId":"67418d49a437380001deed9d","customer":{"id":null,"firstName":"dipPawwwWc"
  08:07:56.936 [front-end] Posting Customer: {"username":"GcMmQDuDu","password":"WEiNmNMXx","email":"GcMmQDuDu@gmail.com","firstName":"GcMmQDuDu","lastName":"GcMmQDuDu"}
  08:07:58.831 [front-end] Posting Customer: {"username":"Zdjpo","password":"QsivDxAxl","email":"Zdjpo@gmail.com","firstName":"Zdjpo","lastName":"Zdjpo"}
  08:08:00.389 [front-end] Order response: {"id":"67418d603f77060008864e8f","customerId":"67418d48a437380001deed97","customer":{"id":null,"firstName":"GkxeiSWvRmt","lastName":"GkxeiSWvRmt
  08:08:02.083 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d623f77060008864e93","customerId":"67418d4ca437380001deeda2","customer":{"id":null,"firstName":"pedsTnZgLDP
  08:08:06.382 [front-end] Posting Customer: {"username":"QvqEOSzLHrufB","password":"sXuLJiBIz","email":"QvqEOSzLHrufB@gmail.com","firstName":"QvqEOSzLHrufB","lastName":"QvqEOSzLHrufB"}
  08:08:10.270 [front-end] Posting Customer: {"username":"cTunMkHBPLATsjP","password":"VuaXoDGWY","email":"cTunMkHBPLATsjP@gmail.com","firstName":"cTunMkHBPLATsjP","lastName":"cTunMkHBPLA
  08:08:12.050 [user] ts=2024-11-23T08:08:12.050093569Z caller=middlewares.go:46 method=Register username=dSmuN email=dSmuN@gmail.com took=2.346572ms
  08:08:16.000 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d6f3f77060008864e9a","customerId":"67418d5ba437380001deedd2","customer":{"id":null,"firstName":"NiPPlOIIuQN
  08:08:20.034 [front-end] Received response: "{\"firstName\":\"Zdjpo\",\"lastName\":\"Zdjpo\",\"username\":\"Zdjpo\",\"id\":\"67418d5ea437380001deedd6\",\"_links\":{\"addresses\":{\"href
  08:08:24.260 [front-end] Received response: "{\"firstName\":\"IrAHbNtAxV\",\"lastName\":\"IrAHbNtAxV\",\"username\":\"IrAHbNtAxV\",\"id\":\"67418d61a437380001deeddc\",\"_links\":{\"addr
  08:08:26.353 [front-end] Received response: "{\"firstName\":\"CCDNavUFFLkbCuy\",\"lastName\":\"CCDNavUFFLkbCuy\",\"username\":\"CCDNavUFFLkbCuy\",\"id\":\"67418d69a437380001deedec\",\"_
  08:08:27.344 [front-end] Posting Customer: {"username":"LfcOjMwJvBPrdSs","password":"uJmbj","email":"LfcOjMwJvBPrdSs@gmail.com","firstName":"LfcOjMwJvBPrdSs","lastName":"LfcOjMwJvBPrdSs
  08:08:29.783 [front-end] Received response: "{\"firstName\":\"JXuYeaZNbme\",\"lastName\":\"JXuYeaZNbme\",\"username\":\"JXuYeaZNbme\",\"id\":\"67418d65a437380001deede5\",\"_links\":{\"a

## p0068
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T09:00:51.495Z
```
{"service":"dbservice2","message":"2021-08-13 09:00:51,495 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | 3589560d375f0fd1 | e7109332-fbd1-11eb-801a-0242ac110004-xVDzUigO-B^s:FwmVgy>_ token generate success token=MTYyODgxNjQ1MS40OTQ2NzEzOmU3MTA5MzMyLWZiZDEtMTFlYi04MDFhLTAyNDJhYzExMDAwNHhWRHpVaWdPQl5zOkZ3bVZneT5fOjE2Mjg4MTY1MTEuNDk0NjgyODo4M2JkMmMzYjk2OTRkODI1ODRkNmNjZTY3NDU1ZmI3ZA=="}
```
Same service, the 2 minutes before (oldest first):
  09:00:38.618 [dbservice2] INFO df553c9c-fbd1-11eb-98b1-0242ac110004-VUzqydWL-cMUr#t?x4mQV token generate success token=MTYyODgxNjQzOC42MTc3MDQ5OmRmNTUzYzljLWZiZDEtMTFlYi05OGIxLTAyNDJhYzE
  09:00:39.965 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  09:00:39.966 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  09:00:40.029 [dbservice2] INFO query = select passwards from username_table where user_name='cwpAkUMO'  (×5)
  09:00:40.110 [dbservice2] INFO e0370df2-fbd1-11eb-a653-0242ac110004-cwpAkUMO-a)qtpDIghOB2 token generate success token=MTYyODgxNjQ0MC4xMDk0OTQyOmUwMzcwZGYyLWZiZDEtMTFlYi1hNjUzLTAyNDJhYzE
  09:00:47.171 [dbservice2] INFO e4763ad2-fbd1-11eb-b94a-0242ac110004-Jcofhzdp-#N?Ss5kvhTH7 token generate success token=MTYyODgxNjQ0Ny4xNzA3NDk0OmU0NzYzYWQyLWZiZDEtMTFlYi1iOTRhLTAyNDJhYzE
  09:00:48.146 [dbservice2] INFO e50cfb8e-fbd1-11eb-8330-0242ac110004-hLXtpSzb-KxJ1VOoDm#-l token generate success token=MTYyODgxNjQ0OC4xNDU2NzU3OmU1MGNmYjhlLWZiZDEtMTFlYi04MzMwLTAyNDJhYzE
  09:00:50.728 [dbservice2] INFO e68b9b82-fbd1-11eb-a978-0242ac110004-JKhDNmCb-yMn!G#EL?u18 token generate success token=MTYyODgxNjQ1MC43Mjc3MTQ1OmU2OGI5YjgyLWZiZDEtMTFlYi1hOTc4LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  09:00:22.742 [webservice2] ERROR unknown error occurred, status_code == 200, message:{'message': 'redis write success, keys=d00872e0-fbd1-11eb-b591-0242ac110004, value=', 'status_code': 2  (×2)
  09:00:22.943 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×38)
  09:00:23.098 [mobservice1] INFO info d6578924-fbd1-11eb-b600-0242ac110003:nRDMHcrY write success
  09:00:23.253 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': 'd6578924-fbd1-11eb-b600-0242ac110003', 'user_id': 'nRDMHcrY'}  (×79)
  09:00:23.438 [dbservice1] INFO query = select passwards from username_table where user_name='nRDMHcrY'  (×47)
  09:00:23.772 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×41)
  09:00:24.222 [dbservice2] INFO query = select passwards from username_table where user_name='nfPDGSVr'  (×27)
  09:00:26.668 [mobservice2] INFO info d86f6056-fbd1-11eb-a497-0242ac110004:jdpqWsnu write success
  09:00:26.834 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×45)
  09:00:32.824 [dbservice2] INFO dbd0fdb8-fbd1-11eb-af31-0242ac110003-LxiphWgj-Y&VDZelm_>vj token generate success token=MTYyODgxNjQzMi44MjM4ODE6ZGJkMGZkYjgtZmJkMS0xMWViLWFmMzEtMDI0MmFjMTE
  09:00:36.341 [mobservice2] INFO info de32b3d0-fbd1-11eb-b7a4-0242ac110004:HRlmyonZ write success
  09:00:38.873 [mobservice1] INFO info dfb86524-fbd1-11eb-9394-0242ac110004:saJCEzRp write success
  09:00:41.527 [dbservice1] INFO e1094006-fbd1-11eb-bc1f-0242ac110004-AsKCtDoY-n2BPkW(-x&s# token generate success token=MTYyODgxNjQ0MS41MjcwNDMzOmUxMDk0MDA2LWZiZDEtMTFlYi1iYzFmLTAyNDJhYzE
  09:00:44.135 [dbservice1] INFO e29bf8fa-fbd1-11eb-abd9-0242ac110004-efoEbcGO-4$CKh&?eZY0N token generate success token=MTYyODgxNjQ0NC4xMzQ3NTEzOmUyOWJmOGZhLWZiZDEtMTFlYi1hYmQ5LTAyNDJhYzE
  09:00:47.391 [dbservice1] INFO e482386e-fbd1-11eb-aec7-0242ac110003-iBxJIdNQ-&20pUS%?J1T. token generate success token=MTYyODgxNjQ0Ny4zOTA4NDUzOmU0ODIzODZlLWZiZDEtMTFlYi1hZWM3LTAyNDJhYzE
  09:00:49.897 [dbservice1] INFO e5fc202e-fbd1-11eb-87d1-0242ac110003-vpUgXqzC-iQ9Zu4A?U^<5 token generate success token=MTYyODgxNjQ0OS44OTY4NjU2OmU1ZmMyMDJlLWZiZDEtMTFlYi04N2QxLTAyNDJhYzE
  09:00:52.457 [dbservice1] INFO e783507a-fbd1-11eb-aed3-0242ac110003-QvNLTxkS-RZxlh$^b6pnw token generate success token=MTYyODgxNjQ1Mi40NTY2NTc2OmU3ODM1MDdhLWZiZDEtMTFlYi1hZWQzLTAyNDJhYzE
  09:00:54.947 [dbservice1] INFO e90ed2de-fbd1-11eb-a65d-0242ac110003-pVIaJPSL-/6iJQ_4ro#jO token generate success token=MTYyODgxNjQ1NC45NDcwMTAzOmU5MGVkMmRlLWZiZDEtMTFlYi1hNjVkLTAyNDJhYzE
  09:00:56.939 [mobservice1] INFO info ea8b7a54-fbd1-11eb-97f4-0242ac110004:rPLoqHhe write success
  09:00:59.095 [dbservice1] INFO eb8ad92c-fbd1-11eb-af09-0242ac110003-AJgiBDVM-N4g%Kh#Z)zj? token generate success token=MTYyODgxNjQ1OS4wOTQ3NDE6ZWI4YWQ5MmMtZmJkMS0xMWViLWFmMDktMDI0MmFjMTE
  09:01:01.282 [dbservice1] INFO ecd30ce6-fbd1-11eb-99a5-0242ac110004-JkvHOUxm-rOwA5m{>N7*E token generate success token=MTYyODgxNjQ2MS4yODIzNzg6ZWNkMzBjZTYtZmJkMS0xMWViLTk5YTUtMDI0MmFjMTE
  09:01:03.880 [dbservice1] INFO ee5e9a12-fbd1-11eb-8d94-0242ac110004-LmHpecgO-{$XO7}iZEDzn token generate success token=MTYyODgxNjQ2My44ODAyNDc4OmVlNWU5YTEyLWZiZDEtMTFlYi04ZDk0LTAyNDJhYzE
  09:01:06.271 [dbservice1] INFO efd74920-fbd1-11eb-bebf-0242ac110003-DQJsnMlT-Nc3Z_Ei.#d7& token generate success token=MTYyODgxNjQ2Ni4yNzA4NjM4OmVmZDc0OTIwLWZiZDEtMTFlYi1iZWJmLTAyNDJhYzE
  09:01:08.512 [mobservice2] INFO info f15add16-fbd1-11eb-80dd-0242ac110003:pKzgewir write success
  09:01:10.743 [mobservice1] INFO info f2c1acc0-fbd1-11eb-a2d7-0242ac110004:CkWFaQYZ write success
  09:01:13.769 [dbservice2] INFO f4505f8c-fbd1-11eb-ad17-0242ac110004-QvNLTxkS-RZxlh$^b6pnw token generate success token=MTYyODgxNjQ3My43Njg1NzE2OmY0NTA1ZjhjLWZiZDEtMTFlYi1hZDE3LTAyNDJhYzE
  09:01:15.913 [mobservice1] INFO info f5d25572-fbd1-11eb-b648-0242ac110004:SDgLpeFn write success
  09:01:18.543 [mobservice2] INFO info f750acb4-fbd1-11eb-b88e-0242ac110003:ITinMyWu write success
  09:01:21.019 [mobservice1] INFO info f8d07a9c-fbd1-11eb-95e9-0242ac110003:ceZjduVy write success

## p0554
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-ui-dashboard, 2024-12-07T18:22:21.341Z
```
{"timestamp":1733595741341477000,"container_name":"ts-ui-dashboard","pod_name":"ts-ui-dashboard-667c5cdd98-x99xl","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"127.0.0.1 - - [08/Dec/2024:02:22:21 +0800] \"GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1\" 200 3056 \"-\" \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36\""}
```
Same service, the 2 minutes before (oldest first):
  18:22:11.059 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:22:11 +0800] "POST /api/v1/users/login HTTP/1.1" 200 353 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×7)
  18:22:11.261 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:22:11 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×4)
  18:22:11.516 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:22:11 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 343 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×3)
  18:22:14.282 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:22:14 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×6)
All services, 30 seconds either side (sampled):
  18:21:52.686 [ts-auth-service] 2024-12-07 18:21:52.685 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×11)
  18:21:52.942 [ts-travel-service] 2024-12-07 18:21:52.942 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×3)
  18:21:55.703 [ts-auth-service] 2024-12-07 18:21:55.703 INFO 1 --- [io-12340-exec-9] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×13)
  18:21:55.990 [ts-price-service] 2024-12-07 18:21:55.990 INFO 1 --- [io-16579-exec-1] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×24)
  18:21:56.185 [ts-seat-service] 2024-12-07 18:21:56.185 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×31)
  18:21:56.399 [ts-travel2-service] 2024-12-07 18:21:56.399 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6  (×17)
  18:21:56.705 [ts-order-other-service] 2024-12-07 18:21:56.704 INFO 1 --- [io-12032-exec-8] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×22)
  18:21:57.577 [ts-basic-service] 2024-12-07 18:21:57.577 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×3)
  18:21:59.050 [ts-travel-service] 2024-12-07 18:21:59.050 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×72)
  18:21:59.110 [ts-basic-service] 2024-12-07 18:21:59.110 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×2)
  18:21:59.201 [ts-seat-service] 2024-12-07 18:21:59.201 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes
  18:21:59.350 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:21:59 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 339 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×3)
  18:21:59.406 [ts-security-service] 2024-12-07 18:21:59.405 INFO 1 --- [io-11188-exec-9] security.service.SecurityServiceImpl : [Security Service][Get Order Num Info]  (×2)
  18:21:59.462 [ts-preserve-service] 2024-12-07 18:21:59.462 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Contacts Id: d14da0ec-da93-46c3-842d-23f  (×2)
  18:21:59.606 [ts-basic-service] 2024-12-07 18:21:59.605 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×4)
  18:22:00.192 [ts-seat-service] 2024-12-07 18:22:00.192 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService distributeSeat] The result of getRouteResult is Success
  18:22:00.294 [ts-order-service] 2024-12-07 18:22:00.294 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 50.0  (×2)
  18:22:01.343 [ts-preserve-other-service] 2024-12-07 18:22:01.342 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Verify Login] Success
  18:22:01.394 [ts-security-service] 2024-12-07 18:22:01.394 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service] Max In One Hour: 2147483647 Max Not Use: 21474836
  18:22:01.528 [ts-order-other-service] 2024-12-07 18:22:01.527 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Stations name list is : Response(status=1, msg=Success, data=[Shang H
  18:22:01.779 [ts-preserve-other-service] 2024-12-07 18:22:01.779 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Check tickets num
  18:22:02.241 [ts-preserve-other-service] 2024-12-07 18:22:02.240 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order] Order Travel Date: Sat Dec 07 00:00:00
  18:22:02.311 [ts-preserve-other-service] 2024-12-07 18:22:02.311 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Service][Add Assurance Type For Order]
  18:22:03.530 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:22:03 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 200 14819 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) App  (×2)
  18:22:17.869 [ts-admin-basic-info-service] 2024-12-07 18:22:17.869 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  18:22:25.302 [ts-auth-service] 2024-12-07 18:22:25.302 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×2)
  18:22:29.768 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:22:29.767+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359574
  18:22:34.612 [ts-seat-service] 2024-12-07 18:22:34.611 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat
  18:22:36.042 [ts-travel-service] 2024-12-07 18:22:36.042 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:00:00 GMT 2013  (×6)
  18:22:42.131 [ts-payment-mongo] {"t":{"$date":"2024-12-07T18:22:42.131+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359576

## p0155
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:44:28.550Z
```
{"timestamp":1731908668550687500,"container_name":"adservice","pod_name":"adservice-b9bcc6cc9-sdkf5","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"received ad request (context_words=[accessories])"}
```
Same service, the 2 minutes before (oldest first):
  05:44:22.556 [adservice] received ad request (context_words=[kitchen])  (×8)
  05:44:23.172 [adservice] received ad request (context_words=[])  (×5)
  05:44:23.445 [adservice] received ad request (context_words=[decor, home])
  05:44:23.566 [adservice] received ad request (context_words=[clothing, tops])  (×3)
  05:44:26.727 [adservice] received ad request (context_words=[hair, beauty])
  05:44:27.163 [adservice] received ad request (context_words=[footwear])
  05:44:27.997 [adservice] received ad request (context_words=[accessories])
All services, 30 seconds either side (sampled):
  05:43:58.656 [frontend] request started  (×266)
  05:43:58.664 [cartservice] GetCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×220)
  05:43:58.689 [adservice] received ad request (context_words=[accessories])  (×22)
  05:43:59.373 [frontend] ENV_PLATFORM is: aws  (×28)
  05:44:00.114 [adservice] received ad request (context_words=[footwear])  (×12)
  05:44:00.122 [cartservice] AddItemAsync called with userId=fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a, productId=L9ECAV7KIM, quantity=10000000000  (×27)
  05:44:00.131 [frontend] placing order  (×11)
  05:44:00.139 [shippingservice] [GetQuote] completed request  (×57)
  05:44:00.156 [checkoutservice] payment went through (transaction_id: d8844b85-6a60-4afa-9891-85f3fb265b01)  (×11)
  05:44:00.161 [cartservice] EmptyCartAsync called with userId=fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a  (×11)
  05:44:00.169 [frontend] order placed  (×11)
  05:44:06.143 [adservice] received ad request (context_words=[decor, home])  (×16)
  05:44:06.827 [checkoutservice] [PlaceOrder] user_id="acc735c5-72d0-48e6-b237-46a63eac4c4d" user_currency="JPY"  (×3)
  05:44:06.855 [emailservice] A request to send order confirmation email to nicholaswilson@example.com has been received.
  05:44:08.595 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"12","nanos":30138876},"credit_card":{"credit_card_number":"4473695978471321
  05:44:08.608 [checkoutservice] order confirmation email sent to "martinezphillip@example.org"
  05:44:12.838 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', 'OLJCESPC7Z', '0PUK6V6EV0']  (×3)
  05:44:16.516 [paymentservice] Transaction processed: visa ending 4161 Amount: GBP6.836535161  (×3)
  05:44:20.694 [emailservice] A request to send order confirmation email to jacquelinewilliams@example.org has been received.
  05:44:22.602 [checkoutservice] order confirmation email sent to "ryankristin@example.org"
  05:44:41.950 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="USD"
  05:44:41.977 [emailservice] A request to send order confirmation email to youngjessica@example.net has been received.
  05:44:53.779 [checkoutservice] order confirmation email sent to "jacksonrenee@example.org"

## p0327
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:21:08.790Z
```
{"timestamp":1732245668790995000,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:21:08.790  INFO [carts,,,] 7 --- [           main] o.s.j.e.a.AnnotationMBeanExporter        : Registering beans for JMX exposure on startup"}
```
Same service, the 2 minutes before (oldest first):
  03:21:00.086 [carts] 2024-11-22 03:21:00.086 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframewo
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applicatio
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public jav
  03:21:03.084 [carts] 2024-11-22 03:21:03.083 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/
  03:21:03.084 [carts] 2024-11-22 03:21:03.084 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  03:21:03.086 [carts] 2024-11-22 03:21:03.085 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applicatio
  03:21:03.086 [carts] 2024-11-22 03:21:03.086 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.s
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto 
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public j
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  03:21:03.184 [carts] 2024-11-22 03:21:03.183 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces
  03:21:03.285 [carts] 2024-11-22 03:21:03.285 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/
  03:21:06.490 [carts] 2024-11-22 03:21:06.489 INFO [carts,,,] 7 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
All services, 30 seconds either side (sampled):
  03:20:39.075 [front-end] Posting Customer: {"username":"ELXzX","password":"iajeZG","email":"ELXzX@gmail.com","firstName":"ELXzX","lastName":"ELXzX"}
  03:20:39.646 [user] ts=2024-11-22T03:20:39.646147266Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff87fb0df5c00019b1f03 took=1.919577ms  (×57)
  03:20:39.906 [catalogue] ts=2024-11-22T03:20:39Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=4.413476  (×47)
  03:20:41.184 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff  (×54)
  03:20:42.525 [front-end] Posting Customer: {"username":"jVIVRgJfOAq","password":"zWZXxq","email":"jVIVRgJfOAq@gmail.com","firstName":"jVIVRgJfOAq","lastName":"jVIVRgJfOAq"}
  03:20:43.389 [carts] 2024-11-22 03:20:43.388 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[GET],produces=[applicat
  03:20:48.920 [front-end] Posting Customer: {"username":"DnjBelnPao","password":"eQMYAKREBx","email":"DnjBelnPao@gmail.com","firstName":"DnjBelnPao","lastName":"DnjBelnPao"}
  03:20:51.502 [front-end] Received response: "{\"firstName\":\"znIVGAMLgnSste\",\"lastName\":\"znIVGAMLgnSste\",\"username\":\"znIVGAMLgnSste\",\"id\":\"673ff880b0df5c00019b1f04\",\"_lin
  03:20:55.766 [front-end] Posting Customer: {"username":"PvCLeeg","password":"pTqmeIPqX","email":"PvCLeeg@gmail.com","firstName":"PvCLeeg","lastName":"PvCLeeg"}
  03:20:59.661 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×6)
  03:20:59.783 [carts] 2024-11-22 03:20:59.783 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal
  03:20:59.886 [carts] 2024-11-22 03:20:59.885 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applicati  (×2)
  03:21:02.589 [user] ts=2024-11-22T03:21:02.589004338Z caller=middlewares.go:46 method=Register username=UFhesIA email=UFhesIA@gmail.com took=1.127131ms
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  03:21:04.514 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×2)
  03:21:08.987 [carts] 2024-11-22 03:21:08.987 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  03:21:11.490 [user] ts=2024-11-22T03:21:11.48978732Z caller=middlewares.go:46 method=Register username=onbFNMM email=onbFNMM@gmail.com took=993.598µs
  03:21:14.059 [front-end] Received response: "{\"firstName\":\"bDjuXlWHATfWj\",\"lastName\":\"bDjuXlWHATfWj\",\"username\":\"bDjuXlWHATfWj\",\"id\":\"673ff89cb0df5c00019b1f51\",\"_links\
  03:21:16.220 [front-end] Posting Customer: {"username":"XSDCLJKgyLoxe","password":"WVMgfuZdos","email":"XSDCLJKgyLoxe@gmail.com","firstName":"XSDCLJKgyLoxe","lastName":"XSDCLJKgyLoxe"}
  03:21:18.596 [orders] 2024-11-22 03:21:18.596 INFO [orders,40393c2387463fc4,20a8cb1f4ece78de,false] 6 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Sending payment req  (×17)
  03:21:18.619 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8aed94b9000069b438c","customerId":"673ff89cb0df5c00019b1f51","customer":{"id":null,"firstName":"bDjuXlWHATf
  03:21:19.233 [front-end] Received response: "{\"firstName\":\"cfTPDbfduekTBf\",\"lastName\":\"cfTPDbfduekTBf\",\"username\":\"cfTPDbfduekTBf\",\"id\":\"673ff896b0df5c00019b1f3c\",\"_lin
  03:21:19.905 [front-end] Order response: {"id":"673ff8afd94b9000069b4393","customerId":"673ff89eb0df5c00019b1f54","customer":{"id":null,"firstName":"gKGbBfBuFal","lastName":"gKGbBfBuFal
  03:21:20.783 [carts] 2024-11-22 03:21:20.783 INFO [carts,c68cb8218e3d30a3,e9e627c1a2386c43,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×11)
  03:21:23.285 [front-end] Posting Customer: {"username":"BHMHa","password":"KrLeziWwdr","email":"BHMHa@gmail.com","firstName":"BHMHa","lastName":"BHMHa"}
  03:21:28.217 [front-end] Received response: "{\"firstName\":\"MszyyqkjNcAvcB\",\"lastName\":\"MszyyqkjNcAvcB\",\"username\":\"MszyyqkjNcAvcB\",\"id\":\"673ff8a4b0df5c00019b1f73\",\"_lin
  03:21:32.503 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8bcd94b9000069b439e","customerId":"673ff8a0b0df5c00019b1f63","customer":{"id":null,"firstName":"vpxxpRNxF",
  03:21:34.413 [front-end] Order response: {"id":"673ff8bed94b9000069b43a0","customerId":"673ff8a6b0df5c00019b1f7f","customer":{"id":null,"firstName":"BXlkiHWqBVYl","lastName":"BXlkiHWqBV
  03:21:36.305 [front-end] Order response: {"id":"673ff8c0d94b9000069b43a2","customerId":"673ff8a7b0df5c00019b1f82","customer":{"id":null,"firstName":"onbFNMM","lastName":"onbFNMM","usern
