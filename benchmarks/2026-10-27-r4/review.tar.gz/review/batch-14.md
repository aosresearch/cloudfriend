## p0364
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:34:59.488Z
```
{"timestamp":1732246499488173600,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /cart 201 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  03:34:58.297 [front-end] POST /cart 201 - ms - -
  03:34:58.462 [front-end] GET /catalogue 200 - ms - -
  03:34:58.616 [front-end] Posting Customer: {"username":"CslXBSyJNe","password":"RlBvNvOe","email":"CslXBSyJNe@gmail.com","firstName":"CslXBSyJNe","lastName":"CslXBSyJNe"}
  03:34:58.622 [front-end] { id: '673ffbe2b0df5c00019b2947' }
  03:34:58.622 [front-end] 673ffbe2b0df5c00019b2947
  03:34:58.622 [front-end] Merging carts for customer id: 673ffbe2b0df5c00019b2947 and session id: Dyf8Qatn1VrdBcswy_tGXy-dGV-jheja
  03:34:58.649 [front-end] Carts merged.
  03:34:58.649 [front-end] set cookie673ffbe2b0df5c00019b2947
  03:34:58.649 [front-end] Sent cookies.
  03:34:58.651 [front-end] POST /register 200 33.411 ms - 33
  03:34:59.000 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffbdab0df5c00019b292b"}
  03:34:59.010 [front-end] POST /addresses 200 - ms - -
  03:34:59.015 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffbdab0df5c00019b292b"}
  03:34:59.024 [front-end] POST /cards 200 - ms - -
  03:34:59.070 [front-end] Attempting to delete cart for user: 673ffbdab0df5c00019b292b
  03:34:59.093 [front-end] User cart deleted with status: 202
  03:34:59.095 [front-end] DELETE /cart 202 - ms - -
  03:34:59.102 [front-end] Attempting to add to cart: {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","quantity":1}
  03:34:59.108 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/
  03:34:59.108 [front-end] POST to carts: http://carts/carts/673ffbdab0df5c00019b292b/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}
All services, 30 seconds either side (sampled):
  03:34:29.488 [carts] 2024-11-22 03:34:29.487 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto 
  03:34:29.668 [front-end] Attempting to delete cart for user: 673ffbbdb0df5c00019b28e4  (×60)
  03:34:30.062 [front-end] GET Request to: http://user/customers/673ffbb0b0df5c00019b28b3/addresses  (×126)
  03:34:30.099 [orders] 2024-11-22 03:34:30.099 ERROR [orders,,,] 6 --- [p-nio-80-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×7)
  03:34:32.783 [user] ts=2024-11-22T03:34:32.783731553Z caller=middlewares.go:46 method=Register username=IIPrnhNEpI email=IIPrnhNEpI@gmail.com took=1.05881ms  (×16)
  03:34:34.255 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×7)
  03:34:35.989 [carts] 2024-11-22 03:34:35.989 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as MB
  03:34:39.389 [carts] 2024-11-22 03:34:39.389 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 140.399 seconds (JVM running for 145.3
  03:34:42.110 [front-end] Received response: "{\"firstName\":\"cBiHCInttKC\",\"lastName\":\"cBiHCInttKC\",\"username\":\"cBiHCInttKC\",\"id\":\"673ffbb8b0df5c00019b28d3\",\"_links\":{\"a
  03:34:43.753 [user] ts=2024-11-22T03:34:43.752934079Z caller=middlewares.go:46 method=Register username=PmNVx email=PmNVx@gmail.com took=1.028895ms
  03:34:44.711 [queue-master] Received shipment task: 673ffbbfb0df5c00019b28eb  (×45)
  03:34:44.803 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffbd4d94b9000069b45e0","customerId":"673ffbb8b0df5c00019b28d3","customer":{"id":null,"firstName":"cBiHCInttKC
  03:34:46.590 [front-end] Posting Customer: {"username":"vkmSdk","password":"PMyWnxIY","email":"vkmSdk@gmail.com","firstName":"vkmSdk","lastName":"vkmSdk"}
  03:34:49.635 [user] ts=2024-11-22T03:34:49.635542898Z caller=middlewares.go:46 method=Register username=knntLVSJylaD email=knntLVSJylaD@gmail.com took=980.363µs  (×11)
  03:34:55.502 [front-end] Posting Customer: {"username":"kILVICxIvRmrJH","password":"lIeFaJsrXG","email":"kILVICxIvRmrJH@gmail.com","firstName":"kILVICxIvRmrJH","lastName":"kILVICxIvRmrJ
  03:34:57.501 [front-end] Order response: {"id":"673ffbe1d94b9000069b45e7","customerId":"673ffbccb0df5c00019b2906","customer":{"id":null,"firstName":"zQvKZ","lastName":"zQvKZ","username"
  03:35:02.054 [front-end] Posting Customer: {"username":"lqUQrQGnN","password":"sCPaoeQ","email":"lqUQrQGnN@gmail.com","firstName":"lqUQrQGnN","lastName":"lqUQrQGnN"}
  03:35:03.611 [front-end] Order response: {"id":"673ffbe7d94b9000069b45ea","customerId":"673ffbcdb0df5c00019b2907","customer":{"id":null,"firstName":"ZpArT","lastName":"ZpArT","username"
  03:35:05.711 [front-end] Received response: "{\"firstName\":\"UHiDlZyxI\",\"lastName\":\"UHiDlZyxI\",\"username\":\"UHiDlZyxI\",\"id\":\"673ffbd1b0df5c00019b290d\",\"_links\":{\"address
  03:35:06.860 [front-end] Order response: {"id":"673ffbead94b9000069b45f1","customerId":"673ffbd9b0df5c00019b2927","customer":{"id":null,"firstName":"knntLVSJylaD","lastName":"knntLVSJyl
  03:35:09.202 [front-end] Posting Customer: {"username":"QgsCM","password":"kzMYhFXEG","email":"QgsCM@gmail.com","firstName":"QgsCM","lastName":"QgsCM"}
  03:35:11.353 [front-end] Order response: {"id":"673ffbefd94b9000069b45f5","customerId":"673ffbd6b0df5c00019b291f","customer":{"id":null,"firstName":"fvyDOKJmytC","lastName":"fvyDOKJmytC
  03:35:14.815 [user] ts=2024-11-22T03:35:14.815537952Z caller=middlewares.go:46 method=Register username=LSjWxIIk email=LSjWxIIk@gmail.com took=1.202194ms
  03:35:17.169 [front-end] Order response: {"id":"673ffbf5d94b9000069b45fb","customerId":"673ffbdfb0df5c00019b2941","customer":{"id":null,"firstName":"kILVICxIvRmrJH","lastName":"kILVICxI
  03:35:20.378 [front-end] Received response: "{\"firstName\":\"azurDGvuuR\",\"lastName\":\"azurDGvuuR\",\"username\":\"azurDGvuuR\",\"id\":\"673ffbddb0df5c00019b2938\",\"_links\":{\"addr
  03:35:22.613 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffbfad94b9000069b4602","customerId":"673ffbe8b0df5c00019b295c","customer":{"id":null,"firstName":"Hgaufvxb","
  03:35:25.129 [front-end] Received response: "{\"firstName\":\"rdUseBbUdto\",\"lastName\":\"rdUseBbUdto\",\"username\":\"rdUseBbUdto\",\"id\":\"673ffbe6b0df5c00019b295a\",\"_links\":{\"a
  03:35:28.654 [orders-db] {"t":{"$date":"2024-11-22T03:35:28.653+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224652

## p0227
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service checkoutservice, 2024-11-18T07:52:05.465Z
```
{"service":"checkoutservice","operation":"hipstershop.EmailService/SendOrderConfirmation","method":"SendOrderConfirmation","status_code":13,"duration_us":3949,"trace_id":"ad076da2a021329c6a13ed0c1841a645","message":"span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 13"}
```
Same service, the 2 minutes before (oldest first):
  07:51:05.082 [checkoutservice] payment went through (transaction_id: d905fa95-82ff-4226-b9a2-47405b8a8697)  (×7)
  07:51:05.095 [checkoutservice] order confirmation email sent to "xclark@example.net"
  07:51:10.580 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="GBP"
  07:51:10.620 [checkoutservice] order confirmation email sent to "mccoyheather@example.com"
  07:51:19.511 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="CAD"  (×2)
  07:51:19.562 [checkoutservice] order confirmation email sent to "sshah@example.org"
  07:51:46.135 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="USD"
  07:51:46.178 [checkoutservice] order confirmation email sent to "cjoseph@example.org"
  07:51:57.628 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="TRY"
  07:51:57.671 [checkoutservice] order confirmation email sent to "brucemitchell@example.org"
  07:52:03.888 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="EUR"
  07:52:03.923 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 13
  07:52:03.946 [checkoutservice] failed to send order confirmation to "roachjames@example.net": rpc error: code = Internal desc = Failed to serialize response!
All services, 30 seconds either side (sampled):
  07:51:36.182 [frontend] request started  (×319)
  07:51:36.189 [cartservice] GetCartAsync called with userId=c216dec4-2181-4773-8cc5-aa587ee59fcc  (×264)
  07:51:36.212 [adservice] received ad request (context_words=[clothing, tops])  (×21)
  07:51:36.220 [cartservice] AddItemAsync called with userId=c216dec4-2181-4773-8cc5-aa587ee59fcc, productId=66VCHSJNUP, quantity=2  (×31)
  07:51:36.251 [shippingservice] [GetQuote] completed request  (×78)
  07:51:36.770 [frontend] home  (×32)
  07:51:36.962 [adservice] received ad request (context_words=[accessories])  (×33)
  07:51:40.300 [adservice] received ad request (context_words=[footwear])  (×13)
  07:51:46.165 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"634","nanos":320000000},"credit_card":{"credit_card_number":"43957631712654  (×4)
  07:51:46.169 [shippingservice] [ShipOrder] received request  (×11)
  07:51:46.177 [emailservice] A request to send order confirmation email to cjoseph@example.org has been received.
  07:51:48.870 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '66VCHSJNUP']  (×3)
  07:51:57.658 [paymentservice] Transaction processed: visa ending 9776 Amount: TRY11302.658447622
  07:52:00.558 [emailservice] starting the email service in dummy mode.
  07:52:03.888 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="EUR"  (×2)
  07:52:03.923 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 13  (×8)
  07:52:05.431 [checkoutservice] [PlaceOrder] user_id="736a09b5-665e-4823-8520-b8602b0bdbff" user_currency="CAD"  (×3)
  07:52:05.468 [emailservice] A request to send order confirmation email to ccraig@example.com has been received.
  07:52:12.135 [checkoutservice] failed to send order confirmation to "whooper@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:52:17.876 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="JPY"
  07:52:17.912 [emailservice] A request to send order confirmation email to karenmueller@example.net has been received.
  07:52:23.707 [checkoutservice] failed to send order confirmation to "tammyferrell@example.org": rpc error: code = Internal desc = Failed to serialize response!
  07:52:26.984 [emailservice] A request to send order confirmation email to julie62@example.com has been received.
  07:52:30.317 [checkoutservice] failed to send order confirmation to "garciazachary@example.net": rpc error: code = Internal desc = Failed to serialize response!

## p0758
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T06:34:28.632Z
```
{"timestamp":1732257268632724500,"container_name":"carts","pod_name":"carts-78d749cf8c-x7fnt","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Caused by: java.net.ConnectException: Connection refused (Connection refused)\n\tat java.net.PlainSocketImpl.socketConnect(Native Method) ~[na:1.8.0_131]\n\tat java.net.AbstractPlainSocketImpl.doConnect(AbstractPlainSocketImpl.java:350) ~[na:1.8.0_131]\n\tat java.net.AbstractPlainSocketImpl.connectToAddress(AbstractPlainSocketImpl.java:206) ~[na:1.8.0_131]\n\tat java.net.AbstractPlainSocketImpl.connect(Ab…"}
```
Same service, the 2 minutes before (oldest first):
  06:34:14.054 [carts] 2024-11-22 06:34:14.053 INFO [carts,85f08e33478cfdcc,e53a84c5fb874782,false] 7 --- [-nio-80-exec-10] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×3)
  06:34:15.449 [carts] 2024-11-22 06:34:15.449 INFO [carts,9217e9cbc9e26920,796be3259aa59f9a,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  06:34:15.454 [carts] 2024-11-22 06:34:15.454 INFO [carts,9217e9cbc9e26920,796be3259aa59f9a,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
  06:34:15.463 [carts] 2024-11-22 06:34:15.462 INFO [carts,ab75350dfa59eac5,c1360182b055d96d,false] 7 --- [-nio-80-exec-14] w.w.s.cart.controllers.CartsController : Merge carts reques  (×6)
  06:34:16.497 [carts] 2024-11-22 06:34:16.497 INFO [carts,ad4d97235cefe909,f07fc992d872b33b,false] 7 --- [p-nio-80-exec-9] w.w.s.cart.controllers.CartsController : Merge carts reques  (×3)
  06:34:17.645 [carts] 2024-11-22 06:34:17.645 INFO [carts,00c0f043fd5c0534,ec9ab1bee6badbaf,false] 7 --- [-nio-80-exec-17] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  06:34:28.632 [carts] 2024-11-22 06:34:28.632 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Exception in monitor thread while connecting to server carts-db:270
  06:34:28.632 [carts] com.mongodb.MongoSocketOpenException: Exception opening socket at com.mongodb.connection.SocketStream.open(SocketStream.java:63) ~[mongodb-driver-core-3.2.2.jar
All services, 30 seconds either side (sampled):
  06:33:58.632 [carts] 2024-11-22 06:33:58.632 INFO [carts,78a5263619c16dd4,6fcf450d91558801,false] 7 --- [-nio-80-exec-11] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×10)
  06:33:59.014 [front-end] User cart deleted with status: 202  (×54)
  06:33:59.055 [front-end] { id: '674025d7768f35000114f122' }  (×58)
  06:33:59.431 [front-end] Request received with body: {}  (×57)
  06:33:59.460 [user] ts=2024-11-22T06:33:59.460678246Z caller=middlewares.go:134 method=GetCards id=674025ce768f35000114f107 result=1 took=3.795827ms  (×57)
  06:33:59.478 [queue-master] Received shipment task: 674025c5768f35000114f0e6  (×15)
  06:33:59.483 [front-end] Order response: {"id":"674025d7531af4000701df35","customerId":"674025c4768f35000114f0e0","customer":{"id":null,"firstName":"vbEPCUDAuwhGBON","lastName":"vbEPCUD
  06:34:00.672 [user] ts=2024-11-22T06:34:00.672218502Z caller=middlewares.go:157 method=Health result=2 took=2.458409ms  (×40)
  06:34:01.849 [front-end] POST to carts: http://carts/carts/674025cf768f35000114f10e/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×29)
  06:34:04.887 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×7)
  06:34:06.719 [front-end] Order response: {"id":"674025de531af4000701df3a","customerId":"674025d1768f35000114f112","customer":{"id":null,"firstName":"SkVfq","lastName":"SkVfq","username"
  06:34:08.406 [front-end] Posting Customer: {"username":"eoblhrwisKUWKh","password":"nMmpoT","email":"eoblhrwisKUWKh@gmail.com","firstName":"eoblhrwisKUWKh","lastName":"eoblhrwisKUWKh"}
  06:34:10.978 [front-end] Posting Customer: {"username":"CLvztavBqZzMs","password":"lGhVH","email":"CLvztavBqZzMs@gmail.com","firstName":"CLvztavBqZzMs","lastName":"CLvztavBqZzMs"}
  06:34:13.425 [front-end] Posting Customer: {"username":"MamxkCrkxKz","password":"lmOMA","email":"MamxkCrkxKz@gmail.com","firstName":"MamxkCrkxKz","lastName":"MamxkCrkxKz"}
  06:34:15.867 [front-end] Posting Customer: {"username":"cXgorIbNVx","password":"bzMNhg","email":"cXgorIbNVx@gmail.com","firstName":"cXgorIbNVx","lastName":"cXgorIbNVx"}
  06:34:17.430 [front-end] Received response: "{\"firstName\":\"aQOvOuiac\",\"lastName\":\"aQOvOuiac\",\"username\":\"aQOvOuiac\",\"id\":\"674025d6768f35000114f11c\",\"_links\":{\"address
  06:34:19.647 [front-end] Posting Customer: {"username":"XQjfJgjaxN","password":"UoPBmHlpJ","email":"XQjfJgjaxN@gmail.com","firstName":"XQjfJgjaxN","lastName":"XQjfJgjaxN"}
  06:34:23.043 [user] ts=2024-11-22T06:34:23.043299668Z caller=middlewares.go:46 method=Register username=AhzMVmDC email=AhzMVmDC@gmail.com took=2.866068ms
  06:34:24.734 [user] ts=2024-11-22T06:34:24.734421165Z caller=middlewares.go:46 method=Register username=xZPoptlMd email=xZPoptlMd@gmail.com took=2.160575ms
  06:34:29.510 [front-end] Posting Customer: {"username":"rihiQz","password":"avnMz","email":"rihiQz@gmail.com","firstName":"rihiQz","lastName":"rihiQz"}
  06:34:32.929 [front-end] Received response: "{\"firstName\":\"GqmiLNPOmuQX\",\"lastName\":\"GqmiLNPOmuQX\",\"username\":\"GqmiLNPOmuQX\",\"id\":\"674025eb768f35000114f153\",\"_links\":{
  06:34:36.347 [front-end] Posting Customer: {"username":"vLgISaAaM","password":"hwUhSOiQ","email":"vLgISaAaM@gmail.com","firstName":"vLgISaAaM","lastName":"vLgISaAaM"}
  06:34:39.439 [user] ts=2024-11-22T06:34:39.439701877Z caller=middlewares.go:46 method=Register username=azefvfVc email=azefvfVc@gmail.com took=2.250605ms
  06:34:41.626 [user] ts=2024-11-22T06:34:41.625907119Z caller=middlewares.go:46 method=Register username=gmzbGrIz email=gmzbGrIz@gmail.com took=2.256599ms
  06:34:43.175 [front-end] Posting Customer: {"username":"UmxVKMRgrrQ","password":"eQpjiqwpK","email":"UmxVKMRgrrQ@gmail.com","firstName":"UmxVKMRgrrQ","lastName":"UmxVKMRgrrQ"}
  06:34:47.285 [front-end] Received response: "{\"firstName\":\"jZGRJq\",\"lastName\":\"jZGRJq\",\"username\":\"jZGRJq\",\"id\":\"674025e8768f35000114f14a\",\"_links\":{\"addresses\":{\"h
  06:34:50.373 [front-end] Received response: "{\"firstName\":\"KRIqomMxJllejCw\",\"lastName\":\"KRIqomMxJllejCw\",\"username\":\"KRIqomMxJllejCw\",\"id\":\"674025ed768f35000114f157\",\"_
  06:34:55.433 [front-end] Received response: "{\"firstName\":\"kmOTTiAmqtM\",\"lastName\":\"kmOTTiAmqtM\",\"username\":\"kmOTTiAmqtM\",\"id\":\"674025fb768f35000114f186\",\"_links\":{\"a
  06:34:57.573 [user] ts=2024-11-22T06:34:57.573437929Z caller=middlewares.go:46 method=Register username=xrtJOcF email=xrtJOcF@gmail.com took=2.004871ms

## p0109
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:11:13.458Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731906673458520000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  05:11:12.685 [frontend] adding to cart
  05:11:12.698 [frontend] request complete  (×6)
  05:11:12.701 [frontend] request started  (×6)
  05:11:12.701 [frontend] view user cart  (×2)
  05:11:12.766 [frontend] placing order
  05:11:12.828 [frontend] order placed
  05:11:12.934 [frontend] serving product page  (×3)
All services, 30 seconds either side (sampled):
  05:10:43.599 [frontend] request started  (×307)
  05:10:43.608 [cartservice] GetCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×246)
  05:10:43.630 [adservice] received ad request (context_words=[accessories])  (×36)
  05:10:43.637 [cartservice] AddItemAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927, productId=OLJCESPC7Z, quantity=7  (×29)
  05:10:43.675 [shippingservice] [GetQuote] completed request  (×74)
  05:10:43.727 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"248","nanos":765608136},"credit_card":{"credit_card_number":"40461242281367
  05:10:43.731 [shippingservice] [ShipOrder] received request  (×9)
  05:10:43.742 [checkoutservice] order confirmation email sent to "orush@example.org"
  05:10:44.046 [adservice] received ad request (context_words=[footwear])  (×11)
  05:10:44.105 [adservice] received ad request (context_words=[kitchen])  (×51)
  05:10:44.831 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="GBP"  (×4)
  05:10:44.866 [emailservice] A request to send order confirmation email to riverarandall@example.net has been received.
  05:10:49.800 [adservice] received ad request (context_words=[clothing, tops])  (×14)
  05:10:50.447 [emailservice] A request to send order confirmation email to sarah43@example.com has been received.
  05:10:53.074 [redis] 1:M 18 Nov 2024 05:10:53.074 * Background saving started by pid 48
  05:10:53.174 [redis] 1:M 18 Nov 2024 05:10:53.174 * Background saving terminated with success
  05:11:07.356 [checkoutservice] order confirmation email sent to "simmonsandrew@example.org"
  05:11:12.767 [checkoutservice] [PlaceOrder] user_id="736a09b5-665e-4823-8520-b8602b0bdbff" user_currency="USD"  (×2)
  05:11:12.826 [emailservice] A request to send order confirmation email to joepennington@example.net has been received.
  05:11:15.317 [checkoutservice] order confirmation email sent to "janetbarrett@example.net"
  05:11:37.152 [paymentservice] Transaction processed: visa ending 1989 Amount: JPY65333.314463477
  05:11:42.136 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="EUR"
  05:11:42.179 [emailservice] A request to send order confirmation email to zthompson@example.org has been received.

## p0150
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T05:40:15.650Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731908415650116600,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-sd8v2","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  05:40:15.479 [currencyservice] Getting supported currencies...  (×3)
  05:40:15.490 [currencyservice] conversion request successful  (×17)
All services, 30 seconds either side (sampled):
  05:39:46.273 [frontend] request started  (×295)
  05:39:46.277 [currencyservice] Getting supported currencies...  (×248)
  05:39:46.289 [currencyservice] conversion request successful  (×650)
  05:39:46.307 [adservice] received ad request (context_words=[kitchen])  (×51)
  05:39:46.879 [frontend] view user cart  (×55)
  05:39:46.907 [shippingservice] [GetQuote] completed request  (×63)
  05:39:47.136 [adservice] received ad request (context_words=[decor, home])  (×18)
  05:39:48.108 [frontend] home  (×32)
  05:39:48.159 [adservice] received ad request (context_words=[])  (×32)
  05:39:48.365 [cartservice] AddItemAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432, productId=LS4PSXUNUM, quantity=9  (×26)
  05:39:50.029 [adservice] received ad request (context_words=[footwear])  (×18)
  05:39:52.721 [frontend] placing order  (×8)
  05:39:52.749 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"243","nanos":978373281},"credit_card":{"credit_card_number":"43703513080820  (×2)
  05:39:52.752 [checkoutservice] payment went through (transaction_id: 6686ffe3-73c3-4660-a1ed-d51478f39572)  (×7)
  05:39:52.753 [shippingservice] [ShipOrder] completed request  (×7)
  05:39:52.764 [emailservice] A request to send order confirmation email to jilllopez@example.net has been received.
  05:39:52.765 [frontend] order placed  (×7)
  05:40:01.824 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="TRY"  (×4)
  05:40:01.867 [paymentservice] Transaction processed: visa ending 0148 Amount: TRY2423.8251247  (×3)
  05:40:01.880 [checkoutservice] order confirmation email sent to "chad79@example.org"
  05:40:12.251 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"330","nanos":955945155},"credit_card":{"credit_card_number":"42233416887305
  05:40:12.264 [emailservice] A request to send order confirmation email to xwilliams@example.net has been received.
  05:40:21.103 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×5)
  05:40:26.590 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13  (×2)
  05:40:26.621 [paymentservice] UnacceptedCreditCard [Error]: Sorry, we cannot process visa_electron credit cards. Only VISA or MasterCard is accepted. at charge (/usr/src/app/charge.js:74:68)
  05:40:26.625 [frontend] request error
  05:40:29.596 [checkoutservice] order confirmation email sent to "ashley65@example.net"
  05:40:31.395 [checkoutservice] order confirmation email sent to "onealkevin@example.org"
  05:40:42.515 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"134479","nanos":313581127},"credit_card":{"credit_card_number":"45724925883
  05:40:42.528 [emailservice] A request to send order confirmation email to patrickstephanie@example.com has been received.  (×2)

## p0753
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T06:22:41.503Z
```
{"timestamp":1732256561503491600,"container_name":"carts","pod_name":"carts-78d749cf8c-x7fnt","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-22 06:22:41.503  INFO [carts,,,] 7 --- [           main] o.s.b.a.e.mvc.EndpointHandlerMapping     : Mapped \"{[/restart || /restart.json],methods=[POST]}\" onto public java.lang.Object org.springframework.cloud.context.restart.RestartMvcEndpoint.invoke()"}
```
Same service, the 2 minutes before (oldest first):
  06:22:38.999 [carts] 2024-11-22 06:22:38.999 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframewor
  06:22:38.999 [carts] 2024-11-22 06:22:38.999 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[text/html]}" onto public 
  06:22:39.204 [carts] 2024-11-22 06:22:39.204 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionHa
  06:22:39.204 [carts] 2024-11-22 06:22:39.204 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframewo
  06:22:41.310 [carts] 2024-11-22 06:22:41.304 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  06:22:41.310 [carts] 2024-11-22 06:22:41.305 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applicatio
  06:22:41.406 [carts] 2024-11-22 06:22:41.404 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  06:22:41.406 [carts] 2024-11-22 06:22:41.404 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  06:22:41.498 [carts] 2024-11-22 06:22:41.406 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/
  06:22:41.499 [carts] 2024-11-22 06:22:41.499 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces
  06:22:41.500 [carts] 2024-11-22 06:22:41.500 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]
  06:22:41.500 [carts] 2024-11-22 06:22:41.500 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  06:22:41.500 [carts] 2024-11-22 06:22:41.500 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.s
  06:22:41.501 [carts] 2024-11-22 06:22:41.500 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  06:22:41.501 [carts] 2024-11-22 06:22:41.501 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public jav
  06:22:41.501 [carts] 2024-11-22 06:22:41.501 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto 
  06:22:41.501 [carts] 2024-11-22 06:22:41.501 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  06:22:41.502 [carts] 2024-11-22 06:22:41.502 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  06:22:41.502 [carts] 2024-11-22 06:22:41.502 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/
  06:22:41.503 [carts] 2024-11-22 06:22:41.502 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
All services, 30 seconds either side (sampled):
  06:22:13.052 [front-end] Carts merged.  (×58)
  06:22:13.332 [user] ts=2024-11-22T06:22:13.332615098Z caller=middlewares.go:75 method=GetUsers id=674022fe768f35000114e86c result=1 took=2.373538ms  (×236)
  06:22:13.367 [front-end] DELETE /cart 503 - ms - -  (×65)
  06:22:13.749 [front-end] Posting Customer: {"username":"orDZMANZhvut","password":"XJAoA","email":"orDZMANZhvut@gmail.com","firstName":"orDZMANZhvut","lastName":"orDZMANZhvut"}
  06:22:15.062 [catalogue] ts=2024-11-22T06:22:15Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=3.42314ms  (×58)
  06:22:18.744 [front-end] Posting Customer: {"username":"KPAuI","password":"BkBFQ","email":"KPAuI@gmail.com","firstName":"KPAuI","lastName":"KPAuI"}
  06:22:21.510 [front-end] Received response: "{\"firstName\":\"cqLffvuT\",\"lastName\":\"cqLffvuT\",\"username\":\"cqLffvuT\",\"id\":\"67402308768f35000114e887\",\"_links\":{\"addresses\
  06:22:25.401 [carts] 2024-11-22 06:22:25.401 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  06:22:27.504 [front-end] Received response: "{\"firstName\":\"RrWHimnimv\",\"lastName\":\"RrWHimnimv\",\"username\":\"RrWHimnimv\",\"id\":\"67402310768f35000114e899\",\"_links\":{\"addr
  06:22:30.202 [carts] 2024-11-22 06:22:30.202 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframewo  (×2)
  06:22:33.567 [front-end] Posting Customer: {"username":"BSCLSbhlC","password":"KNnUE","email":"BSCLSbhlC@gmail.com","firstName":"BSCLSbhlC","lastName":"BSCLSbhlC"}
  06:22:37.981 [front-end] Posting Customer: {"username":"WYDtQSJYTlTIwYd","password":"jlDeHije","email":"WYDtQSJYTlTIwYd@gmail.com","firstName":"WYDtQSJYTlTIwYd","lastName":"WYDtQSJYTlTI
  06:22:38.800 [carts] 2024-11-22 06:22:38.800 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[GET],produces=[application
  06:22:38.900 [carts] 2024-11-22 06:22:38.900 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applicat
  06:22:39.327 [front-end] Posting Customer: {"username":"gZCBojN","password":"PeMJtJIhi","email":"gZCBojN@gmail.com","firstName":"gZCBojN","lastName":"gZCBojN"}
  06:22:41.310 [carts] 2024-11-22 06:22:41.304 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  06:22:41.501 [carts] 2024-11-22 06:22:41.501 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  06:22:44.376 [front-end] Posting Customer: {"username":"VfTLY","password":"gXMwOkd","email":"VfTLY@gmail.com","firstName":"VfTLY","lastName":"VfTLY"}
  06:22:46.904 [carts] 2024-11-22 06:22:46.904 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  06:22:48.802 [carts] 2024-11-22 06:22:48.802 INFO [carts,,,] 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  06:22:51.205 [carts] 2024-11-22 06:22:51.205 INFO [carts,,,] 7 --- [p-nio-80-exec-5] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization complet
  06:22:52.545 [front-end] Posting Customer: {"username":"UtTLxbuOgESohy","password":"UvlBRxjc","email":"UtTLxbuOgESohy@gmail.com","firstName":"UtTLxbuOgESohy","lastName":"UtTLxbuOgESohy"
  06:22:55.106 [orders] 2024-11-22 06:22:55.106 INFO [orders,89534d9d5be2c623,775f5e4e129d2d47,false] 7 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Sending payment req  (×16)
  06:22:55.200 [carts] 2024-11-22 06:22:55.199 INFO [carts,a23e788bcb0e6691,0deadd679eb47a7e,false] 7 --- [p-nio-80-exec-6] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{reposi  (×24)
  06:22:55.367 [front-end] Order response: {"statusCode":201,"body":{"id":"6740233f531af4000701dcd8","customerId":"6740232d768f35000114e8f5","customer":{"id":null,"firstName":"GsgdRh","la
  06:22:56.925 [front-end] Posting Customer: {"username":"CvmpdtcCkyH","password":"sygMppejd","email":"CvmpdtcCkyH@gmail.com","firstName":"CvmpdtcCkyH","lastName":"CvmpdtcCkyH"}
  06:23:02.543 [front-end] Posting Customer: {"username":"kmfiXHPThEYI","password":"IugozVt","email":"kmfiXHPThEYI@gmail.com","firstName":"kmfiXHPThEYI","lastName":"kmfiXHPThEYI"}
  06:23:05.017 [front-end] Order response: {"id":"67402349531af4000701dcdf","customerId":"67402333768f35000114e90c","customer":{"id":null,"firstName":"msSICePALTl","lastName":"msSICePALTl
  06:23:08.647 [front-end] Received response: "{\"firstName\":\"gZolnPzYripJ\",\"lastName\":\"gZolnPzYripJ\",\"username\":\"gZolnPzYripJ\",\"id\":\"67402335768f35000114e915\",\"_links\":{

## p0204
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T06:58:18.252Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731913098252400400,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Getting supported currencies..."}
```
Same service, the 2 minutes before (oldest first):
  06:58:17.674 [currencyservice] conversion request successful  (×14)
  06:58:17.708 [currencyservice] Getting supported currencies...  (×6)
All services, 30 seconds either side (sampled):
  06:57:48.296 [frontend] request started  (×339)
  06:57:48.305 [cartservice] GetCartAsync called with userId=acc735c5-72d0-48e6-b237-46a63eac4c4d  (×279)
  06:57:48.328 [adservice] received ad request (context_words=[decor, home])  (×17)
  06:57:48.469 [frontend] ENV_PLATFORM is: aws  (×24)
  06:57:50.565 [adservice] received ad request (context_words=[accessories])  (×36)
  06:57:50.614 [cartservice] AddItemAsync called with userId=33421b66-55b6-413b-9ba9-3230c85c58dc, productId=LS4PSXUNUM, quantity=6  (×43)
  06:57:50.646 [shippingservice] [GetQuote] completed request  (×89)
  06:57:50.701 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"575","nanos":104870416},"credit_card":{"credit_card_number":"42873540362102  (×3)
  06:57:50.705 [shippingservice] [ShipOrder] received request  (×15)
  06:57:50.715 [emailservice] A request to send order confirmation email to allen94@example.net has been received.
  06:57:51.508 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', 'OLJCESPC7Z', '9SIQT8TOJO', '2ZYFJ3GM2N']  (×6)
  06:57:51.587 [paymentservice] Transaction processed: visa ending 3837 Amount: USD1435.160000000  (×6)
  06:57:52.094 [frontend] setting currency  (×17)
  06:57:59.414 [checkoutservice] order confirmation email sent to "john72@example.com"
  06:58:07.008 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="JPY"
  06:58:07.043 [emailservice] A request to send order confirmation email to justin87@example.com has been received.
  06:58:11.535 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"949","nanos":677624054},"credit_card":{"credit_card_number":"42788040456535
  06:58:11.551 [checkoutservice] order confirmation email sent to "kevin94@example.com"
  06:58:16.950 [paymentservice] Transaction processed: visa ending 1976 Amount: EUR175.488721809  (×4)
  06:58:17.782 [emailservice] A request to send order confirmation email to edelacruz@example.org has been received.
  06:58:18.329 [checkoutservice] order confirmation email sent to "dennis76@example.com"
  06:58:19.534 [emailservice] A request to send order confirmation email to barrypeggy@example.com has been received.
  06:58:19.731 [checkoutservice] order confirmation email sent to "smithkyle@example.net"
  06:58:31.167 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  06:58:31.171 [frontend] request error
  06:58:33.546 [emailservice] A request to send order confirmation email to jacksonwayne@example.net has been received.
  06:58:38.934 [checkoutservice] order confirmation email sent to "kathy60@example.org"

## p0562
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:30:15.882Z
```
{"timestamp":1733596215882113300,"container_name":"ts-auth-service","pod_name":"ts-auth-service-75dfb9459b-94tpt","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:30:15.882  INFO 1 --- [       Thread-5] org.mongodb.driver.connection            : Closed connection [connectionId{localValue:4, serverValue:17}] to ts-auth-mongo:27017 because the pool has been closed."}
```
Same service, the 2 minutes before (oldest first):
  18:30:09.450 [ts-auth-service] 2024-12-07 18:30:09.450 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  18:30:09.450 [ts-auth-service] 2024-12-07 18:30:09.450 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:30:09.661 [ts-auth-service] 2024-12-07 18:30:09.661 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×2)
  18:30:09.661 [ts-auth-service] 2024-12-07 18:30:09.661 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×2)
  18:30:10.784 [ts-auth-service] 2024-12-07 18:30:10.782 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  18:30:10.784 [ts-auth-service] 2024-12-07 18:30:10.782 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  18:30:10.967 [ts-auth-service] 2024-12-07 18:30:10.967 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  18:30:10.967 [ts-auth-service] 2024-12-07 18:30:10.967 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:30:11.191 [ts-auth-service] 2024-12-07 18:30:11.190 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI
  18:30:11.191 [ts-auth-service] 2024-12-07 18:30:11.190 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID
  18:30:15.870 [ts-auth-service] 2024-12-07 18:30:15.870 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  18:30:15.873 [ts-auth-service] 2024-12-07 18:30:15.872 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  18:30:15.874 [ts-auth-service] 2024-12-07 18:30:15.874 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  18:30:15.874 [ts-auth-service] 2024-12-07 18:30:15.874 INFO 1 --- [ Thread-5] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 0 subscriber(s).
  18:30:15.874 [ts-auth-service] 2024-12-07 18:30:15.874 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : stopped _org.springframework.integration.errorLogger
  18:30:15.877 [ts-auth-service] 2024-12-07 18:30:15.877 INFO 1 --- [ Thread-5] o.s.s.c.ThreadPoolTaskScheduler : Shutting down ExecutorService 'taskScheduler'
  18:30:15.877 [ts-auth-service] 2024-12-07 18:30:15.877 INFO 1 --- [ Thread-5] o.s.j.e.a.AnnotationMBeanExporter : Unregistering JMX-exposed beans on shutdown
  18:30:15.880 [ts-auth-service] 2024-12-07 18:30:15.880 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:16}] to ts-auth-mongo:2
All services, 30 seconds either side (sampled):
  18:29:45.882 [ts-basic-service] 2024-12-07 18:29:45.882 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×63)
  18:29:45.911 [ts-basic-service] 2024-12-07 18:29:45.911 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×9)
  18:29:45.993 [ts-travel2-service] 2024-12-07 18:29:45.993 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×111)
  18:29:46.031 [ts-seat-service] 2024-12-07 18:29:46.031 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×36)
  18:29:47.860 [ts-auth-service] 2024-12-07 18:29:47.860 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×9)
  18:29:47.919 [ts-travel-service] 2024-12-07 18:29:47.919 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×12)
  18:29:47.979 [ts-travel2-service] 2024-12-07 18:29:47.978 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×16)
  18:29:54.679 [ts-auth-service] 2024-12-07 18:29:54.679 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  18:30:00.246 [ts-basic-service] 2024-12-07 18:30:00.246 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  18:30:00.278 [ts-basic-service] 2024-12-07 18:30:00.278 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  18:30:00.379 [ts-seat-service] 2024-12-07 18:30:00.379 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×3)
  18:30:02.452 [ts-basic-service] 2024-12-07 18:30:02.452 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×24)
  18:30:02.486 [ts-basic-service] 2024-12-07 18:30:02.486 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×11)
  18:30:02.555 [ts-travel-service] 2024-12-07 18:30:02.554 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×4)
  18:30:07.196 [ts-order-other-service] 2024-12-07 18:30:07.196 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×3)
  18:30:09.590 [ts-inside-payment-service] 2024-12-07 18:30:09.588 INFO 1 --- [io-18673-exec-7] i.service.InsidePaymentServiceImpl : Out pay result: Response(status=1, msg=Pay Success, data=null)
  18:30:14.631 [ts-basic-service] 2024-12-07 18:30:14.630 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×19)
  18:30:14.739 [ts-order-service] 2024-12-07 18:30:14.739 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×5)
  18:30:14.807 [ts-seat-service] 2024-12-07 18:30:14.807 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×11)
  18:30:15.479 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:30:15 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 916 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×2)
  18:30:15.880 [ts-auth-service] 2024-12-07 18:30:15.880 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:16}] to ts-auth-mongo:2  (×3)
  18:30:17.523 [ts-travel-service] 2024-12-07 18:30:17.523 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1237
  18:30:26.260 [ts-auth-service] 2024-12-07 18:30:26.260 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default
  18:30:29.606 [ts-food-service] 2024-12-07 18:30:29.605 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  18:30:29.940 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:30:29.940+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359622
  18:30:31.939 [ts-order-service] 2024-12-07 18:30:31.939 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 
  18:30:40.512 [ts-order-other-service] 2024-12-07 18:30:40.512 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 24
  18:30:42.020 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T18:30:42.020+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359624
  18:30:44.984 [ts-travel2-service] 2024-12-07 18:30:44.983 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success

## p0608
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T20:10:33.802Z
```
{"timestamp":1733602233802746400,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-nsc8q","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:10:33.802  INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl             : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Response(status=1, msg=Success, data=TrainType(id=GaoTieOne, economyClass=2147483647, confortClass=2147483647, averageSpeed=250))"}
```
Same service, the 2 minutes before (oldest first):
  20:10:30.074 [ts-seat-service] 2024-12-07 20:10:30.074 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
  20:10:30.086 [ts-seat-service] 2024-12-07 20:10:30.085 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×2)
  20:10:33.233 [ts-seat-service] 2024-12-07 20:10:33.232 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×2)
  20:10:33.233 [ts-seat-service] 2024-12-07 20:10:33.232 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
  20:10:33.248 [ts-seat-service] 2024-12-07 20:10:33.248 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  20:10:33.260 [ts-seat-service] 2024-12-07 20:10:33.259 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:10:33.277 [ts-seat-service] 2024-12-07 20:10:33.276 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re
  20:10:33.277 [ts-seat-service] 2024-12-07 20:10:33.276 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  20:10:33.320 [ts-seat-service] 2024-12-07 20:10:33.319 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN
  20:10:33.320 [ts-seat-service] 2024-12-07 20:10:33.319 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
  20:10:33.336 [ts-seat-service] 2024-12-07 20:10:33.336 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  20:10:33.349 [ts-seat-service] 2024-12-07 20:10:33.349 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:10:33.363 [ts-seat-service] 2024-12-07 20:10:33.362 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re
  20:10:33.363 [ts-seat-service] 2024-12-07 20:10:33.362 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
  20:10:33.372 [ts-seat-service] 2024-12-07 20:10:33.372 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri
  20:10:33.760 [ts-seat-service] 2024-12-07 20:10:33.759 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234
  20:10:33.777 [ts-seat-service] 2024-12-07 20:10:33.777 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes
  20:10:33.788 [ts-seat-service] 2024-12-07 20:10:33.788 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da
All services, 30 seconds either side (sampled):
  20:10:04.355 [ts-travel-service] 2024-12-07 20:10:04.355 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Travel Service] Query TripResponse  (×5)
  20:10:04.397 [ts-travel-service] 2024-12-07 20:10:04.397 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×59)
  20:10:04.441 [ts-basic-service] 2024-12-07 20:10:04.441 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×25)
  20:10:04.464 [ts-travel-service] 2024-12-07 20:10:04.464 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×13)
  20:10:04.524 [ts-seat-service] 2024-12-07 20:10:04.523 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×21)
  20:10:04.664 [ts-travel-service] 2024-12-07 20:10:04.664 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×16)
  20:10:04.810 [ts-seat-service] 2024-12-07 20:10:04.810 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×3)
  20:10:04.889 [ts-travel-service] 2024-12-07 20:10:04.889 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan  (×7)
  20:10:06.489 [ts-auth-service] 2024-12-07 20:10:06.489 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×12)
  20:10:06.827 [ts-travel2-service] 2024-12-07 20:10:06.827 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×135)
  20:10:06.902 [ts-travel2-service] 2024-12-07 20:10:06.902 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×12)
  20:10:06.993 [ts-basic-service] 2024-12-07 20:10:06.992 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×6)
  20:10:07.122 [ts-seat-service] 2024-12-07 20:10:07.121 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×12)
  20:10:09.643 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:10:09 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×11)
  20:10:11.768 [ts-admin-basic-info-service] 2024-12-07 20:10:11.768 INFO 1 --- [io-18767-exec-8] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×11)
  20:10:20.762 [ts-order-other-service] 2024-12-07 20:10:20.761 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×3)
  20:10:28.235 [ts-travel-mongo] {"t":{"$date":"2024-12-07T20:10:28.235+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360222
  20:10:28.442 [ts-route-mongo] {"t":{"$date":"2024-12-07T20:10:28.442+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360222
  20:10:31.116 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T20:10:31.116+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360223
  20:10:32.148 [ts-order-mongo] {"t":{"$date":"2024-12-07T20:10:32.148+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360223
  20:10:34.152 [ts-travel-service] 2024-12-07 20:10:34.152 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×4)
  20:10:41.263 [ts-travel2-service] 2024-12-07 20:10:41.263 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  20:10:55.730 [ts-basic-service] 2024-12-07 20:10:55.730 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×2)
  20:10:57.080 [ts-travel-service] 2024-12-07 20:10:57.079 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  20:10:58.656 [ts-consign-service] 2024-12-07 20:10:58.656 INFO 1 --- [o-16111-exec-10] consign.service.ConsignServiceImpl : [Consign servie] [ Update consign record]
  20:11:00.033 [ts-basic-service] 2024-12-07 20:11:00.033 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×2)
  20:11:00.111 [ts-basic-service] 2024-12-07 20:11:00.111 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : route.getDistances().size : 3

## p0586
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:50.181Z
```
{"timestamp":1733596310181329400,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:50.180  INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl       : nullUSER TOKEN"}
```
Same service, the 2 minutes before (oldest first):
  18:31:40.378 [ts-auth-service] 2024-12-07 18:31:40.378 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×5)
  18:31:40.378 [ts-auth-service] 2024-12-07 18:31:40.378 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×5)
  18:31:41.000 [ts-auth-service] 2024-12-07 18:31:40.999 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×2)
  18:31:41.000 [ts-auth-service] 2024-12-07 18:31:40.999 INFO 1 --- [io-12340-exec-5] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
  18:31:45.547 [ts-auth-service] 2024-12-07 18:31:45.547 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  18:31:45.547 [ts-auth-service] 2024-12-07 18:31:45.547 INFO 1 --- [io-12340-exec-8] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×2)
  18:31:49.989 [ts-auth-service] 2024-12-07 18:31:49.989 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null
  18:31:49.989 [ts-auth-service] 2024-12-07 18:31:49.989 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
All services, 30 seconds either side (sampled):
  18:31:20.890 [ts-travel-service] 2024-12-07 18:31:20.889 ERROR 1 --- [io-12346-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×4)
  18:31:20.993 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:20 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 500 227 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×4)
  18:31:21.810 [ts-order-other-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×2)
  18:31:21.872 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:21 +0800] "GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1" 200 202 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×11)
  18:31:25.386 [ts-auth-service] 2024-12-07 18:31:25.386 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×23)
  18:31:25.408 [ts-travel2-service] 2024-12-07 18:31:25.407 ERROR 1 --- [io-16346-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×13)
  18:31:25.412 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:25 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 500 228 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×15)
  18:31:27.478 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-07T18:31:27.477+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:27.588 [ts-route-mongo] {"t":{"$date":"2024-12-07T18:31:27.588+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.268 [ts-admin-travel-service] 2024-12-07 18:31:28.268 ERROR 1 --- [io-16114-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×10)
  18:31:28.271 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:28 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 500 233 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×12)
  18:31:29.436 [ts-assurance-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×3)
  18:31:29.867 [ts-food-mongo] {"t":{"$date":"2024-12-07T18:31:29.867+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:29.897 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T18:31:29.896+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:30.519 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T18:31:30.518+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:30.725 [ts-notification-mongo] {"t":{"$date":"2024-12-07T18:31:30.725+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:31.064 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×3)
  18:31:31.701 [ts-order-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  18:31:32.290 [ts-admin-basic-info-service] 2024-12-07 18:31:32.289 ERROR 1 --- [io-18767-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×20)
  18:31:38.105 [ts-admin-travel-service] 2024-12-07 18:31:38.104 ERROR 1 --- [o-16114-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×2)
  18:31:42.161 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T18:31:42.161+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359630
  18:31:42.230 [ts-train-mongo] {"t":{"$date":"2024-12-07T18:31:42.230+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359630
  18:31:45.770 [ts-travel2-service] 2024-12-07 18:31:45.770 ERROR 1 --- [o-16346-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×2)
  18:31:51.505 [ts-food-service] 2024-12-07 18:31:51.504 ERROR 1 --- [io-18856-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  18:32:08.507 [ts-auth-service] 2024-12-07 18:32:08.507 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null

## p0612
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T20:12:56.526Z
```
{"timestamp":1733602376526840800,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-w6jt4","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:12:56.526  INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl         : [Travel Service][Get Route By Id] Route ID：a3f256c1-0e43-4f7d-9c21-121bf258101f"}
```
Same service, the 2 minutes before (oldest first):
  20:12:51.703 [ts-travel-service] 2024-12-07 20:12:51.703 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×2)
  20:12:51.704 [ts-travel-service] 2024-12-07 20:12:51.703 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×5)
  20:12:51.711 [ts-travel-service] 2024-12-07 20:12:51.710 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：aefcef3f-3f42-46e8-afd7-6cb2a  (×6)
  20:12:51.718 [ts-travel-service] 2024-12-07 20:12:51.718 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×2)
  20:12:51.731 [ts-travel-service] 2024-12-07 20:12:51.731 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
  20:12:51.745 [ts-travel-service] 2024-12-07 20:12:51.744 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  20:12:51.745 [ts-travel-service] 2024-12-07 20:12:51.745 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  20:12:51.756 [ts-travel-service] 2024-12-07 20:12:51.755 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  20:12:51.756 [ts-travel-service] 2024-12-07 20:12:51.755 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha
All services, 30 seconds either side (sampled):
  20:12:26.616 [ts-travel-service] 2024-12-07 20:12:26.615 INFO 1 --- [io-12346-exec-9] travel.controller.TravelController : [Travel Service] Query TripResponse  (×5)
  20:12:26.665 [ts-travel-service] 2024-12-07 20:12:26.665 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×14)
  20:12:26.721 [ts-basic-service] 2024-12-07 20:12:26.720 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×4)
  20:12:26.753 [ts-admin-basic-info-service] 2024-12-07 20:12:26.753 INFO 1 --- [io-18767-exec-7] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×7)
  20:12:26.807 [ts-order-service] 2024-12-07 20:12:26.807 INFO 1 --- [io-12031-exec-6] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×28)
  20:12:27.514 [ts-auth-service] 2024-12-07 20:12:27.514 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×15)
  20:12:27.755 [ts-basic-service] 2024-12-07 20:12:27.755 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×18)
  20:12:27.846 [ts-seat-service] 2024-12-07 20:12:27.846 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×30)
  20:12:27.973 [ts-basic-service] 2024-12-07 20:12:27.973 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×10)
  20:12:28.454 [ts-config-mongo] {"t":{"$date":"2024-12-07T20:12:28.453+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360234
  20:12:30.115 [ts-price-service] 2024-12-07 20:12:30.114 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×4)
  20:12:31.152 [ts-consign-mongo] {"t":{"$date":"2024-12-07T20:12:31.152+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360235
  20:12:31.959 [ts-basic-service] 2024-12-07 20:12:31.959 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×2)
  20:12:32.060 [ts-order-service] 2024-12-07 20:12:32.060 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×5)
  20:12:32.404 [ts-travel-service] 2024-12-07 20:12:32.404 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×3)
  20:12:35.716 [ts-food-service] 2024-12-07 20:12:35.715 INFO 1 --- [io-18856-exec-9] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×4)
  20:12:40.663 [ts-food-service] 2024-12-07 20:12:40.662 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:12:42.764 [ts-travel-service] 2024-12-07 20:12:42.764 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr  (×8)
  20:12:42.964 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T20:12:42.964+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360236
  20:12:43.035 [ts-security-service] 2024-12-07 20:12:43.035 INFO 1 --- [io-11188-exec-9] security.service.SecurityServiceImpl : [Security Service][Get Order Num Info]
  20:12:43.070 [ts-preserve-service] 2024-12-07 20:12:43.070 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Find contacts
  20:12:43.092 [ts-travel-service] 2024-12-07 20:12:43.092 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  20:12:43.411 [ts-preserve-service] 2024-12-07 20:12:43.411 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] Tickets Enough
  20:12:43.629 [ts-preserve-service] 2024-12-07 20:12:43.629 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service][Order Price] Price is: 22.5
  20:12:43.648 [ts-preserve-service] 2024-12-07 20:12:43.648 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service][Add food Order] Creating....
  20:12:45.271 [ts-admin-travel-service] 2024-12-07 20:12:45.271 INFO 1 --- [io-16114-exec-9] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×6)
  20:12:45.711 [ts-inside-payment-service] 2024-12-07 20:12:45.710 INFO 1 --- [io-18673-exec-3] i.service.InsidePaymentServiceImpl : Out pay result: Response(status=1, msg=Pay Success, data=null)  (×2)
  20:12:46.350 [ts-basic-service] 2024-12-07 20:12:46.350 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieT  (×2)
  20:12:55.063 [ts-inside-payment-service] 2024-12-07 20:12:55.062 INFO 1 --- [io-18673-exec-4] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.
  20:13:14.379 [ts-consign-service] 2024-12-07 20:13:14.379 INFO 1 --- [io-16111-exec-6] consign.service.ConsignServiceImpl : Order ID is :fef9025b-14d3-4d1e-8365-a874979eb146  (×3)

## p0462
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:07:44.409Z
```
{"timestamp":1732349264409552400,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"set cookie67418d50a437380001deedb3"}
```
Same service, the 2 minutes before (oldest first):
  08:07:44.323 [front-end] POST /addresses 200 - ms - -
  08:07:44.328 [front-end] User cart deleted with status: 202  (×2)
  08:07:44.330 [front-end] DELETE /cart 202 - ms - -  (×2)
  08:07:44.331 [front-end] Attempting to delete cart for user: 67418d49a437380001deed9c
  08:07:44.337 [front-end] Attempting to add to cart: {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","quantity":1}  (×2)
  08:07:44.344 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
  08:07:44.344 [front-end] POST to carts: http://carts/carts/67418d4ba437380001deeda0/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}  (×2)
  08:07:44.361 [front-end] Posting Customer: {"username":"krdwYwSwLQ","password":"XsJQyTjHP","email":"krdwYwSwLQ@gmail.com","firstName":"krdwYwSwLQ","lastName":"krdwYwSwLQ"}
  08:07:44.362 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata
  08:07:44.367 [front-end] { id: '67418d50a437380001deedb3' }
  08:07:44.367 [front-end] 67418d50a437380001deedb3
  08:07:44.367 [front-end] Merging carts for customer id: 67418d50a437380001deedb3 and session id: 0xqVfb-1jVwmkbl6eVXEsFd31kfkbPRW
  08:07:44.369 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67418d47a437380001deed8f"}
  08:07:44.376 [front-end] POST /cart 201 - ms - -
  08:07:44.378 [front-end] POST /cards 200 - ms - -
  08:07:44.409 [front-end] Carts merged.
All services, 30 seconds either side (sampled):
  08:07:14.486 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418d28a437380001deed2d"}  (×57)
  08:07:14.603 [front-end] POST to carts: http://carts/carts/67418d28a437380001deed2f/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}  (×30)
  08:07:15.790 [front-end] Received response: "{\"firstName\":\"bUbXreoCTy\",\"lastName\":\"bUbXreoCTy\",\"username\":\"bUbXreoCTy\",\"id\":\"67418d21a437380001deed1d\",\"_links\":{\"addr
  08:07:15.837 [queue-master] Received shipment task: 67418d21a437380001deed1d  (×56)
  08:07:16.096 [front-end] Order response: {"id":"67418d343f77060008864e62","customerId":"67418d1aa437380001deed16","customer":{"id":null,"firstName":"NSgcFqspcTI","lastName":"NSgcFqspcTI
  08:07:17.202 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×6)
  08:07:19.529 [front-end] POST to carts: http://carts/carts/67418d2fa437380001deed47/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}  (×27)
  08:07:22.647 [front-end] Received response: "{\"firstName\":\"cbnvs\",\"lastName\":\"cbnvs\",\"username\":\"cbnvs\",\"id\":\"67418d24a437380001deed24\",\"_links\":{\"addresses\":{\"href
  08:07:23.194 [front-end] Received response: "{\"firstName\":\"hEVaDSOJ\",\"lastName\":\"hEVaDSOJ\",\"username\":\"hEVaDSOJ\",\"id\":\"67418d23a437380001deed21\",\"_links\":{\"addresses\
  08:07:23.798 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d3b3f77060008864e6b","customerId":"67418d27a437380001deed2a","customer":{"id":null,"firstName":"hHThr","las
  08:07:25.605 [user] ts=2024-11-23T08:07:25.605851645Z caller=middlewares.go:46 method=Register username=UacWo email=UacWo@gmail.com took=2.385173ms
  08:07:27.378 [queue-master] 2024-11-23 08:07:27.378 ERROR 7 --- [pool-6-thread-3] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×9)
  08:07:29.357 [front-end] Received response: "{\"firstName\":\"cAaDHOryLykmiRA\",\"lastName\":\"cAaDHOryLykmiRA\",\"username\":\"cAaDHOryLykmiRA\",\"id\":\"67418d2aa437380001deed32\",\"_
  08:07:31.799 [front-end] Order response: {"id":"67418d433f77060008864e73","customerId":"67418d28a437380001deed2d","customer":{"id":null,"firstName":"wCQRAoCVMUbNd","lastName":"wCQRAoCVM
  08:07:33.555 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×2)
  08:07:37.227 [front-end] Posting Customer: {"username":"aWdAdkTjk","password":"mSpgGv","email":"aWdAdkTjk@gmail.com","firstName":"aWdAdkTjk","lastName":"aWdAdkTjk"}
  08:07:39.206 [user] ts=2024-11-23T08:07:39.206331593Z caller=middlewares.go:46 method=Register username=CJuDVJLw email=CJuDVJLw@gmail.com took=2.572156ms
  08:07:42.658 [front-end] Order response: {"id":"67418d4e3f77060008864e7c","customerId":"67418d40a437380001deed78","customer":{"id":null,"firstName":"jymMgFv","lastName":"jymMgFv","usern
  08:07:45.742 [user] ts=2024-11-23T08:07:45.742766052Z caller=middlewares.go:46 method=Register username=ddHmQJZP email=ddHmQJZP@gmail.com took=2.260891ms
  08:07:49.306 [user] ts=2024-11-23T08:07:49.305876369Z caller=middlewares.go:46 method=Register username=sBltl email=sBltl@gmail.com took=2.629228ms
  08:07:51.122 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d573f77060008864e84","customerId":"67418d3ea437380001deed75","customer":{"id":null,"firstName":"TxHiG","las
  08:07:55.434 [front-end] Received response: "{\"firstName\":\"pQpfsHDlQF\",\"lastName\":\"pQpfsHDlQF\",\"username\":\"pQpfsHDlQF\",\"id\":\"67418d4ca437380001deeda1\",\"_links\":{\"addr
  08:07:56.978 [front-end] Received response: "{\"firstName\":\"ZQbUHavflC\",\"lastName\":\"ZQbUHavflC\",\"username\":\"ZQbUHavflC\",\"id\":\"67418d47a437380001deed94\",\"_links\":{\"addr
  08:07:58.892 [front-end] Received response: "{\"firstName\":\"MYuadhgrluR\",\"lastName\":\"MYuadhgrluR\",\"username\":\"MYuadhgrluR\",\"id\":\"67418d4aa437380001deed9e\",\"_links\":{\"a
  08:08:01.067 [front-end] Received response: "{\"firstName\":\"LTJjUQVL\",\"lastName\":\"LTJjUQVL\",\"username\":\"LTJjUQVL\",\"id\":\"67418d43a437380001deed7e\",\"_links\":{\"addresses\
  08:08:02.796 [front-end] Posting Customer: {"username":"iVbUkvuj","password":"TtMLTM","email":"iVbUkvuj@gmail.com","firstName":"iVbUkvuj","lastName":"iVbUkvuj"}
  08:08:08.486 [front-end] Posting Customer: {"username":"lUwPB","password":"hhMdQt","email":"lUwPB@gmail.com","firstName":"lUwPB","lastName":"lUwPB"}
  08:08:10.351 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d6a3f77060008864e97","customerId":"67418d5aa437380001deedd1","customer":{"id":null,"firstName":"RWYjoEZ","l
  08:08:12.738 [front-end] Posting Customer: {"username":"bnDcvNpLex","password":"izlxMxXPmx","email":"bnDcvNpLex@gmail.com","firstName":"bnDcvNpLex","lastName":"bnDcvNpLex"}

## p0772
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T19:28:35.892Z
```
{"timestamp":1732390115892099600,"container_name":"front-end","pod_name":"front-end-f77549869-q8jx8","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"POST /addresses 200 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  19:28:34.764 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67422cce48485600016b184f\",\"_links\":{\"  (×2)
  19:28:34.764 [front-end] [ undefined, undefined ]  (×2)
  19:28:34.764 [front-end] Posting Order: {"customer":"http://user/customers/67422cc448485600016b182f","address":"http://user/addresses/67422cce48485600016b184e","card":"http://user/cards  (×2)
  19:28:34.800 [front-end] Order response: {"statusCode":201,"body":{"id":"67422ce24ca85a00070c52be","customerId":"67422cc448485600016b182f","customer":{"id":null,"firstName":"AVmaNtBHLb"
  19:28:34.800 [front-end] Order response: {"id":"67422ce24ca85a00070c52be","customerId":"67422cc448485600016b182f","customer":{"id":null,"firstName":"AVmaNtBHLb","lastName":"AVmaNtBHLb",
  19:28:34.800 [front-end] POST /orders 201 - ms - -  (×2)
  19:28:34.993 [front-end] GET /catalogue 200 - ms - -  (×2)
  19:28:35.418 [front-end] Request received with body: {}
  19:28:35.435 [front-end] Received response: "{\"firstName\":\"yHmRszWe\",\"lastName\":\"yHmRszWe\",\"username\":\"yHmRszWe\",\"id\":\"67422cc848485600016b1838\",\"_links\":{\"addresses\
  19:28:35.435 [front-end] GET Request to: http://user/customers/67422cc848485600016b1838/addresses  (×2)
  19:28:35.449 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67422
  19:28:35.475 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732390115474,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde
  19:28:35.475 [front-end] Order response: {"timestamp":1732390115474,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli
  19:28:35.877 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67422cde48485600016b1886"}
All services, 30 seconds either side (sampled):
  19:28:05.916 [front-end] Posting Customer: {"username":"EEGdGVWFRFf","password":"qadlD","email":"EEGdGVWFRFf@gmail.com","firstName":"EEGdGVWFRFf","lastName":"EEGdGVWFRFf"}
  19:28:06.012 [front-end] GET /catalogue 200 - ms - -  (×64)
  19:28:06.828 [catalogue] ts=2024-11-23T19:28:06Z caller=logging.go:62 method=Get id=837ab141-399e-4c1f-9abc-bace40296bac sock=837ab141-399e-4c1f-9abc-bace40296bac err=null took=4.985817  (×56)
  19:28:07.929 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×10)
  19:28:09.658 [front-end] Posting Customer: {"username":"AvtGGzdq","password":"IzVEg","email":"AvtGGzdq@gmail.com","firstName":"AvtGGzdq","lastName":"AvtGGzdq"}
  19:28:09.952 [front-end] Posting Order: {"customer":"http://user/customers/67422cb948485600016b1816","address":"http://user/addresses/67422cbf48485600016b1828","card":"http://user/cards  (×55)
  19:28:10.618 [front-end] Posting Customer: {"username":"dByvRug","password":"YvHrfFjGu","email":"dByvRug@gmail.com","firstName":"dByvRug","lastName":"dByvRug"}
  19:28:13.925 [queue-master] 2024-11-23 19:28:13.924 INFO 7 --- [ool-6-thread-47] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×39)
  19:28:14.722 [front-end] Posting Customer: {"username":"MsftVKfrzrDvo","password":"fZYyitE","email":"MsftVKfrzrDvo@gmail.com","firstName":"MsftVKfrzrDvo","lastName":"MsftVKfrzrDvo"}
  19:28:17.428 [front-end] Posting Customer: {"username":"lNJGiQPqy","password":"LoElX","email":"lNJGiQPqy@gmail.com","firstName":"lNJGiQPqy","lastName":"lNJGiQPqy"}
  19:28:18.025 [front-end] Order response: {"statusCode":201,"body":{"id":"67422cd24ca85a00070c52aa","customerId":"67422cb448485600016b180b","customer":{"id":null,"firstName":"WiewxFylkWg
  19:28:20.413 [user] ts=2024-11-23T19:28:20.41315231Z caller=middlewares.go:46 method=Register username=VcfGzxmJl email=VcfGzxmJl@gmail.com took=5.989826ms
  19:28:22.837 [front-end] Received response: "{\"firstName\":\"dByvRug\",\"lastName\":\"dByvRug\",\"username\":\"dByvRug\",\"id\":\"67422cca48485600016b1844\",\"_links\":{\"addresses\":{
  19:28:25.215 [front-end] Order response: {"id":"67422cd94ca85a00070c52b0","customerId":"67422cc548485600016b1831","customer":{"id":null,"firstName":"EEGdGVWFRFf","lastName":"EEGdGVWFRFf
  19:28:27.093 [front-end] Order response: {"id":"67422cdb4ca85a00070c52b3","customerId":"67422cc548485600016b1830","customer":{"id":null,"firstName":"MaCcwVgbdsvZfuX","lastName":"MaCcwVg
  19:28:28.741 [front-end] Order response: {"id":"67422cdc4ca85a00070c52b6","customerId":"67422cce48485600016b184d","customer":{"id":null,"firstName":"MkHxyZshLkPkaZ","lastName":"MkHxyZsh
  19:28:31.042 [front-end] Posting Customer: {"username":"YGUOXoI","password":"zPdcR","email":"YGUOXoI@gmail.com","firstName":"YGUOXoI","lastName":"YGUOXoI"}
  19:28:32.283 [front-end] Order response: {"id":"67422ce04ca85a00070c52ba","customerId":"67422cc948485600016b183c","customer":{"id":null,"firstName":"ovSTXEEzgB","lastName":"ovSTXEEzgB",
  19:28:34.196 [front-end] Posting Customer: {"username":"HTgxUGC","password":"QCJCatwDfa","email":"HTgxUGC@gmail.com","firstName":"HTgxUGC","lastName":"HTgxUGC"}
  19:28:38.930 [user] ts=2024-11-23T19:28:38.930180123Z caller=middlewares.go:46 method=Register username=whaJPsU email=whaJPsU@gmail.com took=5.023285ms
  19:28:42.190 [front-end] Received response: "{\"firstName\":\"zurJilbllY\",\"lastName\":\"zurJilbllY\",\"username\":\"zurJilbllY\",\"id\":\"67422cd248485600016b1863\",\"_links\":{\"addr
  19:28:43.994 [front-end] Order response: {"id":"67422ceb4ca85a00070c52c5","customerId":"67422cd248485600016b185e","customer":{"id":null,"firstName":"faAcrTfQRxKVf","lastName":"faAcrTfQR
  19:28:46.362 [front-end] Order response: {"id":"67422cee4ca85a00070c52c8","customerId":"67422cd648485600016b186f","customer":{"id":null,"firstName":"ODupjdzaC","lastName":"ODupjdzaC","u
  19:28:50.030 [front-end] Order response: {"id":"67422cf24ca85a00070c52ca","customerId":"67422ce048485600016b188b","customer":{"id":null,"firstName":"AwoEuvnhyjL","lastName":"AwoEuvnhyjL
  19:28:51.542 [front-end] Posting Customer: {"username":"oiWIlxgMwtEP","password":"bhZnu","email":"oiWIlxgMwtEP@gmail.com","firstName":"oiWIlxgMwtEP","lastName":"oiWIlxgMwtEP"}
  19:28:53.487 [front-end] Order response: {"statusCode":201,"body":{"id":"67422cf54ca85a00070c52cd","customerId":"67422ce748485600016b1899","customer":{"id":null,"firstName":"YHCgTE","la
  19:28:55.443 [front-end] Order response: {"id":"67422cf74ca85a00070c52d0","customerId":"67422cde48485600016b1884","customer":{"id":null,"firstName":"pEDeCn","lastName":"pEDeCn","usernam
  19:28:58.593 [carts-db] {"t":{"$date":"2024-11-23T19:28:58.593+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173239013
  19:29:02.075 [front-end] Posting Customer: {"username":"KWYVHVwnbmaV","password":"zrhOEhwAWe","email":"KWYVHVwnbmaV@gmail.com","firstName":"KWYVHVwnbmaV","lastName":"KWYVHVwnbmaV"}
  19:29:04.681 [front-end] Order response: {"statusCode":201,"body":{"id":"67422d004ca85a00070c52d4","customerId":"67422ce848485600016b18a4","customer":{"id":null,"firstName":"XlfQPh","la

## p0375
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:40:51.361Z
```
{"timestamp":1732246851361408300,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /register 200 29.503 ms - 33"}
```
Same service, the 2 minutes before (oldest first):
  03:40:50.104 [front-end] POST /register 200 61.451 ms - 33
  03:40:50.129 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffd39b0df5c00019b2d6a"}
  03:40:50.138 [front-end] POST /addresses 200 - ms - -
  03:40:50.184 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffd39b0df5c00019b2d6a"}
  03:40:50.194 [front-end] POST /cards 200 - ms - -
  03:40:50.244 [front-end] Attempting to delete cart for user: 673ffd39b0df5c00019b2d6a
  03:40:50.297 [front-end] User cart deleted with status: 202
  03:40:50.299 [front-end] DELETE /cart 202 - ms - -
  03:40:50.305 [front-end] Attempting to add to cart: {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  03:40:50.314 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca
  03:40:50.314 [front-end] POST to carts: http://carts/carts/673ffd39b0df5c00019b2d6a/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}
  03:40:50.498 [front-end] POST /cart 201 - ms - -
  03:40:50.661 [front-end] GET /catalogue 200 - ms - -
  03:40:51.328 [front-end] Posting Customer: {"username":"ySjyQlrYPeogmav","password":"OGpmbdBEDO","email":"ySjyQlrYPeogmav@gmail.com","firstName":"ySjyQlrYPeogmav","lastName":"ySjyQlrYPe
  03:40:51.333 [front-end] { id: '673ffd43b0df5c00019b2d83' }
  03:40:51.333 [front-end] 673ffd43b0df5c00019b2d83
  03:40:51.333 [front-end] Merging carts for customer id: 673ffd43b0df5c00019b2d83 and session id: gJelQSaIBUvxVf2wCOCMzzBIQ-oe7WXp
  03:40:51.357 [front-end] Carts merged.
  03:40:51.357 [front-end] set cookie673ffd43b0df5c00019b2d83
  03:40:51.357 [front-end] Sent cookies.
All services, 30 seconds either side (sampled):
  03:40:21.450 [front-end] Request received with body: {}  (×64)
  03:40:21.488 [payment] ts=2024-11-22T03:40:21Z caller=logging.go:29 method=Authorise result=true took=982ns  (×40)
  03:40:21.994 [orders] 2024-11-22 03:40:21.993 INFO [orders,8bb35df06ce1be35,801bb3c34cc80352,false] 6 --- [-nio-80-exec-11] w.w.s.o.controllers.OrdersController : Sending payment req  (×25)
  03:40:22.448 [carts] 2024-11-22 03:40:22.448 INFO [carts,f01b778ecb78acb9,9cc394c579197319,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×31)
  03:40:23.185 [front-end] Order response: {"id":"673ffd27d94b9000069b4716","customerId":"673ffd15b0df5c00019b2cf8","customer":{"id":null,"firstName":"dFEEDvbCIt","lastName":"dFEEDvbCIt",
  03:40:24.158 [front-end] POST /cards 200 - ms - -  (×60)
  03:40:24.570 [user] ts=2024-11-22T03:40:24.569868147Z caller=middlewares.go:46 method=Register username=LiUKqRolHOayhli email=LiUKqRolHOayhli@gmail.com took=955.55µs  (×8)
  03:40:25.464 [user] ts=2024-11-22T03:40:25.464086377Z caller=middlewares.go:46 method=Register username=ZhKUJWe email=ZhKUJWe@gmail.com took=863.133µs
  03:40:26.404 [catalogue] ts=2024-11-22T03:40:26Z caller=logging.go:62 method=Get id=3395a43e-2d88-40de-b95f-e00e1502085b sock=3395a43e-2d88-40de-b95f-e00e1502085b err=null took=4.07721m  (×4)
  03:40:29.107 [carts-db] {"t":{"$date":"2024-11-22T03:40:29.106+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224682
  03:40:32.205 [front-end] Order response: {"id":"673ffd30d94b9000069b471c","customerId":"673ffd17b0df5c00019b2d02","customer":{"id":null,"firstName":"AeoEWbZ","lastName":"AeoEWbZ","usern
  03:40:35.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd33d94b9000069b471e","customerId":"673ffd1bb0df5c00019b2d0b","customer":{"id":null,"firstName":"KKkTeydR","
  03:40:37.269 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd35d94b9000069b4722","customerId":"673ffd21b0df5c00019b2d21","customer":{"id":null,"firstName":"uEjMG","las
  03:40:38.846 [front-end] Order response: {"id":"673ffd36d94b9000069b4725","customerId":"673ffd23b0df5c00019b2d23","customer":{"id":null,"firstName":"wDQlrkYxpEcQ","lastName":"wDQlrkYxpE
  03:40:42.071 [session-db] 1:M 22 Nov 2024 03:40:42.071 * 100 changes in 300 seconds. Saving...
  03:40:43.224 [front-end] Posting Customer: {"username":"rrYwYlEJHXGoWY","password":"zFnGhNHVag","email":"rrYwYlEJHXGoWY@gmail.com","firstName":"rrYwYlEJHXGoWY","lastName":"rrYwYlEJHXGoW
  03:40:46.352 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd3ed94b9000069b472c","customerId":"673ffd2ab0df5c00019b2d39","customer":{"id":null,"firstName":"NUHZhd","la
  03:40:48.326 [front-end] Received response: "{\"firstName\":\"oHfjirgMCgcG\",\"lastName\":\"oHfjirgMCgcG\",\"username\":\"oHfjirgMCgcG\",\"id\":\"673ffd2db0df5c00019b2d41\",\"_links\":{
  03:40:49.499 [user] ts=2024-11-22T03:40:49.499254065Z caller=middlewares.go:46 method=Register username=sQIcX email=sQIcX@gmail.com took=1.005416ms
  03:40:54.684 [front-end] Order response: {"id":"673ffd46d94b9000069b4734","customerId":"673ffd31b0df5c00019b2d56","customer":{"id":null,"firstName":"TKYQhsBnqa","lastName":"TKYQhsBnqa",
  03:40:56.711 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×2)
  03:41:00.598 [front-end] Posting Customer: {"username":"SzkfnrtNJgdqL","password":"fpcIRjjREE","email":"SzkfnrtNJgdqL@gmail.com","firstName":"SzkfnrtNJgdqL","lastName":"SzkfnrtNJgdqL"}
  03:41:01.955 [front-end] Posting Customer: {"username":"sGNOxnGtnEaCQ","password":"NkNMAoEQXZ","email":"sGNOxnGtnEaCQ@gmail.com","firstName":"sGNOxnGtnEaCQ","lastName":"sGNOxnGtnEaCQ"}
  03:41:03.877 [front-end] Order response: {"id":"673ffd4fd94b9000069b473d","customerId":"673ffd3ab0df5c00019b2d6b","customer":{"id":null,"firstName":"wRFUDysQwheAMu","lastName":"wRFUDysQ
  03:41:04.751 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd50d94b9000069b4741","customerId":"673ffd40b0df5c00019b2d7d","customer":{"id":null,"firstName":"IOAswmlhXVb
  03:41:09.622 [front-end] Received response: "{\"firstName\":\"jLUtWGWaIeV\",\"lastName\":\"jLUtWGWaIeV\",\"username\":\"jLUtWGWaIeV\",\"id\":\"673ffd41b0df5c00019b2d7e\",\"_links\":{\"a
  03:41:13.030 [front-end] Received response: "{\"firstName\":\"IpoRRBZovaXSTn\",\"lastName\":\"IpoRRBZovaXSTn\",\"username\":\"IpoRRBZovaXSTn\",\"id\":\"673ffd45b0df5c00019b2d8a\",\"_lin
  03:41:14.417 [front-end] Order response: {"id":"673ffd5ad94b9000069b4749","customerId":"673ffd4cb0df5c00019b2da4","customer":{"id":null,"firstName":"SqnCEtlvzfilDvL","lastName":"SqnCEtl
  03:41:17.479 [front-end] Received response: "{\"firstName\":\"ovQpp\",\"lastName\":\"ovQpp\",\"username\":\"ovQpp\",\"id\":\"673ffd4db0df5c00019b2daa\",\"_links\":{\"addresses\":{\"href
  03:41:19.278 [front-end] Posting Customer: {"username":"RWMsckgrRQQenew","password":"hXCEizriy","email":"RWMsckgrRQQenew@gmail.com","firstName":"RWMsckgrRQQenew","lastName":"RWMsckgrRQQ

## p0433
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-23T08:05:44.685Z
```
{"timestamp":1732349144685772500,"container_name":"orders","pod_name":"orders-7fff6698cb-rlq5k","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-23 08:05:44.685  INFO [orders,,,] 8 --- [           main] o.s.j.e.a.AnnotationMBeanExporter        : Bean with name 'configurationPropertiesRebinder' has been autodetected for JMX exposure"}
```
Same service, the 2 minutes before (oldest first):
  08:05:41.185 [orders] 2024-11-23 08:05:41.185 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public 
  08:05:41.187 [orders] 2024-11-23 08:05:41.187 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application
  08:05:41.188 [orders] 2024-11-23 08:05:41.188 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public 
  08:05:41.188 [orders] 2024-11-23 08:05:41.188 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applicati
  08:05:41.189 [orders] 2024-11-23 08:05:41.189 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application
  08:05:41.189 [orders] 2024-11-23 08:05:41.189 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=
  08:05:41.190 [orders] 2024-11-23 08:05:41.190 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applicati
  08:05:41.190 [orders] 2024-11-23 08:05:41.190 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.
  08:05:41.190 [orders] 2024-11-23 08:05:41.190 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<j
  08:05:41.191 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java
  08:05:41.191 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto
  08:05:41.192 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]
  08:05:41.192 [orders] 2024-11-23 08:05:41.192 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json
  08:05:41.192 [orders] 2024-11-23 08:05:41.192 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/j
  08:05:41.193 [orders] 2024-11-23 08:05:41.193 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[app
  08:05:41.194 [orders] 2024-11-23 08:05:41.193 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public ja
  08:05:41.195 [orders] 2024-11-23 08:05:41.195 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[app
  08:05:41.198 [orders] 2024-11-23 08:05:41.198 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produce
  08:05:43.084 [orders] 2024-11-23 08:05:43.084 INFO [orders,,,] 8 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  08:05:44.588 [orders] 2024-11-23 08:05:44.587 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
All services, 30 seconds either side (sampled):
  08:05:16.044 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418cb4a437380001deebd3"}  (×60)
  08:05:16.923 [user] ts=2024-11-23T08:05:16.922581748Z caller=middlewares.go:75 method=GetUsers id=67418caaa437380001deebb5 result=1 took=2.939559ms  (×215)
  08:05:17.299 [front-end] Sent cookies.  (×61)
  08:05:18.714 [carts] 2024-11-23 08:05:18.712 INFO [carts,,,] 7 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  08:05:20.221 [queue-master] 2024-11-23 08:05:20.221 INFO 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  08:05:22.874 [front-end] Posting Customer: {"username":"kvjRZNQgiVnmkal","password":"VhVyZOrv","email":"kvjRZNQgiVnmkal@gmail.com","firstName":"kvjRZNQgiVnmkal","lastName":"kvjRZNQgiVnm
  08:05:26.499 [queue-master] 2024-11-23 08:05:26.499 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+json || applica
  08:05:26.609 [queue-master] 2024-11-23 08:05:26.609 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[GET],produces
  08:05:27.703 [queue-master] 2024-11-23 08:05:27.703 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]}" onto pub
  08:05:27.911 [carts] 2024-11-23 08:05:27.911 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'metricsServlet' to [/metrics]
  08:05:29.553 [user] ts=2024-11-23T08:05:29.553028599Z caller=middlewares.go:46 method=Register username=yYxwhLWv email=yYxwhLWv@gmail.com took=1.895508ms
  08:05:31.631 [carts-db] {"t":{"$date":"2024-11-23T08:05:31.631+00:00"},"s":"W", "c":"COMMAND", "id":5578800, "ctx":"conn1","msg":"Deprecated operation requested. The client driver may 
  08:05:32.893 [orders] 2024-11-23 08:05:32.892 INFO [orders,,,] 8 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionH  (×2)
  08:05:36.422 [user] ts=2024-11-23T08:05:36.422193492Z caller=middlewares.go:46 method=Register username=pSeQWyL email=pSeQWyL@gmail.com took=2.850057ms
  08:05:39.188 [orders] 2024-11-23 08:05:39.188 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/ha
  08:05:39.196 [orders] 2024-11-23 08:05:39.196 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applica
  08:05:41.187 [orders] 2024-11-23 08:05:41.187 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application
  08:05:41.706 [front-end] Posting Customer: {"username":"VGvhEBXruush","password":"TpFMwWsQ","email":"VGvhEBXruush@gmail.com","firstName":"VGvhEBXruush","lastName":"VGvhEBXruush"}
  08:05:44.691 [orders] 2024-11-23 08:05:44.690 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX serve
  08:05:47.988 [orders] 2024-11-23 08:05:47.988 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comple
  08:05:49.885 [orders] 2024-11-23 08:05:49.884 INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repos  (×24)
  08:05:54.265 [front-end] Posting Customer: {"username":"imiXj","password":"mbjOThU","email":"imiXj@gmail.com","firstName":"imiXj","lastName":"imiXj"}
  08:05:55.023 [front-end] Posting Customer: {"username":"brTpfrzj","password":"CqouP","email":"brTpfrzj@gmail.com","firstName":"brTpfrzj","lastName":"brTpfrzj"}
  08:05:58.911 [front-end] Received response: "{\"firstName\":\"eqACgmjO\",\"lastName\":\"eqACgmjO\",\"username\":\"eqACgmjO\",\"id\":\"67418cd4a437380001deec3c\",\"_links\":{\"addresses\
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  08:06:04.990 [front-end] Posting Customer: {"username":"VnaknAEtTvwY","password":"DQLtg","email":"VnaknAEtTvwY@gmail.com","firstName":"VnaknAEtTvwY","lastName":"VnaknAEtTvwY"}
  08:06:07.003 [shipping] 2024-11-23 08:06:07.003 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[applicat
  08:06:07.100 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],pro
  08:06:10.340 [front-end] Posting Customer: {"username":"djVRqry","password":"CJLHmVgJ","email":"djVRqry@gmail.com","firstName":"djVRqry","lastName":"djVRqry"}
  08:06:14.312 [shipping] 2024-11-23 08:06:14.312 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX e

## p0616
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-ui-dashboard, 2024-12-07T20:16:51.351Z
```
{"timestamp":1733602611351465700,"container_name":"ts-ui-dashboard","pod_name":"ts-ui-dashboard-667c5cdd98-x99xl","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"127.0.0.1 - - [08/Dec/2024:04:16:51 +0800] \"GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1\" 200 1697 \"-\" \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36\""}
```
Same service, the 2 minutes before (oldest first):
  20:16:40.249 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:40 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×5)
  20:16:40.695 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:40 +0800] "POST /api/v1/users/login HTTP/1.1" 200 353 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×5)
  20:16:42.980 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:42 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 343 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW
  20:16:43.268 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:43 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×6)
  20:16:47.309 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:47 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 200 31961 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) App
  20:16:47.348 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:47 +0800] "PUT /api/v1/consignservice/consigns HTTP/1.1" 200 399 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebK
  20:16:48.419 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:48 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 5994 "-" "Mozilla/5.0 (Macintosh;
All services, 30 seconds either side (sampled):
  20:16:21.788 [ts-admin-basic-info-service] 2024-12-07 20:16:21.787 INFO 1 --- [io-18767-exec-3] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×16)
  20:16:23.657 [ts-auth-service] 2024-12-07 20:16:23.657 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×23)
  20:16:23.696 [ts-route-service] 2024-12-07 20:16:23.696 INFO 1 --- [io-11178-exec-8] route.controller.RouteController : Route id: aefcef3f-3f42-46e8-afd7-6cb2a928bd3d  (×119)
  20:16:23.743 [ts-admin-travel-service] 2024-12-07 20:16:23.743 INFO 1 --- [io-16114-exec-7] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×16)
  20:16:27.993 [ts-basic-service] 2024-12-07 20:16:27.992 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×26)
  20:16:28.059 [ts-basic-service] 2024-12-07 20:16:28.059 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×3)
  20:16:28.082 [ts-travel2-service] 2024-12-07 20:16:28.081 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×5)
  20:16:28.136 [ts-travel2-service] 2024-12-07 20:16:28.136 INFO 1 --- [io-16346-exec-5] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×8)
  20:16:28.175 [ts-seat-service] 2024-12-07 20:16:28.174 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×8)
  20:16:28.262 [ts-travel2-service] 2024-12-07 20:16:28.261 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×10)
  20:16:29.878 [ts-admin-travel-service] 2024-12-07 20:16:29.878 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×2)
  20:16:30.266 [ts-seat-service] 2024-12-07 20:16:30.265 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×2)
  20:16:30.371 [ts-seat-service] 2024-12-07 20:16:30.371 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:16:31.289 [ts-order-other-service] 2024-12-07 20:16:31.289 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-
  20:16:31.556 [ts-consign-service] 2024-12-07 20:16:31.556 INFO 1 --- [io-16111-exec-1] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] 4432ab96-7bf2-43bd-b045-  (×2)
  20:16:31.588 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T20:16:31.587+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360259
  20:16:31.809 [ts-travel2-service] 2024-12-07 20:16:31.809 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×2)
  20:16:32.910 [ts-food-service] 2024-12-07 20:16:32.909 INFO 1 --- [io-18856-exec-7] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:16:40.693 [ts-auth-service] 2024-12-07 20:16:40.693 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×2)
  20:16:42.649 [ts-basic-service] 2024-12-07 20:16:42.649 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  20:16:42.675 [ts-basic-service] 2024-12-07 20:16:42.675 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3
  20:16:46.989 [ts-order-service] 2024-12-07 20:16:46.988 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-4cf1-
  20:16:48.369 [ts-food-service] 2024-12-07 20:16:48.369 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:16:57.625 [ts-route-service] 2024-12-07 20:16:57.625 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  20:16:57.636 [ts-route-mongo] {"t":{"$date":"2024-12-07T20:16:57.635+00:00"},"s":"I", "c":"NETWORK", "id":22944, "ctx":"conn22","msg":"Connection ended","attr":{"remote":"127.0.0.6:49617","u  (×3)
  20:17:02.697 [ts-travel-service] 2024-12-07 20:17:02.697 ERROR 1 --- [io-12346-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×6)

## p0403
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:50:15.719Z
```
{"timestamp":1732247415719362600,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Order: {\"customer\":\"http://user/customers/673fff60b0df5c00019b3404\",\"address\":\"http://user/addresses/673fff69b0df5c00019b3419\",\"card\":\"http://user/cards/673fff69b0df5c00019b341a\",\"items\":\"http://carts/carts/673fff60b0df5c00019b3404/items\"}"}
```
Same service, the 2 minutes before (oldest first):
  03:50:15.548 [front-end] POST /addresses 200 - ms - -
  03:50:15.555 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fff6db0df5c00019b3429"}
  03:50:15.565 [front-end] POST /cards 200 - ms - -
  03:50:15.609 [front-end] Attempting to delete cart for user: 673fff6db0df5c00019b3429
  03:50:15.631 [front-end] User cart deleted with status: 202
  03:50:15.633 [front-end] DELETE /cart 202 - ms - -
  03:50:15.638 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  03:50:15.645 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  03:50:15.645 [front-end] POST to carts: http://carts/carts/673fff6db0df5c00019b3429/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  03:50:15.705 [front-end] Posting Customer: {"username":"YasPBLxDHHFUwEs","password":"urzTGU","email":"YasPBLxDHHFUwEs@gmail.com","firstName":"YasPBLxDHHFUwEs","lastName":"YasPBLxDHHFUwE
  03:50:15.708 [front-end] Request received with body: {}
  03:50:15.710 [front-end] { id: '673fff77b0df5c00019b3451' }
  03:50:15.710 [front-end] 673fff77b0df5c00019b3451
  03:50:15.710 [front-end] Merging carts for customer id: 673fff77b0df5c00019b3451 and session id: zFNz9PCamgNZ1PK2tlU28BxeRd4OoTpZ
  03:50:15.713 [front-end] Received response: "{\"firstName\":\"MmiDmXUtccJfjHD\",\"lastName\":\"MmiDmXUtccJfjHD\",\"username\":\"MmiDmXUtccJfjHD\",\"id\":\"673fff60b0df5c00019b3404\",\"_
  03:50:15.713 [front-end] GET Request to: http://user/customers/673fff60b0df5c00019b3404/addresses  (×2)
  03:50:15.719 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:50:15.719 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fff69b0df5c00019b341a\",\"_links\":{\"
  03:50:15.719 [front-end] [ undefined, undefined ]
All services, 30 seconds either side (sampled):
  03:49:45.999 [front-end] Request received with body: {}  (×64)
  03:49:46.033 [payment] ts=2024-11-22T03:49:46Z caller=logging.go:29 method=Authorise result=true took=956ns  (×44)
  03:49:46.439 [front-end] Received response: "{\"firstName\":\"SScOKVMUr\",\"lastName\":\"SScOKVMUr\",\"username\":\"SScOKVMUr\",\"id\":\"673fff4cb0df5c00019b33c9\",\"_links\":{\"address
  03:49:47.485 [front-end] { id: '673fff5bb0df5c00019b33f8' }  (×61)
  03:49:48.077 [front-end] POST /addresses 200 - ms - -  (×54)
  03:49:48.178 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×8)
  03:49:49.325 [front-end] Received response: "{\"firstName\":\"dVrMJTrxDdmKj\",\"lastName\":\"dVrMJTrxDdmKj\",\"username\":\"dVrMJTrxDdmKj\",\"id\":\"673fff44b0df5c00019b33af\",\"_links\
  03:49:52.177 [front-end] Order response: {"id":"673fff60d94b9000069b4896","customerId":"673fff4eb0df5c00019b33d0","customer":{"id":null,"firstName":"uCqQRY","lastName":"uCqQRY","usernam
  03:49:54.073 [front-end] Order response: {"id":"673fff62d94b9000069b4898","customerId":"673fff47b0df5c00019b33b6","customer":{"id":null,"firstName":"KGZVkZvnB","lastName":"KGZVkZvnB","u
  03:49:57.654 [front-end] Posting Customer: {"username":"uScQSYyqXHjAz","password":"AheswyMsX","email":"uScQSYyqXHjAz@gmail.com","firstName":"uScQSYyqXHjAz","lastName":"uScQSYyqXHjAz"}
  03:50:00.641 [front-end] Order response: {"statusCode":201,"body":{"id":"673fff68d94b9000069b489e","customerId":"673fff53b0df5c00019b33df","customer":{"id":null,"firstName":"DdVzBtfe","
  03:50:01.195 [front-end] Posting Customer: {"username":"PCwNVgySdq","password":"wLNvsQ","email":"PCwNVgySdq@gmail.com","firstName":"PCwNVgySdq","lastName":"PCwNVgySdq"}
  03:50:03.439 [front-end] Order response: {"statusCode":201,"body":{"id":"673fff6bd94b9000069b48a2","customerId":"673fff52b0df5c00019b33db","customer":{"id":null,"firstName":"hKzuIX","la
  03:50:06.687 [front-end] Received response: "{\"firstName\":\"HiNOkdBfPcUg\",\"lastName\":\"HiNOkdBfPcUg\",\"username\":\"HiNOkdBfPcUg\",\"id\":\"673fff5bb0df5c00019b33f8\",\"_links\":{
  03:50:09.720 [front-end] Posting Customer: {"username":"LTXmY","password":"VsbtvZ","email":"LTXmY@gmail.com","firstName":"LTXmY","lastName":"LTXmY"}
  03:50:12.341 [front-end] Order response: {"id":"673fff74d94b9000069b48a6","customerId":"673fff5fb0df5c00019b33ff","customer":{"id":null,"firstName":"DHOywtAII","lastName":"DHOywtAII","u
  03:50:14.690 [front-end] Order response: {"statusCode":201,"body":{"id":"673fff76d94b9000069b48a9","customerId":"673fff60b0df5c00019b3403","customer":{"id":null,"firstName":"FNWLwy","la
  03:50:16.945 [front-end] Order response: {"id":"673fff78d94b9000069b48ab","customerId":"673fff67b0df5c00019b3415","customer":{"id":null,"firstName":"UHPlvjzLrMCvHdv","lastName":"UHPlvjz
  03:50:19.843 [front-end] Posting Customer: {"username":"MPkrJT","password":"SiMsWQvPub","email":"MPkrJT@gmail.com","firstName":"MPkrJT","lastName":"MPkrJT"}
  03:50:22.311 [front-end] Received response: "{\"firstName\":\"BBgiQfFZYbirTq\",\"lastName\":\"BBgiQfFZYbirTq\",\"username\":\"BBgiQfFZYbirTq\",\"id\":\"673fff64b0df5c00019b340b\",\"_lin
  03:50:23.314 [front-end] Received response: "{\"firstName\":\"IshBpuWzHos\",\"lastName\":\"IshBpuWzHos\",\"username\":\"IshBpuWzHos\",\"id\":\"673fff6bb0df5c00019b3423\",\"_links\":{\"a
  03:50:25.309 [front-end] Received response: "{\"firstName\":\"XzQNZIDSAPV\",\"lastName\":\"XzQNZIDSAPV\",\"username\":\"XzQNZIDSAPV\",\"id\":\"673fff65b0df5c00019b340d\",\"_links\":{\"a
  03:50:28.683 [user] ts=2024-11-22T03:50:28.683448365Z caller=middlewares.go:46 method=Register username=TYEvaLFh email=TYEvaLFh@gmail.com took=1.031023ms
  03:50:32.809 [front-end] Received response: "{\"firstName\":\"AHSIctvfcrsbNPE\",\"lastName\":\"AHSIctvfcrsbNPE\",\"username\":\"AHSIctvfcrsbNPE\",\"id\":\"673fff6db0df5c00019b3429\",\"_
  03:50:35.042 [front-end] Received response: "{\"firstName\":\"DwRuq\",\"lastName\":\"DwRuq\",\"username\":\"DwRuq\",\"id\":\"673fff78b0df5c00019b3457\",\"_links\":{\"addresses\":{\"href
  03:50:37.017 [front-end] Posting Customer: {"username":"ZJYUPnpx","password":"aTUzaGNU","email":"ZJYUPnpx@gmail.com","firstName":"ZJYUPnpx","lastName":"ZJYUPnpx"}
  03:50:39.021 [front-end] Order response: {"id":"673fff8fd94b9000069b48c5","customerId":"673fff77b0df5c00019b3452","customer":{"id":null,"firstName":"SFgQYsAhl","lastName":"SFgQYsAhl","u
  03:50:42.646 [front-end] Received response: "{\"firstName\":\"kgLrCL\",\"lastName\":\"kgLrCL\",\"username\":\"kgLrCL\",\"id\":\"673fff7bb0df5c00019b3463\",\"_links\":{\"addresses\":{\"h
  03:50:43.958 [front-end] Order response: {"id":"673fff93d94b9000069b48c9","customerId":"673fff82b0df5c00019b3474","customer":{"id":null,"firstName":"ULXThWpEcqpeNw","lastName":"ULXThWpE

## p0361
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:33:44.275Z
```
{"timestamp":1732246424275262000,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:33:44.27507094Z caller=middlewares.go:104 method=GetAddresses id=673ffb89b0df5c00019b283e result=1 took=840.766µs"}
```
Same service, the 2 minutes before (oldest first):
  03:33:41.951 [user] ts=2024-11-22T03:33:41.95173112Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffb90b0df5c00019b285c took=16.549474ms
  03:33:41.965 [user] ts=2024-11-22T03:33:41.965317519Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffb90b0df5c00019b285c took=1.706427ms
  03:33:42.094 [user] ts=2024-11-22T03:33:42.093986053Z caller=middlewares.go:157 method=Health result=2 took=707.628µs  (×2)
  03:33:42.152 [user] ts=2024-11-22T03:33:42.152694011Z caller=middlewares.go:46 method=Register username=kawRNTixjIkddrl email=kawRNTixjIkddrl@gmail.com took=1.280771ms
  03:33:43.361 [user] ts=2024-11-22T03:33:43.36175006Z caller=middlewares.go:75 method=GetUsers id=673ffb84b0df5c00019b282d result=1 took=876.904µs  (×11)
  03:33:43.378 [user] ts=2024-11-22T03:33:43.377837829Z caller=middlewares.go:134 method=GetCards id=673ffb8ab0df5c00019b2843 result=1 took=595.752µs  (×2)
  03:33:43.378 [user] ts=2024-11-22T03:33:43.377838785Z caller=middlewares.go:104 method=GetAddresses id=673ffb8ab0df5c00019b2842 result=1 took=692.557µs  (×2)
All services, 30 seconds either side (sampled):
  03:33:14.280 [user] ts=2024-11-22T03:33:14.280447102Z caller=middlewares.go:104 method=GetAddresses id=673ffb72b0df5c00019b27ee result=1 took=876.674µs  (×53)
  03:33:14.375 [front-end] GET /catalogue 200 - ms - -  (×66)
  03:33:14.582 [front-end] DELETE /cart 503 - ms - -  (×65)
  03:33:15.609 [front-end] Received response: "{\"firstName\":\"LZlDtlVkxGaH\",\"lastName\":\"LZlDtlVkxGaH\",\"username\":\"LZlDtlVkxGaH\",\"id\":\"673ffb6bb0df5c00019b27da\",\"_links\":{
  03:33:15.982 [user] ts=2024-11-22T03:33:15.982214422Z caller=middlewares.go:46 method=Register username=TrMGZkyRZ email=TrMGZkyRZ@gmail.com took=1.003327ms
  03:33:16.342 [user] ts=2024-11-22T03:33:16.342208407Z caller=middlewares.go:75 method=GetUsers id=673ffb67b0df5c00019b27c9 result=1 took=1.043161ms  (×36)
  03:33:16.847 [user] ts=2024-11-22T03:33:16.846935787Z caller=middlewares.go:46 method=Register username=WhbIoXyrAtuytnU email=WhbIoXyrAtuytnU@gmail.com took=992.125µs  (×14)
  03:33:18.054 [front-end] POST to carts: http://carts/carts/673ffb74b0df5c00019b27fa/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}  (×29)
  03:33:21.094 [user] ts=2024-11-22T03:33:21.094148421Z caller=middlewares.go:157 method=Health result=2 took=1.047449ms  (×3)
  03:33:22.912 [user] ts=2024-11-22T03:33:22.912289073Z caller=middlewares.go:46 method=Register username=SIRLTM email=SIRLTM@gmail.com took=1.268698ms
  03:33:24.615 [front-end] Received response: "{\"firstName\":\"wQynfxMnpuO\",\"lastName\":\"wQynfxMnpuO\",\"username\":\"wQynfxMnpuO\",\"id\":\"673ffb6eb0df5c00019b27e3\",\"_links\":{\"a
  03:33:26.540 [user] ts=2024-11-22T03:33:26.539858147Z caller=middlewares.go:46 method=Register username=VJGglye email=VJGglye@gmail.com took=948.237µs
  03:33:29.286 [carts] 2024-11-22 03:33:29.286 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricsFilter' to: [/*]  (×7)
  03:33:34.081 [front-end] Received response: "{\"firstName\":\"aNdFIdrRbHC\",\"lastName\":\"aNdFIdrRbHC\",\"username\":\"aNdFIdrRbHC\",\"id\":\"673ffb7db0df5c00019b2815\",\"_links\":{\"a
  03:33:36.135 [front-end] Posting Customer: {"username":"rrgyCZ","password":"cXQJPzGixR","email":"rrgyCZ@gmail.com","firstName":"rrgyCZ","lastName":"rrgyCZ"}
  03:33:39.240 [front-end] Received response: "{\"firstName\":\"gsgGmxLUYu\",\"lastName\":\"gsgGmxLUYu\",\"username\":\"gsgGmxLUYu\",\"id\":\"673ffb7fb0df5c00019b2818\",\"_links\":{\"addr
  03:33:41.913 [user] ts=2024-11-22T03:33:41.913311318Z caller=middlewares.go:46 method=Register username=APmrfhOzv email=APmrfhOzv@gmail.com took=945.028µs
  03:33:46.412 [front-end] Received response: "{\"firstName\":\"wjltiaKMhIQWgsE\",\"lastName\":\"wjltiaKMhIQWgsE\",\"username\":\"wjltiaKMhIQWgsE\",\"id\":\"673ffb83b0df5c00019b2826\",\"_
  03:33:49.063 [front-end] Received response: "{\"firstName\":\"wwiuNOWiSORrd\",\"lastName\":\"wwiuNOWiSORrd\",\"username\":\"wwiuNOWiSORrd\",\"id\":\"673ffb87b0df5c00019b283c\",\"_links\
  03:33:52.977 [front-end] Posting Customer: {"username":"DVZJHFBzPsrh","password":"mNNViBZBF","email":"DVZJHFBzPsrh@gmail.com","firstName":"DVZJHFBzPsrh","lastName":"DVZJHFBzPsrh"}
  03:33:59.087 [front-end] Posting Customer: {"username":"YJVFdVWMw","password":"fBRQSU","email":"YJVFdVWMw@gmail.com","firstName":"YJVFdVWMw","lastName":"YJVFdVWMw"}
  03:34:00.987 [front-end] Received response: "{\"firstName\":\"NYnnsUtjnB\",\"lastName\":\"NYnnsUtjnB\",\"username\":\"NYnnsUtjnB\",\"id\":\"673ffb8fb0df5c00019b285a\",\"_links\":{\"addr
  03:34:02.750 [user] ts=2024-11-22T03:34:02.749931366Z caller=middlewares.go:46 method=Register username=QnXDnBV email=QnXDnBV@gmail.com took=1.040674ms
  03:34:04.632 [front-end] Received response: "{\"firstName\":\"UGnsoaKOfg\",\"lastName\":\"UGnsoaKOfg\",\"username\":\"UGnsoaKOfg\",\"id\":\"673ffb99b0df5c00019b286e\",\"_links\":{\"addr
  03:34:09.187 [carts] 2024-11-22 03:34:09.187 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[GET],produces=
  03:34:09.191 [carts] 2024-11-22 03:34:09.191 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:34:12.460 [front-end] Posting Customer: {"username":"KyAFZsVVE","password":"DbHajOAiN","email":"KyAFZsVVE@gmail.com","firstName":"KyAFZsVVE","lastName":"KyAFZsVVE"}
  03:34:13.622 [user] ts=2024-11-22T03:34:13.622270819Z caller=middlewares.go:46 method=Register username=Umaupu email=Umaupu@gmail.com took=1.083971ms

## p0230
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:53:49.093Z
```
{"timestamp":1731916429093385500,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"serving product page"}
```
Same service, the 2 minutes before (oldest first):
  07:53:45.775 [frontend] order placed
  07:53:45.797 [frontend] request complete  (×6)
  07:53:46.985 [frontend] request started  (×6)
  07:53:46.985 [frontend] home  (×2)
  07:53:47.030 [frontend] ENV_PLATFORM is: aws  (×2)
  07:53:48.477 [frontend] serving product page  (×2)
  07:53:48.593 [frontend] setting currency
All services, 30 seconds either side (sampled):
  07:53:19.095 [currencyservice] conversion request successful  (×785)
  07:53:19.124 [adservice] received ad request (context_words=[])  (×45)
  07:53:19.300 [frontend] request started  (×320)
  07:53:19.303 [currencyservice] Getting supported currencies...  (×255)
  07:53:19.322 [recommendationservice] [Recv ListRecommendations] product_ids=['9SIQT8TOJO', '6E92ZMYYFZ', 'L9ECAV7KIM', '1YMWWN1N4O', '0PUK6V6EV0']  (×207)
  07:53:19.332 [adservice] received ad request (context_words=[clothing, tops])  (×15)
  07:53:19.350 [shippingservice] [GetQuote] completed request  (×77)
  07:53:19.870 [frontend] home  (×44)
  07:53:20.173 [cartservice] AddItemAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43, productId=66VCHSJNUP, quantity=3  (×35)
  07:53:20.242 [frontend] placing order  (×7)
  07:53:20.286 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"78007","nanos":975233281},"credit_card":{"credit_card_number":"414432022675  (×2)
  07:53:20.289 [checkoutservice] payment went through (transaction_id: 8672a4ac-c25f-43be-aa08-3d0e5181f483)  (×7)
  07:53:20.290 [shippingservice] [ShipOrder] completed request  (×7)
  07:53:20.298 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 13  (×7)
  07:53:20.302 [checkoutservice] failed to send order confirmation to "stevenlewis@example.org": rpc error: code = Internal desc = Failed to serialize response!
  07:53:20.613 [adservice] received ad request (context_words=[kitchen])  (×48)
  07:53:23.694 [adservice] received ad request (context_words=[footwear])  (×17)
  07:53:25.804 [adservice] received ad request (context_words=[hair, beauty])  (×16)
  07:53:32.252 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"1212","nanos":696017704},"credit_card":{"credit_card_number":"4231918750980  (×3)
  07:53:32.267 [emailservice] A request to send order confirmation email to stacy95@example.org has been received.
  07:53:35.209 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', 'OLJCESPC7Z', '1YMWWN1N4O', '0PUK6V6EV0']  (×3)
  07:53:35.374 [checkoutservice] failed to send order confirmation to "vwalker@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:53:37.641 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"37","nanos":441967271},"credit_card":{"credit_card_number":"474030341009273
  07:53:37.654 [emailservice] A request to send order confirmation email to williamsfrank@example.org has been received.
  07:53:44.116 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="USD"
  07:53:44.144 [paymentservice] Transaction processed: visa ending 6323 Amount: USD303.850000000
  07:53:44.158 [checkoutservice] failed to send order confirmation to "jfuentes@example.org": rpc error: code = Internal desc = Failed to serialize response!
  07:53:45.774 [checkoutservice] failed to send order confirmation to "jamesflores@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:53:59.759 [checkoutservice] failed to send order confirmation to "marvinriley@example.net": rpc error: code = Internal desc = Failed to serialize response!

## p0149
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:40:04.540Z
```
{"timestamp":1731908404540961500,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"serving product page"}
```
Same service, the 2 minutes before (oldest first):
  05:40:02.608 [frontend] request complete  (×7)
  05:40:02.640 [frontend] request started  (×7)
  05:40:02.640 [frontend] serving product page  (×5)
  05:40:02.994 [frontend] view user cart
All services, 30 seconds either side (sampled):
  05:39:35.138 [frontend] request started  (×291)
  05:39:35.147 [cartservice] GetCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×246)
  05:39:35.172 [adservice] received ad request (context_words=[kitchen])  (×52)
  05:39:35.181 [cartservice] AddItemAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927, productId=LS4PSXUNUM, quantity=7  (×26)
  05:39:35.215 [shippingservice] [GetQuote] completed request  (×62)
  05:39:37.027 [frontend] placing order  (×8)
  05:39:37.049 [paymentservice] Transaction processed: visa ending 3497 Amount: USD141.920000000
  05:39:37.053 [shippingservice] [ShipOrder] completed request  (×7)
  05:39:37.064 [checkoutservice] order confirmation email sent to "nicholasvillegas@example.org"
  05:39:38.826 [frontend] home  (×30)
  05:39:39.129 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', 'OLJCESPC7Z', '1YMWWN1N4O', 'LS4PSXUNUM']  (×6)
  05:39:39.548 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"108","nanos":266686419},"credit_card":{"credit_card_number":"48758128453958  (×3)
  05:39:39.561 [checkoutservice] order confirmation email sent to "qcalhoun@example.org"
  05:39:52.764 [emailservice] A request to send order confirmation email to jilllopez@example.net has been received.
  05:40:01.867 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"2423","nanos":8251247},"credit_card":{"credit_card_number":"419071745454014  (×3)
  05:40:01.880 [checkoutservice] order confirmation email sent to "chad79@example.org"
  05:40:12.251 [paymentservice] Transaction processed: visa ending 0507 Amount: CAD330.955945155
  05:40:21.103 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×4)
  05:40:26.620 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  05:40:26.625 [frontend] request error
  05:40:31.394 [emailservice] A request to send order confirmation email to onealkevin@example.org has been received.

## p0313
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:20:31.593Z
```
{"timestamp":1732245631593009700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /cart 500 30.657 ms - 64"}
```
Same service, the 2 minutes before (oldest first):
  03:20:30.885 [front-end] Sent cookies.  (×2)
  03:20:30.886 [front-end] POST /register 200 85.831 ms - 33  (×2)
  03:20:31.454 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff877b0df5c00019b1eec"}
  03:20:31.462 [front-end] POST /addresses 200 - ms - -
  03:20:31.467 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff877b0df5c00019b1eec"}
  03:20:31.475 [front-end] POST /cards 200 - ms - -
  03:20:31.505 [front-end] Posting Customer: {"username":"pPOWMtcwKJaePCn","password":"KHxGo","email":"pPOWMtcwKJaePCn@gmail.com","firstName":"pPOWMtcwKJaePCn","lastName":"pPOWMtcwKJaePCn
  03:20:31.510 [front-end] { id: '673ff87fb0df5c00019b1f03' }
  03:20:31.510 [front-end] 673ff87fb0df5c00019b1f03
  03:20:31.510 [front-end] Merging carts for customer id: 673ff87fb0df5c00019b1f03 and session id: d0fyODfgmoMPZCz_fr2CxWlmdbrKeQQ1
  03:20:31.524 [front-end] Attempting to delete cart for user: 673ff877b0df5c00019b1eec
  03:20:31.549 [front-end] User cart deleted with status: 503
  03:20:31.552 [front-end] DELETE /cart 503 - ms - -
  03:20:31.559 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}
  03:20:31.567 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
  03:20:31.567 [front-end] POST to carts: http://carts/carts/673ff877b0df5c00019b1eec/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}
  03:20:31.586 [front-end] Carts merged.
  03:20:31.586 [front-end] set cookie673ff87fb0df5c00019b1f03
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×34)
  03:20:06.543 [front-end] Posting Order: {"customer":"http://user/customers/673ff84eb0df5c00019b1e6c","address":"http://user/addresses/673ff854b0df5c00019b1e7e","card":"http://user/cards  (×52)
  03:20:06.649 [user] ts=2024-11-22T03:20:06.649242768Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff861b0df5c00019b1e9e took=1.734848ms  (×57)
  03:20:06.789 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×9)
  03:20:07.186 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×10)
  03:20:08.474 [front-end] 673ff868b0df5c00019b1eb9  (×55)
  03:20:09.093 [user] ts=2024-11-22T03:20:09.093533288Z caller=middlewares.go:46 method=Register username=CBhyKd email=CBhyKd@gmail.com took=1.350871ms
  03:20:09.910 [front-end] Posting Customer: {"username":"uQhCpCJIyYL","password":"dElvDjn","email":"uQhCpCJIyYL@gmail.com","firstName":"uQhCpCJIyYL","lastName":"uQhCpCJIyYL"}
  03:20:12.002 [front-end] Received response: "{\"firstName\":\"oVuSYHHeDcohK\",\"lastName\":\"oVuSYHHeDcohK\",\"username\":\"oVuSYHHeDcohK\",\"id\":\"673ff855b0df5c00019b1e85\",\"_links\
  03:20:15.090 [front-end] Received response: "{\"firstName\":\"NNuouUNggTNDT\",\"lastName\":\"NNuouUNggTNDT\",\"username\":\"NNuouUNggTNDT\",\"id\":\"673ff859b0df5c00019b1e89\",\"_links\
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:20.995 [front-end] Received response: "{\"firstName\":\"WQulX\",\"lastName\":\"WQulX\",\"username\":\"WQulX\",\"id\":\"673ff85fb0df5c00019b1e97\",\"_links\":{\"addresses\":{\"href
  03:20:26.017 [front-end] Posting Customer: {"username":"HLNoIPafm","password":"sBlBYfK","email":"HLNoIPafm@gmail.com","firstName":"HLNoIPafm","lastName":"HLNoIPafm"}
  03:20:29.280 [front-end] Received response: "{\"firstName\":\"iyaZwEHsMf\",\"lastName\":\"iyaZwEHsMf\",\"username\":\"iyaZwEHsMf\",\"id\":\"673ff861b0df5c00019b1ea0\",\"_links\":{\"addr
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.676 [front-end] Received response: "{\"firstName\":\"BBYdunXrngQk\",\"lastName\":\"BBYdunXrngQk\",\"username\":\"BBYdunXrngQk\",\"id\":\"673ff874b0df5c00019b1ee8\",\"_links\":{
  03:20:38.070 [session-db] 1:M 22 Nov 2024 03:20:38.070 * Background saving started by pid 32
  03:20:40.151 [user] ts=2024-11-22T03:20:40.151621717Z caller=middlewares.go:46 method=Register username=dOIvn email=dOIvn@gmail.com took=1.048258ms
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:20:46.654 [front-end] Received response: "{\"firstName\":\"iLqTiAFoVbIq\",\"lastName\":\"iLqTiAFoVbIq\",\"username\":\"iLqTiAFoVbIq\",\"id\":\"673ff877b0df5c00019b1eec\",\"_links\":{
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.sp
  03:20:51.235 [front-end] Posting Customer: {"username":"cqPFUedoarsUCI","password":"BNbmkot","email":"cqPFUedoarsUCI@gmail.com","firstName":"cqPFUedoarsUCI","lastName":"cqPFUedoarsUCI"}
  03:20:54.897 [front-end] Posting Customer: {"username":"cfTPDbfduekTBf","password":"FQrLzttH","email":"cfTPDbfduekTBf@gmail.com","firstName":"cfTPDbfduekTBf","lastName":"cfTPDbfduekTBf"
  03:20:58.176 [front-end] Received response: "{\"firstName\":\"MpDJxkmv\",\"lastName\":\"MpDJxkmv\",\"username\":\"MpDJxkmv\",\"id\":\"673ff87eb0df5c00019b1f00\",\"_links\":{\"addresses\
  03:20:59.688 [carts] 2024-11-22 03:20:59.688 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[OPTIONS],produces=[applica
  03:20:59.783 [carts] 2024-11-22 03:20:59.783 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal
  03:20:59.789 [carts] 2024-11-22 03:20:59.789 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],produc
  03:21:00.716 [front-end] Posting Customer: {"username":"bDjuXlWHATfWj","password":"ynjkfXmXiY","email":"bDjuXlWHATfWj@gmail.com","firstName":"bDjuXlWHATfWj","lastName":"bDjuXlWHATfWj"}

## p0670
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-11T12:13:55.503Z
```
{"service":"webservice2","message":"2021-08-11 12:13:55,503 | INFO | 0.0.0.3 | 172.17.0.4 | webservice2 | be8cf8a87941238f | now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  12:13:52.531 [webservice2] INFO uuid: 896cae8c-fa5a-11eb-b007-0242ac110004 write redis successfully  (×3)
  12:13:52.637 [webservice2] INFO complete information: {'uuid': '896cae8c-fa5a-11eb-b007-0242ac110004', 'user_id': 'SNyDIdeO'}  (×3)
  12:13:52.645 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×3)
  12:13:52.646 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  12:13:53.202 [webservice2] ERROR an error occurred in the downstream service
  12:13:53.249 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  12:13:53.249 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×2)
  12:13:53.250 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '89e554a4-fa5a-11eb-985d-0242ac110004', 'value': '', 'ex': 10}  (×2)
All services, 30 seconds either side (sampled):
  12:13:25.510 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×40)
  12:13:25.815 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×39)
  12:13:25.925 [redisservice1] INFO service accept, status_code: 200  (×36)
  12:13:26.288 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×44)
  12:13:26.540 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×45)
  12:13:27.096 [redisservice2] INFO redis write success  (×89)
  12:13:28.496 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  12:13:28.765 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×38)
  12:13:30.041 [dbservice1] INFO 7b9ef9b8-fa5a-11eb-a35c-0242ac110003-aCdZXfNn-HVB*h$/mtRAv token generate success token=MTYyODY1NTIxMC4wNDA5OTY6N2I5ZWY5YjgtZmE1YS0xMWViLWEzNWMtMDI0MmFjMTE
  12:13:31.428 [mobservice1] INFO info 7ca77a7e-fa5a-11eb-b1a1-0242ac110004:DkpCcNIV write success
  12:13:34.233 [mobservice2] INFO info 7e590bc6-fa5a-11eb-a271-0242ac110003:NOmfIvPM write success
  12:13:36.867 [mobservice2] INFO info 7fdf1e54-fa5a-11eb-895e-0242ac110003:dImbafKg write success
  12:13:39.448 [mobservice1] INFO info 817559cc-fa5a-11eb-be7c-0242ac110004:gwdEDvWp write success
  12:13:42.015 [mobservice2] INFO info 82f03b32-fa5a-11eb-8b1a-0242ac110004:IwBSEYcZ write success
  12:13:44.733 [dbservice2] INFO 8458d4c0-fa5a-11eb-814f-0242ac110004-JXejhiMl-97R5_3u8cLX? token generate success token=MTYyODY1NTIyNC43MzMwMDI0Ojg0NThkNGMwLWZhNWEtMTFlYi04MTRmLTAyNDJhYzE
  12:13:47.242 [dbservice1] INFO 85e67f4a-fa5a-11eb-94ab-0242ac110004-vpXbgtCB-_*/-kYvxu+yC token generate success token=MTYyODY1NTIyNy4yNDIyMzA0Ojg1ZTY3ZjRhLWZhNWEtMTFlYi05NGFiLTAyNDJhYzE
  12:13:50.161 [mobservice2] INFO info 87da6456-fa5a-11eb-9399-0242ac110004:EVqCPZRD write success
  12:13:53.166 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat  (×2)
  12:13:55.860 [mobservice1] INFO info 8b3d388a-fa5a-11eb-a9b4-0242ac110004:zoVLGdbn write success
  12:13:58.650 [mobservice2] INFO info 8ce67f48-fa5a-11eb-851c-0242ac110003:YDlFxnqQ write success
  12:14:01.561 [dbservice1] INFO 8e539f64-fa5a-11eb-95c9-0242ac110003-RIklYufT-gZ(@VjR5X^<E token generate success token=MTYyODY1NTI0MS41NjEzODk6OGU1MzlmNjQtZmE1YS0xMWViLTk1YzktMDI0MmFjMTE
  12:14:04.406 [mobservice1] INFO info 9054353a-fa5a-11eb-8185-0242ac110004:ZQXfBztT write success
  12:14:10.256 [mobservice1] INFO info 93cd963e-fa5a-11eb-a4e8-0242ac110003:spFyrBHI write success
  12:14:16.013 [mobservice2] INFO info 9730eb8c-fa5a-11eb-9e4e-0242ac110003:rwdmTblM write success
  12:14:18.599 [mobservice1] INFO info 98c9de86-fa5a-11eb-9bc8-0242ac110003:HBlmbePk write success
  12:14:21.716 [mobservice1] INFO info 9aa4a146-fa5a-11eb-8f82-0242ac110004:SgtQlrMk write success
  12:14:24.488 [mobservice2] INFO info 9c49d638-fa5a-11eb-af69-0242ac110004:LPlrKejU write success

## p0479
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:17:40.902Z
```
{"timestamp":1732349860902825500,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"npm ERR! path /usr/src/app"}
```
Same service, the 2 minutes before (oldest first):
  08:17:40.283 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732349860280,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde
  08:17:40.283 [front-end] Order response: {"timestamp":1732349860280,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli
  08:17:40.285 [front-end] POST /orders 406 - ms - -
  08:17:40.900 [front-end] npm timing command:run-script Completed in 795498ms
  08:17:40.900 [front-end] npm timing command:start Completed in 795556ms
  08:17:40.900 [front-end] npm notice   (×2)
  08:17:40.900 [front-end] npm notice New major version of npm available! 8.19.4 -> 10.9.1
  08:17:40.900 [front-end] npm notice Changelog: <https://github.com/npm/cli/releases/tag/v10.9.1>
  08:17:40.900 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!
  08:17:40.902 [front-end] npm verb stack Error: command failed
  08:17:40.902 [front-end] npm verb stack at ChildProcess.<anonymous> (/usr/local/lib/node_modules/npm/node_modules/@npmcli/promise-spawn/lib/index.js:63:27)
  08:17:40.902 [front-end] npm verb stack at ChildProcess.emit (node:events:513:28)
  08:17:40.902 [front-end] npm verb stack at maybeClose (node:internal/child_process:1100:16)
  08:17:40.902 [front-end] npm verb stack at Process.ChildProcess._handle.onexit (node:internal/child_process:304:5)
  08:17:40.902 [front-end] npm verb pkgid microservices-demo-front-end@0.0.1
  08:17:40.902 [front-end] npm verb cwd /usr/src/app
  08:17:40.902 [front-end] npm verb Linux 5.10.227-219.884.amzn2.x86_64
  08:17:40.902 [front-end] npm verb node v16.20.2
  08:17:40.902 [front-end] npm verb npm v8.19.4
All services, 30 seconds either side (sampled):
  08:17:11.123 [front-end] Posting Customer: {"username":"QRhdA","password":"HNBUiuhCFK","email":"QRhdA@gmail.com","firstName":"QRhdA","lastName":"QRhdA"}
  08:17:11.402 [user] ts=2024-11-23T08:17:11.402696116Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418f7ea437380001def440 took=3.96969ms  (×49)
  08:17:11.497 [front-end] POST to carts: http://carts/carts/67418f7ea437380001def440/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×25)
  08:17:11.791 [front-end] Posting Order: {"customer":"http://user/customers/67418f76a437380001def427","address":"http://user/addresses/67418f7ea437380001def443","card":"http://user/cards  (×50)
  08:17:11.817 [queue-master] 2024-11-23 08:17:11.817 ERROR 7 --- [ool-6-thread-31] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×20)
  08:17:12.383 [catalogue] ts=2024-11-23T08:17:12Z caller=logging.go:85 method=Health result=2 took=25.962µs  (×40)
  08:17:13.850 [user] ts=2024-11-23T08:17:13.850301423Z caller=middlewares.go:157 method=Health result=2 took=2.694113ms  (×40)
  08:17:16.173 [front-end] Order response: {"id":"67418f8c3f77060008865085","customerId":"67418f74a437380001def422","customer":{"id":null,"firstName":"bTsDpZbGpl","lastName":"bTsDpZbGpl",
  08:17:16.995 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×11)
  08:17:18.715 [front-end] Posting Customer: {"username":"AHLEGfzWOkJSK","password":"WZnyHLi","email":"AHLEGfzWOkJSK@gmail.com","firstName":"AHLEGfzWOkJSK","lastName":"AHLEGfzWOkJSK"}
  08:17:20.207 [front-end] Received response: "{\"firstName\":\"eXwxPKpvOLhZ\",\"lastName\":\"eXwxPKpvOLhZ\",\"username\":\"eXwxPKpvOLhZ\",\"id\":\"67418f7da437380001def43e\",\"_links\":{
  08:17:22.446 [front-end] Order response: {"id":"67418f923f7706000886508d","customerId":"67418f7aa437380001def431","customer":{"id":null,"firstName":"QyeRRnQZmNfKX","lastName":"QyeRRnQZm
  08:17:24.854 [front-end] Received response: "{\"firstName\":\"hDADdujiVgp\",\"lastName\":\"hDADdujiVgp\",\"username\":\"hDADdujiVgp\",\"id\":\"67418f7ca437380001def439\",\"_links\":{\"a
  08:17:27.573 [front-end] Order response: {"id":"67418f973f77060008865091","customerId":"67418f83a437380001def457","customer":{"id":null,"firstName":"HwJeJftl","lastName":"HwJeJftl","use
  08:17:28.253 [front-end] npm timing npm:load:whichnode Completed in 0ms  (×2)
  08:17:28.253 [front-end] npm timing config:load:validate Completed in 1ms  (×2)
  08:17:28.254 [front-end] npm timing npm:load:display Completed in 8ms  (×2)
  08:17:29.112 [queue-master] 2024-11-23 08:17:29.112 INFO 7 --- [pool-6-thread-3] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×24)
  08:17:30.858 [front-end] Using the redis based session manager
  08:17:32.825 [front-end] Order response: {"id":"67418f9c3f77060008865097","customerId":"67418f83a437380001def45a","customer":{"id":null,"firstName":"pOdFHAXyWrS","lastName":"pOdFHAXyWrS
  08:17:34.861 [front-end] Posting Customer: {"username":"bwDjbwXxI","password":"KnrQLgvYFB","email":"bwDjbwXxI@gmail.com","firstName":"bwDjbwXxI","lastName":"bwDjbwXxI"}
  08:17:36.195 [front-end] Posting Customer: {"username":"LSoIyTnpnDI","password":"TJJqPCKCj","email":"LSoIyTnpnDI@gmail.com","firstName":"LSoIyTnpnDI","lastName":"LSoIyTnpnDI"}
  08:17:39.264 [front-end] Order response: {"id":"67418fa33f7706000886509b","customerId":"67418f90a437380001def47a","customer":{"id":null,"firstName":"qEFqyOJF","lastName":"qEFqyOJF","use
  08:17:40.900 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!  (×2)
  08:17:40.904 [front-end] npm ERR! command failed  (×2)
  08:17:48.008 [front-end] Posting Customer: {"username":"EPQaiJm","password":"lypRom","email":"EPQaiJm@gmail.com","firstName":"EPQaiJm","lastName":"EPQaiJm"}
  08:17:52.024 [front-end] Posting Order: {"customer":"http://user/customers/67418f9fa437380001def4a8","address":null,"card":null,"items":"http://carts/carts/67418f9fa437380001def4a8/item  (×6)
  08:17:56.736 [front-end] Posting Customer: {"username":"oYJYFgYFnZzQlq","password":"VVPjLX","email":"oYJYFgYFnZzQlq@gmail.com","firstName":"oYJYFgYFnZzQlq","lastName":"oYJYFgYFnZzQlq"}
  08:18:01.550 [front-end] Received response: "{\"firstName\":\"fhvyKaGX\",\"lastName\":\"fhvyKaGX\",\"username\":\"fhvyKaGX\",\"id\":\"67418fa3a437380001def4b7\",\"_links\":{\"addresses\
  08:18:07.314 [front-end] Received response: "{\"firstName\":\"EPQaiJm\",\"lastName\":\"EPQaiJm\",\"username\":\"EPQaiJm\",\"id\":\"67418faca437380001def4c0\",\"_links\":{\"addresses\":{

## p0213
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T07:40:35.382Z
```
{"timestamp":1731915635382889700,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Getting supported currencies..."}
```
Same service, the 2 minutes before (oldest first):
  07:40:34.381 [currencyservice] conversion request successful  (×13)
  07:40:34.534 [currencyservice] Getting supported currencies...  (×7)
All services, 30 seconds either side (sampled):
  07:40:05.561 [frontend] request started  (×322)
  07:40:05.563 [frontend] home  (×25)
  07:40:05.577 [currencyservice] conversion request successful  (×648)
  07:40:05.644 [frontend] serving product page  (×153)
  07:40:05.681 [frontend] adding to cart  (×40)
  07:40:05.718 [shippingservice] [GetQuote] received request  (×87)
  07:40:05.772 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', '9SIQT8TOJO', '1YMWWN1N4O', 'OLJCESPC7Z']  (×10)
  07:40:06.974 [frontend] placing order  (×10)
  07:40:06.993 [paymentservice] Transaction processed: visa ending 4598 Amount: JPY13744.672269244  (×4)
  07:40:06.996 [shippingservice] [ShipOrder] completed request  (×10)
  07:40:07.007 [checkoutservice] order confirmation email sent to "rodriguezmichael@example.com"
  07:40:15.764 [adservice] received ad request (context_words=[hair, beauty])  (×19)
  07:40:18.557 [paymentservice] Transaction processed: visa ending 9860 Amount: GBP956.787924799  (×2)
  07:40:24.410 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="EUR"  (×2)
  07:40:24.446 [emailservice] A request to send order confirmation email to stevenortiz@example.net has been received.
  07:40:29.942 [checkoutservice] order confirmation email sent to "woodardmatthew@example.org"
  07:40:38.169 [paymentservice] Transaction processed: visa ending 3881 Amount: TRY7022.790684688
  07:40:40.768 [emailservice] A request to send order confirmation email to barrettmichael@example.net has been received.
  07:40:46.441 [checkoutservice] [PlaceOrder] user_id="5e004f2d-a61a-45b2-840d-6bfd47a2be43" user_currency="USD"
  07:40:46.500 [emailservice] A request to send order confirmation email to stephen11@example.net has been received.
  07:40:47.470 [checkoutservice] order confirmation email sent to "floresnicole@example.net"
  07:41:00.871 [emailservice] A request to send order confirmation email to wendybryant@example.com has been received.

## p0329
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:21:08.990Z
```
{"timestamp":1732245668990797600,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:21:08.990  INFO [carts,,,] 7 --- [           main] o.s.j.e.a.AnnotationMBeanExporter        : Located managed bean 'environmentManager': registering with JMX server as MBean [org.springframework.cloud.context.environment:name=environmentManager,type=EnvironmentManager]"}
```
Same service, the 2 minutes before (oldest first):
  03:21:03.086 [carts] 2024-11-22 03:21:03.086 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.s
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto 
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public j
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  03:21:03.184 [carts] 2024-11-22 03:21:03.183 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces
  03:21:03.285 [carts] 2024-11-22 03:21:03.285 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/
  03:21:06.490 [carts] 2024-11-22 03:21:06.489 INFO [carts,,,] 7 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  03:21:08.790 [carts] 2024-11-22 03:21:08.790 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetected
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposur  (×2)
  03:21:08.986 [carts] 2024-11-22 03:21:08.986 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  03:21:08.987 [carts] 2024-11-22 03:21:08.987 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
All services, 30 seconds either side (sampled):
  03:20:39.075 [front-end] Posting Customer: {"username":"ELXzX","password":"iajeZG","email":"ELXzX@gmail.com","firstName":"ELXzX","lastName":"ELXzX"}
  03:20:39.646 [user] ts=2024-11-22T03:20:39.646147266Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff87fb0df5c00019b1f03 took=1.919577ms  (×57)
  03:20:39.906 [catalogue] ts=2024-11-22T03:20:39Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=4.413476  (×48)
  03:20:41.184 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff  (×54)
  03:20:42.525 [front-end] Posting Customer: {"username":"jVIVRgJfOAq","password":"zWZXxq","email":"jVIVRgJfOAq@gmail.com","firstName":"jVIVRgJfOAq","lastName":"jVIVRgJfOAq"}
  03:20:43.389 [carts] 2024-11-22 03:20:43.388 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[GET],produces=[applicat
  03:20:48.920 [front-end] Posting Customer: {"username":"DnjBelnPao","password":"eQMYAKREBx","email":"DnjBelnPao@gmail.com","firstName":"DnjBelnPao","lastName":"DnjBelnPao"}
  03:20:51.502 [front-end] Received response: "{\"firstName\":\"znIVGAMLgnSste\",\"lastName\":\"znIVGAMLgnSste\",\"username\":\"znIVGAMLgnSste\",\"id\":\"673ff880b0df5c00019b1f04\",\"_lin
  03:20:55.766 [front-end] Posting Customer: {"username":"PvCLeeg","password":"pTqmeIPqX","email":"PvCLeeg@gmail.com","firstName":"PvCLeeg","lastName":"PvCLeeg"}
  03:20:59.661 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×6)
  03:20:59.783 [carts] 2024-11-22 03:20:59.783 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal
  03:20:59.886 [carts] 2024-11-22 03:20:59.885 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applicati  (×2)
  03:21:02.589 [user] ts=2024-11-22T03:21:02.589004338Z caller=middlewares.go:46 method=Register username=UFhesIA email=UFhesIA@gmail.com took=1.127131ms
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  03:21:04.514 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×2)
  03:21:08.986 [carts] 2024-11-22 03:21:08.986 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  03:21:11.490 [user] ts=2024-11-22T03:21:11.48978732Z caller=middlewares.go:46 method=Register username=onbFNMM email=onbFNMM@gmail.com took=993.598µs
  03:21:14.059 [front-end] Received response: "{\"firstName\":\"bDjuXlWHATfWj\",\"lastName\":\"bDjuXlWHATfWj\",\"username\":\"bDjuXlWHATfWj\",\"id\":\"673ff89cb0df5c00019b1f51\",\"_links\
  03:21:16.220 [front-end] Posting Customer: {"username":"XSDCLJKgyLoxe","password":"WVMgfuZdos","email":"XSDCLJKgyLoxe@gmail.com","firstName":"XSDCLJKgyLoxe","lastName":"XSDCLJKgyLoxe"}
  03:21:18.596 [orders] 2024-11-22 03:21:18.596 INFO [orders,40393c2387463fc4,20a8cb1f4ece78de,false] 6 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Sending payment req  (×17)
  03:21:18.619 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8aed94b9000069b438c","customerId":"673ff89cb0df5c00019b1f51","customer":{"id":null,"firstName":"bDjuXlWHATf
  03:21:19.233 [front-end] Received response: "{\"firstName\":\"cfTPDbfduekTBf\",\"lastName\":\"cfTPDbfduekTBf\",\"username\":\"cfTPDbfduekTBf\",\"id\":\"673ff896b0df5c00019b1f3c\",\"_lin
  03:21:19.905 [front-end] Order response: {"id":"673ff8afd94b9000069b4393","customerId":"673ff89eb0df5c00019b1f54","customer":{"id":null,"firstName":"gKGbBfBuFal","lastName":"gKGbBfBuFal
  03:21:20.783 [carts] 2024-11-22 03:21:20.783 INFO [carts,c68cb8218e3d30a3,e9e627c1a2386c43,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×11)
  03:21:23.285 [front-end] Posting Customer: {"username":"BHMHa","password":"KrLeziWwdr","email":"BHMHa@gmail.com","firstName":"BHMHa","lastName":"BHMHa"}
  03:21:28.217 [front-end] Received response: "{\"firstName\":\"MszyyqkjNcAvcB\",\"lastName\":\"MszyyqkjNcAvcB\",\"username\":\"MszyyqkjNcAvcB\",\"id\":\"673ff8a4b0df5c00019b1f73\",\"_lin
  03:21:32.503 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8bcd94b9000069b439e","customerId":"673ff8a0b0df5c00019b1f63","customer":{"id":null,"firstName":"vpxxpRNxF",
  03:21:34.413 [front-end] Order response: {"id":"673ff8bed94b9000069b43a0","customerId":"673ff8a6b0df5c00019b1f7f","customer":{"id":null,"firstName":"BXlkiHWqBVYl","lastName":"BXlkiHWqBV
  03:21:36.305 [front-end] Order response: {"id":"673ff8c0d94b9000069b43a2","customerId":"673ff8a7b0df5c00019b1f82","customer":{"id":null,"firstName":"onbFNMM","lastName":"onbFNMM","usern

## p0390
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:26.404Z
```
{"timestamp":1732247186404452000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"GET Request to: http://user/customers/673ffe84b0df5c00019b3164/cards"}
```
Same service, the 2 minutes before (oldest first):
  03:46:25.695 [front-end] set cookie673ffe91b0df5c00019b318b  (×2)
  03:46:25.695 [front-end] Sent cookies.  (×2)
  03:46:25.698 [front-end] POST /register 200 52.053 ms - 33  (×2)
  03:46:25.988 [front-end] Posting Customer: {"username":"jAAETa","password":"IwsrY","email":"jAAETa@gmail.com","firstName":"jAAETa","lastName":"jAAETa"}
  03:46:25.993 [front-end] { id: '673ffe91b0df5c00019b318c' }  (×2)
  03:46:25.993 [front-end] 673ffe91b0df5c00019b318c  (×2)
  03:46:25.993 [front-end] Merging carts for customer id: 673ffe91b0df5c00019b318c and session id: OE_o-NswilhBSSbFFISRYSnr3JqEBGyW  (×2)
  03:46:26.006 [front-end] GET /catalogue 200 - ms - -
  03:46:26.044 [front-end] Carts merged.
  03:46:26.373 [front-end] Posting Customer: {"username":"HSRfpVFfwJppXn","password":"XmBVu","email":"HSRfpVFfwJppXn@gmail.com","firstName":"HSRfpVFfwJppXn","lastName":"HSRfpVFfwJppXn"}
  03:46:26.396 [front-end] Request received with body: {}
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:26.404 [front-end] Received response: "{\"firstName\":\"VaPxY\",\"lastName\":\"VaPxY\",\"username\":\"VaPxY\",\"id\":\"673ffe84b0df5c00019b3164\",\"_links\":{\"addresses\":{\"href
  03:46:26.404 [front-end] GET Request to: http://user/customers/673ffe84b0df5c00019b3164/addresses
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×27)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×44)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×58)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×47)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×47)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×45)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×45)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×45)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h

## p0466
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:08:53.766Z
```
{"timestamp":1732349333766836200,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Order: {\"customer\":\"http://user/customers/67418d82a437380001deee46\",\"address\":\"http://user/addresses/67418d89a437380001deee5c\",\"card\":\"http://user/cards/67418d89a437380001deee5d\",\"items\":\"http://carts/carts/67418d82a437380001deee46/items\"}"}
```
Same service, the 2 minutes before (oldest first):
  08:08:53.126 [front-end] POST /cart 201 - ms - -  (×2)
  08:08:53.406 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418d90a437380001deee78"}
  08:08:53.416 [front-end] POST /addresses 200 - ms - -
  08:08:53.421 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67418d90a437380001deee78"}
  08:08:53.431 [front-end] POST /cards 200 - ms - -
  08:08:53.477 [front-end] Attempting to delete cart for user: 67418d90a437380001deee78
  08:08:53.492 [front-end] GET /catalogue 200 - ms - -
  08:08:53.493 [front-end] User cart deleted with status: 202
  08:08:53.496 [front-end] DELETE /cart 202 - ms - -
  08:08:53.503 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}
  08:08:53.511 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
  08:08:53.511 [front-end] POST to carts: http://carts/carts/67418d90a437380001deee78/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}
  08:08:53.745 [front-end] Request received with body: {}
  08:08:53.755 [front-end] Received response: "{\"firstName\":\"ZeaRS\",\"lastName\":\"ZeaRS\",\"username\":\"ZeaRS\",\"id\":\"67418d82a437380001deee46\",\"_links\":{\"addresses\":{\"href
  08:08:53.755 [front-end] GET Request to: http://user/customers/67418d82a437380001deee46/addresses  (×2)
  08:08:53.766 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418d89a437380001deee5d\",\"_links\":{\"
  08:08:53.766 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418
  08:08:53.766 [front-end] [ undefined, undefined ]
All services, 30 seconds either side (sampled):
  08:08:23.787 [orders-db] {"t":{"$date":"2024-11-23T08:08:23.787+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173234930
  08:08:24.021 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×5)
  08:08:24.050 [user] ts=2024-11-23T08:08:24.049989525Z caller=middlewares.go:104 method=GetAddresses id=67418d6aa437380001deedf1 result=1 took=1.911178ms  (×71)
  08:08:24.071 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d783f77060008864e9d","customerId":"67418d62a437380001deede0","customer":{"id":null,"firstName":"iVbUkvuj","
  08:08:24.683 [carts] 2024-11-23 08:08:24.683 INFO [carts,93d9ef367e272c29,febdfb75eeaae3fa,false] 7 --- [-nio-80-exec-19] w.w.s.cart.controllers.ItemsController : Did not find item.  (×37)
  08:08:25.335 [front-end] POST /register 200 25.607 ms - 33  (×61)
  08:08:25.888 [front-end] GET /catalogue 200 - ms - -  (×63)
  08:08:26.659 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×9)
  08:08:27.826 [user] ts=2024-11-23T08:08:27.826713418Z caller=middlewares.go:46 method=Register username=JsZkpwTMC email=JsZkpwTMC@gmail.com took=2.114704ms
  08:08:29.783 [front-end] Received response: "{\"firstName\":\"JXuYeaZNbme\",\"lastName\":\"JXuYeaZNbme\",\"username\":\"JXuYeaZNbme\",\"id\":\"67418d65a437380001deede5\",\"_links\":{\"a
  08:08:33.412 [front-end] Order response: {"id":"67418d813f77060008864ea8","customerId":"67418d6aa437380001deedee","customer":{"id":null,"firstName":"UuTozj","lastName":"UuTozj","usernam
  08:08:35.762 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d833f77060008864eaa","customerId":"67418d6da437380001deedfd","customer":{"id":null,"firstName":"iwcXRT","la
  08:08:37.771 [front-end] Order response: {"id":"67418d853f77060008864ead","customerId":"67418d71a437380001deee0d","customer":{"id":null,"firstName":"ystQcWrZZKmUA","lastName":"ystQcWrZZ
  08:08:39.497 [front-end] Order response: {"id":"67418d873f77060008864eaf","customerId":"67418d75a437380001deee1b","customer":{"id":null,"firstName":"afBVtCoCbIbqxV","lastName":"afBVtCoC
  08:08:41.582 [front-end] Received response: "{\"firstName\":\"lUDfSgDYNQSlug\",\"lastName\":\"lUDfSgDYNQSlug\",\"username\":\"lUDfSgDYNQSlug\",\"id\":\"67418d79a437380001deee28\",\"_lin
  08:08:42.957 [user] ts=2024-11-23T08:08:42.957730226Z caller=middlewares.go:46 method=Register username=BvoLLnU email=BvoLLnU@gmail.com took=2.451112ms
  08:08:47.195 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d8f3f77060008864eb4","customerId":"67418d7da437380001deee35","customer":{"id":null,"firstName":"kXWivMa","l
  08:08:50.633 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d923f77060008864eb6","customerId":"67418d7ba437380001deee2e","customer":{"id":null,"firstName":"LfcOjMwJvBP
  08:08:55.500 [front-end] Posting Customer: {"username":"PRHmPU","password":"KfycHPSO","email":"PRHmPU@gmail.com","firstName":"PRHmPU","lastName":"PRHmPU"}
  08:08:57.288 [user] ts=2024-11-23T08:08:57.288383452Z caller=middlewares.go:46 method=Register username=lLJuyio email=lLJuyio@gmail.com took=2.738287ms
  08:08:58.197 [front-end] Order response: {"id":"67418d9a3f77060008864ebf","customerId":"67418d86a437380001deee53","customer":{"id":null,"firstName":"JjHlhWXKjCs","lastName":"JjHlhWXKjCs
  08:09:02.389 [front-end] Received response: "{\"firstName\":\"KnJAZSvU\",\"lastName\":\"KnJAZSvU\",\"username\":\"KnJAZSvU\",\"id\":\"67418d87a437380001deee54\",\"_links\":{\"addresses\
  08:09:03.325 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d9f3f77060008864ec5","customerId":"67418d8fa437380001deee77","customer":{"id":null,"firstName":"GCXSEYDNrdh
  08:09:05.647 [front-end] Received response: "{\"firstName\":\"kewwaIUZ\",\"lastName\":\"kewwaIUZ\",\"username\":\"kewwaIUZ\",\"id\":\"67418d8ea437380001deee74\",\"_links\":{\"addresses\
  08:09:06.608 [front-end] Order response: {"id":"67418da23f77060008864ec9","customerId":"67418d90a437380001deee78","customer":{"id":null,"firstName":"QTaAWbwnlhlNvAn","lastName":"QTaAWbw
  08:09:08.560 [user] ts=2024-11-23T08:09:08.56035192Z caller=middlewares.go:46 method=Register username=YMqLahy email=YMqLahy@gmail.com took=2.967136ms
  08:09:12.756 [front-end] Order response: {"id":"67418da83f77060008864ecf","customerId":"67418d8da437380001deee6e","customer":{"id":null,"firstName":"HpBqOyp","lastName":"HpBqOyp","usern
  08:09:17.398 [front-end] Received response: "{\"firstName\":\"wAmDBPvwqRI\",\"lastName\":\"wAmDBPvwqRI\",\"username\":\"wAmDBPvwqRI\",\"id\":\"67418d9ba437380001deee98\",\"_links\":{\"a
  08:09:20.743 [front-end] Received response: "{\"firstName\":\"cBnZLtIqqDgTZ\",\"lastName\":\"cBnZLtIqqDgTZ\",\"username\":\"cBnZLtIqqDgTZ\",\"id\":\"67418d99a437380001deee95\",\"_links\
  08:09:22.756 [front-end] Received response: "{\"firstName\":\"OhaHddoInhscx\",\"lastName\":\"OhaHddoInhscx\",\"username\":\"OhaHddoInhscx\",\"id\":\"67418d9fa437380001deeea0\",\"_links\

## p0097
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service checkoutservice, 2024-11-18T05:05:51.642Z
```
{"service":"checkoutservice","operation":"hipstershop.CheckoutService/PlaceOrder","method":"PlaceOrder","status_code":13,"duration_us":24653,"trace_id":"bfc52b9eb6fef86dcd193fc701e0f189","message":"span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13"}
```
Same service, the 2 minutes before (oldest first):
  05:05:28.996 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="USD"  (×3)
  05:05:29.017 [checkoutservice] payment went through (transaction_id: e43c7587-0e24-4a72-8d85-16a465855b2a)  (×4)
  05:05:29.029 [checkoutservice] order confirmation email sent to "williamserin@example.org"
  05:05:33.940 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="CAD"  (×2)
  05:05:33.987 [checkoutservice] order confirmation email sent to "ferrelljeffrey@example.com"
  05:05:43.963 [checkoutservice] order confirmation email sent to "samuelraymond@example.com"
  05:05:46.056 [checkoutservice] order confirmation email sent to "fcontreras@example.com"
All services, 30 seconds either side (sampled):
  05:05:28.413 [frontend] request started  (×265)
  05:05:28.422 [cartservice] GetCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×218)
  05:05:28.449 [adservice] received ad request (context_words=[accessories])  (×17)
  05:05:28.458 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=1YMWWN1N4O, quantity=7  (×26)
  05:05:28.497 [shippingservice] [GetQuote] completed request  (×59)
  05:05:28.996 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="USD"  (×6)
  05:05:29.017 [checkoutservice] payment went through (transaction_id: e43c7587-0e24-4a72-8d85-16a465855b2a)  (×9)
  05:05:29.021 [cartservice] EmptyCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×9)
  05:05:29.030 [frontend] order placed  (×9)
  05:05:31.741 [adservice] received ad request (context_words=[decor, home])  (×11)
  05:05:32.748 [frontend] ENV_PLATFORM is: aws  (×39)
  05:05:33.869 [adservice] received ad request (context_words=[footwear])  (×17)
  05:05:33.972 [paymentservice] Transaction processed: visa ending 2652 Amount: CAD426.701933656
  05:05:38.673 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×4)
  05:05:46.056 [emailservice] A request to send order confirmation email to fcontreras@example.com has been received.
  05:05:51.661 [checkoutservice] span hipstershop.PaymentService/Charge failed with gRPC status 400
  05:05:51.663 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  05:05:52.043 [redis] 1:M 18 Nov 2024 05:05:52.043 * Background saving started by pid 47
  05:05:52.145 [redis] 1:M 18 Nov 2024 05:05:52.144 * Background saving terminated with success
  05:05:52.522 [paymentservice] Transaction processed: visa ending 2457 Amount: EUR565.165855819
  05:06:04.238 [emailservice] A request to send order confirmation email to michaelacosta@example.net has been received.
  05:06:07.915 [checkoutservice] order confirmation email sent to "cwilson@example.com"
  05:06:12.430 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="JPY"
  05:06:12.471 [emailservice] A request to send order confirmation email to leenathaniel@example.org has been received.

## p0838
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-08T12:49:49.503Z
```
{"timestamp":1733662189503512000,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-dnzbq","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-08 12:49:49.503  INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl  : route.getDistances().size : 4"}
```
Same service, the 2 minutes before (oldest first):
  12:49:47.921 [ts-basic-service] 2024-12-08 12:49:47.921 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4
  12:49:47.951 [ts-basic-service] 2024-12-08 12:49:47.950 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×5)
  12:49:47.964 [ts-basic-service] 2024-12-08 12:49:47.963 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan
  12:49:47.994 [ts-basic-service] 2024-12-08 12:49:47.993 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×4)
  12:49:49.456 [ts-basic-service] 2024-12-08 12:49:49.456 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  12:49:49.461 [ts-basic-service] 2024-12-08 12:49:49.461 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
  12:49:49.464 [ts-basic-service] 2024-12-08 12:49:49.464 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa
  12:49:49.472 [ts-basic-service] 2024-12-08 12:49:49.472 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  12:49:49.483 [ts-basic-service] 2024-12-08 12:49:49.483 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  12:49:49.484 [ts-basic-service] 2024-12-08 12:49:49.484 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693
  12:49:49.495 [ts-basic-service] 2024-12-08 12:49:49.495 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  12:49:49.503 [ts-basic-service] 2024-12-08 12:49:49.503 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai
  12:49:49.503 [ts-basic-service] 2024-12-08 12:49:49.503 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3
All services, 30 seconds either side (sampled):
  12:49:19.980 [ts-auth-service] 2024-12-08 12:49:19.979 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×12)
  12:49:20.323 [ts-basic-service] 2024-12-08 12:49:20.323 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×2)
  12:49:20.421 [ts-order-other-service] 2024-12-08 12:49:20.421 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:0  (×13)
  12:49:20.531 [ts-seat-service] 2024-12-08 12:49:20.530 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×55)
  12:49:21.144 [ts-basic-service] 2024-12-08 12:49:21.144 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×32)
  12:49:21.363 [ts-travel2-service] 2024-12-08 12:49:21.363 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×5)
  12:49:21.887 [ts-travel-service] 2024-12-08 12:49:21.886 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×20)
  12:49:22.051 [ts-seat-service] 2024-12-08 12:49:22.051 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×5)
  12:49:22.309 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:49:22 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 339 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×6)
  12:49:22.369 [ts-order-service] 2024-12-08 12:49:22.369 INFO 1 --- [io-12031-exec-2] order.controller.OrderController : [Order Other Service][Security Info Get] 4d2a46c7-71cb-4cf1-b5bb-b68406d  (×3)
  12:49:22.420 [ts-contacts-service] 2024-12-08 12:49:22.419 INFO 1 --- [io-12347-exec-6] contacts.service.ContactsServiceImpl : FIND CONTACTS BY ID: 47e015f5-6a9d-41ce-9b3a-e0978710fd71  (×3)
  12:49:22.810 [ts-preserve-service] 2024-12-08 12:49:22.809 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : TripResponse:TripResponse(tripId=D1345, startingStation=Shang Hai, t
  12:49:22.956 [ts-order-service] 2024-12-08 12:49:22.955 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at 
  12:49:22.987 [ts-preserve-service] 2024-12-08 12:49:22.986 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Cancel Order Service][Get Order By Id]
  12:49:26.026 [ts-food-service] 2024-12-08 12:49:26.026 INFO 1 --- [io-18856-exec-6] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×3)
  12:49:26.831 [ts-travel-service] 2024-12-08 12:49:26.830 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:00:00 GMT 2013  (×24)
  12:49:31.532 [ts-order-other-service] 2024-12-08 12:49:31.532 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=178781  (×17)
  12:49:37.354 [ts-travel2-service] 2024-12-08 12:49:37.353 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sun Dec 08 00:00:00 GMT 2024,   (×2)
  12:49:38.095 [ts-inside-payment-service] 2024-12-08 12:49:38.094 INFO 1 --- [io-18673-exec-1] i.service.InsidePaymentServiceImpl : Out pay result: Response(status=1, msg=Pay Success, data=null)  (×2)
  12:49:42.315 [ts-consign-service] 2024-12-08 12:49:42.315 INFO 1 --- [o-16111-exec-10] consign.service.ConsignServiceImpl : The target date is 2024-12-08 12:49:42
  12:49:56.209 [ts-preserve-other-service] 2024-12-08 12:49:56.209 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security Complete. 
  12:49:56.620 [ts-preserve-other-service] 2024-12-08 12:49:56.620 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order
  12:49:56.764 [ts-order-other-service] 2024-12-08 12:49:56.763 INFO 1 --- [io-12032-exec-5] other.service.OrderOtherServiceImpl : [Order Other Service][Order Create] Success.  (×2)
  12:50:00.165 [ts-seat-service] 2024-12-08 12:50:00.164 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  12:50:03.782 [ts-preserve-other-service] 2024-12-08 12:50:03.782 INFO 1 --- [o-14569-exec-10] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security Complete. 
  12:50:04.304 [ts-preserve-other-service] 2024-12-08 12:50:04.304 INFO 1 --- [o-14569-exec-10] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order] Order Travel Date: Sun Dec 08 00:00:00
  12:50:10.914 [ts-route-mongo] {"t":{"$date":"2024-12-08T12:50:10.914+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366221
  12:50:12.825 [ts-travel2-mongo] {"t":{"$date":"2024-12-08T12:50:12.824+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366221

## p0736
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-22T12:24:59.602Z
```
{"timestamp":1732278299602187300,"container_name":"adservice","pod_name":"adservice-b9bcc6cc9-275zk","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-22T12:24:59.601026789Z Thread-1 WARN Unable to register Log4j shutdown hook because JVM is shutting down. Using SimpleLogger"}
```
Same service, the 2 minutes before (oldest first):
  12:24:53.380 [adservice] received ad request (context_words=[accessories])  (×4)
  12:24:53.608 [adservice] received ad request (context_words=[decor, home])  (×4)
  12:24:54.252 [adservice] received ad request (context_words=[kitchen])  (×5)
  12:24:56.166 [adservice] received ad request (context_words=[hair, beauty])  (×2)
  12:24:56.569 [adservice] received ad request (context_words=[footwear])  (×2)
  12:24:57.110 [adservice] received ad request (context_words=[clothing, tops])  (×2)
  12:24:59.460 [adservice] *** shutting down gRPC ads server since JVM is shutting down
All services, 30 seconds either side (sampled):
  12:24:29.830 [frontend] request started  (×334)
  12:24:29.839 [cartservice] GetCartAsync called with userId=8dc610ea-4cce-470d-9dec-0cdabe7e0a9c  (×270)
  12:24:29.882 [adservice] received ad request (context_words=[])  (×8)
  12:24:30.676 [frontend] serving product page  (×156)
  12:24:30.850 [adservice] received ad request (context_words=[decor, home])  (×14)
  12:24:31.033 [shippingservice] [GetQuote] received request  (×82)
  12:24:31.870 [frontend] adding to cart  (×39)
  12:24:31.930 [checkoutservice] [PlaceOrder] user_id="622c169c-0d0a-41a5-9033-a384314a893d" user_currency="USD"  (×4)
  12:24:31.958 [checkoutservice] payment went through (transaction_id: 9a48f8c2-bee9-4eb1-b46f-7eeebf682903)  (×13)
  12:24:31.961 [cartservice] EmptyCartAsync called with userId=622c169c-0d0a-41a5-9033-a384314a893d  (×13)
  12:24:31.971 [frontend] order placed  (×13)
  12:24:34.181 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"417","nanos":374896060},"credit_card":{"credit_card_number":"42961323896023  (×3)
  12:24:34.194 [checkoutservice] order confirmation email sent to "michelle03@example.org"
  12:24:34.323 [paymentservice] Transaction processed: visa ending 7949 Amount: GBP196.875482521
  12:24:35.008 [adservice] received ad request (context_words=[clothing, tops])  (×7)
  12:24:40.004 [checkoutservice] [PlaceOrder] user_id="eaf79d1b-31f0-4e8e-91c1-cb7afff81318" user_currency="TRY"  (×2)
  12:24:40.036 [emailservice] A request to send order confirmation email to kimberly05@example.net has been received.
  12:24:43.928 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"159","nanos":133126939},"credit_card":{"credit_card_number":"41738073239607  (×3)
  12:24:43.942 [checkoutservice] order confirmation email sent to "brennanangela@example.net"
  12:24:44.720 [checkoutservice] order confirmation email sent to "gonzalezdavid@example.org"
  12:24:49.252 [emailservice] A request to send order confirmation email to charlesfernandez@example.org has been received.
  12:24:53.516 [checkoutservice] order confirmation email sent to "watersderrick@example.com"
  12:24:59.629 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 4  (×93)
  12:25:03.786 [adservice] AdService starting.  (×2)
  12:25:03.788 [adservice] Tracing enabled - Stackdriver exporter initialized.  (×2)
  12:25:05.388 [adservice] Exception in thread "main" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000 at io.grpc.netty.NettyServer.start(NettyServer.java:333) at io.g  (×2)
  12:25:28.925 [emailservice] A request to send order confirmation email to hendrixhannah@example.org has been received.
  12:25:29.540 [checkoutservice] order confirmation email sent to "kathleengood@example.com"

## p0232
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T07:55:52.408Z
```
{"timestamp":1731916552408549400,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-svrwm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4"}
```
Same service, the 2 minutes before (oldest first):
  07:55:49.045 [cartservice] GetCartAsync called with userId=adf41e5f-12f6-4c40-88a0-a1bcf421e416  (×15)
  07:55:49.062 [cartservice] EmptyCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121  (×3)
  07:55:50.542 [cartservice] AddItemAsync called with userId=c216dec4-2181-4773-8cc5-aa587ee59fcc, productId=OLJCESPC7Z, quantity=7  (×2)
All services, 30 seconds either side (sampled):
  07:55:23.151 [frontend] request started  (×337)
  07:55:23.159 [cartservice] GetCartAsync called with userId=fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a  (×273)
  07:55:23.186 [adservice] received ad request (context_words=[kitchen])  (×37)
  07:55:23.703 [frontend] setting currency  (×25)
  07:55:23.752 [adservice] received ad request (context_words=[])  (×39)
  07:55:25.530 [frontend] view user cart  (×74)
  07:55:26.031 [adservice] received ad request (context_words=[decor, home])  (×16)
  07:55:26.545 [cartservice] AddItemAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43, productId=66VCHSJNUP, quantity=2  (×38)
  07:55:26.948 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="CAD"  (×3)
  07:55:26.980 [checkoutservice] payment went through (transaction_id: c4b360de-0a54-41d1-a930-24293a2ee594)  (×14)
  07:55:26.984 [cartservice] EmptyCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×14)
  07:55:26.991 [checkoutservice] failed to send order confirmation to "gregoryjefferson@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:55:36.162 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"51234","nanos":207873389},"credit_card":{"credit_card_number":"474467310724  (×2)
  07:55:36.176 [checkoutservice] failed to send order confirmation to "eric14@example.org": rpc error: code = Internal desc = Failed to serialize response!
  07:55:40.563 [checkoutservice] failed to send order confirmation to "gilbertlindsay@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:55:42.576 [paymentservice] Transaction processed: visa ending 3321 Amount: USD918.860000000  (×3)
  07:55:49.007 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="GBP"  (×3)
  07:55:49.067 [emailservice] A request to send order confirmation email to william31@example.com has been received.
  07:55:50.628 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"6169","nanos":829368447},"credit_card":{"credit_card_number":"4969097768646  (×3)
  07:55:50.642 [checkoutservice] failed to send order confirmation to "oscarglenn@example.org": rpc error: code = Internal desc = Failed to serialize response!
  07:55:53.748 [emailservice] A request to send order confirmation email to jspencer@example.org has been received.
  07:56:06.481 [checkoutservice] failed to send order confirmation to "scottevans@example.org": rpc error: code = Internal desc = Failed to serialize response!
  07:56:07.373 [checkoutservice] failed to send order confirmation to "bryanjoshua@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:56:13.867 [emailservice] A request to send order confirmation email to nelsonronald@example.org has been received.
  07:56:17.583 [checkoutservice] failed to send order confirmation to "donna14@example.net": rpc error: code = Internal desc = Failed to serialize response!

## p0144
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:35:49.088Z
```
{"timestamp":1731908149088162800,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  05:35:48.608 [frontend] request started  (×7)
  05:35:48.608 [frontend] serving product page  (×4)
  05:35:48.645 [frontend] request complete  (×6)
  05:35:48.649 [frontend] adding to cart
  05:35:48.665 [frontend] view user cart  (×2)
All services, 30 seconds either side (sampled):
  05:35:19.094 [frontend] request started  (×304)
  05:35:19.096 [currencyservice] Getting supported currencies...  (×248)
  05:35:19.113 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '0PUK6V6EV0', '6E92ZMYYFZ', '66VCHSJNUP', '1YMWWN1N4O']  (×202)
  05:35:19.132 [adservice] received ad request (context_words=[hair, beauty])  (×15)
  05:35:19.415 [frontend] home  (×41)
  05:35:19.773 [adservice] received ad request (context_words=[kitchen])  (×58)
  05:35:20.110 [frontend] placing order  (×8)
  05:35:20.151 [paymentservice] Transaction processed: visa ending 7037 Amount: EUR554.789915977
  05:35:20.155 [shippingservice] [ShipOrder] completed request  (×8)
  05:35:20.166 [checkoutservice] order confirmation email sent to "jenniferedwards@example.com"
  05:35:23.759 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM']
  05:35:23.872 [paymentservice] Transaction processed: visa ending 0220 Amount: USD5161.560000000
  05:35:25.234 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', 'OLJCESPC7Z', '6E92ZMYYFZ', '2ZYFJ3GM2N']  (×3)
  05:35:25.456 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"71436","nanos":964175516},"credit_card":{"credit_card_number":"410890958600  (×3)
  05:35:25.472 [checkoutservice] order confirmation email sent to "isingleton@example.com"
  05:35:33.278 [emailservice] A request to send order confirmation email to farmerrobert@example.com has been received.
  05:35:35.747 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"291","nanos":560251221},"credit_card":{"credit_card_number":"44533064532990  (×3)
  05:35:35.761 [checkoutservice] order confirmation email sent to "gmorton@example.net"
  05:35:47.794 [emailservice] A request to send order confirmation email to amandajohnson@example.org has been received.
  05:35:52.271 [checkoutservice] order confirmation email sent to "leslieschroeder@example.net"
  05:35:58.060 [redis] 53:C 18 Nov 2024 05:35:58.059 * DB saved on disk
  05:36:11.139 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', 'OLJCESPC7Z', '0PUK6V6EV0']

## p0740
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service paymentservice, 2024-11-22T12:36:03.630Z
```
{"timestamp":1732278963630497300,"container_name":"paymentservice","pod_name":"paymentservice-856946df7c-l895d","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"PaymentService#Charge invoked with request {\"amount\":{\"currency_code\":\"JPY\",\"units\":\"13303\",\"nanos\":26979251},\"credit_card\":{\"credit_card_number\":\"4397603415967672\",\"credit_card_cvv\":503,\"credit_card_expiration_year\":2081,\"credit_card_expiration_month\":12}}"}
```
Same service, the 2 minutes before (oldest first):
  12:34:46.992 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"1450","nanos":334273327},"credit_card":{"credit_card_number":"4546545138669  (×3)
  12:34:46.992 [paymentservice] Transaction processed: visa ending 9897 Amount: CAD1450.334273327  (×3)
  12:34:48.681 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"1066","nanos":187696585},"credit_card":{"credit_card_number":"4950961445253
  12:34:48.681 [paymentservice] Transaction processed: visa ending 3649 Amount: GBP1066.187696585
  12:34:51.754 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"202","nanos":459088903},"credit_card":{"credit_card_number":"45399955765502  (×3)
  12:34:51.754 [paymentservice] Transaction processed: visa ending 0209 Amount: EUR202.459088903  (×3)
  12:35:12.587 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"2057","nanos":639150857},"credit_card":{"credit_card_number":"4750030908738  (×2)
  12:35:12.587 [paymentservice] Transaction processed: visa ending 8876 Amount: TRY2057.639150857  (×2)
  12:35:18.115 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"98086","nanos":623619039},"credit_card":{"credit_card_number":"460901154627
  12:35:18.115 [paymentservice] Transaction processed: visa ending 6886 Amount: JPY98086.623619039
All services, 30 seconds either side (sampled):
  12:35:33.642 [shippingservice] [GetQuote] received request  (×77)
  12:35:33.654 [frontend] request complete  (×329)
  12:35:34.036 [currencyservice] Getting supported currencies...  (×262)
  12:35:34.063 [frontend] failed to retrieve ads  (×186)
  12:35:36.232 [frontend] adding to cart  (×38)
  12:35:37.868 [frontend] setting currency  (×26)
  12:35:40.662 [frontend] placing order  (×14)
  12:35:40.685 [paymentservice] Transaction processed: visa ending 1532 Amount: TRY7361.775628515  (×5)
  12:35:40.690 [shippingservice] [ShipOrder] completed request  (×14)
  12:35:40.699 [checkoutservice] order confirmation email sent to "charles36@example.org"
  12:35:41.021 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"181","nanos":662980986},"credit_card":{"credit_card_number":"43767535040759
  12:35:41.036 [checkoutservice] order confirmation email sent to "virginiawest@example.com"
  12:36:03.630 [paymentservice] Transaction processed: visa ending 7672 Amount: JPY13303.26979251  (×3)
  12:36:07.041 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"18885","nanos":647059216},"credit_card":{"credit_card_number":"419735963530  (×2)
  12:36:07.389 [emailservice] A request to send order confirmation email to patriciaprice@example.net has been received.
  12:36:08.261 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"1423","nanos":630000000},"credit_card":{"credit_card_number":"4979931084525  (×2)
  12:36:08.275 [checkoutservice] order confirmation email sent to "melendezsavannah@example.org"
  12:36:10.426 [checkoutservice] [PlaceOrder] user_id="8dc610ea-4cce-470d-9dec-0cdabe7e0a9c" user_currency="CAD"
  12:36:10.468 [emailservice] A request to send order confirmation email to ihogan@example.net has been received.
  12:36:13.553 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"1244","nanos":667652360},"credit_card":{"credit_card_number":"4120694636457  (×2)
  12:36:13.565 [checkoutservice] order confirmation email sent to "kmiller@example.org"
  12:36:20.807 [emailservice] A request to send order confirmation email to duranrichard@example.net has been received.
  12:36:26.114 [checkoutservice] order confirmation email sent to "cristian60@example.com"
  12:36:32.136 [emailservice] A request to send order confirmation email to vstewart@example.org has been received.

## p0158
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:46:33.428Z
```
{"timestamp":1731908793428474600,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"serving product page"}
```
Same service, the 2 minutes before (oldest first):
  05:46:32.964 [frontend] request started  (×6)
  05:46:32.964 [frontend] serving product page  (×2)
  05:46:33.009 [frontend] request complete  (×5)
  05:46:33.012 [frontend] adding to cart  (×2)
  05:46:33.013 [frontend] span hipstershop.CartService/AddItem failed with gRPC status 9  (×2)
  05:46:33.019 [frontend] request error  (×2)
  05:46:33.362 [frontend] view user cart
All services, 30 seconds either side (sampled):
  05:46:03.428 [frontend] span hipstershop.CartService/AddItem failed with gRPC status 9  (×31)
  05:46:03.433 [cartservice] info: Grpc.AspNetCore.Server.ServerCallHandler[7] Error status code 'FailedPrecondition' with detail 'Can't access cart storage. System.OverflowException: Value  (×31)
  05:46:03.434 [frontend] request complete  (×283)
  05:46:03.643 [frontend] serving product page  (×155)
  05:46:03.651 [cartservice] GetCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×230)
  05:46:03.663 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '0PUK6V6EV0', 'L9ECAV7KIM', '6E92ZMYYFZ', 'OLJCESPC7Z']  (×202)
  05:46:03.695 [frontend] view user cart  (×40)
  05:46:03.717 [shippingservice] [GetQuote] completed request  (×46)
  05:46:04.024 [frontend] adding to cart  (×30)
  05:46:04.951 [frontend] home  (×28)
  05:46:05.001 [adservice] received ad request (context_words=[])  (×28)
  05:46:07.816 [adservice] received ad request (context_words=[footwear])  (×19)
  05:46:15.904 [adservice] received ad request (context_words=[hair, beauty])  (×21)
  05:46:20.601 [checkoutservice] [PlaceOrder] user_id="5e004f2d-a61a-45b2-840d-6bfd47a2be43" user_currency="JPY"
  05:46:20.616 [paymentservice] Transaction processed: visa ending 9737 Amount: JPY1005.162317560
  05:46:20.620 [shippingservice] [ShipOrder] received request  (×6)
  05:46:20.623 [cartservice] EmptyCartAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43  (×6)
  05:46:20.628 [checkoutservice] order confirmation email sent to "erica33@example.net"
  05:46:21.782 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="GBP"
  05:46:21.807 [paymentservice] Transaction processed: visa ending 1697 Amount: GBP612.421230426
  05:46:21.820 [checkoutservice] order confirmation email sent to "robertkirk@example.com"
  05:46:41.886 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"12","nanos":30138876},"credit_card":{"credit_card_number":"4413858399502891
  05:46:41.899 [emailservice] A request to send order confirmation email to bharris@example.net has been received.
  05:46:52.447 [checkoutservice] [PlaceOrder] user_id="0727db9d-83b9-44b7-acab-68a4f8f289c0" user_currency="TRY"
  05:46:52.461 [paymentservice] Transaction processed: visa ending 6083 Amount: TRY48.705044670
  05:46:52.477 [checkoutservice] order confirmation email sent to "john38@example.com"
  05:46:54.229 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"8","nanos":990000000},"credit_card":{"credit_card_number":"4335392688539484  (×2)
  05:46:54.243 [emailservice] A request to send order confirmation email to sheri34@example.org has been received.
  05:46:57.233 [emailservice] A request to send order confirmation email to stevengregory@example.com has been received.

## p0188
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T06:48:32.339Z
```
{"timestamp":1731912512339757800,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-svrwm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121"}
```
Same service, the 2 minutes before (oldest first):
  06:48:29.489 [cartservice] GetCartAsync called with userId=acc735c5-72d0-48e6-b237-46a63eac4c4d  (×15)
  06:48:29.789 [cartservice] AddItemAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add, productId=66VCHSJNUP, quantity=1  (×4)
  06:48:30.057 [cartservice] EmptyCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03
All services, 30 seconds either side (sampled):
  06:48:24.473 [frontend] request started  (×188)
  06:48:24.477 [currencyservice] Getting supported currencies...  (×157)
  06:48:24.488 [currencyservice] conversion request successful  (×395)
  06:48:24.504 [adservice] received ad request (context_words=[decor, home])  (×9)
  06:48:24.556 [adservice] received ad request (context_words=[accessories])  (×20)
  06:48:24.564 [cartservice] AddItemAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03, productId=OLJCESPC7Z, quantity=1  (×18)
  06:48:24.603 [shippingservice] [GetQuote] received request  (×45)
  06:48:25.170 [adservice] received ad request (context_words=[kitchen])  (×30)
  06:48:26.158 [frontend] setting currency  (×13)
  06:48:26.211 [frontend] ENV_PLATFORM is: aws  (×18)
  06:48:26.901 [adservice] received ad request (context_words=[clothing, tops])  (×7)
  06:48:27.795 [adservice] received ad request (context_words=[hair, beauty])  (×17)
  06:48:30.014 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="JPY"
  06:48:30.051 [paymentservice] Transaction processed: visa ending 4133 Amount: JPY147999.249890397
  06:48:30.054 [shippingservice] [ShipOrder] received request  (×2)
  06:48:30.057 [cartservice] EmptyCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03  (×2)
  06:48:30.063 [checkoutservice] order confirmation email sent to "mccoymelissa@example.net"
  06:48:32.337 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="GBP"
  06:48:32.374 [paymentservice] Transaction processed: visa ending 3003 Amount: GBP1238.66859775
  06:48:32.389 [checkoutservice] order confirmation email sent to "ericlewis@example.org"

## p0767
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-23T19:25:56.972Z
```
{"timestamp":1732389956972795600,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-x6bhs","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-23 19:25:56.972 ERROR 7 --- [ool-6-thread-32] w.weave.socks.queuemaster.DockerSpawner  : Exception trying to launch/remove worker container. javax.ws.rs.ProcessingException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock)"}
```
Same service, the 2 minutes before (oldest first):
  19:25:52.387 [queue-master] 2024-11-23 19:25:52.387 INFO 7 --- [ool-6-thread-30] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×7)
  19:25:52.387 [queue-master] 2024-11-23 19:25:52.387 INFO 7 --- [ool-6-thread-30] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×7)
  19:25:52.387 [queue-master] 2024-11-23 19:25:52.387 ERROR 7 --- [ool-6-thread-30] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×2)
  19:25:52.388 [queue-master] Received shipment task: 67422c2c48485600016b165d  (×2)
  19:25:52.388 [queue-master] 2024-11-23 19:25:52.388 INFO 7 --- [ool-6-thread-31] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×2)
All services, 30 seconds either side (sampled):
  19:25:27.012 [catalogue] ts=2024-11-23T19:25:27Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.218246ms  (×61)
  19:25:27.361 [front-end] POST /register 200 35.168 ms - 33  (×60)
  19:25:27.918 [orders] 2024-11-23 19:25:27.917 INFO [orders,3f2b75107e2b5ea7,83d1a148b7f30781,false] 7 --- [p-nio-80-exec-7] w.w.s.o.controllers.OrdersController : Sending payment req  (×31)
  19:25:27.931 [front-end] Order response: {"id":"67422c274ca85a00070c527c","customerId":"67422c1448485600016b161e","customer":{"id":null,"firstName":"LwRSbtCm","lastName":"LwRSbtCm","use
  19:25:28.191 [front-end] Attempting to add to cart: {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","quantity":1}  (×64)
  19:25:28.869 [front-end] Received response: "{\"firstName\":\"qCjDL\",\"lastName\":\"qCjDL\",\"username\":\"qCjDL\",\"id\":\"67422c1048485600016b1613\",\"_links\":{\"addresses\":{\"href
  19:25:29.621 [user] ts=2024-11-23T19:25:29.621387467Z caller=middlewares.go:46 method=Register username=Mktewd email=Mktewd@gmail.com took=5.391555ms
  19:25:30.728 [queue-master] 2024-11-23 19:25:30.727 INFO 7 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×25)
  19:25:30.932 [carts] 2024-11-23 19:25:30.932 INFO [carts,4b9bba27907a77c2,0c4565e9cc49ed00,false] 7 --- [-nio-80-exec-12] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×18)
  19:25:31.224 [front-end] Order response: {"id":"67422c2b4ca85a00070c5284","customerId":"67422c1b48485600016b1635","customer":{"id":null,"firstName":"jgzxrQZXHMO","lastName":"jgzxrQZXHMO
  19:25:33.826 [user] ts=2024-11-23T19:25:33.825885146Z caller=middlewares.go:46 method=Register username=bxfLwpr email=bxfLwpr@gmail.com took=5.075432ms
  19:25:37.009 [user] ts=2024-11-23T19:25:37.008974782Z caller=middlewares.go:46 method=Register username=tUoqE email=tUoqE@gmail.com took=4.907897ms
  19:25:39.968 [front-end] Received response: "{\"firstName\":\"rSLhEnzCgHZXSfy\",\"lastName\":\"rSLhEnzCgHZXSfy\",\"username\":\"rSLhEnzCgHZXSfy\",\"id\":\"67422c2148485600016b163f\",\"_
  19:25:42.007 [front-end] Order response: {"statusCode":201,"body":{"id":"67422c364ca85a00070c528c","customerId":"67422c2448485600016b1649","customer":{"id":null,"firstName":"XJhAhIdVwJ"
  19:25:44.231 [front-end] Received response: "{\"firstName\":\"hzOzdcBcvzCE\",\"lastName\":\"hzOzdcBcvzCE\",\"username\":\"hzOzdcBcvzCE\",\"id\":\"67422c2448485600016b164a\",\"_links\":{
  19:25:47.051 [front-end] Posting Customer: {"username":"twbouTyBIvlt","password":"RRusAIFcLw","email":"twbouTyBIvlt@gmail.com","firstName":"twbouTyBIvlt","lastName":"twbouTyBIvlt"}
  19:25:48.841 [front-end] Received response: "{\"firstName\":\"Mktewd\",\"lastName\":\"Mktewd\",\"username\":\"Mktewd\",\"id\":\"67422c2948485600016b1653\",\"_links\":{\"addresses\":{\"h
  19:25:50.009 [front-end] Posting Customer: {"username":"AnfITfpoSgHTzM","password":"VXDaK","email":"AnfITfpoSgHTzM@gmail.com","firstName":"AnfITfpoSgHTzM","lastName":"AnfITfpoSgHTzM"}
  19:25:52.391 [front-end] Order response: {"id":"67422c404ca85a00070c5295","customerId":"67422c2c48485600016b165c","customer":{"id":null,"firstName":"GJXnBwInYmiun","lastName":"GJXnBwInY
  19:25:56.973 [front-end] Order response: {"statusCode":201,"body":{"id":"67422c444ca85a00070c5297","customerId":"67422c3348485600016b167b","customer":{"id":null,"firstName":"sBqll","las
  19:26:00.267 [front-end] Received response: "{\"firstName\":\"tUoqE\",\"lastName\":\"tUoqE\",\"username\":\"tUoqE\",\"id\":\"67422c3148485600016b1672\",\"_links\":{\"addresses\":{\"href
  19:26:01.799 [front-end] Posting Customer: {"username":"PzDVrke","password":"bAfovNMfn","email":"PzDVrke@gmail.com","firstName":"PzDVrke","lastName":"PzDVrke"}
  19:26:07.524 [front-end] Received response: "{\"firstName\":\"HnphKTnKRHBLmxd\",\"lastName\":\"HnphKTnKRHBLmxd\",\"username\":\"HnphKTnKRHBLmxd\",\"id\":\"67422c3b48485600016b168b\",\"_
  19:26:10.152 [front-end] Received response: "{\"firstName\":\"RERtqeJ\",\"lastName\":\"RERtqeJ\",\"username\":\"RERtqeJ\",\"id\":\"67422c3848485600016b1681\",\"_links\":{\"addresses\":{
  19:26:13.724 [user] ts=2024-11-23T19:26:13.723921602Z caller=middlewares.go:46 method=Register username=eHhkk email=eHhkk@gmail.com took=5.480947ms
  19:26:14.853 [front-end] Received response: "{\"firstName\":\"VVHDXt\",\"lastName\":\"VVHDXt\",\"username\":\"VVHDXt\",\"id\":\"67422c3e48485600016b1692\",\"_links\":{\"addresses\":{\"h
  19:26:17.581 [front-end] Received response: "{\"firstName\":\"CQQAUaCilPTGBGO\",\"lastName\":\"CQQAUaCilPTGBGO\",\"username\":\"CQQAUaCilPTGBGO\",\"id\":\"67422c4248485600016b16a3\",\"_
  19:26:22.495 [user] ts=2024-11-23T19:26:22.495184128Z caller=middlewares.go:46 method=Register username=ZSxSSGOG email=ZSxSSGOG@gmail.com took=4.063925ms

## p0618
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-07T20:16:57.629Z
```
{"timestamp":1733602617629355300,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-67hjc","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 20:16:57.629  INFO 1 --- [       Thread-5] o.s.j.e.a.AnnotationMBeanExporter        : Unregistering JMX-exposed beans on shutdown"}
```
Same service, the 2 minutes before (oldest first):
  20:16:53.876 [ts-route-service] 2024-12-07 20:16:53.875 INFO 1 --- [io-11178-exec-8] route.controller.RouteController : Route id: f3d4d4ef-693b-4456-8eed-59c0d717dd08  (×13)
  20:16:57.146 [ts-route-service] 2024-12-07 20:16:57.146 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: d693a2c5-ef87-4a3c-bef8-600b43f62c68
  20:16:57.621 [ts-route-service] 2024-12-07 20:16:57.621 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  20:16:57.625 [ts-route-service] 2024-12-07 20:16:57.625 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  20:16:57.626 [ts-route-service] 2024-12-07 20:16:57.625 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  20:16:57.627 [ts-route-service] 2024-12-07 20:16:57.627 INFO 1 --- [ Thread-5] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-route-service:11178.errorChannel' has 0 subscriber(s).
  20:16:57.627 [ts-route-service] 2024-12-07 20:16:57.627 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : stopped _org.springframework.integration.errorLogger
  20:16:57.629 [ts-route-service] 2024-12-07 20:16:57.629 INFO 1 --- [ Thread-5] o.s.s.c.ThreadPoolTaskScheduler : Shutting down ExecutorService 'taskScheduler'
All services, 30 seconds either side (sampled):
  20:16:27.706 [ts-auth-service] 2024-12-07 20:16:27.706 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×12)
  20:16:27.967 [ts-auth-service] 2024-12-07 20:16:27.967 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×27)
  20:16:28.023 [ts-travel2-service] 2024-12-07 20:16:28.023 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×68)
  20:16:28.066 [ts-price-service] 2024-12-07 20:16:28.065 INFO 1 --- [io-16579-exec-5] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×4)
  20:16:28.085 [ts-order-other-service] 2024-12-07 20:16:28.085 INFO 1 --- [io-12032-exec-1] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×4)
  20:16:28.145 [ts-travel2-service] 2024-12-07 20:16:28.145 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×8)
  20:16:28.174 [ts-travel-service] 2024-12-07 20:16:28.173 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×49)
  20:16:28.209 [ts-travel-service] 2024-12-07 20:16:28.209 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×8)
  20:16:28.247 [ts-seat-service] 2024-12-07 20:16:28.247 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×4)
  20:16:28.324 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:28 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×8)
  20:16:30.117 [ts-basic-service] 2024-12-07 20:16:30.117 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×4)
  20:16:30.290 [ts-order-other-service] 2024-12-07 20:16:30.290 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×2)
  20:16:30.901 [ts-auth-mongo] {"t":{"$date":"2024-12-07T20:16:30.901+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360259
  20:16:31.291 [ts-order-other-service] 2024-12-07 20:16:31.291 INFO 1 --- [io-12032-exec-9] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 60
  20:16:31.556 [ts-consign-service] 2024-12-07 20:16:31.556 INFO 1 --- [io-16111-exec-1] consign.service.ConsignServiceImpl : The handle date is 2024-12-07  (×2)
  20:16:31.653 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:16:31.653+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360259
  20:16:31.816 [ts-travel2-service] 2024-12-07 20:16:31.816 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  20:16:32.958 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:32 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 5994 "-" "Mozilla/5.0 (Macintosh;  (×2)
  20:16:40.693 [ts-auth-service] 2024-12-07 20:16:40.693 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×2)
  20:16:42.649 [ts-basic-service] 2024-12-07 20:16:42.649 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  20:16:42.675 [ts-basic-service] 2024-12-07 20:16:42.675 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3
  20:16:46.989 [ts-order-service] 2024-12-07 20:16:46.988 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-4cf1-
  20:16:48.369 [ts-food-service] 2024-12-07 20:16:48.369 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:16:57.625 [ts-route-service] 2024-12-07 20:16:57.625 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  20:16:58.394 [ts-travel-service] 2024-12-07 20:16:58.394 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×2)
  20:17:02.705 [ts-admin-travel-service] 2024-12-07 20:17:02.705 ERROR 1 --- [io-16114-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×7)
  20:17:24.657 [ts-route-service] 2024-12-07 20:17:24.562 INFO 1 --- [ main] route.RouteApplication : Starting RouteApplication v1.0 on ts-route-service-6f78466fb7-9ll65 with PID 1 (/app/ts-rout

## p0085
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T15:16:22.575Z
```
{"service":"logservice1","message":"2021-08-13 15:16:22,575 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | 6fa38760be11d011 | the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389"}
```
Same service, the 2 minutes before (oldest first):
  15:16:18.144 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  15:16:18.145 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '5a1af2e4-fc06-11eb-af0c-0242ac110004', 'user_id': 'DoEuftsg'}  (×5)
  15:16:19.376 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  15:16:19.377 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×2)
  15:16:19.377 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '5ad9ed2a-fc06-11eb-a27d-0242ac110003'}  (×2)
  15:16:19.451 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×2)
  15:16:19.589 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×2)
  15:16:19.590 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×2)
All services, 30 seconds either side (sampled):
  15:15:52.596 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  15:15:52.835 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '4b4cc1fc-fc06-11eb-8653-0242ac110004', 'value': '', 'ex': 10}  (×38)
  15:15:53.100 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×40)
  15:15:53.274 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '4b4cc1fc-fc06-11eb-8653-0242ac110004'}  (×39)
  15:15:53.364 [logservice2] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': '4b4cc1fc-fc06-11eb-8653-0242ac110004', 'user_id': 'EVWjdQPL'}  (×75)
  15:15:53.596 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '4bc16304-fc06-11eb-8fcc-0242ac110003', 'value': '', 'ex': 10}  (×38)
  15:15:53.932 [mobservice1] INFO info 4bc16304-fc06-11eb-8fcc-0242ac110003:CqkgPMzS write success
  15:15:54.120 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×36)
  15:15:54.583 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '4c2c32c4-fc06-11eb-b232-0242ac110004', 'value': 'zShwUfFn'}  (×36)
  15:15:56.393 [mobservice1] INFO info 4d3eac8c-fc06-11eb-b2ea-0242ac110003:ulnvrqij write success
  15:15:58.180 [dbservice1] INFO 4ded1d44-fc06-11eb-bf69-0242ac110003-gwdEDvWp-lda>CXq^!9O3 token generate success token=MTYyODgzODk1OC4xNzk4NDk6NGRlZDFkNDQtZmMwNi0xMWViLWJmNjktMDI0MmFjMTE
  15:16:00.675 [mobservice2] INFO info 4fc0d66a-fc06-11eb-bec5-0242ac110004:GmfKwAOM write success
  15:16:02.733 [dbservice2] INFO 50d84c5e-fc06-11eb-b319-0242ac110003-LUmfKNIy-SHVeob!8dBT= token generate success token=MTYyODgzODk2Mi43MzI0NjI6NTBkODRjNWUtZmMwNi0xMWViLWIzMTktMDI0MmFjMTE
  15:16:04.456 [webservice2] ERROR an error occurred in the downstream service  (×5)
  15:16:07.291 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×2)
  15:16:10.346 [dbservice1] INFO 55246b1c-fc06-11eb-b839-0242ac110003-DomOhFAT-JOhx^<NsCKSd token generate success token=MTYyODgzODk3MC4zNDU1Nzg6NTUyNDZiMWMtZmMwNi0xMWViLWI4MzktMDI0MmFjMTE  (×2)
  15:16:13.796 [mobservice1] INFO info 5794a3bc-fc06-11eb-aec2-0242ac110003:qexisTfm write success
  15:16:15.941 [webservice1] ERROR an error occurred in the downstream service  (×5)
  15:16:18.023 [mobservice2] INFO info 5a1af2e4-fc06-11eb-af0c-0242ac110004:DoEuftsg write success
  15:16:20.804 [mobservice1] INFO info 5bc96760-fc06-11eb-aaeb-0242ac110004:cwbxRDST write success
  15:16:28.471 [dbservice2] INFO 602f7b64-fc06-11eb-8db9-0242ac110003-mAIhCgaZ-0qYDJS.})WI& token generate success token=MTYyODgzODk4OC40NzExMjI3OjYwMmY3YjY0LWZjMDYtMTFlYi04ZGI5LTAyNDJhYzE
  15:16:31.664 [dbservice2] INFO 61e81920-fc06-11eb-a486-0242ac110004-CPiYkQrA-O&mRE!hKAS{t token generate success token=MTYyODgzODk5MS42NjM2Mzg0OjYxZTgxOTIwLWZjMDYtMTFlYi1hNDg2LTAyNDJhYzE
  15:16:34.315 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  15:16:37.610 [dbservice1] INFO 6558aa0c-fc06-11eb-8fed-0242ac110003-wpiyObsr-WJ.&AIR!3rPn token generate success token=MTYyODgzODk5Ny42MTAwNDM6NjU1OGFhMGMtZmMwNi0xMWViLThmZWQtMDI0MmFjMTE
  15:16:40.415 [mobservice1] INFO info 677893e2-fc06-11eb-9c79-0242ac110004:GRzjnWha write success
  15:16:42.576 [dbservice2] INFO 688b86ae-fc06-11eb-b185-0242ac110003-sCbMprDF-1e*T8(m.o!u/ token generate success token=MTYyODgzOTAwMi41NzU5NzY4OjY4OGI4NmFlLWZjMDYtMTFlYi1iMTg1LTAyNDJhYzE
  15:16:46.711 [mobservice2] INFO info 6b33ebda-fc06-11eb-8cf7-0242ac110003:rwdmTblM write success
  15:16:50.027 [dbservice2] INFO 6cf718ac-fc06-11eb-9cd7-0242ac110003-wRjEsaDr-6yOCQJ=RzT1( token generate success token=MTYyODgzOTAxMC4wMjY3ODM6NmNmNzE4YWMtZmMwNi0xMWViLTljZDctMDI0MmFjMTE
  15:16:52.417 [mobservice1] INFO info 6ea118c4-fc06-11eb-8113-0242ac110003:EYeCRGvF write success

## p0809
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-08T09:16:24.280Z
```
{"timestamp":1733649384280679700,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h4k7r","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-08 09:16:24.280  INFO 1 --- [           main] o.s.i.endpoint.EventDrivenConsumer       : started _org.springframework.integration.errorLogger"}
```
Same service, the 2 minutes before (oldest first):
  09:16:18.391 [ts-auth-service] 2024-12-08 09:16:18.391 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  09:16:18.392 [ts-auth-service] 2024-12-08 09:16:18.392 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/auditevents || /auditevents.json],methods=[GET],produces=[applicati
  09:16:18.478 [ts-auth-service] 2024-12-08 09:16:18.478 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  09:16:18.479 [ts-auth-service] 2024-12-08 09:16:18.478 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  09:16:18.479 [ts-auth-service] 2024-12-08 09:16:18.479 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  09:16:18.480 [ts-auth-service] 2024-12-08 09:16:18.479 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  09:16:18.480 [ts-auth-service] 2024-12-08 09:16:18.480 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
  09:16:18.592 [ts-auth-service] 2024-12-08 09:16:18.592 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.boot.actuate.autoconfigure.Manageme
  09:16:19.590 [ts-auth-service] 2024-12-08 09:16:19.590 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.embedded.A
  09:16:19.996 [ts-auth-service] 2024-12-08 09:16:19.995 INFO 1 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in globalExceptionHandler
  09:16:21.053 [ts-auth-service] 2024-12-08 09:16:21.053 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 12340 (http)
  09:16:21.359 [ts-auth-service] 2024-12-08 09:16:21.358 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  09:16:21.359 [ts-auth-service] 2024-12-08 09:16:21.359 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43
  09:16:21.885 [ts-auth-service] 2024-12-08 09:16:21.885 INFO 1 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 'taskScheduler'
  09:16:22.457 [ts-auth-service] 2024-12-08 09:16:22.456 INFO 1 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  09:16:22.457 [ts-auth-service] 2024-12-08 09:16:22.456 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 19995 ms
  09:16:23.696 [ts-auth-service] 2024-12-08 09:16:23.695 INFO 1 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  09:16:23.882 [ts-auth-service] 2024-12-08 09:16:23.881 INFO 1 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  09:16:24.280 [ts-auth-service] 2024-12-08 09:16:24.280 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : Adding {logging-channel-adapter:_org.springframework.integration.errorLogger} as
  09:16:24.280 [ts-auth-service] 2024-12-08 09:16:24.280 INFO 1 --- [ main] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 1 subscriber(s).
All services, 30 seconds either side (sampled):
  09:15:54.593 [ts-auth-service] 2024-12-08 09:15:54.593 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def  (×2)
  09:15:57.091 [ts-auth-service] 2024-12-08 09:15:57.091 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact  (×2)
  09:15:57.362 [ts-basic-service] 2024-12-08 09:15:57.362 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×7)
  09:15:57.395 [ts-basic-service] 2024-12-08 09:15:57.395 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×35)
  09:15:57.459 [ts-seat-service] 2024-12-08 09:15:57.458 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×17)
  09:15:57.501 [ts-seat-service] 2024-12-08 09:15:57.500 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×17)
  09:15:57.602 [ts-travel2-service] 2024-12-08 09:15:57.602 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6  (×7)
  09:16:01.487 [ts-auth-service] 2024-12-08 09:16:01.487 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]  (×2)
  09:16:01.679 [ts-travel-service] 2024-12-08 09:16:01.679 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×2)
  09:16:01.737 [ts-basic-service] 2024-12-08 09:16:01.737 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×2)
  09:16:01.754 [ts-basic-service] 2024-12-08 09:16:01.754 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
  09:16:01.805 [ts-travel-service] 2024-12-08 09:16:01.805 INFO 1 --- [io-12346-exec-8] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×5)
  09:16:01.993 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:16:01 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 403 148 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)  (×3)
  09:16:04.787 [ts-auth-service] 2024-12-08 09:16:04.787 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]  (×2)
  09:16:09.507 [ts-order-mongo] {"t":{"$date":"2024-12-08T09:16:09.507+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364936
  09:16:10.201 [ts-travel-mongo] {"t":{"$date":"2024-12-08T09:16:10.200+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364937
  09:16:11.861 [ts-price-mongo] {"t":{"$date":"2024-12-08T09:16:11.861+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364937
  09:16:15.283 [ts-auth-service] 2024-12-08 09:16:15.283 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  09:16:16.289 [ts-auth-service] 2024-12-08 09:16:16.289 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.springframewo
  09:16:18.389 [ts-auth-service] 2024-12-08 09:16:18.389 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/vnd.spring-boot.
  09:16:18.480 [ts-auth-service] 2024-12-08 09:16:18.479 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  09:16:21.091 [ts-travel2-service] 2024-12-08 09:16:21.091 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  09:16:21.903 [ts-basic-service] 2024-12-08 09:16:21.903 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4
  09:16:22.165 [ts-food-service] 2024-12-08 09:16:22.165 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  09:16:24.588 [ts-auth-service] 2024-12-08 09:16:24.588 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 12340 (http)
  09:16:28.028 [ts-basic-service] 2024-12-08 09:16:28.028 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  09:16:33.094 [ts-auth-service] 2024-12-08 09:16:33.094 INFO 1 --- [io-12340-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  09:16:35.389 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:16:35 +0800] "POST /api/v1/users/login HTTP/1.1" 200 134 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×10)
  09:16:36.428 [ts-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  09:16:42.045 [ts-order-service] 2024-12-08 09:16:42.044 ERROR 1 --- [io-12031-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)

## p0120
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:17:45.450Z
```
{"timestamp":1731907065450477800,"container_name":"adservice","pod_name":"adservice-574c5fd7b4-tmkhn","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Caused by: java.net.BindException: Address in use\n\tat java.base/sun.nio.ch.Net.bind0(Native Method)\n\tat java.base/sun.nio.ch.Net.bind(Unknown Source)\n\tat java.base/sun.nio.ch.ServerSocketChannelImpl.netBind(Unknown Source)\n\tat java.base/sun.nio.ch.ServerSocketChannelImpl.bind(Unknown Source)\n\tat io.netty.channel.socket.nio.NioServerSocketChannel.doBind(NioServerSocketChannel.java:141)\n\tat io.netty…"}
```
Same service, the 2 minutes before (oldest first):
  05:17:36.872 [adservice] received ad request (context_words=[hair, beauty])  (×3)
  05:17:37.099 [adservice] received ad request (context_words=[footwear])
  05:17:37.384 [adservice] received ad request (context_words=[clothing, tops])  (×3)
  05:17:37.638 [adservice] received ad request (context_words=[accessories])
  05:17:38.742 [adservice] received ad request (context_words=[kitchen])  (×2)
  05:17:38.820 [adservice] received ad request (context_words=[])  (×2)
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:40.213 [adservice] *** server shut down
  05:17:43.747 [adservice] AdService starting.
  05:17:43.839 [adservice] Stats enabled, but temporarily unavailable
  05:17:43.840 [adservice] Tracing enabled but temporarily unavailable
  05:17:43.841 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.
  05:17:43.842 [adservice] Tracing enabled - Stackdriver exporter initialized.
  05:17:45.449 [adservice] Exception in thread "main" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000 at io.grpc.netty.NettyServer.start(NettyServer.java:333) at io.g
All services, 30 seconds either side (sampled):
  05:17:15.533 [frontend] request started  (×279)
  05:17:15.540 [cartservice] GetCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121  (×238)
  05:17:15.560 [shippingservice] [GetQuote] completed request  (×77)
  05:17:15.836 [frontend] setting currency  (×16)
  05:17:15.890 [adservice] received ad request (context_words=[])  (×11)
  05:17:16.603 [frontend] adding to cart  (×25)
  05:17:16.636 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '66VCHSJNUP']  (×4)
  05:17:16.693 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"1792","nanos":226454698},"credit_card":{"credit_card_number":"4639203387545  (×4)
  05:17:16.696 [shippingservice] [ShipOrder] received request  (×7)
  05:17:16.705 [emailservice] A request to send order confirmation email to abowman@example.com has been received.
  05:17:16.824 [emailservice] A request to send order confirmation email to barbara24@example.com has been received.
  05:17:17.631 [recommendationservice] [Recv ListRecommendations] product_ids=['9SIQT8TOJO', 'L9ECAV7KIM', '66VCHSJNUP', '0PUK6V6EV0']  (×4)
  05:17:24.088 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="CAD"  (×2)
  05:17:24.126 [emailservice] A request to send order confirmation email to adamholder@example.org has been received.
  05:17:25.127 [checkoutservice] order confirmation email sent to "coxchristine@example.net"
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:40.406 [frontend] failed to retrieve ads  (×87)
  05:17:43.840 [adservice] Tracing enabled but temporarily unavailable  (×2)
  05:17:45.449 [adservice] Exception in thread "main" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000 at io.grpc.netty.NettyServer.start(NettyServer.java:333) at io.g  (×2)
  05:17:55.144 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base
  05:17:55.262 [paymentservice] Transaction processed: visa ending 8741 Amount: EUR679.655019909
  05:18:02.298 [emailservice] A request to send order confirmation email to caseyhoward@example.com has been received.

## p0420
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T04:07:15.174Z
```
{"timestamp":1732248435174275300,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T04:07:15.174037678Z caller=middlewares.go:75 method=GetUsers id=67400359b0df5c00019b402f result=1 took=754.566µs"}
```
Same service, the 2 minutes before (oldest first):
  04:07:13.704 [user] ts=2024-11-22T04:07:13.703863677Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67400367b0df5c00019b4060 took=1.950917ms  (×2)
  04:07:13.717 [user] ts=2024-11-22T04:07:13.717468966Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67400367b0df5c00019b4060 took=1.848334ms  (×2)
  04:07:13.723 [user] ts=2024-11-22T04:07:13.723427381Z caller=middlewares.go:75 method=GetUsers id=6740035db0df5c00019b403a result=1 took=972.111µs  (×9)
  04:07:13.741 [user] ts=2024-11-22T04:07:13.74159094Z caller=middlewares.go:104 method=GetAddresses id=67400365b0df5c00019b4057 result=1 took=937.03µs
  04:07:13.741 [user] ts=2024-11-22T04:07:13.741794199Z caller=middlewares.go:134 method=GetCards id=67400365b0df5c00019b4058 result=1 took=755.144µs
  04:07:13.755 [user] ts=2024-11-22T04:07:13.755719555Z caller=middlewares.go:46 method=Register username=ZzqhQdjVkVkL email=ZzqhQdjVkVkL@gmail.com took=837.524µs
  04:07:14.396 [user] ts=2024-11-22T04:07:14.396543752Z caller=middlewares.go:104 method=GetAddresses id=67400366b0df5c00019b405b result=1 took=3.167089ms
  04:07:14.397 [user] ts=2024-11-22T04:07:14.397447806Z caller=middlewares.go:134 method=GetCards id=67400366b0df5c00019b405c result=1 took=3.501651ms
  04:07:15.093 [user] ts=2024-11-22T04:07:15.093294332Z caller=middlewares.go:157 method=Health result=2 took=805.355µs  (×2)
All services, 30 seconds either side (sampled):
  04:06:45.307 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6740034cb0df5c00019b3fff"}  (×69)
  04:06:45.411 [front-end] POST to carts: http://carts/carts/6740034cb0df5c00019b3fff/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}  (×37)
  04:06:46.187 [front-end] Sent cookies.  (×67)
  04:06:46.244 [user] ts=2024-11-22T04:06:46.243885541Z caller=middlewares.go:134 method=GetCards id=6740034bb0df5c00019b3ff9 result=1 took=645.57µs  (×49)
  04:06:46.266 [front-end] Order response: {"id":"67400356d94b9000069b4c14","customerId":"67400342b0df5c00019b3fde","customer":{"id":null,"firstName":"qVBRqYL","lastName":"qVBRqYL","usern
  04:06:46.604 [front-end] Posting Customer: {"username":"ibOpj","password":"UQGUVs","email":"ibOpj@gmail.com","firstName":"ibOpj","lastName":"ibOpj"}
  04:06:48.106 [front-end] Order response: {"id":"67400358d94b9000069b4c16","customerId":"67400343b0df5c00019b3fe3","customer":{"id":null,"firstName":"HncBHmzIEUrIF","lastName":"HncBHmzIE
  04:06:49.457 [front-end] Received response: "{\"firstName\":\"eAbkkZiUfZLSHXz\",\"lastName\":\"eAbkkZiUfZLSHXz\",\"username\":\"eAbkkZiUfZLSHXz\",\"id\":\"67400349b0df5c00019b3ff1\",\"_
  04:06:52.059 [front-end] Order response: {"id":"6740035cd94b9000069b4c1a","customerId":"67400346b0df5c00019b3feb","customer":{"id":null,"firstName":"VMacAfAb","lastName":"VMacAfAb","use
  04:06:53.382 [front-end] Order response: {"statusCode":201,"body":{"id":"6740035dd94b9000069b4c1d","customerId":"6740034ab0df5c00019b3ff4","customer":{"id":null,"firstName":"aWlbSrGvZfk
  04:06:54.362 [front-end] Posting Customer: {"username":"PQuUWJa","password":"oipmQc","email":"PQuUWJa@gmail.com","firstName":"PQuUWJa","lastName":"PQuUWJa"}
  04:07:00.528 [front-end] Posting Customer: {"username":"YdvJlnFQc","password":"SoXhhYeTi","email":"YdvJlnFQc@gmail.com","firstName":"YdvJlnFQc","lastName":"YdvJlnFQc"}
  04:07:03.598 [front-end] Order response: {"statusCode":201,"body":{"id":"67400367d94b9000069b4c22","customerId":"67400354b0df5c00019b4017","customer":{"id":null,"firstName":"kMZBCbCjSLq
  04:07:05.207 [front-end] Order response: {"id":"67400369d94b9000069b4c24","customerId":"67400358b0df5c00019b402d","customer":{"id":null,"firstName":"OWBcDQsyWzqD","lastName":"OWBcDQsyWz
  04:07:05.928 [front-end] Order response: {"id":"67400369d94b9000069b4c28","customerId":"6740034eb0df5c00019b4003","customer":{"id":null,"firstName":"uOdioCwjTxtYiSs","lastName":"uOdioCw
  04:07:08.520 [front-end] Order response: {"id":"6740036cd94b9000069b4c2a","customerId":"67400358b0df5c00019b4029","customer":{"id":null,"firstName":"FdvmzLhgGonpAi","lastName":"FdvmzLhg
  04:07:11.257 [front-end] Received response: "{\"firstName\":\"ipJkRGhgGPtHCik\",\"lastName\":\"ipJkRGhgGPtHCik\",\"username\":\"ipJkRGhgGPtHCik\",\"id\":\"6740035bb0df5c00019b4033\",\"_
  04:07:12.932 [front-end] Order response: {"statusCode":201,"body":{"id":"67400370d94b9000069b4c2f","customerId":"67400356b0df5c00019b4020","customer":{"id":null,"firstName":"ibOpj","las
  04:07:15.208 [front-end] Order response: {"id":"67400373d94b9000069b4c32","customerId":"67400359b0df5c00019b402f","customer":{"id":null,"firstName":"ZYGBInCuPELZ","lastName":"ZYGBInCuPE
  04:07:16.783 [user] ts=2024-11-22T04:07:16.783238295Z caller=middlewares.go:46 method=Register username=bobgk email=bobgk@gmail.com took=1.039975ms
  04:07:23.231 [front-end] Order response: {"statusCode":201,"body":{"id":"6740037bd94b9000069b4c35","customerId":"6740035eb0df5c00019b4042","customer":{"id":null,"firstName":"qyvYPUsfNeR
  04:07:26.325 [front-end] Order response: {"id":"6740037ed94b9000069b4c37","customerId":"6740036cb0df5c00019b4068","customer":{"id":null,"firstName":"LtqGwqrmaQMw","lastName":"LtqGwqrmaQ
  04:07:29.741 [carts-db] {"t":{"$date":"2024-11-22T04:07:29.741+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224844
  04:07:32.043 [front-end] Received response: "{\"firstName\":\"ZzqhQdjVkVkL\",\"lastName\":\"ZzqhQdjVkVkL\",\"username\":\"ZzqhQdjVkVkL\",\"id\":\"67400371b0df5c00019b407a\",\"_links\":{
  04:07:33.753 [front-end] Order response: {"id":"67400385d94b9000069b4c3b","customerId":"67400376b0df5c00019b4087","customer":{"id":null,"firstName":"XbsnEzYFDYfLUg","lastName":"XbsnEzYF
  04:07:35.300 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×4)
  04:07:37.937 [front-end] Received response: "{\"firstName\":\"nAjAbNBaYmZOK\",\"lastName\":\"nAjAbNBaYmZOK\",\"username\":\"nAjAbNBaYmZOK\",\"id\":\"6740036fb0df5c00019b4071\",\"_links\
  04:07:42.152 [user] ts=2024-11-22T04:07:42.152585341Z caller=middlewares.go:46 method=Register username=GDqspo email=GDqspo@gmail.com took=788.164µs

## p0279
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service payment, 2024-11-22T02:28:23.749Z
```
{"timestamp":1732242503749931500,"container_name":"payment","pod_name":"payment-78bf948dc4-kdg7s","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=805ns"}
```
Same service, the 2 minutes before (oldest first):
  02:28:04.843 [payment] ts=2024-11-22T02:28:04Z caller=logging.go:40 method=Health result=1 took=7.866µs  (×14)
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=1.213µs
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=673ns  (×4)
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×49)
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -  (×49)
  02:28:03.203 [front-end] [ undefined, undefined ]  (×48)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×4)
  02:28:07.445 [orders] 2024-11-22 02:28:07.445 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
  02:28:10.277 [front-end] Posting Customer: {"username":"opFqwUnVow","password":"habyXFSF","email":"opFqwUnVow@gmail.com","firstName":"opFqwUnVow","lastName":"opFqwUnVow"}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
  02:28:23.301 [front-end] Received response: "{\"firstName\":\"HFHBXn\",\"lastName\":\"HFHBXn\",\"username\":\"HFHBXn\",\"id\":\"673fec34b0df5c00019af967\",\"_links\":{\"addresses\":{\"h
  02:28:24.999 [rabbitmq] 
  02:28:25.743 [carts] 2024-11-22 02:28:25.743 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×14)
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39d0","customerId":"673fec31b0df5c00019af95b","customer":{"id":null,"firstName":"bCCZHBaYc","lastName":"bCCZHBaYc","u
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×60)
  02:28:37.548 [user] ts=2024-11-22T02:28:37.548591Z caller=middlewares.go:46 method=Register username=OeZpiPZUn email=OeZpiPZUn@gmail.com took=1.009704ms
  02:28:40.321 [front-end] Order response: {"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR","lastName":"nbZCdAQyR","u
  02:28:42.162 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732242522152,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×2)
  02:28:44.338 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec5cd94b9000069b39e2","customerId":"673fec3ab0df5c00019af974","customer":{"id":null,"firstName":"opFqwUnVow"
  02:28:45.405 [front-end] Posting Customer: {"username":"crSMtAKNWrXaJJx","password":"TlwWXSanSW","email":"crSMtAKNWrXaJJx@gmail.com","firstName":"crSMtAKNWrXaJJx","lastName":"crSMtAKNWr
  02:28:47.575 [front-end] Received response: "{\"firstName\":\"QGHrdp\",\"lastName\":\"QGHrdp\",\"username\":\"QGHrdp\",\"id\":\"673fec41b0df5c00019af98c\",\"_links\":{\"addresses\":{\"h
  02:28:50.618 [front-end] Received response: "{\"firstName\":\"XsZRA\",\"lastName\":\"XsZRA\",\"username\":\"XsZRA\",\"id\":\"673fec4ab0df5c00019af99b\",\"_links\":{\"addresses\":{\"href

## p0547
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T18:20:19.871Z
```
{"timestamp":1733595619871692500,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-kwkx6","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:20:19.871  INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller     : [Travel Service] Query TripResponse"}
```
Same service, the 2 minutes before (oldest first):
  18:20:17.635 [ts-travel2-service] 2024-12-07 18:20:17.635 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  18:20:17.689 [ts-travel2-service] 2024-12-07 18:20:17.689 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  18:20:17.703 [ts-travel2-service] 2024-12-07 18:20:17.703 INFO 1 --- [io-16346-exec-6] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×2)
  18:20:17.705 [ts-travel2-service] 2024-12-07 18:20:17.705 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×4)
  18:20:17.712 [ts-travel2-service] 2024-12-07 18:20:17.712 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×4)
  18:20:17.713 [ts-travel2-service] 2024-12-07 18:20:17.713 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  18:20:17.755 [ts-travel2-service] 2024-12-07 18:20:17.755 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  18:20:17.855 [ts-travel2-service] 2024-12-07 18:20:17.855 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6
  18:20:17.864 [ts-travel2-service] 2024-12-07 18:20:17.864 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×2)
All services, 30 seconds either side (sampled):
  18:19:50.296 [ts-travel-service] 2024-12-07 18:19:50.295 INFO 1 --- [io-12346-exec-8] travel.controller.TravelController : [Travel Service] Query TripResponse  (×4)
  18:19:50.373 [ts-basic-service] 2024-12-07 18:19:50.373 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×4)
  18:19:50.420 [ts-travel-service] 2024-12-07 18:19:50.420 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×7)
  18:19:50.520 [ts-order-service] 2024-12-07 18:19:50.520 INFO 1 --- [io-12031-exec-6] order.service.OrderServiceImpl : Left ticket info is empty  (×11)
  18:19:50.696 [ts-travel-service] 2024-12-07 18:19:50.696 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×18)
  18:19:51.057 [ts-travel-service] 2024-12-07 18:19:51.057 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×19)
  18:19:51.470 [ts-auth-service] 2024-12-07 18:19:51.470 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×22)
  18:19:55.302 [ts-auth-service] 2024-12-07 18:19:55.301 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×2)
  18:19:55.585 [ts-auth-service] 2024-12-07 18:19:55.584 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×11)
  18:19:56.088 [ts-basic-service] 2024-12-07 18:19:56.088 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×2)
  18:19:56.201 [ts-seat-service] 2024-12-07 18:19:56.201 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×19)
  18:19:56.383 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:19:56 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 343 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×12)
  18:19:59.680 [ts-order-service] 2024-12-07 18:19:59.680 INFO 1 --- [io-12031-exec-7] order.controller.OrderController : [Order Other Service][Modify Order Status] Order Id: eb0c0bd2-68cc-4846-
  18:20:01.331 [ts-seat-service] 2024-12-07 18:20:01.330 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×5)
  18:20:01.457 [ts-seat-service] 2024-12-07 18:20:01.457 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×13)
  18:20:04.017 [ts-travel-service] 2024-12-07 18:20:04.016 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×8)
  18:20:04.074 [ts-security-service] 2024-12-07 18:20:04.074 INFO 1 --- [io-11188-exec-4] security.controller.SecurityController : [Security Service][Check Security] Check Account Id: 4d2a46c7-71cb
  18:20:04.157 [ts-preserve-service] 2024-12-07 18:20:04.157 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security Complete
  18:20:04.176 [ts-preserve-service] 2024-12-07 18:20:04.175 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting...
  18:20:04.677 [ts-basic-service] 2024-12-07 18:20:04.676 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4
  18:20:04.777 [ts-preserve-service] 2024-12-07 18:20:04.776 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Creating....
  18:20:04.791 [ts-preserve-service] 2024-12-07 18:20:04.791 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service]
  18:20:09.079 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:20:09 +0800] "PUT /api/v1/consignservice/consigns HTTP/1.1" 200 399 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebK  (×2)
  18:20:18.585 [ts-order-other-service] 2024-12-07 18:20:18.584 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou  (×2)
  18:20:19.828 [ts-travel-service] 2024-12-07 18:20:19.828 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×3)
  18:20:20.134 [ts-travel2-service] 2024-12-07 18:20:20.133 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  18:20:29.739 [ts-food-mongo] {"t":{"$date":"2024-12-07T18:20:29.739+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359562
  18:20:30.525 [ts-security-mongo] {"t":{"$date":"2024-12-07T18:20:30.525+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359563
  18:20:42.152 [ts-train-mongo] {"t":{"$date":"2024-12-07T18:20:42.152+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359564

## p0471
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:13:30.260Z
```
{"timestamp":1732349610260637400,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"GET /catalogue 200 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  08:13:29.685 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67418ea1a437380001def1a0"}  (×2)
  08:13:29.696 [front-end] POST /cards 200 - ms - -  (×2)
  08:13:29.742 [front-end] Attempting to delete cart for user: 67418ea1a437380001def1a0  (×2)
  08:13:29.758 [front-end] User cart deleted with status: 202  (×2)
  08:13:29.761 [front-end] DELETE /cart 202 - ms - -  (×2)
  08:13:29.768 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}  (×2)
  08:13:29.778 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  08:13:29.778 [front-end] POST to carts: http://carts/carts/67418ea1a437380001def1a0/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}  (×2)
  08:13:29.788 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418ea3a437380001def1a7"}
  08:13:29.797 [front-end] POST /addresses 200 - ms - -
  08:13:29.810 [front-end] POST /cart 201 - ms - -  (×2)
  08:13:29.897 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca
All services, 30 seconds either side (sampled):
  08:13:00.315 [front-end] Posting Customer: {"username":"QULMUkvXYM","password":"WupsRm","email":"QULMUkvXYM@gmail.com","firstName":"QULMUkvXYM","lastName":"QULMUkvXYM"}
  08:13:00.562 [user] ts=2024-11-23T08:13:00.562798633Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418e86a437380001def157 took=4.927907ms  (×56)
  08:13:00.686 [carts] 2024-11-23 08:13:00.686 INFO [carts,e9af1e9431524a7a,dd71a0176d885c56,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.ItemsController : Did not find item.  (×24)
  08:13:02.121 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418  (×67)
  08:13:02.148 [queue-master] 2024-11-23 08:13:02.148 INFO 7 --- [ool-6-thread-48] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×135)
  08:13:02.758 [front-end] Received response: "{\"firstName\":\"mUpYCp\",\"lastName\":\"mUpYCp\",\"username\":\"mUpYCp\",\"id\":\"67418e72a437380001def117\",\"_links\":{\"addresses\":{\"h
  08:13:02.949 [queue-master] 2024-11-23 08:13:02.949 ERROR 7 --- [pool-6-thread-3] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×18)
  08:13:03.961 [front-end] GET /catalogue 200 - ms - -  (×61)
  08:13:06.462 [front-end] Posting Customer: {"username":"sdyfCivjgFgOvf","password":"nPnEJa","email":"sdyfCivjgFgOvf@gmail.com","firstName":"sdyfCivjgFgOvf","lastName":"sdyfCivjgFgOvf"}
  08:13:08.487 [front-end] Order response: {"id":"67418e943f77060008864fa1","customerId":"67418e7ba437380001def132","customer":{"id":null,"firstName":"RWuPBdLEPSNm","lastName":"RWuPBdLEPS
  08:13:09.595 [front-end] Order response: {"statusCode":201,"body":{"id":"67418e953f77060008864fa5","customerId":"67418e88a437380001def165","customer":{"id":null,"firstName":"qgNtEzD","l
  08:13:14.224 [front-end] Order response: {"statusCode":201,"body":{"id":"67418e9a3f77060008864fa7","customerId":"67418e85a437380001def156","customer":{"id":null,"firstName":"IisOAo","la
  08:13:16.276 [front-end] Posting Customer: {"username":"YJvDsmLfl","password":"UnhQdbb","email":"YJvDsmLfl@gmail.com","firstName":"YJvDsmLfl","lastName":"YJvDsmLfl"}
  08:13:19.460 [front-end] Order response: {"id":"67418e9f3f77060008864fac","customerId":"67418e90a437380001def17b","customer":{"id":null,"firstName":"jtywKwz","lastName":"jtywKwz","usern
  08:13:20.730 [front-end] Received response: "{\"firstName\":\"hvGfawGejHEWFy\",\"lastName\":\"hvGfawGejHEWFy\",\"username\":\"hvGfawGejHEWFy\",\"id\":\"67418e86a437380001def157\",\"_lin
  08:13:23.353 [front-end] Received response: "{\"firstName\":\"TGGjG\",\"lastName\":\"TGGjG\",\"username\":\"TGGjG\",\"id\":\"67418e8ca437380001def16e\",\"_links\":{\"addresses\":{\"href
  08:13:26.233 [user] ts=2024-11-23T08:13:26.233501808Z caller=middlewares.go:46 method=Register username=oEnpeJHxi email=oEnpeJHxi@gmail.com took=2.958936ms
  08:13:30.900 [front-end] Posting Customer: {"username":"BDztuJxFXlbrk","password":"necCCJ","email":"BDztuJxFXlbrk@gmail.com","firstName":"BDztuJxFXlbrk","lastName":"BDztuJxFXlbrk"}
  08:13:32.734 [front-end] Order response: {"statusCode":201,"body":{"id":"67418eac3f77060008864fb7","customerId":"67418e92a437380001def181","customer":{"id":null,"firstName":"sdyfCivjgFg
  08:13:36.619 [front-end] Posting Customer: {"username":"tqPzhLLdw","password":"ilwUP","email":"tqPzhLLdw@gmail.com","firstName":"tqPzhLLdw","lastName":"tqPzhLLdw"}
  08:13:38.895 [front-end] Order response: {"statusCode":201,"body":{"id":"67418eb23f77060008864fbb","customerId":"67418e98a437380001def18c","customer":{"id":null,"firstName":"HDiNt","las
  08:13:42.043 [front-end] Posting Customer: {"username":"NUsJUnpKiz","password":"CverkW","email":"NUsJUnpKiz@gmail.com","firstName":"NUsJUnpKiz","lastName":"NUsJUnpKiz"}
  08:13:44.960 [front-end] Posting Customer: {"username":"UTQyfvRpz","password":"daKke","email":"UTQyfvRpz@gmail.com","firstName":"UTQyfvRpz","lastName":"UTQyfvRpz"}
  08:13:46.445 [front-end] Received response: "{\"firstName\":\"loAsbLWw\",\"lastName\":\"loAsbLWw\",\"username\":\"loAsbLWw\",\"id\":\"67418ea9a437380001def1ba\",\"_links\":{\"addresses\
  08:13:48.072 [user] ts=2024-11-23T08:13:48.072838656Z caller=middlewares.go:46 method=Register username=aRdxJc email=aRdxJc@gmail.com took=2.151727ms
  08:13:50.906 [front-end] Received response: "{\"firstName\":\"cHcqNDvhuh\",\"lastName\":\"cHcqNDvhuh\",\"username\":\"cHcqNDvhuh\",\"id\":\"67418eaaa437380001def1c1\",\"_links\":{\"addr
  08:13:53.562 [front-end] Posting Customer: {"username":"RHkPKvGiLJQ","password":"cojdLGQX","email":"RHkPKvGiLJQ@gmail.com","firstName":"RHkPKvGiLJQ","lastName":"RHkPKvGiLJQ"}
  08:13:55.829 [front-end] Order response: {"statusCode":201,"body":{"id":"67418ec33f77060008864fd1","customerId":"67418eaba437380001def1c6","customer":{"id":null,"firstName":"oBkGmDLNcyx
  08:13:57.002 [front-end] Posting Customer: {"username":"BfLBPW","password":"tSRha","email":"BfLBPW@gmail.com","firstName":"BfLBPW","lastName":"BfLBPW"}

## p0302
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:20:07.755Z
```
{"timestamp":1732245607755788000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Card: {\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"userID\":\"673ff85fb0df5c00019b1e97\"}"}
```
Same service, the 2 minutes before (oldest first):
  03:20:06.942 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}  (×2)
  03:20:06.949 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  03:20:06.949 [front-end] POST to carts: http://carts/carts/673ff85cb0df5c00019b1e91/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  03:20:06.965 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245606963,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:20:06.965 [front-end] Order response: {"timestamp":1732245606963,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:20:06.967 [front-end] POST /orders 500 - ms - -
  03:20:07.006 [front-end] POST /cart 500 60.455 ms - 64  (×2)
  03:20:07.062 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff861b0df5c00019b1e9f"}  (×2)
  03:20:07.072 [front-end] POST /addresses 200 - ms - -  (×2)
  03:20:07.077 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff861b0df5c00019b1e9f"}
  03:20:07.085 [front-end] POST /cards 200 - ms - -
  03:20:07.133 [front-end] Attempting to delete cart for user: 673ff861b0df5c00019b1e9f
  03:20:07.173 [front-end] User cart deleted with status: 503
  03:20:07.175 [front-end] DELETE /cart 503 - ms - -
  03:20:07.186 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
  03:20:07.186 [front-end] POST to carts: http://carts/carts/673ff861b0df5c00019b1e9f/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×21)
  03:20:06.540 [user] ts=2024-11-22T03:20:06.540288162Z caller=middlewares.go:75 method=GetUsers id=673ff84eb0df5c00019b1e6c result=1 took=1.052177ms  (×43)
  03:20:06.550 [user] ts=2024-11-22T03:20:06.549939822Z caller=middlewares.go:104 method=GetAddresses id=673ff854b0df5c00019b1e7e result=1 took=839.732µs  (×22)
  03:20:06.590 [front-end] Order response: {"timestamp":1732245606587,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×38)
  03:20:06.660 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff861b0df5c00019b1e9e"}  (×35)
  03:20:06.772 [front-end] DELETE /cart 503 - ms - -  (×36)
  03:20:06.803 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×4)
  03:20:06.949 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×3)
  03:20:08.182 [front-end] GET /catalogue 200 - ms - -  (×31)
  03:20:08.474 [front-end] 673ff868b0df5c00019b1eb9  (×29)
  03:20:08.498 [front-end] Sent cookies.  (×29)
  03:20:09.093 [user] ts=2024-11-22T03:20:09.093546446Z caller=middlewares.go:157 method=Health result=2 took=1.105162ms
  03:20:09.192 [carts] 2024-11-22 03:20:09.192 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  03:20:09.944 [user] ts=2024-11-22T03:20:09.944714234Z caller=middlewares.go:46 method=Register username=TpbEqowkn email=TpbEqowkn@gmail.com took=1.003034ms
  03:20:11.559 [user] ts=2024-11-22T03:20:11.558844653Z caller=middlewares.go:46 method=Register username=xQhxkcD email=xQhxkcD@gmail.com took=1.123618ms
  03:20:12.464 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×4)
  03:20:14.697 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×4)
  03:20:16.381 [user] ts=2024-11-22T03:20:16.381484973Z caller=middlewares.go:46 method=Register username=zCHyJV email=zCHyJV@gmail.com took=895.452µs
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:20.321 [front-end] Received response: "{\"firstName\":\"hRqnN\",\"lastName\":\"hRqnN\",\"username\":\"hRqnN\",\"id\":\"673ff85bb0df5c00019b1e8d\",\"_links\":{\"addresses\":{\"href
  03:20:21.876 [front-end] Received response: "{\"firstName\":\"GSlyQdwsNkS\",\"lastName\":\"GSlyQdwsNkS\",\"username\":\"GSlyQdwsNkS\",\"id\":\"673ff862b0df5c00019b1ea1\",\"_links\":{\"a
  03:20:24.692 [carts] 2024-11-22 03:20:24.692 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  03:20:26.469 [front-end] Received response: "{\"firstName\":\"tbhaDXI\",\"lastName\":\"tbhaDXI\",\"username\":\"tbhaDXI\",\"id\":\"673ff865b0df5c00019b1ea5\",\"_links\":{\"addresses\":{
  03:20:28.426 [user] ts=2024-11-22T03:20:28.426008438Z caller=middlewares.go:46 method=Register username=MoGml email=MoGml@gmail.com took=1.054731ms
  03:20:30.252 [front-end] Posting Customer: {"username":"MKGIsEbVYi","password":"VhFAQhsXw","email":"MKGIsEbVYi@gmail.com","firstName":"MKGIsEbVYi","lastName":"MKGIsEbVYi"}
  03:20:32.204 [front-end] Posting Customer: {"username":"znIVGAMLgnSste","password":"zCqOHq","email":"znIVGAMLgnSste@gmail.com","firstName":"znIVGAMLgnSste","lastName":"znIVGAMLgnSste"}
  03:20:32.913 [front-end] Received response: "{\"firstName\":\"xQhxkcD\",\"lastName\":\"xQhxkcD\",\"username\":\"xQhxkcD\",\"id\":\"673ff86bb0df5c00019b1ec3\",\"_links\":{\"addresses\":{
  03:20:34.676 [front-end] Received response: "{\"firstName\":\"BBYdunXrngQk\",\"lastName\":\"BBYdunXrngQk\",\"username\":\"BBYdunXrngQk\",\"id\":\"673ff874b0df5c00019b1ee8\",\"_links\":{
  03:20:36.743 [front-end] Received response: "{\"firstName\":\"UzagwCTnbpaXVzA\",\"lastName\":\"UzagwCTnbpaXVzA\",\"username\":\"UzagwCTnbpaXVzA\",\"id\":\"673ff86fb0df5c00019b1ed4\",\"_
