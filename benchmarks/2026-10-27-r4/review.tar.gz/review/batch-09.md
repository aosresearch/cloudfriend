## p0354
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:30:40.141Z
```
{"timestamp":1732246240141755100,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"GET /catalogue 200 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  03:30:38.921 [front-end] POST /cart 201 - ms - -
  03:30:39.862 [front-end] Request received with body: {}
  03:30:39.869 [front-end] Received response: "{\"firstName\":\"WWZxbyCv\",\"lastName\":\"WWZxbyCv\",\"username\":\"WWZxbyCv\",\"id\":\"673ffac9b0df5c00019b25fb\",\"_links\":{\"addresses\
  03:30:39.869 [front-end] GET Request to: http://user/customers/673ffac9b0df5c00019b25fb/addresses  (×2)
  03:30:39.878 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffad3b0df5c00019b2619\",\"_links\":{\"
  03:30:39.878 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:30:39.878 [front-end] [ undefined, undefined ]
  03:30:39.878 [front-end] Posting Order: {"customer":"http://user/customers/673ffac9b0df5c00019b25fb","address":"http://user/addresses/673ffad3b0df5c00019b2618","card":"http://user/cards
  03:30:39.906 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffadfd94b9000069b4588","customerId":"673ffac9b0df5c00019b25fb","customer":{"id":null,"firstName":"WWZxbyCv","
  03:30:39.906 [front-end] Order response: {"id":"673ffadfd94b9000069b4588","customerId":"673ffac9b0df5c00019b25fb","customer":{"id":null,"firstName":"WWZxbyCv","lastName":"WWZxbyCv","use
  03:30:39.909 [front-end] POST /orders 201 - ms - -
  03:30:40.026 [front-end] Posting Customer: {"username":"PzhYBvrQwFKqfEF","password":"DgbGMOGWx","email":"PzhYBvrQwFKqfEF@gmail.com","firstName":"PzhYBvrQwFKqfEF","lastName":"PzhYBvrQwFK
  03:30:40.032 [front-end] { id: '673ffae0b0df5c00019b263a' }
  03:30:40.032 [front-end] 673ffae0b0df5c00019b263a
  03:30:40.032 [front-end] Merging carts for customer id: 673ffae0b0df5c00019b263a and session id: rrS1mEHOo4YitGXARYyweWtoOysIjwDD
  03:30:40.058 [front-end] Carts merged.
  03:30:40.058 [front-end] set cookie673ffae0b0df5c00019b263a
  03:30:40.058 [front-end] Sent cookies.
  03:30:40.060 [front-end] POST /register 200 31.855 ms - 33
All services, 30 seconds either side (sampled):
  03:30:10.151 [front-end] User cart deleted with status: 202  (×59)
  03:30:10.231 [front-end] GET Request to: http://user/customers/673ffaafb0df5c00019b25a3/addresses  (×124)
  03:30:10.264 [queue-master] 2024-11-22 03:30:10.264 INFO 6 --- [ool-6-thread-23] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×48)
  03:30:10.275 [carts] 2024-11-22 03:30:10.275 INFO [carts,e3766ea05c31f99a,769420093f9049fb,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.controllers.CartsController : Merge carts reques  (×28)
  03:30:10.667 [front-end] Attempting to delete cart for user: 673ffab9b0df5c00019b25c2  (×58)
  03:30:11.150 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffac3d94b9000069b456b","customerId":"673ffab0b0df5c00019b25a7","customer":{"id":null,"firstName":"yqNFrdpxwpS
  03:30:12.461 [catalogue] ts=2024-11-22T03:30:12Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.483777ms  (×61)
  03:30:13.830 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×12)
  03:30:14.908 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffac6d94b9000069b4571","customerId":"673ffab6b0df5c00019b25b7","customer":{"id":null,"firstName":"CbHxzavqmqq
  03:30:17.001 [front-end] Posting Customer: {"username":"RwMntR","password":"iweziEY","email":"RwMntR@gmail.com","firstName":"RwMntR","lastName":"RwMntR"}
  03:30:18.032 [front-end] Received response: "{\"firstName\":\"mqUStAUJzKTGUoV\",\"lastName\":\"mqUStAUJzKTGUoV\",\"username\":\"mqUStAUJzKTGUoV\",\"id\":\"673ffab5b0df5c00019b25b1\",\"_
  03:30:23.271 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffacfd94b9000069b4577","customerId":"673ffabbb0df5c00019b25c8","customer":{"id":null,"firstName":"SriqyrjCBEG
  03:30:24.721 [front-end] Received response: "{\"firstName\":\"oymBXDuQBxYSp\",\"lastName\":\"oymBXDuQBxYSp\",\"username\":\"oymBXDuQBxYSp\",\"id\":\"673ffac1b0df5c00019b25d9\",\"_links\
  03:30:26.225 [front-end] Posting Customer: {"username":"naXRwawEqXUVRw","password":"bMQcjG","email":"naXRwawEqXUVRw@gmail.com","firstName":"naXRwawEqXUVRw","lastName":"naXRwawEqXUVRw"}
  03:30:28.815 [front-end] Posting Customer: {"username":"RIPqgEcW","password":"IRBlnnbvqq","email":"RIPqgEcW@gmail.com","firstName":"RIPqgEcW","lastName":"RIPqgEcW"}
  03:30:30.736 [front-end] Posting Customer: {"username":"vnHIAcbxhIz","password":"MHMweDjztB","email":"vnHIAcbxhIz@gmail.com","firstName":"vnHIAcbxhIz","lastName":"vnHIAcbxhIz"}
  03:30:33.462 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×3)
  03:30:37.172 [queue-master] 2024-11-22 03:30:37.172 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×27)
  03:30:40.026 [front-end] Posting Customer: {"username":"PzhYBvrQwFKqfEF","password":"DgbGMOGWx","email":"PzhYBvrQwFKqfEF@gmail.com","firstName":"PzhYBvrQwFKqfEF","lastName":"PzhYBvrQwFK
  03:30:40.642 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffae0d94b9000069b458a","customerId":"673ffaceb0df5c00019b2608","customer":{"id":null,"firstName":"CmcknC","la
  03:30:43.495 [front-end] Order response: {"id":"673ffae3d94b9000069b458b","customerId":"673ffad2b0df5c00019b2611","customer":{"id":null,"firstName":"naXRwawEqXUVRw","lastName":"naXRwawE
  03:30:45.947 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffae5d94b9000069b458e","customerId":"673ffad5b0df5c00019b261e","customer":{"id":null,"firstName":"mvOqvyFgp",
  03:30:47.703 [front-end] Posting Customer: {"username":"YzcHyDoIrKP","password":"CONLsahB","email":"YzcHyDoIrKP@gmail.com","firstName":"YzcHyDoIrKP","lastName":"YzcHyDoIrKP"}
  03:30:51.146 [front-end] Order response: {"id":"673ffaebd94b9000069b4594","customerId":"673ffad4b0df5c00019b261d","customer":{"id":null,"firstName":"RIPqgEcW","lastName":"RIPqgEcW","use
  03:30:57.791 [user] ts=2024-11-22T03:30:57.791185531Z caller=middlewares.go:46 method=Register username=IlkSNTSkO email=IlkSNTSkO@gmail.com took=1.102669ms
  03:31:00.502 [front-end] Posting Customer: {"username":"XeKMPiTTOKbdOIU","password":"JnnFH","email":"XeKMPiTTOKbdOIU@gmail.com","firstName":"XeKMPiTTOKbdOIU","lastName":"XeKMPiTTOKbdOIU
  03:31:02.263 [front-end] Order response: {"id":"673ffaf6d94b9000069b459b","customerId":"673ffae0b0df5c00019b263a","customer":{"id":null,"firstName":"PzhYBvrQwFKqfEF","lastName":"PzhYBvr
  03:31:04.492 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffaf8d94b9000069b459f","customerId":"673ffae2b0df5c00019b263e","customer":{"id":null,"firstName":"cpFgxucXe",
  03:31:07.032 [user] ts=2024-11-22T03:31:07.032614349Z caller=middlewares.go:46 method=Register username=sLcoeMTd email=sLcoeMTd@gmail.com took=1.058669ms

## p0090
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-13T20:37:33.503Z
```
{"service":"mobservice2","message":"2021-08-13 20:37:33,503 | INFO | 0.0.0.4 | 172.17.0.2 | mobservice2 | 76e954d1f02c6c2f | info 3b2078fa-fc33-11eb-80b4-0242ac110004:ulnvrqij write success"}
```
Same service, the 2 minutes before (oldest first):
  20:37:28.233 [mobservice2] INFO info 380c1b42-fc33-11eb-ba93-0242ac110003:rPLoqHhe write success
  20:37:28.779 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  20:37:28.780 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  20:37:28.780 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '3865d3e4-fc33-11eb-a811-0242ac110003'}  (×4)
  20:37:28.836 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '3865d3e4-fc33-11eb-a811-0242ac110003', 'value': 'zBtAqOdX'}  (×4)
  20:37:28.908 [mobservice2] INFO info 3865d3e4-fc33-11eb-a811-0242ac110003:zBtAqOdX write success
  20:37:29.756 [mobservice2] INFO info 38f296a8-fc33-11eb-9d31-0242ac110004:nulqIiBE write success
  20:37:31.099 [mobservice2] INFO info 39c3f428-fc33-11eb-8d3f-0242ac110003:cTCBbWEI write success
All services, 30 seconds either side (sampled):
  20:37:03.544 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  20:37:03.870 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  20:37:04.014 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '298992c0-fc33-11eb-a5b7-0242ac110003'}  (×44)
  20:37:04.144 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  20:37:04.393 [webservice2] INFO uuid: 2a038922-fc33-11eb-870c-0242ac110004 write redis successfully  (×45)
  20:37:04.711 [mobservice2] INFO info 2a038922-fc33-11eb-870c-0242ac110004:zfawCciR write success
  20:37:04.874 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×49)
  20:37:05.581 [mobservice2] INFO info 2a84e0c6-fc33-11eb-96ec-0242ac110003:ZadRMLrA write success
  20:37:08.194 [mobservice2] INFO info 2c1268fa-fc33-11eb-b291-0242ac110004:WvNJCdPU write success  (×2)
  20:37:10.910 [mobservice1] INFO info 2db47d9c-fc33-11eb-9c4f-0242ac110003:JkvHOUxm write success
  20:37:13.249 [mobservice1] INFO info 2f1d5668-fc33-11eb-8104-0242ac110004:ropVRsqh write success
  20:37:15.873 [mobservice2] INFO info 30a81dc4-fc33-11eb-a110-0242ac110004:kmPegpXw write success
  20:37:18.369 [mobservice2] INFO info 322830c6-fc33-11eb-b97b-0242ac110003:JUvKDVWZ write success
  20:37:21.001 [mobservice1] INFO info 33b95adc-fc33-11eb-bfce-0242ac110004:sUWAVXFt write success
  20:37:23.609 [mobservice1] INFO info 35444466-fc33-11eb-9bbc-0242ac110004:DLQYKJTg write success
  20:37:26.331 [mobservice2] INFO info 36d902c6-fc33-11eb-9a04-0242ac110003:yZPEbHDA write success
  20:37:29.756 [mobservice2] INFO info 38f296a8-fc33-11eb-9d31-0242ac110004:nulqIiBE write success
  20:37:31.887 [dbservice1] INFO 3a01640c-fc33-11eb-b6a4-0242ac110003-GRzjnWha-YXV0E=(>a1MP token generate success token=MTYyODg1ODI1MS44ODcwODozYTAxNjQwYy1mYzMzLTExZWItYjZhNC0wMjQyYWMxMTA
  20:37:34.741 [webservice1] ERROR an error occurred in the downstream service  (×6)
  20:37:37.161 [dbservice1] INFO 3d22aeb6-fc33-11eb-90b6-0242ac110003-WILFvAUY-@gqs5xJrY<v) token generate success token=MTYyODg1ODI1Ny4xNjEzNTY0OjNkMjJhZWI2LWZjMzMtMTFlYi05MGI2LTAyNDJhYzE
  20:37:39.973 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  20:37:42.551 [dbservice1] INFO 40610b5e-fc33-11eb-aaac-0242ac110004-RcoJYnsh-sPdxZat-)M%I token generate success token=MTYyODg1ODI2Mi41NTA2ODg6NDA2MTBiNWUtZmMzMy0xMWViLWFhYWMtMDI0MmFjMTE
  20:37:45.141 [mobservice2] INFO info 4221d6ee-fc33-11eb-9204-0242ac110004:dUFBYtEJ write success
  20:37:47.739 [mobservice1] INFO info 43adfc4a-fc33-11eb-b803-0242ac110003:lAkaXYfP write success
  20:37:50.080 [mobservice2] INFO info 4510f830-fc33-11eb-9f9a-0242ac110003:NZDQOdvq write success
  20:37:52.460 [mobservice2] INFO info 467ba5d0-fc33-11eb-9334-0242ac110004:fegJlQaO write success
  20:37:54.950 [mobservice1] INFO info 47fbe5b4-fc33-11eb-9309-0242ac110004:jnAxEKot write success
  20:37:58.198 [mobservice1] INFO info 49e9dcf0-fc33-11eb-9577-0242ac110004:hVyjbRgD write success
  20:38:00.603 [mobservice2] INFO info 4b5a45d4-fc33-11eb-8804-0242ac110003:vEGoarin write success
  20:38:03.318 [mobservice2] INFO info 4cf39990-fc33-11eb-a8f2-0242ac110004:GBzXyJft write success

## p0318
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:20:49.169Z
```
{"timestamp":1732245649169215200,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Attempting to delete cart for user: 673ff887b0df5c00019b1f13"}
```
Same service, the 2 minutes before (oldest first):
  03:20:48.920 [front-end] Posting Customer: {"username":"DnjBelnPao","password":"eQMYAKREBx","email":"DnjBelnPao@gmail.com","firstName":"DnjBelnPao","lastName":"DnjBelnPao"}
  03:20:48.926 [front-end] { id: '673ff890b0df5c00019b1f29' }  (×2)
  03:20:48.926 [front-end] 673ff890b0df5c00019b1f29  (×2)
  03:20:48.926 [front-end] Merging carts for customer id: 673ff890b0df5c00019b1f29 and session id: jnISKiTRaFwdCJHUn8WYbMXUHWIOX3JL  (×2)
  03:20:48.965 [front-end] Carts merged.  (×2)
  03:20:48.965 [front-end] set cookie673ff890b0df5c00019b1f29  (×2)
  03:20:48.965 [front-end] Sent cookies.  (×2)
  03:20:48.969 [front-end] POST /register 200 45.090 ms - 33  (×2)
  03:20:48.998 [front-end] Posting Customer: {"username":"asYAoymkBkzj","password":"aSSKLjGTT","email":"asYAoymkBkzj@gmail.com","firstName":"asYAoymkBkzj","lastName":"asYAoymkBkzj"}
  03:20:49.097 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff887b0df5c00019b1f13"}
  03:20:49.105 [front-end] POST /addresses 200 - ms - -
  03:20:49.110 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff887b0df5c00019b1f13"}
  03:20:49.119 [front-end] POST /cards 200 - ms - -
All services, 30 seconds either side (sampled):
  03:20:19.352 [catalogue] ts=2024-11-22T03:20:19Z caller=logging.go:85 method=Health result=2 took=26.87µs  (×40)
  03:20:19.663 [catalogue] ts=2024-11-22T03:20:19Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.69412m  (×9)
  03:20:19.810 [front-end] Carts merged.  (×61)
  03:20:20.329 [front-end] [ undefined, undefined ]  (×59)
  03:20:20.454 [catalogue] ts=2024-11-22T03:20:20Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.690358ms  (×54)
  03:20:21.876 [front-end] Received response: "{\"firstName\":\"GSlyQdwsNkS\",\"lastName\":\"GSlyQdwsNkS\",\"username\":\"GSlyQdwsNkS\",\"id\":\"673ff862b0df5c00019b1ea1\",\"_links\":{\"a
  03:20:25.544 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×7)
  03:20:29.280 [front-end] Received response: "{\"firstName\":\"iyaZwEHsMf\",\"lastName\":\"iyaZwEHsMf\",\"username\":\"iyaZwEHsMf\",\"id\":\"673ff861b0df5c00019b1ea0\",\"_links\":{\"addr
  03:20:32.700 [front-end] Posting Customer: {"username":"qXbvoaUIXMc","password":"THyvHwYrL","email":"qXbvoaUIXMc@gmail.com","firstName":"qXbvoaUIXMc","lastName":"qXbvoaUIXMc"}
  03:20:36.109 [front-end] Posting Customer: {"username":"HWsmCvxoMrNqX","password":"MJvuU","email":"HWsmCvxoMrNqX@gmail.com","firstName":"HWsmCvxoMrNqX","lastName":"HWsmCvxoMrNqX"}
  03:20:39.075 [front-end] Posting Customer: {"username":"ELXzX","password":"iajeZG","email":"ELXzX@gmail.com","firstName":"ELXzX","lastName":"ELXzX"}
  03:20:43.387 [carts] 2024-11-22 03:20:43.386 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[DE
  03:20:46.654 [front-end] Received response: "{\"firstName\":\"iLqTiAFoVbIq\",\"lastName\":\"iLqTiAFoVbIq\",\"username\":\"iLqTiAFoVbIq\",\"id\":\"673ff877b0df5c00019b1eec\",\"_links\":{
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/browser/**] onto handler of type [class org.sp
  03:20:52.462 [front-end] Posting Customer: {"username":"MGpVgwryvJC","password":"EXSsAw","email":"MGpVgwryvJC@gmail.com","firstName":"MGpVgwryvJC","lastName":"MGpVgwryvJC"}
  03:20:56.307 [front-end] Posting Customer: {"username":"TxflHMpaWteY","password":"HuykDEusv","email":"TxflHMpaWteY@gmail.com","firstName":"TxflHMpaWteY","lastName":"TxflHMpaWteY"}
  03:20:59.685 [carts] 2024-11-22 03:20:59.684 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[application/hal+json || 
  03:20:59.690 [carts] 2024-11-22 03:20:59.690 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/hal+  (×2)
  03:20:59.789 [carts] 2024-11-22 03:20:59.789 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces=
  03:21:01.182 [front-end] Posting Customer: {"username":"EFvIPXnJWRPmy","password":"UDHAmT","email":"EFvIPXnJWRPmy@gmail.com","firstName":"EFvIPXnJWRPmy","lastName":"EFvIPXnJWRPmy"}
  03:21:03.086 [carts] 2024-11-22 03:21:03.085 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applicatio
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  03:21:06.274 [front-end] Received response: "{\"firstName\":\"WwpBLC\",\"lastName\":\"WwpBLC\",\"username\":\"WwpBLC\",\"id\":\"673ff885b0df5c00019b1f10\",\"_links\":{\"addresses\":{\"h
  03:21:08.990 [carts] 2024-11-22 03:21:08.990 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX server
  03:21:11.486 [front-end] Posting Customer: {"username":"onbFNMM","password":"YJlvj","email":"onbFNMM@gmail.com","firstName":"onbFNMM","lastName":"onbFNMM"}
  03:21:13.304 [front-end] Received response: "{\"firstName\":\"XYDErsNhuY\",\"lastName\":\"XYDErsNhuY\",\"username\":\"XYDErsNhuY\",\"id\":\"673ff88fb0df5c00019b1f26\",\"_links\":{\"addr
  03:21:15.774 [front-end] Posting Customer: {"username":"eSafJJOuc","password":"LrXrl","email":"eSafJJOuc@gmail.com","firstName":"eSafJJOuc","lastName":"eSafJJOuc"}
  03:21:17.489 [front-end] Received response: "{\"firstName\":\"kJMPYF\",\"lastName\":\"kJMPYF\",\"username\":\"kJMPYF\",\"id\":\"673ff896b0df5c00019b1f37\",\"_links\":{\"addresses\":{\"h
  03:21:18.602 [orders] 2024-11-22 03:21:18.602 INFO [orders,145906930ffa3fb8,359c2f868402564c,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×2)
  03:21:18.708 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8aed94b9000069b438d","customerId":"673ff891b0df5c00019b1f2a","customer":{"id":null,"firstName":"asYAoymkBkz

## p0214
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service recommendationservice, 2024-11-18T07:41:35.189Z
```
{"timestamp":1731915695189788400,"container_name":"recommendationservice","pod_name":"recommendationservice-fdf57f545-q8t5v","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"[Recv ListRecommendations] product_ids=['9SIQT8TOJO', '0PUK6V6EV0', '2ZYFJ3GM2N', '66VCHSJNUP', '1YMWWN1N4O']"}
```
Same service, the 2 minutes before (oldest first):
  07:41:30.052 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', '6E92ZMYYFZ', '66VCHSJNUP', 'OLJCESPC7Z', 'LS4PSXUNUM']  (×19)
  07:41:34.246 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', '0PUK6V6EV0', '2ZYFJ3GM2N', '9SIQT8TOJO']
All services, 30 seconds either side (sampled):
  07:41:05.196 [adservice] received ad request (context_words=[clothing, tops])  (×13)
  07:41:05.387 [frontend] setting currency  (×21)
  07:41:05.397 [cartservice] GetCartAsync called with userId=33421b66-55b6-413b-9ba9-3230c85c58dc  (×242)
  07:41:05.435 [adservice] received ad request (context_words=[])  (×31)
  07:41:05.467 [adservice] received ad request (context_words=[kitchen])  (×51)
  07:41:05.734 [shippingservice] [GetQuote] completed request  (×67)
  07:41:07.040 [cartservice] AddItemAsync called with userId=736a09b5-665e-4823-8520-b8602b0bdbff, productId=0PUK6V6EV0, quantity=9  (×27)
  07:41:07.105 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"974","nanos":642662557},"credit_card":{"credit_card_number":"47417661145692  (×3)
  07:41:07.109 [shippingservice] [ShipOrder] received request  (×10)
  07:41:07.119 [emailservice] A request to send order confirmation email to keithherrera@example.com has been received.
  07:41:08.047 [adservice] received ad request (context_words=[accessories])  (×30)
  07:41:09.408 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"894","nanos":980776648},"credit_card":{"credit_card_number":"42308093995196  (×2)
  07:41:09.420 [checkoutservice] order confirmation email sent to "hhenderson@example.org"
  07:41:10.778 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"63","nanos":460384784},"credit_card":{"credit_card_number":"436814040047483  (×3)
  07:41:10.792 [checkoutservice] order confirmation email sent to "gomezwilliam@example.com"
  07:41:23.032 [redis] 78:C 18 Nov 2024 07:41:23.032 * DB saved on disk
  07:41:30.304 [emailservice] A request to send order confirmation email to shanehudson@example.org has been received.
  07:41:43.926 [emailservice] A request to send order confirmation email to nicoleanderson@example.com has been received.
  07:41:45.209 [emailservice] A request to send order confirmation email to nicholasduran@example.org has been received.
  07:41:49.165 [paymentservice] Transaction processed: visa ending 4058 Amount: USD563.200000000
  07:41:59.364 [checkoutservice] [PlaceOrder] user_id="736a09b5-665e-4823-8520-b8602b0bdbff" user_currency="JPY"
  07:41:59.397 [emailservice] A request to send order confirmation email to hardykelli@example.org has been received.
  07:42:02.036 [checkoutservice] order confirmation email sent to "rhonda65@example.com"

## p0225
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T07:51:42.901Z
```
{"timestamp":1731916302901283800,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Getting supported currencies..."}
```
Same service, the 2 minutes before (oldest first):
  07:51:42.749 [currencyservice] Getting supported currencies...  (×5)
  07:51:42.770 [currencyservice] conversion request successful  (×15)
All services, 30 seconds either side (sampled):
  07:51:12.951 [frontend] request started  (×306)
  07:51:12.959 [cartservice] GetCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×254)
  07:51:12.980 [adservice] received ad request (context_words=[kitchen])  (×56)
  07:51:13.054 [shippingservice] [GetQuote] received request  (×68)
  07:51:13.496 [adservice] received ad request (context_words=[footwear])  (×12)
  07:51:14.745 [frontend] ENV_PLATFORM is: aws  (×35)
  07:51:15.790 [adservice] received ad request (context_words=[hair, beauty])  (×17)
  07:51:18.258 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', '0PUK6V6EV0', '1YMWWN1N4O', '2ZYFJ3GM2N']  (×2)
  07:51:19.511 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="CAD"  (×2)
  07:51:19.551 [checkoutservice] payment went through (transaction_id: c61e707d-3aba-4fc4-a905-3622b758a42a)  (×6)
  07:51:19.555 [cartservice] EmptyCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121  (×6)
  07:51:19.563 [frontend] order placed  (×6)
  07:51:25.088 [redis] 80:C 18 Nov 2024 07:51:25.087 * DB saved on disk
  07:51:33.788 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '66VCHSJNUP', '0PUK6V6EV0']
  07:51:46.165 [paymentservice] Transaction processed: visa ending 5497 Amount: USD634.320000000  (×2)
  07:51:48.870 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '66VCHSJNUP']
  07:51:57.658 [paymentservice] Transaction processed: visa ending 9776 Amount: TRY11302.658447622
  07:52:00.558 [emailservice] starting the email service in dummy mode.
  07:52:03.888 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="EUR"
  07:52:03.923 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 13  (×3)
  07:52:05.468 [emailservice] A request to send order confirmation email to ccraig@example.com has been received.
  07:52:12.135 [checkoutservice] failed to send order confirmation to "whooper@example.com": rpc error: code = Internal desc = Failed to serialize response!

## p0300
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:51:48.458Z
```
{"timestamp":1732243908458830600,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Order: {\"customer\":\"http://user/customers/673ff1b4b0df5c00019b0a35\",\"address\":\"http://user/addresses/673ff1b9b0df5c00019b0a3a\",\"card\":\"http://user/cards/673ff1b9b0df5c00019b0a3b\",\"items\":\"http://carts/carts/673ff1b4b0df5c00019b0a35/items\"}"}
```
Same service, the 2 minutes before (oldest first):
  02:51:48.361 [front-end] Merging carts for customer id: 673ff1c4b0df5c00019b0a53 and session id: -7CzSWzmZrMmDK5B1dmO1fprYUPKidbH  (×2)
  02:51:48.383 [front-end] Carts merged.  (×2)
  02:51:48.383 [front-end] set cookie673ff1c4b0df5c00019b0a53  (×2)
  02:51:48.383 [front-end] Sent cookies.  (×2)
  02:51:48.386 [front-end] POST /register 200 28.058 ms - 33  (×2)
  02:51:48.421 [front-end] Posting Customer: {"username":"zdKOpLtZtUaAnev","password":"LgbgY","email":"zdKOpLtZtUaAnev@gmail.com","firstName":"zdKOpLtZtUaAnev","lastName":"zdKOpLtZtUaAnev
  02:51:48.427 [front-end] { id: '673ff1c4b0df5c00019b0a54' }
  02:51:48.427 [front-end] 673ff1c4b0df5c00019b0a54
  02:51:48.446 [front-end] Request received with body: {}
  02:51:48.452 [front-end] Received response: "{\"firstName\":\"tQeXOe\",\"lastName\":\"tQeXOe\",\"username\":\"tQeXOe\",\"id\":\"673ff1b4b0df5c00019b0a35\",\"_links\":{\"addresses\":{\"h
  02:51:48.452 [front-end] GET Request to: http://user/customers/673ff1b4b0df5c00019b0a35/addresses  (×2)
  02:51:48.458 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff1b9b0df5c00019b0a3b\",\"_links\":{\"
  02:51:48.458 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  02:51:48.458 [front-end] [ undefined, undefined ]
All services, 30 seconds either side (sampled):
  02:51:18.518 [catalogue] ts=2024-11-22T02:51:18Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.289716ms  (×47)
  02:51:18.868 [user] ts=2024-11-22T02:51:18.868351043Z caller=middlewares.go:104 method=GetAddresses id=673ff197b0df5c00019b09d1 result=1 took=870.79µs  (×25)
  02:51:18.892 [queue-master] 2024-11-22 02:51:18.892 INFO 6 --- [ool-6-thread-34] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×108)
  02:51:18.927 [carts] 2024-11-22 02:51:18.927 INFO [carts,eaab49d1cd2885f6,2b11d85422975e55,false] 7 --- [-nio-80-exec-24] w.w.s.cart.controllers.CartsController : Merge carts reques  (×32)
  02:51:19.899 [front-end] Received response: "{\"firstName\":\"cduSiU\",\"lastName\":\"cduSiU\",\"username\":\"cduSiU\",\"id\":\"673ff197b0df5c00019b09d0\",\"_links\":{\"addresses\":{\"h
  02:51:20.447 [front-end] Order response: {"id":"673ff1a8d94b9000069b3e6f","customerId":"673ff195b0df5c00019b09c9","customer":{"id":null,"firstName":"ntIiC","lastName":"ntIiC","username"
  02:51:21.162 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff1a9d94b9000069b3e72","customerId":"673ff196b0df5c00019b09ce","customer":{"id":null,"firstName":"MPFSbsCJV",
  02:51:22.544 [user] ts=2024-11-22T02:51:22.543779252Z caller=middlewares.go:46 method=Register username=ZMjTiAGuBAX email=ZMjTiAGuBAX@gmail.com took=953.341µs  (×9)
  02:51:23.939 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff1a4b0df5c00019b09fb"}  (×42)
  02:51:24.029 [carts] 2024-11-22 02:51:24.028 WARN [carts,b7ca950fcdaeac66,b7ca950fcdaeac66,false] 7 --- [-nio-80-exec-28] o.s.web.servlet.PageNotFound : Request method 'POST' not su  (×31)
  02:51:25.389 [front-end] Posting Customer: {"username":"PPSynBUUkOeqd","password":"QPyzlBu","email":"PPSynBUUkOeqd@gmail.com","firstName":"PPSynBUUkOeqd","lastName":"PPSynBUUkOeqd"}
  02:51:28.105 [carts-db] {"t":{"$date":"2024-11-22T02:51:28.104+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224388
  02:51:29.106 [carts] 2024-11-22 02:51:29.106 WARN [carts,d860ce369403952a,d860ce369403952a,false] 7 --- [p-nio-80-exec-7] o.s.web.servlet.PageNotFound : Request method 'POST' not su  (×10)
  02:51:31.013 [front-end] Order response: {"id":"673ff1b3d94b9000069b3e7b","customerId":"673ff197b0df5c00019b09d3","customer":{"id":null,"firstName":"GIWWf","lastName":"GIWWf","username"
  02:51:34.141 [front-end] Order response: {"id":"673ff1b6d94b9000069b3e7d","customerId":"673ff1a4b0df5c00019b09fb","customer":{"id":null,"firstName":"EkSLOMiOSHJh","lastName":"EkSLOMiOSH
  02:51:35.418 [front-end] Order response: {"id":"673ff1b7d94b9000069b3e7f","customerId":"673ff1a6b0df5c00019b0a00","customer":{"id":null,"firstName":"vGHgjzZMKaRR","lastName":"vGHgjzZMKa
  02:51:38.216 [front-end] Posting Customer: {"username":"adJNPbl","password":"MeaDppveP","email":"adJNPbl@gmail.com","firstName":"adJNPbl","lastName":"adJNPbl"}
  02:51:41.274 [user] ts=2024-11-22T02:51:41.272835734Z caller=middlewares.go:46 method=Register username=hztxRft email=hztxRft@gmail.com took=1.665856ms
  02:51:42.321 [front-end] Received response: "{\"firstName\":\"sKSQlMmjJQ\",\"lastName\":\"sKSQlMmjJQ\",\"username\":\"sKSQlMmjJQ\",\"id\":\"673ff1aab0df5c00019b0a07\",\"_links\":{\"addr
  02:51:43.102 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff1bfd94b9000069b3e87","customerId":"673ff1adb0df5c00019b0a19","customer":{"id":null,"firstName":"NMxxYzllIFP
  02:51:44.300 [front-end] Order response: {"id":"673ff1c0d94b9000069b3e8a","customerId":"673ff1abb0df5c00019b0a0c","customer":{"id":null,"firstName":"FZQmbkG","lastName":"FZQmbkG","usern
  02:51:45.477 [front-end] Posting Customer: {"username":"fBDrVaBt","password":"UKcBha","email":"fBDrVaBt@gmail.com","firstName":"fBDrVaBt","lastName":"fBDrVaBt"}
  02:51:48.853 [front-end] Received response: "{\"firstName\":\"ZMjTiAGuBAX\",\"lastName\":\"ZMjTiAGuBAX\",\"username\":\"ZMjTiAGuBAX\",\"id\":\"673ff1aab0df5c00019b0a08\",\"_links\":{\"a
  02:51:49.637 [front-end] Received response: "{\"firstName\":\"AWtnbOhrsRlhx\",\"lastName\":\"AWtnbOhrsRlhx\",\"username\":\"AWtnbOhrsRlhx\",\"id\":\"673ff1a8b0df5c00019b0a04\",\"_links\
  02:51:53.613 [front-end] Posting Customer: {"username":"BhtbaMr","password":"RdEcJDazID","email":"BhtbaMr@gmail.com","firstName":"BhtbaMr","lastName":"BhtbaMr"}
  02:51:55.932 [front-end] Posting Customer: {"username":"DBmNWolRgHzq","password":"iSExCIsmby","email":"DBmNWolRgHzq@gmail.com","firstName":"DBmNWolRgHzq","lastName":"DBmNWolRgHzq"}
  02:51:57.033 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff1cdd94b9000069b3e96","customerId":"673ff1bab0df5c00019b0a3e","customer":{"id":null,"firstName":"LPEYFReblte
  02:52:00.872 [front-end] Posting Customer: {"username":"fjxUVfXnkNGpi","password":"ClYpis","email":"fjxUVfXnkNGpi@gmail.com","firstName":"fjxUVfXnkNGpi","lastName":"fjxUVfXnkNGpi"}

## p0619
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-admin-basic-info-service, 2024-12-07T20:16:59.504Z
```
{"timestamp":1733602619504317200,"container_name":"ts-admin-basic-info-service","pod_name":"ts-admin-basic-info-service-87bf97b79-s4tgm","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 20:16:59.503  INFO 1 --- [io-18767-exec-6] a.controller.AdminBasicInfoController    : [Admin Basic Info Service][Find All Price by admin "}
```
Same service, the 2 minutes before (oldest first):
  20:16:35.350 [ts-admin-basic-info-service] 2024-12-07 20:16:35.350 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin 
  20:16:36.071 [ts-admin-basic-info-service] 2024-12-07 20:16:36.070 INFO 1 --- [io-18767-exec-1] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×7)
  20:16:43.257 [ts-admin-basic-info-service] 2024-12-07 20:16:43.257 INFO 1 --- [io-18767-exec-2] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×5)
  20:16:43.267 [ts-admin-basic-info-service] 2024-12-07 20:16:43.266 INFO 1 --- [io-18767-exec-2] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×5)
  20:16:51.342 [ts-admin-basic-info-service] 2024-12-07 20:16:51.341 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  20:16:51.350 [ts-admin-basic-info-service] 2024-12-07 20:16:51.349 INFO 1 --- [o-18767-exec-10] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult] 
All services, 30 seconds either side (sampled):
  20:16:29.754 [ts-auth-service] 2024-12-07 20:16:29.753 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×12)
  20:16:29.887 [ts-route-service] 2024-12-07 20:16:29.887 INFO 1 --- [io-11178-exec-7] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×93)
  20:16:29.950 [ts-travel-service] 2024-12-07 20:16:29.950 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×7)
  20:16:30.098 [ts-travel2-service] 2024-12-07 20:16:30.097 INFO 1 --- [io-16346-exec-9] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×11)
  20:16:30.166 [ts-basic-service] 2024-12-07 20:16:30.166 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×3)
  20:16:30.185 [ts-basic-service] 2024-12-07 20:16:30.185 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1  (×3)
  20:16:30.266 [ts-seat-service] 2024-12-07 20:16:30.265 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×2)
  20:16:30.292 [ts-seat-service] 2024-12-07 20:16:30.292 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:16:30.362 [ts-seat-service] 2024-12-07 20:16:30.362 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×6)
  20:16:30.434 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:30 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 356 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×12)
  20:16:31.289 [ts-order-other-service] 2024-12-07 20:16:31.289 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-
  20:16:31.556 [ts-consign-service] 2024-12-07 20:16:31.556 INFO 1 --- [io-16111-exec-1] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] 4432ab96-7bf2-43bd-b045-  (×2)
  20:16:31.588 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T20:16:31.587+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360259
  20:16:31.686 [ts-order-other-service] 2024-12-07 20:16:31.686 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0
  20:16:31.811 [ts-user-mongo] {"t":{"$date":"2024-12-07T20:16:31.811+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360259
  20:16:32.910 [ts-food-service] 2024-12-07 20:16:32.909 INFO 1 --- [io-18856-exec-7] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:16:36.071 [ts-admin-basic-info-service] 2024-12-07 20:16:36.070 INFO 1 --- [io-18767-exec-1] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×14)
  20:16:40.693 [ts-auth-service] 2024-12-07 20:16:40.693 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×2)
  20:16:42.644 [ts-basic-service] 2024-12-07 20:16:42.644 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa
  20:16:42.675 [ts-basic-service] 2024-12-07 20:16:42.675 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai
  20:16:43.206 [ts-payment-mongo] {"t":{"$date":"2024-12-07T20:16:43.206+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360260
  20:16:48.358 [ts-food-service] 2024-12-07 20:16:48.358 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345
  20:16:57.621 [ts-route-service] 2024-12-07 20:16:57.621 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  20:16:57.634 [ts-route-service] 2024-12-07 20:16:57.634 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:22}] to ts-route-mongo:  (×2)
  20:16:58.494 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:58 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×9)
  20:17:18.203 [ts-travel2-service] 2024-12-07 20:17:18.202 ERROR 1 --- [o-16346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  20:17:28.414 [ts-price-mongo] {"t":{"$date":"2024-12-07T20:17:28.413+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360264
  20:17:29.370 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:29 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 500 231 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe

## p0380
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:43:27.503Z
```
{"timestamp":1732247007503380500,"container_name":"carts","pod_name":"carts-6cdcbc6cd7-bswq8","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:43:27.503  INFO [carts,5ffc457e80dda959,526daa68fae6f5a9,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.controllers.ItemsController   : Did not find item. Creating item for user: 673ffdd9b0df5c00019b2f5b, Item{id='673ffddf2f1cab0007facb02', itemId='837ab141-399e-4c1f-9abc-bace40296bac', quantity=1, unitPrice=15.0}"}
```
Same service, the 2 minutes before (oldest first):
  03:43:21.273 [carts] 2024-11-22 03:43:21.273 INFO [carts,37c42f27e6478b06,7ce1e73024d4da79,false] 7 --- [p-nio-80-exec-9] w.w.s.cart.controllers.ItemsController : Did not find item.  (×5)
  03:43:21.280 [carts] 2024-11-22 03:43:21.280 INFO [carts,37c42f27e6478b06,7ce1e73024d4da79,false] 7 --- [p-nio-80-exec-9] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×5)
  03:43:21.302 [carts] 2024-11-22 03:43:21.302 INFO [carts,257139d3ba44ef90,c40159fc3d784e20,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×4)
  03:43:21.329 [carts] 2024-11-22 03:43:21.329 INFO [carts,8253a7c7fee30198,634fb1261b474a9b,false] 7 --- [-nio-80-exec-10] w.w.s.cart.controllers.CartsController : Merge carts reques  (×4)
  03:43:23.007 [carts] 2024-11-22 03:43:23.007 INFO [carts,b6408a10d6218dc5,2d035b1b47794d8d,false] 7 --- [-nio-80-exec-18] w.w.s.cart.controllers.ItemsController : Did not find item.
  03:43:23.015 [carts] 2024-11-22 03:43:23.014 INFO [carts,b6408a10d6218dc5,2d035b1b47794d8d,false] 7 --- [-nio-80-exec-18] w.w.s.cart.cart.CartContentsResource : Adding for user: Car
All services, 30 seconds either side (sampled):
  03:42:57.945 [catalogue] ts=2024-11-22T03:42:57Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.3625ms  (×64)
  03:42:58.322 [user] ts=2024-11-22T03:42:58.321924511Z caller=middlewares.go:104 method=GetAddresses id=673ffdb7b0df5c00019b2ef0 result=1 took=978.326µs  (×35)
  03:42:58.347 [queue-master] 2024-11-22 03:42:58.347 INFO 6 --- [ool-6-thread-48] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×40)
  03:42:58.485 [front-end] User cart deleted with status: 202  (×62)
  03:42:58.915 [front-end] POST to carts: http://carts/carts/673ffdbdb0df5c00019b2efe/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}  (×27)
  03:42:59.503 [front-end] set cookie673ffdc3b0df5c00019b2f0b  (×65)
  03:43:00.635 [payment] ts=2024-11-22T03:43:00Z caller=logging.go:29 method=Authorise result=true took=951ns  (×34)
  03:43:01.934 [front-end] Posting Customer: {"username":"EewXOAPbirg","password":"NzdpYsxS","email":"EewXOAPbirg@gmail.com","firstName":"EewXOAPbirg","lastName":"EewXOAPbirg"}
  03:43:02.526 [front-end] Order response: {"id":"673ffdc6d94b9000069b47ad","customerId":"673ffdb1b0df5c00019b2edf","customer":{"id":null,"firstName":"rvCqMTmQGUsuzx","lastName":"rvCqMTmQ
  03:43:04.763 [front-end] Posting Customer: {"username":"TxUzDcjub","password":"AHOelDF","email":"TxUzDcjub@gmail.com","firstName":"TxUzDcjub","lastName":"TxUzDcjub"}
  03:43:07.849 [front-end] Posting Customer: {"username":"JhURHOeViHweu","password":"veasEld","email":"JhURHOeViHweu@gmail.com","firstName":"JhURHOeViHweu","lastName":"JhURHOeViHweu"}
  03:43:10.764 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdced94b9000069b47b1","customerId":"673ffdbbb0df5c00019b2ef8","customer":{"id":null,"firstName":"fLItzEWVGdq
  03:43:13.468 [user] ts=2024-11-22T03:43:13.468729539Z caller=middlewares.go:46 method=Register username=HcEIw email=HcEIw@gmail.com took=1.095526ms
  03:43:14.619 [front-end] Received response: "{\"firstName\":\"SvRvqJSYrXwS\",\"lastName\":\"SvRvqJSYrXwS\",\"username\":\"SvRvqJSYrXwS\",\"id\":\"673ffdc0b0df5c00019b2eff\",\"_links\":{
  03:43:14.876 [front-end] Order response: {"id":"673ffdd2d94b9000069b47b6","customerId":"673ffdbdb0df5c00019b2efd","customer":{"id":null,"firstName":"xdBoNAXezKdSKL","lastName":"xdBoNAXe
  03:43:22.409 [front-end] Received response: "{\"firstName\":\"opbLXWwfGnVvRP\",\"lastName\":\"opbLXWwfGnVvRP\",\"username\":\"opbLXWwfGnVvRP\",\"id\":\"673ffdc9b0df5c00019b2f1a\",\"_lin
  03:43:23.505 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffddbd94b9000069b47ba","customerId":"673ffdc5b0df5c00019b2f0e","customer":{"id":null,"firstName":"OThtLIsTsiH
  03:43:24.963 [front-end] Received response: "{\"firstName\":\"TxUzDcjub\",\"lastName\":\"TxUzDcjub\",\"username\":\"TxUzDcjub\",\"id\":\"673ffdc8b0df5c00019b2f19\",\"_links\":{\"address
  03:43:26.741 [front-end] Received response: "{\"firstName\":\"FjIBgpqiWYgXCEH\",\"lastName\":\"FjIBgpqiWYgXCEH\",\"username\":\"FjIBgpqiWYgXCEH\",\"id\":\"673ffdccb0df5c00019b2f28\",\"_
  03:43:27.726 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffddfd94b9000069b47c3","customerId":"673ffdcfb0df5c00019b2f2e","customer":{"id":null,"firstName":"MSMhLESnSjG
  03:43:28.806 [orders-db] {"t":{"$date":"2024-11-22T03:43:28.806+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224700
  03:43:29.761 [front-end] Received response: "{\"firstName\":\"qZEgvgztzB\",\"lastName\":\"qZEgvgztzB\",\"username\":\"qZEgvgztzB\",\"id\":\"673ffdd5b0df5c00019b2f4c\",\"_links\":{\"addr
  03:43:35.050 [front-end] Received response: "{\"firstName\":\"EOOhxQuGFX\",\"lastName\":\"EOOhxQuGFX\",\"username\":\"EOOhxQuGFX\",\"id\":\"673ffdd1b0df5c00019b2f3e\",\"_links\":{\"addr
  03:43:37.356 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffde9d94b9000069b47cd","customerId":"673ffdd1b0df5c00019b2f35","customer":{"id":null,"firstName":"XZbRK","las
  03:43:39.754 [front-end] Posting Customer: {"username":"ijQFfEAgFfuvKzE","password":"TnbvgasF","email":"ijQFfEAgFfuvKzE@gmail.com","firstName":"ijQFfEAgFfuvKzE","lastName":"ijQFfEAgFfuv
  03:43:42.955 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdeed94b9000069b47d0","customerId":"673ffddcb0df5c00019b2f69","customer":{"id":null,"firstName":"qJqohTN","l
  03:43:44.538 [front-end] Received response: "{\"firstName\":\"wDbabVZf\",\"lastName\":\"wDbabVZf\",\"username\":\"wDbabVZf\",\"id\":\"673ffddbb0df5c00019b2f65\",\"_links\":{\"addresses\
  03:43:46.297 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdf2d94b9000069b47d5","customerId":"673ffdddb0df5c00019b2f6b","customer":{"id":null,"firstName":"SPGPcOuF","
  03:43:49.096 [front-end] Order response: {"id":"673ffdf5d94b9000069b47d7","customerId":"673ffddfb0df5c00019b2f6f","customer":{"id":null,"firstName":"fSOCXj","lastName":"fSOCXj","usernam
  03:43:55.421 [front-end] Received response: "{\"firstName\":\"XNuYV\",\"lastName\":\"XNuYV\",\"username\":\"XNuYV\",\"id\":\"673ffde2b0df5c00019b2f76\",\"_links\":{\"addresses\":{\"href

## p0590
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:32:34.503Z
```
{"timestamp":1733596354503310600,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:32:34.503  INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl     : UsernamePasswordAuthenticationToken  username :fdse_microservice"}
```
Same service, the 2 minutes before (oldest first):
  18:32:27.067 [ts-auth-service] 2024-12-07 18:32:27.067 INFO 1 --- [io-12340-exec-1] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×2)
  18:32:27.284 [ts-auth-service] 2024-12-07 18:32:27.284 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×5)
  18:32:27.284 [ts-auth-service] 2024-12-07 18:32:27.284 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×5)
  18:32:28.059 [ts-auth-service] 2024-12-07 18:32:28.059 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  18:32:28.392 [ts-auth-service] 2024-12-07 18:32:28.391 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×3)
  18:32:28.392 [ts-auth-service] 2024-12-07 18:32:28.391 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×3)
All services, 30 seconds either side (sampled):
  18:32:04.824 [ts-admin-basic-info-service] 2024-12-07 18:32:04.823 ERROR 1 --- [io-18767-exec-1] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×28)
  18:32:04.827 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:32:04 +0800] "GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×16)
  18:32:06.381 [ts-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×2)
  18:32:06.390 [ts-assurance-service] 2024-12-07 18:32:06.390 ERROR 1 --- [io-18888-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  18:32:07.072 [ts-auth-service] 2024-12-07 18:32:07.071 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×12)
  18:32:07.275 [ts-auth-service] 2024-12-07 18:32:07.275 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×25)
  18:32:07.295 [ts-admin-travel-service] 2024-12-07 18:32:07.295 ERROR 1 --- [o-16114-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×3)
  18:32:07.881 [ts-auth-service] 2024-12-07 18:32:07.880 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×13)
  18:32:08.287 [ts-travel2-service] 2024-12-07 18:32:08.286 ERROR 1 --- [io-16346-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×11)
  18:32:08.405 [ts-admin-basic-info-service] 2024-12-07 18:32:08.405 ERROR 1 --- [o-18767-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×4)
  18:32:08.507 [ts-auth-service] 2024-12-07 18:32:08.507 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×3)
  18:32:08.675 [ts-auth-service] 2024-12-07 18:32:08.675 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×3)
  18:32:09.296 [ts-food-service] 2024-12-07 18:32:09.295 ERROR 1 --- [io-18856-exec-2] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×4)
  18:32:09.305 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:32:09 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 500 259 "-" "Mozilla/5.0 (Macintosh;   (×4)
  18:32:27.265 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:32:27.265+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359634
  18:32:27.501 [ts-price-mongo] {"t":{"$date":"2024-12-07T18:32:27.501+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359634
  18:32:29.848 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:32:29.848+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359634
  18:32:29.904 [ts-station-mongo] {"t":{"$date":"2024-12-07T18:32:29.903+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359634
  18:32:30.447 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T18:32:30.447+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359635
  18:32:30.636 [ts-security-mongo] {"t":{"$date":"2024-12-07T18:32:30.636+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359635
  18:32:30.959 [ts-order-mongo] {"t":{"$date":"2024-12-07T18:32:30.959+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359635
  18:32:42.227 [ts-order-other-mongo] {"t":{"$date":"2024-12-07T18:32:42.226+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359636
  18:33:03.012 [ts-order-service] 2024-12-07 18:33:03.012 ERROR 1 --- [io-12031-exec-7] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:33:03.021 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:33:03 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 500 229 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Apple

## p0785
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:43:31.439Z
```
{"timestamp":1732351411439845400,"container_name":"front-end","pod_name":"front-end-f77549869-fh46p","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"npm ERR! command failed"}
```
Same service, the 2 minutes before (oldest first):
  08:43:30.710 [front-end] POST /cart 201 - ms - -
  08:43:30.781 [front-end] GET /catalogue 200 - ms - -
  08:43:31.431 [front-end] npm timing command:run-script Completed in 819270ms
  08:43:31.432 [front-end] npm timing command:start Completed in 819274ms
  08:43:31.432 [front-end] npm notice   (×2)
  08:43:31.432 [front-end] npm notice New major version of npm available! 8.19.4 -> 10.9.1
  08:43:31.432 [front-end] npm notice Changelog: <https://github.com/npm/cli/releases/tag/v10.9.1>
  08:43:31.432 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!
  08:43:31.434 [front-end] npm verb stack Error: command failed
  08:43:31.434 [front-end] npm verb stack at ChildProcess.<anonymous> (/usr/local/lib/node_modules/npm/node_modules/@npmcli/promise-spawn/lib/index.js:63:27)
  08:43:31.434 [front-end] npm verb stack at ChildProcess.emit (node:events:513:28)
  08:43:31.434 [front-end] npm verb stack at maybeClose (node:internal/child_process:1100:16)
  08:43:31.434 [front-end] npm verb stack at Process.ChildProcess._handle.onexit (node:internal/child_process:304:5)
  08:43:31.439 [front-end] npm verb pkgid microservices-demo-front-end@0.0.1
  08:43:31.439 [front-end] npm verb cwd /usr/src/app
  08:43:31.439 [front-end] npm verb Linux 5.10.227-219.884.amzn2.x86_64
  08:43:31.439 [front-end] npm verb node v16.20.2
  08:43:31.439 [front-end] npm verb npm v8.19.4
  08:43:31.439 [front-end] npm ERR! path /usr/src/app
All services, 30 seconds either side (sampled):
  08:43:01.574 [catalogue] ts=2024-11-23T08:43:01Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.120099ms  (×45)
  08:43:02.003 [user] ts=2024-11-23T08:43:02.003248176Z caller=middlewares.go:104 method=GetAddresses id=67419589a437380001defe29 result=1 took=2.452319ms  (×29)
  08:43:02.022 [front-end] Order response: {"statusCode":201,"body":{"id":"674195963f7706000886534b","customerId":"67419583a437380001defe16","customer":{"id":null,"firstName":"kOAxFHlONns
  08:43:02.535 [front-end] Sent cookies.  (×51)
  08:43:02.892 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}  (×55)
  08:43:03.630 [front-end] Posting Customer: {"username":"OsNYqfzZRaMW","password":"izyKK","email":"OsNYqfzZRaMW@gmail.com","firstName":"OsNYqfzZRaMW","lastName":"OsNYqfzZRaMW"}
  08:43:04.804 [front-end] Order response: {"id":"674195983f7706000886534c","customerId":"67419587a437380001defe24","customer":{"id":null,"firstName":"XcAQaDJCWNfQJ","lastName":"XcAQaDJCW
  08:43:07.065 [front-end] Order response: {"timestamp":1732351387063,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×4)
  08:43:08.747 [front-end] Posting Customer: {"username":"atjnaEuCr","password":"YeayP","email":"atjnaEuCr@gmail.com","firstName":"atjnaEuCr","lastName":"atjnaEuCr"}
  08:43:10.781 [front-end] Posting Customer: {"username":"RgzxpfsTAiQ","password":"MpdymG","email":"RgzxpfsTAiQ@gmail.com","firstName":"RgzxpfsTAiQ","lastName":"RgzxpfsTAiQ"}
  08:43:11.764 [front-end] Order response: {"id":"6741959f3f77060008865352","customerId":"6741958fa437380001defe3a","customer":{"id":null,"firstName":"tXOnd","lastName":"tXOnd","username"
  08:43:14.237 [front-end] npm timing config:load:cli Completed in 3ms  (×2)
  08:43:14.238 [front-end] npm timing npm:load:configload Completed in 103ms  (×2)
  08:43:14.246 [front-end] npm timing npm:load:logFile Completed in 7ms  (×2)
  08:43:14.578 [front-end] Received response: "{\"firstName\":\"BIRJKPIoxpSLPc\",\"lastName\":\"BIRJKPIoxpSLPc\",\"username\":\"BIRJKPIoxpSLPc\",\"id\":\"6741958ea437380001defe37\",\"_lin
  08:43:16.133 [front-end] Order response: {"id":"674195a43f77060008865355","customerId":"67419593a437380001defe44","customer":{"id":null,"firstName":"CfYLelSE","lastName":"CfYLelSE","use
  08:43:19.655 [front-end] Order response: {"id":"674195a73f77060008865357","customerId":"6741958ba437380001defe2d","customer":{"id":null,"firstName":"FuTpsQAV","lastName":"FuTpsQAV","use
  08:43:22.050 [front-end] Received response: "{\"firstName\":\"YyimhmvssZ\",\"lastName\":\"YyimhmvssZ\",\"username\":\"YyimhmvssZ\",\"id\":\"67419599a437380001defe5a\",\"_links\":{\"addr
  08:43:23.805 [front-end] Order response: {"id":"674195ab3f7706000886535c","customerId":"6741959aa437380001defe5d","customer":{"id":null,"firstName":"sQDhmFmoIZwIYDG","lastName":"sQDhmFm
  08:43:26.197 [front-end] Posting Customer: {"username":"flEFTXC","password":"etSAPItUy","email":"flEFTXC@gmail.com","firstName":"flEFTXC","lastName":"flEFTXC"}
  08:43:27.706 [front-end] Order response: {"statusCode":201,"body":{"id":"674195af3f77060008865361","customerId":"67419598a437380001defe55","customer":{"id":null,"firstName":"gOgYQtJy","
  08:43:30.102 [front-end] Order response: {"statusCode":201,"body":{"id":"674195b23f77060008865363","customerId":"6741959ca437380001defe64","customer":{"id":null,"firstName":"atjnaEuCr",
  08:43:31.434 [front-end] npm verb stack Error: command failed  (×2)
  08:43:31.439 [front-end] npm ERR! signal SIGTERM  (×2)
  08:43:36.462 [front-end] Received response: "{\"firstName\":\"FBOLvYflPzcEwLv\",\"lastName\":\"FBOLvYflPzcEwLv\",\"username\":\"FBOLvYflPzcEwLv\",\"id\":\"674195a2a437380001defe79\",\"_
  08:43:40.775 [front-end] Received response: "{\"firstName\":\"xlkVGcv\",\"lastName\":\"xlkVGcv\",\"username\":\"xlkVGcv\",\"id\":\"674195a7a437380001defe84\",\"_links\":{\"addresses\":{
  08:43:45.655 [front-end] Posting Customer: {"username":"PHSmla","password":"chOsruk","email":"PHSmla@gmail.com","firstName":"PHSmla","lastName":"PHSmla"}
  08:43:48.791 [front-end] Received response: "{\"firstName\":\"BJjqqW\",\"lastName\":\"BJjqqW\",\"username\":\"BJjqqW\",\"id\":\"674195aea437380001defe9c\",\"_links\":{\"addresses\":{\"h
  08:43:57.303 [front-end] Received response: "{\"firstName\":\"bSIxNayRKIFiLC\",\"lastName\":\"bSIxNayRKIFiLC\",\"username\":\"bSIxNayRKIFiLC\",\"id\":\"674195bfa437380001defec0\",\"_lin

## p0774
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T19:30:58.133Z
```
{"timestamp":1732390258133287200,"container_name":"user","pod_name":"user-558cdfd768-brrlt","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"ts=2024-11-23T19:30:58.133174075Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67422d6948485600016b1a25 took=10.311865ms"}
```
Same service, the 2 minutes before (oldest first):
  19:30:56.563 [user] ts=2024-11-23T19:30:56.563093689Z caller=middlewares.go:104 method=GetAddresses id=67422d6248485600016b1a0d result=1 took=4.070941ms  (×2)
  19:30:56.563 [user] ts=2024-11-23T19:30:56.563108707Z caller=middlewares.go:134 method=GetCards id=67422d6248485600016b1a0e result=1 took=3.904731ms  (×2)
  19:30:56.563 [user] ts=2024-11-23T19:30:56.563121677Z caller=middlewares.go:75 method=GetUsers id=67422d5848485600016b19e9 result=1 took=4.003603ms  (×5)
  19:30:56.600 [user] ts=2024-11-23T19:30:56.600074851Z caller=middlewares.go:46 method=Register username=VqPEeuRrvOUp email=VqPEeuRrvOUp@gmail.com took=6.183261ms
  19:30:56.617 [user] ts=2024-11-23T19:30:56.616923218Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67422d6948485600016b1a28 took=8.737202ms  (×4)
  19:30:56.637 [user] ts=2024-11-23T19:30:56.637661152Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67422d6948485600016b1a28 took=10.035826ms  (×3)
  19:30:56.696 [user] ts=2024-11-23T19:30:56.696795907Z caller=middlewares.go:157 method=Health result=2 took=4.438699ms  (×2)
  19:30:57.485 [user] ts=2024-11-23T19:30:57.485848197Z caller=middlewares.go:46 method=Register username=BMrwg email=BMrwg@gmail.com took=4.326461ms
All services, 30 seconds either side (sampled):
  19:30:28.241 [catalogue] ts=2024-11-23T19:30:28Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.449035ms  (×62)
  19:30:28.793 [front-end] POST /register 200 28.473 ms - 33  (×61)
  19:30:28.871 [user] ts=2024-11-23T19:30:28.871387796Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67422d4e48485600016b19ca took=7.524203ms  (×61)
  19:30:28.887 [front-end] Order response: {"statusCode":201,"body":{"id":"67422d544ca85a00070c531d","customerId":"67422d3f48485600016b19a6","customer":{"id":null,"firstName":"leFEEBB","l
  19:30:28.988 [carts] 2024-11-23 19:30:28.988 INFO [carts,ae46c8a9b4476f07,19547594992ed6d3,false] 7 --- [-nio-80-exec-19] w.w.s.cart.controllers.ItemsController : Did not find item.  (×34)
  19:30:29.963 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×12)
  19:30:30.668 [front-end] Order response: {"id":"67422d564ca85a00070c5321","customerId":"67422d3d48485600016b19a0","customer":{"id":null,"firstName":"iVvBUQn","lastName":"iVvBUQn","usern
  19:30:31.537 [front-end] Order response: {"id":"67422d574ca85a00070c5323","customerId":"67422d4648485600016b19b6","customer":{"id":null,"firstName":"IrwBKHMo","lastName":"IrwBKHMo","use
  19:30:33.678 [front-end] Received response: "{\"firstName\":\"MtXZKQ\",\"lastName\":\"MtXZKQ\",\"username\":\"MtXZKQ\",\"id\":\"67422d4548485600016b19b5\",\"_links\":{\"addresses\":{\"h
  19:30:36.938 [front-end] Posting Customer: {"username":"dtMzJ","password":"gAcGpZK","email":"dtMzJ@gmail.com","firstName":"dtMzJ","lastName":"dtMzJ"}
  19:30:39.399 [front-end] Posting Customer: {"username":"OHDDE","password":"zwMnpoP","email":"OHDDE@gmail.com","firstName":"OHDDE","lastName":"OHDDE"}
  19:30:42.815 [user] ts=2024-11-23T19:30:42.815236785Z caller=middlewares.go:46 method=Register username=bGDsyoKV email=bGDsyoKV@gmail.com took=4.395753ms
  19:30:45.916 [front-end] Received response: "{\"firstName\":\"doBHEwVeadMxsZ\",\"lastName\":\"doBHEwVeadMxsZ\",\"username\":\"doBHEwVeadMxsZ\",\"id\":\"67422d5548485600016b19e0\",\"_lin
  19:30:48.406 [front-end] Order response: {"statusCode":201,"body":{"id":"67422d684ca85a00070c532e","customerId":"67422d5148485600016b19d4","customer":{"id":null,"firstName":"xJUGWGSclPn
  19:30:50.375 [front-end] Posting Customer: {"username":"yenTir","password":"usoGLqWB","email":"yenTir@gmail.com","firstName":"yenTir","lastName":"yenTir"}
  19:30:52.028 [front-end] Order response: {"statusCode":201,"body":{"id":"67422d6c4ca85a00070c5334","customerId":"67422d5448485600016b19dc","customer":{"id":null,"firstName":"VBvLwanlCpI
  19:30:56.505 [front-end] Posting Customer: {"username":"lQZaduG","password":"yYZssCQnX","email":"lQZaduG@gmail.com","firstName":"lQZaduG","lastName":"lQZaduG"}
  19:30:58.384 [user] ts=2024-11-23T19:30:58.384095579Z caller=middlewares.go:46 method=Register username=OSkfUQZ email=OSkfUQZ@gmail.com took=6.257058ms
  19:31:03.053 [front-end] Order response: {"id":"67422d774ca85a00070c5339","customerId":"67422d6248485600016b1a0f","customer":{"id":null,"firstName":"bGDsyoKV","lastName":"bGDsyoKV","use
  19:31:04.143 [front-end] Posting Customer: {"username":"cwsjtKd","password":"oVyXR","email":"cwsjtKd@gmail.com","firstName":"cwsjtKd","lastName":"cwsjtKd"}
  19:31:05.298 [front-end] Order response: {"statusCode":201,"body":{"id":"67422d794ca85a00070c533e","customerId":"67422d6348485600016b1a10","customer":{"id":null,"firstName":"ZwKTGizHaby
  19:31:07.470 [queue-master] 2024-11-23 19:31:07.470 INFO 7 --- [pool-6-thread-3] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×27)
  19:31:09.269 [front-end] Received response: "{\"firstName\":\"MRKEnprxyqX\",\"lastName\":\"MRKEnprxyqX\",\"username\":\"MRKEnprxyqX\",\"id\":\"67422d6948485600016b1a25\",\"_links\":{\"a
  19:31:12.497 [front-end] Order response: {"id":"67422d804ca85a00070c5345","customerId":"67422d6e48485600016b1a36","customer":{"id":null,"firstName":"eKpEypXsQQuES","lastName":"eKpEypXsQ
  19:31:16.650 [front-end] Received response: "{\"firstName\":\"OSkfUQZ\",\"lastName\":\"OSkfUQZ\",\"username\":\"OSkfUQZ\",\"id\":\"67422d7248485600016b1a47\",\"_links\":{\"addresses\":{
  19:31:19.921 [front-end] Order response: {"statusCode":201,"body":{"id":"67422d874ca85a00070c534a","customerId":"67422d7048485600016b1a3d","customer":{"id":null,"firstName":"VqPEeuRrvOU
  19:31:22.234 [front-end] Received response: "{\"firstName\":\"iCqfWNcQkjLbYnK\",\"lastName\":\"iCqfWNcQkjLbYnK\",\"username\":\"iCqfWNcQkjLbYnK\",\"id\":\"67422d7248485600016b1a48\",\"_
  19:31:23.636 [front-end] Received response: "{\"firstName\":\"okuTUDpVeBs\",\"lastName\":\"okuTUDpVeBs\",\"username\":\"okuTUDpVeBs\",\"id\":\"67422d7748485600016b1a4c\",\"_links\":{\"a
  19:31:25.714 [front-end] Order response: {"statusCode":201,"body":{"id":"67422d8d4ca85a00070c5351","customerId":"67422d7948485600016b1a58","customer":{"id":null,"firstName":"NiPuwAjk","
  19:31:27.495 [front-end] Order response: {"statusCode":201,"body":{"id":"67422d8f4ca85a00070c5355","customerId":"67422d7848485600016b1a53","customer":{"id":null,"firstName":"cwsjtKd","l

## p0049
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice2, 2021-08-13T08:08:48.504Z
```
{"service":"redisservice2","message":"2021-08-13 08:08:48,504 | INFO | 0.0.0.2 | 172.17.0.4 | redisservice2 | a2a73f5563392f34 | service refuse, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  08:08:44.808 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×5)
  08:08:44.850 [redisservice2] INFO redis write success  (×9)
  08:08:44.894 [redisservice2] INFO service accept, status_code: 200  (×2)
  08:08:45.495 [redisservice2] INFO redis读取信息成功, status_code: 200  (×3)
  08:08:47.909 [redisservice2] INFO service refuse, status_code: 200
All services, 30 seconds either side (sampled):
  08:08:18.527 [webservice1] INFO uuid: 9010bfa0-fbca-11eb-97c0-0242ac110003 write redis successfully  (×42)
  08:08:18.643 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×42)
  08:08:18.831 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×43)
  08:08:18.969 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×45)
  08:08:19.049 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×44)
  08:08:19.466 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×42)
  08:08:19.690 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×36)
  08:08:20.039 [redisservice1] INFO service refuse, status_code: 200  (×22)
  08:08:21.387 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  08:08:21.884 [mobservice1] INFO info 91d9474e-fbca-11eb-bbcd-0242ac110004:mwbCGSva write success
  08:08:24.824 [mobservice1] INFO info 93b356b8-fbca-11eb-836e-0242ac110004:btlsWgLd write success
  08:08:27.482 [mobservice1] INFO info 954cb186-fbca-11eb-b810-0242ac110004:cFoEvJPG write success
  08:08:33.358 [dbservice1] INFO 9889fd18-fbca-11eb-8f53-0242ac110003-kWcbAndl-+K)#TtAh_eL$ token generate success token=MTYyODgxMzMxMy4zNTc5NTQzOjk4ODlmZDE4LWZiY2EtMTFlYi04ZjUzLTAyNDJhYzE
  08:08:39.550 [mobservice2] INFO info 9c7d97e0-fbca-11eb-a350-0242ac110004:Jcofhzdp write success
  08:08:42.309 [mobservice2] INFO info 9e05b566-fbca-11eb-a1bf-0242ac110003:OxCTRwMa write success
  08:08:44.939 [dbservice1] INFO 9f7a78be-fbca-11eb-a605-0242ac110004-OkyWpDvC-YSR3f{z?a:H/ token generate success token=MTYyODgxMzMyNC45MzkzNTYzOjlmN2E3OGJlLWZiY2EtMTFlYi1hNjA1LTAyNDJhYzE
  08:08:47.698 [mobservice1] INFO info a1502c60-fbca-11eb-8906-0242ac110003:jrKReZbn write success
  08:08:50.576 [mobservice1] INFO info a306d2de-fbca-11eb-87e6-0242ac110003:hpcKRNdx write success
  08:08:52.947 [mobservice2] INFO info a475bfe0-fbca-11eb-9494-0242ac110003:nAxhWmpD write success
  08:08:55.889 [mobservice1] INFO info a63486ea-fbca-11eb-a9de-0242ac110003:mPzNQvtl write success
  08:08:58.477 [dbservice1] INFO a792d32a-fbca-11eb-a103-0242ac110003-dMOcrJWb-_!QcK%2x(ubj token generate success token=MTYyODgxMzMzOC40Nzc0ODA0OmE3OTJkMzJhLWZiY2EtMTFlYi1hMTAzLTAyNDJhYzE
  08:09:01.067 [mobservice2] INFO info a94df898-fbca-11eb-a45e-0242ac110003:rJHuqoXG write success
  08:09:04.501 [mobservice1] INFO info ab4d28da-fbca-11eb-891c-0242ac110004:hRGCgxwP write success
  08:09:07.287 [mobservice1] INFO info ad00c808-fbca-11eb-9faa-0242ac110004:SpJzmrVL write success
  08:09:10.088 [mobservice1] INFO info aead5b30-fbca-11eb-8d3f-0242ac110004:RIklYufT write success
  08:09:12.820 [mobservice1] INFO info b049af5c-fbca-11eb-a031-0242ac110004:kicMwWKP write success

## p0542
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-07T18:17:56.404Z
```
{"timestamp":1733595476404874000,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-8vwb6","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 18:17:56.404  INFO 1 --- [io-11178-exec-3] route.controller.RouteController         : Route id: 20eb7122-3a11-423f-b10a-be0dc5bce7db"}
```
Same service, the 2 minutes before (oldest first):
  18:17:53.919 [ts-route-service] 2024-12-07 18:17:53.918 INFO 1 --- [io-11178-exec-3] route.controller.RouteController : Route id: f3d4d4ef-693b-4456-8eed-59c0d717dd08  (×18)
  18:17:54.082 [ts-route-service] 2024-12-07 18:17:54.082 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: d693a2c5-ef87-4a3c-bef8-600b43f62c68  (×2)
All services, 30 seconds either side (sampled):
  18:17:26.651 [ts-auth-service] 2024-12-07 18:17:26.651 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×11)
  18:17:27.141 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:17:27.140+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359544
  18:17:27.225 [ts-basic-service] 2024-12-07 18:17:27.225 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×9)
  18:17:27.313 [ts-travel2-service] 2024-12-07 18:17:27.313 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×26)
  18:17:27.369 [ts-seat-service] 2024-12-07 18:17:27.368 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×19)
  18:17:27.498 [ts-travel2-service] 2024-12-07 18:17:27.498 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×26)
  18:17:30.291 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T18:17:30.290+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359545
  18:17:30.855 [ts-travel-service] 2024-12-07 18:17:30.855 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×75)
  18:17:30.935 [ts-basic-service] 2024-12-07 18:17:30.935 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×4)
  18:17:31.084 [ts-order-service] 2024-12-07 18:17:31.084 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160,   (×7)
  18:17:31.318 [ts-auth-service] 2024-12-07 18:17:31.318 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×3)
  18:17:37.049 [ts-travel2-service] 2024-12-07 18:17:37.049 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×19)
  18:17:37.119 [ts-basic-service] 2024-12-07 18:17:37.119 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×2)
  18:17:37.553 [ts-food-service] 2024-12-07 18:17:37.553 INFO 1 --- [io-18856-exec-1] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×3)
  18:17:37.645 [ts-contacts-service] 2024-12-07 18:17:37.644 INFO 1 --- [io-12347-exec-5] contacts.service.ContactsServiceImpl : [Contacts-Query-Service][Query-Contacts] Result Size: 2  (×2)
  18:17:39.895 [ts-security-service] 2024-12-07 18:17:39.895 INFO 1 --- [io-11188-exec-2] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....  (×2)
  18:17:39.978 [ts-preserve-other-service] 2024-12-07 18:17:39.977 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Contacts By Id is] Getting....
  18:17:40.891 [ts-travel2-service] 2024-12-07 18:17:40.891 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×4)
  18:17:41.391 [ts-seat-service] 2024-12-07 18:17:41.391 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService distributeSeat] The request seat type is economyClass and the t
  18:17:41.604 [ts-assurance-service] 2024-12-07 18:17:41.603 INFO 1 --- [io-18888-exec-9] assurance.service.AssuranceServiceImpl : [Assurance-Add&Delete-Service][AddAssurance] Success.
  18:17:42.053 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T18:17:42.053+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359546
  18:17:44.100 [ts-travel-service] 2024-12-07 18:17:44.100 INFO 1 --- [io-12346-exec-9] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234  (×6)
  18:17:45.010 [ts-basic-service] 2024-12-07 18:17:45.010 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：084837bb-53
  18:18:09.833 [ts-seat-service] 2024-12-07 18:18:09.832 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  18:18:10.282 [ts-preserve-service] 2024-12-07 18:18:10.282 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting...
  18:18:10.808 [ts-seat-service] 2024-12-07 18:18:10.808 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService distributeSeat 1] The result of getTrainTypeResult is Response(
  18:18:10.890 [ts-preserve-service] 2024-12-07 18:18:10.890 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service][Step 5] Do not need to buy assurance
  18:18:25.322 [ts-order-service] 2024-12-07 18:18:25.322 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : Name List is: Response(status=1, msg=Success, data=[Nan Jing, Shang Hai Ho

## p0602
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T20:03:59.609Z
```
{"timestamp":1733601839609702000,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-w6jt4","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:03:59.609  INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl         : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainNumber='D1345', startStation='shanghai', destStation='suzhou', seatType=2}"}
```
Same service, the 2 minutes before (oldest first):
  20:03:59.450 [ts-travel-service] 2024-12-07 20:03:59.450 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='aefcef3f-3f42-46e8-afd7-6cb2a928bd3d', stations=[nan  (×3)
  20:03:59.450 [ts-travel-service] 2024-12-07 20:03:59.450 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：a3f256c1-0e43-4f7d-9c21-121bf  (×4)
  20:03:59.461 [ts-travel-service] 2024-12-07 20:03:59.461 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×2)
  20:03:59.469 [ts-travel-service] 2024-12-07 20:03:59.469 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  20:03:59.469 [ts-travel-service] 2024-12-07 20:03:59.469 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  20:03:59.472 [ts-travel-service] 2024-12-07 20:03:59.471 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter
  20:03:59.480 [ts-travel-service] 2024-12-07 20:03:59.480 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  20:03:59.481 [ts-travel-service] 2024-12-07 20:03:59.481 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha
  20:03:59.487 [ts-travel-service] 2024-12-07 20:03:59.487 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Sat May 04 04:00:00 GMT 2013  (×2)
  20:03:59.553 [ts-travel-service] 2024-12-07 20:03:59.553 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s
  20:03:59.569 [ts-travel-service] 2024-12-07 20:03:59.568 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat
  20:03:59.593 [ts-travel-service] 2024-12-07 20:03:59.592 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)
  20:03:59.609 [ts-travel-service] 2024-12-07 20:03:59.609 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)
All services, 30 seconds either side (sampled):
  20:03:29.868 [ts-auth-service] 2024-12-07 20:03:29.868 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×14)
  20:03:30.143 [ts-travel2-service] 2024-12-07 20:03:30.142 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×122)
  20:03:30.222 [ts-basic-service] 2024-12-07 20:03:30.221 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×23)
  20:03:30.311 [ts-seat-service] 2024-12-07 20:03:30.311 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×26)
  20:03:30.382 [ts-travel2-service] 2024-12-07 20:03:30.382 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×2)
  20:03:30.567 [ts-travel2-service] 2024-12-07 20:03:30.566 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×4)
  20:03:30.750 [ts-basic-service] 2024-12-07 20:03:30.750 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×5)
  20:03:31.008 [ts-order-other-service] 2024-12-07 20:03:31.008 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×7)
  20:03:31.680 [ts-user-mongo] {"t":{"$date":"2024-12-07T20:03:31.680+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360181
  20:03:31.870 [ts-travel-service] 2024-12-07 20:03:31.869 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×20)
  20:03:32.306 [ts-basic-service] 2024-12-07 20:03:32.306 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270  (×2)
  20:03:32.410 [ts-travel-service] 2024-12-07 20:03:32.409 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×2)
  20:03:32.727 [ts-basic-service] 2024-12-07 20:03:32.726 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f  (×2)
  20:03:39.148 [ts-seat-service] 2024-12-07 20:03:39.148 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  20:03:44.078 [ts-auth-service] 2024-12-07 20:03:44.077 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×2)
  20:03:44.780 [ts-order-other-service] 2024-12-07 20:03:44.779 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Modify Order Status] Order Id: f1805b91-a421-
  20:03:52.064 [ts-admin-travel-service] 2024-12-07 20:03:52.064 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)
  20:03:59.545 [ts-basic-service] 2024-12-07 20:03:59.545 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou  (×3)
  20:04:00.106 [ts-contacts-service] 2024-12-07 20:04:00.105 INFO 1 --- [io-12347-exec-1] contacts.controller.ContactsController : [Contacts Service][Find Contacts By Account Id: 4d2a46c7-71cb-4cf1
  20:04:00.153 [ts-order-service] 2024-12-07 20:04:00.153 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Security Info Get] 4d2a46c7-71cb-4cf1-b5bb-b68406d
  20:04:00.191 [ts-preserve-service] 2024-12-07 20:04:00.191 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Getting....
  20:04:00.867 [ts-preserve-service] 2024-12-07 20:04:00.867 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : TripResponse:TripResponse(tripId=D1345, startingStation=Shang Hai, t
  20:04:01.081 [ts-seat-service] 2024-12-07 20:04:01.081 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : Left ticket info is : Response(status=1, msg=Success, data=LeftTicketInfo{so
  20:04:01.194 [ts-order-service] 2024-12-07 20:04:01.194 INFO 1 --- [io-12031-exec-8] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 50.0
  20:04:01.247 [ts-preserve-service] 2024-12-07 20:04:01.247 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service][Step 7] Do not need to consign
  20:04:09.674 [ts-basic-service] 2024-12-07 20:04:09.674 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  20:04:25.223 [ts-price-service] 2024-12-07 20:04:25.222 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]
  20:04:28.184 [ts-travel-mongo] {"t":{"$date":"2024-12-07T20:04:28.184+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360186

## p0413
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:58:44.699Z
```
{"timestamp":1732247924699492600,"container_name":"front-end","pod_name":"front-end-ccbbfbf7f-szg8d","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"firstName\\\":\\\"Vprqe\\\",\\\"lastName\\\":\\\"Vprqe\\\",\\\"username\\\":\\\"Vprqe\\\",\\\"id\\\":\\\"67400163b0df5c00019b3a36\\\",\\\"_links\\\":{\\\"addresses\\\":{\\\"href\\\":\\\"http://user/customers/67400163b0df5c00019b3a36/addresses\\\"},\\\"cards\\\":{\\\"href\\\":\\\"http://user/customers/67400163b0df5c00019b3a36/cards\\\"},\\\"customer\\\":{\\\"href\\\":\\\"http://user/customers/67400163b0df5c00019b3a36\\\"},\\\"self\\\":{\\\"href\\\":\\\"h…"}
```
Same service, the 2 minutes before (oldest first):
  03:58:44.450 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67400  (×2)
  03:58:44.450 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6740016eb0df5c00019b3a48\",\"_links\":{\"  (×2)
  03:58:44.450 [front-end] [ undefined, undefined ]  (×2)
  03:58:44.450 [front-end] Posting Order: {"customer":"http://user/customers/67400167b0df5c00019b3a45","address":"http://user/addresses/6740016eb0df5c00019b3a47","card":"http://user/cards  (×2)
  03:58:44.481 [front-end] Order response: {"statusCode":201,"body":{"id":"67400174d94b9000069b4a6f","customerId":"67400167b0df5c00019b3a45","customer":{"id":null,"firstName":"QbRwfaGNMrp
  03:58:44.481 [front-end] Order response: {"id":"67400174d94b9000069b4a6f","customerId":"67400167b0df5c00019b3a45","customer":{"id":null,"firstName":"QbRwfaGNMrpJQ","lastName":"QbRwfaGNM
  03:58:44.482 [front-end] POST /orders 201 - ms - -  (×2)
  03:58:44.597 [front-end] Request received with body: {}  (×3)
  03:58:44.606 [front-end] Received response: "{\"firstName\":\"evITZIribRIPY\",\"lastName\":\"evITZIribRIPY\",\"username\":\"evITZIribRIPY\",\"id\":\"6740015eb0df5c00019b3a1b\",\"_links\
  03:58:44.606 [front-end] GET Request to: http://user/customers/6740015eb0df5c00019b3a1b/addresses  (×2)
  03:58:44.648 [front-end] Order response: {"statusCode":201,"body":{"id":"67400174d94b9000069b4a70","customerId":"6740015eb0df5c00019b3a1b","customer":{"id":null,"firstName":"evITZIribRI
  03:58:44.648 [front-end] Order response: {"id":"67400174d94b9000069b4a70","customerId":"6740015eb0df5c00019b3a1b","customer":{"id":null,"firstName":"evITZIribRIPY","lastName":"evITZIrib
All services, 30 seconds either side (sampled):
  03:58:14.737 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67400151b0df5c00019b39f5"}  (×58)
  03:58:14.870 [carts] 2024-11-22 03:58:14.870 INFO [carts,4dad101036402c24,62d83dc7b1c8d7e5,false] 7 --- [-nio-80-exec-15] w.w.s.cart.controllers.ItemsController : Did not find item.  (×29)
  03:58:14.897 [user] ts=2024-11-22T03:58:14.897671372Z caller=middlewares.go:134 method=GetCards id=67400147b0df5c00019b39d4 result=1 took=774.222µs  (×37)
  03:58:15.093 [user] ts=2024-11-22T03:58:15.093748939Z caller=middlewares.go:157 method=Health result=2 took=606.285µs  (×39)
  03:58:15.581 [front-end] Carts merged.  (×63)
  03:58:16.835 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×3)
  03:58:17.397 [front-end] Order response: {"id":"67400159d94b9000069b4a56","customerId":"67400146b0df5c00019b39ca","customer":{"id":null,"firstName":"YkyyyvHObBrHr","lastName":"YkyyyvHOb
  03:58:19.301 [front-end] npm timing config:load:defaults Completed in 3ms  (×2)
  03:58:19.301 [front-end] npm timing config:load Completed in 104ms  (×2)
  03:58:19.384 [front-end] npm timing npm:load:configScope Completed in 0ms  (×2)
  03:58:21.054 [front-end] Order response: {"statusCode":201,"body":{"id":"6740015dd94b9000069b4a58","customerId":"67400148b0df5c00019b39d5","customer":{"id":null,"firstName":"lTZDURPARbY
  03:58:22.551 [front-end] Received response: "{\"firstName\":\"gvPQw\",\"lastName\":\"gvPQw\",\"username\":\"gvPQw\",\"id\":\"67400143b0df5c00019b39c5\",\"_links\":{\"addresses\":{\"href
  03:58:24.202 [front-end] Order response: {"id":"67400160d94b9000069b4a5c","customerId":"67400149b0df5c00019b39dd","customer":{"id":null,"firstName":"UdNgROj","lastName":"UdNgROj","usern
  03:58:28.911 [front-end] Received response: "{\"firstName\":\"JUezOvE\",\"lastName\":\"JUezOvE\",\"username\":\"JUezOvE\",\"id\":\"67400151b0df5c00019b39f5\",\"_links\":{\"addresses\":{
  03:58:30.501 [front-end] Posting Customer: {"username":"EFKSgtHIgoWhxSi","password":"GsnSugDb","email":"EFKSgtHIgoWhxSi@gmail.com","firstName":"EFKSgtHIgoWhxSi","lastName":"EFKSgtHIgoWh
  03:58:32.444 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!  (×2)
  03:58:32.446 [front-end] npm ERR! signal SIGTERM  (×2)
  03:58:39.068 [front-end] Order response: {"id":"6740016fd94b9000069b4a64","customerId":"67400154b0df5c00019b39fa","customer":{"id":null,"firstName":"aZPZyoBQeZYZRAl","lastName":"aZPZyoB
  03:58:39.707 [front-end] Order response: {"id":"6740016fd94b9000069b4a67","customerId":"6740015db0df5c00019b3a19","customer":{"id":null,"firstName":"OSwLDsB","lastName":"OSwLDsB","usern
  03:58:41.172 [front-end] Received response: "{\"firstName\":\"xwVnnVKCjmt\",\"lastName\":\"xwVnnVKCjmt\",\"username\":\"xwVnnVKCjmt\",\"id\":\"67400159b0df5c00019b3a0a\",\"_links\":{\"a
  03:58:42.987 [front-end] Received response: "{\"firstName\":\"cJnkJ\",\"lastName\":\"cJnkJ\",\"username\":\"cJnkJ\",\"id\":\"67400159b0df5c00019b3a09\",\"_links\":{\"addresses\":{\"href
  03:58:44.725 [front-end] Order response: {"timestamp":1732247924719,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$InvalidOrder  (×7)
  03:58:46.963 [front-end] Posting Customer: {"username":"ekPCG","password":"ocNiGAWrRC","email":"ekPCG@gmail.com","firstName":"ekPCG","lastName":"ekPCG"}
  03:58:51.055 [front-end] Received response: "{\"firstName\":\"UmLwUlE\",\"lastName\":\"UmLwUlE\",\"username\":\"UmLwUlE\",\"id\":\"67400138b0df5c00019b39a3\",\"_links\":{\"addresses\":{
  03:58:57.029 [front-end] Received response: "{\"firstName\":\"vcQSwENKufOmzWa\",\"lastName\":\"vcQSwENKufOmzWa\",\"username\":\"vcQSwENKufOmzWa\",\"id\":\"67400171b0df5c00019b3a4c\",\"_
  03:59:02.953 [front-end] Posting Customer: {"username":"OYuSlBrwqYvpQ","password":"INdYWH","email":"OYuSlBrwqYvpQ@gmail.com","firstName":"OYuSlBrwqYvpQ","lastName":"OYuSlBrwqYvpQ"}
  03:59:04.875 [front-end] Posting Customer: {"username":"BVVIMHORoQdqN","password":"AwkLxsK","email":"BVVIMHORoQdqN@gmail.com","firstName":"BVVIMHORoQdqN","lastName":"BVVIMHORoQdqN"}
  03:59:08.400 [front-end] Posting Customer: {"username":"XKNFApPwjrdxbW","password":"wCUpAgL","email":"XKNFApPwjrdxbW@gmail.com","firstName":"XKNFApPwjrdxbW","lastName":"XKNFApPwjrdxbW"}
  03:59:11.706 [front-end] Posting Customer: {"username":"NzwEZSgA","password":"KISqmphzg","email":"NzwEZSgA@gmail.com","firstName":"NzwEZSgA","lastName":"NzwEZSgA"}

## p0274
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:23.041Z
```
{"timestamp":1732242503041863700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"set cookie673fec41b0df5c00019af98d"}
```
Same service, the 2 minutes before (oldest first):
  02:28:22.400 [front-end] Order response: {"timestamp":1732242502396,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:22.400 [front-end] POST /addresses 200 - ms - -
  02:28:22.401 [front-end] POST /orders 500 - ms - -
  02:28:22.405 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec3eb0df5c00019af985"}
  02:28:22.413 [front-end] POST /cards 200 - ms - -
  02:28:22.419 [front-end] GET /catalogue 200 - ms - -
  02:28:22.461 [front-end] Attempting to delete cart for user: 673fec3eb0df5c00019af985
  02:28:22.516 [front-end] Posting Customer: {"username":"FUekuDogRI","password":"vzTsDBt","email":"FUekuDogRI@gmail.com","firstName":"FUekuDogRI","lastName":"FUekuDogRI"}
  02:28:22.521 [front-end] { id: '673fec46b0df5c00019af994' }  (×2)
  02:28:22.521 [front-end] 673fec46b0df5c00019af994  (×2)
  02:28:22.521 [front-end] Merging carts for customer id: 673fec46b0df5c00019af994 and session id: KkZrOzNoqKgxA2YV9xemsYfowSvZTYBW  (×2)
  02:28:22.550 [front-end] Carts merged.  (×2)
  02:28:22.550 [front-end] set cookie673fec41b0df5c00019af98c
  02:28:22.550 [front-end] Sent cookies.
  02:28:22.552 [front-end] POST /register 200 4675.058 ms - 33
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×48)
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -  (×48)
  02:28:03.203 [front-end] [ undefined, undefined ]  (×48)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×4)
  02:28:07.445 [orders] 2024-11-22 02:28:07.445 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
  02:28:10.277 [front-end] Posting Customer: {"username":"opFqwUnVow","password":"habyXFSF","email":"opFqwUnVow@gmail.com","firstName":"opFqwUnVow","lastName":"opFqwUnVow"}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
  02:28:23.301 [front-end] Received response: "{\"firstName\":\"HFHBXn\",\"lastName\":\"HFHBXn\",\"username\":\"HFHBXn\",\"id\":\"673fec34b0df5c00019af967\",\"_links\":{\"addresses\":{\"h
  02:28:24.999 [rabbitmq] 
  02:28:25.743 [carts] 2024-11-22 02:28:25.743 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×14)
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39d0","customerId":"673fec31b0df5c00019af95b","customer":{"id":null,"firstName":"bCCZHBaYc","lastName":"bCCZHBaYc","u
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×60)
  02:28:37.548 [user] ts=2024-11-22T02:28:37.548591Z caller=middlewares.go:46 method=Register username=OeZpiPZUn email=OeZpiPZUn@gmail.com took=1.009704ms
  02:28:40.321 [front-end] Order response: {"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR","lastName":"nbZCdAQyR","u
  02:28:42.162 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732242522152,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×2)
  02:28:44.338 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec5cd94b9000069b39e2","customerId":"673fec3ab0df5c00019af974","customer":{"id":null,"firstName":"opFqwUnVow"
  02:28:45.405 [front-end] Posting Customer: {"username":"crSMtAKNWrXaJJx","password":"TlwWXSanSW","email":"crSMtAKNWrXaJJx@gmail.com","firstName":"crSMtAKNWrXaJJx","lastName":"crSMtAKNWr
  02:28:47.575 [front-end] Received response: "{\"firstName\":\"QGHrdp\",\"lastName\":\"QGHrdp\",\"username\":\"QGHrdp\",\"id\":\"673fec41b0df5c00019af98c\",\"_links\":{\"addresses\":{\"h
  02:28:50.618 [front-end] Received response: "{\"firstName\":\"XsZRA\",\"lastName\":\"XsZRA\",\"username\":\"XsZRA\",\"id\":\"673fec4ab0df5c00019af99b\",\"_links\":{\"addresses\":{\"href

## p0152
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T05:42:54.372Z
```
{"timestamp":1731908574372134400,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-m2ddm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b"}
```
Same service, the 2 minutes before (oldest first):
  05:42:50.692 [cartservice] GetCartAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0  (×17)
  05:42:50.722 [cartservice] AddItemAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0, productId=1YMWWN1N4O, quantity=6  (×3)
All services, 30 seconds either side (sampled):
  05:42:25.231 [frontend] request started  (×325)
  05:42:25.239 [cartservice] GetCartAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0  (×267)
  05:42:25.253 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '0PUK6V6EV0', '9SIQT8TOJO', 'LS4PSXUNUM', '66VCHSJNUP']  (×235)
  05:42:25.265 [shippingservice] [GetQuote] received request  (×85)
  05:42:26.567 [adservice] received ad request (context_words=[decor, home])  (×20)
  05:42:27.570 [frontend] home  (×29)
  05:42:27.677 [adservice] received ad request (context_words=[hair, beauty])  (×19)
  05:42:28.182 [frontend] placing order  (×9)
  05:42:28.209 [paymentservice] Transaction processed: visa ending 7677 Amount: USD296.870000000  (×2)
  05:42:28.213 [shippingservice] [ShipOrder] completed request  (×9)
  05:42:28.224 [checkoutservice] order confirmation email sent to "andrew84@example.org"
  05:42:54.428 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', '66VCHSJNUP', '6E92ZMYYFZ', '1YMWWN1N4O']  (×3)
  05:42:54.515 [paymentservice] Transaction processed: visa ending 5320 Amount: EUR1328.279522350  (×2)
  05:42:59.266 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', 'L9ECAV7KIM', '0PUK6V6EV0']
  05:43:00.036 [paymentservice] Transaction processed: visa ending 1697 Amount: TRY4782.737868224  (×3)
  05:43:03.512 [emailservice] A request to send order confirmation email to sanderscorey@example.org has been received.
  05:43:06.550 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"1174","nanos":629288797},"credit_card":{"credit_card_number":"4931699243930
  05:43:06.565 [checkoutservice] order confirmation email sent to "clayruth@example.net"
  05:43:09.195 [paymentservice] Transaction processed: visa ending 2776 Amount: JPY84221.197701114
  05:43:10.051 [emailservice] A request to send order confirmation email to schroederlucas@example.com has been received.
  05:43:10.551 [checkoutservice] order confirmation email sent to "stephenjackson@example.net"
  05:43:23.822 [cartservice] info: Microsoft.Hosting.Lifetime[0] Application is shutting down...

## p0572
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:01.656Z
```
{"timestamp":1733596261656649000,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:01.655  INFO 1 --- [           main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped \"{[/error]}\" onto public org.springframework.http.ResponseEntity<java.util.Map<java.lang.String, java.lang.Object>> org.springframework.boot.autoconfigure.web.BasicErrorController.error(javax.servlet.http.HttpServletRequest)"}
```
Same service, the 2 minutes before (oldest first):
  18:30:49.764 [ts-auth-service] 2024-12-07 18:30:49.764 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'webRequestLoggingFilter' to: [/*]  (×2)
  18:30:49.764 [ts-auth-service] 2024-12-07 18:30:49.764 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  18:30:51.479 [ts-auth-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  18:30:51.661 [ts-auth-service] 2024-12-07 18:30:51.661 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClust
  18:30:51.661 [ts-auth-service] 2024-12-07 18:30:51.661 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-auth-mongo:27017 to client view of cluster
  18:30:52.554 [ts-auth-service] 2024-12-07 18:30:52.553 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:20}] to ts-auth-m
  18:30:52.557 [ts-auth-service] 2024-12-07 18:30:52.557 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip
  18:30:52.562 [ts-auth-service] 2024-12-07 18:30:52.561 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  18:30:53.685 [ts-auth-service] 2024-12-07 18:30:53.678 INFO 1 --- [ main] auth.AuthApplication : Starting AuthApplication v1.0 on ts-auth-service-75dfb9459b-ctqkr with PID 1 (/app/ts-auth-ser
  18:30:53.685 [ts-auth-service] 2024-12-07 18:30:53.685 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default
  18:30:54.486 [ts-auth-service] 2024-12-07 18:30:54.485 INFO 1 --- [ main] ationConfigEmbeddedWebApplicationContext : Refreshing org.springframework.boot.context.embedded.AnnotationConfigEmbed
  18:31:00.863 [ts-auth-service] 2024-12-07 18:31:00.862 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  18:31:01.562 [ts-auth-service] 2024-12-07 18:31:01.562 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/hello],methods=[GET]}" onto public java.lang.Objec
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users],methods=[GET]}" onto public org.springframework.h
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/{userId}],methods=[DELETE]}" onto public org.sprin
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  18:31:01.654 [ts-auth-service] 2024-12-07 18:31:01.653 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth/hello],methods=[GET]}" onto public java.lang.String
  18:31:01.654 [ts-auth-service] 2024-12-07 18:31:01.653 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth],methods=[POST]}" onto public org.springframework.h
  18:31:01.656 [ts-auth-service] 2024-12-07 18:31:01.655 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
All services, 30 seconds either side (sampled):
  18:30:31.939 [ts-order-service] 2024-12-07 18:30:31.939 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 
  18:30:37.714 [ts-travel2-service] 2024-12-07 18:30:37.713 INFO 1 --- [io-16346-exec-5] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×11)
  18:30:37.795 [ts-basic-service] 2024-12-07 18:30:37.795 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×19)
  18:30:37.825 [ts-order-other-service] 2024-12-07 18:30:37.825 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×10)
  18:30:37.914 [ts-seat-service] 2024-12-07 18:30:37.913 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×35)
  18:30:39.463 [ts-auth-service] 2024-12-07 18:30:39.463 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def  (×2)
  18:30:40.512 [ts-order-other-service] 2024-12-07 18:30:40.512 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 24  (×3)
  18:30:41.360 [ts-auth-service] 2024-12-07 18:30:41.359 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.access.expression.method.DefaultMethodS  (×2)
  18:30:42.209 [ts-order-other-mongo] {"t":{"$date":"2024-12-07T18:30:42.208+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359624
  18:30:42.430 [ts-travel-service] 2024-12-07 18:30:42.430 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×11)
  18:30:47.127 [ts-basic-service] 2024-12-07 18:30:47.127 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×12)
  18:30:47.200 [ts-basic-service] 2024-12-07 18:30:47.199 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×3)
  18:30:47.286 [ts-travel-service] 2024-12-07 18:30:47.286 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  18:30:49.754 [ts-auth-service] 2024-12-07 18:30:49.754 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricsFilter' to: [/*]  (×8)
  18:30:52.562 [ts-auth-service] 2024-12-07 18:30:52.561 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  18:30:57.130 [ts-seat-service] 2024-12-07 18:30:57.129 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  18:31:00.863 [ts-auth-service] 2024-12-07 18:31:00.862 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  18:31:02.163 [ts-auth-service] 2024-12-07 18:31:02.162 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class org.springfra
  18:31:03.869 [ts-auth-service] 2024-12-07 18:31:03.869 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/auditevents || /auditevents.json],methods=[GET],produces=[applicati
  18:31:04.078 [ts-order-service] 2024-12-07 18:31:04.078 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160, 
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.467 INFO 1 --- [ main] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 1 subscriber(s).
  18:31:11.697 [ts-travel-service] 2024-12-07 18:31:11.697 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234  (×5)
  18:31:12.245 [ts-basic-service] 2024-12-07 18:31:12.245 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2
  18:31:19.258 [ts-auth-service] 2024-12-07 18:31:19.257 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×7)
  18:31:20.904 [ts-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×2)
  18:31:28.040 [ts-auth-service] 2024-12-07 18:31:28.039 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  18:31:29.893 [ts-station-mongo] {"t":{"$date":"2024-12-07T18:31:29.893+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:31.064 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null

## p0001
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-13T00:35:40.354Z
```
{"service":"webservice2","message":"2021-08-13 00:35:40,354 | ERROR | 0.0.0.3 | webservice2 | web_helper.py -> web_service_resource -> 200 | 18304b65128637b3 | an error occurred in the downstream service"}
```
Same service, the 2 minutes before (oldest first):
  00:35:37.711 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '5308e59a-fb8b-11eb-a9ef-0242ac110004', 'value': '', 'ex': 10}  (×3)
  00:35:37.767 [webservice2] INFO uuid: 5308e59a-fb8b-11eb-a9ef-0242ac110004 write redis successfully  (×3)
  00:35:37.873 [webservice2] INFO complete information: {'uuid': '5308e59a-fb8b-11eb-a9ef-0242ac110004', 'user_id': 'QlZMgGXD'}  (×3)
  00:35:37.882 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×3)
  00:35:37.883 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  00:35:38.622 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  00:35:38.622 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  00:35:39.485 [webservice2] ERROR an error occurred in the downstream service
All services, 30 seconds either side (sampled):
  00:35:10.390 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  00:35:10.589 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  00:35:10.724 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×38)
  00:35:10.913 [dbservice2] INFO 429a49f6-fb8b-11eb-8588-0242ac110004-xXiaofbu-2Yl&jd#+ApZV token generate success token=MTYyODc4NjExMC45MTM0MjkzOjQyOWE0OWY2LWZiOGItMTFlYi04NTg4LTAyNDJhYzE
  00:35:11.729 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×41)
  00:35:12.076 [redisservice1] INFO redis读取信息成功, status_code: 200  (×37)
  00:35:14.390 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×40)
  00:35:14.764 [mobservice2] INFO info 45228990-fb8b-11eb-82db-0242ac110003:spFyrBHI write success
  00:35:16.212 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '46167654-fb8b-11eb-813f-0242ac110003'}  (×44)
  00:35:18.184 [mobservice1] INFO info 472b1694-fb8b-11eb-a06e-0242ac110004:YCHLRfzD write success  (×2)
  00:35:20.622 [mobservice2] INFO info 489e5fae-fb8b-11eb-9495-0242ac110003:rEZWRTXD write success
  00:35:22.692 [dbservice2] INFO 49a10dca-fb8b-11eb-9a49-0242ac110004-HaBrICUJ-eudL_5)GUA!} token generate success token=MTYyODc4NjEyMi42OTIxMzY1OjQ5YTEwZGNhLWZiOGItMTFlYi05YTQ5LTAyNDJhYzE
  00:35:24.385 [webservice2] ERROR an error occurred in the downstream service  (×5)
  00:35:26.905 [dbservice1] INFO 4c05f706-fb8b-11eb-8c0f-0242ac110003-UeHdKlGN-ZHxuf4*oXj?< token generate success token=MTYyODc4NjEyNi45MDQ5OTc6NGMwNWY3MDYtZmI4Yi0xMWViLThjMGYtMDI0MmFjMTE
  00:35:28.992 [mobservice2] INFO info 4da0309a-fb8b-11eb-99db-0242ac110003:jnuiIECt write success
  00:35:30.996 [dbservice1] INFO 4e98b35a-fb8b-11eb-9f89-0242ac110003-XhnipBWc-?SvP1{}M+_9= token generate success token=MTYyODc4NjEzMC45OTY0MDU6NGU5OGIzNWEtZmI4Yi0xMWViLTlmODktMDI0MmFjMTE
  00:35:33.127 [mobservice2] INFO info 501abcd2-fb8b-11eb-aafc-0242ac110004:JkvHOUxm write success
  00:35:35.449 [dbservice2] INFO 514a2c6e-fb8b-11eb-89b7-0242ac110003-ropVRsqh-hActS-H+f9_x token generate success token=MTYyODc4NjEzNS40NDkwMjIzOjUxNGEyYzZlLWZiOGItMTFlYi04OWI3LTAyNDJhYzE  (×3)
  00:35:37.872 [mobservice2] INFO info 52e84a74-fb8b-11eb-a3bb-0242ac110003:yeMqQbFt write success
  00:35:40.738 [mobservice1] INFO info 549cec8a-fb8b-11eb-8031-0242ac110004:pxXmtnLl write success
  00:35:43.006 [dbservice2] INFO 55b51732-fb8b-11eb-96ac-0242ac110004-tbBdwIhl-z<.1sUKo@xvu token generate success token=MTYyODc4NjE0My4wMDYyMzI6NTViNTE3MzItZmI4Yi0xMWViLTk2YWMtMDI0MmFjMTE
  00:35:45.187 [mobservice1] INFO info 5749b788-fb8b-11eb-a23f-0242ac110003:BeqngSzw write success
  00:35:47.729 [mobservice1] INFO info 58cae190-fb8b-11eb-895c-0242ac110004:MDLxpWSd write success
  00:35:49.943 [dbservice1] INFO 59db7a4a-fb8b-11eb-8e29-0242ac110003-bZJaiYAt-*S+vbf5AyB2- token generate success token=MTYyODc4NjE0OS45NDM0MjM3OjU5ZGI3YTRhLWZiOGItMTFlYi04ZTI5LTAyNDJhYzE
  00:35:52.676 [dbservice1] INFO 5b935f06-fb8b-11eb-bb64-0242ac110004-rXbZtUoM-Rw%Nn/U}9<h. token generate success token=MTYyODc4NjE1Mi42NzYxODU0OjViOTM1ZjA2LWZiOGItMTFlYi1iYjY0LTAyNDJhYzE
  00:35:55.172 [mobservice2] INFO info 5d37da44-fb8b-11eb-9042-0242ac110004:rwmAxZUJ write success
  00:35:57.154 [dbservice1] INFO 5e388de4-fb8b-11eb-be2f-0242ac110003-sCbMprDF-1e*T8(m.o!u/ token generate success token=MTYyODc4NjE1Ny4xNTQ1MTI6NWUzODhkZTQtZmI4Yi0xMWViLWJlMmYtMDI0MmFjMTE  (×2)
  00:35:59.445 [mobservice1] INFO info 5fcb813e-fb8b-11eb-bfcf-0242ac110003:PYTAOBbU write success
  00:36:01.624 [dbservice2] INFO 60c53206-fb8b-11eb-966f-0242ac110003-FMChXPGp-1ZD.v{4)u6AM token generate success token=MTYyODc4NjE2MS42MjM5MTM6NjBjNTMyMDYtZmI4Yi0xMWViLTk2NmYtMDI0MmFjMTE
  00:36:05.631 [mobservice1] INFO info 637a7790-fb8b-11eb-ab3f-0242ac110003:jFTtOqPD write success

## p0128
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:18:26.964Z
```
{"timestamp":1731907106964095500,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request error"}
```
Same service, the 2 minutes before (oldest first):
  05:18:26.721 [frontend] request started  (×5)
  05:18:26.721 [frontend] home
  05:18:26.769 [frontend] ENV_PLATFORM is: aws
  05:18:26.769 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14  (×3)
  05:18:26.770 [frontend] failed to retrieve ads  (×2)
  05:18:26.770 [frontend] request complete  (×4)
  05:18:26.793 [frontend] serving product page
  05:18:26.826 [frontend] adding to cart
  05:18:26.839 [frontend] view user cart
  05:18:26.910 [frontend] placing order
All services, 30 seconds either side (sampled):
  05:17:58.058 [frontend] request started  (×292)
  05:17:58.067 [cartservice] GetCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×246)
  05:17:58.087 [frontend] failed to retrieve ads  (×178)
  05:17:58.090 [frontend] adding to cart  (×27)
  05:17:58.127 [shippingservice] [GetQuote] received request  (×68)
  05:17:58.812 [frontend] ENV_PLATFORM is: aws  (×34)
  05:18:02.258 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="TRY"  (×3)
  05:18:02.287 [checkoutservice] payment went through (transaction_id: f6b68b4a-60c3-43ba-a064-a6b85fb7ff1c)  (×7)
  05:18:02.293 [cartservice] EmptyCartAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4  (×7)
  05:18:02.299 [frontend] order placed  (×7)
  05:18:18.646 [adservice] AdService starting.  (×2)
  05:18:18.741 [adservice] Tracing enabled - Stackdriver exporter initialized.  (×2)
  05:18:20.440 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  05:18:22.550 [paymentservice] Transaction processed: visa ending 1783 Amount: GBP1521.300176901
  05:18:25.894 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '0PUK6V6EV0', '6E92ZMYYFZ', '1YMWWN1N4O']  (×6)
  05:18:25.981 [paymentservice] Transaction processed: visa ending 9193 Amount: JPY106183.826626688  (×3)
  05:18:26.910 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13  (×2)
  05:18:26.960 [paymentservice] }
  05:18:32.581 [paymentservice] Transaction processed: visa ending 3587 Amount: EUR1094.975674484
  05:18:35.671 [emailservice] A request to send order confirmation email to daniel24@example.org has been received.
  05:18:45.411 [checkoutservice] order confirmation email sent to "fknox@example.org"

## p0431
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-23T08:05:43.084Z
```
{"timestamp":1732349143084867800,"container_name":"orders","pod_name":"orders-7fff6698cb-rlq5k","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-23 08:05:43.084  INFO [orders,,,] 8 --- [           main] o.s.s.c.ThreadPoolTaskScheduler          : Initializing ExecutorService "}
```
Same service, the 2 minutes before (oldest first):
  08:05:39.388 [orders] 2024-11-23 08:05:39.388 INFO [orders,,,] 8 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionH
  08:05:39.388 [orders] 2024-11-23 08:05:39.388 INFO [orders,,,] 8 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframew
  08:05:41.185 [orders] 2024-11-23 08:05:41.185 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public 
  08:05:41.187 [orders] 2024-11-23 08:05:41.187 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application
  08:05:41.188 [orders] 2024-11-23 08:05:41.188 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public 
  08:05:41.188 [orders] 2024-11-23 08:05:41.188 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applicati
  08:05:41.189 [orders] 2024-11-23 08:05:41.189 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application
  08:05:41.189 [orders] 2024-11-23 08:05:41.189 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=
  08:05:41.190 [orders] 2024-11-23 08:05:41.190 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applicati
  08:05:41.190 [orders] 2024-11-23 08:05:41.190 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.
  08:05:41.190 [orders] 2024-11-23 08:05:41.190 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<j
  08:05:41.191 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java
  08:05:41.191 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto
  08:05:41.192 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]
  08:05:41.192 [orders] 2024-11-23 08:05:41.192 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json
  08:05:41.192 [orders] 2024-11-23 08:05:41.192 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/j
  08:05:41.193 [orders] 2024-11-23 08:05:41.193 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[app
  08:05:41.194 [orders] 2024-11-23 08:05:41.193 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public ja
  08:05:41.195 [orders] 2024-11-23 08:05:41.195 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[app
  08:05:41.198 [orders] 2024-11-23 08:05:41.198 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produce
All services, 30 seconds either side (sampled):
  08:05:16.044 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418cb4a437380001deebd3"}  (×58)
  08:05:16.923 [user] ts=2024-11-23T08:05:16.922581748Z caller=middlewares.go:75 method=GetUsers id=67418caaa437380001deebb5 result=1 took=2.939559ms  (×203)
  08:05:17.299 [front-end] Sent cookies.  (×60)
  08:05:18.714 [carts] 2024-11-23 08:05:18.712 INFO [carts,,,] 7 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  08:05:20.221 [queue-master] 2024-11-23 08:05:20.221 INFO 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  08:05:22.874 [front-end] Posting Customer: {"username":"kvjRZNQgiVnmkal","password":"VhVyZOrv","email":"kvjRZNQgiVnmkal@gmail.com","firstName":"kvjRZNQgiVnmkal","lastName":"kvjRZNQgiVnm
  08:05:26.499 [queue-master] 2024-11-23 08:05:26.499 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+json || applica
  08:05:26.609 [queue-master] 2024-11-23 08:05:26.609 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[GET],produces
  08:05:27.703 [queue-master] 2024-11-23 08:05:27.703 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]}" onto pub
  08:05:27.911 [carts] 2024-11-23 08:05:27.911 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'metricsServlet' to [/metrics]
  08:05:29.553 [user] ts=2024-11-23T08:05:29.553028599Z caller=middlewares.go:46 method=Register username=yYxwhLWv email=yYxwhLWv@gmail.com took=1.895508ms
  08:05:31.631 [carts-db] {"t":{"$date":"2024-11-23T08:05:31.631+00:00"},"s":"W", "c":"COMMAND", "id":5578800, "ctx":"conn1","msg":"Deprecated operation requested. The client driver may 
  08:05:32.893 [orders] 2024-11-23 08:05:32.892 INFO [orders,,,] 8 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionH  (×2)
  08:05:36.422 [user] ts=2024-11-23T08:05:36.422193492Z caller=middlewares.go:46 method=Register username=pSeQWyL email=pSeQWyL@gmail.com took=2.850057ms
  08:05:39.188 [orders] 2024-11-23 08:05:39.188 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/ha
  08:05:39.196 [orders] 2024-11-23 08:05:39.196 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applica
  08:05:41.187 [orders] 2024-11-23 08:05:41.187 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application
  08:05:41.706 [front-end] Posting Customer: {"username":"VGvhEBXruush","password":"TpFMwWsQ","email":"VGvhEBXruush@gmail.com","firstName":"VGvhEBXruush","lastName":"VGvhEBXruush"}
  08:05:44.691 [orders] 2024-11-23 08:05:44.690 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX serve
  08:05:47.988 [orders] 2024-11-23 08:05:47.988 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comple
  08:05:49.885 [orders] 2024-11-23 08:05:49.884 INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repos  (×24)
  08:05:54.265 [front-end] Posting Customer: {"username":"imiXj","password":"mbjOThU","email":"imiXj@gmail.com","firstName":"imiXj","lastName":"imiXj"}
  08:05:55.023 [front-end] Posting Customer: {"username":"brTpfrzj","password":"CqouP","email":"brTpfrzj@gmail.com","firstName":"brTpfrzj","lastName":"brTpfrzj"}
  08:05:58.911 [front-end] Received response: "{\"firstName\":\"eqACgmjO\",\"lastName\":\"eqACgmjO\",\"username\":\"eqACgmjO\",\"id\":\"67418cd4a437380001deec3c\",\"_links\":{\"addresses\
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  08:06:04.990 [front-end] Posting Customer: {"username":"VnaknAEtTvwY","password":"DQLtg","email":"VnaknAEtTvwY@gmail.com","firstName":"VnaknAEtTvwY","lastName":"VnaknAEtTvwY"}
  08:06:07.003 [shipping] 2024-11-23 08:06:07.003 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[applicat
  08:06:07.100 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],pro
  08:06:10.340 [front-end] Posting Customer: {"username":"djVRqry","password":"CJLHmVgJ","email":"djVRqry@gmail.com","firstName":"djVRqry","lastName":"djVRqry"}

## p0344
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:23:17.534Z
```
{"timestamp":1732245797534744800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"GET /catalogue 200 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  03:23:17.155 [front-end] Carts merged.  (×2)
  03:23:17.155 [front-end] set cookie673ff925b0df5c00019b20f5  (×2)
  03:23:17.155 [front-end] Sent cookies.  (×2)
  03:23:17.157 [front-end] POST /register 200 28.534 ms - 33  (×2)
  03:23:17.162 [front-end] POST /cards 200 - ms - -
  03:23:17.212 [front-end] Attempting to delete cart for user: 673ff91cb0df5c00019b20dd
  03:23:17.234 [front-end] User cart deleted with status: 202
  03:23:17.236 [front-end] DELETE /cart 202 - ms - -
  03:23:17.242 [front-end] Attempting to add to cart: {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","quantity":1}
  03:23:17.250 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/
  03:23:17.250 [front-end] POST to carts: http://carts/carts/673ff91cb0df5c00019b20dd/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}
  03:23:17.318 [front-end] POST /cart 201 - ms - -
  03:23:17.507 [front-end] Posting Customer: {"username":"xjpAW","password":"eosjZF","email":"xjpAW@gmail.com","firstName":"xjpAW","lastName":"xjpAW"}
  03:23:17.511 [front-end] { id: '673ff925b0df5c00019b20f8' }
  03:23:17.511 [front-end] 673ff925b0df5c00019b20f8
  03:23:17.511 [front-end] Merging carts for customer id: 673ff925b0df5c00019b20f8 and session id: irFyIK4QMbggxgJuip2BjfVckHvysNYh
All services, 30 seconds either side (sampled):
  03:22:47.881 [front-end] Request received with body: {}  (×62)
  03:22:47.912 [orders] 2024-11-22 03:22:47.911 INFO [orders,3a169c37703494a4,60446c00307f7c45,false] 6 --- [-nio-80-exec-14] w.w.s.o.controllers.OrdersController : Received payment re  (×25)
  03:22:48.131 [front-end] GET /catalogue 200 - ms - -  (×65)
  03:22:49.230 [front-end] POST /register 200 29.539 ms - 33  (×62)
  03:22:50.315 [front-end] Posting Customer: {"username":"przOfIDu","password":"HnyeuPxtR","email":"przOfIDu@gmail.com","firstName":"przOfIDu","lastName":"przOfIDu"}
  03:22:50.997 [front-end] Attempting to delete cart for user: 673ff900b0df5c00019b208c  (×61)
  03:22:51.688 [front-end] Order response: {"id":"673ff90bd94b9000069b43eb","customerId":"673ff8f7b0df5c00019b2064","customer":{"id":null,"firstName":"UKxIYzJzVOb","lastName":"UKxIYzJzVOb
  03:22:52.900 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff90cd94b9000069b43ec","customerId":"673ff8f7b0df5c00019b2065","customer":{"id":null,"firstName":"ucqXq","las
  03:22:54.181 [front-end] Received response: "{\"firstName\":\"rcfZFElxmjN\",\"lastName\":\"rcfZFElxmjN\",\"username\":\"rcfZFElxmjN\",\"id\":\"673ff8fbb0df5c00019b2079\",\"_links\":{\"a
  03:22:57.096 [user] ts=2024-11-22T03:22:57.095434774Z caller=middlewares.go:157 method=Health result=2 took=2.812932ms  (×5)
  03:22:58.556 [front-end] Order response: {"id":"673ff912d94b9000069b43f2","customerId":"673ff8fdb0df5c00019b207c","customer":{"id":null,"firstName":"AictmYxCsfmixW","lastName":"AictmYxC
  03:23:01.777 [catalogue] ts=2024-11-22T03:23:01Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=5.11525m
  03:23:05.110 [front-end] Received response: "{\"firstName\":\"tKspRd\",\"lastName\":\"tKspRd\",\"username\":\"tKspRd\",\"id\":\"673ff903b0df5c00019b2095\",\"_links\":{\"addresses\":{\"h
  03:23:07.541 [front-end] Posting Customer: {"username":"DXTqACLHRps","password":"vHNWPh","email":"DXTqACLHRps@gmail.com","firstName":"DXTqACLHRps","lastName":"DXTqACLHRps"}
  03:23:09.408 [front-end] Received response: "{\"firstName\":\"IpgOJYOKfEnEyD\",\"lastName\":\"IpgOJYOKfEnEyD\",\"username\":\"IpgOJYOKfEnEyD\",\"id\":\"673ff909b0df5c00019b209c\",\"_lin
  03:23:15.912 [front-end] Received response: "{\"firstName\":\"DVHpwX\",\"lastName\":\"DVHpwX\",\"username\":\"DVHpwX\",\"id\":\"673ff916b0df5c00019b20c2\",\"_links\":{\"addresses\":{\"h
  03:23:17.510 [user] ts=2024-11-22T03:23:17.51010195Z caller=middlewares.go:46 method=Register username=xjpAW email=xjpAW@gmail.com took=1.021501ms
  03:23:19.866 [front-end] Posting Customer: {"username":"ACgihpwMZcIfvmH","password":"YdCRD","email":"ACgihpwMZcIfvmH@gmail.com","firstName":"ACgihpwMZcIfvmH","lastName":"ACgihpwMZcIfvmH
  03:23:21.352 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff929d94b9000069b4402","customerId":"673ff915b0df5c00019b20bb","customer":{"id":null,"firstName":"bawuakYcPCO
  03:23:22.359 [front-end] Order response: {"id":"673ff92ad94b9000069b4404","customerId":"673ff913b0df5c00019b20b4","customer":{"id":null,"firstName":"OfgNNALNbNsqRu","lastName":"OfgNNALN
  03:23:26.470 [front-end] Order response: {"id":"673ff92ed94b9000069b4407","customerId":"673ff91ab0df5c00019b20cb","customer":{"id":null,"firstName":"JOXFQoQEogFXS","lastName":"JOXFQoQEo
  03:23:29.023 [front-end] Posting Customer: {"username":"hijBZvCMa","password":"ENRYoe","email":"hijBZvCMa@gmail.com","firstName":"hijBZvCMa","lastName":"hijBZvCMa"}
  03:23:31.508 [front-end] Received response: "{\"firstName\":\"rsgdAOHbLvwK\",\"lastName\":\"rsgdAOHbLvwK\",\"username\":\"rsgdAOHbLvwK\",\"id\":\"673ff920b0df5c00019b20e5\",\"_links\":{
  03:23:35.378 [front-end] Order response: {"id":"673ff937d94b9000069b440d","customerId":"673ff91cb0df5c00019b20dd","customer":{"id":null,"firstName":"GMlUtKwjLFL","lastName":"GMlUtKwjLFL
  03:23:37.629 [front-end] Received response: "{\"firstName\":\"PstFcx\",\"lastName\":\"PstFcx\",\"username\":\"PstFcx\",\"id\":\"673ff928b0df5c00019b2108\",\"_links\":{\"addresses\":{\"h
  03:23:40.407 [front-end] Received response: "{\"firstName\":\"yRhrS\",\"lastName\":\"yRhrS\",\"username\":\"yRhrS\",\"id\":\"673ff928b0df5c00019b2105\",\"_links\":{\"addresses\":{\"href
  03:23:42.703 [front-end] Received response: "{\"firstName\":\"xjpAW\",\"lastName\":\"xjpAW\",\"username\":\"xjpAW\",\"id\":\"673ff925b0df5c00019b20f8\",\"_links\":{\"addresses\":{\"href
  03:23:44.843 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff940d94b9000069b441a","customerId":"673ff929b0df5c00019b210b","customer":{"id":null,"firstName":"dcNTmZnFsja

## p0265
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:15.906Z
```
{"timestamp":1732242495906764500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Merging carts for customer id: 673fec3fb0df5c00019af987 and session id: cO62M9UVCOuvJ1O5mBAsYIgXKpWqDQZY"}
```
Same service, the 2 minutes before (oldest first):
  02:28:14.337 [front-end] Carts merged.
  02:28:14.337 [front-end] set cookie673fec3eb0df5c00019af985
  02:28:14.337 [front-end] Sent cookies.
  02:28:14.339 [front-end] POST /register 200 27.005 ms - 33
  02:28:15.632 [front-end] GET /catalogue 200 - ms - -
  02:28:15.696 [front-end] Posting Customer: {"username":"NGQZYvsdKz","password":"rioCzg","email":"NGQZYvsdKz@gmail.com","firstName":"NGQZYvsdKz","lastName":"NGQZYvsdKz"}
  02:28:15.701 [front-end] { id: '673fec3fb0df5c00019af986' }  (×2)
  02:28:15.701 [front-end] 673fec3fb0df5c00019af986  (×2)
  02:28:15.701 [front-end] Merging carts for customer id: 673fec3fb0df5c00019af986 and session id: m7tqqWakHxD90sn69NbpFpdgCpaxFP3Y
  02:28:15.891 [front-end] Request received with body: {}
  02:28:15.896 [front-end] Received response: "{\"firstName\":\"rcABXsHV\",\"lastName\":\"rcABXsHV\",\"username\":\"rcABXsHV\",\"id\":\"673fec2ab0df5c00019af943\",\"_links\":{\"addresses\
  02:28:15.896 [front-end] GET Request to: http://user/customers/673fec2ab0df5c00019af943/addresses  (×2)
  02:28:15.903 [front-end] Posting Customer: {"username":"tWrduaLeWjJ","password":"FQckBqInY","email":"tWrduaLeWjJ@gmail.com","firstName":"tWrduaLeWjJ","lastName":"tWrduaLeWjJ"}
  02:28:15.905 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec2fb0df5c00019af958\",\"_links\":{\"
  02:28:15.905 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:15.905 [front-end] [ undefined, undefined ]
  02:28:15.905 [front-end] Posting Order: {"customer":"http://user/customers/673fec2ab0df5c00019af943","address":"http://user/addresses/673fec2fb0df5c00019af957","card":"http://user/cards
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×41)
  02:28:03.174 [front-end] User cart deleted with status: 503  (×41)
  02:28:03.202 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×42)
  02:28:03.249 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×17)
  02:28:03.410 [front-end] Carts merged.  (×39)
  02:28:04.973 [front-end] Posting Customer: {"username":"HFHBXn","password":"EOgUhihln","email":"HFHBXn@gmail.com","firstName":"HFHBXn","lastName":"HFHBXn"}
  02:28:05.351 [user] ts=2024-11-22T02:28:05.351787827Z caller=middlewares.go:46 method=Register username=vuOxCKL email=vuOxCKL@gmail.com took=4.581531ms
  02:28:08.095 [front-end] Received response: "{\"firstName\":\"RsyjMQXEZqDOIBa\",\"lastName\":\"RsyjMQXEZqDOIBa\",\"username\":\"RsyjMQXEZqDOIBa\",\"id\":\"673fec1eb0df5c00019af912\",\"_
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:15.136 [carts] 2024-11-22 02:28:15.041 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 160.989 seconds (JVM running for 167.0
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:22.317 [front-end] Received response: "{\"firstName\":\"JGQXvUjPbFrtK\",\"lastName\":\"JGQXvUjPbFrtK\",\"username\":\"JGQXvUjPbFrtK\",\"id\":\"673fec34b0df5c00019af964\",\"_links\
  02:28:23.143 [orders] 2024-11-22 02:28:23.143 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×9)
  02:28:24.588 [shipping] Adding shipment to queue...  (×24)
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:26.156 [front-end] POST /cart 201 - ms - -  (×26)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d8","customerId":"673fec2cb0df5c00019af949","customer":{"id":null,"firstName":"KoWsmDtUqsE
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:30.547 [front-end] Received response: "{\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\",\"username\":\"vvgsHcY\",\"id\":\"673fec35b0df5c00019af968\",\"_links\":{\"addresses\":{
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.645 [queue-master] 2024-11-22 02:28:32.645 INFO 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×15)
  02:28:37.005 [user] ts=2024-11-22T02:28:37.005380807Z caller=middlewares.go:46 method=Register username=XTqSaA email=XTqSaA@gmail.com took=624.562µs
  02:28:40.136 [front-end] Order response: {"id":"673fec58d94b9000069b39dc","customerId":"673fec41b0df5c00019af98b","customer":{"id":null,"firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe",
  02:28:41.723 [user] ts=2024-11-22T02:28:41.723279742Z caller=middlewares.go:46 method=Register username=yaELjpCD email=yaELjpCD@gmail.com took=1.302265ms
  02:28:43.812 [front-end] Order response: {"id":"673fec5bd94b9000069b39e0","customerId":"673fec47b0df5c00019af996","customer":{"id":null,"firstName":"bhZuEQ","lastName":"bhZuEQ","usernam
  02:28:45.163 [front-end] Received response: "{\"firstName\":\"oqYeDriHaX\",\"lastName\":\"oqYeDriHaX\",\"username\":\"oqYeDriHaX\",\"id\":\"673fec49b0df5c00019af999\",\"_links\":{\"addr

## p0579
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:18.553Z
```
{"timestamp":1733596278553610000,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:18.553  INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl       : LOGIN USER NEW:fdse_microservice __ 111111 __ null"}
```
Same service, the 2 minutes before (oldest first):
  18:31:09.181 [ts-auth-service] 2024-12-07 18:31:09.181 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact
  18:31:09.183 [ts-auth-service] 2024-12-07 18:31:09.183 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [java.util.Properties] is not e
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.466 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : Adding {logging-channel-adapter:_org.springframework.integration.errorLogger} as
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.467 INFO 1 --- [ main] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 1 subscriber(s).
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.467 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : started _org.springframework.integration.errorLogger
  18:31:09.955 [ts-auth-service] 2024-12-07 18:31:09.954 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 12340 (http)
  18:31:10.283 [ts-auth-service] 2024-12-07 18:31:10.283 INFO 1 --- [ main] org.mongodb.driver.connection : Opened connection [connectionId{localValue:2, serverValue:21}] to ts-auth-mongo:27017
  18:31:10.954 [ts-auth-service] 2024-12-07 18:31:10.953 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.907 seconds (JVM running for 71.147)
  18:31:13.283 [ts-auth-service] 2024-12-07 18:31:13.283 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 12340 (http)
  18:31:13.587 [ts-auth-service] 2024-12-07 18:31:13.586 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  18:31:13.587 [ts-auth-service] 2024-12-07 18:31:13.587 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43
  18:31:14.585 [ts-auth-service] 2024-12-07 18:31:14.585 INFO 1 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  18:31:14.585 [ts-auth-service] 2024-12-07 18:31:14.585 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 20107 ms
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  18:31:17.262 [ts-auth-service] 2024-12-07 18:31:17.262 INFO 1 --- [io-12340-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization completed in 100 m
  18:31:18.474 [ts-auth-service] 2024-12-07 18:31:18.474 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  18:31:18.474 [ts-auth-service] 2024-12-07 18:31:18.474 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×2)
All services, 30 seconds either side (sampled):
  18:30:49.008 [ts-admin-basic-info-service] 2024-12-07 18:30:49.007 INFO 1 --- [io-18767-exec-7] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×5)
  18:30:50.707 [ts-route-service] 2024-12-07 18:30:50.707 INFO 1 --- [io-11178-exec-6] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×92)
  18:30:50.758 [ts-price-service] 2024-12-07 18:30:50.757 INFO 1 --- [io-16579-exec-2] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×12)
  18:30:50.825 [ts-travel2-service] 2024-12-07 18:30:50.824 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×16)
  18:30:50.873 [ts-seat-service] 2024-12-07 18:30:50.873 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×25)
  18:30:52.263 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:30:52.262+00:00"},"s":"I", "c":"NETWORK", "id":51800, "ctx":"conn20","msg":"client metadata","attr":{"remote":"127.0.0.6:49147","cl  (×4)
  18:30:53.574 [ts-order-other-service] 2024-12-07 18:30:53.574 INFO 1 --- [io-12032-exec-4] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 24  (×7)
  18:30:57.097 [ts-seat-service] 2024-12-07 18:30:57.096 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  18:30:58.080 [ts-price-service] 2024-12-07 18:30:58.080 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×2)
  18:31:00.335 [ts-order-other-service] 2024-12-07 18:31:00.334 ERROR 1 --- [io-12032-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×4)
  18:31:01.656 [ts-auth-service] 2024-12-07 18:31:01.655 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  18:31:03.828 [ts-travel-service] 2024-12-07 18:31:03.828 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×25)
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  18:31:03.871 [ts-auth-service] 2024-12-07 18:31:03.871 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  18:31:03.909 [ts-travel-service] 2024-12-07 18:31:03.909 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×5)
  18:31:04.007 [ts-travel-service] 2024-12-07 18:31:04.006 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×10)
  18:31:05.567 [ts-auth-service] 2024-12-07 18:31:05.566 INFO 1 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in globalExceptionHandler
  18:31:08.782 [ts-auth-service] 2024-12-07 18:31:08.782 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  18:31:10.954 [ts-auth-service] 2024-12-07 18:31:10.953 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.907 seconds (JVM running for 71.147)
  18:31:11.909 [ts-basic-service] 2024-12-07 18:31:11.909 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f
  18:31:12.420 [ts-travel-service] 2024-12-07 18:31:12.420 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan
  18:31:18.474 [ts-auth-service] 2024-12-07 18:31:18.474 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×9)
  18:31:19.676 [ts-travel2-service] 2024-12-07 18:31:19.676 ERROR 1 --- [io-16346-exec-2] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×9)
  18:31:27.257 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:31:27.257+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.270 [ts-admin-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×5)
  18:31:29.947 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:31:29.947+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  18:31:38.105 [ts-admin-travel-service] 2024-12-07 18:31:38.104 ERROR 1 --- [o-16114-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt

## p0194
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:51:36.287Z
```
{"timestamp":1731912696287204000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  06:51:34.779 [frontend] request complete  (×6)
  06:51:34.783 [frontend] request started  (×6)
  06:51:34.783 [frontend] placing order
  06:51:34.871 [frontend] order placed
  06:51:34.879 [frontend] setting currency
  06:51:34.881 [frontend] home
  06:51:34.927 [frontend] ENV_PLATFORM is: aws
  06:51:35.523 [frontend] serving product page  (×3)
All services, 30 seconds either side (sampled):
  06:51:06.341 [currencyservice] conversion request successful  (×782)
  06:51:06.450 [frontend] request complete  (×343)
  06:51:06.456 [frontend] ENV_PLATFORM is: aws  (×35)
  06:51:06.557 [adservice] received ad request (context_words=[footwear])  (×20)
  06:51:06.730 [cartservice] AddItemAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03, productId=L9ECAV7KIM, quantity=9  (×38)
  06:51:06.762 [shippingservice] [GetQuote] completed request  (×94)
  06:51:10.622 [frontend] home  (×34)
  06:51:13.058 [redis] 1:M 18 Nov 2024 06:51:13.058 * Background saving started by pid 68
  06:51:13.159 [redis] 1:M 18 Nov 2024 06:51:13.159 * Background saving terminated with success
  06:51:16.512 [frontend] placing order  (×15)
  06:51:16.535 [paymentservice] Transaction processed: visa ending 1622 Amount: GBP64.601074745  (×3)
  06:51:16.539 [shippingservice] [ShipOrder] completed request  (×15)
  06:51:16.550 [checkoutservice] order confirmation email sent to "patriciapalmer@example.com"
  06:51:23.111 [checkoutservice] [PlaceOrder] user_id="5e004f2d-a61a-45b2-840d-6bfd47a2be43" user_currency="JPY"  (×2)
  06:51:23.152 [emailservice] A request to send order confirmation email to lindatownsend@example.com has been received.
  06:51:26.357 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="TRY"  (×5)
  06:51:26.414 [emailservice] A request to send order confirmation email to natasha78@example.net has been received.
  06:51:27.875 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"489","nanos":740000000},"credit_card":{"credit_card_number":"44608264192392  (×2)
  06:51:27.892 [checkoutservice] order confirmation email sent to "jamesfinley@example.com"
  06:51:30.873 [paymentservice] Transaction processed: visa ending 7502 Amount: CAD660.51835466  (×3)
  06:51:31.918 [emailservice] A request to send order confirmation email to nicholas06@example.org has been received.
  06:51:34.869 [emailservice] A request to send order confirmation email to jonathanbonilla@example.net has been received.
  06:51:40.010 [checkoutservice] order confirmation email sent to "aaron51@example.net"
  06:51:51.244 [emailservice] A request to send order confirmation email to vanessa27@example.net has been received.
  06:51:51.609 [checkoutservice] order confirmation email sent to "dianehicks@example.org"
  06:51:55.017 [emailservice] A request to send order confirmation email to mchan@example.com has been received.
  06:52:00.891 [checkoutservice] order confirmation email sent to "rebeccacolon@example.org"

## p0397
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:27.487Z
```
{"timestamp":1732247187487672300,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /orders 500 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  03:46:26.987 [front-end] Sent cookies.
  03:46:26.988 [front-end] POST /register 200 69.729 ms - 33
  03:46:26.994 [front-end] POST /cards 200 - ms - -
  03:46:27.039 [front-end] Attempting to delete cart for user: 673ffe88b0df5c00019b3174
  03:46:27.098 [front-end] User cart deleted with status: 503
  03:46:27.101 [front-end] DELETE /cart 503 - ms - -
  03:46:27.107 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  03:46:27.113 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  03:46:27.113 [front-end] POST to carts: http://carts/carts/673ffe88b0df5c00019b3174/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  03:46:27.170 [front-end] POST /cart 500 61.224 ms - 64
  03:46:27.454 [front-end] Request received with body: {}
  03:46:27.460 [front-end] Received response: "{\"firstName\":\"acXEVLvnjUxlkJf\",\"lastName\":\"acXEVLvnjUxlkJf\",\"username\":\"acXEVLvnjUxlkJf\",\"id\":\"673ffe79b0df5c00019b3143\",\"_
  03:46:27.460 [front-end] GET Request to: http://user/customers/673ffe79b0df5c00019b3143/addresses  (×2)
  03:46:27.466 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe83b0df5c00019b315d\",\"_links\":{\"
  03:46:27.466 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:46:27.466 [front-end] [ undefined, undefined ]
  03:46:27.466 [front-end] Posting Order: {"customer":"http://user/customers/673ffe79b0df5c00019b3143","address":"http://user/addresses/673ffe83b0df5c00019b315c","card":"http://user/cards
  03:46:27.485 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732247187482,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:46:27.485 [front-end] Order response: {"timestamp":1732247187482,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×27)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×45)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×60)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×48)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×48)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×46)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×46)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×46)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h
  03:46:57.285 [carts] 2024-11-22 03:46:57.285 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr

## p0706
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-14T00:37:08.503Z
```
{"service":"webservice1","message":"2021-08-14 00:37:08,503 | INFO | 0.0.0.1 | 172.17.0.3 | webservice1 | 225f6a185b3171c2 | call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  00:37:04.055 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  00:37:05.386 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  00:37:05.387 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×3)
  00:37:05.387 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'b1b4f100-fc54-11eb-b5f5-0242ac110003', 'value': '', 'ex': 10}  (×3)
  00:37:05.460 [webservice1] INFO uuid: b1b4f100-fc54-11eb-b5f5-0242ac110003 write redis successfully  (×3)
  00:37:05.565 [webservice1] INFO complete information: {'uuid': 'b1b4f100-fc54-11eb-b5f5-0242ac110003', 'user_id': 'KaeOhoMc'}  (×3)
  00:37:05.575 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×2)
All services, 30 seconds either side (sampled):
  00:36:38.519 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  00:36:38.832 [redisservice2] INFO redis write success  (×100)
  00:36:39.048 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×48)
  00:36:39.242 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×43)
  00:36:39.497 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  00:36:39.589 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×47)
  00:36:39.986 [logservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×50)
  00:36:40.783 [mobservice2] INFO info a2d47912-fc54-11eb-a65e-0242ac110004:PbuDYKEa write success
  00:36:42.531 [mobservice1] INFO info a3e0b3a2-fc54-11eb-afbb-0242ac110003:LCiNwseu write success
  00:36:44.916 [mobservice1] INFO info a54cd22a-fc54-11eb-b409-0242ac110004:HSRAIxlj write success  (×2)
  00:36:47.685 [dbservice1] INFO a6b76242-fc54-11eb-a927-0242ac110004-cSnIQPJM-f<2m{M+)*sSK token generate success token=MTYyODg3MjYwNy42ODQ5MjMyOmE2Yjc2MjQyLWZjNTQtMTFlYi1hOTI3LTAyNDJhYzE
  00:36:50.415 [dbservice1] INFO a8539f8a-fc54-11eb-9a51-0242ac110003-CAQfZdjo-Kb!NEVot&pm^ token generate success token=MTYyODg3MjYxMC40MTU0ODc4OmE4NTM5ZjhhLWZjNTQtMTFlYi05YTUxLTAyNDJhYzE  (×2)
  00:36:53.217 [mobservice2] INFO info aa44d822-fc54-11eb-90df-0242ac110004:TZitjmpu write success
  00:36:55.984 [mobservice1] INFO info abe68c16-fc54-11eb-9823-0242ac110003:PDUHwGKg write success
  00:36:58.523 [mobservice1] INFO info ad59e9ee-fc54-11eb-b5a3-0242ac110003:ucXDZIio write success
  00:37:01.095 [mobservice1] INFO info aef3f628-fc54-11eb-8b61-0242ac110004:ytsxAVue write success
  00:37:03.439 [mobservice1] INFO info b05c5816-fc54-11eb-8446-0242ac110003:wzQhcEjW write success
  00:37:06.173 [dbservice2] INFO b1b4f100-fc54-11eb-b5f5-0242ac110003-KaeOhoMc-C8w@bIBzX{A$ token generate success token=MTYyODg3MjYyNi4xNzMyMTc1OmIxYjRmMTAwLWZjNTQtMTFlYi1iNWY1LTAyNDJhYzE
  00:37:08.656 [dbservice2] INFO b3325356-fc54-11eb-80ca-0242ac110004-WILFvAUY-@gqs5xJrY<v) token generate success token=MTYyODg3MjYyOC42NTYwMDk6YjMzMjUzNTYtZmM1NC0xMWViLTgwY2EtMDI0MmFjMTE
  00:37:11.612 [mobservice2] INFO info b52d99f4-fc54-11eb-91a6-0242ac110003:LEFinroh write success
  00:37:14.042 [mobservice2] INFO info b6a93892-fc54-11eb-bd87-0242ac110004:pKxfZBio write success
  00:37:17.359 [mobservice2] INFO info b8a5b5a8-fc54-11eb-b784-0242ac110004:yQDVrgJw write success
  00:37:20.089 [dbservice1] INFO ba1ac266-fc54-11eb-9607-0242ac110003-FgWeZKzi-DO)LdaZhiTEI token generate success token=MTYyODg3MjY0MC4wODg3MDY6YmExYWMyNjYtZmM1NC0xMWViLTk2MDctMDI0MmFjMTE
  00:37:22.548 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  00:37:25.399 [dbservice2] INFO bd377c14-fc54-11eb-b3d0-0242ac110003-OBgRIvmU-{eaD^f2GlVBk token generate success token=MTYyODg3MjY0NS4zOTg2MjU2OmJkMzc3YzE0LWZjNTQtMTFlYi1iM2QwLTAyNDJhYzE
  00:37:28.440 [dbservice1] INFO bf127d04-fc54-11eb-8e31-0242ac110004-VxubFBRX-Qgr73J_$>S}{ token generate success token=MTYyODg3MjY0OC40Mzk5MTI2OmJmMTI3ZDA0LWZjNTQtMTFlYi04ZTMxLTAyNDJhYzE
  00:37:30.800 [dbservice2] INFO c06b5180-fc54-11eb-b063-0242ac110004-xgMQOjrh-{:H$4CY!l1#_ token generate success token=MTYyODg3MjY1MC43OTk4MDY0OmMwNmI1MTgwLWZjNTQtMTFlYi1iMDYzLTAyNDJhYzE
  00:37:33.293 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  00:37:36.247 [mobservice1] INFO info c3d85b60-fc54-11eb-8a3b-0242ac110003:gFNpOQjC write success

## p0683
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-12T00:56:03.078Z
```
{"service":"logservice1","message":"2021-08-12 00:56:03,078 | ERROR | 0.0.0.3 | logservice1 | login_helper.py -> login_query_methods_model -> 93 | cb7d86783e524f4f | get information failed, fail code: 400"}
```
Same service, the 2 minutes before (oldest first):
  00:55:58.474 [logservice1] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': 'fff0ef36-fac4-11eb-bb51-0242ac110003', 'user_id': 'vUOZQjfI'}  (×5)
  00:55:59.330 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×3)
  00:55:59.331 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×3)
  00:56:01.014 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  00:56:01.028 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  00:56:01.029 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '0186b308-fac5-11eb-907b-0242ac110004'}  (×2)
  00:56:01.088 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385
  00:56:01.089 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service
  00:56:03.077 [logservice1] ERROR uuid expired, invalid phone request
All services, 30 seconds either side (sampled):
  00:55:33.117 [webservice2] INFO complete information: {'uuid': 'f1097ab0-fac4-11eb-bd10-0242ac110004', 'user_id': 'NxPGARft'}  (×32)
  00:55:33.238 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'f1097ab0-fac4-11eb-bd10-0242ac110004', 'value': 'NxPGARft'}  (×38)
  00:55:33.382 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×24)
  00:55:33.453 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×35)
  00:55:33.789 [redisservice1] INFO redis write success  (×66)
  00:55:33.964 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'f18334d6-fac4-11eb-a201-0242ac110003'}  (×29)
  00:55:34.168 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×41)
  00:55:34.474 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×32)
  00:55:35.135 [redisservice2] INFO service accept, status_code: 200  (×35)
  00:55:36.872 [dbservice2] INFO f2f5d99a-fac4-11eb-bafe-0242ac110004-LcFMmKnX-_%6c#hHYeQa{ token generate success token=MTYyODcwMDkzNi44NzE2MjQyOmYyZjVkOTlhLWZhYzQtMTFlYi1iYWZlLTAyNDJhYzE
  00:55:38.891 [mobservice2] INFO info f45f4fc8-fac4-11eb-878a-0242ac110004:nqLzRCkG write success
  00:55:40.923 [dbservice2] INFO f5674772-fac4-11eb-beea-0242ac110003-AnasJGMP-Q?)$%dAI{qjZ token generate success token=MTYyODcwMDk0MC45MjI5NDE3OmY1Njc0NzcyLWZhYzQtMTFlYi1iZWVhLTAyNDJhYzE
  00:55:43.487 [mobservice1] INFO info f70cde48-fac4-11eb-93cd-0242ac110004:vLPzKelQ write success
  00:55:45.812 [dbservice2] INFO f8525184-fac4-11eb-8dc6-0242ac110003-BphUxVDk-F39R}YcGk_K? token generate success token=MTYyODcwMDk0NS44MTE1Nzg6Zjg1MjUxODQtZmFjNC0xMWViLThkYzYtMDI0MmFjMTE
  00:55:47.613 [webservice2] ERROR an error occurred in the downstream service  (×3)
  00:55:49.623 [mobservice2] INFO info fad0bf22-fac4-11eb-8872-0242ac110003:nfPDGSVr write success
  00:55:59.503 [dbservice2] INFO 006fd846-fac5-11eb-beb7-0242ac110004-VHLPfDSU-?%<=*FYN4E2+ token generate success token=MTYyODcwMDk1OS41MDMyMDc3OjAwNmZkODQ2LWZhYzUtMTFlYi1iZWI3LTAyNDJhYzE
  00:56:02.906 [redisservice2] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400  (×3)
  00:56:11.260 [mobservice1] INFO info 07ac67fa-fac5-11eb-95bf-0242ac110003:VLUjOpcK write success
  00:56:14.713 [dbservice2] INFO 098b5f2c-fac5-11eb-b10b-0242ac110003-gtLKWOSc-hjD2_FZ_9Qmn token generate success token=MTYyODcwMDk3NC43MTI5OTY6MDk4YjVmMmMtZmFjNS0xMWViLWIxMGItMDI0MmFjMTE  (×2)
  00:56:17.264 [dbservice2] INFO 0b00137a-fac5-11eb-96a7-0242ac110004-CAQfZdjo-Kb!NEVot&pm^ token generate success token=MTYyODcwMDk3Ny4yNjQwNjg0OjBiMDAxMzdhLWZhYzUtMTFlYi05NmE3LTAyNDJhYzE
  00:56:19.759 [dbservice2] INFO 0c8544e0-fac5-11eb-81ce-0242ac110004-bAyVlxfw-{$iaeTwmn-v# token generate success token=MTYyODcwMDk3OS43NTg4MzM6MGM4NTQ0ZTAtZmFjNS0xMWViLTgxY2UtMDI0MmFjMTE
  00:56:21.864 [mobservice2] INFO info 0e02c00e-fac5-11eb-a89a-0242ac110003:xYHiSMPL write success
  00:56:24.095 [dbservice2] INFO 0f1e7b68-fac5-11eb-bd50-0242ac110003-guYIhUdp-G-Z5>I<YCLtF token generate success token=MTYyODcwMDk4NC4wOTQ4NzkyOjBmMWU3YjY4LWZhYzUtMTFlYi1iZDUwLTAyNDJhYzE
  00:56:26.883 [dbservice1] INFO 10aef1e2-fac5-11eb-98e4-0242ac110004-FXAevOmb-vIR32bWN1z{l token generate success token=MTYyODcwMDk4Ni44ODMzODI6MTBhZWYxZTItZmFjNS0xMWViLTk4ZTQtMDI0MmFjMTE
  00:56:29.100 [dbservice1] INFO 120cac96-fac5-11eb-b7b7-0242ac110004-SbjCGNIe-I{}FNyGTP5E7 token generate success token=MTYyODcwMDk4OS4xMDAyODg5OjEyMGNhYzk2LWZhYzUtMTFlYi1iN2I3LTAyNDJhYzE
  00:56:31.762 [mobservice1] INFO info 13ca3756-fac5-11eb-ab36-0242ac110003:yWbZXEez write success

## p0253
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:06.796Z
```
{"timestamp":1732242486796515600,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Customer: {\"username\":\"oyShDJ\",\"password\":\"sWqvpeFZPy\",\"email\":\"oyShDJ@gmail.com\",\"firstName\":\"oyShDJ\",\"lastName\":\"oyShDJ\"}"}
```
Same service, the 2 minutes before (oldest first):
  02:28:05.620 [front-end] POST /cards 200 - ms - -
  02:28:05.665 [front-end] Attempting to delete cart for user: 673fec2cb0df5c00019af949
  02:28:05.688 [front-end] GET /catalogue 200 - ms - -
  02:28:05.694 [front-end] User cart deleted with status: 503
  02:28:05.697 [front-end] DELETE /cart 503 - ms - -
  02:28:05.703 [front-end] Attempting to add to cart: {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","quantity":1}
  02:28:05.709 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
  02:28:05.709 [front-end] POST to carts: http://carts/carts/673fec2cb0df5c00019af949/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}
  02:28:05.758 [front-end] POST /cart 500 50.973 ms - 64
  02:28:05.816 [front-end] Request received with body: {}
  02:28:05.824 [front-end] Received response: "{\"firstName\":\"bezHdMQDDj\",\"lastName\":\"bezHdMQDDj\",\"username\":\"bezHdMQDDj\",\"id\":\"673fec1cb0df5c00019af90c\",\"_links\":{\"addr
  02:28:05.824 [front-end] GET Request to: http://user/customers/673fec1cb0df5c00019af90c/addresses  (×2)
  02:28:05.829 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:05.830 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec23b0df5c00019af929\",\"_links\":{\"
  02:28:05.830 [front-end] [ undefined, undefined ]
  02:28:05.830 [front-end] Posting Order: {"customer":"http://user/customers/673fec1cb0df5c00019af90c","address":"http://user/addresses/673fec23b0df5c00019af928","card":"http://user/cards
  02:28:05.886 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242485883,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:05.886 [front-end] Order response: {"timestamp":1732242485883,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:05.888 [front-end] POST /orders 500 - ms - -
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×33)
  02:28:03.118 [catalogue] ts=2024-11-22T02:28:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.040202ms  (×39)
  02:28:03.190 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af953/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×18)
  02:28:03.211 [user] ts=2024-11-22T02:28:03.211690554Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=1.207621ms  (×36)
  02:28:03.252 [front-end] POST /orders 500 - ms - -  (×30)
  02:28:03.410 [front-end] Carts merged.  (×33)
  02:28:04.929 [front-end] Posting Customer: {"username":"JGQXvUjPbFrtK","password":"HtglbTyNG","email":"JGQXvUjPbFrtK@gmail.com","firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPbFrtK"}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:07.408 [front-end] Received response: "{\"firstName\":\"iTdzWTHcUAJJ\",\"lastName\":\"iTdzWTHcUAJJ\",\"username\":\"iTdzWTHcUAJJ\",\"id\":\"673fec22b0df5c00019af923\",\"_links\":{
  02:28:09.014 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×4)
  02:28:10.451 [carts] 2024-11-22 02:28:10.451 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  02:28:11.653 [user] ts=2024-11-22T02:28:11.653746097Z caller=middlewares.go:75 method=GetUsers id=673fec2ab0df5c00019af942 result=1 took=692µs
  02:28:14.311 [front-end] Posting Customer: {"username":"AIwPgMB","password":"ciKTe","email":"AIwPgMB@gmail.com","firstName":"AIwPgMB","lastName":"AIwPgMB"}
  02:28:16.228 [front-end] Posting Customer: {"username":"yTFoonPwqaY","password":"UsabiUKuuH","email":"yTFoonPwqaY@gmail.com","firstName":"yTFoonPwqaY","lastName":"yTFoonPwqaY"}
  02:28:17.978 [front-end] Posting Customer: {"username":"XaRPipq","password":"IPVIE","email":"XaRPipq@gmail.com","firstName":"XaRPipq","lastName":"XaRPipq"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.114 [front-end] Received response: "{\"firstName\":\"bCCZHBaYc\",\"lastName\":\"bCCZHBaYc\",\"username\":\"bCCZHBaYc\",\"id\":\"673fec31b0df5c00019af95b\",\"_links\":{\"address
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=673ns  (×9)
  02:28:23.749 [front-end] Posting Customer: {"username":"bhZuEQ","password":"CYefrd","email":"bhZuEQ@gmail.com","firstName":"bhZuEQ","lastName":"bhZuEQ"}
  02:28:24.870 [front-end] Received response: "{\"firstName\":\"sgQXbZQ\",\"lastName\":\"sgQXbZQ\",\"username\":\"sgQXbZQ\",\"id\":\"673fec33b0df5c00019af963\",\"_links\":{\"addresses\":{
  02:28:25.471 [front-end] Received response: "{\"firstName\":\"TcTuIokN\",\"lastName\":\"TcTuIokN\",\"username\":\"TcTuIokN\",\"id\":\"673fec32b0df5c00019af95c\",\"_links\":{\"addresses\
  02:28:25.838 [carts] 2024-11-22 02:28:25.837 INFO [carts,041812a6e38b1a0d,28fc13fb8146605a,false] 7 --- [-nio-80-exec-10] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×8)
  02:28:26.670 [orders-db] {"t":{"$date":"2024-11-22T02:28:26.670+00:00"},"s":"I", "c":"STORAGE", "id":20279, "ctx":"conn2","msg":"Conflicted creating a collection","attr":{"namespace":"d
  02:28:26.957 [front-end] Order response: {"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","lastName":"vuOxCKL","usern
  02:28:26.962 [front-end] Order response: {"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPb
  02:28:27.060 [front-end] Order response: {"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","lastName":"HFHBXn","usernam
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.842 [front-end] Posting Customer: {"username":"UsfOoRUlayKw","password":"RviRN","email":"UsfOoRUlayKw@gmail.com","firstName":"UsfOoRUlayKw","lastName":"UsfOoRUlayKw"}
  02:28:32.341 [queue-master] Caused by: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket
  02:28:32.649 [queue-master] 2024-11-22 02:28:32.649 ERROR 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×4)

## p0511
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:40:51.164Z
```
{"timestamp":1732358451164946200,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"Order response: {\"statusCode\":503,\"body\":\"upstream connect error or disconnect/reset before headers. retried and the latest reset reason: remote connection failure, transport failure reason: delayed connect error: Connection refused\",\"headers\":{\"content-length\":\"190\",\"content-type\":\"text/plain\",\"date\":\"Sat, 23 Nov 2024 10:40:50 GMT\",\"server\":\"envoy\",\"x-envoy-upstream-service-time\":\"75\",\"connection…"}
```
Same service, the 2 minutes before (oldest first):
  10:40:51.011 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"6741b  (×2)
  10:40:51.011 [front-end] [ undefined, undefined ]  (×2)
  10:40:51.011 [front-end] Posting Order: {"customer":"http://user/customers/6741b123a437380001df4a67","address":"http://user/addresses/6741b12aa437380001df4a76","card":"http://user/cards  (×2)
  10:40:51.011 [front-end] GET /catalogue 200 - ms - -
  10:40:51.050 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b12da437380001df4a7e"}
  10:40:51.057 [front-end] Request received with body: {}
  10:40:51.059 [front-end] POST /addresses 200 - ms - -
  10:40:51.062 [front-end] Order response: {"statusCode":503,"body":"upstream connect error or disconnect/reset before headers. retried and the latest reset reason: remote connection fail
  10:40:51.062 [front-end] Order response: "upstream connect error or disconnect/reset before headers. retried and the latest reset reason: remote connection failure, transport failure re
  10:40:51.063 [front-end] POST /orders 503 - ms - -
  10:40:51.070 [front-end] Received response: "{\"firstName\":\"VeudtRN\",\"lastName\":\"VeudtRN\",\"username\":\"VeudtRN\",\"id\":\"6741b11fa437380001df4a52\",\"_links\":{\"addresses\":{
  10:40:51.070 [front-end] GET Request to: http://user/customers/6741b11fa437380001df4a52/addresses  (×2)
  10:40:51.084 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b129a437380001df4a73\",\"_links\":{\"
  10:40:51.104 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"6741b12da437380001df4a7e"}
  10:40:51.115 [front-end] POST /cards 200 - ms - -
  10:40:51.160 [front-end] Attempting to delete cart for user: 6741b12da437380001df4a7e
All services, 30 seconds either side (sampled):
  10:40:51.001 [user] ts=2024-11-23T10:40:51.001253583Z caller=middlewares.go:75 method=GetUsers id=6741b123a437380001df4a67 result=1 took=2.561807ms  (×127)
  10:40:51.057 [front-end] Request received with body: {}  (×34)
  10:40:51.115 [front-end] POST /cards 200 - ms - -  (×33)
  10:40:51.243 [carts] 2024-11-23 10:40:51.243 INFO [carts,d2c2e6abee6853ca,7c11b7f04a005886,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×15)
  10:40:51.650 [carts] 2024-11-23 10:40:51.644 INFO [carts,ce28dad27a7f1e73,b550dd7d93e87a62,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×20)
  10:40:52.715 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×4)
  10:40:54.042 [carts] 2024-11-23 10:40:54.042 INFO [carts,55279b5e8192e632,8c77ccf18a9ceab9,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.ItemsController : Did not find item.  (×18)
  10:40:55.439 [front-end] Posting Customer: {"username":"RWEKCzZbyoL","password":"eCgDEu","email":"RWEKCzZbyoL@gmail.com","firstName":"RWEKCzZbyoL","lastName":"RWEKCzZbyoL"}
  10:40:57.337 [orders] 2024-11-23 10:40:57.337 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+jso
  10:40:57.345 [orders] 2024-11-23 10:40:57.345 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[applicatio
  10:40:57.435 [orders] 2024-11-23 10:40:57.435 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicat
  10:40:57.546 [orders] 2024-11-23 10:40:57.546 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http
  10:40:58.821 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  10:40:59.450 [orders] 2024-11-23 10:40:59.450 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=
  10:40:59.540 [orders] 2024-11-23 10:40:59.540 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[app
  10:41:02.850 [front-end] Posting Customer: {"username":"oljxrbkvgRPchx","password":"KICnrSMycj","email":"oljxrbkvgRPchx@gmail.com","firstName":"oljxrbkvgRPchx","lastName":"oljxrbkvgRPch
  10:41:04.149 [orders] 2024-11-23 10:41:04.149 INFO [orders,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering w
  10:41:06.939 [orders] 2024-11-23 10:41:06.843 INFO [orders,,,] 7 --- [p-nio-80-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization starte
  10:41:08.897 [front-end] Received response: "{\"firstName\":\"FoMnUsWRwtr\",\"lastName\":\"FoMnUsWRwtr\",\"username\":\"FoMnUsWRwtr\",\"id\":\"6741b133a437380001df4a8e\",\"_links\":{\"a
  10:41:09.781 [front-end] Posting Customer: {"username":"gzAwltOvrAOlwZ","password":"mvbfevmrG","email":"gzAwltOvrAOlwZ@gmail.com","firstName":"gzAwltOvrAOlwZ","lastName":"gzAwltOvrAOlwZ
  10:41:10.346 [queue-master] 2024-11-23 10:41:10.346 INFO 7 --- [ool-6-thread-24] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×18)
  10:41:10.951 [orders-db] {"t":{"$date":"2024-11-23T10:41:10.951+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:4145  (×10)
  10:41:11.658 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b14601dd390007094dcc","customerId":"6741b12ea437380001df4a7f","customer":{"id":null,"firstName":"vDSVmUfFkYR
  10:41:11.740 [front-end] Order response: {"id":"6741b14601dd390007094dcb","customerId":"6741b135a437380001df4a95","customer":{"id":null,"firstName":"oMOnLjzHZXUV","lastName":"oMOnLjzHZX
  10:41:11.746 [front-end] Order response: {"id":"6741b14601dd390007094dcd","customerId":"6741b133a437380001df4a8d","customer":{"id":null,"firstName":"PMMsVPkCBtB","lastName":"PMMsVPkCBtB
  10:41:13.508 [user] ts=2024-11-23T10:41:13.508595513Z caller=middlewares.go:46 method=Register username=AQxdn email=AQxdn@gmail.com took=2.184408ms
  10:41:15.043 [front-end] Order response: {"id":"6741b14a01dd390007094dd4","customerId":"6741b132a437380001df4a8a","customer":{"id":null,"firstName":"mfkgXqTHaTye","lastName":"mfkgXqTHaT
  10:41:17.757 [front-end] Received response: "{\"firstName\":\"RPAyWJFRkAtx\",\"lastName\":\"RPAyWJFRkAtx\",\"username\":\"RPAyWJFRkAtx\",\"id\":\"6741b138a437380001df4aa1\",\"_links\":{
  10:41:20.018 [front-end] Received response: "{\"firstName\":\"qqkRVDrhVVQ\",\"lastName\":\"qqkRVDrhVVQ\",\"username\":\"qqkRVDrhVVQ\",\"id\":\"6741b138a437380001df4aa2\",\"_links\":{\"a

## p0754
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T06:26:33.264Z
```
{"timestamp":1732256793264099800,"container_name":"front-end","pod_name":"front-end-f77549869-mxq2p","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Address: {\"number\":\"123\",\"street\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"country\":\"123\",\"userID\":\"6740240f768f35000114ebaa\"}"}
```
Same service, the 2 minutes before (oldest first):
  06:26:32.795 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67402411768f35000114ebb0"}  (×2)
  06:26:32.807 [front-end] POST /cards 200 - ms - -  (×2)
  06:26:32.841 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67402412768f35000114ebb5"}
  06:26:32.852 [front-end] POST /addresses 200 - ms - -
  06:26:32.853 [front-end] Attempting to delete cart for user: 67402411768f35000114ebb0  (×2)
  06:26:32.863 [front-end] User cart deleted with status: 202  (×2)
  06:26:32.866 [front-end] DELETE /cart 202 - ms - -  (×2)
  06:26:32.873 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×2)
  06:26:32.880 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  06:26:32.880 [front-end] POST to carts: http://carts/carts/67402411768f35000114ebb0/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×2)
  06:26:32.905 [front-end] POST /cart 201 - ms - -  (×2)
  06:26:32.946 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/
All services, 30 seconds either side (sampled):
  06:26:03.409 [front-end] Request received with body: {}  (×54)
  06:26:03.450 [payment] ts=2024-11-22T06:26:03Z caller=logging.go:29 method=Authorise result=false took=5.257µs  (×5)
  06:26:03.800 [carts] 2024-11-22 06:26:03.799 INFO [carts,71cc5c1f75609f9d,962a4dd189fa5a10,false] 7 --- [p-nio-80-exec-9] w.w.s.cart.controllers.CartsController : Merge carts reques  (×21)
  06:26:04.952 [queue-master] 2024-11-22 06:26:04.952 INFO 7 --- [pool-6-thread-6] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×8)
  06:26:05.069 [front-end] POST /cards 200 - ms - -  (×63)
  06:26:05.178 [front-end] POST /cart 201 - ms - -  (×63)
  06:26:06.846 [carts] 2024-11-22 06:26:06.846 INFO [carts,33ee38ef45fbfade,e9d0d0e3cee27ba8,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×27)
  06:26:08.341 [queue-master] 2024-11-22 06:26:08.341 INFO 7 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×41)
  06:26:09.136 [front-end] Posting Customer: {"username":"ilYQhjayz","password":"uguQqjux","email":"ilYQhjayz@gmail.com","firstName":"ilYQhjayz","lastName":"ilYQhjayz"}
  06:26:10.921 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×10)
  06:26:15.568 [front-end] Received response: "{\"firstName\":\"jYpPVHrgDyRAtAz\",\"lastName\":\"jYpPVHrgDyRAtAz\",\"username\":\"jYpPVHrgDyRAtAz\",\"id\":\"674023f7768f35000114eb6a\",\"_
  06:26:18.863 [user] ts=2024-11-22T06:26:18.863227007Z caller=middlewares.go:46 method=Register username=bqMcioQ email=bqMcioQ@gmail.com took=2.377204ms
  06:26:22.253 [front-end] Order response: {"statusCode":201,"body":{"id":"6740240e531af4000701dd92","customerId":"674023fe768f35000114eb78","customer":{"id":null,"firstName":"ejDKu","las
  06:26:22.712 [front-end] Order response: {"id":"6740240e531af4000701dd94","customerId":"67402400768f35000114eb7e","customer":{"id":null,"firstName":"APAdr","lastName":"APAdr","username"
  06:26:24.031 [front-end] Received response: "{\"firstName\":\"mtLVrtWRAZPGRTu\",\"lastName\":\"mtLVrtWRAZPGRTu\",\"username\":\"mtLVrtWRAZPGRTu\",\"id\":\"674023f6768f35000114eb67\",\"_
  06:26:26.491 [front-end] Order response: {"statusCode":201,"body":{"id":"67402412531af4000701dd98","customerId":"67402400768f35000114eb7d","customer":{"id":null,"firstName":"fVVKrEjpSvr
  06:26:31.729 [front-end] Order response: {"statusCode":201,"body":{"id":"67402417531af4000701dd9b","customerId":"67402402768f35000114eb84","customer":{"id":null,"firstName":"MYyCRqwjgO"
  06:26:34.466 [front-end] Order response: {"statusCode":201,"body":{"id":"6740241a531af4000701dd9d","customerId":"67402403768f35000114eb89","customer":{"id":null,"firstName":"iCApJNynWx"
  06:26:37.213 [front-end] Order response: {"id":"6740241d531af4000701dda0","customerId":"67402403768f35000114eb8b","customer":{"id":null,"firstName":"prYdjhuERUy","lastName":"prYdjhuERUy
  06:26:40.753 [orders-db] {"t":{"$date":"2024-11-22T06:26:40.753+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173225680
  06:26:43.056 [front-end] Received response: "{\"firstName\":\"bqMcioQ\",\"lastName\":\"bqMcioQ\",\"username\":\"bqMcioQ\",\"id\":\"6740240a768f35000114eb9d\",\"_links\":{\"addresses\":{
  06:26:44.249 [front-end] Posting Customer: {"username":"HWNyMmpqZkBnYo","password":"VmyXD","email":"HWNyMmpqZkBnYo@gmail.com","firstName":"HWNyMmpqZkBnYo","lastName":"HWNyMmpqZkBnYo"}
  06:26:44.661 [front-end] Order response: {"statusCode":201,"body":{"id":"67402424531af4000701ddaa","customerId":"6740240e768f35000114eba7","customer":{"id":null,"firstName":"YqiNdz","la
  06:26:46.970 [front-end] Order response: {"id":"67402426531af4000701ddad","customerId":"67402411768f35000114ebb0","customer":{"id":null,"firstName":"GeXniR","lastName":"GeXniR","usernam
  06:26:50.311 [front-end] Posting Customer: {"username":"PoluAaZSu","password":"PBRCvnicI","email":"PoluAaZSu@gmail.com","firstName":"PoluAaZSu","lastName":"PoluAaZSu"}
  06:26:52.900 [front-end] Posting Customer: {"username":"KhMjrL","password":"XNwzwnQ","email":"KhMjrL@gmail.com","firstName":"KhMjrL","lastName":"KhMjrL"}
  06:26:57.413 [front-end] Order response: {"id":"67402431531af4000701ddb0","customerId":"6740241b768f35000114ebd1","customer":{"id":null,"firstName":"HSblqrSTBFUTwT","lastName":"HSblqrST
  06:26:59.154 [front-end] Order response: {"id":"67402433531af4000701ddb3","customerId":"67402419768f35000114ebd0","customer":{"id":null,"firstName":"ThfaLS","lastName":"ThfaLS","usernam
  06:27:00.624 [front-end] Order response: {"id":"67402434531af4000701ddb4","customerId":"6740241d768f35000114ebd2","customer":{"id":null,"firstName":"zyWWGsklpVrit","lastName":"zyWWGsklp

## p0650
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-11T02:47:19.503Z
```
{"service":"mobservice1","message":"2021-08-11 02:47:19,503 | INFO | 0.0.0.1 | 172.17.0.5 | mobservice1 | 859ff8ae934b21ee | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  02:47:15.477 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  02:47:15.477 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  02:47:15.478 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '617bd410-fa0b-11eb-90d9-0242ac110004'}  (×4)
  02:47:15.549 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '617bd410-fa0b-11eb-90d9-0242ac110004', 'value': 'PUILkhrM'}  (×4)
  02:47:15.643 [mobservice1] INFO info 617bd410-fa0b-11eb-90d9-0242ac110004:PUILkhrM write success
  02:47:17.622 [mobservice1] INFO info 62ad40e4-fa0b-11eb-b4eb-0242ac110004:WRbeulvc write success
  02:47:18.097 [mobservice1] INFO info 62faecae-fa0b-11eb-b6f2-0242ac110004:ockFwOnC write success
  02:47:18.821 [mobservice1] INFO info 6366b484-fa0b-11eb-887c-0242ac110004:nBSDicYe write success
All services, 30 seconds either side (sampled):
  02:46:49.530 [dbservice2] INFO query = select passwards from username_table where user_name='yHoAlkMd'  (×36)
  02:46:49.687 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  02:46:49.921 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×40)
  02:46:50.074 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×42)
  02:46:50.169 [logservice2] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '5245cc6c-fa0b-11eb-a589-0242ac110004', 'user_id': 'bTPjsUVJ'}  (×85)
  02:46:50.774 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×52)
  02:46:51.696 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×44)
  02:46:52.043 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '53ab3fc4-fa0b-11eb-acf0-0242ac110003', 'value': '', 'ex': 10}  (×43)
  02:46:53.244 [mobservice1] INFO info 54254c4c-fa0b-11eb-b55b-0242ac110003:dFRVcSCY write success
  02:46:55.921 [mobservice1] INFO info 55c0bd2a-fa0b-11eb-b5f8-0242ac110003:osKDHrgX write success
  02:46:58.118 [dbservice2] INFO 56ebce2e-fa0b-11eb-a782-0242ac110003-JeRfoygk-7AZktBHf9zNu token generate success token=MTYyODYyMTIxOC4xMTgzMTIxOjU2ZWJjZTJlLWZhMGItMTFlYi1hNzgyLTAyNDJhYzE  (×6)
  02:47:00.992 [dbservice2] INFO 5892bdfa-fa0b-11eb-84d9-0242ac110003-lTYxuZoK-3UtL7AG$HnN5 token generate success token=MTYyODYyMTIyMC45OTIyNDM4OjU4OTJiZGZhLWZhMGItMTFlYi04NGQ5LTAyNDJhYzE
  02:47:03.441 [mobservice2] INFO info 5a40e7d0-fa0b-11eb-8921-0242ac110004:WYMpZilL write success
  02:47:05.829 [dbservice2] INFO 5b787afa-fa0b-11eb-b6c2-0242ac110004-WQyFOAmB-#WsQM+91Ce2R token generate success token=MTYyODYyMTIyNS44MjkzMTY2OjViNzg3YWZhLWZhMGItMTFlYi1iNmMyLTAyNDJhYzE
  02:47:08.634 [mobservice1] INFO info 5d62a494-fa0b-11eb-8b33-0242ac110003:GLwvPubR write success
  02:47:11.902 [mobservice2] INFO info 5f4ca70a-fa0b-11eb-870c-0242ac110004:tBueHCAS write success
  02:47:14.324 [dbservice2] INFO 60978e18-fa0b-11eb-9d9b-0242ac110004-aLCdNFuD->*a5MwtuL=pF token generate success token=MTYyODYyMTIzNC4zMjQyNTEyOjYwOTc4ZTE4LWZhMGItMTFlYi05ZDliLTAyNDJhYzE
  02:47:16.715 [dbservice1] INFO 6200d570-fa0b-11eb-84a8-0242ac110003-OzKQAVJF-y0PH2h:lM}5T token generate success token=MTYyODYyMTIzNi43MTU0NjI0OjYyMDBkNTcwLWZhMGItMTFlYi04NGE4LTAyNDJhYzE
  02:47:19.149 [dbservice1] INFO 6366b484-fa0b-11eb-887c-0242ac110004-nBSDicYe-Xnmoyc%*g{)k token generate success token=MTYyODYyMTIzOS4xNDkxNTI4OjYzNjZiNDg0LWZhMGItMTFlYi04ODdjLTAyNDJhYzE
  02:47:21.732 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat  (×2)
  02:47:24.194 [dbservice1] INFO 666b2444-fa0b-11eb-a477-0242ac110003-GLwvPubR-c9O=AoplwGk_ token generate success token=MTYyODYyMTI0NC4xOTM4OTU4OjY2NmIyNDQ0LWZhMGItMTFlYi1hNDc3LTAyNDJhYzE
  02:47:26.638 [dbservice1] INFO 67ea02b8-fa0b-11eb-96d0-0242ac110003-OVLDMHZf-2*N=10SK9_YR token generate success token=MTYyODYyMTI0Ni42MzgxNjEyOjY3ZWEwMmI4LWZhMGItMTFlYi05NmQwLTAyNDJhYzE
  02:47:29.319 [dbservice1] INFO 6988e76a-fa0b-11eb-a362-0242ac110003-JjOStLkT-_GA<:4K/vjX@ token generate success token=MTYyODYyMTI0OS4zMTkzOTAzOjY5ODhlNzZhLWZhMGItMTFlYi1hMzYyLTAyNDJhYzE
  02:47:32.222 [dbservice2] INFO 6b24c738-fa0b-11eb-83cb-0242ac110004-DBUWXtFp-Tc5tA%i1s$&9 token generate success token=MTYyODYyMTI1Mi4yMjE5NzM3OjZiMjRjNzM4LWZhMGItMTFlYi04M2NiLTAyNDJhYzE
  02:47:34.856 [mobservice1] INFO info 6cfff820-fa0b-11eb-9b51-0242ac110003:wdBFovNq write success
  02:47:37.898 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  02:47:46.481 [dbservice1] INFO 73a75e84-fa0b-11eb-8e5a-0242ac110004-tRLZzuQg-6=h^0Kp$%lJx token generate success token=MTYyODYyMTI2Ni40ODE2MzI1OjczYTc1ZTg0LWZhMGItMTFlYi04ZTVhLTAyNDJhYzE
  02:47:48.981 [mobservice2] INFO info 75601716-fa0b-11eb-b0b3-0242ac110004:VaMiodsE write success

## p0833
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-08T12:26:18.503Z
```
{"timestamp":1733660778503258400,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-58w5c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:26:18.502  INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl  : indexStart : 0 __ indexEnd : 1"}
```
Same service, the 2 minutes before (oldest first):
  12:26:17.992 [ts-basic-service] 2024-12-08 12:26:17.992 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1
  12:26:17.992 [ts-basic-service] 2024-12-08 12:26:17.992 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4
  12:26:18.013 [ts-basic-service] 2024-12-08 12:26:18.013 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×5)
  12:26:18.028 [ts-basic-service] 2024-12-08 12:26:18.028 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan
  12:26:18.060 [ts-basic-service] 2024-12-08 12:26:18.059 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×4)
  12:26:18.457 [ts-basic-service] 2024-12-08 12:26:18.457 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
  12:26:18.461 [ts-basic-service] 2024-12-08 12:26:18.461 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  12:26:18.466 [ts-basic-service] 2024-12-08 12:26:18.465 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa
  12:26:18.474 [ts-basic-service] 2024-12-08 12:26:18.474 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87
  12:26:18.480 [ts-basic-service] 2024-12-08 12:26:18.480 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  12:26:18.481 [ts-basic-service] 2024-12-08 12:26:18.481 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23
  12:26:18.492 [ts-basic-service] 2024-12-08 12:26:18.492 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  12:26:18.503 [ts-basic-service] 2024-12-08 12:26:18.502 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing
All services, 30 seconds either side (sampled):
  12:25:49.464 [ts-auth-service] 2024-12-08 12:25:49.463 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×14)
  12:25:49.728 [ts-route-service] 2024-12-08 12:25:49.728 INFO 1 --- [io-11178-exec-4] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×240)
  12:25:49.799 [ts-price-service] 2024-12-08 12:25:49.799 INFO 1 --- [io-16579-exec-2] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×17)
  12:25:49.834 [ts-basic-service] 2024-12-08 12:25:49.833 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×8)
  12:25:49.921 [ts-seat-service] 2024-12-08 12:25:49.921 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×34)
  12:25:50.383 [ts-food-service] 2024-12-08 12:25:50.383 INFO 1 --- [io-18856-exec-3] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×5)
  12:25:51.435 [ts-admin-basic-info-service] 2024-12-08 12:25:51.435 INFO 1 --- [io-18767-exec-7] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×13)
  12:25:56.322 [ts-travel2-service] 2024-12-08 12:25:56.322 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  12:25:56.405 [ts-travel2-service] 2024-12-08 12:25:56.405 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  12:25:56.575 [ts-basic-service] 2024-12-08 12:25:56.574 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×2)
  12:25:56.655 [ts-seat-service] 2024-12-08 12:25:56.655 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×6)
  12:25:56.798 [ts-travel-service] 2024-12-08 12:25:56.798 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×14)
  12:25:57.330 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:25:57 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 916 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe
  12:26:00.404 [ts-price-service] 2024-12-08 12:26:00.404 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×3)
  12:26:00.603 [ts-seat-service] 2024-12-08 12:26:00.602 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×3)
  12:26:01.283 [ts-admin-basic-info-service] 2024-12-08 12:26:01.283 INFO 1 --- [io-18767-exec-6] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×9)
  12:26:05.700 [ts-admin-basic-info-service] 2024-12-08 12:26:05.699 INFO 1 --- [o-18767-exec-10] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×3)
  12:26:11.750 [ts-station-mongo] {"t":{"$date":"2024-12-08T12:26:11.750+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366077
  12:26:12.265 [ts-config-mongo] {"t":{"$date":"2024-12-08T12:26:12.265+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366077
  12:26:14.823 [ts-food-map-mongo] {"t":{"$date":"2024-12-08T12:26:14.823+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366077
  12:26:28.754 [ts-assurance-service] 2024-12-08 12:26:28.754 INFO 1 --- [o-18888-exec-10] a.controller.AssuranceController : [Assurances Service][Get Assurance Type]
  12:26:28.781 [ts-preserve-other-service] 2024-12-08 12:26:28.781 INFO 1 --- [o-14569-exec-10] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Check Account Security] Checking....
  12:26:28.822 [ts-security-service] 2024-12-08 12:26:28.822 INFO 1 --- [io-11188-exec-5] security.service.SecurityServiceImpl : [Security Service][Get Security Config Info]
  12:26:28.846 [ts-preserve-other-service] 2024-12-08 12:26:28.846 INFO 1 --- [o-14569-exec-10] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Step 2] Complete
  12:26:29.165 [ts-preserve-other-service] 2024-12-08 12:26:29.165 INFO 1 --- [o-14569-exec-10] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order
  12:26:29.228 [ts-basic-service] 2024-12-08 12:26:29.228 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing
  12:26:29.275 [ts-seat-service] 2024-12-08 12:26:29.275 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService distributeSeat] Use a new seat number! 1204802788
  12:26:29.291 [ts-preserve-other-service] 2024-12-08 12:26:29.291 INFO 1 --- [o-14569-exec-10] p.service.PreserveOtherServiceImpl : [Preserve Service][Add Assurance Type For Order]
  12:26:34.737 [ts-order-other-service] 2024-12-08 12:26:34.736 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0
  12:26:38.183 [ts-travel-service] 2024-12-08 12:26:38.182 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha

## p0278
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:23.749Z
```
{"timestamp":1732242503749410600,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Customer: {\"username\":\"bhZuEQ\",\"password\":\"CYefrd\",\"email\":\"bhZuEQ@gmail.com\",\"firstName\":\"bhZuEQ\",\"lastName\":\"bhZuEQ\"}"}
```
Same service, the 2 minutes before (oldest first):
  02:28:23.301 [front-end] GET Request to: http://user/customers/673fec34b0df5c00019af967/addresses  (×2)
  02:28:23.308 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:23.308 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec3eb0df5c00019af984\",\"_links\":{\"
  02:28:23.308 [front-end] [ undefined, undefined ]
  02:28:23.308 [front-end] Posting Order: {"customer":"http://user/customers/673fec34b0df5c00019af967","address":"http://user/addresses/673fec3eb0df5c00019af983","card":"http://user/cards
  02:28:23.340 [front-end] User cart deleted with status: 202  (×2)
  02:28:23.342 [front-end] DELETE /cart 202 - ms - -  (×2)
  02:28:23.354 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×2)
  02:28:23.362 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×2)
  02:28:23.362 [front-end] POST to carts: http://carts/carts/673fec3eb0df5c00019af985/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}  (×2)
  02:28:23.543 [front-end] Carts merged.
  02:28:23.543 [front-end] set cookie673fec45b0df5c00019af990
  02:28:23.544 [front-end] Sent cookies.
  02:28:23.545 [front-end] POST /register 200 1576.719 ms - 33
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×49)
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -  (×49)
  02:28:03.203 [front-end] [ undefined, undefined ]  (×48)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×4)
  02:28:07.445 [orders] 2024-11-22 02:28:07.445 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
  02:28:10.277 [front-end] Posting Customer: {"username":"opFqwUnVow","password":"habyXFSF","email":"opFqwUnVow@gmail.com","firstName":"opFqwUnVow","lastName":"opFqwUnVow"}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
  02:28:23.301 [front-end] Received response: "{\"firstName\":\"HFHBXn\",\"lastName\":\"HFHBXn\",\"username\":\"HFHBXn\",\"id\":\"673fec34b0df5c00019af967\",\"_links\":{\"addresses\":{\"h
  02:28:24.999 [rabbitmq] =INFO REPORT==== 22-Nov-2024::02:28:24 ===  (×2)
  02:28:25.776 [front-end] Posting Customer: {"username":"oqYeDriHaX","password":"fGIijlAHQ","email":"oqYeDriHaX@gmail.com","firstName":"oqYeDriHaX","lastName":"oqYeDriHaX"}
  02:28:26.670 [orders-db] {"t":{"$date":"2024-11-22T02:28:26.670+00:00"},"s":"I", "c":"STORAGE", "id":20279, "ctx":"conn2","msg":"Conflicted creating a collection","attr":{"namespace":"d
  02:28:26.959 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39cf","customerId":"673fec36b0df5c00019af96c","customer":{"id":null,"firstName":"oyShDJ","la
  02:28:27.046 [front-end] Order response: {"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","lastName":"uBxHmzyg","use
  02:28:30.547 [front-end] Received response: "{\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\",\"username\":\"vvgsHcY\",\"id\":\"673fec35b0df5c00019af968\",\"_links\":{\"addresses\":{
  02:28:32.249 [queue-master] org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket-factory-20
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×60)
  02:28:38.668 [front-end] Received response: "{\"firstName\":\"PDQejFz\",\"lastName\":\"PDQejFz\",\"username\":\"PDQejFz\",\"id\":\"673fec45b0df5c00019af990\",\"_links\":{\"addresses\":{
  02:28:40.372 [front-end] Received response: "{\"firstName\":\"ngvaqDyp\",\"lastName\":\"ngvaqDyp\",\"username\":\"ngvaqDyp\",\"id\":\"673fec48b0df5c00019af997\",\"_links\":{\"addresses\
  02:28:42.162 [front-end] Order response: {"timestamp":1732242522152,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×2)
  02:28:44.338 [front-end] Order response: {"id":"673fec5cd94b9000069b39e2","customerId":"673fec3ab0df5c00019af974","customer":{"id":null,"firstName":"opFqwUnVow","lastName":"opFqwUnVow",
  02:28:45.917 [front-end] Posting Customer: {"username":"TmuiGnjHXKwQyA","password":"AlXtuGS","email":"TmuiGnjHXKwQyA@gmail.com","firstName":"TmuiGnjHXKwQyA","lastName":"TmuiGnjHXKwQyA"}
  02:28:47.785 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec5fd94b9000069b39e7","customerId":"673fec41b0df5c00019af98c","customer":{"id":null,"firstName":"QGHrdp","la
  02:28:50.862 [front-end] Posting Customer: {"username":"tuMdldzXaDzdlI","password":"tqMnacPIQx","email":"tuMdldzXaDzdlI@gmail.com","firstName":"tuMdldzXaDzdlI","lastName":"tuMdldzXaDzdl

## p0780
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-24T13:34:45.949Z
```
{"timestamp":1732455285949811000,"container_name":"front-end","pod_name":"front-end-f77549869-qkdxd","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"DELETE /cart 503 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  13:34:44.181 [front-end] POST /register 200 59.765 ms - 33  (×2)
  13:34:44.213 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732455284211,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  13:34:44.213 [front-end] Order response: {"timestamp":1732455284211,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  13:34:44.214 [front-end] POST /orders 500 - ms - -
  13:34:45.188 [front-end] GET /catalogue 200 - ms - -  (×2)
  13:34:45.729 [front-end] Posting Customer: {"username":"IXMyAQkuBeK","password":"yGgQbTX","email":"IXMyAQkuBeK@gmail.com","firstName":"IXMyAQkuBeK","lastName":"IXMyAQkuBeK"}
  13:34:45.734 [front-end] { id: '67432b75f6d875000161ffaf' }
  13:34:45.734 [front-end] 67432b75f6d875000161ffaf
  13:34:45.734 [front-end] Merging carts for customer id: 67432b75f6d875000161ffaf and session id: TLxtLP3zSbMiiuYPfQRRMDLAeML-drtD
  13:34:45.778 [front-end] Carts merged.
  13:34:45.778 [front-end] set cookie67432b75f6d875000161ffaf
  13:34:45.778 [front-end] Sent cookies.
  13:34:45.808 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67432b6ff6d875000161ff99"}
  13:34:45.817 [front-end] POST /addresses 200 - ms - -
  13:34:45.865 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67432b6ff6d875000161ff99"}
  13:34:45.874 [front-end] POST /cards 200 - ms - -
  13:34:45.921 [front-end] Attempting to delete cart for user: 67432b6ff6d875000161ff99
  13:34:45.948 [front-end] User cart deleted with status: 503
All services, 30 seconds either side (sampled):
  13:34:16.004 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67432b4ff6d875000161ff34"}  (×63)
  13:34:16.103 [front-end] Attempting to add to cart: {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×63)
  13:34:16.434 [carts] 2024-11-24 13:34:16.434 INFO [carts,fb4ba9c8e6dfb2fd,797077bde4808e77,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.ItemsController : Did not find item.  (×22)
  13:34:17.654 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67432  (×63)
  13:34:17.681 [queue-master] Received shipment task: 67432b42f6d875000161ff19  (×27)
  13:34:17.705 [front-end] { id: '67432b59f6d875000161ff51' }  (×64)
  13:34:18.650 [front-end] Posting Customer: {"username":"MDemFnmhXrGzUDY","password":"fxbpEJatWy","email":"MDemFnmhXrGzUDY@gmail.com","firstName":"MDemFnmhXrGzUDY","lastName":"MDemFnmhXr
  13:34:20.720 [user] ts=2024-11-24T13:34:20.720543435Z caller=middlewares.go:46 method=Register username=FEqRYTMSH email=FEqRYTMSH@gmail.com took=1.592323ms
  13:34:22.111 [front-end] Received response: "{\"firstName\":\"oaJPSVOc\",\"lastName\":\"oaJPSVOc\",\"username\":\"oaJPSVOc\",\"id\":\"67432b47f6d875000161ff20\",\"_links\":{\"addresses\
  13:34:23.013 [front-end] Order response: {"id":"67432b5fc4380300078a4804","customerId":"67432b45f6d875000161ff1c","customer":{"id":null,"firstName":"LctUiPHz","lastName":"LctUiPHz","use
  13:34:25.823 [front-end] Received response: "{\"firstName\":\"ufjHTcuTuLeodxV\",\"lastName\":\"ufjHTcuTuLeodxV\",\"username\":\"ufjHTcuTuLeodxV\",\"id\":\"67432b4bf6d875000161ff28\",\"_
  13:34:26.589 [front-end] Posting Customer: {"username":"owzxqQXxjeJLd","password":"lCNMRoX","email":"owzxqQXxjeJLd@gmail.com","firstName":"owzxqQXxjeJLd","lastName":"owzxqQXxjeJLd"}
  13:34:29.658 [front-end] Received response: "{\"firstName\":\"rYRZTQlFgJm\",\"lastName\":\"rYRZTQlFgJm\",\"username\":\"rYRZTQlFgJm\",\"id\":\"67432b53f6d875000161ff3d\",\"_links\":{\"a
  13:34:31.537 [front-end] Order response: {"statusCode":201,"body":{"id":"67432b67c4380300078a480e","customerId":"67432b55f6d875000161ff42","customer":{"id":null,"firstName":"MBZTVPjzcIV
  13:34:32.523 [front-end] Order response: {"statusCode":201,"body":{"id":"67432b68c4380300078a4811","customerId":"67432b55f6d875000161ff43","customer":{"id":null,"firstName":"ENgnxuzOFmR
  13:34:34.268 [user] ts=2024-11-24T13:34:34.268104984Z caller=middlewares.go:46 method=Register username=YhlNbHKUS email=YhlNbHKUS@gmail.com took=1.922336ms
  13:34:38.269 [front-end] Order response: {"statusCode":201,"body":{"id":"67432b6ec4380300078a4814","customerId":"67432b56f6d875000161ff49","customer":{"id":null,"firstName":"dEBMyIJuAKm
  13:34:40.120 [front-end] Order response: {"statusCode":201,"body":{"id":"67432b70c4380300078a4816","customerId":"67432b5bf6d875000161ff5c","customer":{"id":null,"firstName":"CHQPpycImUJ
  13:34:42.997 [front-end] Posting Customer: {"username":"VlZDl","password":"EYcxGDQO","email":"VlZDl@gmail.com","firstName":"VlZDl","lastName":"VlZDl"}
  13:34:44.072 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732455284070,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×34)
  13:34:46.787 [front-end] Received response: "{\"firstName\":\"owzxqQXxjeJLd\",\"lastName\":\"owzxqQXxjeJLd\",\"username\":\"owzxqQXxjeJLd\",\"id\":\"67432b62f6d875000161ff6e\",\"_links\
  13:34:49.227 [front-end] Posting Customer: {"username":"ZqUTi","password":"MufItgb","email":"ZqUTi@gmail.com","firstName":"ZqUTi","lastName":"ZqUTi"}
  13:34:51.399 [front-end] Received response: "{\"firstName\":\"fwjKtUwureQ\",\"lastName\":\"fwjKtUwureQ\",\"username\":\"fwjKtUwureQ\",\"id\":\"67432b63f6d875000161ff6f\",\"_links\":{\"a
  13:34:55.254 [front-end] Posting Customer: {"username":"FDvjJpEistkFFH","password":"PllzgvAwf","email":"FDvjJpEistkFFH@gmail.com","firstName":"FDvjJpEistkFFH","lastName":"FDvjJpEistkFFH
  13:34:59.256 [user] ts=2024-11-24T13:34:59.256086146Z caller=middlewares.go:46 method=Register username=EVRMZI email=EVRMZI@gmail.com took=1.97347ms
  13:35:02.383 [front-end] Posting Customer: {"username":"KwaCON","password":"boIMcCRX","email":"KwaCON@gmail.com","firstName":"KwaCON","lastName":"KwaCON"}
  13:35:06.684 [front-end] Posting Customer: {"username":"tXxWPCq","password":"zmsGTY","email":"tXxWPCq@gmail.com","firstName":"tXxWPCq","lastName":"tXxWPCq"}
  13:35:08.702 [user] ts=2024-11-24T13:35:08.701909101Z caller=middlewares.go:46 method=Register username=EWWLyYS email=EWWLyYS@gmail.com took=1.881826ms
  13:35:12.941 [front-end] Received response: "{\"firstName\":\"PoBVCcThKWUccy\",\"lastName\":\"PoBVCcThKWUccy\",\"username\":\"PoBVCcThKWUccy\",\"id\":\"67432b7ef6d875000161ffcb\",\"_lin
  13:35:15.039 [front-end] Received response: "{\"firstName\":\"PFJYbD\",\"lastName\":\"PFJYbD\",\"username\":\"PFJYbD\",\"id\":\"67432b85f6d875000161ffdc\",\"_links\":{\"addresses\":{\"h

## p0738
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-22T12:28:26.807Z
```
{"timestamp":1732278506807125800,"container_name":"frontend","pod_name":"frontend-588fbcd66b-fjnp2","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"view user cart"}
```
Same service, the 2 minutes before (oldest first):
  12:28:26.401 [frontend] view user cart  (×2)
  12:28:26.409 [frontend] request complete  (×6)
  12:28:26.556 [frontend] request started  (×5)
  12:28:26.562 [frontend] serving product page  (×2)
  12:28:26.594 [frontend] failed to retrieve ads  (×2)
  12:28:26.594 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14  (×2)
  12:28:26.795 [frontend] adding to cart
All services, 30 seconds either side (sampled):
  12:27:57.198 [frontend] request started  (×293)
  12:27:57.204 [currencyservice] Getting supported currencies...  (×244)
  12:27:57.212 [currencyservice] conversion request successful  (×662)
  12:27:57.231 [frontend] failed to retrieve ads  (×178)
  12:27:57.232 [frontend] request complete  (×293)
  12:27:57.827 [frontend] home  (×39)
  12:27:57.971 [frontend] adding to cart  (×28)
  12:27:57.985 [frontend] view user cart  (×58)
  12:27:58.012 [shippingservice] [GetQuote] completed request  (×66)
  12:27:58.029 [checkoutservice] [PlaceOrder] user_id="88ff07fb-64e1-4f87-827d-f0bb3b8aab5d" user_currency="EUR"  (×2)
  12:27:58.048 [paymentservice] Transaction processed: visa ending 6650 Amount: EUR74.268022999  (×2)
  12:27:58.052 [shippingservice] [ShipOrder] received request  (×7)
  12:27:58.054 [cartservice] EmptyCartAsync called with userId=88ff07fb-64e1-4f87-827d-f0bb3b8aab5d  (×7)
  12:27:58.061 [checkoutservice] order confirmation email sent to "sarah12@example.org"
  12:28:13.652 [checkoutservice] [PlaceOrder] user_id="07008eda-9426-4259-a693-c0275e226c75" user_currency="GBP"  (×2)
  12:28:13.670 [paymentservice] Transaction processed: visa ending 8915 Amount: GBP119.323774433  (×2)
  12:28:13.683 [checkoutservice] order confirmation email sent to "lesterchristopher@example.net"
  12:28:17.895 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"2257","nanos":985374656},"credit_card":{"credit_card_number":"4022964276879  (×2)
  12:28:17.908 [emailservice] A request to send order confirmation email to beckerjames@example.net has been received.
  12:28:26.882 [emailservice] A request to send order confirmation email to kiarasimon@example.net has been received.
  12:28:47.396 [adservice] AdService starting.
  12:28:47.487 [adservice] Tracing enabled but temporarily unavailable
  12:28:47.488 [adservice] Tracing enabled - Stackdriver exporter initialized.
  12:28:49.086 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base
  12:28:51.602 [checkoutservice] order confirmation email sent to "susan75@example.net"
  12:28:51.933 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"201","nanos":400000000},"credit_card":{"credit_card_number":"41480911863018
  12:28:51.946 [emailservice] A request to send order confirmation email to athomas@example.org has been received.
  12:28:54.354 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', 'OLJCESPC7Z', '0PUK6V6EV0', '9SIQT8TOJO']
  12:28:56.403 [checkoutservice] order confirmation email sent to "nnicholson@example.com"

## p0343
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:22:08.681Z
```
{"timestamp":1732245728681235500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Attempting to delete cart for user: 673ff8d7b0df5c00019b2002"}
```
Same service, the 2 minutes before (oldest first):
  03:22:08.153 [front-end] Order response: {"id":"673ff8e0d94b9000069b43c1","customerId":"673ff8cfb0df5c00019b1fec","customer":{"id":null,"firstName":"fPXDiFRPLnaD","lastName":"fPXDiFRPLn
  03:22:08.158 [front-end] POST /orders 201 - ms - -  (×2)
  03:22:08.209 [front-end] GET /catalogue 200 - ms - -  (×3)
  03:22:08.564 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff8d7b0df5c00019b2002"}
  03:22:08.574 [front-end] POST /addresses 200 - ms - -
  03:22:08.603 [front-end] Request received with body: {}
  03:22:08.611 [front-end] Received response: "{\"firstName\":\"VaXJYznhb\",\"lastName\":\"VaXJYznhb\",\"username\":\"VaXJYznhb\",\"id\":\"673ff8c5b0df5c00019b1fc5\",\"_links\":{\"address
  03:22:08.611 [front-end] GET Request to: http://user/customers/673ff8c5b0df5c00019b1fc5/addresses  (×2)
  03:22:08.618 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff8ceb0df5c00019b1fe9\",\"_links\":{\"
  03:22:08.618 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:22:08.618 [front-end] [ undefined, undefined ]
  03:22:08.618 [front-end] Posting Order: {"customer":"http://user/customers/673ff8c5b0df5c00019b1fc5","address":"http://user/addresses/673ff8ceb0df5c00019b1fe8","card":"http://user/cards
  03:22:08.625 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff8d7b0df5c00019b2002"}
  03:22:08.633 [front-end] POST /cards 200 - ms - -
  03:22:08.648 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8e0d94b9000069b43c2","customerId":"673ff8c5b0df5c00019b1fc5","customer":{"id":null,"firstName":"VaXJYznhb",
  03:22:08.648 [front-end] Order response: {"id":"673ff8e0d94b9000069b43c2","customerId":"673ff8c5b0df5c00019b1fc5","customer":{"id":null,"firstName":"VaXJYznhb","lastName":"VaXJYznhb","u
All services, 30 seconds either side (sampled):
  03:21:38.689 [orders] 2024-11-22 03:21:38.689 INFO [orders,b60933d2c5eba664,2ded28f41db65908,false] 6 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Sending payment req  (×37)
  03:21:38.719 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff8b9b0df5c00019b1fac"}  (×68)
  03:21:38.918 [front-end] POST to carts: http://carts/carts/673ff8b9b0df5c00019b1fac/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}  (×37)
  03:21:39.831 [front-end] [ undefined, undefined ]  (×58)
  03:21:40.352 [catalogue] ts=2024-11-22T03:21:40Z caller=logging.go:85 method=Health result=2 took=28.053µs  (×40)
  03:21:41.389 [front-end] set cookie673ff8c5b0df5c00019b1fc5  (×64)
  03:21:42.644 [front-end] Posting Customer: {"username":"xJlcQpb","password":"oVqgWBllp","email":"xJlcQpb@gmail.com","firstName":"xJlcQpb","lastName":"xJlcQpb"}
  03:21:43.915 [front-end] Received response: "{\"firstName\":\"XSDCLJKgyLoxe\",\"lastName\":\"XSDCLJKgyLoxe\",\"username\":\"XSDCLJKgyLoxe\",\"id\":\"673ff8acb0df5c00019b1f91\",\"_links\
  03:21:45.743 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×9)
  03:21:50.026 [front-end] Order response: {"id":"673ff8ced94b9000069b43ad","customerId":"673ff8b9b0df5c00019b1fac","customer":{"id":null,"firstName":"QoPcWQ","lastName":"QoPcWQ","usernam
  03:21:51.746 [front-end] Posting Customer: {"username":"fPXDiFRPLnaD","password":"IeiPzVruW","email":"fPXDiFRPLnaD@gmail.com","firstName":"fPXDiFRPLnaD","lastName":"fPXDiFRPLnaD"}
  03:21:55.412 [front-end] Received response: "{\"firstName\":\"xyFLJGPDL\",\"lastName\":\"xyFLJGPDL\",\"username\":\"xyFLJGPDL\",\"id\":\"673ff8b8b0df5c00019b1fab\",\"_links\":{\"address
  03:21:56.646 [front-end] Order response: {"id":"673ff8d4d94b9000069b43b6","customerId":"673ff8c6b0df5c00019b1fc7","customer":{"id":null,"firstName":"aQnXDQax","lastName":"aQnXDQax","use
  03:21:57.860 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8d5d94b9000069b43b8","customerId":"673ff8c2b0df5c00019b1fbe","customer":{"id":null,"firstName":"otqrpqrI","
  03:22:00.057 [front-end] Order response: {"id":"673ff8d8d94b9000069b43bb","customerId":"673ff8c6b0df5c00019b1fcc","customer":{"id":null,"firstName":"ukABrPBTudQxx","lastName":"ukABrPBTu
  03:22:03.367 [front-end] Received response: "{\"firstName\":\"TKpvFVaQefAs\",\"lastName\":\"TKpvFVaQefAs\",\"username\":\"TKpvFVaQefAs\",\"id\":\"673ff8c9b0df5c00019b1fdb\",\"_links\":{
  03:22:05.938 [front-end] Received response: "{\"firstName\":\"uJQuaCc\",\"lastName\":\"uJQuaCc\",\"username\":\"uJQuaCc\",\"id\":\"673ff8c8b0df5c00019b1fd9\",\"_links\":{\"addresses\":{
  03:22:09.562 [front-end] Received response: "{\"firstName\":\"ewaPIqYPbLQLN\",\"lastName\":\"ewaPIqYPbLQLN\",\"username\":\"ewaPIqYPbLQLN\",\"id\":\"673ff8ccb0df5c00019b1fe2\",\"_links\
  03:22:11.884 [front-end] Posting Customer: {"username":"MOAwTUsaRSuUttf","password":"yJVWO","email":"MOAwTUsaRSuUttf@gmail.com","firstName":"MOAwTUsaRSuUttf","lastName":"MOAwTUsaRSuUttf
  03:22:16.728 [front-end] Posting Customer: {"username":"mRDoqspxyB","password":"FgKNuKHR","email":"mRDoqspxyB@gmail.com","firstName":"mRDoqspxyB","lastName":"mRDoqspxyB"}
  03:22:18.776 [front-end] Received response: "{\"firstName\":\"IbvbfU\",\"lastName\":\"IbvbfU\",\"username\":\"IbvbfU\",\"id\":\"673ff8d7b0df5c00019b2002\",\"_links\":{\"addresses\":{\"h
  03:22:20.410 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8ecd94b9000069b43cb","customerId":"673ff8ddb0df5c00019b200f","customer":{"id":null,"firstName":"VpXBJhek","
  03:22:25.448 [front-end] Posting Customer: {"username":"FYjmTCvIDYMc","password":"HnYlWLDR","email":"FYjmTCvIDYMc@gmail.com","firstName":"FYjmTCvIDYMc","lastName":"FYjmTCvIDYMc"}
  03:22:28.685 [user] ts=2024-11-22T03:22:28.685585986Z caller=middlewares.go:46 method=Register username=VewIdx email=VewIdx@gmail.com took=944.324µs
  03:22:29.563 [front-end] Order response: {"id":"673ff8f5d94b9000069b43d2","customerId":"673ff8ddb0df5c00019b2010","customer":{"id":null,"firstName":"flfXwE","lastName":"flfXwE","usernam
  03:22:31.695 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8f7d94b9000069b43d5","customerId":"673ff8e2b0df5c00019b201c","customer":{"id":null,"firstName":"klfigsQDuJO
  03:22:34.942 [front-end] Posting Customer: {"username":"uxeWM","password":"ePNdukw","email":"uxeWM@gmail.com","firstName":"uxeWM","lastName":"uxeWM"}
  03:22:37.323 [front-end] Received response: "{\"firstName\":\"XrxCxfARvAXPQ\",\"lastName\":\"XrxCxfARvAXPQ\",\"username\":\"XrxCxfARvAXPQ\",\"id\":\"673ff8e9b0df5c00019b202f\",\"_links\

## p0515
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T10:40:52.755Z
```
{"timestamp":1732358452755722200,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 10:40:52.755  INFO [carts,9bb4906174a9c5f8,a5774a224abb6a4c,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.cart.CartContentsResource     : Adding for user: Cart{id='6741b134f074bf0007004adf', customerId='6741b12ea437380001df4a80', items=[]}, Item{id='6741b134f074bf0007004ae0', itemId='837ab141-399e-4c1f-9abc-bace40296bac', quantity=1, unitPrice=15.0}"}
```
Same service, the 2 minutes before (oldest first):
  10:40:51.232 [carts] 2024-11-23 10:40:51.232 INFO [carts,d2c2e6abee6853ca,7c11b7f04a005886,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  10:40:51.243 [carts] 2024-11-23 10:40:51.243 INFO [carts,d2c2e6abee6853ca,7c11b7f04a005886,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.cart.CartContentsResource : Adding for user: Car
  10:40:51.650 [carts] 2024-11-23 10:40:51.644 INFO [carts,ce28dad27a7f1e73,b550dd7d93e87a62,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×3)
All services, 30 seconds either side (sampled):
  10:40:51.001 [user] ts=2024-11-23T10:40:51.001253583Z caller=middlewares.go:75 method=GetUsers id=6741b123a437380001df4a67 result=1 took=2.561807ms  (×127)
  10:40:51.057 [front-end] Request received with body: {}  (×34)
  10:40:51.115 [front-end] POST /cards 200 - ms - -  (×35)
  10:40:51.243 [carts] 2024-11-23 10:40:51.243 INFO [carts,d2c2e6abee6853ca,7c11b7f04a005886,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×15)
  10:40:51.650 [carts] 2024-11-23 10:40:51.644 INFO [carts,ce28dad27a7f1e73,b550dd7d93e87a62,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×21)
  10:40:52.715 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×4)
  10:40:54.042 [carts] 2024-11-23 10:40:54.042 INFO [carts,55279b5e8192e632,8c77ccf18a9ceab9,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.ItemsController : Did not find item.  (×19)
  10:40:55.439 [front-end] Posting Customer: {"username":"RWEKCzZbyoL","password":"eCgDEu","email":"RWEKCzZbyoL@gmail.com","firstName":"RWEKCzZbyoL","lastName":"RWEKCzZbyoL"}
  10:40:57.337 [orders] 2024-11-23 10:40:57.337 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+jso
  10:40:57.345 [orders] 2024-11-23 10:40:57.345 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[applicatio
  10:40:57.435 [orders] 2024-11-23 10:40:57.435 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicat
  10:40:57.546 [orders] 2024-11-23 10:40:57.546 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http
  10:40:58.821 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  10:40:59.450 [orders] 2024-11-23 10:40:59.450 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=
  10:40:59.540 [orders] 2024-11-23 10:40:59.540 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[app
  10:41:02.850 [front-end] Posting Customer: {"username":"oljxrbkvgRPchx","password":"KICnrSMycj","email":"oljxrbkvgRPchx@gmail.com","firstName":"oljxrbkvgRPchx","lastName":"oljxrbkvgRPch
  10:41:04.149 [orders] 2024-11-23 10:41:04.149 INFO [orders,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering w
  10:41:06.939 [orders] 2024-11-23 10:41:06.843 INFO [orders,,,] 7 --- [p-nio-80-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization starte
  10:41:08.897 [front-end] Received response: "{\"firstName\":\"FoMnUsWRwtr\",\"lastName\":\"FoMnUsWRwtr\",\"username\":\"FoMnUsWRwtr\",\"id\":\"6741b133a437380001df4a8e\",\"_links\":{\"a
  10:41:09.781 [front-end] Posting Customer: {"username":"gzAwltOvrAOlwZ","password":"mvbfevmrG","email":"gzAwltOvrAOlwZ@gmail.com","firstName":"gzAwltOvrAOlwZ","lastName":"gzAwltOvrAOlwZ
  10:41:10.346 [queue-master] 2024-11-23 10:41:10.346 INFO 7 --- [ool-6-thread-24] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×18)
  10:41:10.951 [orders-db] {"t":{"$date":"2024-11-23T10:41:10.951+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:4145  (×10)
  10:41:11.658 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b14601dd390007094dcc","customerId":"6741b12ea437380001df4a7f","customer":{"id":null,"firstName":"vDSVmUfFkYR
  10:41:11.740 [front-end] Order response: {"id":"6741b14601dd390007094dcb","customerId":"6741b135a437380001df4a95","customer":{"id":null,"firstName":"oMOnLjzHZXUV","lastName":"oMOnLjzHZX
  10:41:11.746 [front-end] Order response: {"id":"6741b14601dd390007094dcd","customerId":"6741b133a437380001df4a8d","customer":{"id":null,"firstName":"PMMsVPkCBtB","lastName":"PMMsVPkCBtB
  10:41:13.508 [user] ts=2024-11-23T10:41:13.508595513Z caller=middlewares.go:46 method=Register username=AQxdn email=AQxdn@gmail.com took=2.184408ms
  10:41:15.043 [front-end] Order response: {"id":"6741b14a01dd390007094dd4","customerId":"6741b132a437380001df4a8a","customer":{"id":null,"firstName":"mfkgXqTHaTye","lastName":"mfkgXqTHaT
  10:41:17.757 [front-end] Received response: "{\"firstName\":\"RPAyWJFRkAtx\",\"lastName\":\"RPAyWJFRkAtx\",\"username\":\"RPAyWJFRkAtx\",\"id\":\"6741b138a437380001df4aa1\",\"_links\":{
  10:41:20.018 [front-end] Received response: "{\"firstName\":\"qqkRVDrhVVQ\",\"lastName\":\"qqkRVDrhVVQ\",\"username\":\"qqkRVDrhVVQ\",\"id\":\"6741b138a437380001df4aa2\",\"_links\":{\"a

## p0476
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:15:34.986Z
```
{"timestamp":1732349734986184700,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"set cookie67418f26a437380001def339"}
```
Same service, the 2 minutes before (oldest first):
  08:15:34.292 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f263f77060008865023","customerId":"67418f11a437380001def2ef","customer":{"id":null,"firstName":"xJARrTlidT"
  08:15:34.292 [front-end] Order response: {"id":"67418f263f77060008865023","customerId":"67418f11a437380001def2ef","customer":{"id":null,"firstName":"xJARrTlidT","lastName":"xJARrTlidT",
  08:15:34.294 [front-end] POST /orders 201 - ms - -  (×2)
  08:15:34.444 [front-end] Request received with body: {}
  08:15:34.458 [front-end] Received response: "{\"firstName\":\"WiRsJAISiF\",\"lastName\":\"WiRsJAISiF\",\"username\":\"WiRsJAISiF\",\"id\":\"67418f0da437380001def2df\",\"_links\":{\"addr
  08:15:34.458 [front-end] GET Request to: http://user/customers/67418f0da437380001def2df/addresses  (×2)
  08:15:34.468 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418
  08:15:34.468 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418f17a437380001def2fc\",\"_links\":{\"
  08:15:34.468 [front-end] [ undefined, undefined ]
  08:15:34.468 [front-end] Posting Order: {"customer":"http://user/customers/67418f0da437380001def2df","address":"http://user/addresses/67418f17a437380001def2fb","card":"http://user/cards
  08:15:34.498 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f263f77060008865024","customerId":"67418f0da437380001def2df","customer":{"id":null,"firstName":"WiRsJAISiF"
  08:15:34.498 [front-end] Order response: {"id":"67418f263f77060008865024","customerId":"67418f0da437380001def2df","customer":{"id":null,"firstName":"WiRsJAISiF","lastName":"WiRsJAISiF",
  08:15:34.636 [front-end] GET /catalogue 200 - ms - -
  08:15:34.964 [front-end] Posting Customer: {"username":"wsSPiYybdC","password":"SuhPNOY","email":"wsSPiYybdC@gmail.com","firstName":"wsSPiYybdC","lastName":"wsSPiYybdC"}
  08:15:34.968 [front-end] { id: '67418f26a437380001def339' }
  08:15:34.968 [front-end] 67418f26a437380001def339
  08:15:34.968 [front-end] Merging carts for customer id: 67418f26a437380001def339 and session id: A6vVl0uRISop3GkBJNNOn1cBOD7eDI4W
  08:15:34.986 [front-end] Carts merged.
All services, 30 seconds either side (sampled):
  08:15:05.037 [front-end] Posting Customer: {"username":"IlglDlnCU","password":"TkrjX","email":"IlglDlnCU@gmail.com","firstName":"IlglDlnCU","lastName":"IlglDlnCU"}
  08:15:05.184 [carts] 2024-11-23 08:15:05.184 INFO [carts,00dfa96e985a5757,385a4d501661c894,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×35)
  08:15:05.335 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418efda437380001def2b6\",\"_links\":{\"  (×62)
  08:15:05.363 [queue-master] 2024-11-23 08:15:05.363 INFO 7 --- [ool-6-thread-16] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×47)
  08:15:05.412 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×7)
  08:15:07.554 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×7)
  08:15:10.421 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×11)
  08:15:11.817 [front-end] Received response: "{\"firstName\":\"PaSCOxuwbl\",\"lastName\":\"PaSCOxuwbl\",\"username\":\"PaSCOxuwbl\",\"id\":\"67418ef6a437380001def2a0\",\"_links\":{\"addr
  08:15:15.138 [front-end] Received response: "{\"firstName\":\"KVBrETy\",\"lastName\":\"KVBrETy\",\"username\":\"KVBrETy\",\"id\":\"67418efda437380001def2b9\",\"_links\":{\"addresses\":{
  08:15:17.297 [front-end] Order response: {"id":"67418f153f77060008865015","customerId":"67418f02a437380001def2c5","customer":{"id":null,"firstName":"bKFFvbEPHcpsTL","lastName":"bKFFvbEP
  08:15:18.996 [front-end] Posting Customer: {"username":"SOxnyT","password":"IDjWJGm","email":"SOxnyT@gmail.com","firstName":"SOxnyT","lastName":"SOxnyT"}
  08:15:20.582 [front-end] Received response: "{\"firstName\":\"zdcqqHDfhtQQLd\",\"lastName\":\"zdcqqHDfhtQQLd\",\"username\":\"zdcqqHDfhtQQLd\",\"id\":\"67418f09a437380001def2d8\",\"_lin
  08:15:22.388 [front-end] Received response: "{\"firstName\":\"muoACWUNWYEL\",\"lastName\":\"muoACWUNWYEL\",\"username\":\"muoACWUNWYEL\",\"id\":\"67418f04a437380001def2ca\",\"_links\":{
  08:15:25.236 [front-end] Received response: "{\"firstName\":\"IlglDlnCU\",\"lastName\":\"IlglDlnCU\",\"username\":\"IlglDlnCU\",\"id\":\"67418f09a437380001def2d4\",\"_links\":{\"address
  08:15:30.464 [front-end] Posting Customer: {"username":"sKVdDxEyWH","password":"DvqDBOVR","email":"sKVdDxEyWH@gmail.com","firstName":"sKVdDxEyWH","lastName":"sKVdDxEyWH"}
  08:15:33.213 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f253f77060008865021","customerId":"67418f0fa437380001def2ed","customer":{"id":null,"firstName":"UyUwS","las
  08:15:34.964 [front-end] Posting Customer: {"username":"wsSPiYybdC","password":"SuhPNOY","email":"wsSPiYybdC@gmail.com","firstName":"wsSPiYybdC","lastName":"wsSPiYybdC"}
  08:15:38.246 [front-end] Received response: "{\"firstName\":\"SOxnyT\",\"lastName\":\"SOxnyT\",\"username\":\"SOxnyT\",\"id\":\"67418f16a437380001def2f8\",\"_links\":{\"addresses\":{\"h
  08:15:41.332 [front-end] Received response: "{\"firstName\":\"BLPHB\",\"lastName\":\"BLPHB\",\"username\":\"BLPHB\",\"id\":\"67418f18a437380001def300\",\"_links\":{\"addresses\":{\"href
  08:15:43.281 [front-end] Received response: "{\"firstName\":\"jUjTcjhKorA\",\"lastName\":\"jUjTcjhKorA\",\"username\":\"jUjTcjhKorA\",\"id\":\"67418f1aa437380001def309\",\"_links\":{\"a
  08:15:44.913 [front-end] Received response: "{\"firstName\":\"CsQLjXsNmQ\",\"lastName\":\"CsQLjXsNmQ\",\"username\":\"CsQLjXsNmQ\",\"id\":\"67418f1ca437380001def310\",\"_links\":{\"addr
  08:15:47.637 [front-end] Received response: "{\"firstName\":\"POZhjFoHWBq\",\"lastName\":\"POZhjFoHWBq\",\"username\":\"POZhjFoHWBq\",\"id\":\"67418f19a437380001def308\",\"_links\":{\"a
  08:15:48.711 [front-end] Posting Customer: {"username":"XlGDjSTF","password":"xdbrD","email":"XlGDjSTF@gmail.com","firstName":"XlGDjSTF","lastName":"XlGDjSTF"}
  08:15:52.490 [user] ts=2024-11-23T08:15:52.490011826Z caller=middlewares.go:46 method=Register username=ABYwFPtfW email=ABYwFPtfW@gmail.com took=2.746245ms
  08:15:54.333 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f3a3f77060008865039","customerId":"67418f24a437380001def332","customer":{"id":null,"firstName":"JJmqhUUuz",
  08:15:58.087 [front-end] Received response: "{\"firstName\":\"KqChwVxcGQtO\",\"lastName\":\"KqChwVxcGQtO\",\"username\":\"KqChwVxcGQtO\",\"id\":\"67418f2ca437380001def348\",\"_links\":{
  08:15:59.828 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f3f3f7706000886503e","customerId":"67418f30a437380001def354","customer":{"id":null,"firstName":"RWPOVyQsPfS
  08:16:02.088 [front-end] Received response: "{\"firstName\":\"GtjqrqiyorBsYoL\",\"lastName\":\"GtjqrqiyorBsYoL\",\"username\":\"GtjqrqiyorBsYoL\",\"id\":\"67418f25a437380001def338\",\"_
  08:16:03.943 [front-end] Order response: {"id":"67418f433f77060008865043","customerId":"67418f33a437380001def357","customer":{"id":null,"firstName":"gvjBUszNJaPAe","lastName":"gvjBUszNJ

## p0399
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:46:28.646Z
```
{"timestamp":1732247188646364000,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:46:28.646167563Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffe8db0df5c00019b3180 took=1.71051ms"}
```
Same service, the 2 minutes before (oldest first):
  03:46:26.511 [user] ts=2024-11-22T03:46:26.511349649Z caller=middlewares.go:75 method=GetUsers id=673ffe80b0df5c00019b3159 result=1 took=1.112744ms  (×3)
  03:46:26.511 [user] ts=2024-11-22T03:46:26.511346503Z caller=middlewares.go:134 method=GetCards id=673ffe8ab0df5c00019b317b result=1 took=1.108604ms  (×2)
  03:46:26.511 [user] ts=2024-11-22T03:46:26.511512982Z caller=middlewares.go:104 method=GetAddresses id=673ffe8ab0df5c00019b3176 result=1 took=1.276727ms  (×2)
  03:46:26.921 [user] ts=2024-11-22T03:46:26.921445594Z caller=middlewares.go:46 method=Register username=SGNMlFJX email=SGNMlFJX@gmail.com took=998.659µs
  03:46:26.976 [user] ts=2024-11-22T03:46:26.97658275Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffe88b0df5c00019b3174 took=1.785463ms  (×2)
  03:46:26.990 [user] ts=2024-11-22T03:46:26.990065082Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffe88b0df5c00019b3174 took=1.670605ms
  03:46:27.095 [user] ts=2024-11-22T03:46:27.095193237Z caller=middlewares.go:157 method=Health result=2 took=981.671µs  (×2)
  03:46:27.458 [user] ts=2024-11-22T03:46:27.457886429Z caller=middlewares.go:75 method=GetUsers id=673ffe79b0df5c00019b3143 result=1 took=909.892µs  (×5)
  03:46:27.981 [user] ts=2024-11-22T03:46:27.981683887Z caller=middlewares.go:46 method=Register username=gEqHWvVKGL email=gEqHWvVKGL@gmail.com took=927.359µs
  03:46:28.501 [user] ts=2024-11-22T03:46:28.501519133Z caller=middlewares.go:46 method=Register username=WrRpd email=WrRpd@gmail.com took=1.01114ms
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×27)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×47)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×60)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×48)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×48)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×46)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×46)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×46)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h
  03:46:57.285 [carts] 2024-11-22 03:46:57.285 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr
  03:46:57.791 [user] ts=2024-11-22T03:46:57.791031339Z caller=middlewares.go:46 method=Register username=kHKtAIS email=kHKtAIS@gmail.com took=1.166895ms

## p0172
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:34:38.971Z
```
{"timestamp":1731911678971398400,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  06:34:37.578 [frontend] request complete  (×7)
  06:34:37.982 [frontend] request started  (×6)
  06:34:37.982 [frontend] setting currency
  06:34:37.986 [frontend] home
  06:34:38.033 [frontend] ENV_PLATFORM is: aws
  06:34:38.219 [frontend] view user cart
  06:34:38.605 [frontend] serving product page  (×3)
All services, 30 seconds either side (sampled):
  06:34:09.392 [frontend] request started  (×306)
  06:34:09.401 [cartservice] GetCartAsync called with userId=0ae6d9b6-4e7f-4d38-a0eb-042389dcac30  (×254)
  06:34:09.425 [adservice] received ad request (context_words=[decor, home])  (×17)
  06:34:09.434 [cartservice] AddItemAsync called with userId=0ae6d9b6-4e7f-4d38-a0eb-042389dcac30, productId=0PUK6V6EV0, quantity=10  (×28)
  06:34:09.467 [shippingservice] [GetQuote] completed request  (×75)
  06:34:10.110 [adservice] received ad request (context_words=[clothing, tops])  (×26)
  06:34:10.484 [checkoutservice] [PlaceOrder] user_id="5e004f2d-a61a-45b2-840d-6bfd47a2be43" user_currency="GBP"  (×2)
  06:34:10.519 [checkoutservice] payment went through (transaction_id: bfa71953-daec-48f3-b1e1-73b87a3b9a36)  (×12)
  06:34:10.523 [cartservice] EmptyCartAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43  (×12)
  06:34:10.530 [frontend] order placed  (×12)
  06:34:11.495 [adservice] received ad request (context_words=[])  (×33)
  06:34:17.648 [checkoutservice] [PlaceOrder] user_id="fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a" user_currency="EUR"  (×2)
  06:34:17.680 [emailservice] A request to send order confirmation email to bwells@example.net has been received.
  06:34:17.778 [checkoutservice] order confirmation email sent to "julieperkins@example.com"
  06:34:18.436 [checkoutservice] [PlaceOrder] user_id="b63bea0e-d05f-4589-be71-8fef43557432" user_currency="USD"
  06:34:18.474 [emailservice] A request to send order confirmation email to david72@example.com has been received.
  06:34:23.185 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"1229","nanos":219976114},"credit_card":{"credit_card_number":"4389370295135  (×2)
  06:34:23.201 [checkoutservice] order confirmation email sent to "chris07@example.com"
  06:34:30.275 [paymentservice] Transaction processed: visa ending 0302 Amount: CAD62.853795666  (×2)
  06:34:35.734 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', '2ZYFJ3GM2N']
  06:34:39.059 [emailservice] A request to send order confirmation email to pthompson@example.org has been received.
  06:34:41.359 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"50173","nanos":141089159},"credit_card":{"credit_card_number":"437122483557  (×3)
  06:34:41.372 [checkoutservice] order confirmation email sent to "krivas@example.net"
  06:34:49.143 [emailservice] Traceback (most recent call last): File "/email_server/email_server.py", line 199, in <module> start(dummy_mode = True) File "/email_server/email_server.py", li  (×2)
  06:34:49.784 [checkoutservice] failed to send order confirmation to "jeffrey34@example.net": rpc error: code = Unavailable desc = no healthy upstream

## p0545
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T18:19:30.656Z
```
{"timestamp":1733595570656265200,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-kwkx6","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:19:30.656  INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl       : [Train Service] calculate time：475  time: Sat May 04 07:00:52 GMT 2013"}
```
Same service, the 2 minutes before (oldest first):
  18:19:30.480 [ts-travel2-service] 2024-12-07 18:19:30.480 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×3)
  18:19:30.499 [ts-travel2-service] 2024-12-07 18:19:30.498 INFO 1 --- [io-16346-exec-9] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×3)
  18:19:30.500 [ts-travel2-service] 2024-12-07 18:19:30.500 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×3)
  18:19:30.507 [ts-travel2-service] 2024-12-07 18:19:30.507 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×3)
  18:19:30.508 [ts-travel2-service] 2024-12-07 18:19:30.507 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×3)
  18:19:30.544 [ts-travel2-service] 2024-12-07 18:19:30.544 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  18:19:30.550 [ts-travel2-service] 2024-12-07 18:19:30.549 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  18:19:30.558 [ts-travel2-service] 2024-12-07 18:19:30.558 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  18:19:30.646 [ts-travel2-service] 2024-12-07 18:19:30.646 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6
All services, 30 seconds either side (sampled):
  18:19:00.782 [ts-admin-basic-info-service] 2024-12-07 18:19:00.781 INFO 1 --- [io-18767-exec-9] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×11)
  18:19:01.596 [ts-route-service] 2024-12-07 18:19:01.596 INFO 1 --- [io-11178-exec-8] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×245)
  18:19:01.703 [ts-travel2-service] 2024-12-07 18:19:01.703 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×139)
  18:19:05.562 [ts-basic-service] 2024-12-07 18:19:05.562 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×13)
  18:19:05.619 [ts-order-other-service] 2024-12-07 18:19:05.619 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×3)
  18:19:05.735 [ts-order-other-service] 2024-12-07 18:19:05.735 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×11)
  18:19:06.778 [ts-basic-service] 2024-12-07 18:19:06.778 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×7)
  18:19:07.120 [ts-inside-payment-service] 2024-12-07 18:19:07.119 INFO 1 --- [io-18673-exec-2] i.controller.InsidePaymentController : [Inside Payment Service][Pay] Pay for: e396f188-4000-46aa-b7cb-d41eb
  18:19:12.843 [ts-preserve-other-service] 2024-12-07 18:19:12.843 INFO 1 --- [io-14569-exec-9] p.controller.PreserveOtherController : [Preserve Other Service][Preserve] Account order from Shang Hai ----
  18:19:12.894 [ts-security-service] 2024-12-07 18:19:12.894 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Last One Hour:
  18:19:12.977 [ts-preserve-other-service] 2024-12-07 18:19:12.977 INFO 1 --- [io-14569-exec-9] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Check tickets num
  18:19:13.423 [ts-seat-service] 2024-12-07 18:19:13.422 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×4)
  18:19:14.091 [ts-seat-service] 2024-12-07 18:19:14.091 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService distributeSeat] The request seat type is confortClass and the t  (×2)
  18:19:14.200 [ts-assurance-service] 2024-12-07 18:19:14.199 INFO 1 --- [io-18888-exec-3] assurance.service.AssuranceServiceImpl : [Assurance-Add&Delete-Service][AddAssurance] Success.
  18:19:15.176 [ts-auth-service] 2024-12-07 18:19:15.176 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×3)
  18:19:18.242 [ts-travel-service] 2024-12-07 18:19:18.242 INFO 1 --- [io-12346-exec-1] travel.controller.TravelController : [Travel Service] Query TripResponse  (×3)
  18:19:18.414 [ts-order-service] 2024-12-07 18:19:18.414 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×2)
  18:19:18.680 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:19:18 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 339 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×3)
  18:19:27.387 [ts-price-mongo] {"t":{"$date":"2024-12-07T18:19:27.387+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359556
  18:19:30.042 [ts-travel2-service] 2024-12-07 18:19:30.042 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×2)
  18:19:30.684 [ts-user-mongo] {"t":{"$date":"2024-12-07T18:19:30.684+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359557
  18:19:43.550 [ts-order-service] 2024-12-07 18:19:43.550 INFO 1 --- [io-12031-exec-6] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 29  (×4)
  18:19:43.802 [ts-assurance-service] 2024-12-07 18:19:43.802 INFO 1 --- [io-18888-exec-6] a.controller.AssuranceController : [Assurances Service][Get Assurance Type]
  18:19:43.966 [ts-security-service] 2024-12-07 18:19:43.966 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Last One Hour:
  18:19:44.008 [ts-travel-service] 2024-12-07 18:19:44.008 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  18:19:44.499 [ts-preserve-service] 2024-12-07 18:19:44.498 INFO 1 --- [io-14568-exec-9] preserve.service.PreserveServiceImpl : [Preserve Service][Order] Order Travel Date: Sat Dec 07 00:00:00 GMT
  18:19:44.580 [ts-preserve-service] 2024-12-07 18:19:44.579 INFO 1 --- [io-14568-exec-9] preserve.service.PreserveServiceImpl : [Preserve Service][Step 5] Do not need to buy assurance
  18:19:45.791 [ts-travel2-service] 2024-12-07 18:19:45.791 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236
  18:19:50.742 [ts-basic-service] 2024-12-07 18:19:50.741 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2

## p0778
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-24T13:34:44.072Z
```
{"timestamp":1732455284072788500,"container_name":"front-end","pod_name":"front-end-f77549869-qkdxd","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"timestamp\":1732455284070,\"status\":500,\"error\":\"Internal Server Error\",\"exception\":\"java.lang.IllegalStateException\",\"message\":\"Unable to create order due to unspecified IO error.\",\"path\":\"/orders\"}"}
```
Same service, the 2 minutes before (oldest first):
  13:34:43.598 [front-end] Received response: "{\"firstName\":\"YWpZnJUmRD\",\"lastName\":\"YWpZnJUmRD\",\"username\":\"YWpZnJUmRD\",\"id\":\"67432b63f6d875000161ff70\",\"_links\":{\"addr
  13:34:43.598 [front-end] GET Request to: http://user/customers/67432b63f6d875000161ff70/addresses  (×4)
  13:34:43.611 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67432b6af6d875000161ff88\",\"_links\":{\"  (×2)
  13:34:43.612 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67432  (×2)
  13:34:43.612 [front-end] [ undefined, undefined ]  (×2)
  13:34:43.612 [front-end] Posting Order: {"customer":"http://user/customers/67432b63f6d875000161ff70","address":"http://user/addresses/67432b6af6d875000161ff87","card":"http://user/cards  (×2)
  13:34:43.642 [front-end] Order response: {"statusCode":201,"body":{"id":"67432b73c4380300078a481a","customerId":"67432b63f6d875000161ff70","customer":{"id":null,"firstName":"YWpZnJUmRD"
  13:34:43.642 [front-end] Order response: {"id":"67432b73c4380300078a481a","customerId":"67432b63f6d875000161ff70","customer":{"id":null,"firstName":"YWpZnJUmRD","lastName":"YWpZnJUmRD",
  13:34:43.645 [front-end] POST /orders 201 - ms - -
  13:34:43.922 [front-end] GET /catalogue 200 - ms - -
  13:34:44.018 [front-end] Request received with body: {}
  13:34:44.026 [front-end] Received response: "{\"firstName\":\"MDemFnmhXrGzUDY\",\"lastName\":\"MDemFnmhXrGzUDY\",\"username\":\"MDemFnmhXrGzUDY\",\"id\":\"67432b5af6d875000161ff56\",\"_
  13:34:44.072 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732455284070,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
All services, 30 seconds either side (sampled):
  13:34:14.661 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67432b4cf6d875000161ff2a"}  (×63)
  13:34:14.768 [catalogue] ts=2024-11-24T13:34:14Z caller=logging.go:62 method=Get id=837ab141-399e-4c1f-9abc-bace40296bac sock=837ab141-399e-4c1f-9abc-bace40296bac err=null took=4.954646  (×57)
  13:34:14.984 [front-end] { id: '67432b56f6d875000161ff49' }  (×62)
  13:34:15.078 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×11)
  13:34:15.108 [orders] 2024-11-24 13:34:15.108 INFO [orders,6f679e06869cd015,ac10fa87fc63ae0d,false] 7 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Sending payment req  (×23)
  13:34:15.125 [front-end] Order response: {"id":"67432b57c4380300078a47ff","customerId":"67432b40f6d875000161ff12","customer":{"id":null,"firstName":"dvAjGKJXWbKOMh","lastName":"dvAjGKJX
  13:34:16.934 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×8)
  13:34:20.078 [front-end] Received response: "{\"firstName\":\"luCICjFJFuxH\",\"lastName\":\"luCICjFJFuxH\",\"username\":\"luCICjFJFuxH\",\"id\":\"67432b43f6d875000161ff1b\",\"_links\":{
  13:34:21.110 [front-end] Received response: "{\"firstName\":\"IitGLtRt\",\"lastName\":\"IitGLtRt\",\"username\":\"IitGLtRt\",\"id\":\"67432b43f6d875000161ff1a\",\"_links\":{\"addresses\
  13:34:22.148 [front-end] Order response: {"id":"67432b5ec4380300078a4803","customerId":"67432b47f6d875000161ff20","customer":{"id":null,"firstName":"oaJPSVOc","lastName":"oaJPSVOc","use
  13:34:25.104 [front-end] Received response: "{\"firstName\":\"vUjPhTlme\",\"lastName\":\"vUjPhTlme\",\"username\":\"vUjPhTlme\",\"id\":\"67432b4bf6d875000161ff29\",\"_links\":{\"address
  13:34:26.154 [front-end] Received response: "{\"firstName\":\"fmnCPeuTDwq\",\"lastName\":\"fmnCPeuTDwq\",\"username\":\"fmnCPeuTDwq\",\"id\":\"67432b4ff6d875000161ff33\",\"_links\":{\"a
  13:34:27.386 [front-end] Posting Customer: {"username":"YWpZnJUmRD","password":"sbEFc","email":"YWpZnJUmRD@gmail.com","firstName":"YWpZnJUmRD","lastName":"YWpZnJUmRD"}
  13:34:29.880 [user] ts=2024-11-24T13:34:29.87987189Z caller=middlewares.go:46 method=Register username=wjAbg email=wjAbg@gmail.com took=1.850059ms
  13:34:32.474 [front-end] Received response: "{\"firstName\":\"YrZdGbUyhHu\",\"lastName\":\"YrZdGbUyhHu\",\"username\":\"YrZdGbUyhHu\",\"id\":\"67432b53f6d875000161ff3c\",\"_links\":{\"a
  13:34:33.217 [front-end] Posting Customer: {"username":"noCxsESXBLLVRL","password":"SxKyNjlr","email":"noCxsESXBLLVRL@gmail.com","firstName":"noCxsESXBLLVRL","lastName":"noCxsESXBLLVRL"
  13:34:36.705 [front-end] Order response: {"id":"67432b6cc4380300078a4812","customerId":"67432b55f6d875000161ff45","customer":{"id":null,"firstName":"PoZnzQvKWzrr","lastName":"PoZnzQvKWz
  13:34:39.769 [front-end] Posting Customer: {"username":"GuHwHrmymno","password":"EPZbcSkPfe","email":"GuHwHrmymno@gmail.com","firstName":"GuHwHrmymno","lastName":"GuHwHrmymno"}
  13:34:41.138 [front-end] Received response: "{\"firstName\":\"PYwyezUKdqyfUKi\",\"lastName\":\"PYwyezUKdqyfUKi\",\"username\":\"PYwyezUKdqyfUKi\",\"id\":\"67432b5ef6d875000161ff67\",\"_
  13:34:43.642 [front-end] Order response: {"statusCode":201,"body":{"id":"67432b73c4380300078a481a","customerId":"67432b63f6d875000161ff70","customer":{"id":null,"firstName":"YWpZnJUmRD"
  13:34:46.017 [front-end] POST /cart 500 60.730 ms - 64  (×25)
  13:34:47.840 [user] ts=2024-11-24T13:34:47.840390429Z caller=middlewares.go:46 method=Register username=zrsYINvC email=zrsYINvC@gmail.com took=1.682172ms
  13:34:49.557 [front-end] Posting Customer: {"username":"AfbhiBJ","password":"BwECCt","email":"AfbhiBJ@gmail.com","firstName":"AfbhiBJ","lastName":"AfbhiBJ"}
  13:34:54.204 [carts] 2024-11-24 13:34:54.104 INFO [bootstrap,,,] 7 --- [ main] s.c.a.AnnotationConfigApplicationContext : Refreshing org.springframework.context.annotation.Annotatio
  13:34:58.464 [front-end] Received response: "{\"firstName\":\"YhlNbHKUS\",\"lastName\":\"YhlNbHKUS\",\"username\":\"YhlNbHKUS\",\"id\":\"67432b6af6d875000161ff86\",\"_links\":{\"address
  13:35:01.805 [carts] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  13:35:04.490 [front-end] Posting Customer: {"username":"vmbCNyhUNvSjDE","password":"duSqx","email":"vmbCNyhUNvSjDE@gmail.com","firstName":"vmbCNyhUNvSjDE","lastName":"vmbCNyhUNvSjDE"}
  13:35:08.011 [user] ts=2024-11-24T13:35:08.011362174Z caller=middlewares.go:46 method=Register username=IKvYgtNzw email=IKvYgtNzw@gmail.com took=1.819279ms
  13:35:10.933 [front-end] Posting Customer: {"username":"cvldXPFNlPBL","password":"vubVrTmkL","email":"cvldXPFNlPBL@gmail.com","firstName":"cvldXPFNlPBL","lastName":"cvldXPFNlPBL"}

## p0526
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T10:58:14.867Z
```
{"timestamp":1732359494867528400,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T10:58:14.867429148Z caller=middlewares.go:75 method=GetUsers id=6741b535a437380001df5468 result=1 took=2.307896ms"}
```
Same service, the 2 minutes before (oldest first):
  10:58:10.711 [user] ts=2024-11-23T10:58:10.710936619Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=6741b538a437380001df5469 took=4.720837ms  (×3)
  10:58:10.725 [user] ts=2024-11-23T10:58:10.725705905Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6741b538a437380001df5469 took=3.810876ms  (×3)
  10:58:10.819 [user] ts=2024-11-23T10:58:10.819289252Z caller=middlewares.go:46 method=Register username=wScMVduv email=wScMVduv@gmail.com took=2.911071ms
  10:58:10.848 [user] ts=2024-11-23T10:58:10.848889419Z caller=middlewares.go:157 method=Health result=2 took=2.29858ms  (×4)
  10:58:10.888 [user] ts=2024-11-23T10:58:10.888284398Z caller=middlewares.go:46 method=Register username=NIhXZJjJLUsCq email=NIhXZJjJLUsCq@gmail.com took=2.139829ms  (×4)
  10:58:13.055 [user] ts=2024-11-23T10:58:13.055151044Z caller=middlewares.go:46 method=Register username=WcpWgwhF email=WcpWgwhF@gmail.com took=2.200825ms
  10:58:14.181 [user] ts=2024-11-23T10:58:14.180710733Z caller=middlewares.go:46 method=Register username=joUpLDVGg email=joUpLDVGg@gmail.com took=1.601965ms
  10:58:14.554 [user] ts=2024-11-23T10:58:14.554600165Z caller=middlewares.go:46 method=Register username=eNIubTXdi email=eNIubTXdi@gmail.com took=2.509084ms
  10:58:14.852 [user] ts=2024-11-23T10:58:14.852862371Z caller=middlewares.go:75 method=GetUsers id=6741b535a437380001df5468 result=1 took=1.850271ms  (×2)
All services, 30 seconds either side (sampled):
  10:57:45.384 [catalogue] ts=2024-11-23T10:57:45Z caller=logging.go:85 method=Health result=2 took=31.021µs  (×40)
  10:57:53.940 [front-end] GET /catalogue 200 - ms - -  (×50)
  10:57:57.603 [front-end] 6741b535a437380001df5468  (×21)
  10:57:57.638 [front-end] set cookie6741b535a437380001df5468  (×21)
  10:58:00.663 [carts] 2024-11-23 10:58:00.663 INFO [carts,0de42ae5d773b963,95c349d174013d5e,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×8)
  10:58:02.031 [front-end] Posting Customer: {"username":"TRIBx","password":"psKUl","email":"TRIBx@gmail.com","firstName":"TRIBx","lastName":"TRIBx"}
  10:58:04.648 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b535a437380001df5468"}  (×7)
  10:58:04.675 [user] ts=2024-11-23T10:58:04.674837946Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6741b535a437380001df5468 took=4.342692ms  (×7)
  10:58:04.757 [front-end] DELETE /cart 202 - ms - -  (×7)
  10:58:04.774 [front-end] POST to carts: http://carts/carts/6741b535a437380001df5468/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}  (×4)
  10:58:07.148 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  10:58:07.343 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca
  10:58:08.977 [front-end] Posting Customer: {"username":"pOzMeLaxbALvLyJ","password":"xmCzYil","email":"pOzMeLaxbALvLyJ@gmail.com","firstName":"pOzMeLaxbALvLyJ","lastName":"pOzMeLaxbALvL
  10:58:09.767 [user] ts=2024-11-23T10:58:09.766942866Z caller=middlewares.go:46 method=Register username=nteTFRaAE email=nteTFRaAE@gmail.com took=3.141973ms
  10:58:10.163 [front-end] Posting Customer: {"username":"vpSECXgC","password":"ZrJDPHyp","email":"vpSECXgC@gmail.com","firstName":"vpSECXgC","lastName":"vpSECXgC"}
  10:58:10.822 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata
  10:58:13.048 [front-end] Posting Customer: {"username":"WcpWgwhF","password":"iIirtYMa","email":"WcpWgwhF@gmail.com","firstName":"WcpWgwhF","lastName":"WcpWgwhF"}
  10:58:14.174 [front-end] Posting Customer: {"username":"joUpLDVGg","password":"GXkBHIi","email":"joUpLDVGg@gmail.com","firstName":"joUpLDVGg","lastName":"joUpLDVGg"}
  10:58:14.845 [front-end] Request received with body: {}
  10:58:14.873 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b53ca437380001df546f\",\"_links\":{\"
  10:58:14.890 [user] ts=2024-11-23T10:58:14.890724743Z caller=middlewares.go:104 method=GetAddresses id=6741b53ca437380001df546e result=1 took=1.818989ms
  10:58:14.910 [orders] 2024-11-23 10:58:14.910 INFO [orders,8a17b4e84f8ec2d0,40f87b260ecc2b79,false] 7 --- [p-nio-80-exec-8] w.w.s.o.controllers.OrdersController : Received payment re
  10:58:14.921 [queue-master] 2024-11-23 10:58:14.921 INFO 7 --- [ool-6-thread-22] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×3)
  10:58:14.937 [front-end] Order response: undefined
  10:58:14.948 [front-end] npm timing command:run-script Completed in 39004ms
  10:58:14.949 [front-end] npm notice Changelog: <https://github.com/npm/cli/releases/tag/v10.9.1>
  10:58:14.950 [front-end] npm verb code 1

## p0469
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:12:59.281Z
```
{"timestamp":1732349579281097500,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Request received with body: {}"}
```
Same service, the 2 minutes before (oldest first):
  08:12:57.417 [front-end] Posting Customer: {"username":"fAckD","password":"tSaBmAaqR","email":"fAckD@gmail.com","firstName":"fAckD","lastName":"fAckD"}
  08:12:57.422 [front-end] { id: '67418e89a437380001def16b' }
  08:12:57.422 [front-end] 67418e89a437380001def16b
  08:12:57.422 [front-end] Merging carts for customer id: 67418e89a437380001def16b and session id: 6F6O8rZdE26dJRm5dca5_kieNLcs0a4m
  08:12:57.441 [front-end] Carts merged.
  08:12:57.441 [front-end] set cookie67418e89a437380001def16b
  08:12:57.441 [front-end] Sent cookies.
  08:12:57.444 [front-end] POST /register 200 24.658 ms - 33
  08:12:58.176 [front-end] GET /catalogue 200 - ms - -
  08:12:58.385 [front-end] Request received with body: {}
  08:12:58.395 [front-end] Received response: "{\"firstName\":\"pVrEA\",\"lastName\":\"pVrEA\",\"username\":\"pVrEA\",\"id\":\"67418e73a437380001def118\",\"_links\":{\"addresses\":{\"href
  08:12:58.395 [front-end] GET Request to: http://user/customers/67418e73a437380001def118/addresses  (×2)
  08:12:58.404 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418
  08:12:58.404 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418e7da437380001def138\",\"_links\":{\"
  08:12:58.404 [front-end] [ undefined, undefined ]
  08:12:58.404 [front-end] Posting Order: {"customer":"http://user/customers/67418e73a437380001def118","address":"http://user/addresses/67418e7da437380001def137","card":"http://user/cards
  08:12:58.435 [front-end] Order response: {"statusCode":201,"body":{"id":"67418e8a3f77060008864f94","customerId":"67418e73a437380001def118","customer":{"id":null,"firstName":"pVrEA","las
  08:12:58.435 [front-end] Order response: {"id":"67418e8a3f77060008864f94","customerId":"67418e73a437380001def118","customer":{"id":null,"firstName":"pVrEA","lastName":"pVrEA","username"
  08:12:58.438 [front-end] POST /orders 201 - ms - -
All services, 30 seconds either side (sampled):
  08:12:29.619 [catalogue] ts=2024-11-23T08:12:29Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.569566ms  (×65)
  08:12:29.741 [user] ts=2024-11-23T08:12:29.741634009Z caller=middlewares.go:134 method=GetCards id=67418e5da437380001def0e3 result=1 took=1.844117ms  (×56)
  08:12:29.759 [queue-master] 2024-11-23 08:12:29.758 ERROR 7 --- [ool-6-thread-28] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×41)
  08:12:29.848 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×58)
  08:12:31.050 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  08:12:32.320 [front-end] 67418e70a437380001def111  (×60)
  08:12:34.142 [front-end] Received response: "{\"firstName\":\"mVqIxIRuWDsUkh\",\"lastName\":\"mVqIxIRuWDsUkh\",\"username\":\"mVqIxIRuWDsUkh\",\"id\":\"67418e5aa437380001def0d5\",\"_lin
  08:12:35.155 [user] ts=2024-11-23T08:12:35.154753238Z caller=middlewares.go:46 method=Register username=pVrEA email=pVrEA@gmail.com took=2.234383ms
  08:12:38.506 [payment] ts=2024-11-23T08:12:38Z caller=logging.go:29 method=Authorise result=true took=1.133µs  (×10)
  08:12:40.296 [front-end] Posting Customer: {"username":"fPLAVX","password":"dHckIywL","email":"fPLAVX@gmail.com","firstName":"fPLAVX","lastName":"fPLAVX"}
  08:12:41.176 [front-end] Received response: "{\"firstName\":\"iPAScbOlgcB\",\"lastName\":\"iPAScbOlgcB\",\"username\":\"iPAScbOlgcB\",\"id\":\"67418e62a437380001def0f4\",\"_links\":{\"a
  08:12:43.915 [front-end] Received response: "{\"firstName\":\"audJHn\",\"lastName\":\"audJHn\",\"username\":\"audJHn\",\"id\":\"67418e67a437380001def0fe\",\"_links\":{\"addresses\":{\"h
  08:12:45.715 [front-end] Posting Customer: {"username":"vlmtKMXqHWhKvY","password":"eYVhQXhRgX","email":"vlmtKMXqHWhKvY@gmail.com","firstName":"vlmtKMXqHWhKvY","lastName":"vlmtKMXqHWhKv
  08:12:48.372 [user] ts=2024-11-23T08:12:48.372475603Z caller=middlewares.go:46 method=Register username=NhFru email=NhFru@gmail.com took=2.56014ms
  08:12:52.319 [user] ts=2024-11-23T08:12:52.319493584Z caller=middlewares.go:46 method=Register username=VSYuzVK email=VSYuzVK@gmail.com took=2.068162ms
  08:12:54.314 [front-end] Order response: {"statusCode":201,"body":{"id":"67418e863f77060008864f93","customerId":"67418e71a437380001def112","customer":{"id":null,"firstName":"lhQrwepbLYU
  08:12:58.395 [front-end] Received response: "{\"firstName\":\"pVrEA\",\"lastName\":\"pVrEA\",\"username\":\"pVrEA\",\"id\":\"67418e73a437380001def118\",\"_links\":{\"addresses\":{\"href
  08:13:00.211 [front-end] Posting Customer: {"username":"EkDUiWSoOR","password":"JLPURWT","email":"EkDUiWSoOR@gmail.com","firstName":"EkDUiWSoOR","lastName":"EkDUiWSoOR"}
  08:13:02.795 [front-end] Order response: {"id":"67418e8e3f77060008864f99","customerId":"67418e72a437380001def117","customer":{"id":null,"firstName":"mUpYCp","lastName":"mUpYCp","usernam
  08:13:03.521 [front-end] Received response: "{\"firstName\":\"AaGMGNITyt\",\"lastName\":\"AaGMGNITyt\",\"username\":\"AaGMGNITyt\",\"id\":\"67418e76a437380001def121\",\"_links\":{\"addr
  08:13:06.240 [front-end] Order response: {"id":"67418e923f77060008864f9e","customerId":"67418e82a437380001def149","customer":{"id":null,"firstName":"KTZfCCIyQimS","lastName":"KTZfCCIyQi
  08:13:08.487 [front-end] Order response: {"id":"67418e943f77060008864fa1","customerId":"67418e7ba437380001def132","customer":{"id":null,"firstName":"RWuPBdLEPSNm","lastName":"RWuPBdLEPS
  08:13:09.551 [front-end] Received response: "{\"firstName\":\"qgNtEzD\",\"lastName\":\"qgNtEzD\",\"username\":\"qgNtEzD\",\"id\":\"67418e88a437380001def165\",\"_links\":{\"addresses\":{
  08:13:12.914 [user] ts=2024-11-23T08:13:12.914195511Z caller=middlewares.go:46 method=Register username=mBTdUPYnx email=mBTdUPYnx@gmail.com took=3.404779ms
  08:13:15.454 [front-end] Order response: {"statusCode":201,"body":{"id":"67418e9b3f77060008864faa","customerId":"67418e87a437380001def15e","customer":{"id":null,"firstName":"otXPBnhRRym
  08:13:18.504 [front-end] Order response: {"id":"67418e9e3f77060008864fab","customerId":"67418e83a437380001def150","customer":{"id":null,"firstName":"KHfKzcdRgeZYbrk","lastName":"KHfKzcd
  08:13:19.608 [front-end] Posting Customer: {"username":"oXhrzHnpKINysts","password":"zYXIAQ","email":"oXhrzHnpKINysts@gmail.com","firstName":"oXhrzHnpKINysts","lastName":"oXhrzHnpKINyst
  08:13:21.222 [front-end] Order response: {"id":"67418ea13f77060008864fb1","customerId":"67418e88a437380001def168","customer":{"id":null,"firstName":"wanUWFGCf","lastName":"wanUWFGCf","u
  08:13:25.398 [front-end] Posting Customer: {"username":"gozJp","password":"TumPS","email":"gozJp@gmail.com","firstName":"gozJp","lastName":"gozJp"}
  08:13:29.235 [front-end] Received response: "{\"firstName\":\"cmUECnHNrXiNG\",\"lastName\":\"cmUECnHNrXiNG\",\"username\":\"cmUECnHNrXiNG\",\"id\":\"67418e94a437380001def185\",\"_links\
