## p0573
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:01.962Z
```
{"timestamp":1733596261962266000,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:01.962  INFO 1 --- [           main] o.s.w.s.handler.SimpleUrlHandlerMapping  : Mapped URL path [/**] onto handler of type [class org.springframework.web.servlet.resource.ResourceHttpRequestHandler]"}
```
Same service, the 2 minutes before (oldest first):
  18:30:49.764 [ts-auth-service] 2024-12-07 18:30:49.764 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  18:30:51.479 [ts-auth-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  18:30:51.661 [ts-auth-service] 2024-12-07 18:30:51.661 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClust
  18:30:51.661 [ts-auth-service] 2024-12-07 18:30:51.661 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-auth-mongo:27017 to client view of cluster
  18:30:52.554 [ts-auth-service] 2024-12-07 18:30:52.553 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:20}] to ts-auth-m
  18:30:52.557 [ts-auth-service] 2024-12-07 18:30:52.557 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip
  18:30:52.562 [ts-auth-service] 2024-12-07 18:30:52.561 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  18:30:53.685 [ts-auth-service] 2024-12-07 18:30:53.678 INFO 1 --- [ main] auth.AuthApplication : Starting AuthApplication v1.0 on ts-auth-service-75dfb9459b-ctqkr with PID 1 (/app/ts-auth-ser
  18:30:53.685 [ts-auth-service] 2024-12-07 18:30:53.685 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default
  18:30:54.486 [ts-auth-service] 2024-12-07 18:30:54.485 INFO 1 --- [ main] ationConfigEmbeddedWebApplicationContext : Refreshing org.springframework.boot.context.embedded.AnnotationConfigEmbed
  18:31:00.863 [ts-auth-service] 2024-12-07 18:31:00.862 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  18:31:01.562 [ts-auth-service] 2024-12-07 18:31:01.562 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/hello],methods=[GET]}" onto public java.lang.Objec
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users],methods=[GET]}" onto public org.springframework.h
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/{userId}],methods=[DELETE]}" onto public org.sprin
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  18:31:01.654 [ts-auth-service] 2024-12-07 18:31:01.653 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth/hello],methods=[GET]}" onto public java.lang.String
  18:31:01.654 [ts-auth-service] 2024-12-07 18:31:01.653 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth],methods=[POST]}" onto public org.springframework.h
  18:31:01.656 [ts-auth-service] 2024-12-07 18:31:01.655 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  18:31:01.656 [ts-auth-service] 2024-12-07 18:31:01.655 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  18:31:01.962 [ts-auth-service] 2024-12-07 18:31:01.961 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.springframewo
All services, 30 seconds either side (sampled):
  18:30:31.978 [ts-order-service] 2024-12-07 18:30:31.953 ERROR 1 --- [io-12031-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  18:30:37.721 [ts-basic-service] 2024-12-07 18:30:37.721 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×72)
  18:30:37.796 [ts-basic-service] 2024-12-07 18:30:37.795 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×7)
  18:30:37.827 [ts-travel2-service] 2024-12-07 18:30:37.827 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×11)
  18:30:37.914 [ts-seat-service] 2024-12-07 18:30:37.913 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×18)
  18:30:39.560 [ts-auth-service] 2024-12-07 18:30:39.559 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'taskScheduler' has been explicitly defined. Therefore, a de  (×2)
  18:30:40.513 [ts-travel2-service] 2024-12-07 18:30:40.513 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×2)
  18:30:41.368 [ts-auth-service] 2024-12-07 18:30:41.368 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.method.configuration.  (×2)
  18:30:42.223 [ts-train-mongo] {"t":{"$date":"2024-12-07T18:30:42.223+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359624
  18:30:42.457 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:30:42 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 3056 "-" "Mozilla/5.0 (Macintosh;  (×2)
  18:30:47.136 [ts-travel-service] 2024-12-07 18:30:47.136 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×9)
  18:30:47.220 [ts-basic-service] 2024-12-07 18:30:47.220 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou  (×3)
  18:30:47.287 [ts-travel-service] 2024-12-07 18:30:47.287 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha
  18:30:49.764 [ts-auth-service] 2024-12-07 18:30:49.764 INFO 1 --- [ost-startStop-1] .s.DelegatingFilterProxyRegistrationBean : Mapping filter: 'springSecurityFilterChain' to: [/*]
  18:30:53.685 [ts-auth-service] 2024-12-07 18:30:53.678 INFO 1 --- [ main] auth.AuthApplication : Starting AuthApplication v1.0 on ts-auth-service-75dfb9459b-ctqkr with PID 1 (/app/ts-auth-ser
  18:30:57.149 [ts-basic-service] 2024-12-07 18:30:57.148 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×3)
  18:31:01.562 [ts-auth-service] 2024-12-07 18:31:01.562 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/hello],methods=[GET]}" onto public java.lang.Objec
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  18:31:03.871 [ts-auth-service] 2024-12-07 18:31:03.871 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  18:31:04.637 [ts-seat-service] 2024-12-07 18:31:04.637 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.467 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : started _org.springframework.integration.errorLogger
  18:31:11.720 [ts-order-service] 2024-12-07 18:31:11.720 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : Left ticket info is empty  (×5)
  18:31:12.412 [ts-travel-service] 2024-12-07 18:31:12.412 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1236
  18:31:19.258 [ts-auth-service] 2024-12-07 18:31:19.257 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×7)
  18:31:21.809 [ts-order-other-service] 2024-12-07 18:31:21.808 ERROR 1 --- [io-12032-exec-4] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:31:28.268 [ts-admin-travel-service] 2024-12-07 18:31:28.268 ERROR 1 --- [io-16114-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:31:29.897 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T18:31:29.896+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:31.065 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice

## p0692
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-12T11:15:59.503Z
```
{"service":"webservice2","message":"2021-08-12 11:15:59,503 | INFO | 0.0.0.3 | 172.17.0.4 | webservice2 | 92166aab7d45505b | complete information: {'uuid': '9db0d5f0-fb1b-11eb-a8ba-0242ac110004', 'user_id': 'NxPGARft'}"}
```
Same service, the 2 minutes before (oldest first):
  11:15:54.596 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×3)
  11:15:54.596 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
  11:15:57.247 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  11:15:57.247 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×3)
  11:15:57.248 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '9c735fdc-fb1b-11eb-afb5-0242ac110004', 'value': '', 'ex': 10}  (×3)
  11:15:57.291 [webservice2] INFO uuid: 9c735fdc-fb1b-11eb-afb5-0242ac110004 write redis successfully  (×3)
  11:15:57.395 [webservice2] INFO complete information: {'uuid': '9c735fdc-fb1b-11eb-afb5-0242ac110004', 'user_id': 'GBzXyJft'}  (×2)
All services, 30 seconds either side (sampled):
  11:15:30.295 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×40)
  11:15:30.467 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×39)
  11:15:30.751 [redisservice2] INFO redis write success  (×85)
  11:15:30.869 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '8c62d1f4-fb1b-11eb-9323-0242ac110004', 'user_id': 'irpbvSZq'}  (×80)
  11:15:31.001 [dbservice2] INFO query = select passwards from username_table where user_name='irpbvSZq'  (×31)
  11:15:33.026 [webservice1] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×41)
  11:15:33.659 [redisservice2] INFO redis读取信息成功, status_code: 200  (×43)
  11:15:34.389 [dbservice2] INFO 8e5c20b4-fb1b-11eb-9492-0242ac110004-ImYCctrK-Dg=z2:JN3pmH token generate success token=MTYyODczODEzNC4zODkzNTQ1OjhlNWMyMGI0LWZiMWItMTFlYi05NDkyLTAyNDJhYzE
  11:15:35.004 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×42)
  11:15:36.645 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×51)
  11:15:38.356 [mobservice2] INFO info 90fa17b8-fb1b-11eb-af7a-0242ac110003:ycKvOJwP write success
  11:15:40.784 [dbservice1] INFO 921a3be6-fb1b-11eb-8f3d-0242ac110003-tJwGvlrd-_X.0m+hp>Z-/ token generate success token=MTYyODczODE0MC43ODQzODg1OjkyMWEzYmU2LWZiMWItMTFlYi04ZjNkLTAyNDJhYzE
  11:15:42.892 [mobservice1] INFO info 93ac0502-fb1b-11eb-9332-0242ac110004:rXbZtUoM write success
  11:15:45.670 [dbservice2] INFO 94f65750-fb1b-11eb-b054-0242ac110003-UNSufgGV-/vKh_Vz$jr.C token generate success token=MTYyODczODE0NS42Njk2MTEyOjk0ZjY1NzUwLWZiMWItMTFlYi1iMDU0LTAyNDJhYzE
  11:15:48.435 [dbservice2] INFO 96a31796-fb1b-11eb-b984-0242ac110004-nlMAOLaH-.+x$_%GPZ*lV token generate success token=MTYyODczODE0OC40MzQ2NjAyOjk2YTMxNzk2LWZiMWItMTFlYi1iOTg0LTAyNDJhYzE
  11:15:50.577 [mobservice1] INFO info 983f551a-fb1b-11eb-9955-0242ac110004:jdpqWsnu write success
  11:15:53.073 [dbservice2] INFO 9953f49c-fb1b-11eb-981a-0242ac110003-rJNyXqRj-p$^%8M<usL@t token generate success token=MTYyODczODE1My4wNzI5NTA2Ojk5NTNmNDljLWZiMWItMTFlYi05ODFhLTAyNDJhYzE
  11:15:56.042 [dbservice1] INFO 9b45f8b8-fb1b-11eb-ab0f-0242ac110003-rpjRlDAu-{db}FToam8uK token generate success token=MTYyODczODE1Ni4wNDI1MTAzOjliNDVmOGI4LWZiMWItMTFlYi1hYjBmLTAyNDJhYzE
  11:15:59.256 [dbservice1] INFO 9d43d658-fb1b-11eb-8478-0242ac110004-LcFMmKnX-_%6c#hHYeQa{ token generate success token=MTYyODczODE1OS4yNTY1NjQ2OjlkNDNkNjU4LWZiMWItMTFlYi04NDc4LTAyNDJhYzE
  11:16:01.227 [mobservice1] INFO info 9e99992a-fb1b-11eb-be3a-0242ac110003:ocwNidgD write success
  11:16:03.449 [dbservice1] INFO 9f98c12a-fb1b-11eb-8b74-0242ac110003-lvCfjILw-D1@9U_jQh_$a token generate success token=MTYyODczODE2My40NDg5MDU1OjlmOThjMTJhLWZiMWItMTFlYi04Yjc0LTAyNDJhYzE
  11:16:06.035 [dbservice1] INFO a11b47ac-fb1b-11eb-950c-0242ac110003-SBgdrmlT-HkpM0UVa+&9- token generate success token=MTYyODczODE2Ni4wMzU0NzI2OmExMWI0N2FjLWZiMWItMTFlYi05NTBjLTAyNDJhYzE
  11:16:08.668 [mobservice1] INFO info a305592c-fb1b-11eb-ac4f-0242ac110004:QurEfLHx write success
  11:16:11.615 [mobservice2] INFO info a4d0ec08-fb1b-11eb-95ac-0242ac110004:IKAZGYCc write success
  11:16:14.827 [dbservice1] INFO a5ffab50-fb1b-11eb-bb5a-0242ac110003-IToaCVWE-}<7sLbog{2vF token generate success token=MTYyODczODE3NC44MjcwMzMzOmE1ZmZhYjUwLWZiMWItMTFlYi1iYjVhLTAyNDJhYzE
  11:16:17.295 [dbservice1] INFO a7ec1930-fb1b-11eb-a199-0242ac110003-xVDzUigO-B^s:FwmVgy>_ token generate success token=MTYyODczODE3Ny4yOTU0ODE0OmE3ZWMxOTMwLWZiMWItMTFlYi1hMTk5LTAyNDJhYzE
  11:16:20.041 [mobservice1] INFO info a9ceac86-fb1b-11eb-959d-0242ac110004:hBdYEDwt write success
  11:16:22.320 [mobservice1] INFO info ab2c26bc-fb1b-11eb-b8bd-0242ac110004:URvXGzml write success
  11:16:26.123 [mobservice2] INFO info ad6c2f76-fb1b-11eb-859a-0242ac110003:fLyAPDBT write success
  11:16:28.649 [mobservice2] INFO info aeec7950-fb1b-11eb-84f0-0242ac110003:eHFMUigu write success

## p0113
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T05:14:50.746Z
```
{"timestamp":1731906890746418000,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-sd8v2","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  05:14:49.431 [currencyservice] conversion request successful  (×16)
  05:14:49.806 [currencyservice] Getting supported currencies...  (×4)
All services, 30 seconds either side (sampled):
  05:14:21.122 [frontend] request started  (×325)
  05:14:21.129 [cartservice] GetCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×269)
  05:14:21.151 [shippingservice] [GetQuote] completed request  (×79)
  05:14:21.171 [frontend] request complete  (×325)
  05:14:21.340 [frontend] ENV_PLATFORM is: aws  (×39)
  05:14:22.688 [frontend] adding to cart  (×36)
  05:14:24.501 [adservice] received ad request (context_words=[decor, home])  (×10)
  05:14:26.858 [adservice] received ad request (context_words=[hair, beauty])  (×17)
  05:14:42.546 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"261","nanos":256081385},"credit_card":{"credit_card_number":"47478464233859  (×2)
  05:14:42.550 [shippingservice] [ShipOrder] received request  (×8)
  05:14:42.560 [emailservice] A request to send order confirmation email to dianaobrien@example.net has been received.
  05:14:43.523 [checkoutservice] [PlaceOrder] user_id="c216dec4-2181-4773-8cc5-aa587ee59fcc" user_currency="TRY"
  05:14:43.552 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', '6E92ZMYYFZ', '9SIQT8TOJO']
  05:14:43.650 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="GBP"  (×3)
  05:14:43.711 [emailservice] A request to send order confirmation email to joshuahenderson@example.com has been received.
  05:14:53.589 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"1861","nanos":714172491},"credit_card":{"credit_card_number":"4476090273543
  05:14:53.604 [checkoutservice] order confirmation email sent to "kimberly02@example.net"
  05:15:02.368 [checkoutservice] order confirmation email sent to "beckyanderson@example.net"
  05:15:06.051 [checkoutservice] order confirmation email sent to "nicholas22@example.com"
  05:15:15.732 [checkoutservice] [PlaceOrder] user_id="adf41e5f-12f6-4c40-88a0-a1bcf421e416" user_currency="JPY"
  05:15:15.799 [emailservice] A request to send order confirmation email to ramirezcrystal@example.org has been received.

## p0808
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-08T09:16:24.280Z
```
{"timestamp":1733649384280670700,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h4k7r","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-08 09:16:24.280  INFO 1 --- [           main] o.s.i.channel.PublishSubscribeChannel    : Channel 'ts-auth-service:12340.errorChannel' has 1 subscriber(s)."}
```
Same service, the 2 minutes before (oldest first):
  09:16:18.391 [ts-auth-service] 2024-12-08 09:16:18.391 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/vnd.spring-
  09:16:18.391 [ts-auth-service] 2024-12-08 09:16:18.391 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  09:16:18.392 [ts-auth-service] 2024-12-08 09:16:18.392 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/auditevents || /auditevents.json],methods=[GET],produces=[applicati
  09:16:18.478 [ts-auth-service] 2024-12-08 09:16:18.478 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  09:16:18.479 [ts-auth-service] 2024-12-08 09:16:18.478 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  09:16:18.479 [ts-auth-service] 2024-12-08 09:16:18.479 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  09:16:18.480 [ts-auth-service] 2024-12-08 09:16:18.479 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  09:16:18.480 [ts-auth-service] 2024-12-08 09:16:18.480 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
  09:16:18.592 [ts-auth-service] 2024-12-08 09:16:18.592 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.boot.actuate.autoconfigure.Manageme
  09:16:19.590 [ts-auth-service] 2024-12-08 09:16:19.590 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.embedded.A
  09:16:19.996 [ts-auth-service] 2024-12-08 09:16:19.995 INFO 1 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in globalExceptionHandler
  09:16:21.053 [ts-auth-service] 2024-12-08 09:16:21.053 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 12340 (http)
  09:16:21.359 [ts-auth-service] 2024-12-08 09:16:21.358 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  09:16:21.359 [ts-auth-service] 2024-12-08 09:16:21.359 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43
  09:16:21.885 [ts-auth-service] 2024-12-08 09:16:21.885 INFO 1 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 'taskScheduler'
  09:16:22.457 [ts-auth-service] 2024-12-08 09:16:22.456 INFO 1 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  09:16:22.457 [ts-auth-service] 2024-12-08 09:16:22.456 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 19995 ms
  09:16:23.696 [ts-auth-service] 2024-12-08 09:16:23.695 INFO 1 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  09:16:23.882 [ts-auth-service] 2024-12-08 09:16:23.881 INFO 1 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  09:16:24.280 [ts-auth-service] 2024-12-08 09:16:24.280 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : Adding {logging-channel-adapter:_org.springframework.integration.errorLogger} as
All services, 30 seconds either side (sampled):
  09:15:54.593 [ts-auth-service] 2024-12-08 09:15:54.593 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def  (×2)
  09:15:57.091 [ts-auth-service] 2024-12-08 09:15:57.091 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact  (×2)
  09:15:57.362 [ts-basic-service] 2024-12-08 09:15:57.362 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×7)
  09:15:57.395 [ts-basic-service] 2024-12-08 09:15:57.395 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×35)
  09:15:57.459 [ts-seat-service] 2024-12-08 09:15:57.458 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×17)
  09:15:57.501 [ts-seat-service] 2024-12-08 09:15:57.500 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×17)
  09:15:57.602 [ts-travel2-service] 2024-12-08 09:15:57.602 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6  (×7)
  09:16:01.487 [ts-auth-service] 2024-12-08 09:16:01.487 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]  (×2)
  09:16:01.679 [ts-travel-service] 2024-12-08 09:16:01.679 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×2)
  09:16:01.737 [ts-basic-service] 2024-12-08 09:16:01.737 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×2)
  09:16:01.754 [ts-basic-service] 2024-12-08 09:16:01.754 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
  09:16:01.805 [ts-travel-service] 2024-12-08 09:16:01.805 INFO 1 --- [io-12346-exec-8] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×5)
  09:16:01.993 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:16:01 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 403 148 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)  (×3)
  09:16:04.787 [ts-auth-service] 2024-12-08 09:16:04.787 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]  (×2)
  09:16:09.507 [ts-order-mongo] {"t":{"$date":"2024-12-08T09:16:09.507+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364936
  09:16:10.201 [ts-travel-mongo] {"t":{"$date":"2024-12-08T09:16:10.200+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364937
  09:16:11.861 [ts-price-mongo] {"t":{"$date":"2024-12-08T09:16:11.861+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364937
  09:16:15.283 [ts-auth-service] 2024-12-08 09:16:15.283 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  09:16:16.289 [ts-auth-service] 2024-12-08 09:16:16.289 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.springframewo
  09:16:18.389 [ts-auth-service] 2024-12-08 09:16:18.389 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/vnd.spring-boot.
  09:16:18.480 [ts-auth-service] 2024-12-08 09:16:18.479 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  09:16:21.091 [ts-travel2-service] 2024-12-08 09:16:21.091 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  09:16:21.903 [ts-basic-service] 2024-12-08 09:16:21.903 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4
  09:16:22.165 [ts-food-service] 2024-12-08 09:16:22.165 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  09:16:24.588 [ts-auth-service] 2024-12-08 09:16:24.588 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 12340 (http)
  09:16:28.028 [ts-basic-service] 2024-12-08 09:16:28.028 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  09:16:33.094 [ts-auth-service] 2024-12-08 09:16:33.094 INFO 1 --- [io-12340-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  09:16:35.389 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:16:35 +0800] "POST /api/v1/users/login HTTP/1.1" 200 134 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×10)
  09:16:36.428 [ts-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  09:16:42.045 [ts-order-service] 2024-12-08 09:16:42.044 ERROR 1 --- [io-12031-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)

## p0377
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:41:46.262Z
```
{"timestamp":1732246906262704000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST to carts: http://carts/carts/673ffd75b0df5c00019b2e27/items body: {\"itemId\":\"03fef6ac-1896-4ce8-bd69-b798f85c6e0b\",\"unitPrice\":99.99}"}
```
Same service, the 2 minutes before (oldest first):
  03:41:45.233 [front-end] Order response: {"id":"673ffd79d94b9000069b4765","customerId":"673ffd67b0df5c00019b2df4","customer":{"id":null,"firstName":"rCsCUOWahk","lastName":"rCsCUOWahk",
  03:41:45.235 [front-end] POST /orders 201 - ms - -
  03:41:46.128 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffd75b0df5c00019b2e27"}
  03:41:46.136 [front-end] POST /addresses 200 - ms - -
  03:41:46.173 [front-end] GET /catalogue 200 - ms - -
  03:41:46.179 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffd75b0df5c00019b2e27"}
  03:41:46.187 [front-end] POST /cards 200 - ms - -
  03:41:46.231 [front-end] Attempting to delete cart for user: 673ffd75b0df5c00019b2e27
  03:41:46.239 [front-end] Request received with body: {}
  03:41:46.245 [front-end] Received response: "{\"firstName\":\"NqeGftHRvMF\",\"lastName\":\"NqeGftHRvMF\",\"username\":\"NqeGftHRvMF\",\"id\":\"673ffd63b0df5c00019b2de7\",\"_links\":{\"a
  03:41:46.245 [front-end] GET Request to: http://user/customers/673ffd63b0df5c00019b2de7/addresses  (×2)
  03:41:46.249 [front-end] User cart deleted with status: 202
  03:41:46.250 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffd6bb0df5c00019b2e02\",\"_links\":{\"
  03:41:46.251 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:41:46.251 [front-end] [ undefined, undefined ]
  03:41:46.251 [front-end] Posting Order: {"customer":"http://user/customers/673ffd63b0df5c00019b2de7","address":"http://user/addresses/673ffd6bb0df5c00019b2e01","card":"http://user/cards
  03:41:46.251 [front-end] DELETE /cart 202 - ms - -
  03:41:46.256 [front-end] Attempting to add to cart: {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","quantity":1}
  03:41:46.262 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
All services, 30 seconds either side (sampled):
  03:41:16.340 [front-end] Request received with body: {}  (×61)
  03:41:16.372 [payment] ts=2024-11-22T03:41:16Z caller=logging.go:29 method=Authorise result=true took=1.249µs  (×17)
  03:41:16.626 [user] ts=2024-11-22T03:41:16.625808986Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffd54b0df5c00019b2dbf took=1.706561ms  (×59)
  03:41:16.746 [carts] 2024-11-22 03:41:16.746 INFO [carts,9286b6b982121d0b,f19176d7dab91317,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.ItemsController : Did not find item.  (×29)
  03:41:16.870 [front-end] Posting Customer: {"username":"lXeWgosqTxFxsGj","password":"KglEX","email":"lXeWgosqTxFxsGj@gmail.com","firstName":"lXeWgosqTxFxsGj","lastName":"lXeWgosqTxFxsGj
  03:41:16.940 [front-end] Posting Customer: {"username":"MjDsOwvGGOjr","password":"DPfZe","email":"MjDsOwvGGOjr@gmail.com","firstName":"MjDsOwvGGOjr","lastName":"MjDsOwvGGOjr"}
  03:41:17.588 [front-end] Posting Customer: {"username":"DUpcyDDzm","password":"OsviickztE","email":"DUpcyDDzm@gmail.com","firstName":"DUpcyDDzm","lastName":"DUpcyDDzm"}
  03:41:19.322 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd5fd94b9000069b474f","customerId":"673ffd46b0df5c00019b2d8b","customer":{"id":null,"firstName":"caRRmJjQ","
  03:41:22.571 [front-end] Received response: "{\"firstName\":\"ctQSXUnuKjxCpou\",\"lastName\":\"ctQSXUnuKjxCpou\",\"username\":\"ctQSXUnuKjxCpou\",\"id\":\"673ffd4eb0df5c00019b2dac\",\"_
  03:41:23.109 [user] ts=2024-11-22T03:41:23.108806116Z caller=middlewares.go:46 method=Register username=rjRiwr email=rjRiwr@gmail.com took=1.040005ms
  03:41:25.821 [front-end] Order response: {"id":"673ffd65d94b9000069b4754","customerId":"673ffd54b0df5c00019b2dbf","customer":{"id":null,"firstName":"hHrCFaDHpNUkNyX","lastName":"hHrCFaD
  03:41:28.121 [front-end] Received response: "{\"firstName\":\"sGNOxnGtnEaCQ\",\"lastName\":\"sGNOxnGtnEaCQ\",\"username\":\"sGNOxnGtnEaCQ\",\"id\":\"673ffd4db0df5c00019b2dab\",\"_links\
  03:41:29.536 [front-end] Posting Customer: {"username":"SanQLyRnEUI","password":"pjjjWZiM","email":"SanQLyRnEUI@gmail.com","firstName":"SanQLyRnEUI","lastName":"SanQLyRnEUI"}
  03:41:32.178 [front-end] Received response: "{\"firstName\":\"MjDsOwvGGOjr\",\"lastName\":\"MjDsOwvGGOjr\",\"username\":\"MjDsOwvGGOjr\",\"id\":\"673ffd5cb0df5c00019b2dd7\",\"_links\":{
  03:41:35.949 [front-end] Posting Customer: {"username":"cweIZu","password":"ZhpVbvmC","email":"cweIZu@gmail.com","firstName":"cweIZu","lastName":"cweIZu"}
  03:41:39.129 [user] ts=2024-11-22T03:41:39.12976045Z caller=middlewares.go:46 method=Register username=mHIUg email=mHIUg@gmail.com took=934.142µs
  03:41:41.510 [payment] ts=2024-11-22T03:41:41Z caller=logging.go:29 method=Authorise result=false took=7.318µs  (×5)
  03:41:43.364 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd77d94b9000069b4763","customerId":"673ffd61b0df5c00019b2de0","customer":{"id":null,"firstName":"mQgMWsV","l
  03:41:46.280 [front-end] Order response: {"id":"673ffd7ad94b9000069b4766","customerId":"673ffd63b0df5c00019b2de7","customer":{"id":null,"firstName":"NqeGftHRvMF","lastName":"NqeGftHRvMF
  03:41:50.825 [front-end] Received response: "{\"firstName\":\"CfAFyQ\",\"lastName\":\"CfAFyQ\",\"username\":\"CfAFyQ\",\"id\":\"673ffd6eb0df5c00019b2e15\",\"_links\":{\"addresses\":{\"h
  03:41:52.197 [front-end] Received response: "{\"firstName\":\"cweIZu\",\"lastName\":\"cweIZu\",\"username\":\"cweIZu\",\"id\":\"673ffd6fb0df5c00019b2e16\",\"_links\":{\"addresses\":{\"h
  03:41:54.397 [front-end] Received response: "{\"firstName\":\"cYdcmnMFITFX\",\"lastName\":\"cYdcmnMFITFX\",\"username\":\"cYdcmnMFITFX\",\"id\":\"673ffd6eb0df5c00019b2e10\",\"_links\":{
  03:41:56.766 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd84d94b9000069b4772","customerId":"673ffd76b0df5c00019b2e2f","customer":{"id":null,"firstName":"EynITfZQyPG
  03:41:58.230 [front-end] Posting Customer: {"username":"yzLzGk","password":"NnKzidrKi","email":"yzLzGk@gmail.com","firstName":"yzLzGk","lastName":"yzLzGk"}
  03:42:00.346 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd88d94b9000069b4778","customerId":"673ffd6eb0df5c00019b2e0f","customer":{"id":null,"firstName":"DqgjRdJzkTR
  03:42:04.361 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd8cd94b9000069b477a","customerId":"673ffd70b0df5c00019b2e18","customer":{"id":null,"firstName":"CBuNNCTjyMk
  03:42:09.917 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd91d94b9000069b477c","customerId":"673ffd7db0df5c00019b2e4a","customer":{"id":null,"firstName":"FriJsQ","la
  03:42:12.059 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd94d94b9000069b477e","customerId":"673ffd7bb0df5c00019b2e47","customer":{"id":null,"firstName":"hVAhAn","la
  03:42:14.493 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd96d94b9000069b4781","customerId":"673ffd83b0df5c00019b2e4e","customer":{"id":null,"firstName":"sJPYfXehRhh

## p0566
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-service, 2024-12-07T18:30:31.978Z
```
{"timestamp":1733596231978510300,"container_name":"ts-order-service","pod_name":"ts-order-service-7596478c9d-4p7wg","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"java.lang.IllegalArgumentException: Invalid UUID string: \n\tat java.util.UUID.fromString(UUID.java:194) ~[na:1.8.0_402]\n\tat order.service.OrderServiceImpl.queryOrders(OrderServiceImpl.java:107) ~[classes!/:1.0]\n\tat order.service.OrderServiceImpl.queryOrdersForRefresh(OrderServiceImpl.java:167) ~[classes!/:1.0]\n\tat order.controller.OrderController.queryOrdersForRefresh(OrderController.java:69) ~[cla…"}
```
Same service, the 2 minutes before (oldest first):
  18:30:16.794 [ts-order-service] 2024-12-07 18:30:16.793 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00 
  18:30:16.798 [ts-order-service] 2024-12-07 18:30:16.797 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0
  18:30:16.868 [ts-order-service] 2024-12-07 18:30:16.867 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×6)
  18:30:16.871 [ts-order-service] 2024-12-07 18:30:16.871 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : Left ticket info is empty  (×6)
  18:30:17.095 [ts-order-service] 2024-12-07 18:30:17.095 INFO 1 --- [io-12031-exec-3] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×2)
  18:30:17.098 [ts-order-service] 2024-12-07 18:30:17.098 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×2)
  18:30:31.939 [ts-order-service] 2024-12-07 18:30:31.939 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 
  18:30:31.978 [ts-order-service] 2024-12-07 18:30:31.953 ERROR 1 --- [io-12031-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
All services, 30 seconds either side (sampled):
  18:30:02.203 [ts-auth-service] 2024-12-07 18:30:02.202 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×3)
  18:30:02.422 [ts-route-service] 2024-12-07 18:30:02.421 INFO 1 --- [io-11178-exec-2] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×178)
  18:30:02.475 [ts-price-service] 2024-12-07 18:30:02.475 INFO 1 --- [io-16579-exec-1] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×21)
  18:30:02.522 [ts-basic-service] 2024-12-07 18:30:02.522 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×6)
  18:30:02.559 [ts-seat-service] 2024-12-07 18:30:02.559 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×31)
  18:30:02.574 [ts-order-other-service] 2024-12-07 18:30:02.574 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×30)
  18:30:02.705 [ts-travel2-service] 2024-12-07 18:30:02.704 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×6)
  18:30:07.009 [ts-travel-service] 2024-12-07 18:30:07.009 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×23)
  18:30:07.087 [ts-travel2-service] 2024-12-07 18:30:07.087 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×14)
  18:30:07.358 [ts-travel2-service] 2024-12-07 18:30:07.357 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×14)
  18:30:09.590 [ts-inside-payment-service] 2024-12-07 18:30:09.588 INFO 1 --- [io-18673-exec-7] i.service.InsidePaymentServiceImpl : Out pay result: Response(status=1, msg=Pay Success, data=null)
  18:30:11.438 [ts-basic-service] 2024-12-07 18:30:11.437 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×10)
  18:30:14.631 [ts-basic-service] 2024-12-07 18:30:14.630 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×23)
  18:30:14.740 [ts-travel-service] 2024-12-07 18:30:14.740 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×7)
  18:30:14.931 [ts-travel-service] 2024-12-07 18:30:14.931 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×12)
  18:30:15.870 [ts-auth-service] 2024-12-07 18:30:15.870 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  18:30:16.794 [ts-order-service] 2024-12-07 18:30:16.793 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00 
  18:30:17.530 [ts-travel-service] 2024-12-07 18:30:17.530 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  18:30:27.249 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:30:27.249+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359622
  18:30:29.832 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:30:29.831+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359622
  18:30:30.616 [ts-security-mongo] {"t":{"$date":"2024-12-07T18:30:30.616+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359623
  18:30:39.560 [ts-auth-service] 2024-12-07 18:30:39.559 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'taskScheduler' has been explicitly defined. Therefore, a de
  18:30:41.967 [ts-auth-service] 2024-12-07 18:30:41.967 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [java.util.Properties] is not e
  18:30:44.984 [ts-travel2-service] 2024-12-07 18:30:44.983 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  18:30:47.280 [ts-travel-service] 2024-12-07 18:30:47.279 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  18:30:49.764 [ts-auth-service] 2024-12-07 18:30:49.764 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  18:31:00.335 [ts-order-other-service] 2024-12-07 18:31:00.334 ERROR 1 --- [io-12032-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  18:31:01.654 [ts-auth-service] 2024-12-07 18:31:01.653 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth],methods=[POST]}" onto public org.springframework.h

## p0746
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-23T13:05:00.399Z
```
{"timestamp":1732367100399433500,"container_name":"adservice","pod_name":"adservice-574c5fd7b4-26pcp","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Exception in thread \"main\" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000\n\tat io.grpc.netty.NettyServer.start(NettyServer.java:333)\n\tat io.grpc.internal.ServerImpl.start(ServerImpl.java:185)\n\tat io.grpc.internal.ServerImpl.start(ServerImpl.java:94)\n\tat hipstershop.AdService.start(AdService.java:63)\n\tat hipstershop.AdService.main(AdService.java:236)"}
```
Same service, the 2 minutes before (oldest first):
  13:04:50.538 [adservice] received ad request (context_words=[footwear])
  13:04:50.771 [adservice] received ad request (context_words=[decor, home])
  13:04:51.485 [adservice] received ad request (context_words=[kitchen])  (×5)
  13:04:53.219 [adservice] received ad request (context_words=[])  (×2)
  13:04:53.598 [adservice] received ad request (context_words=[accessories])  (×2)
  13:04:54.271 [adservice] received ad request (context_words=[clothing, tops])  (×2)
  13:04:55.301 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  13:04:55.304 [adservice] *** server shut down
  13:04:58.914 [adservice] Stats enabled, but temporarily unavailable
  13:04:59.000 [adservice] Tracing enabled but temporarily unavailable
  13:04:59.000 [adservice] AdService starting.
  13:04:59.000 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.
  13:04:59.001 [adservice] Tracing enabled - Stackdriver exporter initialized.
All services, 30 seconds either side (sampled):
  13:04:30.489 [frontend] request started  (×317)
  13:04:30.492 [cartservice] GetCartAsync called with userId=4abf74df-6c0b-4392-bdb0-f19f4d7ff511  (×257)
  13:04:30.514 [shippingservice] [GetQuote] completed request  (×70)
  13:04:31.167 [frontend] serving product page  (×147)
  13:04:31.726 [adservice] received ad request (context_words=[decor, home])  (×5)
  13:04:31.996 [frontend] ENV_PLATFORM is: aws  (×40)
  13:04:33.651 [adservice] received ad request (context_words=[hair, beauty])  (×4)
  13:04:35.541 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '0PUK6V6EV0', 'L9ECAV7KIM', '2ZYFJ3GM2N']  (×11)
  13:04:55.299 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 4  (×118)
  13:04:55.401 [frontend] failed to retrieve ads  (×118)
  13:04:59.000 [adservice] AdService starting.  (×3)
  13:05:00.399 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  13:05:02.995 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"993","nanos":333697488},"credit_card":{"credit_card_number":"49785007864081  (×2)
  13:05:03.000 [shippingservice] [ShipOrder] received request  (×7)
  13:05:03.008 [emailservice] A request to send order confirmation email to lutzadam@example.com has been received.
  13:05:05.126 [checkoutservice] [PlaceOrder] user_id="6e17f999-1f44-47b4-93f0-534a09a0d813" user_currency="CAD"  (×4)
  13:05:05.158 [emailservice] A request to send order confirmation email to ggomez@example.net has been received.
  13:05:07.130 [checkoutservice] order confirmation email sent to "berryryan@example.net"
  13:05:09.205 [adservice] Exception in thread "main" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000 at io.grpc.netty.NettyServer.start(NettyServer.java:333) at io.g
  13:05:11.548 [paymentservice] Transaction processed: visa ending 9095 Amount: JPY419266.731537048
  13:05:17.301 [emailservice] A request to send order confirmation email to hwhite@example.net has been received.
  13:05:26.942 [checkoutservice] order confirmation email sent to "perkinstimothy@example.com"

## p0520
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:42:26.512Z
```
{"timestamp":1732358546512614100,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"{ id: '6741b192a437380001df4b9d' }"}
```
Same service, the 2 minutes before (oldest first):
  10:42:25.849 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"6741b  (×2)
  10:42:25.849 [front-end] [ undefined, undefined ]  (×2)
  10:42:25.849 [front-end] Posting Order: {"customer":"http://user/customers/6741b17ba437380001df4b71","address":"http://user/addresses/6741b181a437380001df4b7b","card":"http://user/cards  (×2)
  10:42:25.944 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19101dd390007094e0d","customerId":"6741b17ba437380001df4b71","customer":{"id":null,"firstName":"FLiqlpA","l
  10:42:25.944 [front-end] Order response: {"id":"6741b19101dd390007094e0d","customerId":"6741b17ba437380001df4b71","customer":{"id":null,"firstName":"FLiqlpA","lastName":"FLiqlpA","usern
  10:42:25.955 [front-end] POST /orders 201 - ms - -  (×2)
  10:42:26.223 [front-end] GET /catalogue 200 - ms - -  (×2)
  10:42:26.264 [front-end] Request received with body: {}
  10:42:26.274 [front-end] Received response: "{\"firstName\":\"tjTgc\",\"lastName\":\"tjTgc\",\"username\":\"tjTgc\",\"id\":\"6741b17aa437380001df4b6a\",\"_links\":{\"addresses\":{\"href
  10:42:26.274 [front-end] GET Request to: http://user/customers/6741b17aa437380001df4b6a/addresses  (×2)
  10:42:26.285 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b184a437380001df4b81\",\"_links\":{\"
  10:42:26.318 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732358546316,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde
  10:42:26.318 [front-end] Order response: {"timestamp":1732358546316,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli
  10:42:26.503 [front-end] Posting Customer: {"username":"kpvsmqOHyaKwEvJ","password":"odRVGYXk","email":"kpvsmqOHyaKwEvJ@gmail.com","firstName":"kpvsmqOHyaKwEvJ","lastName":"kpvsmqOHyaKw
All services, 30 seconds either side (sampled):
  10:41:56.648 [front-end] Request received with body: {}  (×59)
  10:41:56.699 [payment] ts=2024-11-23T10:41:56Z caller=logging.go:29 method=Authorise result=true took=1.315µs  (×10)
  10:41:57.011 [front-end] Received response: "{\"firstName\":\"VkjiwmTiXIs\",\"lastName\":\"VkjiwmTiXIs\",\"username\":\"VkjiwmTiXIs\",\"id\":\"6741b15ca437380001df4b07\",\"_links\":{\"a
  10:41:57.375 [front-end] User cart deleted with status: 202  (×58)
  10:41:57.868 [front-end] Posting Customer: {"username":"vqiGwzuJlekI","password":"jzTlwRVlSg","email":"vqiGwzuJlekI@gmail.com","firstName":"vqiGwzuJlekI","lastName":"vqiGwzuJlekI"}
  10:41:58.551 [user] ts=2024-11-23T10:41:58.550910731Z caller=middlewares.go:46 method=Register username=rDzQLwb email=rDzQLwb@gmail.com took=1.711836ms
  10:41:59.275 [user] ts=2024-11-23T10:41:59.274585093Z caller=middlewares.go:46 method=Register username=SCxrEnxcK email=SCxrEnxcK@gmail.com took=3.016714ms
  10:42:01.504 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×9)
  10:42:03.408 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b17b01dd390007094df9","customerId":"6741b16ba437380001df4b3b","customer":{"id":null,"firstName":"WzPQXTXTGID
  10:42:05.449 [front-end] Received response: "{\"firstName\":\"IfOkjlIP\",\"lastName\":\"IfOkjlIP\",\"username\":\"IfOkjlIP\",\"id\":\"6741b16ba437380001df4b3c\",\"_links\":{\"addresses\
  10:42:06.550 [front-end] Order response: {"id":"6741b17e01dd390007094dfe","customerId":"6741b165a437380001df4b27","customer":{"id":null,"firstName":"THlEsd","lastName":"THlEsd","usernam
  10:42:08.990 [front-end] Order response: {"timestamp":1732358528987,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×7)
  10:42:13.530 [front-end] Order response: {"id":"6741b18501dd390007094e02","customerId":"6741b16fa437380001df4b4a","customer":{"id":null,"firstName":"DSAgaYnbcBN","lastName":"DSAgaYnbcBN
  10:42:17.181 [front-end] Received response: "{\"firstName\":\"BBoDQLZVQIzI\",\"lastName\":\"BBoDQLZVQIzI\",\"username\":\"BBoDQLZVQIzI\",\"id\":\"6741b176a437380001df4b64\",\"_links\":{
  10:42:18.245 [front-end] Order response: {"id":"6741b18a01dd390007094e08","customerId":"6741b175a437380001df4b60","customer":{"id":null,"firstName":"vqiGwzuJlekI","lastName":"vqiGwzuJle
  10:42:23.996 [front-end] Received response: "{\"firstName\":\"jGtfmTYFLF\",\"lastName\":\"jGtfmTYFLF\",\"username\":\"jGtfmTYFLF\",\"id\":\"6741b17ba437380001df4b72\",\"_links\":{\"addr
  10:42:24.904 [user] ts=2024-11-23T10:42:24.904623485Z caller=middlewares.go:46 method=Register username=SGHrmQKj email=SGHrmQKj@gmail.com took=2.263575ms
  10:42:27.029 [front-end] Posting Customer: {"username":"drIpSVYoFYMY","password":"YGkAbaE","email":"drIpSVYoFYMY@gmail.com","firstName":"drIpSVYoFYMY","lastName":"drIpSVYoFYMY"}
  10:42:29.218 [front-end] Posting Customer: {"username":"mGHHyeKOwbUN","password":"QBuLJML","email":"mGHHyeKOwbUN@gmail.com","firstName":"mGHHyeKOwbUN","lastName":"mGHHyeKOwbUN"}
  10:42:32.458 [front-end] Received response: "{\"firstName\":\"fMqkVIscpJAub\",\"lastName\":\"fMqkVIscpJAub\",\"username\":\"fMqkVIscpJAub\",\"id\":\"6741b183a437380001df4b7f\",\"_links\
  10:42:34.927 [queue-master] 2024-11-23 10:42:34.927 INFO 7 --- [pool-6-thread-3] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×9)
  10:42:37.074 [front-end] Posting Customer: {"username":"kIGeXyfwDdcnX","password":"HYvjBVQVkK","email":"kIGeXyfwDdcnX@gmail.com","firstName":"kIGeXyfwDdcnX","lastName":"kIGeXyfwDdcnX"}
  10:42:39.648 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19f01dd390007094e16","customerId":"6741b18fa437380001df4b9a","customer":{"id":null,"firstName":"hkNXgDJyv",
  10:42:42.256 [front-end] Order response: {"id":"6741b1a201dd390007094e19","customerId":"6741b190a437380001df4b9c","customer":{"id":null,"firstName":"juGLviwwFqYBQb","lastName":"juGLviww
  10:42:44.968 [front-end] Order response: {"id":"6741b1a401dd390007094e1b","customerId":"6741b194a437380001df4ba5","customer":{"id":null,"firstName":"zQXUmkCZssMpOLp","lastName":"zQXUmkC
  10:42:46.608 [user] ts=2024-11-23T10:42:46.608545965Z caller=middlewares.go:46 method=Register username=LFlcXJd email=LFlcXJd@gmail.com took=1.991812ms
  10:42:49.045 [front-end] Posting Customer: {"username":"BRyiIgIUue","password":"qvGmbS","email":"BRyiIgIUue@gmail.com","firstName":"BRyiIgIUue","lastName":"BRyiIgIUue"}
  10:42:52.524 [front-end] Order response: {"id":"6741b1ac01dd390007094e1f","customerId":"6741b19ca437380001df4bbe","customer":{"id":null,"firstName":"FaALE","lastName":"FaALE","username"
  10:42:54.294 [front-end] Received response: "{\"firstName\":\"drIpSVYoFYMY\",\"lastName\":\"drIpSVYoFYMY\",\"username\":\"drIpSVYoFYMY\",\"id\":\"6741b193a437380001df4ba1\",\"_links\":{
  10:42:55.192 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b1af01dd390007094e26","customerId":"6741b19da437380001df4bc9","customer":{"id":null,"firstName":"ysfRffWVDnk

## p0789
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T20:40:25.846Z
```
{"timestamp":1732394425846722000,"container_name":"front-end","pod_name":"front-end-f77549869-gbrgw","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"Attempting to delete cart for user: 67423db148485600016b4bbc"}
```
Same service, the 2 minutes before (oldest first):
  20:40:25.556 [front-end] GET Request to: http://user/customers/67423daa48485600016b4bab/addresses  (×2)
  20:40:25.572 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67423db148485600016b4bbb\",\"_links\":{\"
  20:40:25.574 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67423
  20:40:25.574 [front-end] [ undefined, undefined ]
  20:40:25.574 [front-end] Posting Order: {"customer":"http://user/customers/67423daa48485600016b4bab","address":"http://user/addresses/67423db148485600016b4bba","card":"http://user/cards
  20:40:25.606 [front-end] Order response: {"statusCode":201,"body":{"id":"67423db94ca85a00070c6184","customerId":"67423daa48485600016b4bab","customer":{"id":null,"firstName":"IAjLwCURAUJ
  20:40:25.606 [front-end] Order response: {"id":"67423db94ca85a00070c6184","customerId":"67423daa48485600016b4bab","customer":{"id":null,"firstName":"IAjLwCURAUJrDfF","lastName":"IAjLwCU
  20:40:25.607 [front-end] POST /orders 201 - ms - -
  20:40:25.636 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67423db148485600016b4bbc"}  (×3)
  20:40:25.649 [front-end] POST /addresses 200 - ms - -  (×3)
  20:40:25.784 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67423db148485600016b4bbc"}  (×3)
  20:40:25.800 [front-end] POST /cards 200 - ms - -  (×2)
All services, 30 seconds either side (sampled):
  20:39:56.697 [user] ts=2024-11-23T20:39:56.697306692Z caller=middlewares.go:157 method=Health result=2 took=4.559948ms  (×40)
  20:39:56.911 [user] ts=2024-11-23T20:39:56.911578123Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67423d9448485600016b4b76 took=8.839992ms  (×60)
  20:39:57.030 [carts] 2024-11-23 20:39:57.029 INFO [carts,37d267831097e60f,e185cc3eb79c3e8c,false] 6 --- [-nio-80-exec-12] w.w.s.cart.controllers.ItemsController : Did not find item.  (×24)
  20:39:57.154 [front-end] Posting Order: {"customer":"http://user/customers/67423d8848485600016b4b3e","address":"http://user/addresses/67423d9148485600016b4b65","card":"http://user/cards  (×63)
  20:39:57.184 [front-end] Order response: {"statusCode":201,"body":{"id":"67423d9d4ca85a00070c6168","customerId":"67423d8848485600016b4b3e","customer":{"id":null,"firstName":"IkGXkuscyAk
  20:39:57.478 [front-end] GET /catalogue 200 - ms - -  (×65)
  20:39:58.616 [front-end] Received response: "{\"firstName\":\"SjoEcKB\",\"lastName\":\"SjoEcKB\",\"username\":\"SjoEcKB\",\"id\":\"67423d8548485600016b4b2f\",\"_links\":{\"addresses\":{
  20:39:59.760 [front-end] Order response: {"statusCode":201,"body":{"id":"67423d9f4ca85a00070c616e","customerId":"67423d8848485600016b4b3a","customer":{"id":null,"firstName":"nqXrgXNmYFJ
  20:40:01.258 [front-end] Received response: "{\"firstName\":\"OFEfSPIV\",\"lastName\":\"OFEfSPIV\",\"username\":\"OFEfSPIV\",\"id\":\"67423d8d48485600016b4b52\",\"_links\":{\"addresses\
  20:40:01.599 [user] ts=2024-11-23T20:40:01.599527568Z caller=middlewares.go:46 method=Register username=dwGzxShwU email=dwGzxShwU@gmail.com took=4.78409ms
  20:40:03.457 [front-end] Order response: {"id":"67423da34ca85a00070c6175","customerId":"67423d8848485600016b4b39","customer":{"id":null,"firstName":"yRqQlkZEnjO","lastName":"yRqQlkZEnjO
  20:40:07.947 [front-end] Order response: {"statusCode":201,"body":{"id":"67423da74ca85a00070c6177","customerId":"67423d9248485600016b4b6a","customer":{"id":null,"firstName":"eTvGrPCkr",
  20:40:12.924 [front-end] Received response: "{\"firstName\":\"WffpNH\",\"lastName\":\"WffpNH\",\"username\":\"WffpNH\",\"id\":\"67423d9948485600016b4b7f\",\"_links\":{\"addresses\":{\"h
  20:40:14.786 [front-end] Received response: "{\"firstName\":\"HiNCaUPh\",\"lastName\":\"HiNCaUPh\",\"username\":\"HiNCaUPh\",\"id\":\"67423d9b48485600016b4b84\",\"_links\":{\"addresses\
  20:40:17.653 [front-end] Order response: {"statusCode":201,"body":{"id":"67423db14ca85a00070c617d","customerId":"67423d9748485600016b4b7c","customer":{"id":null,"firstName":"crbCpdqumL"
  20:40:18.584 [user] ts=2024-11-23T20:40:18.584280527Z caller=middlewares.go:46 method=Register username=ZlsMZb email=ZlsMZb@gmail.com took=5.828518ms
  20:40:21.944 [front-end] Order response: {"id":"67423db54ca85a00070c6181","customerId":"67423da148485600016b4b92","customer":{"id":null,"firstName":"dwGzxShwU","lastName":"dwGzxShwU","u
  20:40:23.455 [user] ts=2024-11-23T20:40:23.454960392Z caller=middlewares.go:46 method=Register username=nKVYLqSc email=nKVYLqSc@gmail.com took=5.068193ms
  20:40:24.816 [front-end] Order response: {"id":"67423db84ca85a00070c6183","customerId":"67423d9f48485600016b4b8c","customer":{"id":null,"firstName":"JImOzkMlRfFSDYb","lastName":"JImOzkM
  20:40:26.436 [front-end] Order response: {"id":"67423dba4ca85a00070c6186","customerId":"67423da348485600016b4b97","customer":{"id":null,"firstName":"eBPIHDmqOPms","lastName":"eBPIHDmqOP
  20:40:32.796 [front-end] Received response: "{\"firstName\":\"TYgVTIQWkJ\",\"lastName\":\"TYgVTIQWkJ\",\"username\":\"TYgVTIQWkJ\",\"id\":\"67423dac48485600016b4bb1\",\"_links\":{\"addr
  20:40:35.799 [front-end] Order response: {"id":"67423dc34ca85a00070c618b","customerId":"67423dad48485600016b4bb5","customer":{"id":null,"firstName":"VzgwDk","lastName":"VzgwDk","usernam
  20:40:37.399 [front-end] Order response: {"statusCode":201,"body":{"id":"67423dc54ca85a00070c618e","customerId":"67423db048485600016b4bb8","customer":{"id":null,"firstName":"dxixjT","la
  20:40:40.045 [front-end] Order response: {"statusCode":201,"body":{"id":"67423dc84ca85a00070c6191","customerId":"67423db448485600016b4bc4","customer":{"id":null,"firstName":"pTfoFafBjFd
  20:40:42.129 [front-end] Order response: {"id":"67423dca4ca85a00070c6194","customerId":"67423db448485600016b4bc5","customer":{"id":null,"firstName":"NHenUPOvHKH","lastName":"NHenUPOvHKH
  20:40:43.185 [front-end] Order response: {"id":"67423dcb4ca85a00070c6197","customerId":"67423dba48485600016b4bde","customer":{"id":null,"firstName":"CudjNULbs","lastName":"CudjNULbs","u
  20:40:45.658 [front-end] Received response: "{\"firstName\":\"qqAfZnS\",\"lastName\":\"qqAfZnS\",\"username\":\"qqAfZnS\",\"id\":\"67423db248485600016b4bbf\",\"_links\":{\"addresses\":{
  20:40:47.856 [front-end] Posting Customer: {"username":"CHHKmq","password":"wwARKS","email":"CHHKmq@gmail.com","firstName":"CHHKmq","lastName":"CHHKmq"}
  20:40:51.911 [front-end] Received response: "{\"firstName\":\"XIudtkdstIkrY\",\"lastName\":\"XIudtkdstIkrY\",\"username\":\"XIudtkdstIkrY\",\"id\":\"67423dc348485600016b4bf7\",\"_links\

## p0834
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-admin-basic-info-service, 2024-12-08T12:36:37.707Z
```
{"timestamp":1733661397707685000,"container_name":"ts-admin-basic-info-service","pod_name":"ts-admin-basic-info-service-87bf97b79-b5gbq","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:36:37.706  INFO 1 --- [io-18767-exec-3] a.service.AdminBasicInfoServiceImpl      : [!!!!GetAllPriceResult] "}
```
Same service, the 2 minutes before (oldest first):
  12:36:13.328 [ts-admin-basic-info-service] 2024-12-08 12:36:13.328 INFO 1 --- [io-18767-exec-9] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×7)
  12:36:13.336 [ts-admin-basic-info-service] 2024-12-08 12:36:13.335 INFO 1 --- [io-18767-exec-9] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×6)
  12:36:15.233 [ts-admin-basic-info-service] 2024-12-08 12:36:15.233 INFO 1 --- [io-18767-exec-5] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×5)
  12:36:15.432 [ts-admin-basic-info-service] 2024-12-08 12:36:15.432 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×2)
All services, 30 seconds either side (sampled):
  12:36:07.853 [ts-auth-service] 2024-12-08 12:36:07.853 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×24)
  12:36:07.922 [ts-travel-service] 2024-12-08 12:36:07.922 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×16)
  12:36:08.213 [ts-travel2-service] 2024-12-08 12:36:08.213 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×15)
  12:36:11.759 [ts-auth-service] 2024-12-08 12:36:11.759 INFO 1 --- [io-12340-exec-1] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×11)
  12:36:12.083 [ts-basic-service] 2024-12-08 12:36:12.082 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×14)
  12:36:12.139 [ts-basic-service] 2024-12-08 12:36:12.139 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4  (×14)
  12:36:12.223 [ts-travel2-service] 2024-12-08 12:36:12.222 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×27)
  12:36:12.319 [ts-order-other-mongo] {"t":{"$date":"2024-12-08T12:36:12.319+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366137
  12:36:13.908 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-08T12:36:13.908+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366137
  12:36:15.530 [ts-order-service] 2024-12-08 12:36:15.530 INFO 1 --- [io-12031-exec-7] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 142  (×2)
  12:36:15.814 [ts-consign-service] 2024-12-08 12:36:15.814 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : SAVE consign result : ConsignRecord(id=a095f612-3f73-4785-b9e0-8491f08  (×2)
  12:36:26.414 [ts-basic-service] 2024-12-08 12:36:26.413 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×3)
  12:36:32.589 [ts-admin-travel-service] 2024-12-08 12:36:32.589 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×4)
  12:36:36.917 [ts-seat-service] 2024-12-08 12:36:36.916 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  12:36:40.608 [ts-food-service] 2024-12-08 12:36:40.608 INFO 1 --- [io-18856-exec-2] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×3)
  12:36:42.058 [ts-contacts-service] 2024-12-08 12:36:42.058 INFO 1 --- [io-12347-exec-6] contacts.service.ContactsServiceImpl : [Contacts-Query-Service][Query-Contacts] Result Size: 2
  12:36:44.887 [ts-security-service] 2024-12-08 12:36:44.887 INFO 1 --- [io-11188-exec-6] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  12:36:46.806 [ts-security-service] 2024-12-08 12:36:46.806 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service][Get Security Config Info]
  12:36:47.159 [ts-preserve-other-service] 2024-12-08 12:36:47.159 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Check tickets num
  12:36:47.864 [ts-preserve-other-service] 2024-12-08 12:36:47.863 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order] Order Travel Date: Sun Dec 08 00:00:00
  12:36:48.018 [ts-order-other-service] 2024-12-08 12:36:48.018 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Verify Login] Success
  12:36:48.881 [ts-preserve-other-service] 2024-12-08 12:36:48.881 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 5] Preserve Buy Assurance Success
  12:36:49.695 [ts-preserve-other-service] 2024-12-08 12:36:49.695 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Cancel Order Service][Get Order By Id]
  12:36:53.075 [ts-inside-payment-service] 2024-12-08 12:36:53.075 INFO 1 --- [io-18673-exec-5] i.controller.InsidePaymentController : [Inside Payment Service][Pay] Pay for: f3f4efad-1716-45de-963e-9f540
  12:36:56.608 [ts-basic-service] 2024-12-08 12:36:56.608 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270
  12:36:56.723 [ts-order-service] 2024-12-08 12:36:56.723 INFO 1 --- [io-12031-exec-8] order.service.OrderServiceImpl : Left ticket info is empty  (×5)
  12:36:56.944 [ts-basic-service] 2024-12-08 12:36:56.944 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO
  12:36:57.787 [ts-travel-service] 2024-12-08 12:36:57.787 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
  12:36:58.348 [ts-travel2-service] 2024-12-08 12:36:58.348 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sun Dec 08 00:00:00 GMT 2024,   (×2)

## p0624
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-07T20:17:51.174Z
```
{"timestamp":1733602671174479400,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-9ll65","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:17:51.173  INFO 1 --- [           main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped \"{[/error],produces=[text/html]}\" onto public org.springframework.web.servlet.ModelAndView org.springframework.boot.autoconfigure.web.BasicErrorController.errorHtml(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)"}
```
Same service, the 2 minutes before (oldest first):
  20:17:43.865 [ts-route-service] 2024-12-07 20:17:43.865 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'requestContextFilter' to: [/*]  (×3)
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] .s.DelegatingFilterProxyRegistrationBean : Mapping filter: 'springSecurityFilterChain' to: [/*]
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  20:17:46.368 [ts-route-service] 2024-12-07 20:17:46.368 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-route-mongo:27017], mode=MULTIPLE, requiredClus
  20:17:46.369 [ts-route-service] 2024-12-07 20:17:46.368 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-route-mongo:27017 to client view of cluster
  20:17:46.954 [ts-route-service] 2024-12-07 20:17:46.954 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:24}] to ts-route-
  20:17:46.959 [ts-route-service] 2024-12-07 20:17:46.957 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip
  20:17:46.960 [ts-route-service] 2024-12-07 20:17:46.959 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  20:17:51.165 [ts-route-service] 2024-12-07 20:17:51.165 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes],methods=[POST]}" onto public org.sp
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.165 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{startId}/{terminalId}],methods=[GET
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{routeId}],methods=[DELETE]}" onto p
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{routeId}],methods=[GET]}" onto publ
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes],methods=[GET]}" onto public org.spr
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/welcome],methods=[GET]}" onto public java.l
  20:17:51.168 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/v2/api-docs],methods=[GET],produces=[application/json || applic
  20:17:51.171 [ts-route-service] 2024-12-07 20:17:51.170 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/swagger-resources]}" onto org.springframework.http.ResponseEnti
  20:17:51.172 [ts-route-service] 2024-12-07 20:17:51.171 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/configuration/ui]}" onto org.springframework.http.ResponseEntit
  20:17:51.172 [ts-route-service] 2024-12-07 20:17:51.172 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/configuration/security]}" onto org.springframework.http.Respons
All services, 30 seconds either side (sampled):
  20:17:21.221 [ts-auth-service] 2024-12-07 20:17:21.221 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×12)
  20:17:21.406 [ts-basic-service] 2024-12-07 20:17:21.405 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×17)
  20:17:21.793 [ts-travel-service] 2024-12-07 20:17:21.793 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×27)
  20:17:24.657 [ts-route-service] 2024-12-07 20:17:24.657 INFO 1 --- [ main] route.RouteApplication : No active profile set, falling back to default profiles: default
  20:17:28.414 [ts-price-mongo] {"t":{"$date":"2024-12-07T20:17:28.413+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360264
  20:17:29.626 [ts-auth-service] 2024-12-07 20:17:29.626 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×3)
  20:17:31.474 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T20:17:31.474+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:35.032 [ts-route-service] Error opening zip file or JAR manifest missing : /tmp/opentelemetry-javaagent.jar
  20:17:36.448 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:36 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 200 31992 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) App
  20:17:37.664 [ts-route-service] 2024-12-07 20:17:37.664 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  20:17:38.802 [ts-food-service] org.springframework.web.client.HttpServerErrorException: 500 Internal Server Error at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Def
  20:17:42.857 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T20:17:42.857+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360266
  20:17:46.369 [ts-route-service] 2024-12-07 20:17:46.368 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-route-mongo:27017 to client view of cluster
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{routeId}],methods=[GET]}" onto publ
  20:17:52.758 [ts-route-service] 2024-12-07 20:17:52.757 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics || /metrics.json],methods=[GET],produces=[application/vnd.s
  20:17:52.762 [ts-route-service] 2024-12-07 20:17:52.762 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  20:17:53.879 [ts-travel2-service] 2024-12-07 20:17:53.878 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  20:17:57.960 [ts-basic-service] 2024-12-07 20:17:57.959 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su 
  20:18:01.659 [ts-route-service] 2024-12-07 20:18:01.657 INFO 1 --- [ main] d.s.w.p.DocumentationPluginsBootstrapper : Found 1 custom documentation plugin(s)
  20:18:04.265 [ts-route-service] 2024-12-07 20:18:04.265 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: taiyuan End: shanghai
  20:18:09.561 [ts-route-service] 2024-12-07 20:18:09.560 INFO 1 --- [io-11178-exec-3] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×41)
  20:18:10.466 [ts-travel-service] 2024-12-07 20:18:10.465 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×3)
  20:18:11.789 [ts-basic-service] 2024-12-07 20:18:11.789 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×2)
  20:18:11.820 [ts-order-other-service] 2024-12-07 20:18:11.820 INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×2)
  20:18:11.911 [ts-seat-service] 2024-12-07 20:18:11.911 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  20:18:11.988 [ts-seat-service] 2024-12-07 20:18:11.988 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×3)
  20:18:12.051 [ts-travel2-service] 2024-12-07 20:18:12.051 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×4)
  20:18:15.448 [ts-order-other-service] 2024-12-07 20:18:15.448 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Get Order By Id] Order Id: 0326c0cb-84c6-4b7b

## p0776
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-24T13:24:16.570Z
```
{"timestamp":1732454656570807000,"container_name":"user","pod_name":"user-558cdfd768-t6jmz","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"ts=2024-11-24T13:24:16.570641777Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=674328f9f6d875000161f812 took=3.506229ms"}
```
Same service, the 2 minutes before (oldest first):
  13:24:14.137 [user] ts=2024-11-24T13:24:14.137705763Z caller=middlewares.go:75 method=GetUsers id=674328ecf6d875000161f7e2 result=1 took=1.55621ms  (×11)
  13:24:14.150 [user] ts=2024-11-24T13:24:14.150129903Z caller=middlewares.go:134 method=GetCards id=674328f5f6d875000161f806 result=1 took=1.476008ms  (×3)
  13:24:14.150 [user] ts=2024-11-24T13:24:14.150151483Z caller=middlewares.go:104 method=GetAddresses id=674328f5f6d875000161f805 result=1 took=1.433194ms  (×3)
  13:24:15.333 [user] ts=2024-11-24T13:24:15.333778174Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=674328faf6d875000161f818 took=3.497044ms
  13:24:15.347 [user] ts=2024-11-24T13:24:15.347059365Z caller=middlewares.go:118 method=PostCard card=*****3321 user=674328faf6d875000161f818 took=2.894328ms
  13:24:15.820 [user] ts=2024-11-24T13:24:15.820235089Z caller=middlewares.go:46 method=Register username=AJSbaQw email=AJSbaQw@gmail.com took=1.823432ms
All services, 30 seconds either side (sampled):
  13:23:46.663 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"674328daf6d875000161f7b8"}  (×60)
  13:23:46.761 [front-end] Attempting to add to cart: {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","quantity":1}  (×60)
  13:23:48.467 [user] ts=2024-11-24T13:23:48.467143495Z caller=middlewares.go:46 method=Register username=aoySWp email=aoySWp@gmail.com took=2.017085ms
  13:23:48.932 [front-end] GET Request to: http://user/customers/674328cbf6d875000161f788/addresses  (×120)
  13:23:48.973 [queue-master] 2024-11-24 13:23:48.973 INFO 7 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×46)
  13:23:49.212 [payment] ts=2024-11-24T13:23:49Z caller=logging.go:29 method=Authorise result=false took=5.812µs  (×5)
  13:23:51.819 [front-end] Posting Customer: {"username":"tCbHLxru","password":"ouHTZneheP","email":"tCbHLxru@gmail.com","firstName":"tCbHLxru","lastName":"tCbHLxru"}
  13:23:52.888 [front-end] Order response: {"statusCode":201,"body":{"id":"674328e8c4380300078a45d0","customerId":"674328daf6d875000161f7b8","customer":{"id":null,"firstName":"fMPYiLSflVB
  13:23:56.328 [front-end] Received response: "{\"firstName\":\"LEBxtu\",\"lastName\":\"LEBxtu\",\"username\":\"LEBxtu\",\"id\":\"674328d6f6d875000161f7af\",\"_links\":{\"addresses\":{\"h
  13:23:58.035 [session-db] 1:M 24 Nov 2024 13:23:58.035 * 100 changes in 300 seconds. Saving...
  13:23:58.737 [user] ts=2024-11-24T13:23:58.737405472Z caller=middlewares.go:46 method=Register username=yEdIzXb email=yEdIzXb@gmail.com took=1.731459ms
  13:24:00.099 [front-end] Order response: {"statusCode":201,"body":{"id":"674328f0c4380300078a45d7","customerId":"674328dcf6d875000161f7b9","customer":{"id":null,"firstName":"HVSOWKqPNit
  13:24:02.171 [user] ts=2024-11-24T13:24:02.171456033Z caller=middlewares.go:46 method=Register username=sjpBp email=sjpBp@gmail.com took=1.826501ms
  13:24:04.174 [front-end] Order response: {"statusCode":201,"body":{"id":"674328f4c4380300078a45da","customerId":"674328def6d875000161f7c3","customer":{"id":null,"firstName":"HWFVodz","l
  13:24:06.364 [front-end] Order response: {"statusCode":201,"body":{"id":"674328f6c4380300078a45dd","customerId":"674328e9f6d875000161f7da","customer":{"id":null,"firstName":"ngLVxnwXRgg
  13:24:12.031 [front-end] Received response: "{\"firstName\":\"VIqXg\",\"lastName\":\"VIqXg\",\"username\":\"VIqXg\",\"id\":\"674328e7f6d875000161f7d8\",\"_links\":{\"addresses\":{\"href
  13:24:15.069 [front-end] Order response: {"id":"674328ffc4380300078a45e2","customerId":"674328edf6d875000161f7e3","customer":{"id":null,"firstName":"ojnTQUGVt","lastName":"ojnTQUGVt","u
  13:24:18.776 [front-end] Order response: {"statusCode":201,"body":{"id":"67432902c4380300078a45e5","customerId":"674328eef6d875000161f7e9","customer":{"id":null,"firstName":"klriwbZVUpF
  13:24:20.793 [front-end] Order response: {"statusCode":201,"body":{"id":"67432904c4380300078a45e8","customerId":"674328ecf6d875000161f7e0","customer":{"id":null,"firstName":"jVaMpr","la
  13:24:22.728 [front-end] Order response: {"statusCode":201,"body":{"id":"67432906c4380300078a45ea","customerId":"674328f0f6d875000161f7f2","customer":{"id":null,"firstName":"vPlLw","las
  13:24:23.669 [front-end] Received response: "{\"firstName\":\"COhRRAzQ\",\"lastName\":\"COhRRAzQ\",\"username\":\"COhRRAzQ\",\"id\":\"674328f0f6d875000161f7f1\",\"_links\":{\"addresses\
  13:24:28.525 [front-end] Order response: {"statusCode":201,"body":{"id":"6743290cc4380300078a45f0","customerId":"674328f6f6d875000161f807","customer":{"id":null,"firstName":"qUgdxKRYRi"
  13:24:30.173 [front-end] Order response: {"statusCode":201,"body":{"id":"6743290ec4380300078a45f4","customerId":"674328f2f6d875000161f7f7","customer":{"id":null,"firstName":"VvKnjqT","l
  13:24:32.501 [front-end] Received response: "{\"firstName\":\"uspazyzHzHrei\",\"lastName\":\"uspazyzHzHrei\",\"username\":\"uspazyzHzHrei\",\"id\":\"674328faf6d875000161f818\",\"_links\
  13:24:35.083 [front-end] Received response: "{\"firstName\":\"cVSDDPMJMauAwCH\",\"lastName\":\"cVSDDPMJMauAwCH\",\"username\":\"cVSDDPMJMauAwCH\",\"id\":\"674328fcf6d875000161f825\",\"_
  13:24:38.641 [front-end] Order response: {"statusCode":201,"body":{"id":"67432916c4380300078a45fa","customerId":"67432905f6d875000161f839","customer":{"id":null,"firstName":"bkVhCjeCkuD
  13:24:40.185 [front-end] Received response: "{\"firstName\":\"gbdIVoxa\",\"lastName\":\"gbdIVoxa\",\"username\":\"gbdIVoxa\",\"id\":\"67432906f6d875000161f841\",\"_links\":{\"addresses\
  13:24:41.871 [front-end] Order response: {"id":"67432919c4380300078a4601","customerId":"67432904f6d875000161f835","customer":{"id":null,"firstName":"LFrGsaPhHuvYE","lastName":"LFrGsaPhH
  13:24:45.766 [front-end] Posting Customer: {"username":"NhKkbYX","password":"IoUSWH","email":"NhKkbYX@gmail.com","firstName":"NhKkbYX","lastName":"NhKkbYX"}

## p0024
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T07:21:07.455Z
```
{"service":"dbservice2","message":"2021-08-13 07:21:07,455 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | 4aad29353703e40d | f8324592-fbc3-11eb-b54d-0242ac110004-CfHjswnr-5atn1@V=8r4l token generate success token=MTYyODgxMDQ2Ny40NTQ3OTk6ZjgzMjQ1OTItZmJjMy0xMWViLWI1NGQtMDI0MmFjMTEwMDA0Q2ZIanN3bnI1YXRuMUBWPThyNGw6MTYyODgxMDUyNy40NTQ4MTA5OjA2MjdmOGRiN2Y0YzkwMTY1ZmM5YzRmMjI2ZmM4NzZh"}
```
Same service, the 2 minutes before (oldest first):
  07:21:00.644 [dbservice2] INFO f4328768-fbc3-11eb-baf5-0242ac110003-NJwFMgYh-r7602!<ni{bW token generate success token=MTYyODgxMDQ2MC42NDQzNzQxOmY0MzI4NzY4LWZiYzMtMTFlYi1iYWY1LTAyNDJhYzE
  07:21:04.101 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  07:21:04.101 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  07:21:04.141 [dbservice2] INFO query = select passwards from username_table where user_name='UoOtrWnu'  (×5)
  07:21:04.218 [dbservice2] INFO f656cc3e-fbc3-11eb-bf6e-0242ac110004-UoOtrWnu-l>x7frKnk89y token generate success token=MTYyODgxMDQ2NC4yMTgwMjY0OmY2NTZjYzNlLWZiYzMtMTFlYi1iZjZlLTAyNDJhYzE
  07:21:05.012 [dbservice2] INFO f6d3f40c-fbc3-11eb-9bd2-0242ac110004-DGlMEFgf-hDX.AML@KH9e token generate success token=MTYyODgxMDQ2NS4wMTE5MzE3OmY2ZDNmNDBjLWZiYzMtMTFlYi05YmQyLTAyNDJhYzE
  07:21:06.477 [dbservice2] INFO f7c4a9d8-fbc3-11eb-9e46-0242ac110003-QSNmqeTf-X!?shln-IxLw token generate success token=MTYyODgxMDQ2Ni40NzY0Mjk1OmY3YzRhOWQ4LWZiYzMtMTFlYi05ZTQ2LTAyNDJhYzE
  07:21:07.365 [dbservice2] INFO f831aea2-fbc3-11eb-bbc9-0242ac110003-HBUrWkyb-d9v-_CftTxs{ token generate success token=MTYyODgxMDQ2Ny4zNjQ5MDQyOmY4MzFhZWEyLWZiYzMtMTFlYi1iYmM5LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  07:20:38.022 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  07:20:38.204 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×43)
  07:20:38.454 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  07:20:38.587 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×38)
  07:20:38.756 [dbservice2] INFO e7263fec-fbc3-11eb-8297-0242ac110003-UlXetfSn-i#KQO@L$Ef9X token generate success token=MTYyODgxMDQzOC43NTU1OTY5OmU3MjYzZmVjLWZiYzMtMTFlYi04Mjk3LTAyNDJhYzE
  07:20:41.052 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×39)
  07:20:41.275 [mobservice1] INFO info e8d85d16-fbc3-11eb-af9e-0242ac110004:PUILkhrM write success  (×2)
  07:20:41.547 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×44)
  07:20:41.836 [dbservice1] INFO e8ff194c-fbc3-11eb-a9e2-0242ac110003-RvaUsgNC-mT$@KrBb)Ax/ token generate success token=MTYyODgxMDQ0MS44MzY1MTY2OmU4ZmYxOTRjLWZiYzMtMTFlYi1hOWUyLTAyNDJhYzE
  07:20:44.374 [redisservice2] INFO service accept, status_code: 200  (×39)
  07:20:46.476 [mobservice2] INFO info ec0463e0-fbc3-11eb-b966-0242ac110003:zwDGqUsI write success
  07:20:48.492 [dbservice1] INFO ecf6b78a-fbc3-11eb-a390-0242ac110003-VcbkjSAZ-H}z)MI_t986B token generate success token=MTYyODgxMDQ0OC40OTE2NTE1OmVjZjZiNzhhLWZiYzMtMTFlYi1hMzkwLTAyNDJhYzE
  07:20:50.797 [mobservice2] INFO info ee8812a6-fbc3-11eb-84ee-0242ac110004:edSFETbQ write success
  07:20:53.115 [dbservice2] INFO efbaaeea-fbc3-11eb-a856-0242ac110004-LXQegUZS-iNwdpV=%fU<F token generate success token=MTYyODgxMDQ1My4xMTQ3Nzc6ZWZiYWFlZWEtZmJjMy0xMWViLWE4NTYtMDI0MmFjMTE
  07:20:55.610 [mobservice1] INFO info f16d146c-fbc3-11eb-96fe-0242ac110003:zxoeJtIu write success
  07:20:58.002 [dbservice2] INFO f28a7b50-fbc3-11eb-9791-0242ac110004-SpJzmrVL-uO+f&?:*M^mq token generate success token=MTYyODgxMDQ1OC4wMDE5MDU0OmYyOGE3YjUwLWZiYzMtMTFlYi05NzkxLTAyNDJhYzE
  07:21:00.221 [mobservice2] INFO info f4328768-fbc3-11eb-baf5-0242ac110003:NJwFMgYh write success
  07:21:02.552 [dbservice1] INFO f554ad1a-fbc3-11eb-8cfe-0242ac110003-jnuiIECt-_JI:sCNEZ%ay token generate success token=MTYyODgxMDQ2Mi41NTI0OTM4OmY1NTRhZDFhLWZiYzMtMTFlYi04Y2ZlLTAyNDJhYzE
  07:21:05.012 [dbservice2] INFO f6d3f40c-fbc3-11eb-9bd2-0242ac110004-DGlMEFgf-hDX.AML@KH9e token generate success token=MTYyODgxMDQ2NS4wMTE5MzE3OmY2ZDNmNDBjLWZiYzMtMTFlYi05YmQyLTAyNDJhYzE
  07:21:07.365 [dbservice2] INFO f831aea2-fbc3-11eb-bbc9-0242ac110003-HBUrWkyb-d9v-_CftTxs{ token generate success token=MTYyODgxMDQ2Ny4zNjQ5MDQyOmY4MzFhZWEyLWZiYzMtMTFlYi1iYmM5LTAyNDJhYzE
  07:21:09.942 [mobservice2] INFO info f9f1f1a2-fbc3-11eb-adb3-0242ac110004:GZqDYHLc write success
  07:21:12.184 [dbservice1] INFO fb19d432-fbc3-11eb-a965-0242ac110004-OSENDWPb-6)hw=<r&R9.T token generate success token=MTYyODgxMDQ3Mi4xODQxMzpmYjE5ZDQzMi1mYmMzLTExZWItYTk2NS0wMjQyYWMxMTA
  07:21:14.184 [mobservice2] INFO info fc89199a-fbc3-11eb-836d-0242ac110003:CxaURntJ write success
  07:21:16.224 [dbservice1] INFO fd747980-fbc3-11eb-b1b6-0242ac110004-JVwBQHua-/A_5xQRM{X.J token generate success token=MTYyODgxMDQ3Ni4yMjM5NTQ3OmZkNzQ3OTgwLWZiYzMtMTFlYi1iMWI2LTAyNDJhYzE
  07:21:18.876 [dbservice2] INFO ff02cf72-fbc3-11eb-a1ef-0242ac110003-McHWnbKA-<V&r%^nqCeZ* token generate success token=MTYyODgxMDQ3OC44NzU3OTA0OmZmMDJjZjcyLWZiYzMtMTFlYi1hMWVmLTAyNDJhYzE
  07:21:21.500 [dbservice2] INFO 008f8736-fbc4-11eb-b1f1-0242ac110004-HNmhtWzM-u-}_4oB7AmID token generate success token=MTYyODgxMDQ4MS41MDAxOTY3OjAwOGY4NzM2LWZiYzQtMTFlYi1iMWYxLTAyNDJhYzE
  07:21:24.088 [dbservice1] INFO 02306308-fbc4-11eb-838e-0242ac110003-OMLuHZEe-zUGYQa}urZJ/ token generate success token=MTYyODgxMDQ4NC4wODgxMzg4OjAyMzA2MzA4LWZiYzQtMTFlYi04MzhlLTAyNDJhYzE
  07:21:26.524 [mobservice1] INFO info 03daba46-fbc4-11eb-a092-0242ac110003:MiawoxWe write success
  07:21:28.406 [dbservice1] INFO 04c0f4c0-fbc4-11eb-852a-0242ac110004-btlsWgLd-X^oq#)eu9Fd/ token generate success token=MTYyODgxMDQ4OC40MDYzMjQ6MDRjMGY0YzAtZmJjNC0xMWViLTg1MmEtMDI0MmFjMTE
  07:21:30.499 [mobservice2] INFO info 063fa0d0-fbc4-11eb-b732-0242ac110003:lrWJDxNP write success

## p0009
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T02:00:51.754Z
```
{"service":"dbservice1","message":"2021-08-13 02:00:51,754 | ERROR | 0.0.0.4 | 172.17.0.3 | dbservice1 | 9b8d5fc67e08d30a | (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)"}
```
Same service, the 2 minutes before (oldest first):
  02:00:46.855 [dbservice1] INFO query = select passwards from username_table where user_name='KXtHNvbZ'  (×5)
  02:00:46.931 [dbservice1] INFO 37fc3016-fb97-11eb-9c99-0242ac110003-KXtHNvbZ-Qh<MIBE8TJ9i token generate success token=MTYyODc5MTI0Ni45MzE0Njk6MzdmYzMwMTYtZmI5Ny0xMWViLTljOTktMDI0MmFjMTE
  02:00:48.769 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  02:00:48.769 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  02:00:48.860 [dbservice1] INFO 391def84-fb97-11eb-8341-0242ac110003-FGqxBRpZ-}9s_LQ?u>hzS token generate success token=MTYyODc5MTI0OC44NjAwNzA3OjM5MWRlZjg0LWZiOTctMTFlYi04MzQxLTAyNDJhYzE
  02:00:49.998 [dbservice1] INFO 39c8c3c8-fb97-11eb-875f-0242ac110003-uZrYXDKb-MT}4%L2EhXFS token generate success token=MTYyODc5MTI0OS45OTg0ODE6MzljOGMzYzgtZmI5Ny0xMWViLTg3NWYtMDI0MmFjMTE
  02:00:50.774 [dbservice1] INFO 3a3f8526-fb97-11eb-80f0-0242ac110004-XrSheKyp-}WR*812Zg_<M token generate success token=MTYyODc5MTI1MC43NzQ1Mjc4OjNhM2Y4NTI2LWZiOTctMTFlYi04MGYwLTAyNDJhYzE
  02:00:51.670 [dbservice1] INFO 3ab7db66-fb97-11eb-9073-0242ac110003-tAuqKoTw-yCN:@jA43dVi token generate success token=MTYyODc5MTI1MS42NzAzMTEyOjNhYjdkYjY2LWZiOTctMTFlYi05MDczLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  02:00:21.759 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '292fef8c-fb97-11eb-a00b-0242ac110004', 'value': 'OZQbWUnN'}  (×40)
  02:00:21.931 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×41)
  02:00:22.032 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '2986d306-fb97-11eb-a6f2-0242ac110004', 'value': '', 'ex': 10}  (×43)
  02:00:22.207 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×43)
  02:00:22.480 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×46)
  02:00:22.545 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '29b0bd88-fb97-11eb-8ce6-0242ac110004'}  (×46)
  02:00:22.760 [dbservice2] INFO 2986d306-fb97-11eb-a6f2-0242ac110004-IfmxlhUD-(EG)!n_@/CPS token generate success token=MTYyODc5MTIyMi43NjAwOTYzOjI5ODZkMzA2LWZiOTctMTFlYi1hNmYyLTAyNDJhYzE  (×2)
  02:00:23.372 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×42)
  02:00:25.617 [dbservice1] INFO 2b34f976-fb97-11eb-8ea6-0242ac110004-ifjIWOde--f_zlhg+K1LD token generate success token=MTYyODc5MTIyNS42MTczMTE3OjJiMzRmOTc2LWZiOTctMTFlYi04ZWE2LTAyNDJhYzE  (×2)
  02:00:32.505 [dbservice2] INFO 2f4e8b8a-fb97-11eb-a5fb-0242ac110004-WdLJXtHG-UZY)^Efxi>LV token generate success token=MTYyODc5MTIzMi41MDUyMTg1OjJmNGU4YjhhLWZiOTctMTFlYi1hNWZiLTAyNDJhYzE
  02:00:35.018 [dbservice1] INFO 30d4f214-fb97-11eb-bafe-0242ac110003-slEUKmfJ-<53oCLnjJMdv token generate success token=MTYyODc5MTIzNS4wMTgzNTE2OjMwZDRmMjE0LWZiOTctMTFlYi1iYWZlLTAyNDJhYzE
  02:00:37.592 [dbservice1] INFO 325f1934-fb97-11eb-9d1f-0242ac110004-guYIhUdp-G-Z5>I<YCLtF token generate success token=MTYyODc5MTIzNy41OTE3NjAyOjMyNWYxOTM0LWZiOTctMTFlYi05ZDFmLTAyNDJhYzE
  02:00:40.158 [dbservice1] INFO 33d7ab0a-fb97-11eb-b8ab-0242ac110003-xUAQKIOl-SZl=)D>^PYVI token generate success token=MTYyODc5MTI0MC4xNTgzNjEyOjMzZDdhYjBhLWZiOTctMTFlYi1iOGFiLTAyNDJhYzE
  02:00:43.290 [mobservice2] INFO info 35f96608-fb97-11eb-a359-0242ac110003:NhtsWobx write success
  02:00:46.079 [dbservice2] INFO 37478972-fb97-11eb-ba72-0242ac110003-oJvuskDK-ce_Fo%vzuUK< token generate success token=MTYyODc5MTI0Ni4wNzg2MjU3OjM3NDc4OTcyLWZiOTctMTFlYi1iYTcyLTAyNDJhYzE
  02:00:48.518 [mobservice2] INFO info 391def84-fb97-11eb-8341-0242ac110003:FGqxBRpZ write success
  02:00:51.183 [mobservice2] INFO info 3ab7db66-fb97-11eb-9073-0242ac110003:tAuqKoTw write success
  02:00:54.167 [dbservice2] INFO 3c2fc1ca-fb97-11eb-aa28-0242ac110004-FqaTIXhn-^vCabrQL@MgF token generate success token=MTYyODc5MTI1NC4xNjY3MDc4OjNjMmZjMWNhLWZiOTctMTFlYi1hYTI4LTAyNDJhYzE
  02:00:56.575 [dbservice1] INFO 3dba13ba-fb97-11eb-a755-0242ac110003-rcwlDFam-ukK^?blc3pg) token generate success token=MTYyODc5MTI1Ni41NzU2MjQ3OjNkYmExM2JhLWZiOTctMTFlYi1hNzU1LTAyNDJhYzE
  02:00:58.628 [mobservice2] INFO info 3f1a335c-fb97-11eb-8a0c-0242ac110004:WefLRrQS write success
  02:01:01.287 [dbservice2] INFO 40789ff4-fb97-11eb-bad9-0242ac110004-VnGSpqai-jIe*x?+nDlz> token generate success token=MTYyODc5MTI2MS4yODY2NTQ3OjQwNzg5ZmY0LWZiOTctMTFlYi1iYWQ5LTAyNDJhYzE
  02:01:04.114 [mobservice1] INFO info 42696d5c-fb97-11eb-b447-0242ac110003:LEFinroh write success
  02:01:06.418 [mobservice2] INFO info 43c70628-fb97-11eb-b04e-0242ac110003:OMLuHZEe write success
  02:01:08.774 [dbservice2] INFO 44fb03f0-fb97-11eb-9b89-0242ac110004-NSiQolUW-T3rg/Jh_qz#l token generate success token=MTYyODc5MTI2OC43NzM4ODU1OjQ0ZmIwM2YwLWZiOTctMTFlYi05Yjg5LTAyNDJhYzE
  02:01:11.582 [dbservice1] INFO 46a26342-fb97-11eb-91a1-0242ac110004-tVZirvSy-RdOP!c4y.62_ token generate success token=MTYyODc5MTI3MS41ODE4OTE6NDZhMjYzNDItZmI5Ny0xMWViLTkxYTEtMDI0MmFjMTE
  02:01:14.347 [dbservice2] INFO 4851322c-fb97-11eb-9fbc-0242ac110004-ItWBCNrc-GUJ7{#*fP2/g token generate success token=MTYyODc5MTI3NC4zNDcyMjYxOjQ4NTEzMjJjLWZiOTctMTFlYi05ZmJjLTAyNDJhYzE
  02:01:16.841 [dbservice2] INFO 49cc088e-fb97-11eb-bd9c-0242ac110004-mMWStTBy-K=7!ICE-naiw token generate success token=MTYyODc5MTI3Ni44NDAyMDM6NDljYzA4OGUtZmI5Ny0xMWViLWJkOWMtMDI0MmFjMTE
  02:01:19.847 [dbservice2] INFO 4b9baec6-fb97-11eb-aa8b-0242ac110004-GmfKwAOM-)X4PM9QtBES/ token generate success token=MTYyODc5MTI3OS44NDcwMDc1OjRiOWJhZWM2LWZiOTctMTFlYi1hYThiLTAyNDJhYzE

## p0729
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-14T20:23:32.504Z
```
{"service":"dbservice2","message":"2021-08-14 20:23:32,504 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | d1db3d0aa67c7344 | 70269486-fcfa-11eb-8691-0242ac110004-jliMGRSf-@UO%!NH}$bsm token generate success token=MTYyODk0MzgxMi41MDQwMzgzOjcwMjY5NDg2LWZjZmEtMTFlYi04NjkxLTAyNDJhYzExMDAwNGpsaU1HUlNmQFVPJSFOSH0kYnNtOjE2Mjg5NDM4NzIuNTA0MDQ5OjE3NzljZWY2MDgyOGIwMjE0NGI2NGMxYmMyODliYTY1"}
```
Same service, the 2 minutes before (oldest first):
  20:23:19.159 [dbservice2] INFO 68301b08-fcfa-11eb-b436-0242ac110003-IwBSEYcZ-(ytghoMs$0KL token generate success token=MTYyODk0Mzc5OS4xNTg5OTU0OjY4MzAxYjA4LWZjZmEtMTFlYi1iNDM2LTAyNDJhYzE
  20:23:19.772 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  20:23:19.772 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  20:23:19.788 [dbservice2] INFO query = select passwards from username_table where user_name='lkNrGYTL'  (×5)
  20:23:19.865 [dbservice2] INFO 68a5b64c-fcfa-11eb-8e96-0242ac110004-lkNrGYTL-S$afkB0(o_gn token generate success token=MTYyODk0Mzc5OS44NjUzMjE5OjY4YTViNjRjLWZjZmEtMTFlYi04ZTk2LTAyNDJhYzE
  20:23:20.671 [dbservice2] INFO 6910b21c-fcfa-11eb-b0f5-0242ac110003-pXfjsTOr-0GYex1pad2DZ token generate success token=MTYyODk0MzgwMC42NzA2NDU6NjkxMGIyMWMtZmNmYS0xMWViLWIwZjUtMDI0MmFjMTE
  20:23:23.850 [dbservice2] INFO 6afedec8-fcfa-11eb-a953-0242ac110004-ISmxpnEs--5/4Hwoa@2dU token generate success token=MTYyODk0MzgwMy44NDk3MTI2OjZhZmVkZWM4LWZjZmEtMTFlYi1hOTUzLTAyNDJhYzE
  20:23:28.800 [dbservice2] INFO 6ddd1b6e-fcfa-11eb-be08-0242ac110003-vEGoarin-aD/}1_Q-2%xq token generate success token=MTYyODk0MzgwOC44MDAyMzY6NmRkZDFiNmUtZmNmYS0xMWViLWJlMDgtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  20:23:02.530 [redisservice2] INFO service accept, status_code: 200  (×53)
  20:23:02.919 [webservice2] INFO complete information: {'uuid': '5ec7e4ba-fcfa-11eb-8fdc-0242ac110004', 'user_id': 'BHYNveZc'}  (×45)
  20:23:03.056 [redisservice1] INFO redis write success  (×77)
  20:23:03.228 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '5ec7e4ba-fcfa-11eb-8fdc-0242ac110004', 'user_id': 'BHYNveZc'}  (×87)
  20:23:03.297 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×57)
  20:23:03.868 [mobservice1] INFO info 5f4d5f96-fcfa-11eb-b496-0242ac110004:dzcaqmiU write success
  20:23:04.260 [dbservice1] INFO 5f4d5f96-fcfa-11eb-b496-0242ac110004-dzcaqmiU-y0Gd$h@MNAoL token generate success token=MTYyODk0Mzc4NC4yNjAwMTAyOjVmNGQ1Zjk2LWZjZmEtMTFlYi1iNDk2LTAyNDJhYzE
  20:23:04.704 [mobservice1] INFO info 5fc1e564-fcfa-11eb-82e3-0242ac110003:oGQcxZEF write success
  20:23:06.364 [mobservice2] INFO info 60ba0e74-fcfa-11eb-868e-0242ac110004:QClFzynH write success
  20:23:08.955 [mobservice1] INFO info 62452f44-fcfa-11eb-853e-0242ac110003:MGhzxsST write success
  20:23:11.357 [mobservice2] INFO info 63bc8ec6-fcfa-11eb-a22a-0242ac110004:MBoWvOAG write success
  20:23:14.744 [mobservice1] INFO info 65c0467c-fcfa-11eb-9f4b-0242ac110004:CSoBqsmk write success
  20:23:17.650 [dbservice2] INFO 674b37f4-fcfa-11eb-babc-0242ac110004-aZMCtwXA-S!NRjF$n*AB_ token generate success token=MTYyODk0Mzc5Ny42NTAyMDM3OjY3NGIzN2Y0LWZjZmEtMTFlYi1iYWJjLTAyNDJhYzE
  20:23:20.671 [dbservice2] INFO 6910b21c-fcfa-11eb-b0f5-0242ac110003-pXfjsTOr-0GYex1pad2DZ token generate success token=MTYyODk0MzgwMC42NzA2NDU6NjkxMGIyMWMtZmNmYS0xMWViLWIwZjUtMDI0MmFjMTE
  20:23:23.085 [dbservice1] INFO 6a7795b2-fcfa-11eb-999c-0242ac110003-SjMAKXaq-9iISt>qQZ7<X token generate success token=MTYyODk0MzgwMy4wODQ2ODUzOjZhNzc5NWIyLWZjZmEtMTFlYi05OTljLTAyNDJhYzE
  20:23:25.423 [dbservice1] INFO 6bec19f4-fcfa-11eb-8dfe-0242ac110003-VvLhTogZ-c=V#H@AY&IQ4 token generate success token=MTYyODk0MzgwNS40MjM0NDkzOjZiZWMxOWY0LWZjZmEtMTFlYi04ZGZlLTAyNDJhYzE
  20:23:27.714 [dbservice1] INFO 6d4b2678-fcfa-11eb-a01b-0242ac110003-dIHpsMvT-UQ)#EA.:F_XL token generate success token=MTYyODk0MzgwNy43MTM2NDc0OjZkNGIyNjc4LWZjZmEtMTFlYi1hMDFiLTAyNDJhYzE
  20:23:30.151 [dbservice1] INFO 6eb834f6-fcfa-11eb-aab3-0242ac110003-MXIwargu-ua>(SrBpfXKs token generate success token=MTYyODk0MzgxMC4xNTA3OTI2OjZlYjgzNGY2LWZjZmEtMTFlYi1hYWIzLTAyNDJhYzE
  20:23:32.910 [mobservice2] INFO info 70972610-fcfa-11eb-b9a7-0242ac110003:jHRvwBZi write success
  20:23:35.451 [mobservice2] INFO info 721b1a64-fcfa-11eb-be2e-0242ac110004:QSUqdTsv write success
  20:23:38.115 [mobservice2] INFO info 73a99d9c-fcfa-11eb-8b23-0242ac110004:xomaJMly write success
  20:23:41.662 [mobservice2] INFO info 75c92110-fcfa-11eb-9737-0242ac110003:zoYxJZbF write success
  20:23:44.612 [dbservice1] INFO 77528dd2-fcfa-11eb-ae78-0242ac110003-QvNLTxkS-RZxlh$^b6pnw token generate success token=MTYyODk0MzgyNC42MTIxNTgzOjc3NTI4ZGQyLWZjZmEtMTFlYi1hZTc4LTAyNDJhYzE
  20:23:47.158 [dbservice2] INFO 78d4e358-fcfa-11eb-b55e-0242ac110004-WefLRrQS-GU9{g+v6(X0m token generate success token=MTYyODk0MzgyNy4xNTc3NTU6NzhkNGUzNTgtZmNmYS0xMWViLWI1NWUtMDI0MmFjMTE
  20:23:49.908 [dbservice1] INFO 7a7c9200-fcfa-11eb-a2c7-0242ac110004-spFyrBHI-q7DbzX1CUA=% token generate success token=MTYyODk0MzgyOS45MDgzMzM6N2E3YzkyMDAtZmNmYS0xMWViLWEyYzctMDI0MmFjMTE
  20:23:52.775 [dbservice1] INFO 7c27a892-fcfa-11eb-a7d2-0242ac110004-lebfEIwL-N(UKYsd1kEm4 token generate success token=MTYyODk0MzgzMi43NzUwNzc2OjdjMjdhODkyLWZjZmEtMTFlYi1hN2QyLTAyNDJhYzE
  20:23:55.421 [dbservice1] INFO 7dc89aee-fcfa-11eb-a7e6-0242ac110003-BuiqHsCZ-9fT<+%?POyQv token generate success token=MTYyODk0MzgzNS40MjA5ODYyOjdkYzg5YWVlLWZjZmEtMTFlYi1hN2U2LTAyNDJhYzE
  20:23:59.040 [mobservice2] INFO info 80259dd2-fcfa-11eb-a5fe-0242ac110003:qfINGhoa write success
  20:24:01.546 [mobservice2] INFO info 81a5e6d0-fcfa-11eb-9b35-0242ac110004:hUmNCczf write success

## p0621
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-inside-payment-service, 2024-12-07T20:17:36.472Z
```
{"timestamp":1733602656472539000,"container_name":"ts-inside-payment-service","pod_name":"ts-inside-payment-service-6bfcd599c9-x44n5","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 20:17:36.471  INFO 1 --- [io-18673-exec-6] i.service.InsidePaymentServiceImpl       : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay."}
```
Same service, the 2 minutes before (oldest first):
  20:15:57.162 [ts-inside-payment-service] 2024-12-07 20:15:57.161 INFO 1 --- [io-18673-exec-3] i.controller.InsidePaymentController : [Inside Payment Service][Pay] Pay for: 85a81a80-06d2-445c-8900-13ed2  (×4)
  20:15:57.172 [ts-inside-payment-service] 2024-12-07 20:15:57.172 INFO 1 --- [io-18673-exec-3] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.  (×3)
All services, 30 seconds either side (sampled):
  20:17:06.750 [ts-admin-basic-info-service] 2024-12-07 20:17:06.749 INFO 1 --- [io-18767-exec-1] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×17)
  20:17:12.371 [ts-auth-service] 2024-12-07 20:17:12.370 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×23)
  20:17:12.401 [ts-auth-service] 2024-12-07 20:17:12.401 INFO 1 --- [io-12340-exec-4] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×12)
  20:17:12.601 [ts-admin-travel-service] 2024-12-07 20:17:12.601 INFO 1 --- [io-16114-exec-5] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×13)
  20:17:12.633 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:12 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×14)
  20:17:22.669 [ts-route-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  20:17:27.209 [ts-travel-service] 2024-12-07 20:17:27.209 ERROR 1 --- [o-12346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  20:17:28.498 [ts-route-mongo] {"t":{"$date":"2024-12-07T20:17:28.498+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360264
  20:17:29.626 [ts-auth-service] 2024-12-07 20:17:29.626 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
  20:17:31.156 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T20:17:31.156+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:31.663 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:17:31.663+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:35.032 [ts-route-service] Error opening zip file or JAR manifest missing : /tmp/opentelemetry-javaagent.jar
  20:17:36.164 [ts-route-service] 2024-12-07 20:17:36.163 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def
  20:17:36.474 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:36 +0800] "POST /api/v1/inside_pay_service/inside_payment HTTP/1.1" 200 83 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
  20:17:38.176 [ts-route-service] 2024-12-07 20:17:38.176 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact
  20:17:38.770 [ts-travel-service] 2024-12-07 20:17:38.770 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  20:17:41.056 [ts-route-service] 2024-12-07 20:17:41.055 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 11178 (http)
  20:17:42.999 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T20:17:42.999+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360266
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  20:17:46.959 [ts-route-service] 2024-12-07 20:17:46.957 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes],methods=[GET]}" onto public org.spr
  20:17:51.174 [ts-route-service] 2024-12-07 20:17:51.173 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  20:17:52.759 [ts-route-service] 2024-12-07 20:17:52.759 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[application/vnd.sprin
  20:17:52.762 [ts-route-service] 2024-12-07 20:17:52.762 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  20:17:52.765 [ts-route-service] 2024-12-07 20:17:52.765 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/vnd.spring-bo
  20:17:55.659 [ts-route-service] 2024-12-07 20:17:55.659 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class org.springfra
  20:18:00.870 [ts-route-service] 2024-12-07 20:18:00.870 INFO 1 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  20:18:01.659 [ts-route-service] 2024-12-07 20:18:01.657 INFO 1 --- [ main] d.s.w.p.DocumentationPluginsBootstrapper : Found 1 custom documentation plugin(s)
  20:18:03.854 [ts-route-service] 2024-12-07 20:18:03.853 INFO 1 --- [ main] org.mongodb.driver.connection : Opened connection [connectionId{localValue:2, serverValue:25}] to ts-route-mongo:2701
  20:18:04.554 [ts-route-service] 2024-12-07 20:18:04.554 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: suzhou End: shanghai

## p0819
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-admin-basic-info-service, 2024-12-10T13:27:38.041Z
```
{"timestamp":1733837258041291800,"container_name":"ts-admin-basic-info-service","pod_name":"ts-admin-basic-info-service-87bf97b79-2gh44","node_name":"ip-192-168-64-253.ap-southeast-2.compute.internal","message":"2024-12-10 13:27:38.041 ERROR 1 --- [io-18767-exec-6] edu.fudan.common.security.jwt.JWTUtil    : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwtException: JWT strings must contain exactly 2 period characters. Found: 0"}
```
Same service, the 2 minutes before (oldest first):
  13:27:15.744 [ts-admin-basic-info-service] 2024-12-10 13:27:15.744 ERROR 1 --- [io-18767-exec-7] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×6)
  13:27:15.744 [ts-admin-basic-info-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×7)
  13:27:19.754 [ts-admin-basic-info-service] 2024-12-10 13:27:19.754 ERROR 1 --- [io-18767-exec-8] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×5)
  13:27:21.040 [ts-admin-basic-info-service] 2024-12-10 13:27:21.040 ERROR 1 --- [o-18767-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  13:27:21.041 [ts-admin-basic-info-service] 2024-12-10 13:27:21.041 ERROR 1 --- [o-18767-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
All services, 30 seconds either side (sampled):
  13:27:08.348 [ts-admin-basic-info-service] 2024-12-10 13:27:08.347 ERROR 1 --- [io-18767-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×19)
  13:27:08.351 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:08 +0800] "GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×12)
  13:27:09.625 [ts-auth-service] 2024-12-10 13:27:09.625 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×22)
  13:27:09.641 [ts-travel2-service] 2024-12-10 13:27:09.641 ERROR 1 --- [o-16346-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  13:27:09.644 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:09 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 500 228 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×13)
  13:27:10.732 [ts-admin-travel-service] 2024-12-10 13:27:10.732 ERROR 1 --- [io-16114-exec-7] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×11)
  13:27:10.736 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:10 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 500 233 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×12)
  13:27:11.950 [ts-order-mongo] {"t":{"$date":"2024-12-10T13:27:11.950+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:12.151 [ts-assurance-mongo] {"t":{"$date":"2024-12-10T13:27:12.150+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:12.457 [ts-order-other-mongo] {"t":{"$date":"2024-12-10T13:27:12.456+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:12.482 [ts-order-other-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  13:27:12.650 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-10T13:27:12.650+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:12.819 [ts-notification-mongo] {"t":{"$date":"2024-12-10T13:27:12.819+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:13.326 [ts-security-mongo] {"t":{"$date":"2024-12-10T13:27:13.326+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:13.347 [ts-price-mongo] {"t":{"$date":"2024-12-10T13:27:13.346+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:15.045 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-10T13:27:15.045+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:15.213 [ts-consign-mongo] {"t":{"$date":"2024-12-10T13:27:15.213+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:15.543 [ts-food-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×4)
  13:27:20.497 [ts-auth-service] 2024-12-10 13:27:20.497 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  13:27:20.714 [ts-auth-service] 2024-12-10 13:27:20.714 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×3)
  13:27:21.742 [ts-order-service] 2024-12-10 13:27:21.742 ERROR 1 --- [io-12031-exec-8] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  13:27:21.747 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:21 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 500 229 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Apple
  13:27:41.459 [ts-travel-service] 2024-12-10 13:27:41.458 ERROR 1 --- [io-12346-exec-1] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  13:27:41.462 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:41 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 500 227 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe

## p0116
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:17:40.210Z
```
{"timestamp":1731907060210773000,"container_name":"adservice","pod_name":"adservice-b9bcc6cc9-h4k2c","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"*** shutting down gRPC ads server since JVM is shutting down"}
```
Same service, the 2 minutes before (oldest first):
  05:17:33.734 [adservice] received ad request (context_words=[accessories])  (×3)
  05:17:34.069 [adservice] received ad request (context_words=[decor, home])
  05:17:34.221 [adservice] received ad request (context_words=[kitchen])  (×4)
  05:17:34.919 [adservice] received ad request (context_words=[footwear])  (×2)
  05:17:34.960 [adservice] received ad request (context_words=[hair, beauty])  (×5)
  05:17:37.384 [adservice] received ad request (context_words=[clothing, tops])  (×3)
  05:17:38.820 [adservice] received ad request (context_words=[])  (×2)
All services, 30 seconds either side (sampled):
  05:17:10.253 [frontend] request started  (×280)
  05:17:10.260 [cartservice] GetCartAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432  (×238)
  05:17:10.285 [adservice] received ad request (context_words=[accessories])  (×12)
  05:17:10.324 [frontend] adding to cart  (×24)
  05:17:10.367 [shippingservice] [GetQuote] received request  (×76)
  05:17:12.011 [adservice] received ad request (context_words=[clothing, tops])  (×8)
  05:17:12.236 [frontend] ENV_PLATFORM is: aws  (×30)
  05:17:16.636 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '66VCHSJNUP']  (×4)
  05:17:16.693 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"1792","nanos":226454698},"credit_card":{"credit_card_number":"4639203387545  (×4)
  05:17:16.696 [shippingservice] [ShipOrder] received request  (×7)
  05:17:16.705 [emailservice] A request to send order confirmation email to abowman@example.com has been received.
  05:17:16.824 [emailservice] A request to send order confirmation email to barbara24@example.com has been received.
  05:17:23.425 [adservice] received ad request (context_words=[footwear])  (×6)
  05:17:24.111 [paymentservice] Transaction processed: visa ending 1703 Amount: CAD346.438559926  (×2)
  05:17:25.127 [emailservice] A request to send order confirmation email to coxchristine@example.net has been received.
  05:17:40.213 [adservice] *** server shut down
  05:17:43.747 [adservice] AdService starting.  (×2)
  05:17:43.841 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.  (×2)
  05:17:45.450 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  05:17:55.239 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="EUR"
  05:17:55.276 [emailservice] A request to send order confirmation email to alopez@example.org has been received.
  05:18:02.298 [checkoutservice] order confirmation email sent to "caseyhoward@example.com"

## p0320
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service payment, 2024-11-22T03:20:52.843Z
```
{"timestamp":1732245652843076400,"container_name":"payment","pod_name":"payment-78bf948dc4-kdg7s","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:20:52Z caller=logging.go:40 method=Health result=1 took=7.058µs"}
```
Same service, the 2 minutes before (oldest first):
  03:20:22.843 [payment] ts=2024-11-22T03:20:22Z caller=logging.go:40 method=Health result=1 took=7.479µs  (×20)
All services, 30 seconds either side (sampled):
  03:20:22.843 [payment] ts=2024-11-22T03:20:22Z caller=logging.go:40 method=Health result=1 took=7.479µs  (×41)
  03:20:23.465 [front-end] Request received with body: {}  (×64)
  03:20:23.527 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×46)
  03:20:24.296 [front-end] POST /addresses 200 - ms - -  (×59)
  03:20:24.597 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×8)
  03:20:27.856 [front-end] Posting Customer: {"username":"dpZIGojLodgB","password":"ZuQfdM","email":"dpZIGojLodgB@gmail.com","firstName":"dpZIGojLodgB","lastName":"dpZIGojLodgB"}
  03:20:30.803 [user] ts=2024-11-22T03:20:30.803179178Z caller=middlewares.go:46 method=Register username=MpDJxkmv email=MpDJxkmv@gmail.com took=1.03144ms
  03:20:34.372 [front-end] Received response: "{\"firstName\":\"CBhyKd\",\"lastName\":\"CBhyKd\",\"username\":\"CBhyKd\",\"id\":\"673ff869b0df5c00019b1eba\",\"_links\":{\"addresses\":{\"h
  03:20:38.070 [session-db] 1:M 22 Nov 2024 03:20:38.070 * Background saving started by pid 32
  03:20:42.525 [front-end] Posting Customer: {"username":"jVIVRgJfOAq","password":"zWZXxq","email":"jVIVRgJfOAq@gmail.com","firstName":"jVIVRgJfOAq","lastName":"jVIVRgJfOAq"}
  03:20:43.391 [carts] 2024-11-22 03:20:43.391 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.sp
  03:20:51.970 [front-end] Posting Customer: {"username":"nPklGOsvzh","password":"YuEpn","email":"nPklGOsvzh@gmail.com","firstName":"nPklGOsvzh","lastName":"nPklGOsvzh"}
  03:20:56.307 [front-end] Posting Customer: {"username":"TxflHMpaWteY","password":"HuykDEusv","email":"TxflHMpaWteY@gmail.com","firstName":"TxflHMpaWteY","lastName":"TxflHMpaWteY"}
  03:20:59.685 [carts] 2024-11-22 03:20:59.685 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+json
  03:20:59.785 [carts] 2024-11-22 03:20:59.785 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[GE
  03:20:59.886 [carts] 2024-11-22 03:20:59.885 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applicati  (×2)
  03:21:02.584 [front-end] Posting Customer: {"username":"sQAAadzpZlKDfq","password":"reYll","email":"sQAAadzpZlKDfq@gmail.com","firstName":"sQAAadzpZlKDfq","lastName":"sQAAadzpZlKDfq"}
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]
  03:21:04.427 [front-end] Posting Customer: {"username":"qklQL","password":"OfLCWzLJmr","email":"qklQL@gmail.com","firstName":"qklQL","lastName":"qklQL"}
  03:21:08.790 [carts] 2024-11-22 03:21:08.790 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  03:21:09.807 [front-end] Received response: "{\"firstName\":\"URVWiLVbByzZ\",\"lastName\":\"URVWiLVbByzZ\",\"username\":\"URVWiLVbByzZ\",\"id\":\"673ff889b0df5c00019b1f1d\",\"_links\":{
  03:21:12.988 [carts] 2024-11-22 03:21:12.988 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  03:21:15.278 [user] ts=2024-11-22T03:21:15.27845523Z caller=middlewares.go:46 method=Register username=xlSpYB email=xlSpYB@gmail.com took=1.032808ms
  03:21:17.383 [front-end] Received response: "{\"firstName\":\"isaznhmc\",\"lastName\":\"isaznhmc\",\"username\":\"isaznhmc\",\"id\":\"673ff89db0df5c00019b1f52\",\"_links\":{\"addresses\
  03:21:18.602 [orders] 2024-11-22 03:21:18.602 INFO [orders,145906930ffa3fb8,359c2f868402564c,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×6)
  03:21:18.708 [front-end] Order response: {"id":"673ff8aed94b9000069b438d","customerId":"673ff891b0df5c00019b1f2a","customer":{"id":null,"firstName":"asYAoymkBkzj","lastName":"asYAoymkBk
  03:21:19.317 [front-end] Order response: {"id":"673ff8afd94b9000069b4391","customerId":"673ff896b0df5c00019b1f3c","customer":{"id":null,"firstName":"cfTPDbfduekTBf","lastName":"cfTPDbfd
  03:21:19.922 [front-end] Received response: "{\"firstName\":\"pNgaEfQnfRl\",\"lastName\":\"pNgaEfQnfRl\",\"username\":\"pNgaEfQnfRl\",\"id\":\"673ff899b0df5c00019b1f45\",\"_links\":{\"a
  03:21:20.783 [carts] 2024-11-22 03:21:20.783 INFO [carts,c68cb8218e3d30a3,e9e627c1a2386c43,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)

## p0636
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T20:23:56.503Z
```
{"timestamp":1733603036503339500,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-nsc8q","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:23:56.503  INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl             : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainNumber='Z1234', startStation='shanghai', destStation='nanjing', seatType=2}"}
```
Same service, the 2 minutes before (oldest first):
  20:23:54.107 [ts-seat-service] 2024-12-07 20:23:54.107 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×2)
  20:23:54.127 [ts-seat-service] 2024-12-07 20:23:54.127 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×2)
  20:23:54.136 [ts-seat-service] 2024-12-07 20:23:54.136 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  20:23:54.152 [ts-seat-service] 2024-12-07 20:23:54.152 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×2)
  20:23:54.152 [ts-seat-service] 2024-12-07 20:23:54.152 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  20:23:54.164 [ts-seat-service] 2024-12-07 20:23:54.164 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×2)
  20:23:55.330 [ts-seat-service] 2024-12-07 20:23:55.330 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN
  20:23:55.330 [ts-seat-service] 2024-12-07 20:23:55.330 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
  20:23:55.348 [ts-seat-service] 2024-12-07 20:23:55.348 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  20:23:55.361 [ts-seat-service] 2024-12-07 20:23:55.360 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:23:55.379 [ts-seat-service] 2024-12-07 20:23:55.379 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re
  20:23:55.379 [ts-seat-service] 2024-12-07 20:23:55.379 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  20:23:55.386 [ts-seat-service] 2024-12-07 20:23:55.385 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri
  20:23:55.418 [ts-seat-service] 2024-12-07 20:23:55.417 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN
All services, 30 seconds either side (sampled):
  20:23:26.508 [ts-travel-service] 2024-12-07 20:23:26.507 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：aefcef3f-3f42-46e8-afd7-6cb2a  (×70)
  20:23:26.571 [ts-travel2-service] 2024-12-07 20:23:26.570 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×171)
  20:23:29.423 [ts-auth-service] 2024-12-07 20:23:29.422 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×3)
  20:23:29.683 [ts-basic-service] 2024-12-07 20:23:29.683 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×10)
  20:23:29.716 [ts-travel2-service] 2024-12-07 20:23:29.715 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×19)
  20:23:29.879 [ts-seat-service] 2024-12-07 20:23:29.878 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×28)
  20:23:30.859 [ts-order-other-service] 2024-12-07 20:23:30.859 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×25)
  20:23:31.052 [ts-seat-service] 2024-12-07 20:23:31.052 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  20:23:31.721 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:23:31.720+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360301
  20:23:33.350 [ts-consign-service] 2024-12-07 20:23:33.350 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : The handle date is 2024-12-07  (×2)
  20:23:34.158 [ts-basic-service] 2024-12-07 20:23:34.158 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×4)
  20:23:34.276 [ts-order-service] 2024-12-07 20:23:34.276 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160,   (×2)
  20:23:34.621 [ts-preserve-service] 2024-12-07 20:23:34.621 INFO 1 --- [io-14568-exec-3] preserve.controller.PreserveController : [Preserve Service][Preserve] Account order from Shang Hai -----> S
  20:23:34.663 [ts-security-service] 2024-12-07 20:23:34.663 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service] Max In One Hour: 2147483647 Max Not Use: 21474836  (×2)
  20:23:34.686 [ts-travel-service] 2024-12-07 20:23:34.686 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  20:23:35.077 [ts-seat-service] 2024-12-07 20:23:35.077 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService distributeSeat] The result of getRouteResult is Success
  20:23:35.181 [ts-preserve-service] 2024-12-07 20:23:35.181 INFO 1 --- [io-14568-exec-3] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 4] Do Order Complete
  20:23:36.240 [ts-food-service] 2024-12-07 20:23:36.239 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:23:42.239 [ts-admin-basic-info-service] 2024-12-07 20:23:42.239 INFO 1 --- [io-18767-exec-2] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×5)
  20:23:56.470 [ts-inside-payment-service] 2024-12-07 20:23:56.469 INFO 1 --- [io-18673-exec-2] i.service.InsidePaymentServiceImpl : Out pay result: Response(status=1, msg=Pay Success, data=null)
  20:23:57.372 [ts-order-service] 2024-12-07 20:23:57.372 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : Left ticket info is empty  (×10)
  20:24:02.109 [ts-preserve-other-service] 2024-12-07 20:24:02.109 INFO 1 --- [io-14569-exec-4] p.controller.PreserveOtherController : [Preserve Other Service][Preserve] Account order from Shang Hai ----  (×2)
  20:24:02.148 [ts-preserve-other-service] 2024-12-07 20:24:02.147 INFO 1 --- [io-14569-exec-4] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security Complete.   (×2)
  20:24:02.221 [ts-basic-service] 2024-12-07 20:24:02.221 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×2)
  20:24:02.564 [ts-travel2-service] 2024-12-07 20:24:02.564 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×4)
  20:24:02.690 [ts-order-other-service] 2024-12-07 20:24:02.690 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Create Order] Create Order form shanghai --->  (×2)
  20:24:03.770 [ts-basic-service] 2024-12-07 20:24:03.770 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  20:24:09.969 [ts-order-other-service] 2024-12-07 20:24:09.969 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392
  20:24:15.338 [ts-travel-service] 2024-12-07 20:24:15.338 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan

## p0104
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:07:17.652Z
```
{"timestamp":1731906437652615200,"container_name":"adservice","pod_name":"adservice-b9bcc6cc9-h4k2c","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"received ad request (context_words=[decor, home])"}
```
Same service, the 2 minutes before (oldest first):
  05:07:10.473 [adservice] received ad request (context_words=[kitchen])  (×8)
  05:07:10.902 [adservice] received ad request (context_words=[decor, home])  (×3)
  05:07:11.289 [adservice] received ad request (context_words=[hair, beauty])  (×4)
  05:07:11.891 [adservice] received ad request (context_words=[footwear])
  05:07:13.911 [adservice] received ad request (context_words=[])  (×2)
  05:07:14.139 [adservice] received ad request (context_words=[clothing, tops])  (×2)
All services, 30 seconds either side (sampled):
  05:06:48.245 [frontend] request started  (×306)
  05:06:48.250 [currencyservice] Getting supported currencies...  (×250)
  05:06:48.261 [currencyservice] conversion request successful  (×735)
  05:06:48.278 [adservice] received ad request (context_words=[accessories])  (×21)
  05:06:48.646 [frontend] view user cart  (×64)
  05:06:48.670 [shippingservice] [GetQuote] received request  (×69)
  05:06:48.752 [adservice] received ad request (context_words=[hair, beauty])  (×23)
  05:06:49.226 [frontend] adding to cart  (×32)
  05:06:49.283 [frontend] placing order  (×5)
  05:06:49.310 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"5601","nanos":25960215},"credit_card":{"credit_card_number":"49393496482936
  05:06:49.312 [checkoutservice] payment went through (transaction_id: 978621c7-6f95-4076-b8b6-f97d36b1d7a9)  (×5)
  05:06:49.313 [shippingservice] [ShipOrder] completed request  (×5)
  05:06:49.327 [emailservice] A request to send order confirmation email to suzannerush@example.net has been received.
  05:06:49.329 [frontend] order placed  (×5)
  05:06:49.484 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"1363","nanos":260000000},"credit_card":{"credit_card_number":"4909124675051  (×2)
  05:06:49.497 [emailservice] A request to send order confirmation email to doconnell@example.net has been received.
  05:06:51.467 [adservice] received ad request (context_words=[footwear])  (×16)
  05:06:52.749 [frontend] ENV_PLATFORM is: aws  (×32)
  05:06:52.846 [adservice] received ad request (context_words=[decor, home])  (×17)
  05:06:53.428 [frontend] setting currency  (×24)
  05:07:06.725 [checkoutservice] [PlaceOrder] user_id="33421b66-55b6-413b-9ba9-3230c85c58dc" user_currency="CAD"  (×2)
  05:07:06.768 [paymentservice] Transaction processed: visa ending 2818 Amount: CAD2968.875018134  (×2)
  05:07:06.782 [checkoutservice] order confirmation email sent to "charles21@example.org"
  05:07:12.845 [checkoutservice] order confirmation email sent to "abbottdaniel@example.net"
  05:07:22.573 [checkoutservice] order confirmation email sent to "jacksonthomas@example.org"

## p0813
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-admin-travel-service, 2024-12-10T13:12:15.840Z
```
{"timestamp":1733836335840305700,"container_name":"ts-admin-travel-service","pod_name":"ts-admin-travel-service-5c866595d6-bscdc","node_name":"ip-192-168-51-182.ap-southeast-2.compute.internal","message":"2024-12-10 13:12:15.840  INFO 1 --- [io-16114-exec-9] a.service.AdminTravelServiceImpl         : [Admin Travel Service][Get Travel From ts-travel2-service successfully!]"}
```
Same service, the 2 minutes before (oldest first):
  13:11:36.934 [ts-admin-travel-service] 2024-12-10 13:11:36.933 INFO 1 --- [io-16114-exec-9] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×7)
  13:11:37.045 [ts-admin-travel-service] 2024-12-10 13:11:37.044 INFO 1 --- [io-16114-exec-9] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×13)
All services, 30 seconds either side (sampled):
  13:11:46.001 [ts-auth-service] 2024-12-10 13:11:45.999 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×23)
  13:11:46.030 [ts-basic-service] 2024-12-10 13:11:46.030 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×11)
  13:11:46.081 [ts-travel2-service] 2024-12-10 13:11:46.080 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×80)
  13:11:46.199 [ts-route-service] 2024-12-10 13:11:46.198 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×16)
  13:11:47.437 [ts-travel-service] 2024-12-10 13:11:47.437 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×3)
  13:11:47.463 [ts-travel-service] 2024-12-10 13:11:47.463 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×35)
  13:11:48.616 [ts-food-map-service] 2024-12-10 13:11:48.616 INFO 1 --- [io-18855-exec-3] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×5)
  13:11:48.639 [ts-travel-service] 2024-12-10 13:11:48.639 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×15)
  13:11:50.291 [ts-order-service] 2024-12-10 13:11:50.291 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Query Order][Step 1] Get Orders Number of Account: 3
  13:11:50.331 [ts-consign-service] 2024-12-10 13:11:50.331 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : [Consign servie] [ Update consign record]
  13:11:50.336 [ts-consign-service] 2024-12-10 13:11:50.336 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : The target date is 2024-12-10 13:11:50
  13:11:52.408 [ts-auth-service] 2024-12-10 13:11:52.407 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×12)
  13:11:52.662 [ts-travel-service] 2024-12-10 13:11:52.662 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×11)
  13:11:52.808 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:11:52 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5514 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×12)
  13:11:55.432 [ts-travel-service] 2024-12-10 13:11:55.432 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×3)
  13:11:56.842 [ts-admin-basic-info-service] 2024-12-10 13:11:56.842 INFO 1 --- [io-18767-exec-6] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×10)
  13:12:05.212 [ts-food-service] 2024-12-10 13:12:05.212 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345
  13:12:11.836 [ts-station-mongo] {"t":{"$date":"2024-12-10T13:12:11.835+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383633
  13:12:12.313 [ts-order-other-mongo] {"t":{"$date":"2024-12-10T13:12:12.313+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383633
  13:12:12.667 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-10T13:12:12.667+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383633
  13:12:13.191 [ts-travel2-mongo] {"t":{"$date":"2024-12-10T13:12:13.191+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383633
  13:12:14.879 [ts-train-mongo] {"t":{"$date":"2024-12-10T13:12:14.879+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383633
  13:12:14.917 [ts-travel-mongo] {"t":{"$date":"2024-12-10T13:12:14.916+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383633
  13:12:17.031 [ts-travel-service] 2024-12-10 13:12:17.031 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×6)
  13:12:17.098 [ts-travel-service] 2024-12-10 13:12:17.098 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×2)
  13:12:37.237 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:12:37 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 200 119 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)  (×2)

## p0037
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T07:57:12.934Z
```
{"service":"dbservice1","message":"2021-08-13 07:57:12,934 | ERROR | 0.0.0.4 | 172.17.0.3 | dbservice1 | d8f7e47637504aee | (pymysql.err.OperationalError) (1054, \"Unknown column 'system_data_time' in 'field list'\")[SQL: select service_name, system_data_time, system_cpu_utilization, system_memory_usage,system_disk_usage, disk_io_read_count, disk_io_write_count,system_network, network_io_read_count, network_io_write_count from `metri…"}
```
Same service, the 2 minutes before (oldest first):
  07:56:56.875 [dbservice1] INFO query = select passwards from username_table where user_name='pVblEhjw'  (×5)
  07:56:56.952 [dbservice1] INFO f972852a-fbc8-11eb-b285-0242ac110003-pVblEhjw-SiZo2*.WPsa% token generate success token=MTYyODgxMjYxNi45NTIwNDczOmY5NzI4NTJhLWZiYzgtMTFlYi1iMjg1LTAyNDJhYzE
  07:57:09.274 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  07:57:09.274 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  07:57:09.403 [dbservice1] INFO 00dc9652-fbc9-11eb-9767-0242ac110004-GwpUdJLR-<=#>pyVh.A$d token generate success token=MTYyODgxMjYyOS40MDMxMTE3OjAwZGM5NjUyLWZiYzktMTFlYi05NzY3LTAyNDJhYzE
  07:57:11.055 [dbservice1] INFO 01e1da3a-fbc9-11eb-8c2d-0242ac110004-WYjcLizJ-pZYv_kf^:i!E token generate success token=MTYyODgxMjYzMS4wNTUyMzU6MDFlMWRhM2EtZmJjOS0xMWViLThjMmQtMDI0MmFjMTE
  07:57:11.929 [dbservice1] INFO 02622334-fbc9-11eb-9270-0242ac110003-qYMpFKOS-3_B8TGV!g<1j token generate success token=MTYyODgxMjYzMS45Mjg4NzQzOjAyNjIyMzM0LWZiYzktMTFlYi05MjcwLTAyNDJhYzE
  07:57:12.875 [dbservice1] INFO 02e0bae6-fbc9-11eb-bd9c-0242ac110003-NpSktBQI-ZNc-73/n1Rbm token generate success token=MTYyODgxMjYzMi44NzUzOTg0OjAyZTBiYWU2LWZiYzktMTFlYi1iZDljLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  07:56:43.803 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  07:56:43.977 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×36)
  07:56:44.138 [redisservice2] INFO redis write success  (×70)
  07:56:44.288 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': 'f20e2aa0-fbc8-11eb-92d1-0242ac110004', 'user_id': 'uloJcsne'}  (×63)
  07:56:44.470 [redisservice1] INFO service accept, status_code: 200  (×37)
  07:56:46.887 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×29)
  07:56:47.059 [mobservice1] INFO info f3c67d7a-fbc8-11eb-a51c-0242ac110003:lnbVdqst write success
  07:56:49.695 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×34)
  07:56:50.061 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×29)
  07:56:51.658 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  07:56:53.430 [dbservice1] INFO f75251d0-fbc8-11eb-9b7a-0242ac110003-EVBLhgrm-9os/__E:hq47 token generate success token=MTYyODgxMjYxMy40Mjk2NDY6Zjc1MjUxZDAtZmJjOC0xMWViLTliN2EtMDI0MmFjMTE
  07:56:55.902 [dbservice1] INFO f8dbd652-fbc8-11eb-a407-0242ac110004-APxbpyWu-<Fk%s3dztCD} token generate success token=MTYyODgxMjYxNS45MDE4MjA0OmY4ZGJkNjUyLWZiYzgtMTFlYi1hNDA3LTAyNDJhYzE
  07:57:01.496 [dbservice2] INFO fc341b66-fbc8-11eb-8896-0242ac110004-wRjEsaDr-6yOCQJ=RzT1( token generate success token=MTYyODgxMjYyMS40OTU4OTI6ZmMzNDFiNjYtZmJjOC0xMWViLTg4OTYtMDI0MmFjMTE
  07:57:08.559 [redisservice1] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400
  07:57:09.928 [mobservice1] INFO info 01659074-fbc9-11eb-a3ee-0242ac110004:uHrsPUfR write success
  07:57:12.454 [mobservice1] INFO info 02ea2ec8-fbc9-11eb-9c0b-0242ac110003:wzuckBhX write success
  07:57:15.227 [dbservice2] INFO 045cc950-fbc9-11eb-8407-0242ac110003-FWZKSkEd-d*WN%Kbw7ZHk token generate success token=MTYyODgxMjYzNS4yMjY3ODM4OjA0NWNjOTUwLWZiYzktMTFlYi04NDA3LTAyNDJhYzE
  07:57:17.906 [mobservice1] INFO info 062a0f0e-fbc9-11eb-b1d3-0242ac110003:KvpoNGOC write success
  07:57:19.676 [dbservice2] INFO 070a5032-fbc9-11eb-8e21-0242ac110004-AMGHfWVz-IboWt}1>NAEC token generate success token=MTYyODgxMjYzOS42NzU4NzM1OjA3MGE1MDMyLWZiYzktMTFlYi04ZTIxLTAyNDJhYzE
  07:57:21.875 [mobservice2] INFO info 088893ec-fbc9-11eb-9d29-0242ac110004:zFRIyZKg write success
  07:57:24.103 [dbservice2] INFO 09b5d478-fbc9-11eb-88ff-0242ac110003-UEASdwYn-lX/Z%YE&xQ5: token generate success token=MTYyODgxMjY0NC4xMDI3ODI3OjA5YjVkNDc4LWZiYzktMTFlYi04OGZmLTAyNDJhYzE
  07:57:26.565 [mobservice2] INFO info 0b578e52-fbc9-11eb-b2a5-0242ac110004:ArxCmQcb write success
  07:57:28.652 [dbservice2] INFO 0c616796-fbc9-11eb-8cbc-0242ac110003-zoVLGdbn-)#WhFj$b=<CN token generate success token=MTYyODgxMjY0OC42NTIyOTgyOjBjNjE2Nzk2LWZiYzktMTFlYi04Y2JjLTAyNDJhYzE
  07:57:30.663 [mobservice2] INFO info 0dcb9818-fbc9-11eb-87e7-0242ac110004:hsyfMqgb write success
  07:57:32.649 [dbservice1] INFO 0eccca84-fbc9-11eb-8565-0242ac110003-MfgEVxGn-&F1b%*m}.ro4 token generate success token=MTYyODgxMjY1Mi42NDkwNTI2OjBlY2NjYTg0LWZiYzktMTFlYi04NTY1LTAyNDJhYzE
  07:57:35.076 [dbservice2] INFO 1027b100-fbc9-11eb-90cb-0242ac110004-PwhZOREl-WRJ.O)$mF28d token generate success token=MTYyODgxMjY1NS4wNzYxODI2OjEwMjdiMTAwLWZiYzktMTFlYi05MGNiLTAyNDJhYzE

## p0303
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-22T03:20:12.068Z
```
{"timestamp":1732245612068921900,"container_name":"orders","pod_name":"orders-5fd66f9688-2x7kx","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-22 03:20:12.068 ERROR [orders,,,] 6 --- [p-nio-80-exec-7] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalStateException: Unable to create order due to unspecified IO error.] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  03:20:06.586 [orders] 2024-11-22 03:20:06.586 ERROR [orders,,,] 6 --- [p-nio-80-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×2)
  03:20:06.587 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×3)
  03:20:09.137 [orders] 2024-11-22 03:20:09.137 ERROR [orders,,,] 6 --- [-nio-80-exec-14] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×23)
  03:20:06.543 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff854b0df5c00019b1e7f\",\"_links\":{\"  (×40)
  03:20:06.586 [orders] 2024-11-22 03:20:06.586 ERROR [orders,,,] 6 --- [p-nio-80-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×22)
  03:20:06.649 [user] ts=2024-11-22T03:20:06.649242768Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff861b0df5c00019b1e9e took=1.734848ms  (×42)
  03:20:06.769 [front-end] User cart deleted with status: 503  (×42)
  03:20:06.803 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×6)
  03:20:07.186 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×9)
  03:20:08.469 [front-end] Posting Customer: {"username":"HNCLfJfsnW","password":"sSvsy","email":"HNCLfJfsnW@gmail.com","firstName":"HNCLfJfsnW","lastName":"HNCLfJfsnW"}
  03:20:08.498 [front-end] Carts merged.  (×33)
  03:20:09.093 [user] ts=2024-11-22T03:20:09.093533288Z caller=middlewares.go:46 method=Register username=CBhyKd email=CBhyKd@gmail.com took=1.350871ms
  03:20:09.192 [carts] 2024-11-22 03:20:09.192 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  03:20:10.049 [front-end] Posting Customer: {"username":"lPEGqahDSutlQTj","password":"AoWWVDzGsz","email":"lPEGqahDSutlQTj@gmail.com","firstName":"lPEGqahDSutlQTj","lastName":"lPEGqahDSu
  03:20:12.002 [front-end] Received response: "{\"firstName\":\"oVuSYHHeDcohK\",\"lastName\":\"oVuSYHHeDcohK\",\"username\":\"oVuSYHHeDcohK\",\"id\":\"673ff855b0df5c00019b1e85\",\"_links\
  03:20:14.429 [front-end] Posting Customer: {"username":"LWbxoNrjdrYfe","password":"dgukoXmQfq","email":"LWbxoNrjdrYfe@gmail.com","firstName":"LWbxoNrjdrYfe","lastName":"LWbxoNrjdrYfe"}
  03:20:16.376 [front-end] Posting Customer: {"username":"zCHyJV","password":"DBVYLG","email":"zCHyJV@gmail.com","firstName":"zCHyJV","lastName":"zCHyJV"}
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:20.340 [front-end] Posting Customer: {"username":"BBYdunXrngQk","password":"jbihHjN","email":"BBYdunXrngQk@gmail.com","firstName":"BBYdunXrngQk","lastName":"BBYdunXrngQk"}
  03:20:23.473 [front-end] Received response: "{\"firstName\":\"AIHRSQU\",\"lastName\":\"AIHRSQU\",\"username\":\"AIHRSQU\",\"id\":\"673ff863b0df5c00019b1ea2\",\"_links\":{\"addresses\":{
  03:20:26.017 [front-end] Posting Customer: {"username":"HLNoIPafm","password":"sBlBYfK","email":"HLNoIPafm@gmail.com","firstName":"HLNoIPafm","lastName":"HLNoIPafm"}
  03:20:28.421 [front-end] Posting Customer: {"username":"MoGml","password":"PJpiau","email":"MoGml@gmail.com","firstName":"MoGml","lastName":"MoGml"}
  03:20:30.252 [front-end] Posting Customer: {"username":"MKGIsEbVYi","password":"VhFAQhsXw","email":"MKGIsEbVYi@gmail.com","firstName":"MKGIsEbVYi","lastName":"MKGIsEbVYi"}
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.186 [front-end] Received response: "{\"firstName\":\"kgzVKACfUvkHp\",\"lastName\":\"kgzVKACfUvkHp\",\"username\":\"kgzVKACfUvkHp\",\"id\":\"673ff869b0df5c00019b1ebd\",\"_links\
  03:20:36.109 [front-end] Posting Customer: {"username":"HWsmCvxoMrNqX","password":"MJvuU","email":"HWsmCvxoMrNqX@gmail.com","firstName":"HWsmCvxoMrNqX","lastName":"HWsmCvxoMrNqX"}
  03:20:38.070 [session-db] 1:M 22 Nov 2024 03:20:38.070 * Background saving started by pid 32
  03:20:39.079 [user] ts=2024-11-22T03:20:39.079141282Z caller=middlewares.go:46 method=Register username=ELXzX email=ELXzX@gmail.com took=1.044635ms

## p0021
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T06:46:11.850Z
```
{"service":"logservice1","message":"2021-08-13 06:46:11,850 | ERROR | 0.0.0.3 | logservice1 | login_helper.py -> login_query_methods_model -> 93 | cb9869c448d8e520 | get information failed, fail code: 400"}
```
Same service, the 2 minutes before (oldest first):
  06:46:08.595 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '15702f20-fbbf-11eb-b8cc-0242ac110004'}  (×3)
  06:46:08.667 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×2)
  06:46:08.668 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×2)
  06:46:08.668 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '15702f20-fbbf-11eb-b8cc-0242ac110004', 'user_id': 'tTkArhiW'}  (×4)
  06:46:09.447 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×2)
  06:46:09.448 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×2)
  06:46:10.914 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  06:46:10.915 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  06:46:11.850 [logservice1] ERROR uuid expired, invalid phone request
All services, 30 seconds either side (sampled):
  06:45:41.885 [redisservice2] INFO redis write success  (×76)
  06:45:42.030 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×39)
  06:45:42.205 [redisservice1] INFO service accept, status_code: 200  (×37)
  06:45:42.445 [redisservice1] INFO redis write success  (×73)
  06:45:42.690 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×34)
  06:45:42.853 [redisservice1] INFO redis读取信息成功, status_code: 200  (×40)
  06:45:43.461 [mobservice1] INFO info 0676f468-fbbf-11eb-8c29-0242ac110004:JvrVBhsk write success
  06:45:44.070 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  06:45:44.348 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×33)
  06:45:45.657 [dbservice2] INFO 0790e7fa-fbbf-11eb-b035-0242ac110003-hpcKRNdx-E5o4m%SA(zhR token generate success token=MTYyODgwODM0NS42NTcwODc4OjA3OTBlN2ZhLWZiYmYtMTFlYi1iMDM1LTAyNDJhYzE
  06:45:47.945 [mobservice1] INFO info 0919b2e6-fbbf-11eb-b9d7-0242ac110003:pGnBPZOX write success
  06:45:49.669 [mobservice1] INFO info 0a269a32-fbbf-11eb-8072-0242ac110004:jIBRSGcQ write success
  06:45:52.192 [mobservice1] INFO info 0babf80c-fbbf-11eb-9d1d-0242ac110003:rAmXuCJg write success
  06:45:55.007 [mobservice2] INFO info 0d541158-fbbf-11eb-b99d-0242ac110003:uLFWxbvM write success
  06:46:06.605 [redisservice1] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400
  06:46:08.551 [mobservice1] INFO info 15702f20-fbbf-11eb-b8cc-0242ac110004:tTkArhiW write success
  06:46:11.232 [dbservice2] INFO 16d3979e-fbbf-11eb-ab5a-0242ac110004-QPYaeVWt-4EbCnjLW>+T* token generate success token=MTYyODgwODM3MS4yMzIyODcyOjE2ZDM5NzllLWZiYmYtMTFlYi1hYjVhLTAyNDJhYzE
  06:46:13.752 [dbservice2] INFO 1853f38e-fbbf-11eb-9a0d-0242ac110004-pKxfZBio-*wUb}zXdlquF token generate success token=MTYyODgwODM3My43NTE2MDE6MTg1M2YzOGUtZmJiZi0xMWViLTlhMGQtMDI0MmFjMTE
  06:46:15.941 [mobservice2] INFO info 19d55720-fbbf-11eb-a1ab-0242ac110003:plhmCNjI write success
  06:46:18.077 [dbservice2] INFO 1ae0710e-fbbf-11eb-8ddb-0242ac110004-AwlIqmHD-pyw@uEvW-irk token generate success token=MTYyODgwODM3OC4wNzc1MzUyOjFhZTA3MTBlLWZiYmYtMTFlYi04ZGRiLTAyNDJhYzE
  06:46:20.500 [dbservice1] INFO 1c4980ee-fbbf-11eb-9424-0242ac110003-JXejhiMl-97R5_3u8cLX? token generate success token=MTYyODgwODM4MC40OTk4MzQzOjFjNDk4MGVlLWZiYmYtMTFlYi05NDI0LTAyNDJhYzE
  06:46:23.252 [dbservice2] INFO 1df4f7e8-fbbf-11eb-aed4-0242ac110004-lmvshOqT-%2#uLB3dNKSs token generate success token=MTYyODgwODM4My4yNTIwNTU2OjFkZjRmN2U4LWZiYmYtMTFlYi1hZWQ0LTAyNDJhYzE
  06:46:25.795 [dbservice1] INFO 1f797ec2-fbbf-11eb-85bf-0242ac110003-GRzjnWha-YXV0E=(>a1MP token generate success token=MTYyODgwODM4NS43OTUyMDU2OjFmNzk3ZWMyLWZiYmYtMTFlYi04NWJmLTAyNDJhYzE
  06:46:27.814 [mobservice1] INFO info 20ef0632-fbbf-11eb-80ac-0242ac110003:TrtKhHmF write success
  06:46:29.778 [dbservice1] INFO 21de6f92-fbbf-11eb-9806-0242ac110004-BNxliRze-sJxRb3Bzd#4c token generate success token=MTYyODgwODM4OS43Nzc5NjM2OjIxZGU2ZjkyLWZiYmYtMTFlYi05ODA2LTAyNDJhYzE
  06:46:32.269 [dbservice2] INFO 235474e8-fbbf-11eb-8229-0242ac110003-TEzNtqXJ-hX%YBAgR(yzj token generate success token=MTYyODgwODM5Mi4yNjkzMTM4OjIzNTQ3NGU4LWZiYmYtMTFlYi04MjI5LTAyNDJhYzE
  06:46:34.649 [dbservice1] INFO 24ce3af2-fbbf-11eb-a3d3-0242ac110003-VkjGfAwW-1:P5T_I!BiLK token generate success token=MTYyODgwODM5NC42NDg2NDI6MjRjZTNhZjItZmJiZi0xMWViLWEzZDMtMDI0MmFjMTE
  06:46:36.990 [dbservice1] INFO 262465b6-fbbf-11eb-99de-0242ac110003-ckfeNPTM-WcHR.sT#4DEu token generate success token=MTYyODgwODM5Ni45OTA1MTAyOjI2MjQ2NWI2LWZiYmYtMTFlYi05OWRlLTAyNDJhYzE
  06:46:39.020 [mobservice2] INFO info 27927ff0-fbbf-11eb-8aeb-0242ac110003:IlvgFiyE write success
  06:46:40.998 [dbservice2] INFO 2895b21e-fbbf-11eb-994a-0242ac110004-nNFECVbW-Ydhf$1eKym8X token generate success token=MTYyODgwODQwMC45OTgxNDM0OjI4OTViMjFlLWZiYmYtMTFlYi05OTRhLTAyNDJhYzE

## p0658
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-11T07:27:09.767Z
```
{"service":"dbservice2","message":"2021-08-11 07:27:09,767 | ERROR | 0.0.0.2 | 172.17.0.2 | dbservice2 | 8474a5f34706a290 | (pymysql.err.OperationalError) (1054, \"Unknown column 'system_data_time' in 'field list'\")[SQL: select service_name, system_data_time, system_cpu_utilization, system_memory_usage,system_disk_usage, disk_io_read_count, disk_io_write_count,system_network, network_io_read_count, network_io_write_count from `metri…"}
```
Same service, the 2 minutes before (oldest first):
  07:27:02.896 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×6)
  07:27:02.911 [dbservice2] INFO query = select passwards from username_table where user_name='TURfmxwe'  (×4)
  07:27:02.991 [dbservice2] INFO 77668992-fa32-11eb-9898-0242ac110004-TURfmxwe-30x($j9LcmY? token generate success token=MTYyODYzODAyMi45OTE0MjM6Nzc2Njg5OTItZmEzMi0xMWViLTk4OTgtMDI0MmFjMTE
  07:27:03.719 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  07:27:03.867 [dbservice2] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  07:27:05.421 [dbservice2] INFO 78d86d4a-fa32-11eb-b98e-0242ac110004-rhVoyqAc-:LnRb/Hg2fzY token generate success token=MTYyODYzODAyNS40MjEyODg1Ojc4ZDg2ZDRhLWZhMzItMTFlYi1iOThlLTAyNDJhYzE
  07:27:07.032 [dbservice2] INFO 79c637dc-fa32-11eb-9b36-0242ac110003-NSiQolUW-T3rg/Jh_qz#l token generate success token=MTYyODYzODAyNy4wMzE2ODU6NzljNjM3ZGMtZmEzMi0xMWViLTliMzYtMDI0MmFjMTE
  07:27:09.699 [dbservice2] INFO 7b51f32a-fa32-11eb-b8cd-0242ac110004-tTbvdojy-ck-aO0rUmB.1 token generate success token=MTYyODYzODAyOS42OTkzMTk2OjdiNTFmMzJhLWZhMzItMTFlYi1iOGNkLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  07:26:39.797 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '69cd2bce-fa32-11eb-a500-0242ac110003', 'value': 'sSHyNrVB'}  (×48)
  07:26:39.981 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×42)
  07:26:40.020 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×33)
  07:26:40.317 [redisservice1] INFO redis write success  (×79)
  07:26:40.514 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '6a3d2168-fa32-11eb-ae70-0242ac110003'}  (×47)
  07:26:40.740 [mobservice1] INFO info 6a52e9c6-fa32-11eb-97a9-0242ac110003:NZDQOdvq write success  (×2)
  07:26:40.954 [dbservice1] INFO query = select passwards from username_table where user_name='NZDQOdvq'  (×46)
  07:26:41.209 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '6acc8bd2-fa32-11eb-b306-0242ac110004', 'value': '', 'ex': 10}  (×42)
  07:26:41.825 [dbservice2] INFO 6acc8bd2-fa32-11eb-b306-0242ac110004-PKIhxRvi-08cv}aACK*n4 token generate success token=MTYyODYzODAwMS44MjUzMzY3OjZhY2M4YmQyLWZhMzItMTFlYi1iMzA2LTAyNDJhYzE
  07:26:43.380 [dbservice1] INFO 6bac6090-fa32-11eb-b69b-0242ac110003-vyNKmojf-tObRnCdzeI&j token generate success token=MTYyODYzODAwMy4zODAwNzYyOjZiYWM2MDkwLWZhMzItMTFlYi1iNjliLTAyNDJhYzE
  07:26:45.017 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat  (×2)
  07:26:46.996 [dbservice1] INFO 6db9065e-fa32-11eb-9978-0242ac110003-lmvshOqT-%2#uLB3dNKSs token generate success token=MTYyODYzODAwNi45OTU2MzU1OjZkYjkwNjVlLWZhMzItMTFlYi05OTc4LTAyNDJhYzE
  07:26:49.321 [dbservice2] INFO 6f3fdb42-fa32-11eb-9d6e-0242ac110004-vUGVxSct-oE/Qs.WM!UC< token generate success token=MTYyODYzODAwOS4zMjE0MDYxOjZmM2ZkYjQyLWZhMzItMTFlYi05ZDZlLTAyNDJhYzE
  07:26:51.885 [dbservice1] INFO 70cc795c-fa32-11eb-b871-0242ac110004-jFTtOqPD-V5xAt:Q*{qep token generate success token=MTYyODYzODAxMS44ODQ5ODc2OjcwY2M3OTVjLWZhMzItMTFlYi1iODcxLTAyNDJhYzE
  07:26:53.825 [mobservice2] INFO info 72275b32-fa32-11eb-a240-0242ac110003:ITDnZiPv write success
  07:26:56.496 [mobservice1] INFO info 73ad6154-fa32-11eb-9c51-0242ac110004:tcvLYMig write success
  07:26:58.623 [dbservice1] INFO 74bb9fd4-fa32-11eb-a301-0242ac110003-DqvNnYcw-eUr7.Ox_/5Yd token generate success token=MTYyODYzODAxOC42MjI5NzQ6NzRiYjlmZDQtZmEzMi0xMWViLWEzMDEtMDI0MmFjMTE
  07:27:01.181 [dbservice2] INFO 76453b8a-fa32-11eb-bcc8-0242ac110004-AfSqKhsi->emTu&{%^-K? token generate success token=MTYyODYzODAyMS4xODA1MTIyOjc2NDUzYjhhLWZhMzItMTFlYi1iY2M4LTAyNDJhYzE
  07:27:03.623 [mobservice2] INFO info 77fcc150-fa32-11eb-934e-0242ac110004:YWGLHvVN write success
  07:27:05.852 [mobservice2] INFO info 794d96ec-fa32-11eb-aca1-0242ac110003:cforzalb write success
  07:27:08.419 [mobservice1] INFO info 7acfa906-fa32-11eb-8af1-0242ac110003:BkNFnfui write success
  07:27:11.022 [mobservice1] INFO info 7c5409c0-fa32-11eb-ac76-0242ac110003:rNfgkPxE write success
  07:27:12.971 [dbservice1] INFO 7d5823d8-fa32-11eb-bfdc-0242ac110004-kHIDhMnd-h+i/nz=N}69% token generate success token=MTYyODYzODAzMi45NzEzODcxOjdkNTgyM2Q4LWZhMzItMTFlYi1iZmRjLTAyNDJhYzE
  07:27:15.594 [dbservice1] INFO 7ecf939a-fa32-11eb-bfea-0242ac110004-QoXmzFit-OWK_0QrnFE_{ token generate success token=MTYyODYzODAzNS41OTM4MTg6N2VjZjkzOWEtZmEzMi0xMWViLWJmZWEtMDI0MmFjMTE
  07:27:24.211 [dbservice1] INFO 84053b8a-fa32-11eb-aabe-0242ac110004-gstLzvnZ-lhfi/n1P7ZQ: token generate success token=MTYyODYzODA0NC4yMTE1OTM2Ojg0MDUzYjhhLWZhMzItMTFlYi1hYWJlLTAyNDJhYzE
  07:27:27.983 [dbservice1] INFO 864a8f80-fa32-11eb-bf0a-0242ac110004-wzQhcEjW-&q(Z_ECc)a<V token generate success token=MTYyODYzODA0Ny45ODI3NjM6ODY0YThmODAtZmEzMi0xMWViLWJmMGEtMDI0MmFjMTE
  07:27:30.547 [dbservice1] INFO 87d06aaa-fa32-11eb-8fa3-0242ac110003-GiuNzrvJ-YnTciU0WR&3p token generate success token=MTYyODYzODA1MC41NDc1NzMzOjg3ZDA2YWFhLWZhMzItMTFlYi04ZmEzLTAyNDJhYzE
  07:27:32.762 [dbservice1] INFO 8919f7c8-fa32-11eb-8bdb-0242ac110003-UoOtrWnu-l>x7frKnk89y token generate success token=MTYyODYzODA1Mi43NjE4NDQ2Ojg5MTlmN2M4LWZhMzItMTFlYi04YmRiLTAyNDJhYzE
  07:27:35.363 [dbservice2] INFO 8ab700d0-fa32-11eb-8d05-0242ac110004-OVhMJowB-tS9TykY$s?)x token generate success token=MTYyODYzODA1NS4zNjMzNTU2OjhhYjcwMGQwLWZhMzItMTFlYi04ZDA1LTAyNDJhYzE
  07:27:38.040 [mobservice2] INFO info 8c7ef2e2-fa32-11eb-ae00-0242ac110004:GEFNbRmp write success

## p0183
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T06:43:15.183Z
```
{"timestamp":1731912195183601700,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-svrwm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=0ae6d9b6-4e7f-4d38-a0eb-042389dcac30"}
```
Same service, the 2 minutes before (oldest first):
  06:43:11.478 [cartservice] GetCartAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0  (×16)
  06:43:13.797 [cartservice] AddItemAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927, productId=0PUK6V6EV0, quantity=9  (×3)
  06:43:13.884 [cartservice] EmptyCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927
All services, 30 seconds either side (sampled):
  06:42:45.598 [frontend] request started  (×344)
  06:42:45.606 [cartservice] GetCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×274)
  06:42:45.629 [adservice] received ad request (context_words=[kitchen])  (×46)
  06:42:45.637 [cartservice] AddItemAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53, productId=6E92ZMYYFZ, quantity=9  (×43)
  06:42:45.664 [shippingservice] [GetQuote] received request  (×90)
  06:42:45.707 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="EUR"
  06:42:45.754 [checkoutservice] payment went through (transaction_id: 22233adf-30d8-4479-b775-9aecd942f079)  (×15)
  06:42:45.759 [cartservice] EmptyCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×15)
  06:42:45.766 [frontend] order placed  (×15)
  06:42:47.161 [adservice] received ad request (context_words=[decor, home])  (×22)
  06:42:47.189 [paymentservice] Transaction processed: visa ending 3461 Amount: JPY21120.707651923  (×4)
  06:42:47.556 [frontend] setting currency  (×26)
  06:42:47.609 [adservice] received ad request (context_words=[])  (×31)
  06:42:50.514 [adservice] received ad request (context_words=[clothing, tops])  (×21)
  06:42:55.308 [paymentservice] Transaction processed: visa ending 0123 Amount: GBP75.201886771  (×4)
  06:42:58.600 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"47","nanos":420000000},"credit_card":{"credit_card_number":"477400432250076  (×2)
  06:43:03.279 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', 'LS4PSXUNUM', 'L9ECAV7KIM', '1YMWWN1N4O']  (×3)
  06:43:04.988 [paymentservice] Transaction processed: visa ending 7006 Amount: TRY1808.750413089  (×4)
  06:43:15.278 [checkoutservice] failed to send order confirmation to "katie93@example.com": rpc error: code = Unavailable desc = no healthy upstream
  06:43:24.493 [checkoutservice] failed to send order confirmation to "snorman@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:43:41.166 [checkoutservice] failed to send order confirmation to "allensteele@example.net": rpc error: code = Unavailable desc = no healthy upstream

## p0755
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T06:27:35.173Z
```
{"timestamp":1732256855173162000,"container_name":"front-end","pod_name":"front-end-f77549869-mxq2p","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /orders 201 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  06:27:35.040 [front-end] POST /addresses 200 - ms - -
  06:27:35.048 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"6740244d768f35000114ec6e"}
  06:27:35.059 [front-end] POST /cards 200 - ms - -
  06:27:35.106 [front-end] Attempting to delete cart for user: 6740244d768f35000114ec6e
  06:27:35.118 [front-end] User cart deleted with status: 202
  06:27:35.120 [front-end] DELETE /cart 202 - ms - -
  06:27:35.122 [front-end] Request received with body: {}
  06:27:35.126 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  06:27:35.133 [front-end] Received response: "{\"firstName\":\"obZOcbRF\",\"lastName\":\"obZOcbRF\",\"username\":\"obZOcbRF\",\"id\":\"67402443768f35000114ec49\",\"_links\":{\"addresses\
  06:27:35.133 [front-end] GET Request to: http://user/customers/67402443768f35000114ec49/addresses  (×2)
  06:27:35.133 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  06:27:35.133 [front-end] POST to carts: http://carts/carts/6740244d768f35000114ec6e/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  06:27:35.145 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67402
  06:27:35.145 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6740244d768f35000114ec6d\",\"_links\":{\"
  06:27:35.145 [front-end] [ undefined, undefined ]
  06:27:35.145 [front-end] Posting Order: {"customer":"http://user/customers/67402443768f35000114ec49","address":"http://user/addresses/6740244d768f35000114ec6c","card":"http://user/cards
  06:27:35.159 [front-end] POST /cart 201 - ms - -
  06:27:35.170 [front-end] Order response: {"statusCode":201,"body":{"id":"67402457531af4000701ddd7","customerId":"67402443768f35000114ec49","customer":{"id":null,"firstName":"obZOcbRF","
  06:27:35.170 [front-end] Order response: {"id":"67402457531af4000701ddd7","customerId":"67402443768f35000114ec49","customer":{"id":null,"firstName":"obZOcbRF","lastName":"obZOcbRF","use
All services, 30 seconds either side (sampled):
  06:27:05.181 [front-end] Carts merged.  (×63)
  06:27:05.543 [user] ts=2024-11-22T06:27:05.54357586Z caller=middlewares.go:75 method=GetUsers id=6740242b768f35000114ebfa result=1 took=1.962319ms  (×256)
  06:27:05.589 [orders] 2024-11-22 06:27:05.589 INFO [orders,b9c624ac159044ff,8e4979fb6c72192d,false] 7 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Received payment re  (×57)
  06:27:05.952 [front-end] Received response: "{\"firstName\":\"fGIaiiYfyOu\",\"lastName\":\"fGIaiiYfyOu\",\"username\":\"fGIaiiYfyOu\",\"id\":\"67402422768f35000114ebd8\",\"_links\":{\"a
  06:27:06.874 [front-end] POST /addresses 200 - ms - -  (×57)
  06:27:07.042 [carts] 2024-11-22 06:27:07.042 INFO [carts,5bad915f703744ff,505fee2eaa890004,false] 7 --- [-nio-80-exec-21] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×32)
  06:27:08.430 [front-end] POST to carts: http://carts/carts/67402434768f35000114ec1d/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×25)
  06:27:09.025 [catalogue] ts=2024-11-22T06:27:09Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.14728m  (×7)
  06:27:09.885 [front-end] Received response: "{\"firstName\":\"wwiOMTsrmXiN\",\"lastName\":\"wwiOMTsrmXiN\",\"username\":\"wwiOMTsrmXiN\",\"id\":\"6740242d768f35000114ec02\",\"_links\":{
  06:27:12.446 [front-end] Order response: {"statusCode":201,"body":{"id":"67402440531af4000701ddc2","customerId":"67402428768f35000114ebee","customer":{"id":null,"firstName":"ExHitAsxvdb
  06:27:14.625 [front-end] Received response: "{\"firstName\":\"ifYNNbWZtTUTwf\",\"lastName\":\"ifYNNbWZtTUTwf\",\"username\":\"ifYNNbWZtTUTwf\",\"id\":\"67402430768f35000114ec0f\",\"_lin
  06:27:15.747 [user] ts=2024-11-22T06:27:15.747148904Z caller=middlewares.go:46 method=Register username=obZOcbRF email=obZOcbRF@gmail.com took=2.082666ms
  06:27:16.151 [user] ts=2024-11-22T06:27:16.15126683Z caller=middlewares.go:46 method=Register username=amYeHFhs email=amYeHFhs@gmail.com took=2.991977ms
  06:27:18.557 [front-end] Order response: {"id":"67402446531af4000701ddcc","customerId":"6740242e768f35000114ec03","customer":{"id":null,"firstName":"jJhjllunIDRN","lastName":"jJhjllunID
  06:27:25.157 [front-end] Received response: "{\"firstName\":\"PRpvE\",\"lastName\":\"PRpvE\",\"username\":\"PRpvE\",\"id\":\"67402434768f35000114ec22\",\"_links\":{\"addresses\":{\"href
  06:27:29.768 [front-end] Order response: {"statusCode":201,"body":{"id":"67402451531af4000701ddd1","customerId":"67402444768f35000114ec4f","customer":{"id":null,"firstName":"jKleghvmoFz
  06:27:32.273 [front-end] Posting Customer: {"username":"bOtQp","password":"nFWWhI","email":"bOtQp@gmail.com","firstName":"bOtQp","lastName":"bOtQp"}
  06:27:33.852 [front-end] Received response: "{\"firstName\":\"EPYklPsIWElFrjF\",\"lastName\":\"EPYklPsIWElFrjF\",\"username\":\"EPYklPsIWElFrjF\",\"id\":\"67402446768f35000114ec54\",\"_
  06:27:35.926 [front-end] Received response: "{\"firstName\":\"GhNHkUGPBGvkM\",\"lastName\":\"GhNHkUGPBGvkM\",\"username\":\"GhNHkUGPBGvkM\",\"id\":\"67402448768f35000114ec5b\",\"_links\
  06:27:37.441 [front-end] Order response: {"statusCode":201,"body":{"id":"67402459531af4000701dddc","customerId":"6740243d768f35000114ec3e","customer":{"id":null,"firstName":"HREdSBp","l
  06:27:41.665 [front-end] Posting Customer: {"username":"jiCbA","password":"pUYQTiKEJF","email":"jiCbA@gmail.com","firstName":"jiCbA","lastName":"jiCbA"}
  06:27:45.787 [user] ts=2024-11-22T06:27:45.787226557Z caller=middlewares.go:46 method=Register username=LIPckEiAt email=LIPckEiAt@gmail.com took=2.643178ms
  06:27:50.435 [front-end] Posting Customer: {"username":"MmXveGUe","password":"RQFiaB","email":"MmXveGUe@gmail.com","firstName":"MmXveGUe","lastName":"MmXveGUe"}
  06:27:51.743 [front-end] Posting Customer: {"username":"FnrPlapJDRPX","password":"RTshqnnXjz","email":"FnrPlapJDRPX@gmail.com","firstName":"FnrPlapJDRPX","lastName":"FnrPlapJDRPX"}
  06:27:53.218 [front-end] Posting Customer: {"username":"vfwbmjtNhyn","password":"odaBZZon","email":"vfwbmjtNhyn@gmail.com","firstName":"vfwbmjtNhyn","lastName":"vfwbmjtNhyn"}
  06:27:55.933 [front-end] Posting Customer: {"username":"xiIIKDMfpR","password":"OVJSoLwtEN","email":"xiIIKDMfpR@gmail.com","firstName":"xiIIKDMfpR","lastName":"xiIIKDMfpR"}
  06:27:57.337 [front-end] Received response: "{\"firstName\":\"NyFQptoPAqDHX\",\"lastName\":\"NyFQptoPAqDHX\",\"username\":\"NyFQptoPAqDHX\",\"id\":\"67402461768f35000114ec9f\",\"_links\
  06:27:59.106 [front-end] Posting Customer: {"username":"HdKgY","password":"nUWTU","email":"HdKgY@gmail.com","firstName":"HdKgY","lastName":"HdKgY"}
  06:28:03.600 [front-end] Posting Customer: {"username":"keibPntWYDlZ","password":"AuJaU","email":"keibPntWYDlZ@gmail.com","firstName":"keibPntWYDlZ","lastName":"keibPntWYDlZ"}

## p0016
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-13T06:32:49.406Z
```
{"service":"webservice2","message":"2021-08-13 06:32:49,406 | INFO | 0.0.0.3 | 172.17.0.4 | webservice2 | 185eebd0cd7b9f5b | call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  06:32:46.466 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  06:32:46.467 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  06:32:46.467 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '3791a2de-fbbd-11eb-ad18-0242ac110004', 'value': '', 'ex': 10}  (×3)
  06:32:46.544 [webservice2] INFO uuid: 3791a2de-fbbd-11eb-ad18-0242ac110004 write redis successfully  (×3)
  06:32:46.650 [webservice2] INFO complete information: {'uuid': '3791a2de-fbbd-11eb-ad18-0242ac110004', 'user_id': 'pyWndFNv'}  (×3)
  06:32:46.659 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×3)
  06:32:46.659 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×2)
All services, 30 seconds either side (sampled):
  06:32:19.468 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '2747e960-fbbd-11eb-8510-0242ac110003', 'value': 'DBUWXtFp'}  (×36)
  06:32:19.721 [redisservice2] INFO redis读取信息成功, status_code: 200  (×42)
  06:32:19.859 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  06:32:20.063 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '27d4a4a4-fbbd-11eb-b615-0242ac110004', 'value': '', 'ex': 10}  (×41)
  06:32:20.229 [webservice2] INFO complete information: {'uuid': '27d4a4a4-fbbd-11eb-b615-0242ac110004', 'user_id': 'OkyWpDvC'}  (×41)
  06:32:20.321 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×46)
  06:32:20.439 [mobservice2] INFO info 27d4a4a4-fbbd-11eb-b615-0242ac110004:OkyWpDvC write success
  06:32:20.560 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×42)
  06:32:20.855 [dbservice1] INFO query = select passwards from username_table where user_name='sjignBZH'  (×37)
  06:32:23.294 [mobservice2] INFO info 29865a72-fbbd-11eb-b803-0242ac110003:sSHyNrVB write success
  06:32:26.137 [mobservice2] INFO info 2b3664c0-fbbd-11eb-83ca-0242ac110003:KrCJbket write success
  06:32:33.227 [dbservice2] INFO 2f39ed6c-fbbd-11eb-a8b6-0242ac110003-BLOHhDzM-{i4jP}N/rmt9 token generate success token=MTYyODgwNzU1My4yMjY4NDM6MmYzOWVkNmMtZmJiZC0xMWViLWE4YjYtMDI0MmFjMTE
  06:32:35.347 [mobservice2] INFO info 30b9e7dc-fbbd-11eb-8542-0242ac110004:qfINGhoa write success
  06:32:38.084 [mobservice2] INFO info 324940e8-fbbd-11eb-9d8e-0242ac110003:QPshVMni write success  (×2)
  06:32:40.652 [mobservice1] INFO info 33e46504-fbbd-11eb-a877-0242ac110004:GBzXyJft write success
  06:32:43.227 [mobservice2] INFO info 3566250c-fbbd-11eb-a241-0242ac110004:GTqJKEWv write success
  06:32:45.445 [dbservice2] INFO 36819b9c-fbbd-11eb-8d39-0242ac110003-IZrFSezD-{*jxBT_%zkSX token generate success token=MTYyODgwNzU2NS40NDU1MDk6MzY4MTliOWMtZmJiZC0xMWViLThkMzktMDI0MmFjMTE
  06:32:47.775 [mobservice1] INFO info 381e314a-fbbd-11eb-a49d-0242ac110003:THZxeBPz write success
  06:32:50.121 [dbservice2] INFO 393097d0-fbbd-11eb-bed4-0242ac110004-HCzNJuWb-bP$YVW7=McS1 token generate success token=MTYyODgwNzU3MC4xMjEwMDE1OjM5MzA5N2QwLWZiYmQtMTFlYi1iZWQ0LTAyNDJhYzE
  06:32:52.959 [dbservice2] INFO 3aeaa0f2-fbbd-11eb-9d2f-0242ac110003-wyIESLrY-DI>_{NHq!6=: token generate success token=MTYyODgwNzU3Mi45NTg5NzI6M2FlYWEwZjItZmJiZC0xMWViLTlkMmYtMDI0MmFjMTE
  06:32:55.912 [mobservice1] INFO info 3cfa7138-fbbd-11eb-867f-0242ac110004:zHhwQRUN write success
  06:32:58.755 [dbservice1] INFO 3e6a0646-fbbd-11eb-a533-0242ac110004-ydDVPRrH-K>1}?T{_&NHS token generate success token=MTYyODgwNzU3OC43NTQ2MDAzOjNlNmEwNjQ2LWZiYmQtMTFlYi1hNTMzLTAyNDJhYzE
  06:33:01.344 [mobservice2] INFO info 402d6f68-fbbd-11eb-9eca-0242ac110003:BkNFnfui write success
  06:33:03.786 [mobservice2] INFO info 41a88e9a-fbbd-11eb-bd35-0242ac110004:lkNrGYTL write success
  06:33:05.838 [dbservice2] INFO 42a9b1d4-fbbd-11eb-87c7-0242ac110004-VxubFBRX-Qgr73J_$>S}{ token generate success token=MTYyODgwNzU4NS44Mzc1MzM3OjQyYTliMWQ0LWZiYmQtMTFlYi04N2M3LTAyNDJhYzE
  06:33:08.001 [mobservice2] INFO info 442e9aec-fbbd-11eb-af6d-0242ac110003:lGPfCvhn write success
  06:33:10.255 [dbservice2] INFO 454a8576-fbbd-11eb-ae65-0242ac110003-fiNWCoaq-R92=3TN.}J8v token generate success token=MTYyODgwNzU5MC4yNTQ5MDM4OjQ1NGE4NTc2LWZiYmQtMTFlYi1hZTY1LTAyNDJhYzE
  06:33:12.676 [mobservice1] INFO info 46fead20-fbbd-11eb-b266-0242ac110004:WvYxbhDu write success
  06:33:15.119 [dbservice1] INFO 482a8caa-fbbd-11eb-bd4c-0242ac110003-PuHhfCZO-GImoA>p7EnU6 token generate success token=MTYyODgwNzU5NS4xMTg3MDQzOjQ4MmE4Y2FhLWZiYmQtMTFlYi1iZDRjLTAyNDJhYzE
  06:33:17.224 [mobservice1] INFO info 49b25ec2-fbbd-11eb-99cd-0242ac110003:bykmrCDS write success

## p0822
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-08T12:09:37.777Z
```
{"timestamp":1733659777777645300,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-hq66v","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-08 12:09:37.777  INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl             : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Response(status=1, msg=Success query Train by trip id, data=TrainType(id=ZhiDa, economyClass=2147483647, confortClass=2147483647, averageSpeed=120))"}
```
Same service, the 2 minutes before (oldest first):
  12:09:37.570 [ts-seat-service] 2024-12-08 12:09:37.569 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  12:09:37.576 [ts-seat-service] 2024-12-08 12:09:37.576 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  12:09:37.593 [ts-seat-service] 2024-12-08 12:09:37.592 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×3)
  12:09:37.593 [ts-seat-service] 2024-12-08 12:09:37.592 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×2)
  12:09:37.614 [ts-seat-service] 2024-12-08 12:09:37.613 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×2)
  12:09:37.625 [ts-seat-service] 2024-12-08 12:09:37.625 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  12:09:37.638 [ts-seat-service] 2024-12-08 12:09:37.638 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×2)
  12:09:37.676 [ts-seat-service] 2024-12-08 12:09:37.676 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1237
  12:09:37.690 [ts-seat-service] 2024-12-08 12:09:37.690 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes
  12:09:37.701 [ts-seat-service] 2024-12-08 12:09:37.700 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da
  12:09:37.717 [ts-seat-service] 2024-12-08 12:09:37.717 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
All services, 30 seconds either side (sampled):
  12:09:07.880 [ts-auth-service] 2024-12-08 12:09:07.880 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×15)
  12:09:08.153 [ts-travel-service] 2024-12-08 12:09:08.153 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×19)
  12:09:08.245 [ts-auth-service] 2024-12-08 12:09:08.245 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×7)
  12:09:08.505 [ts-basic-service] 2024-12-08 12:09:08.505 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×2)
  12:09:08.529 [ts-travel2-service] 2024-12-08 12:09:08.529 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×6)
  12:09:08.591 [ts-travel2-service] 2024-12-08 12:09:08.591 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  12:09:08.715 [ts-seat-service] 2024-12-08 12:09:08.715 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×13)
  12:09:09.600 [ts-basic-service] 2024-12-08 12:09:09.600 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×14)
  12:09:09.784 [ts-seat-service] 2024-12-08 12:09:09.784 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  12:09:11.808 [ts-user-mongo] {"t":{"$date":"2024-12-08T12:09:11.808+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365975
  12:09:12.761 [ts-food-service] 2024-12-08 12:09:12.761 INFO 1 --- [io-18856-exec-3] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×2)
  12:09:13.690 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-08T12:09:13.690+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365975
  12:09:14.417 [ts-travel2-service] 2024-12-08 12:09:14.417 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0
  12:09:16.588 [ts-basic-service] 2024-12-08 12:09:16.587 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×3)
  12:09:16.677 [ts-travel-service] 2024-12-08 12:09:16.677 INFO 1 --- [io-12346-exec-2] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234  (×10)
  12:09:16.785 [ts-order-service] 2024-12-08 12:09:16.785 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024
  12:09:17.343 [ts-seat-service] 2024-12-08 12:09:17.342 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  12:09:33.590 [ts-order-service] 2024-12-08 12:09:33.589 INFO 1 --- [io-12031-exec-6] order.service.OrderServiceImpl : [Order Service][Query Order][Step 1] Get Orders Number of Account: 132
  12:09:37.177 [ts-basic-service] 2024-12-08 12:09:37.177 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO
  12:09:40.275 [ts-travel-service] 2024-12-08 12:09:40.275 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Travel Service] Query TripResponse
  12:09:40.372 [ts-basic-service] 2024-12-08 12:09:40.372 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×3)
  12:09:40.629 [ts-travel-service] 2024-12-08 12:09:40.629 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×2)
  12:09:40.682 [ts-security-service] 2024-12-08 12:09:40.681 INFO 1 --- [io-11188-exec-1] security.controller.SecurityController : [Security Service][Check Security] Check Account Id: 4d2a46c7-71cb
  12:09:40.721 [ts-preserve-service] 2024-12-08 12:09:40.721 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security Complete
  12:09:40.734 [ts-preserve-service] 2024-12-08 12:09:40.734 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting...
  12:09:41.153 [ts-seat-service] 2024-12-08 12:09:41.152 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService distributeSeat] The result of getRouteResult is Success
  12:09:41.205 [ts-order-service] 2024-12-08 12:09:41.204 INFO 1 --- [io-12031-exec-8] order.service.OrderServiceImpl : [Order Service][Order Create] Success.
  12:09:49.505 [ts-basic-service] 2024-12-08 12:09:49.505 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693

## p0694
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-12T11:17:59.502Z
```
{"service":"webservice2","message":"2021-08-12 11:17:59,502 | INFO | 0.0.0.3 | 172.17.0.4 | webservice2 | 79bc382e320bdd73 | call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  11:17:57.663 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  11:17:57.663 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  11:17:57.663 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'e43976d0-fb1b-11eb-89bb-0242ac110004', 'value': '', 'ex': 10}  (×3)
  11:17:57.741 [webservice2] INFO uuid: e43976d0-fb1b-11eb-89bb-0242ac110004 write redis successfully  (×3)
  11:17:57.845 [webservice2] INFO complete information: {'uuid': 'e43976d0-fb1b-11eb-89bb-0242ac110004', 'user_id': 'SbjCGNIe'}  (×3)
  11:17:57.853 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×3)
  11:17:57.853 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×2)
All services, 30 seconds either side (sampled):
  11:17:29.657 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  11:17:29.897 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×40)
  11:17:30.027 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×53)
  11:17:30.151 [logservice2] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': 'd387f852-fb1b-11eb-a4cd-0242ac110004', 'user_id': 'JXejhiMl'}  (×89)
  11:17:30.832 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'd43af9ca-fb1b-11eb-aa90-0242ac110003', 'value': '', 'ex': 10}  (×45)
  11:17:31.143 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'd43af9ca-fb1b-11eb-aa90-0242ac110003', 'value': 'irpbvSZq'}  (×50)
  11:17:32.471 [dbservice1] INFO d4cca32a-fb1b-11eb-a507-0242ac110004-rVQYJsxi-OWzny%LI4&07 token generate success token=MTYyODczODI1Mi40NzEzOTUzOmQ0Y2NhMzJhLWZiMWItMTFlYi1hNTA3LTAyNDJhYzE
  11:17:32.794 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×36)
  11:17:34.823 [webservice1] ERROR an error occurred in the downstream service  (×6)
  11:17:37.002 [mobservice1] INFO info d7afde22-fb1b-11eb-84b0-0242ac110004:JuoeTjfH write success
  11:17:39.202 [mobservice2] INFO info d9068848-fb1b-11eb-8b48-0242ac110004:WstfjpFZ write success
  11:17:42.046 [mobservice2] INFO info dab446d0-fb1b-11eb-bec6-0242ac110003:yGkKOuIc write success
  11:17:44.594 [mobservice1] INFO info dc3a62b4-fb1b-11eb-90a4-0242ac110004:TrtKhHmF write success
  11:17:47.736 [mobservice2] INFO info de16e198-fb1b-11eb-a7d3-0242ac110004:AMFryZUz write success
  11:17:50.475 [mobservice2] INFO info dfb99fae-fb1b-11eb-b2fa-0242ac110004:lebfEIwL write success
  11:17:53.369 [mobservice1] INFO info e169cd1a-fb1b-11eb-acd2-0242ac110004:FGqxBRpZ write success
  11:17:56.189 [mobservice1] INFO info e319a518-fb1b-11eb-b8a1-0242ac110003:elIAhJnr write success
  11:17:58.854 [mobservice2] INFO info e4b9ce02-fb1b-11eb-8e5d-0242ac110003:HwOItPMW write success
  11:18:01.356 [mobservice2] INFO info e636467a-fb1b-11eb-b552-0242ac110004:iZWtCSMp write success
  11:18:04.271 [dbservice1] INFO e7a98c60-fb1b-11eb-a703-0242ac110004-kXfZVAUx-ugJfZ)m&(3jT token generate success token=MTYyODczODI4NC4yNzA4NzY6ZTdhOThjNjAtZmIxYi0xMWViLWE3MDMtMDI0MmFjMTE
  11:18:07.168 [dbservice2] INFO e96df1bc-fb1b-11eb-b032-0242ac110004-rxiVPwZL-#kN4x}e6EY-J token generate success token=MTYyODczODI4Ny4xNjgzMzc4OmU5NmRmMWJjLWZiMWItMTFlYi1iMDMyLTAyNDJhYzE
  11:18:09.689 [mobservice2] INFO info eb1bbf80-fb1b-11eb-b47d-0242ac110004:DBUWXtFp write success
  11:18:12.588 [mobservice1] INFO info ece245d2-fb1b-11eb-ba7a-0242ac110003:NxPGARft write success
  11:18:15.483 [mobservice1] INFO info ee9d5326-fb1b-11eb-9fca-0242ac110004:rObgBwap write success
  11:18:18.691 [dbservice2] INFO f045804a-fb1b-11eb-bc87-0242ac110004-OURXjiIJ-5Jn{CRus!OS: token generate success token=MTYyODczODI5OC42OTA1NTI6ZjA0NTgwNGEtZmIxYi0xMWViLWJjODctMDI0MmFjMTE
  11:18:21.298 [mobservice1] INFO info f20df3f8-fb1b-11eb-bdad-0242ac110004:yKfSAmta write success
  11:18:24.406 [mobservice1] INFO info f3ec8a5e-fb1b-11eb-939d-0242ac110004:fwiKVRsI write success
  11:18:27.528 [mobservice2] INFO info f5cdc4f0-fb1b-11eb-a6a4-0242ac110003:GZqDYHLc write success

## p0472
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T08:14:12.632Z
```
{"timestamp":1732349652632061000,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:14:12.631  INFO [carts,788deabc1f8a5ae5,ca29e4c92e5dbfac,false] 7 --- [-nio-80-exec-20] w.w.s.cart.controllers.ItemsController   : Did not find item. Creating item for user: 67418ecba437380001def21e, Item{id='67418ed4f074bf0007ffd513', itemId='d3588630-ad8e-49df-bbd7-3167f7efb246', quantity=1, unitPrice=10.99}"}
```
Same service, the 2 minutes before (oldest first):
  08:14:02.726 [carts] 2024-11-23 08:14:02.726 INFO [carts,9e9b4f0cad82401a,20de5292777b5e6f,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.cart.CartContentsResource : Adding for user: Car
  08:14:03.481 [carts] 2024-11-23 08:14:03.481 INFO [carts,a0f796814ca7c54c,764fdf4f238714ef,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.CartsController : Merge carts reques  (×6)
  08:14:04.268 [carts] 2024-11-23 08:14:04.268 INFO [carts,f771de3d37550504,a6c7cfcd22aebd6e,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.CartsController : Merge carts reques  (×5)
  08:14:07.198 [carts] 2024-11-23 08:14:07.198 INFO [carts,6e7a662dd2f2411e,56d6f593f1cb99f2,false] 7 --- [-nio-80-exec-10] w.w.s.cart.controllers.ItemsController : Did not find item.  (×4)
  08:14:07.204 [carts] 2024-11-23 08:14:07.204 INFO [carts,6e7a662dd2f2411e,56d6f593f1cb99f2,false] 7 --- [-nio-80-exec-10] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)
All services, 30 seconds either side (sampled):
  08:13:42.693 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418eb0a437380001def1d8"}  (×58)
  08:13:42.812 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×10)
  08:13:43.398 [front-end] set cookie67418eb7a437380001def1eb  (×59)
  08:13:43.617 [front-end] Posting Order: {"customer":"http://user/customers/67418ea5a437380001def1ac","address":"http://user/addresses/67418eaaa437380001def1bf","card":"http://user/cards  (×60)
  08:13:43.645 [front-end] Order response: {"statusCode":201,"body":{"id":"67418eb73f77060008864fbe","customerId":"67418ea5a437380001def1ac","customer":{"id":null,"firstName":"gozJp","las
  08:13:44.901 [front-end] POST to carts: http://carts/carts/67418eaea437380001def1ce/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}  (×28)
  08:13:46.182 [front-end] Received response: "{\"firstName\":\"qpFAQgZfeXNp\",\"lastName\":\"qpFAQgZfeXNp\",\"username\":\"qpFAQgZfeXNp\",\"id\":\"67418e9ea437380001def199\",\"_links\":{
  08:13:46.659 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×5)
  08:13:48.577 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×4)
  08:13:50.906 [front-end] Received response: "{\"firstName\":\"cHcqNDvhuh\",\"lastName\":\"cHcqNDvhuh\",\"username\":\"cHcqNDvhuh\",\"id\":\"67418eaaa437380001def1c1\",\"_links\":{\"addr
  08:13:52.508 [front-end] Order response: {"statusCode":201,"body":{"id":"67418ec03f77060008864fcc","customerId":"67418eada437380001def1c8","customer":{"id":null,"firstName":"sKneNBel","
  08:13:54.985 [front-end] Order response: {"id":"67418ec23f77060008864fcf","customerId":"67418eb0a437380001def1d8","customer":{"id":null,"firstName":"tqPzhLLdw","lastName":"tqPzhLLdw","u
  08:13:56.002 [front-end] Order response: {"id":"67418ec33f77060008864fd2","customerId":"67418eaea437380001def1ce","customer":{"id":null,"firstName":"iQQdgVufUKe","lastName":"iQQdgVufUKe
  08:13:58.226 [front-end] Order response: {"statusCode":201,"body":{"id":"67418ec63f77060008864fd4","customerId":"67418eb3a437380001def1e0","customer":{"id":null,"firstName":"MDjbt","las
  08:14:03.474 [front-end] Posting Customer: {"username":"snBtDqtFF","password":"PIeXVm","email":"snBtDqtFF@gmail.com","firstName":"snBtDqtFF","lastName":"snBtDqtFF"}
  08:14:06.548 [user] ts=2024-11-23T08:14:06.548347122Z caller=middlewares.go:46 method=Register username=toBtooZXd email=toBtooZXd@gmail.com took=1.969373ms
  08:14:08.020 [front-end] Posting Customer: {"username":"hPcZoGR","password":"kADzpzl","email":"hPcZoGR@gmail.com","firstName":"hPcZoGR","lastName":"hPcZoGR"}
  08:14:09.756 [front-end] Posting Customer: {"username":"fNsMA","password":"htlXdGT","email":"fNsMA@gmail.com","firstName":"fNsMA","lastName":"fNsMA"}
  08:14:11.826 [front-end] Order response: {"id":"67418ed33f77060008864fdf","customerId":"67418ec4a437380001def20f","customer":{"id":null,"firstName":"mVtyiOHM","lastName":"mVtyiOHM","use
  08:14:17.761 [front-end] Received response: "{\"firstName\":\"RHkPKvGiLJQ\",\"lastName\":\"RHkPKvGiLJQ\",\"username\":\"RHkPKvGiLJQ\",\"id\":\"67418ec1a437380001def204\",\"_links\":{\"a
  08:14:20.720 [front-end] Posting Customer: {"username":"DYVdBLexbV","password":"KYcDTD","email":"DYVdBLexbV@gmail.com","firstName":"DYVdBLexbV","lastName":"DYVdBLexbV"}
  08:14:23.993 [front-end] Received response: "{\"firstName\":\"DDWcsKeJ\",\"lastName\":\"DDWcsKeJ\",\"username\":\"DDWcsKeJ\",\"id\":\"67418ecfa437380001def224\",\"_links\":{\"addresses\
  08:14:26.674 [front-end] Received response: "{\"firstName\":\"snBtDqtFF\",\"lastName\":\"snBtDqtFF\",\"username\":\"snBtDqtFF\",\"id\":\"67418ecba437380001def21e\",\"_links\":{\"address
  08:14:30.117 [user] ts=2024-11-23T08:14:30.117455542Z caller=middlewares.go:46 method=Register username=PTcjnx email=PTcjnx@gmail.com took=2.763801ms
  08:14:32.336 [front-end] Order response: {"id":"67418ee83f77060008864fe9","customerId":"67418ed0a437380001def228","customer":{"id":null,"firstName":"DlRzbsLQWJ","lastName":"DlRzbsLQWJ",
  08:14:35.410 [front-end] Received response: "{\"firstName\":\"AVGFSmxhlQ\",\"lastName\":\"AVGFSmxhlQ\",\"username\":\"AVGFSmxhlQ\",\"id\":\"67418ed6a437380001def23d\",\"_links\":{\"addr
  08:14:38.004 [front-end] Posting Customer: {"username":"tDwhOAs","password":"hvmgzx","email":"tDwhOAs@gmail.com","firstName":"tDwhOAs","lastName":"tDwhOAs"}
  08:14:39.198 [front-end] Order response: {"id":"67418eef3f77060008864ff2","customerId":"67418ed6a437380001def23e","customer":{"id":null,"firstName":"hJqPI","lastName":"hJqPI","username"

## p0139
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T05:31:57.118Z
```
{"timestamp":1731907917118406700,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-sd8v2","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  05:31:56.127 [currencyservice] conversion request successful  (×15)
  05:31:56.393 [currencyservice] Getting supported currencies...  (×5)
All services, 30 seconds either side (sampled):
  05:31:27.579 [frontend] request started  (×291)
  05:31:27.583 [currencyservice] Getting supported currencies...  (×242)
  05:31:27.596 [currencyservice] conversion request successful  (×632)
  05:31:27.616 [adservice] received ad request (context_words=[clothing, tops])  (×17)
  05:31:27.892 [adservice] received ad request (context_words=[kitchen])  (×47)
  05:31:27.957 [shippingservice] [GetQuote] received request  (×65)
  05:31:28.042 [adservice] received ad request (context_words=[footwear])  (×13)
  05:31:28.051 [cartservice] AddItemAsync called with userId=acc735c5-72d0-48e6-b237-46a63eac4c4d, productId=L9ECAV7KIM, quantity=5  (×29)
  05:31:29.931 [frontend] home  (×30)
  05:31:29.988 [adservice] received ad request (context_words=[])  (×30)
  05:31:31.330 [recommendationservice] [Recv ListRecommendations] product_ids=['9SIQT8TOJO', 'OLJCESPC7Z', '6E92ZMYYFZ']  (×2)
  05:31:31.384 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="TRY"  (×2)
  05:31:31.434 [paymentservice] Transaction processed: visa ending 2674 Amount: TRY7986.543787768  (×2)
  05:31:31.438 [shippingservice] [ShipOrder] received request  (×6)
  05:31:31.441 [cartservice] EmptyCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×6)
  05:31:31.447 [checkoutservice] order confirmation email sent to "ncoleman@example.com"
  05:31:31.912 [adservice] received ad request (context_words=[decor, home])  (×15)
  05:31:34.196 [checkoutservice] [PlaceOrder] user_id="5e004f2d-a61a-45b2-840d-6bfd47a2be43" user_currency="JPY"
  05:31:34.223 [paymentservice] Transaction processed: visa ending 5616 Amount: JPY43417.645290246
  05:31:34.240 [checkoutservice] order confirmation email sent to "stephanieadams@example.org"
  05:31:37.483 [emailservice] A request to send order confirmation email to jeffrey07@example.org has been received.
  05:31:46.640 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="EUR"
  05:31:46.676 [paymentservice] Transaction processed: visa ending 2639 Amount: EUR2905.404688208
  05:31:46.696 [checkoutservice] order confirmation email sent to "duranalexander@example.net"
  05:32:06.959 [checkoutservice] [PlaceOrder] user_id="33421b66-55b6-413b-9ba9-3230c85c58dc" user_currency="USD"  (×2)
  05:32:06.983 [paymentservice] Transaction processed: visa ending 7224 Amount: USD214.850000000  (×2)
  05:32:06.995 [checkoutservice] order confirmation email sent to "annette97@example.com"
  05:32:19.265 [checkoutservice] order confirmation email sent to "angelayang@example.org"

## p0394
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:26.985Z
```
{"timestamp":1732247186985270500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Card: {\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"userID\":\"673ffe88b0df5c00019b3174\"}"}
```
Same service, the 2 minutes before (oldest first):
  03:46:26.486 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732247186482,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×2)
  03:46:26.486 [front-end] Order response: {"timestamp":1732247186482,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×2)
  03:46:26.489 [front-end] Request received with body: {}
  03:46:26.489 [front-end] POST /orders 500 - ms - -  (×2)
  03:46:26.496 [front-end] Received response: "{\"firstName\":\"gXlVL\",\"lastName\":\"gXlVL\",\"username\":\"gXlVL\",\"id\":\"673ffe80b0df5c00019b3159\",\"_links\":{\"addresses\":{\"href
  03:46:26.496 [front-end] GET Request to: http://user/customers/673ffe80b0df5c00019b3159/addresses  (×2)
  03:46:26.502 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe8ab0df5c00019b317b\",\"_links\":{\"
  03:46:26.505 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:46:26.505 [front-end] [ undefined, undefined ]
  03:46:26.505 [front-end] Posting Order: {"customer":"http://user/customers/673ffe80b0df5c00019b3159","address":"http://user/addresses/673ffe8ab0df5c00019b3176","card":"http://user/cards
  03:46:26.917 [front-end] Posting Customer: {"username":"SGNMlFJX","password":"XYhpJWT","email":"SGNMlFJX@gmail.com","firstName":"SGNMlFJX","lastName":"SGNMlFJX"}
  03:46:26.923 [front-end] { id: '673ffe92b0df5c00019b318f' }
  03:46:26.923 [front-end] 673ffe92b0df5c00019b318f
  03:46:26.923 [front-end] Merging carts for customer id: 673ffe92b0df5c00019b318f and session id: WBQmvmG8ZZ73Yt0J1h_a1KN42Tyi_nOi
  03:46:26.972 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffe88b0df5c00019b3174"}
  03:46:26.981 [front-end] POST /addresses 200 - ms - -
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×27)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×44)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×58)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×47)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×47)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×45)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×45)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×45)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h

## p0131
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:21:05.701Z
```
{"timestamp":1731907265701671400,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  05:21:05.146 [frontend] request started  (×6)
  05:21:05.146 [frontend] serving product page
  05:21:05.174 [frontend] failed to retrieve ads
  05:21:05.174 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14
  05:21:05.175 [frontend] request complete  (×5)
  05:21:05.178 [frontend] adding to cart
  05:21:05.190 [frontend] view user cart  (×2)
  05:21:05.256 [frontend] placing order
  05:21:05.322 [frontend] order placed
  05:21:05.701 [frontend] setting currency
All services, 30 seconds either side (sampled):
  05:20:36.094 [frontend] request started  (×312)
  05:20:36.103 [cartservice] GetCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121  (×252)
  05:20:36.130 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14  (×183)
  05:20:36.134 [frontend] adding to cart  (×31)
  05:20:36.172 [shippingservice] [GetQuote] received request  (×69)
  05:20:36.189 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="CAD"  (×2)
  05:20:36.212 [checkoutservice] payment went through (transaction_id: 7998f487-08b0-4a2d-b3a4-5c8d4f0c54ad)  (×8)
  05:20:36.217 [cartservice] EmptyCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121  (×8)
  05:20:36.226 [frontend] order placed  (×8)
  05:20:43.143 [frontend] setting currency  (×29)
  05:20:52.998 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"3102","nanos":711800148},"credit_card":{"credit_card_number":"4317888326303
  05:20:53.012 [checkoutservice] order confirmation email sent to "jstevens@example.org"
  05:20:55.028 [redis] 50:C 18 Nov 2024 05:20:55.027 * DB saved on disk
  05:20:56.363 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', 'OLJCESPC7Z', 'LS4PSXUNUM', 'L9ECAV7KIM']
  05:21:03.600 [checkoutservice] order confirmation email sent to "imcpherson@example.com"
  05:21:05.306 [paymentservice] Transaction processed: visa ending 6598 Amount: EUR1219.398496258  (×2)
  05:21:08.506 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="JPY"  (×3)
  05:21:08.571 [emailservice] A request to send order confirmation email to steven03@example.net has been received.
  05:21:16.961 [checkoutservice] order confirmation email sent to "michelebauer@example.com"
  05:21:25.742 [adservice] Tracing enabled but temporarily unavailable
  05:21:27.341 [adservice] Exception in thread "main" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000 at io.grpc.netty.NettyServer.start(NettyServer.java:333) at io.g
  05:21:28.553 [checkoutservice] order confirmation email sent to "lhernandez@example.com"

## p0550
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T18:21:26.710Z
```
{"timestamp":1733595686710250200,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-kwkx6","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:21:26.710  INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl       : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024, trainNumber=Z1236, startStation=nanjing, destStation=shanghai, seatType=3)"}
```
Same service, the 2 minutes before (oldest first):
  18:21:21.555 [ts-travel2-service] 2024-12-07 18:21:21.555 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：650 time: Sat May 04 09:55:52 GMT 2013
  18:21:21.555 [ts-travel2-service] 2024-12-07 18:21:21.555 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：20eb7122-3a11-423f-b10a-be0  (×3)
  18:21:21.561 [ts-travel2-service] 2024-12-07 18:21:21.561 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×3)
  18:21:26.373 [ts-travel2-service] 2024-12-07 18:21:26.373 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  18:21:26.411 [ts-travel2-service] 2024-12-07 18:21:26.411 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×3)
  18:21:26.416 [ts-travel2-service] 2024-12-07 18:21:26.416 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×3)
  18:21:26.536 [ts-travel2-service] 2024-12-07 18:21:26.536 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  18:21:26.547 [ts-travel2-service] 2024-12-07 18:21:26.546 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  18:21:26.597 [ts-travel2-service] 2024-12-07 18:21:26.597 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024, 
  18:21:26.630 [ts-travel2-service] 2024-12-07 18:21:26.630 INFO 1 --- [io-16346-exec-8] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236
  18:21:26.638 [ts-travel2-service] 2024-12-07 18:21:26.638 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  18:21:26.677 [ts-travel2-service] 2024-12-07 18:21:26.677 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int
All services, 30 seconds either side (sampled):
  18:20:57.378 [ts-admin-basic-info-service] 2024-12-07 18:20:57.378 INFO 1 --- [io-18767-exec-9] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×13)
  18:20:58.503 [ts-basic-service] 2024-12-07 18:20:58.503 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×74)
  18:20:58.576 [ts-price-service] 2024-12-07 18:20:58.576 INFO 1 --- [io-16579-exec-3] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×19)
  18:20:58.655 [ts-travel2-service] 2024-12-07 18:20:58.654 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×23)
  18:20:58.704 [ts-seat-service] 2024-12-07 18:20:58.703 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×15)
  18:20:58.830 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:20:58 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 343 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×11)
  18:20:59.193 [ts-basic-service] 2024-12-07 18:20:59.192 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×5)
  18:21:04.391 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:21:04 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 3056 "-" "Mozilla/5.0 (Macintosh;
  18:21:04.672 [ts-admin-travel-service] 2024-12-07 18:21:04.671 INFO 1 --- [io-16114-exec-8] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×24)
  18:21:05.219 [ts-travel2-service] 2024-12-07 18:21:05.219 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×5)
  18:21:07.588 [ts-price-service] 2024-12-07 18:21:07.588 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: f3d4d4ef-693b-4456-8ee
  18:21:07.663 [ts-travel-service] 2024-12-07 18:21:07.663 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr  (×12)
  18:21:07.721 [ts-travel-service] 2024-12-07 18:21:07.720 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×12)
  18:21:09.504 [ts-travel-service] 2024-12-07 18:21:09.504 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×3)
  18:21:11.323 [ts-contacts-service] 2024-12-07 18:21:11.323 INFO 1 --- [io-12347-exec-1] contacts.controller.ContactsController : [Contacts Service][Find Contacts By Account Id: 4d2a46c7-71cb-4cf1
  18:21:11.358 [ts-security-service] 2024-12-07 18:21:11.358 INFO 1 --- [io-11188-exec-2] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....
  18:21:11.398 [ts-preserve-other-service] 2024-12-07 18:21:11.398 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 2] Contacts Id: d14da0ec-da93-46c3-842d
  18:21:11.510 [ts-travel2-service] 2024-12-07 18:21:11.510 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [TravelService] [getTripAllDetailInfo] endPlaceID: nanjing
  18:21:12.334 [ts-seat-service] 2024-12-07 18:21:12.334 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Left ticket info is : Response(status=1, msg=Success, data=LeftTicketInfo{so
  18:21:12.372 [ts-order-other-service] 2024-12-07 18:21:12.372 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : [Order Other Service][Order Create] Price: 350.0
  18:21:14.582 [ts-basic-service] 2024-12-07 18:21:14.581 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×2)
  18:21:27.176 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:21:27.176+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359568
  18:21:29.028 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:21:29 +0800] "POST /api/v1/inside_pay_service/inside_payment HTTP/1.1" 200 71 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
  18:21:30.537 [ts-security-mongo] {"t":{"$date":"2024-12-07T18:21:30.537+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359569
  18:21:43.493 [ts-auth-service] 2024-12-07 18:21:43.493 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  18:21:43.785 [ts-basic-service] 2024-12-07 18:21:43.785 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3  (×2)
  18:21:46.375 [ts-travel-service] 2024-12-07 18:21:46.375 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:00:00 GMT 2013  (×6)
  18:21:49.626 [ts-admin-basic-info-service] 2024-12-07 18:21:49.625 INFO 1 --- [o-18767-exec-10] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult] 

## p0299
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T02:51:09.354Z
```
{"timestamp":1732243869354660400,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T02:51:09.354307785Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff198b0df5c00019b09d4 took=2.511394ms"}
```
Same service, the 2 minutes before (oldest first):
  02:51:08.307 [user] ts=2024-11-22T02:51:08.306747135Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff197b0df5c00019b09cf took=1.638781ms  (×2)
  02:51:08.600 [user] ts=2024-11-22T02:51:08.599962906Z caller=middlewares.go:75 method=GetUsers id=673ff188b0df5c00019b09a1 result=1 took=941.317µs  (×8)
  02:51:08.617 [user] ts=2024-11-22T02:51:08.616927639Z caller=middlewares.go:104 method=GetAddresses id=673ff18eb0df5c00019b09b1 result=1 took=925.115µs  (×2)
  02:51:08.617 [user] ts=2024-11-22T02:51:08.616947013Z caller=middlewares.go:134 method=GetCards id=673ff18eb0df5c00019b09b2 result=1 took=893.231µs  (×2)
  02:51:08.722 [user] ts=2024-11-22T02:51:08.722136702Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff197b0df5c00019b09d0 took=1.640103ms  (×2)
  02:51:08.794 [user] ts=2024-11-22T02:51:08.794277395Z caller=middlewares.go:46 method=Register username=uYctLBvY email=uYctLBvY@gmail.com took=1.058237ms
  02:51:09.032 [user] ts=2024-11-22T02:51:09.031954028Z caller=middlewares.go:46 method=Register username=jMeFxmOu email=jMeFxmOu@gmail.com took=1.075822ms
  02:51:09.094 [user] ts=2024-11-22T02:51:09.093949292Z caller=middlewares.go:157 method=Health result=2 took=818.559µs  (×2)
All services, 30 seconds either side (sampled):
  02:50:39.636 [catalogue] ts=2024-11-22T02:50:39Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.325342ms  (×59)
  02:50:39.908 [front-end] Attempting to add to cart: {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","quantity":1}  (×64)
  02:50:40.189 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff171b0df5c00019b0967\",\"_links\":{\"  (×56)
  02:50:40.220 [queue-master] 2024-11-22 02:50:40.220 INFO 6 --- [ool-6-thread-50] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×42)
  02:50:40.749 [payment] ts=2024-11-22T02:50:40Z caller=logging.go:29 method=Authorise result=true took=966ns  (×38)
  02:50:41.654 [front-end] { id: '673ff181b0df5c00019b0985' }  (×61)
  02:50:42.093 [user] ts=2024-11-22T02:50:42.093378093Z caller=middlewares.go:157 method=Health result=2 took=658.649µs  (×38)
  02:50:43.550 [user] ts=2024-11-22T02:50:43.549896999Z caller=middlewares.go:46 method=Register username=gcwEKFgo email=gcwEKFgo@gmail.com took=1.023705ms
  02:50:46.134 [front-end] Received response: "{\"firstName\":\"QOQKXaUVkO\",\"lastName\":\"QOQKXaUVkO\",\"username\":\"QOQKXaUVkO\",\"id\":\"673ff174b0df5c00019b096c\",\"_links\":{\"addr
  02:50:48.335 [front-end] Posting Customer: {"username":"QbDzm","password":"eUVIdPWd","email":"QbDzm@gmail.com","firstName":"QbDzm","lastName":"QbDzm"}
  02:50:51.656 [front-end] Posting Customer: {"username":"iaBjADP","password":"tMnuVVtVB","email":"iaBjADP@gmail.com","firstName":"iaBjADP","lastName":"iaBjADP"}
  02:50:54.523 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×6)
  02:50:57.290 [front-end] Order response: {"id":"673ff191d94b9000069b3e57","customerId":"673ff17ab0df5c00019b0975","customer":{"id":null,"firstName":"afISOewdQglINZ","lastName":"afISOewd
  02:50:59.941 [front-end] Order response: {"id":"673ff193d94b9000069b3e59","customerId":"673ff181b0df5c00019b0985","customer":{"id":null,"firstName":"RAHtTlVmlDm","lastName":"RAHtTlVmlDm
  02:51:03.207 [front-end] Received response: "{\"firstName\":\"FTPLDLVNJGS\",\"lastName\":\"FTPLDLVNJGS\",\"username\":\"FTPLDLVNJGS\",\"id\":\"673ff17eb0df5c00019b0980\",\"_links\":{\"a
  02:51:03.714 [user] ts=2024-11-22T02:51:03.713778055Z caller=middlewares.go:46 method=Register username=GIWWf email=GIWWf@gmail.com took=1.031965ms
  02:51:04.982 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff198d94b9000069b3e5f","customerId":"673ff181b0df5c00019b0986","customer":{"id":null,"firstName":"sXqyGcud","
  02:51:06.976 [front-end] Received response: "{\"firstName\":\"iaBjADP\",\"lastName\":\"iaBjADP\",\"username\":\"iaBjADP\",\"id\":\"673ff18bb0df5c00019b09aa\",\"_links\":{\"addresses\":{
  02:51:08.883 [front-end] Order response: {"id":"673ff19cd94b9000069b3e65","customerId":"673ff184b0df5c00019b0995","customer":{"id":null,"firstName":"hislSUrlBPGX","lastName":"hislSUrlBP
  02:51:10.802 [front-end] Received response: "{\"firstName\":\"DQvTgbESEdw\",\"lastName\":\"DQvTgbESEdw\",\"username\":\"DQvTgbESEdw\",\"id\":\"673ff185b0df5c00019b0998\",\"_links\":{\"a
  02:51:13.854 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff1a1d94b9000069b3e6b","customerId":"673ff187b0df5c00019b099c","customer":{"id":null,"firstName":"SqFHSbllQSR
  02:51:18.851 [front-end] Received response: "{\"firstName\":\"bVAabIKcSZvr\",\"lastName\":\"bVAabIKcSZvr\",\"username\":\"bVAabIKcSZvr\",\"id\":\"673ff18fb0df5c00019b09b8\",\"_links\":{
  02:51:20.447 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff1a8d94b9000069b3e6f","customerId":"673ff195b0df5c00019b09c9","customer":{"id":null,"firstName":"ntIiC","las
  02:51:21.862 [front-end] Posting Customer: {"username":"uqNUroPUQlWulIC","password":"tvvpK","email":"uqNUroPUQlWulIC@gmail.com","firstName":"uqNUroPUQlWulIC","lastName":"uqNUroPUQlWulIC
  02:51:23.409 [front-end] Posting Customer: {"username":"TXFMzhddnVTpO","password":"sevUPjE","email":"TXFMzhddnVTpO@gmail.com","firstName":"TXFMzhddnVTpO","lastName":"TXFMzhddnVTpO"}
  02:51:25.740 [front-end] Posting Customer: {"username":"NMxxYzllIFP","password":"nNUnMsdB","email":"NMxxYzllIFP@gmail.com","firstName":"NMxxYzllIFP","lastName":"NMxxYzllIFP"}
  02:51:28.547 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff1b0d94b9000069b3e78","customerId":"673ff198b0df5c00019b09d4","customer":{"id":null,"firstName":"StgTxHYJmka
  02:51:31.013 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff1b3d94b9000069b3e7b","customerId":"673ff197b0df5c00019b09d3","customer":{"id":null,"firstName":"GIWWf","las
  02:51:34.409 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff1b6d94b9000069b3e7e","customerId":"673ff1a7b0df5c00019b0a03","customer":{"id":null,"firstName":"SPtMEqJgM",
  02:51:37.661 [front-end] Posting Customer: {"username":"OWozfZS","password":"RRyagV","email":"OWozfZS@gmail.com","firstName":"OWozfZS","lastName":"OWozfZS"}

## p0125
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service checkoutservice, 2024-11-18T05:18:26.910Z
```
{"service":"checkoutservice","operation":"hipstershop.CheckoutService/PlaceOrder","method":"PlaceOrder","status_code":13,"duration_us":52791,"trace_id":"b52573f8a8599bd5184ec1ec9530d37f","message":"span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13"}
```
Same service, the 2 minutes before (oldest first):
  05:17:24.126 [checkoutservice] order confirmation email sent to "adamholder@example.org"
  05:17:25.086 [checkoutservice] [PlaceOrder] user_id="33421b66-55b6-413b-9ba9-3230c85c58dc" user_currency="TRY"  (×3)
  05:17:25.114 [checkoutservice] payment went through (transaction_id: 58e6f1bc-db23-430b-813e-3fddd976218e)  (×6)
  05:17:25.127 [checkoutservice] order confirmation email sent to "coxchristine@example.net"
  05:17:49.561 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="CAD"
  05:17:49.603 [checkoutservice] order confirmation email sent to "vicki59@example.com"
  05:17:55.239 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="EUR"
  05:17:55.276 [checkoutservice] order confirmation email sent to "alopez@example.org"
  05:18:02.298 [checkoutservice] order confirmation email sent to "caseyhoward@example.com"
  05:18:22.485 [checkoutservice] [PlaceOrder] user_id="fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a" user_currency="GBP"
  05:18:22.564 [checkoutservice] order confirmation email sent to "janetbrown@example.org"
  05:18:25.940 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="JPY"
  05:18:25.994 [checkoutservice] order confirmation email sent to "bradycarla@example.net"
All services, 30 seconds either side (sampled):
  05:17:58.058 [frontend] request started  (×292)
  05:17:58.067 [cartservice] GetCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×246)
  05:17:58.087 [frontend] failed to retrieve ads  (×177)
  05:17:58.090 [frontend] adding to cart  (×27)
  05:17:58.127 [shippingservice] [GetQuote] received request  (×68)
  05:17:58.812 [frontend] ENV_PLATFORM is: aws  (×34)
  05:18:02.258 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="TRY"  (×3)
  05:18:02.287 [checkoutservice] payment went through (transaction_id: f6b68b4a-60c3-43ba-a064-a6b85fb7ff1c)  (×7)
  05:18:02.293 [cartservice] EmptyCartAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4  (×7)
  05:18:02.299 [frontend] order placed  (×7)
  05:18:18.646 [adservice] AdService starting.  (×2)
  05:18:18.741 [adservice] Tracing enabled - Stackdriver exporter initialized.  (×2)
  05:18:20.440 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  05:18:22.550 [paymentservice] Transaction processed: visa ending 1783 Amount: GBP1521.300176901
  05:18:25.894 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '0PUK6V6EV0', '6E92ZMYYFZ', '1YMWWN1N4O']  (×6)
  05:18:25.981 [paymentservice] Transaction processed: visa ending 9193 Amount: JPY106183.826626688  (×3)
  05:18:26.957 [checkoutservice] span hipstershop.PaymentService/Charge failed with gRPC status 400
  05:18:26.960 [paymentservice] }
  05:18:32.581 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"1094","nanos":975674484},"credit_card":{"credit_card_number":"4461575195133
  05:18:32.595 [checkoutservice] order confirmation email sent to "tashawolf@example.org"
  05:18:45.410 [emailservice] A request to send order confirmation email to fknox@example.org has been received.
  05:18:49.071 [checkoutservice] order confirmation email sent to "kathy75@example.com"

## p0784
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:33:00.856Z
```
{"timestamp":1732350780856973300,"container_name":"front-end","pod_name":"front-end-f77549869-fh46p","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"{\"id\":\"510a0d7e-8e83-4193-b483-e27e09ddc34d\",\"name\":\"SuperSport XL\",\"description\":\"Ready for action. Engineers: be ready to smash that next bug! Be ready, with these super-action-sport-masterpieces. This particular engineer was chased away from the office with a stick.\",\"imageUrl\":[\"/catalogue/images/puma_1.jpeg\",\"/catalogue/images/puma_2.jpeg\"],\"price\":15,\"count\":820,\"tag\":[\"sport\",\"black\",\"forma…"}
```
Same service, the 2 minutes before (oldest first):
  08:32:59.723 [front-end] Carts merged.  (×2)
  08:32:59.723 [front-end] set cookie6741933ba437380001def70f  (×2)
  08:32:59.724 [front-end] Sent cookies.  (×2)
  08:32:59.725 [front-end] POST /register 200 31.137 ms - 33  (×2)
  08:33:00.165 [front-end] Posting Customer: {"username":"jFuhOMhJvmz","password":"ARImeXskgH","email":"jFuhOMhJvmz@gmail.com","firstName":"jFuhOMhJvmz","lastName":"jFuhOMhJvmz"}
  08:33:00.174 [front-end] { id: '6741933ca437380001def710' }
  08:33:00.174 [front-end] 6741933ca437380001def710
  08:33:00.174 [front-end] Merging carts for customer id: 6741933ca437380001def710 and session id: 6F6O8rZdE26dJRm5dca5_kieNLcs0a4m
  08:33:00.744 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67419337a437380001def704"}
  08:33:00.756 [front-end] POST /addresses 200 - ms - -
  08:33:00.760 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67419337a437380001def704"}
  08:33:00.772 [front-end] POST /cards 200 - ms - -
  08:33:00.820 [front-end] Attempting to delete cart for user: 67419337a437380001def704
  08:33:00.840 [front-end] User cart deleted with status: 202
  08:33:00.841 [front-end] DELETE /cart 202 - ms - -
  08:33:00.846 [front-end] Attempting to add to cart: {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","quantity":1}
All services, 30 seconds either side (sampled):
  08:32:31.581 [front-end] Posting Customer: {"username":"OhtkBXcmI","password":"CmtyPl","email":"OhtkBXcmI@gmail.com","firstName":"OhtkBXcmI","lastName":"OhtkBXcmI"}
  08:32:31.827 [user] ts=2024-11-23T08:32:31.827549093Z caller=middlewares.go:46 method=Register username=zsiHppn email=zsiHppn@gmail.com took=2.021626ms
  08:32:32.601 [user] ts=2024-11-23T08:32:32.601559518Z caller=middlewares.go:134 method=GetCards id=67419315a437380001def698 result=1 took=2.092217ms  (×62)
  08:32:32.624 [front-end] Order response: {"id":"674193203f7706000886510b","customerId":"6741930ba437380001def675","customer":{"id":null,"firstName":"VQlKsWdqbkzx","lastName":"VQlKsWdqbk
  08:32:32.767 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×59)
  08:32:33.041 [front-end] POST to carts: http://carts/carts/6741931aa437380001def6a6/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}  (×26)
  08:32:33.788 [user] ts=2024-11-23T08:32:33.788774284Z caller=middlewares.go:46 method=Register username=BaPTAfCHUdYX email=BaPTAfCHUdYX@gmail.com took=1.948321ms  (×29)
  08:32:35.152 [carts] 2024-11-23 08:32:35.152 INFO [carts,9f4b7a16345ae2e6,b27ad590fca4be0e,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×23)
  08:32:37.216 [front-end] Received response: "{\"firstName\":\"LYMMPPajlHTeqIx\",\"lastName\":\"LYMMPPajlHTeqIx\",\"username\":\"LYMMPPajlHTeqIx\",\"id\":\"6741930ca437380001def679\",\"_
  08:32:39.080 [front-end] Order response: {"statusCode":201,"body":{"id":"674193273f77060008865113","customerId":"67419311a437380001def689","customer":{"id":null,"firstName":"uirgXynKPt"
  08:32:40.558 [front-end] Order response: {"statusCode":201,"body":{"id":"674193283f77060008865116","customerId":"67419311a437380001def682","customer":{"id":null,"firstName":"EruwQavgMGj
  08:32:41.330 [front-end] Received response: "{\"firstName\":\"wGNMErh\",\"lastName\":\"wGNMErh\",\"username\":\"wGNMErh\",\"id\":\"67419312a437380001def68b\",\"_links\":{\"addresses\":{
  08:32:42.636 [front-end] Received response: "{\"firstName\":\"boNSnucZLCTPzDo\",\"lastName\":\"boNSnucZLCTPzDo\",\"username\":\"boNSnucZLCTPzDo\",\"id\":\"67419311a437380001def684\",\"_
  08:32:43.720 [user] ts=2024-11-23T08:32:43.720044519Z caller=middlewares.go:46 method=Register username=qRmqZR email=qRmqZR@gmail.com took=2.51497ms
  08:32:48.245 [front-end] Received response: "{\"firstName\":\"tQTOhfx\",\"lastName\":\"tQTOhfx\",\"username\":\"tQTOhfx\",\"id\":\"67419314a437380001def695\",\"_links\":{\"addresses\":{
  08:32:50.792 [front-end] Received response: "{\"firstName\":\"OhtkBXcmI\",\"lastName\":\"OhtkBXcmI\",\"username\":\"OhtkBXcmI\",\"id\":\"6741931fa437380001def6c3\",\"_links\":{\"address
  08:32:55.009 [front-end] Order response: {"id":"674193373f77060008865123","customerId":"67419322a437380001def6cc","customer":{"id":null,"firstName":"vHBZbOrfy","lastName":"vHBZbOrfy","u
  08:32:56.362 [front-end] Posting Customer: {"username":"DCJlQrzQHtjiz","password":"SmpPpTEMdk","email":"DCJlQrzQHtjiz@gmail.com","firstName":"DCJlQrzQHtjiz","lastName":"DCJlQrzQHtjiz"}
  08:32:59.223 [front-end] Order response: {"statusCode":201,"body":{"id":"6741933b3f77060008865128","customerId":"67419326a437380001def6d8","customer":{"id":null,"firstName":"UvMADRKUoN"
  08:33:01.446 [queue-master] 2024-11-23 08:33:01.446 INFO 7 --- [pool-6-thread-3] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×9)
  08:33:04.066 [front-end] Received response: "{\"firstName\":\"UraaKHKNW\",\"lastName\":\"UraaKHKNW\",\"username\":\"UraaKHKNW\",\"id\":\"67419330a437380001def6f5\",\"_links\":{\"address
  08:33:06.930 [front-end] Posting Customer: {"username":"ScTMMhoWtYGUN","password":"LTKebar","email":"ScTMMhoWtYGUN@gmail.com","firstName":"ScTMMhoWtYGUN","lastName":"ScTMMhoWtYGUN"}
  08:33:09.780 [front-end] Received response: "{\"firstName\":\"gVEri\",\"lastName\":\"gVEri\",\"username\":\"gVEri\",\"id\":\"6741932fa437380001def6f4\",\"_links\":{\"addresses\":{\"href
  08:33:13.533 [user] ts=2024-11-23T08:33:13.533682153Z caller=middlewares.go:46 method=Register username=YpoxB email=YpoxB@gmail.com took=2.105483ms
  08:33:16.957 [user] ts=2024-11-23T08:33:16.957557447Z caller=middlewares.go:46 method=Register username=rZNjSwGsR email=rZNjSwGsR@gmail.com took=1.955427ms
  08:33:19.317 [front-end] Posting Customer: {"username":"SRHGoGAlPgtYc","password":"AHGXzRg","email":"SRHGoGAlPgtYc@gmail.com","firstName":"SRHGoGAlPgtYc","lastName":"SRHGoGAlPgtYc"}
  08:33:20.147 [front-end] Posting Customer: {"username":"EQXxKAifXqWQK","password":"xrMdRR","email":"EQXxKAifXqWQK@gmail.com","firstName":"EQXxKAifXqWQK","lastName":"EQXxKAifXqWQK"}
  08:33:23.117 [front-end] Received response: "{\"firstName\":\"NmmgfzuzC\",\"lastName\":\"NmmgfzuzC\",\"username\":\"NmmgfzuzC\",\"id\":\"67419344a437380001def72b\",\"_links\":{\"address
  08:33:24.444 [user] ts=2024-11-23T08:33:24.44460691Z caller=middlewares.go:46 method=Register username=PdACH email=PdACH@gmail.com took=3.068263ms
  08:33:28.550 [front-end] Posting Customer: {"username":"NnmSY","password":"WQNmemT","email":"NnmSY@gmail.com","firstName":"NnmSY","lastName":"NnmSY"}

## p0771
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T19:26:46.341Z
```
{"timestamp":1732390006341599200,"container_name":"front-end","pod_name":"front-end-f77549869-q8jx8","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"POST /cart 500 62.502 ms - 64"}
```
Same service, the 2 minutes before (oldest first):
  19:26:46.127 [front-end] Attempting to delete cart for user: 67422c6b48485600016b1721  (×2)
  19:26:46.160 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67422c6d48485600016b1724"}  (×2)
  19:26:46.174 [front-end] POST /addresses 200 - ms - -  (×2)
  19:26:46.179 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67422c6d48485600016b1724"}  (×2)
  19:26:46.180 [front-end] User cart deleted with status: 503  (×2)
  19:26:46.181 [front-end] DELETE /cart 503 - ms - -  (×2)
  19:26:46.185 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×2)
  19:26:46.194 [front-end] POST /cards 200 - ms - -
  19:26:46.196 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  19:26:46.196 [front-end] POST to carts: http://carts/carts/67422c6b48485600016b1721/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×2)
  19:26:46.230 [front-end] POST /cart 500 44.004 ms - 64
  19:26:46.290 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
All services, 30 seconds either side (sampled):
  19:26:16.452 [front-end] Request received with body: {}  (×62)
  19:26:16.498 [user] ts=2024-11-23T19:26:16.498777241Z caller=middlewares.go:134 method=GetCards id=67422c4748485600016b16b9 result=1 took=4.484579ms  (×62)
  19:26:16.550 [front-end] GET /catalogue 200 - ms - -  (×70)
  19:26:16.720 [front-end] User cart deleted with status: 503  (×60)
  19:26:16.795 [user] ts=2024-11-23T19:26:16.795255442Z caller=middlewares.go:46 method=Register username=DyqqOfiUN email=DyqqOfiUN@gmail.com took=4.032853ms
  19:26:16.839 [front-end] Posting Customer: {"username":"QvDUr","password":"brflyiequc","email":"QvDUr@gmail.com","firstName":"QvDUr","lastName":"QvDUr"}
  19:26:18.299 [carts] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  19:26:19.316 [front-end] Received response: "{\"firstName\":\"bEsnpi\",\"lastName\":\"bEsnpi\",\"username\":\"bEsnpi\",\"id\":\"67422c4948485600016b16c1\",\"_links\":{\"addresses\":{\"h
  19:26:22.487 [front-end] Posting Customer: {"username":"ZSxSSGOG","password":"tbDkvTdqb","email":"ZSxSSGOG@gmail.com","firstName":"ZSxSSGOG","lastName":"ZSxSSGOG"}
  19:26:24.088 [front-end] Received response: "{\"firstName\":\"PzDVrke\",\"lastName\":\"PzDVrke\",\"username\":\"PzDVrke\",\"id\":\"67422c4948485600016b16c3\",\"_links\":{\"addresses\":{
  19:26:28.169 [front-end] Posting Customer: {"username":"iKQRrdwtSeft","password":"JwHduScC","email":"iKQRrdwtSeft@gmail.com","firstName":"iKQRrdwtSeft","lastName":"iKQRrdwtSeft"}
  19:26:30.617 [user] ts=2024-11-23T19:26:30.617821082Z caller=middlewares.go:46 method=Register username=ZjUAK email=ZjUAK@gmail.com took=5.312782ms
  19:26:34.954 [front-end] Received response: "{\"firstName\":\"ELtTnecX\",\"lastName\":\"ELtTnecX\",\"username\":\"ELtTnecX\",\"id\":\"67422c5748485600016b16e1\",\"_links\":{\"addresses\
  19:26:36.400 [front-end] Posting Customer: {"username":"zywWwrHcdTUEAP","password":"CFSLxqkD","email":"zywWwrHcdTUEAP@gmail.com","firstName":"zywWwrHcdTUEAP","lastName":"zywWwrHcdTUEAP"
  19:26:38.160 [front-end] Posting Customer: {"username":"ASzbWwZjd","password":"qLKioFf","email":"ASzbWwZjd@gmail.com","firstName":"ASzbWwZjd","lastName":"ASzbWwZjd"}
  19:26:40.894 [front-end] Posting Customer: {"username":"TZfndMZCm","password":"cXLozp","email":"TZfndMZCm@gmail.com","firstName":"TZfndMZCm","lastName":"TZfndMZCm"}
  19:26:43.024 [front-end] Received response: "{\"firstName\":\"oqMFbrcw\",\"lastName\":\"oqMFbrcw\",\"username\":\"oqMFbrcw\",\"id\":\"67422c5548485600016b16dd\",\"_links\":{\"addresses\
  19:26:46.858 [front-end] Posting Customer: {"username":"oPzCmbDmACBeNe","password":"zaRIGFg","email":"oPzCmbDmACBeNe@gmail.com","firstName":"oPzCmbDmACBeNe","lastName":"oPzCmbDmACBeNe"}
  19:26:50.104 [carts] 2024-11-23 19:26:50.103 INFO [carts,,,] 7 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.11
  19:26:51.806 [user] ts=2024-11-23T19:26:51.806496208Z caller=middlewares.go:46 method=Register username=eWnJo email=eWnJo@gmail.com took=3.884168ms
  19:26:56.224 [front-end] Received response: "{\"firstName\":\"RorxZKnpvVHbGNQ\",\"lastName\":\"RorxZKnpvVHbGNQ\",\"username\":\"RorxZKnpvVHbGNQ\",\"id\":\"67422c6948485600016b171e\",\"_
  19:26:58.530 [front-end] Received response: "{\"firstName\":\"ASzbWwZjd\",\"lastName\":\"ASzbWwZjd\",\"username\":\"ASzbWwZjd\",\"id\":\"67422c6e48485600016b172b\",\"_links\":{\"address
  19:27:00.302 [carts] 2024-11-23 19:27:00.302 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'metricsServlet' to [/metrics]
  19:27:02.253 [front-end] Received response: "{\"firstName\":\"tErhrZABQFz\",\"lastName\":\"tErhrZABQFz\",\"username\":\"tErhrZABQFz\",\"id\":\"67422c6d48485600016b172a\",\"_links\":{\"a
  19:27:04.705 [carts] 2024-11-23 19:27:04.704 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:64}] t
  19:27:09.528 [front-end] Received response: "{\"firstName\":\"hKDwbuU\",\"lastName\":\"hKDwbuU\",\"username\":\"hKDwbuU\",\"id\":\"67422c7948485600016b1752\",\"_links\":{\"addresses\":{
  19:27:11.286 [user] ts=2024-11-23T19:27:11.285866478Z caller=middlewares.go:46 method=Register username=GAcmQSNZ email=GAcmQSNZ@gmail.com took=3.956821ms
  19:27:13.809 [user] ts=2024-11-23T19:27:13.808974797Z caller=middlewares.go:46 method=Register username=LzBjhAr email=LzBjhAr@gmail.com took=4.975981ms
  19:27:14.590 [user] ts=2024-11-23T19:27:14.589911926Z caller=middlewares.go:46 method=Register username=FOBZYRtn email=FOBZYRtn@gmail.com took=5.099236ms

## p0574
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:03.871Z
```
{"timestamp":1733596263871760600,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:03.871  INFO 1 --- [           main] o.s.b.a.e.mvc.EndpointHandlerMapping     : Mapped \"{[/heapdump || /heapdump.json],methods=[GET],produces=[application/octet-stream]}\" onto public void org.springframework.boot.actuate.endpoint.mvc.HeapdumpMvcEndpoint.invoke(boolean,javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse) throws java.io.IOException,javax.ser…"}
```
Same service, the 2 minutes before (oldest first):
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/{userId}],methods=[DELETE]}" onto public org.sprin
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  18:31:01.654 [ts-auth-service] 2024-12-07 18:31:01.653 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth/hello],methods=[GET]}" onto public java.lang.String
  18:31:01.654 [ts-auth-service] 2024-12-07 18:31:01.653 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth],methods=[POST]}" onto public org.springframework.h
  18:31:01.656 [ts-auth-service] 2024-12-07 18:31:01.655 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  18:31:01.656 [ts-auth-service] 2024-12-07 18:31:01.655 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  18:31:01.962 [ts-auth-service] 2024-12-07 18:31:01.961 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.springframewo
  18:31:01.962 [ts-auth-service] 2024-12-07 18:31:01.962 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springframework.web.s
  18:31:02.163 [ts-auth-service] 2024-12-07 18:31:02.162 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class org.springfra
  18:31:03.486 [ts-auth-service] 2024-12-07 18:31:03.485 INFO 1 --- [ main] o.s.i.config.IntegrationRegistrar : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. The
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
  18:31:03.868 [ts-auth-service] 2024-12-07 18:31:03.868 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[application/vnd.sprin
  18:31:03.868 [ts-auth-service] 2024-12-07 18:31:03.868 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/vnd.spring-boot.
  18:31:03.868 [ts-auth-service] 2024-12-07 18:31:03.868 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/vnd.spring-bo
  18:31:03.869 [ts-auth-service] 2024-12-07 18:31:03.869 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  18:31:03.869 [ts-auth-service] 2024-12-07 18:31:03.869 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[application/vnd.sprin
  18:31:03.869 [ts-auth-service] 2024-12-07 18:31:03.869 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/auditevents || /auditevents.json],methods=[GET],produces=[applicati
All services, 30 seconds either side (sampled):
  18:30:36.068 [ts-auth-service] 2024-12-07 18:30:36.068 INFO 1 --- [ main] o.s.i.config.IntegrationRegistrar : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. The  (×2)
  18:30:37.767 [ts-basic-service] 2024-12-07 18:30:37.766 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×16)
  18:30:37.816 [ts-basic-service] 2024-12-07 18:30:37.815 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3  (×19)
  18:30:37.888 [ts-travel2-service] 2024-12-07 18:30:37.887 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×24)
  18:30:38.000 [ts-travel2-service] 2024-12-07 18:30:37.999 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6  (×11)
  18:30:40.487 [ts-basic-service] 2024-12-07 18:30:40.487 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×6)
  18:30:40.692 [ts-travel2-service] 2024-12-07 18:30:40.692 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×2)
  18:30:41.733 [ts-basic-service] 2024-12-07 18:30:41.733 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×9)
  18:30:42.403 [ts-food-service] 2024-12-07 18:30:42.403 INFO 1 --- [io-18856-exec-3] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×2)
  18:30:44.984 [ts-travel2-service] 2024-12-07 18:30:44.983 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  18:30:47.149 [ts-travel-service] 2024-12-07 18:30:47.149 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×6)
  18:30:47.235 [ts-order-service] 2024-12-07 18:30:47.234 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 38  (×6)
  18:30:47.299 [ts-order-service] 2024-12-07 18:30:47.299 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160,   (×5)
  18:30:51.661 [ts-auth-service] 2024-12-07 18:30:51.661 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClust
  18:30:57.085 [ts-seat-service] 2024-12-07 18:30:57.085 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×3)
  18:30:58.183 [ts-order-other-service] 2024-12-07 18:30:58.182 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×2)
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.872 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics || /metrics.json],methods=[GET],produces=[application/vnd.s
  18:31:05.058 [ts-auth-service] 2024-12-07 18:31:05.057 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.embedded.A
  18:31:10.954 [ts-auth-service] 2024-12-07 18:31:10.953 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.907 seconds (JVM running for 71.147)
  18:31:11.909 [ts-basic-service] 2024-12-07 18:31:11.909 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  18:31:19.676 [ts-travel2-service] 2024-12-07 18:31:19.676 ERROR 1 --- [o-16346-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:31:27.403 [ts-travel-mongo] {"t":{"$date":"2024-12-07T18:31:27.403+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:29.428 [ts-assurance-service] 2024-12-07 18:31:29.428 ERROR 1 --- [io-18888-exec-7] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:31:30.519 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T18:31:30.518+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:31.698 [ts-order-service] 2024-12-07 18:31:31.698 ERROR 1 --- [io-12031-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt

## p0707
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-14T01:21:23.503Z
```
{"service":"dbservice2","message":"2021-08-14 01:21:23,503 | INFO | 0.0.0.2 | dbservice2 | permission_operate.py -> permission_operation -> 51 | 157b81e6c44ddfde | now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  01:21:17.659 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  01:21:17.715 [dbservice2] INFO query = select passwards from username_table where user_name='ICtSnKPU'  (×5)
  01:21:17.793 [dbservice2] INFO de3bad80-fc5a-11eb-9958-0242ac110004-ICtSnKPU-dwfRYX_84Pp6 token generate success token=MTYyODg3NTI3Ny43OTMwNDI0OmRlM2JhZDgwLWZjNWEtMTFlYi05OTU4LTAyNDJhYzE
  01:21:18.462 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  01:21:18.559 [dbservice2] INFO deb5368c-fc5a-11eb-af51-0242ac110004-TuOeLVZp-oM^!RSHCyT6} token generate success token=MTYyODg3NTI3OC41NTkwMTY6ZGViNTM2OGMtZmM1YS0xMWViLWFmNTEtMDI0MmFjMTE
  01:21:19.418 [dbservice2] INFO df2e6b56-fc5a-11eb-aded-0242ac110003-Bmsjcfbe-.Df068n2zr9m token generate success token=MTYyODg3NTI3OS40MTc1MDc6ZGYyZTZiNTYtZmM1YS0xMWViLWFkZWQtMDI0MmFjMTE
  01:21:21.073 [dbservice2] INFO e0294a58-fc5a-11eb-b03f-0242ac110004-ayOIXsmT-0/zb.4@*&g{9 token generate success token=MTYyODg3NTI4MS4wNzI5NTA0OmUwMjk0YTU4LWZjNWEtMTFlYi1iMDNmLTAyNDJhYzE
  01:21:21.962 [dbservice2] INFO e0ac2252-fc5a-11eb-8312-0242ac110003-URvXGzml-*5)F@m4bJeLU token generate success token=MTYyODg3NTI4MS45NjIyNDY0OmUwYWMyMjUyLWZjNWEtMTFlYi04MzEyLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  01:20:53.541 [redisservice1] INFO redis读取信息成功, status_code: 200  (×44)
  01:20:53.592 [logservice1] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': 'cfe01546-fc5a-11eb-8864-0242ac110003', 'user_id': 'iZWtCSMp'}  (×93)
  01:20:53.907 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×48)
  01:20:54.128 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×50)
  01:20:54.357 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'd06d7026-fc5a-11eb-ae7e-0242ac110004'}  (×55)
  01:20:54.781 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×45)
  01:20:55.452 [dbservice2] INFO d0f2a85e-fc5a-11eb-b70f-0242ac110003-IdNORUSj-swS@j6J2Bk%t token generate success token=MTYyODg3NTI1NS40NTIwMjI6ZDBmMmE4NWUtZmM1YS0xMWViLWI3MGYtMDI0MmFjMTE
  01:20:56.194 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×44)
  01:20:57.506 [mobservice2] INFO info d25f08b8-fc5a-11eb-bdeb-0242ac110004:ZQXfBztT write success
  01:21:00.107 [mobservice1] INFO info d3eafc00-fc5a-11eb-8988-0242ac110003:NWUBeIdk write success
  01:21:02.733 [mobservice2] INFO info d57ff1d8-fc5a-11eb-ba7f-0242ac110004:DBUWXtFp write success
  01:21:05.130 [mobservice2] INFO info d6e77b18-fc5a-11eb-9a20-0242ac110004:GZqDYHLc write success
  01:21:07.718 [mobservice2] INFO info d87544ba-fc5a-11eb-8f87-0242ac110003:uGrcWJOt write success
  01:21:10.470 [dbservice1] INFO d9f5c5b2-fc5a-11eb-9f19-0242ac110003-tJwGvlrd-_X.0m+hp>Z-/ token generate success token=MTYyODg3NTI3MC40Njk2Mzg4OmQ5ZjVjNWIyLWZjNWEtMTFlYi05ZjE5LTAyNDJhYzE
  01:21:12.848 [dbservice2] INFO db4e45f6-fc5a-11eb-87dd-0242ac110003-gSjZMlmO--CEXg)FY#_sv token generate success token=MTYyODg3NTI3Mi44NDgxOTk4OmRiNGU0NWY2LWZjNWEtMTFlYi04N2RkLTAyNDJhYzE
  01:21:15.738 [mobservice2] INFO info dd449536-fc5a-11eb-a287-0242ac110003:cFoEvJPG write success
  01:21:18.245 [mobservice1] INFO info deb5368c-fc5a-11eb-af51-0242ac110004:TuOeLVZp write success
  01:21:20.679 [mobservice2] INFO info e0294a58-fc5a-11eb-b03f-0242ac110004:ayOIXsmT write success
  01:21:23.644 [dbservice2] INFO e1b99da0-fc5a-11eb-9a91-0242ac110003-xomaJMly-EYTm8(4?5G7B token generate success token=MTYyODg3NTI4My42NDM1NTM6ZTFiOTlkYTAtZmM1YS0xMWViLTlhOTEtMDI0MmFjMTE
  01:21:26.083 [dbservice2] INFO e32e572a-fc5a-11eb-94df-0242ac110004-dXbvhYuV-XtK?-g9HF@^i token generate success token=MTYyODg3NTI4Ni4wODMxMjQ6ZTMyZTU3MmEtZmM1YS0xMWViLTk0ZGYtMDI0MmFjMTE
  01:21:28.468 [dbservice2] INFO e4a15ef4-fc5a-11eb-95dd-0242ac110003-KvxBQDHV-N^C_Y{W4r5#y token generate success token=MTYyODg3NTI4OC40Njc5NzAxOmU0YTE1ZWY0LWZjNWEtMTFlYi05NWRkLTAyNDJhYzE
  01:21:30.825 [dbservice2] INFO e605dbb2-fc5a-11eb-adad-0242ac110003-OzKQAVJF-y0PH2h:lM}5T token generate success token=MTYyODg3NTI5MC44MjQzNjY6ZTYwNWRiYjItZmM1YS0xMWViLWFkYWQtMDI0MmFjMTE
  01:21:33.705 [dbservice2] INFO e7b3e2c4-fc5a-11eb-9aa2-0242ac110004-oGQcxZEF-LmKxf4s2e(wW token generate success token=MTYyODg3NTI5My43MDUyMTE2OmU3YjNlMmM0LWZjNWEtMTFlYi05YWEyLTAyNDJhYzE
  01:21:36.274 [mobservice1] INFO info e96ca6e6-fc5a-11eb-931a-0242ac110003:JXejhiMl write success
  01:21:39.111 [dbservice1] INFO eafaa67a-fc5a-11eb-b47f-0242ac110003-JVwBQHua-/A_5xQRM{X.J token generate success token=MTYyODg3NTI5OS4xMTA3MTA2OmVhZmFhNjdhLWZjNWEtMTFlYi1iNDdmLTAyNDJhYzE
  01:21:41.666 [dbservice2] INFO ec78ee76-fc5a-11eb-9817-0242ac110004-laVNGIPf-{Z8wE?(U^nzJ token generate success token=MTYyODg3NTMwMS42NjY0MTE2OmVjNzhlZTc2LWZjNWEtMTFlYi05ODE3LTAyNDJhYzE
  01:21:44.814 [mobservice1] INFO info ee7cce9a-fc5a-11eb-8b9e-0242ac110003:NdFpoUqE write success
  01:21:47.333 [mobservice2] INFO info f012bd46-fc5a-11eb-b680-0242ac110004:HaBrICUJ write success
  01:21:50.311 [dbservice2] INFO f1a6e92a-fc5a-11eb-8332-0242ac110003-vaHXLtfK-J{}mY-&CAUgk token generate success token=MTYyODg3NTMxMC4zMTEwODEyOmYxYTZlOTJhLWZjNWEtMTFlYi04MzMyLTAyNDJhYzE
  01:21:52.671 [dbservice2] INFO f30e6662-fc5a-11eb-a192-0242ac110004-bJsneyVk-I0LUye#3x)Wa token generate success token=MTYyODg3NTMxMi42NzA4NTc6ZjMwZTY2NjItZmM1YS0xMWViLWExOTItMDI0MmFjMTE

## p0804
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-mongo, 2024-12-08T09:03:09.357Z
```
{"timestamp":1733648589357128000,"container_name":"ts-order-mongo","pod_name":"ts-order-mongo-97f4c55d4-vgkfg","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"{\"t\":{\"$date\":\"2024-12-08T09:03:09.356+00:00\"},\"s\":\"I\",  \"c\":\"STORAGE\",  \"id\":22430,   \"ctx\":\"Checkpointer\",\"msg\":\"WiredTiger message\",\"attr\":{\"message\":\"[1733648589:356885][1:0x7f6f97952700], WT_SESSION.checkpoint: [WT_VERB_CHECKPOINT_PROGRESS] saving checkpoint snapshot min: 540, snapshot max: 540 snapshot count: 0, oldest timestamp: (0, 0) , meta checkpoint timestamp: (0, 0) base write gen: 1\"}…"}
```
Same service, the 2 minutes before (oldest first):
  09:02:02.310 [ts-order-mongo] {"t":{"$date":"2024-12-08T09:02:02.310+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:4565
  09:02:02.313 [ts-order-mongo] {"t":{"$date":"2024-12-08T09:02:02.313+00:00"},"s":"I", "c":"NETWORK", "id":51800, "ctx":"conn16","msg":"client metadata","attr":{"remote":"127.0.0.6:45655","cl
  09:02:09.346 [ts-order-mongo] {"t":{"$date":"2024-12-08T09:02:09.346+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364852
All services, 30 seconds either side (sampled):
  09:02:39.394 [ts-auth-service] 2024-12-08 09:02:39.393 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×24)
  09:02:39.495 [ts-basic-service] 2024-12-08 09:02:39.495 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×14)
  09:02:39.553 [ts-basic-service] 2024-12-08 09:02:39.553 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×11)
  09:02:39.659 [ts-seat-service] 2024-12-08 09:02:39.658 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×43)
  09:02:39.778 [ts-seat-service] 2024-12-08 09:02:39.777 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×41)
  09:02:41.150 [ts-admin-basic-info-service] 2024-12-08 09:02:41.150 INFO 1 --- [io-18767-exec-3] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×11)
  09:02:41.824 [ts-order-other-service] 2024-12-08 09:02:41.824 INFO 1 --- [io-12032-exec-2] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=208356  (×15)
  09:02:42.150 [ts-travel-service] 2024-12-08 09:02:42.150 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×16)
  09:02:42.229 [ts-basic-service] 2024-12-08 09:02:42.229 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×5)
  09:02:42.343 [ts-travel-service] 2024-12-08 09:02:42.343 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d  (×8)
  09:02:42.524 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:02:42 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 339 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×5)
  09:02:47.249 [ts-seat-service] 2024-12-08 09:02:47.249 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×2)
  09:02:49.962 [ts-basic-service] 2024-12-08 09:02:49.962 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×5)
  09:02:50.027 [ts-basic-service] 2024-12-08 09:02:50.027 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : route.getDistances().size : 2  (×4)
  09:03:05.770 [ts-auth-service] 2024-12-08 09:03:05.770 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  09:03:06.715 [ts-travel-service] 2024-12-08 09:03:06.715 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
  09:03:07.457 [ts-food-map-service] 2024-12-08 09:03:07.456 INFO 1 --- [o-18855-exec-10] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]
  09:03:10.094 [ts-travel-mongo] {"t":{"$date":"2024-12-08T09:03:10.093+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364859
  09:03:12.077 [ts-payment-mongo] {"t":{"$date":"2024-12-08T09:03:12.077+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364859
  09:03:13.897 [ts-basic-service] 2024-12-08 09:03:13.897 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×3)
  09:03:22.067 [ts-consign-service] 2024-12-08 09:03:22.067 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] a85e07e8-eb68-4d19-b0d3-
  09:03:23.217 [ts-basic-service] 2024-12-08 09:03:23.216 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270  (×3)
  09:03:24.041 [ts-basic-service] 2024-12-08 09:03:24.041 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：084837bb-53
  09:03:36.864 [ts-contacts-service] 2024-12-08 09:03:36.863 INFO 1 --- [io-12347-exec-9] contacts.service.ContactsServiceImpl : [Contacts-Query-Service][Query-Contacts] Result Size: 2
  09:03:36.908 [ts-security-service] 2024-12-08 09:03:36.908 INFO 1 --- [io-11188-exec-3] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Last One Hour: 18 To
  09:03:36.972 [ts-preserve-service] 2024-12-08 09:03:36.972 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Getting....
  09:03:37.416 [ts-preserve-service] 2024-12-08 09:03:37.416 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : TripAllDetail:TripAllDetail(status=false, message=null, tripResponse
  09:03:37.579 [ts-seat-service] 2024-12-08 09:03:37.579 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService distributeSeat 1] The result of getTrainTypeResult is Response(
  09:03:37.599 [ts-order-service] 2024-12-08 09:03:37.599 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 22.5
  09:03:37.651 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:03:37 +0800] "POST /api/v1/preserveservice/preserve HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWeb

## p0378
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:42:16.828Z
```
{"timestamp":1732246936828595700,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:42:16.828375094Z caller=middlewares.go:75 method=GetUsers id=673ffd85b0df5c00019b2e51 result=1 took=1.208062ms"}
```
Same service, the 2 minutes before (oldest first):
  03:42:13.434 [user] ts=2024-11-22T03:42:13.434425721Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffd8db0df5c00019b2e69 took=1.418805ms  (×2)
  03:42:14.452 [user] ts=2024-11-22T03:42:14.452302566Z caller=middlewares.go:75 method=GetUsers id=673ffd83b0df5c00019b2e4e result=1 took=936.443µs  (×7)
  03:42:14.467 [user] ts=2024-11-22T03:42:14.467732826Z caller=middlewares.go:134 method=GetCards id=673ffd8ab0df5c00019b2e62 result=1 took=903.176µs
  03:42:14.467 [user] ts=2024-11-22T03:42:14.467735238Z caller=middlewares.go:104 method=GetAddresses id=673ffd8ab0df5c00019b2e61 result=1 took=906.41µs
  03:42:15.093 [user] ts=2024-11-22T03:42:15.093693783Z caller=middlewares.go:157 method=Health result=2 took=828.271µs  (×2)
  03:42:15.176 [user] ts=2024-11-22T03:42:15.175775559Z caller=middlewares.go:46 method=Register username=TjaDE email=TjaDE@gmail.com took=1.04253ms
  03:42:15.303 [user] ts=2024-11-22T03:42:15.303040358Z caller=middlewares.go:46 method=Register username=YrXpJfMg email=YrXpJfMg@gmail.com took=1.088524ms
  03:42:15.776 [user] ts=2024-11-22T03:42:15.776572761Z caller=middlewares.go:46 method=Register username=qMpkYeUHCTtBm email=qMpkYeUHCTtBm@gmail.com took=1.052132ms
  03:42:15.994 [user] ts=2024-11-22T03:42:15.994430125Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffd8db0df5c00019b2e6b took=1.584029ms
  03:42:16.028 [user] ts=2024-11-22T03:42:16.028712159Z caller=middlewares.go:46 method=Register username=mJItTkjoJQArNj email=mJItTkjoJQArNj@gmail.com took=841.321µs
  03:42:16.258 [user] ts=2024-11-22T03:42:16.258134201Z caller=middlewares.go:46 method=Register username=sMZMsF email=sMZMsF@gmail.com took=964.277µs
  03:42:16.271 [user] ts=2024-11-22T03:42:16.271646951Z caller=middlewares.go:46 method=Register username=eXAIll email=eXAIll@gmail.com took=1.056395ms
All services, 30 seconds either side (sampled):
  03:41:46.835 [front-end] Carts merged.  (×59)
  03:41:46.897 [carts] 2024-11-22 03:41:46.896 INFO [carts,f6850ce5cbad5c4f,f1bd103eb8baf083,false] 7 --- [-nio-80-exec-10] w.w.s.cart.controllers.ItemsController : Did not find item.  (×26)
  03:41:47.295 [carts] 2024-11-22 03:41:47.294 INFO [carts,ba7f851854524692,45f0d9ca83f0d4a0,false] 7 --- [p-nio-80-exec-9] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×32)
  03:41:48.259 [front-end] Received response: "{\"firstName\":\"qzJKcVkHxGm\",\"lastName\":\"qzJKcVkHxGm\",\"username\":\"qzJKcVkHxGm\",\"id\":\"673ffd6cb0df5c00019b2e04\",\"_links\":{\"a
  03:41:48.293 [queue-master] Received shipment task: 673ffd6cb0df5c00019b2e04  (×52)
  03:41:49.352 [catalogue] ts=2024-11-22T03:41:49Z caller=logging.go:85 method=Health result=2 took=25.753µs  (×40)
  03:41:50.853 [orders] 2024-11-22 03:41:50.853 INFO [orders,6b2abae19ee8dd4c,b90f68fd29aaf26d,false] 6 --- [-nio-80-exec-15] w.w.s.o.controllers.OrdersController : Received payment re  (×26)
  03:41:52.197 [front-end] Received response: "{\"firstName\":\"cweIZu\",\"lastName\":\"cweIZu\",\"username\":\"cweIZu\",\"id\":\"673ffd6fb0df5c00019b2e16\",\"_links\":{\"addresses\":{\"h
  03:41:54.365 [front-end] Order response: {"id":"673ffd82d94b9000069b476e","customerId":"673ffd73b0df5c00019b2e22","customer":{"id":null,"firstName":"mHIUg","lastName":"mHIUg","username"
  03:41:55.827 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd83d94b9000069b4771","customerId":"673ffd6bb0df5c00019b2e03","customer":{"id":null,"firstName":"GaGiGUSlD",
  03:41:57.534 [front-end] Posting Customer: {"username":"SxxBDLhnOQ","password":"OUrNxvh","email":"SxxBDLhnOQ@gmail.com","firstName":"SxxBDLhnOQ","lastName":"SxxBDLhnOQ"}
  03:41:59.977 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd87d94b9000069b4776","customerId":"673ffd75b0df5c00019b2e2a","customer":{"id":null,"firstName":"eaJDAwyNVdL
  03:42:01.623 [front-end] Posting Customer: {"username":"lEHqSY","password":"vLKUySa","email":"lEHqSY@gmail.com","firstName":"lEHqSY","lastName":"lEHqSY"}
  03:42:04.361 [front-end] Order response: {"id":"673ffd8cd94b9000069b477a","customerId":"673ffd70b0df5c00019b2e18","customer":{"id":null,"firstName":"CBuNNCTjyMkpEJ","lastName":"CBuNNCTj
  03:42:08.984 [user] ts=2024-11-22T03:42:08.984639571Z caller=middlewares.go:46 method=Register username=oPTLuFy email=oPTLuFy@gmail.com took=1.067137ms
  03:42:11.945 [user] ts=2024-11-22T03:42:11.944994687Z caller=middlewares.go:46 method=Register username=FACmTZ email=FACmTZ@gmail.com took=962.772µs
  03:42:13.376 [front-end] Order response: {"id":"673ffd95d94b9000069b4780","customerId":"673ffd7eb0df5c00019b2e4b","customer":{"id":null,"firstName":"xhvtH","lastName":"xhvtH","username"
  03:42:16.268 [front-end] Posting Customer: {"username":"eXAIll","password":"iEPhEMUD","email":"eXAIll@gmail.com","firstName":"eXAIll","lastName":"eXAIll"}
  03:42:20.478 [front-end] Posting Customer: {"username":"RwgQQoDwno","password":"SeXkuhz","email":"RwgQQoDwno@gmail.com","firstName":"RwgQQoDwno","lastName":"RwgQQoDwno"}
  03:42:21.663 [front-end] Order response: {"id":"673ffd9dd94b9000069b4786","customerId":"673ffd8ab0df5c00019b2e63","customer":{"id":null,"firstName":"TnuECCeKX","lastName":"TnuECCeKX","u
  03:42:25.193 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffda1d94b9000069b4788","customerId":"673ffd8db0df5c00019b2e6b","customer":{"id":null,"firstName":"nqEIXwdzikK
  03:42:26.617 [front-end] Received response: "{\"firstName\":\"BGlytgwsK\",\"lastName\":\"BGlytgwsK\",\"username\":\"BGlytgwsK\",\"id\":\"673ffd92b0df5c00019b2e76\",\"_links\":{\"address
  03:42:29.153 [carts-db] {"t":{"$date":"2024-11-22T03:42:29.152+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224694
  03:42:31.528 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffda7d94b9000069b478f","customerId":"673ffd93b0df5c00019b2e7b","customer":{"id":null,"firstName":"rxpiYCqYJg"
  03:42:34.535 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdaad94b9000069b4792","customerId":"673ffd97b0df5c00019b2e85","customer":{"id":null,"firstName":"YrXpJfMg","
  03:42:37.722 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdadd94b9000069b4795","customerId":"673ffd9cb0df5c00019b2e9d","customer":{"id":null,"firstName":"RwgQQoDwno"
  03:42:40.363 [front-end] Posting Customer: {"username":"VsNvz","password":"LVwamw","email":"VsNvz@gmail.com","firstName":"VsNvz","lastName":"VsNvz"}
  03:42:43.245 [user] ts=2024-11-22T03:42:43.244996597Z caller=middlewares.go:46 method=Register username=IeCIwwdF email=IeCIwwdF@gmail.com took=1.038578ms

## p0444
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T08:06:05.306Z
```
{"timestamp":1732349165306157600,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:05.306  INFO [carts,,,] 7 --- [           main] o.s.w.s.handler.SimpleUrlHandlerMapping  : Mapped URL path [/actuator/] onto handler of type [class org.springframework.web.servlet.resource.ResourceHttpRequestHandler]"}
```
Same service, the 2 minutes before (oldest first):
  08:05:30.210 [carts] 2024-11-23 08:05:30.209 INFO [carts,,,] 7 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[carts-db:27017], mode=SINGLE, requiredC
  08:05:31.799 [carts] 2024-11-23 08:05:31.799 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:1}] to
  08:05:31.806 [carts] 2024-11-23 08:05:31.806 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  08:05:45.411 [carts] 2024-11-23 08:05:45.411 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  08:06:00.413 [carts] 2024-11-23 08:06:00.413 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  08:06:00.500 [carts] 2024-11-23 08:06:00.500 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[DE
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[GET],produces=
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}/merge],methods=[GET]}" onto publi
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[GET],produces=[applicat
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.spring
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  08:06:03.410 [carts] 2024-11-23 08:06:03.409 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  08:06:03.602 [carts] 2024-11-23 08:06:03.600 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.ac
  08:06:05.306 [carts] 2024-11-23 08:06:05.304 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.sp
  08:06:05.306 [carts] 2024-11-23 08:06:05.305 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springfram
  08:06:05.306 [carts] 2024-11-23 08:06:05.306 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/browser/**] onto handler of type [class org.sp
All services, 30 seconds either side (sampled):
  08:05:35.373 [front-end] Request received with body: {}  (×63)
  08:05:35.510 [front-end] set cookie67418ccfa437380001deec29  (×66)
  08:05:35.883 [front-end] Received response: "{\"firstName\":\"yxWEkBiarOEcFPl\",\"lastName\":\"yxWEkBiarOEcFPl\",\"username\":\"yxWEkBiarOEcFPl\",\"id\":\"67418cb6a437380001deebd8\",\"_
  08:05:37.554 [front-end] Posting Customer: {"username":"QTNxlk","password":"qwbekCU","email":"QTNxlk@gmail.com","firstName":"QTNxlk","lastName":"QTNxlk"}
  08:05:39.188 [orders] 2024-11-23 08:05:39.188 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[OPTIONS],produces=[application
  08:05:39.196 [orders] 2024-11-23 08:05:39.196 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[OPTIONS],produces=[appl
  08:05:40.562 [front-end] Posting Customer: {"username":"eqACgmjO","password":"JpDGtXlzCs","email":"eqACgmjO@gmail.com","firstName":"eqACgmjO","lastName":"eqACgmjO"}
  08:05:41.194 [orders] 2024-11-23 08:05:41.193 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public ja
  08:05:44.588 [orders] 2024-11-23 08:05:44.587 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:05:46.357 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×8)
  08:05:49.486 [orders] 2024-11-23 08:05:49.394 ERROR [orders,,,] 8 --- [p-nio-80-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×39)
  08:05:51.461 [front-end] Posting Customer: {"username":"JfkloKMY","password":"BAlPTCaswY","email":"JfkloKMY@gmail.com","firstName":"JfkloKMY","lastName":"JfkloKMY"}
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/jso
  08:05:56.815 [front-end] Received response: "{\"firstName\":\"WoyOvB\",\"lastName\":\"WoyOvB\",\"username\":\"WoyOvB\",\"id\":\"67418ccfa437380001deec29\",\"_links\":{\"addresses\":{\"h
  08:05:59.718 [user] ts=2024-11-23T08:05:59.718194949Z caller=middlewares.go:46 method=Register username=RKNDdSk email=RKNDdSk@gmail.com took=3.379621ms
  08:06:02.425 [front-end] Posting Customer: {"username":"vZvbgNwwdo","password":"cAEgTMr","email":"vZvbgNwwdo@gmail.com","firstName":"vZvbgNwwdo","lastName":"vZvbgNwwdo"}
  08:06:06.916 [carts] 2024-11-23 08:06:06.915 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class or
  08:06:07.007 [shipping] 2024-11-23 08:06:07.007 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT
  08:06:07.614 [user] ts=2024-11-23T08:06:07.614423361Z caller=middlewares.go:46 method=Register username=ucodWkVEg email=ucodWkVEg@gmail.com took=3.000643ms
  08:06:13.834 [front-end] Received response: "{\"firstName\":\"bzxtLtBzUaRfo\",\"lastName\":\"bzxtLtBzUaRfo\",\"username\":\"bzxtLtBzUaRfo\",\"id\":\"67418ce5a437380001deec6f\",\"_links\
  08:06:15.701 [carts] 2024-11-23 08:06:15.701 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[application/hal+json || 
  08:06:15.809 [carts] 2024-11-23 08:06:15.809 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applicat
  08:06:16.439 [user] ts=2024-11-23T08:06:16.439397099Z caller=middlewares.go:46 method=Register username=GXUtAA email=GXUtAA@gmail.com took=2.399304ms
  08:06:19.009 [carts] 2024-11-23 08:06:19.009 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  08:06:21.669 [front-end] Posting Customer: {"username":"suxeYRw","password":"WiFMBG","email":"suxeYRw@gmail.com","firstName":"suxeYRw","lastName":"suxeYRw"}
  08:06:24.503 [carts] 2024-11-23 08:06:24.503 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as MB
  08:06:27.104 [carts] 2024-11-23 08:06:27.103 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:06:30.456 [front-end] Received response: "{\"firstName\":\"SPVlWNNsjeesK\",\"lastName\":\"SPVlWNNsjeesK\",\"username\":\"SPVlWNNsjeesK\",\"id\":\"67418cf2a437380001deec94\",\"_links\
  08:06:32.729 [orders] 2024-11-23 08:06:32.728 INFO [orders,fbcebf8ef5e82428,6d050ec4f8a03a61,false] 8 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Sending payment req  (×4)
  08:06:34.501 [shipping] Adding shipment to queue...  (×5)
