## p0432
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-23T08:05:44.588Z
```
{"timestamp":1732349144588097000,"container_name":"orders","pod_name":"orders-7fff6698cb-rlq5k","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-23 08:05:44.587  INFO [orders,,,] 8 --- [           main] o.s.j.e.a.AnnotationMBeanExporter        : Registering beans for JMX exposure on startup"}
```
Same service, the 2 minutes before (oldest first):
  08:05:39.388 [orders] 2024-11-23 08:05:39.388 INFO [orders,,,] 8 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframew
  08:05:41.185 [orders] 2024-11-23 08:05:41.185 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public 
  08:05:41.187 [orders] 2024-11-23 08:05:41.187 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application
  08:05:41.188 [orders] 2024-11-23 08:05:41.188 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public 
  08:05:41.188 [orders] 2024-11-23 08:05:41.188 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applicati
  08:05:41.189 [orders] 2024-11-23 08:05:41.189 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application
  08:05:41.189 [orders] 2024-11-23 08:05:41.189 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=
  08:05:41.190 [orders] 2024-11-23 08:05:41.190 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applicati
  08:05:41.190 [orders] 2024-11-23 08:05:41.190 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.
  08:05:41.190 [orders] 2024-11-23 08:05:41.190 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<j
  08:05:41.191 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java
  08:05:41.191 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto
  08:05:41.192 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]
  08:05:41.192 [orders] 2024-11-23 08:05:41.192 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json
  08:05:41.192 [orders] 2024-11-23 08:05:41.192 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/j
  08:05:41.193 [orders] 2024-11-23 08:05:41.193 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[app
  08:05:41.194 [orders] 2024-11-23 08:05:41.193 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public ja
  08:05:41.195 [orders] 2024-11-23 08:05:41.195 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[app
  08:05:41.198 [orders] 2024-11-23 08:05:41.198 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produce
  08:05:43.084 [orders] 2024-11-23 08:05:43.084 INFO [orders,,,] 8 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
All services, 30 seconds either side (sampled):
  08:05:16.044 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418cb4a437380001deebd3"}  (×60)
  08:05:16.923 [user] ts=2024-11-23T08:05:16.922581748Z caller=middlewares.go:75 method=GetUsers id=67418caaa437380001deebb5 result=1 took=2.939559ms  (×215)
  08:05:17.299 [front-end] Sent cookies.  (×61)
  08:05:18.714 [carts] 2024-11-23 08:05:18.712 INFO [carts,,,] 7 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  08:05:20.221 [queue-master] 2024-11-23 08:05:20.221 INFO 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  08:05:22.874 [front-end] Posting Customer: {"username":"kvjRZNQgiVnmkal","password":"VhVyZOrv","email":"kvjRZNQgiVnmkal@gmail.com","firstName":"kvjRZNQgiVnmkal","lastName":"kvjRZNQgiVnm
  08:05:26.499 [queue-master] 2024-11-23 08:05:26.499 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+json || applica
  08:05:26.609 [queue-master] 2024-11-23 08:05:26.609 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[GET],produces
  08:05:27.703 [queue-master] 2024-11-23 08:05:27.703 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]}" onto pub
  08:05:27.911 [carts] 2024-11-23 08:05:27.911 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'metricsServlet' to [/metrics]
  08:05:29.553 [user] ts=2024-11-23T08:05:29.553028599Z caller=middlewares.go:46 method=Register username=yYxwhLWv email=yYxwhLWv@gmail.com took=1.895508ms
  08:05:31.631 [carts-db] {"t":{"$date":"2024-11-23T08:05:31.631+00:00"},"s":"W", "c":"COMMAND", "id":5578800, "ctx":"conn1","msg":"Deprecated operation requested. The client driver may 
  08:05:32.893 [orders] 2024-11-23 08:05:32.892 INFO [orders,,,] 8 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionH  (×2)
  08:05:36.422 [user] ts=2024-11-23T08:05:36.422193492Z caller=middlewares.go:46 method=Register username=pSeQWyL email=pSeQWyL@gmail.com took=2.850057ms
  08:05:39.188 [orders] 2024-11-23 08:05:39.188 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/ha
  08:05:39.196 [orders] 2024-11-23 08:05:39.196 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applica
  08:05:41.187 [orders] 2024-11-23 08:05:41.187 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application
  08:05:41.706 [front-end] Posting Customer: {"username":"VGvhEBXruush","password":"TpFMwWsQ","email":"VGvhEBXruush@gmail.com","firstName":"VGvhEBXruush","lastName":"VGvhEBXruush"}
  08:05:44.691 [orders] 2024-11-23 08:05:44.690 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX serve
  08:05:47.988 [orders] 2024-11-23 08:05:47.988 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comple
  08:05:49.885 [orders] 2024-11-23 08:05:49.884 INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repos  (×24)
  08:05:54.265 [front-end] Posting Customer: {"username":"imiXj","password":"mbjOThU","email":"imiXj@gmail.com","firstName":"imiXj","lastName":"imiXj"}
  08:05:55.023 [front-end] Posting Customer: {"username":"brTpfrzj","password":"CqouP","email":"brTpfrzj@gmail.com","firstName":"brTpfrzj","lastName":"brTpfrzj"}
  08:05:58.911 [front-end] Received response: "{\"firstName\":\"eqACgmjO\",\"lastName\":\"eqACgmjO\",\"username\":\"eqACgmjO\",\"id\":\"67418cd4a437380001deec3c\",\"_links\":{\"addresses\
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  08:06:04.990 [front-end] Posting Customer: {"username":"VnaknAEtTvwY","password":"DQLtg","email":"VnaknAEtTvwY@gmail.com","firstName":"VnaknAEtTvwY","lastName":"VnaknAEtTvwY"}
  08:06:07.003 [shipping] 2024-11-23 08:06:07.003 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[applicat
  08:06:07.100 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],pro
  08:06:10.340 [front-end] Posting Customer: {"username":"djVRqry","password":"CJLHmVgJ","email":"djVRqry@gmail.com","firstName":"djVRqry","lastName":"djVRqry"}
  08:06:14.312 [shipping] 2024-11-23 08:06:14.312 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX e

## p0083
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-13T13:55:46.317Z
```
{"service":"mobservice2","message":"2021-08-13 13:55:46,317 | INFO | 0.0.0.4 | 172.17.0.2 | mobservice2 | 537af6e72b0e17f | info 1a26d6fe-fbfb-11eb-a02a-0242ac110004:tBueHCAS write success"}
```
Same service, the 2 minutes before (oldest first):
  13:55:41.897 [mobservice2] INFO info 1789447c-fbfb-11eb-b08f-0242ac110004:wRjEsaDr write success
  13:55:43.573 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  13:55:43.573 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  13:55:43.574 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '1897dd06-fbfb-11eb-827b-0242ac110004'}  (×4)
  13:55:43.663 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '1897dd06-fbfb-11eb-827b-0242ac110004', 'value': 'lAkaXYfP'}  (×4)
  13:55:43.706 [mobservice2] INFO info 1897dd06-fbfb-11eb-827b-0242ac110004:lAkaXYfP write success
  13:55:44.574 [mobservice2] INFO info 19260554-fbfb-11eb-a3ac-0242ac110003:etgkwBmP write success
  13:55:45.410 [mobservice2] INFO info 19a71784-fbfb-11eb-9484-0242ac110003:yaAVYWmq write success
All services, 30 seconds either side (sampled):
  13:55:16.326 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  13:55:16.548 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×52)
  13:55:16.706 [logservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×40)
  13:55:16.831 [logservice1] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '0884bfe2-fbfb-11eb-98c8-0242ac110004', 'user_id': 'GtreMfPE'}  (×88)
  13:55:17.138 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×42)
  13:55:17.577 [redisservice1] INFO redis读取信息成功, status_code: 200  (×38)
  13:55:18.387 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×48)
  13:55:19.234 [mobservice2] INFO info 0a066f78-fbfb-11eb-9af7-0242ac110004:APxbpyWu write success
  13:55:21.116 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '0b349d98-fbfb-11eb-b9be-0242ac110003', 'value': 'RVeouDMj'}  (×36)
  13:55:23.795 [dbservice2] INFO 0c7c6604-fbfb-11eb-9823-0242ac110003-CwasWDxu-d.&%?_4@g6BH token generate success token=MTYyODgzNDEyMy43OTQ3NTUyOjBjN2M2NjA0LWZiZmItMTFlYi05ODIzLTAyNDJhYzE
  13:55:26.707 [mobservice2] INFO info 0e852102-fbfb-11eb-9da9-0242ac110004:CuYtcsiR write success
  13:55:28.756 [dbservice1] INFO 0f7ba3d8-fbfb-11eb-a7cc-0242ac110003-lTYxuZoK-3UtL7AG$HnN5 token generate success token=MTYyODgzNDEyOC43NTYyODk1OjBmN2JhM2Q4LWZiZmItMTFlYi1hN2NjLTAyNDJhYzE
  13:55:32.185 [mobservice1] INFO info 11c419d6-fbfb-11eb-8330-0242ac110003:VLUjOpcK write success
  13:55:35.252 [mobservice1] INFO info 13919b4e-fbfb-11eb-9f21-0242ac110004:ZYabGCTS write success
  13:55:37.701 [mobservice1] INFO info 150f5b14-fbfb-11eb-9e5e-0242ac110004:ThPbGWEy write success
  13:55:40.244 [mobservice2] INFO info 1692bd0a-fbfb-11eb-b8e5-0242ac110003:TFaxVQiG write success
  13:55:42.749 [mobservice1] INFO info 180dbb30-fbfb-11eb-be9a-0242ac110004:TuOeLVZp write success
  13:55:45.410 [mobservice2] INFO info 19a71784-fbfb-11eb-9484-0242ac110003:yaAVYWmq write success
  13:55:50.196 [mobservice1] INFO info 1c862af8-fbfb-11eb-b853-0242ac110004:riyTUAVs write success
  13:55:53.188 [mobservice1] INFO info 1e487d6e-fbfb-11eb-b135-0242ac110003:ucXDZIio write success
  13:55:55.875 [mobservice1] INFO info 1fdcccb6-fbfb-11eb-acc3-0242ac110003:DomOhFAT write success
  13:55:58.582 [mobservice2] INFO info 217fa232-fbfb-11eb-814a-0242ac110003:eJuaFIik write success
  13:56:01.481 [mobservice2] INFO info 232adb4c-fbfb-11eb-9969-0242ac110003:GqOpyFdr write success
  13:56:04.698 [dbservice2] INFO 24f44706-fbfb-11eb-b81d-0242ac110003-BkNFnfui-D>HLZoW^2FX{ token generate success token=MTYyODgzNDE2NC42OTgxOTkzOjI0ZjQ0NzA2LWZiZmItMTFlYi1iODFkLTAyNDJhYzE
  13:56:07.827 [mobservice2] INFO info 27018cfc-fbfb-11eb-a643-0242ac110003:PtpxFCHR write success
  13:56:10.188 [mobservice2] INFO info 2867e384-fbfb-11eb-b6c6-0242ac110004:TURfmxwe write success
  13:56:12.555 [mobservice2] INFO info 29da706a-fbfb-11eb-b09d-0242ac110004:WvYxbhDu write success
  13:56:15.846 [mobservice2] INFO info 2bc9c4e8-fbfb-11eb-a5b1-0242ac110003:eJFaBQoW write success

## p0249
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:05.172Z
```
{"timestamp":1732242485172312800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"[ undefined, undefined ]"}
```
Same service, the 2 minutes before (oldest first):
  02:28:05.033 [front-end] GET Request to: http://user/customers/673fec1db0df5c00019af90f/cards  (×3)
  02:28:05.047 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×2)
  02:28:05.047 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec25b0df5c00019af930\",\"_links\":{\"  (×2)
  02:28:05.047 [front-end] [ undefined, undefined ]
  02:28:05.047 [front-end] Posting Order: {"customer":"http://user/customers/673fec1db0df5c00019af90f","address":"http://user/addresses/673fec25b0df5c00019af92f","card":"http://user/cards
  02:28:05.062 [front-end] User cart deleted with status: 503
  02:28:05.065 [front-end] DELETE /cart 503 - ms - -
  02:28:05.071 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  02:28:05.078 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af952/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  02:28:05.097 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:05.097 [front-end] Order response: {"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:05.100 [front-end] POST /orders 500 - ms - -
  02:28:05.146 [front-end] POST /cart 500 72.021 ms - 64
  02:28:05.160 [front-end] Request received with body: {}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×32)
  02:28:03.118 [catalogue] ts=2024-11-22T02:28:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.040202ms  (×36)
  02:28:03.190 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af953/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×18)
  02:28:03.211 [user] ts=2024-11-22T02:28:03.211690554Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=1.207621ms  (×36)
  02:28:03.252 [front-end] POST /orders 500 - ms - -  (×30)
  02:28:03.410 [front-end] Carts merged.  (×31)
  02:28:04.929 [front-end] Posting Customer: {"username":"JGQXvUjPbFrtK","password":"HtglbTyNG","email":"JGQXvUjPbFrtK@gmail.com","firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPbFrtK"}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:06.800 [user] ts=2024-11-22T02:28:06.800234478Z caller=middlewares.go:46 method=Register username=oyShDJ email=oyShDJ@gmail.com took=993.111µs
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.197 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×4)
  02:28:16.205 [front-end] Received response: "{\"firstName\":\"WiHheQzgSpJzgy\",\"lastName\":\"WiHheQzgSpJzgy\",\"username\":\"WiHheQzgSpJzgy\",\"id\":\"673fec2db0df5c00019af952\",\"_lin
  02:28:17.879 [user] ts=2024-11-22T02:28:17.879034554Z caller=middlewares.go:46 method=Register username=QGHrdp email=QGHrdp@gmail.com took=1.008054ms
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:21.971 [user] ts=2024-11-22T02:28:21.971606392Z caller=middlewares.go:46 method=Register username=PDQejFz email=PDQejFz@gmail.com took=1.195014ms
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=1.213µs  (×4)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.819 [front-end] Received response: "{\"firstName\":\"KoWsmDtUqsE\",\"lastName\":\"KoWsmDtUqsE\",\"username\":\"KoWsmDtUqsE\",\"id\":\"673fec2cb0df5c00019af949\",\"_links\":{\"a
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:25.786 [shipping] 2024-11-22 02:28:25.786 INFO [shipping,fb98be28dae5ea9a,b566bc7933720160,false] 7 --- [p-nio-80-exec-6] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.957 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","l
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFr
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:27.463 [orders-db] {"t":{"$date":"2024-11-22T02:28:27.462+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: java.lang.RuntimeException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock) at com.google.commo
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×12)

## p0728
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-14T18:55:41.503Z
```
{"service":"mobservice2","message":"2021-08-14 18:55:41,503 | INFO | 0.0.0.4 | 172.17.0.2 | mobservice2 | 58792c04c9550354 | request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '2a9ec566-fcee-11eb-8ca8-0242ac110004'}"}
```
Same service, the 2 minutes before (oldest first):
  18:55:37.765 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '2865765a-fcee-11eb-8963-0242ac110003'}  (×4)
  18:55:37.819 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '2865765a-fcee-11eb-8963-0242ac110003', 'value': 'NFrlOSIe'}  (×4)
  18:55:37.876 [mobservice2] INFO info 2865765a-fcee-11eb-8963-0242ac110003:NFrlOSIe write success
  18:55:38.889 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  18:55:38.890 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  18:55:39.080 [mobservice2] INFO info 290c2842-fcee-11eb-8b5c-0242ac110004:OKolGsUM write success
  18:55:39.917 [mobservice2] INFO info 299eff0a-fcee-11eb-ba22-0242ac110003:cUsPLdAz write success
  18:55:40.780 [mobservice2] INFO info 2a1ab7f8-fcee-11eb-8c36-0242ac110004:MxLzTnND write success
All services, 30 seconds either side (sampled):
  18:55:11.542 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  18:55:11.674 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×49)
  18:55:11.811 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×43)
  18:55:11.878 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×43)
  18:55:11.917 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×51)
  18:55:12.263 [webservice2] INFO uuid: 19515ab2-fcee-11eb-b77f-0242ac110004 write redis successfully  (×46)
  18:55:13.308 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×50)
  18:55:14.253 [mobservice1] INFO info 1a507114-fcee-11eb-9e18-0242ac110004:aZMCtwXA write success
  18:55:14.983 [dbservice1] INFO 1a7f144c-fcee-11eb-b430-0242ac110003-ToeLCkHR-(_n2MJ%R.Uw0 token generate success token=MTYyODkzODUxNC45ODMyMTEzOjFhN2YxNDRjLWZjZWUtMTFlYi1iNDMwLTAyNDJhYzE
  18:55:17.507 [mobservice2] INFO info 1c3f353c-fcee-11eb-93b7-0242ac110004:aLCdNFuD write success
  18:55:19.882 [mobservice2] INFO info 1da58e30-fcee-11eb-a0cd-0242ac110004:geuyhpUk write success
  18:55:22.715 [dbservice1] INFO 1f2b6a5e-fcee-11eb-afd9-0242ac110003-nlMAOLaH-.+x$_%GPZ*lV token generate success token=MTYyODkzODUyMi43MTUxOTc6MWYyYjZhNWUtZmNlZS0xMWViLWFmZDktMDI0MmFjMTE
  18:55:25.081 [dbservice2] INFO 2094ddee-fcee-11eb-9258-0242ac110004-lTYxuZoK-3UtL7AG$HnN5 token generate success token=MTYyODkzODUyNS4wODEzODY4OjIwOTRkZGVlLWZjZWUtMTFlYi05MjU4LTAyNDJhYzE
  18:55:28.411 [dbservice1] INFO 2282bbd0-fcee-11eb-80bc-0242ac110004-kWPHSeaC-nKV<}+zw:Zk% token generate success token=MTYyODkzODUyOC40MTA5MjE4OjIyODJiYmQwLWZjZWUtMTFlYi04MGJjLTAyNDJhYzE
  18:55:31.239 [dbservice1] INFO 24335566-fcee-11eb-a801-0242ac110004-rtRkpsfM-ul#Hy_*g:KTb token generate success token=MTYyODkzODUzMS4yMzkwODk1OjI0MzM1NTY2LWZjZWUtMTFlYi1hODAxLTAyNDJhYzE
  18:55:33.540 [dbservice2] INFO 25a79f60-fcee-11eb-b068-0242ac110004-etgkwBmP-D<TlS9enGxsY token generate success token=MTYyODkzODUzMy41Mzk4MjA0OjI1YTc5ZjYwLWZjZWUtMTFlYi1iMDY4LTAyNDJhYzE
  18:55:36.003 [dbservice1] INFO 2712172c-fcee-11eb-bde1-0242ac110003-cgKfeRjJ-?%FBPz^@kcZD token generate success token=MTYyODkzODUzNi4wMDI2MjM2OjI3MTIxNzJjLWZjZWUtMTFlYi1iZGUxLTAyNDJhYzE
  18:55:38.510 [dbservice1] INFO 28861c2a-fcee-11eb-8e30-0242ac110003-GLwvPubR-c9O=AoplwGk_ token generate success token=MTYyODkzODUzOC41MTA1MTY6Mjg4NjFjMmEtZmNlZS0xMWViLThlMzAtMDI0MmFjMTE  (×3)
  18:55:41.161 [dbservice1] INFO 2a1ab7f8-fcee-11eb-8c36-0242ac110004-MxLzTnND-Vr<g@j{uqoD> token generate success token=MTYyODkzODU0MS4xNjA3NDI4OjJhMWFiN2Y4LWZjZWUtMTFlYi04YzM2LTAyNDJhYzE
  18:55:43.872 [dbservice1] INFO 2bbbfa86-fcee-11eb-a93c-0242ac110004-dImbafKg-u#L?}jdp-2_5 token generate success token=MTYyODkzODU0My44NzI1NjgxOjJiYmJmYTg2LWZjZWUtMTFlYi1hOTNjLTAyNDJhYzE
  18:55:46.740 [mobservice2] INFO info 2da96e46-fcee-11eb-a9d2-0242ac110004:LEFinroh write success
  18:55:49.697 [dbservice1] INFO 2f2c535a-fcee-11eb-a292-0242ac110003-DGlMEFgf-hDX.AML@KH9e token generate success token=MTYyODkzODU0OS42OTY3MzgyOjJmMmM1MzVhLWZjZWUtMTFlYi1hMjkyLTAyNDJhYzE
  18:55:52.688 [mobservice2] INFO info 313b2b12-fcee-11eb-a489-0242ac110003:qhdLCnSU write success
  18:55:55.578 [dbservice1] INFO 32aea4c4-fcee-11eb-a361-0242ac110004-DhdfCMlE-06Cn#%rGUWLg token generate success token=MTYyODkzODU1NS41Nzc4MTE3OjMyYWVhNGM0LWZjZWUtMTFlYi1hMzYxLTAyNDJhYzE
  18:55:58.503 [mobservice1] INFO info 34a7e236-fcee-11eb-852a-0242ac110004:wkgeEpUD write success
  18:56:01.255 [dbservice1] INFO 36131f50-fcee-11eb-a2f7-0242ac110003-yjlLtMmx-<?.ZdYVR2js- token generate success token=MTYyODkzODU2MS4yNTU1NDIzOjM2MTMxZjUwLWZjZWUtMTFlYi1hMmY3LTAyNDJhYzE
  18:56:03.812 [dbservice2] INFO 3795bdb0-fcee-11eb-a69f-0242ac110004-NptDIkKG--%hyo201DjM@ token generate success token=MTYyODkzODU2My44MTIyMjQ5OjM3OTViZGIwLWZjZWUtMTFlYi1hNjlmLTAyNDJhYzE
  18:56:06.644 [mobservice1] INFO info 398ba9e0-fcee-11eb-9282-0242ac110003:ropVRsqh write success
  18:56:09.599 [mobservice1] INFO info 3b4aeaca-fcee-11eb-a7c5-0242ac110004:CzojFELq write success

## p0168
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T06:29:16.232Z
```
{"timestamp":1731911356232953300,"container_name":"adservice","pod_name":"adservice-b9bcc6cc9-sdkf5","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"received ad request (context_words=[clothing, tops])"}
```
Same service, the 2 minutes before (oldest first):
  06:29:09.543 [adservice] received ad request (context_words=[kitchen])  (×4)
  06:29:10.128 [adservice] received ad request (context_words=[hair, beauty])  (×4)
  06:29:11.602 [adservice] received ad request (context_words=[accessories])  (×7)
  06:29:11.734 [adservice] received ad request (context_words=[clothing, tops])  (×2)
  06:29:13.579 [adservice] received ad request (context_words=[])  (×3)
All services, 30 seconds either side (sampled):
  06:28:46.591 [frontend] request started  (×335)
  06:28:46.599 [cartservice] GetCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×271)
  06:28:46.624 [adservice] received ad request (context_words=[clothing, tops])  (×15)
  06:28:46.631 [cartservice] AddItemAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55, productId=66VCHSJNUP, quantity=1  (×42)
  06:28:46.662 [shippingservice] [GetQuote] completed request  (×82)
  06:28:48.306 [frontend] placing order  (×16)
  06:28:48.336 [paymentservice] Transaction processed: visa ending 6778 Amount: EUR1314.214949145  (×2)
  06:28:48.339 [shippingservice] [ShipOrder] completed request  (×16)
  06:28:48.350 [checkoutservice] order confirmation email sent to "fmitchell@example.net"
  06:28:48.495 [frontend] ENV_PLATFORM is: aws  (×28)
  06:28:49.139 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"1109","nanos":868237078},"credit_card":{"credit_card_number":"4811428181958  (×6)
  06:28:49.153 [emailservice] A request to send order confirmation email to smithjames@example.com has been received.
  06:28:49.256 [paymentservice] Transaction processed: visa ending 4923 Amount: GBP665.250384779  (×2)
  06:28:49.684 [frontend] setting currency  (×22)
  06:28:51.016 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', 'LS4PSXUNUM', '66VCHSJNUP', '1YMWWN1N4O']  (×2)
  06:28:51.735 [paymentservice] Transaction processed: visa ending 2966 Amount: CAD63.455971691  (×2)
  06:28:52.113 [adservice] received ad request (context_words=[decor, home])  (×18)
  06:28:56.327 [paymentservice] Transaction processed: visa ending 8078 Amount: USD371.200000000
  06:28:56.468 [checkoutservice] [PlaceOrder] user_id="b63bea0e-d05f-4589-be71-8fef43557432" user_currency="JPY"  (×3)
  06:28:56.506 [emailservice] A request to send order confirmation email to pittmanbriana@example.com has been received.
  06:29:03.581 [checkoutservice] order confirmation email sent to "littledebra@example.com"
  06:29:14.775 [checkoutservice] order confirmation email sent to "yboone@example.org"
  06:29:23.324 [emailservice] A request to send order confirmation email to ijenkins@example.net has been received.
  06:29:24.424 [checkoutservice] order confirmation email sent to "schmidtmark@example.com"
  06:29:30.167 [emailservice] A request to send order confirmation email to waremegan@example.com has been received.
  06:29:30.820 [checkoutservice] order confirmation email sent to "amyrogers@example.net"
  06:29:43.435 [emailservice] A request to send order confirmation email to ibarrett@example.com has been received.

## p0558
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T18:27:02.100Z
```
{"timestamp":1733596022100928000,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-ndkkb","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 18:27:02.100  INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl             : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Response(status=1, msg=Success, data=TrainType(id=GaoTieOne, economyClass=2147483647, confortClass=2147483647, averageSpeed=250))"}
```
Same service, the 2 minutes before (oldest first):
  18:27:01.655 [ts-seat-service] 2024-12-07 18:27:01.655 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  18:27:01.667 [ts-seat-service] 2024-12-07 18:27:01.666 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  18:27:01.716 [ts-seat-service] 2024-12-07 18:27:01.716 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×3)
  18:27:01.716 [ts-seat-service] 2024-12-07 18:27:01.716 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×3)
  18:27:01.732 [ts-seat-service] 2024-12-07 18:27:01.732 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×3)
  18:27:01.742 [ts-seat-service] 2024-12-07 18:27:01.742 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×3)
  18:27:01.767 [ts-seat-service] 2024-12-07 18:27:01.767 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×2)
  18:27:01.767 [ts-seat-service] 2024-12-07 18:27:01.767 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
All services, 30 seconds either side (sampled):
  18:26:32.387 [ts-admin-basic-info-service] 2024-12-07 18:26:32.387 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  18:26:33.122 [ts-travel2-service] 2024-12-07 18:26:33.121 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×129)
  18:26:33.177 [ts-basic-service] 2024-12-07 18:26:33.177 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×17)
  18:26:33.277 [ts-seat-service] 2024-12-07 18:26:33.277 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×24)
  18:26:33.397 [ts-seat-service] 2024-12-07 18:26:33.396 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×17)
  18:26:35.519 [ts-travel-service] 2024-12-07 18:26:35.519 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×39)
  18:26:37.730 [ts-basic-service] 2024-12-07 18:26:37.729 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×7)
  18:26:37.877 [ts-order-other-service] 2024-12-07 18:26:37.877 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×2)
  18:26:43.822 [ts-travel2-service] 2024-12-07 18:26:43.822 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×17)
  18:26:49.178 [ts-travel-service] 2024-12-07 18:26:49.178 INFO 1 --- [io-12346-exec-5] travel.controller.TravelController : [Travel Service] Query TripResponse  (×3)
  18:26:49.324 [ts-travel-service] 2024-12-07 18:26:49.324 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×7)
  18:26:49.555 [ts-assurance-service] 2024-12-07 18:26:49.555 INFO 1 --- [o-18888-exec-10] a.controller.AssuranceController : [Assurances Service][Get Assurance Type]
  18:26:49.599 [ts-security-service] 2024-12-07 18:26:49.598 INFO 1 --- [io-11188-exec-8] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....  (×2)
  18:26:49.656 [ts-preserve-service] 2024-12-07 18:26:49.656 INFO 1 --- [o-14568-exec-10] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Getting....
  18:26:49.827 [ts-travel-service] 2024-12-07 18:26:49.827 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  18:26:50.052 [ts-basic-service] 2024-12-07 18:26:50.052 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×2)
  18:26:50.133 [ts-order-service] 2024-12-07 18:26:50.133 INFO 1 --- [io-12031-exec-9] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at 
  18:26:50.165 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:26:50 +0800] "POST /api/v1/preserveservice/preserve HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWeb  (×2)
  18:26:58.722 [ts-travel-service] 2024-12-07 18:26:58.722 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×9)
  18:27:01.636 [ts-order-service] 2024-12-07 18:27:01.635 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : Left ticket info is empty  (×5)
  18:27:02.340 [ts-seat-service] 2024-12-07 18:27:02.340 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da
  18:27:18.724 [ts-contacts-service] 2024-12-07 18:27:18.724 INFO 1 --- [o-12347-exec-10] contacts.service.ContactsServiceImpl : [Contacts-Query-Service][Query-Contacts] Result Size: 2
  18:27:18.793 [ts-preserve-service] 2024-12-07 18:27:18.793 INFO 1 --- [io-14568-exec-5] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting...
  18:27:19.269 [ts-order-service] 2024-12-07 18:27:19.269 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Verify Login] Success
  18:27:19.300 [ts-preserve-service] 2024-12-07 18:27:19.300 INFO 1 --- [io-14568-exec-5] preserve.service.PreserveServiceImpl : [Preserve Service][Step 7] Do not need to consign
  18:27:29.487 [ts-seat-service] 2024-12-07 18:27:29.486 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat
  18:27:30.438 [ts-order-other-service] 2024-12-07 18:27:30.438 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Stations name list is : Response(status=1, msg=Success, data=[Shang H
  18:27:30.579 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-07T18:27:30.579+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359605
  18:27:31.701 [ts-order-service] 2024-12-07 18:27:31.701 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Other Service][Get Order By Id] Order Id: e396f188-4000-46aa-b7cb

## p0323
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:21:02.417Z
```
{"timestamp":1732245662417583000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"[ undefined, undefined ]"}
```
Same service, the 2 minutes before (oldest first):
  03:21:02.165 [front-end] Carts merged.
  03:21:02.165 [front-end] set cookie673ff89eb0df5c00019b1f54
  03:21:02.166 [front-end] Sent cookies.
  03:21:02.168 [front-end] POST /register 200 46.470 ms - 33
  03:21:02.270 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff896b0df5c00019b1f37"}
  03:21:02.279 [front-end] POST /addresses 200 - ms - -
  03:21:02.283 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff896b0df5c00019b1f37"}
  03:21:02.291 [front-end] POST /cards 200 - ms - -
  03:21:02.338 [front-end] Attempting to delete cart for user: 673ff896b0df5c00019b1f37
  03:21:02.366 [front-end] User cart deleted with status: 503
  03:21:02.368 [front-end] DELETE /cart 503 - ms - -
  03:21:02.375 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  03:21:02.383 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  03:21:02.383 [front-end] POST to carts: http://carts/carts/673ff896b0df5c00019b1f37/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  03:21:02.403 [front-end] Request received with body: {}
  03:21:02.411 [front-end] Received response: "{\"firstName\":\"HWsmCvxoMrNqX\",\"lastName\":\"HWsmCvxoMrNqX\",\"username\":\"HWsmCvxoMrNqX\",\"id\":\"673ff884b0df5c00019b1f0d\",\"_links\
  03:21:02.411 [front-end] GET Request to: http://user/customers/673ff884b0df5c00019b1f0d/addresses  (×2)
  03:21:02.417 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff88eb0df5c00019b1f22\",\"_links\":{\"
  03:21:02.417 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
All services, 30 seconds either side (sampled):
  03:20:32.428 [catalogue] ts=2024-11-22T03:20:32Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=3.433368ms  (×61)
  03:20:32.747 [front-end] Request received with body: {}  (×59)
  03:20:32.807 [front-end] Order response: {"timestamp":1732245632804,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×38)
  03:20:33.935 [user] ts=2024-11-22T03:20:33.935694632Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff87bb0df5c00019b1efc took=1.962293ms  (×59)
  03:20:34.536 [front-end] Received response: "{\"firstName\":\"burOTnWrVFcFcR\",\"lastName\":\"burOTnWrVFcFcR\",\"username\":\"burOTnWrVFcFcR\",\"id\":\"673ff86eb0df5c00019b1ed0\",\"_lin
  03:20:37.986 [front-end] Posting Customer: {"username":"WwpBLC","password":"ngXKNthnRa","email":"WwpBLC@gmail.com","firstName":"WwpBLC","lastName":"WwpBLC"}
  03:20:41.044 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×5)
  03:20:43.389 [carts] 2024-11-22 03:20:43.389 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
  03:20:48.998 [front-end] Posting Customer: {"username":"asYAoymkBkzj","password":"aSSKLjGTT","email":"asYAoymkBkzj@gmail.com","firstName":"asYAoymkBkzj","lastName":"asYAoymkBkzj"}
  03:20:51.541 [front-end] Received response: "{\"firstName\":\"MKGIsEbVYi\",\"lastName\":\"MKGIsEbVYi\",\"username\":\"MKGIsEbVYi\",\"id\":\"673ff87eb0df5c00019b1eff\",\"_links\":{\"addr
  03:20:56.307 [front-end] Posting Customer: {"username":"TxflHMpaWteY","password":"HuykDEusv","email":"TxflHMpaWteY@gmail.com","firstName":"TxflHMpaWteY","lastName":"TxflHMpaWteY"}
  03:20:59.685 [carts] 2024-11-22 03:20:59.685 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+json
  03:20:59.785 [carts] 2024-11-22 03:20:59.785 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[GET],produces=[  (×2)
  03:20:59.886 [carts] 2024-11-22 03:20:59.886 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http.
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applicatio
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public j
  03:21:05.450 [front-end] Received response: "{\"firstName\":\"dOIvn\",\"lastName\":\"dOIvn\",\"username\":\"dOIvn\",\"id\":\"673ff888b0df5c00019b1f18\",\"_links\":{\"addresses\":{\"href
  03:21:09.189 [carts] 2024-11-22 03:21:09.188 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server as  (×2)
  03:21:12.165 [front-end] Received response: "{\"firstName\":\"nLZjIlByeidrL\",\"lastName\":\"nLZjIlByeidrL\",\"username\":\"nLZjIlByeidrL\",\"id\":\"673ff898b0df5c00019b1f41\",\"_links\
  03:21:14.097 [user] ts=2024-11-22T03:21:14.097040605Z caller=middlewares.go:46 method=Register username=GaVMS email=GaVMS@gmail.com took=1.031461ms
  03:21:16.308 [front-end] Received response: "{\"firstName\":\"asYAoymkBkzj\",\"lastName\":\"asYAoymkBkzj\",\"username\":\"asYAoymkBkzj\",\"id\":\"673ff891b0df5c00019b1f2a\",\"_links\":{
  03:21:18.600 [payment] ts=2024-11-22T03:21:18Z caller=logging.go:29 method=Authorise result=true took=173ns  (×11)
  03:21:18.708 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8aed94b9000069b438d","customerId":"673ff891b0df5c00019b1f2a","customer":{"id":null,"firstName":"asYAoymkBkz
  03:21:19.317 [front-end] Order response: {"id":"673ff8afd94b9000069b4391","customerId":"673ff896b0df5c00019b1f3c","customer":{"id":null,"firstName":"cfTPDbfduekTBf","lastName":"cfTPDbfd
  03:21:20.103 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b0d94b9000069b4394","customerId":"673ff899b0df5c00019b1f44","customer":{"id":null,"firstName":"fnNnBGFeZwj
  03:21:20.805 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b0d94b9000069b4398","customerId":"673ff897b0df5c00019b1f3d","customer":{"id":null,"firstName":"PvCLeeg","l
  03:21:23.837 [front-end] Received response: "{\"firstName\":\"UFhesIA\",\"lastName\":\"UFhesIA\",\"username\":\"UFhesIA\",\"id\":\"673ff89eb0df5c00019b1f57\",\"_links\":{\"addresses\":{
  03:21:28.393 [payment] ts=2024-11-22T03:21:28Z caller=logging.go:29 method=Authorise result=false took=7.697µs

## p0660
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-11T08:00:26.502Z
```
{"service":"webservice1","message":"2021-08-11 08:00:26,502 | INFO | 0.0.0.1 | 172.17.0.3 | webservice1 | 74f99e9e2a2b1abf | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  08:00:17.539 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  08:00:17.540 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  08:00:17.540 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '1ca033d2-fa37-11eb-9c4c-0242ac110003', 'value': '', 'ex': 10}  (×4)
  08:00:17.615 [webservice1] INFO uuid: 1ca033d2-fa37-11eb-9c4c-0242ac110003 write redis successfully  (×4)
  08:00:17.717 [webservice1] ERROR get a error [Errno 2] No such file or directory: 'resources/source_file/source_file.csv'  (×4)
All services, 30 seconds either side (sampled):
  07:59:56.512 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×3)
  07:59:56.658 [redisservice2] INFO redis write success  (×101)
  07:59:56.761 [redisservice2] INFO redis读取信息成功, status_code: 200  (×38)
  07:59:56.813 [logservice2] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '0ffbf53a-fa37-11eb-aa2b-0242ac110003', 'user_id': 'lnbVdqst'}  (×64)
  07:59:57.057 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×63)
  07:59:57.232 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×62)
  07:59:57.690 [dbservice2] INFO query = select passwards from username_table where user_name='dlSUhBPw'  (×30)
  07:59:58.447 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '111a5470-fa37-11eb-8a73-0242ac110004'}  (×34)
  07:59:58.618 [dbservice1] INFO 10e45906-fa37-11eb-b33f-0242ac110004-VMivmOPL-_z$IfwVSs+#T token generate success token=MTYyODYzOTk5OC42MTgwMDA3OjEwZTQ1OTA2LWZhMzctMTFlYi1iMzNmLTAyNDJhYzE
  07:59:58.751 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×54)
  07:59:59.523 [dbservice1] INFO 116d4f9a-fa37-11eb-a857-0242ac110003-ZKnXGxAN-Z@S_<_>310Yl token generate success token=MTYyODYzOTk5OS41MjMwNDY1OjExNmQ0ZjlhLWZhMzctMTFlYi1hODU3LTAyNDJhYzE
  08:00:01.462 [webservice1] ERROR get a error [Errno 2] No such file or directory: 'resources/source_file/source_file.csv'  (×52)
  08:00:03.380 [dbservice2] ERROR password in database of {user} is null, the user is not registered  (×2)
  08:00:05.039 [mobservice2] INFO info 14f519e0-fa37-11eb-a55b-0242ac110004:gDFlmhUH write success
  08:00:07.519 [dbservice1] INFO 16253020-fa37-11eb-93ce-0242ac110004-VcbkjSAZ-H}z)MI_t986B token generate success token=MTYyODY0MDAwNy41MTg2ODU6MTYyNTMwMjAtZmEzNy0xMWViLTkzY2UtMDI0MmFjMTE
  08:00:09.599 [mobservice2] INFO info 17ac02fc-fa37-11eb-894b-0242ac110004:jEWmrMqA write success
  08:00:11.839 [mobservice2] INFO info 1903516e-fa37-11eb-bd1d-0242ac110004:IREbBVhM write success
  08:00:15.054 [mobservice1] INFO info 1af0191c-fa37-11eb-9f3e-0242ac110004:zShwUfFn write success
  08:00:18.117 [mobservice2] INFO info 1cc050ae-fa37-11eb-820f-0242ac110004:XlGeVCEy write success
  08:00:20.735 [dbservice1] INFO 1e163626-fa37-11eb-9277-0242ac110004-fVwtyQDn-m0:RzXgt4@vn token generate success token=MTYyODY0MDAyMC43MzUzODk1OjFlMTYzNjI2LWZhMzctMTFlYi05Mjc3LTAyNDJhYzE
  08:00:31.325 [mobservice1] INFO info 249087ea-fa37-11eb-9258-0242ac110004:wVcuUpbK write success
  08:00:33.973 [dbservice1] INFO 25ef105c-fa37-11eb-8939-0242ac110004-tjrRfeJy-t5EnZ!FmiUq{ token generate success token=MTYyODY0MDAzMy45NzMxNDcyOjI1ZWYxMDVjLWZhMzctMTFlYi04OTM5LTAyNDJhYzE
  08:00:36.796 [dbservice2] INFO 27a3e738-fa37-11eb-9eb1-0242ac110004-IKTgrkvl-puzDw*h+_H#V token generate success token=MTYyODY0MDAzNi43OTYxMjE0OjI3YTNlNzM4LWZhMzctMTFlYi05ZWIxLTAyNDJhYzE
  08:00:41.054 [mobservice1] INFO info 2a5ccfee-fa37-11eb-b992-0242ac110004:TmVsgowE write success
  08:00:43.826 [mobservice2] INFO info 2c17190c-fa37-11eb-9669-0242ac110004:JtGfaIFA write success
  08:00:46.217 [dbservice1] INFO 2d4db718-fa37-11eb-a50d-0242ac110004-LNTWaneB-a-uy{c?erAX@ token generate success token=MTYyODY0MDA0Ni4yMTcwMTIyOjJkNGRiNzE4LWZhMzctMTFlYi1hNTBkLTAyNDJhYzE
  08:00:49.020 [dbservice2] INFO 2efbef4e-fa37-11eb-a331-0242ac110004-hHIokWie-DyHUpusE)bOX token generate success token=MTYyODY0MDA0OS4wMjAzMjQ1OjJlZmJlZjRlLWZhMzctMTFlYi1hMzMxLTAyNDJhYzE
  08:00:51.368 [mobservice2] INFO info 30990594-fa37-11eb-a751-0242ac110004:QurEfLHx write success
  08:00:53.107 [mobservice1] INFO info 31a0123e-fa37-11eb-a63e-0242ac110004:LeQUvMXs write success

## p0127
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service paymentservice, 2024-11-18T05:18:26.959Z
```
{"service":"paymentservice","operation":"grpc.hipstershop.PaymentService/Charge","method":"Charge","status_code":400,"duration_us":485,"trace_id":"b52573f8a8599bd5184ec1ec9530d37f","message":"span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400"}
```
Same service, the 2 minutes before (oldest first):
  05:16:53.202 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"171700","nanos":507741406},"credit_card":{"credit_card_number":"44083849676  (×2)
  05:16:53.202 [paymentservice] Transaction processed: visa ending 5038 Amount: JPY171700.507741406  (×2)
  05:17:16.693 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"1792","nanos":226454698},"credit_card":{"credit_card_number":"4639203387545  (×4)
  05:17:16.693 [paymentservice] Transaction processed: visa ending 5701 Amount: TRY1792.226454698  (×4)
  05:17:24.111 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"346","nanos":438559926},"credit_card":{"credit_card_number":"46766376709217  (×2)
  05:17:24.111 [paymentservice] Transaction processed: visa ending 1703 Amount: CAD346.438559926  (×2)
  05:17:55.262 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"679","nanos":655019909},"credit_card":{"credit_card_number":"44974606316987
  05:17:55.262 [paymentservice] Transaction processed: visa ending 8741 Amount: EUR679.655019909
  05:18:22.550 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"1521","nanos":300176901},"credit_card":{"credit_card_number":"4909740041071
  05:18:22.550 [paymentservice] Transaction processed: visa ending 1783 Amount: GBP1521.300176901
All services, 30 seconds either side (sampled):
  05:17:58.058 [frontend] request started  (×292)
  05:17:58.067 [cartservice] GetCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×246)
  05:17:58.087 [frontend] failed to retrieve ads  (×178)
  05:17:58.090 [frontend] adding to cart  (×27)
  05:17:58.127 [shippingservice] [GetQuote] received request  (×68)
  05:17:58.812 [frontend] ENV_PLATFORM is: aws  (×34)
  05:18:02.258 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="TRY"  (×3)
  05:18:02.287 [checkoutservice] payment went through (transaction_id: f6b68b4a-60c3-43ba-a064-a6b85fb7ff1c)  (×7)
  05:18:02.293 [cartservice] EmptyCartAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4  (×7)
  05:18:02.299 [frontend] order placed  (×7)
  05:18:18.646 [adservice] AdService starting.  (×2)
  05:18:18.741 [adservice] Tracing enabled - Stackdriver exporter initialized.  (×2)
  05:18:20.440 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  05:18:22.550 [paymentservice] Transaction processed: visa ending 1783 Amount: GBP1521.300176901
  05:18:25.894 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '0PUK6V6EV0', '6E92ZMYYFZ', '1YMWWN1N4O']  (×6)
  05:18:25.981 [paymentservice] Transaction processed: visa ending 9193 Amount: JPY106183.826626688  (×3)
  05:18:26.910 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13  (×2)
  05:18:26.964 [frontend] request error
  05:18:32.581 [paymentservice] Transaction processed: visa ending 3587 Amount: EUR1094.975674484
  05:18:35.671 [emailservice] A request to send order confirmation email to daniel24@example.org has been received.
  05:18:45.411 [checkoutservice] order confirmation email sent to "fknox@example.org"

## p0289
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:36:14.255Z
```
{"timestamp":1732242974255418000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Attempting to delete cart for user: 673fee14b0df5c00019aff0d"}
```
Same service, the 2 minutes before (oldest first):
  02:36:13.402 [front-end] 673fee1db0df5c00019aff2d
  02:36:13.402 [front-end] Merging carts for customer id: 673fee1db0df5c00019aff2d and session id: 34fIOr676_X1rqCYThlfnu5LffPEAYD7
  02:36:13.406 [front-end] POST /addresses 200 - ms - -  (×2)
  02:36:13.414 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fee18b0df5c00019aff1e"}  (×2)
  02:36:13.421 [front-end] Carts merged.
  02:36:13.421 [front-end] set cookie673fee1db0df5c00019aff2d
  02:36:13.421 [front-end] Sent cookies.
  02:36:13.422 [front-end] POST /cards 200 - ms - -  (×2)
  02:36:13.424 [front-end] POST /register 200 25.508 ms - 33
  02:36:13.467 [front-end] Attempting to delete cart for user: 673fee18b0df5c00019aff1e
  02:36:13.484 [front-end] User cart deleted with status: 202
  02:36:13.486 [front-end] DELETE /cart 202 - ms - -
  02:36:13.492 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  02:36:13.501 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  02:36:13.501 [front-end] POST to carts: http://carts/carts/673fee18b0df5c00019aff1e/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  02:36:13.534 [front-end] POST /cart 201 - ms - -
  02:36:14.189 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fee14b0df5c00019aff0d"}
All services, 30 seconds either side (sampled):
  02:35:44.349 [catalogue] ts=2024-11-22T02:35:44Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.584131ms  (×62)
  02:35:44.740 [front-end] Request received with body: {}  (×58)
  02:35:44.774 [payment] ts=2024-11-22T02:35:44Z caller=logging.go:29 method=Authorise result=true took=714ns  (×27)
  02:35:44.912 [user] ts=2024-11-22T02:35:44.912412087Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673fedf6b0df5c00019afebf took=1.754415ms  (×62)
  02:35:45.036 [carts] 2024-11-22 02:35:45.036 INFO [carts,a9a540731e7c9a4d,b85842377de1d139,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.ItemsController : Did not find item.  (×33)
  02:35:46.067 [carts] 2024-11-22 02:35:46.067 INFO [carts,684bc9a51d47753e,72bc38f9d533111b,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.CartsController : Merge carts reques  (×29)
  02:35:47.743 [orders] 2024-11-22 02:35:47.743 INFO [orders,44e9e9b3afc38ab9,1f06bee7ad9a1b89,false] 6 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Sending payment req  (×34)
  02:35:48.541 [front-end] Order response: {"id":"673fee04d94b9000069b3b6e","customerId":"673fedefb0df5c00019afe9c","customer":{"id":null,"firstName":"dhOXoLuIAaIivor","lastName":"dhOXoLu
  02:35:51.799 [front-end] Order response: {"id":"673fee07d94b9000069b3b71","customerId":"673fedf5b0df5c00019afeb6","customer":{"id":null,"firstName":"YNulPioXUc","lastName":"YNulPioXUc",
  02:35:55.101 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee0bd94b9000069b3b73","customerId":"673fedf3b0df5c00019afeb4","customer":{"id":null,"firstName":"nxbqVBBGTlw
  02:35:57.150 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee0dd94b9000069b3b76","customerId":"673fedfdb0df5c00019afece","customer":{"id":null,"firstName":"XdvVyIB","l
  02:35:59.279 [front-end] Order response: {"id":"673fee0fd94b9000069b3b77","customerId":"673fedfab0df5c00019afec4","customer":{"id":null,"firstName":"tbBanYWlqACR","lastName":"tbBanYWlqA
  02:36:01.810 [front-end] Posting Customer: {"username":"dFPnn","password":"VSxaxKxKIy","email":"dFPnn@gmail.com","firstName":"dFPnn","lastName":"dFPnn"}
  02:36:02.622 [front-end] Posting Customer: {"username":"jHxHGx","password":"gHycEjueZ","email":"jHxHGx@gmail.com","firstName":"jHxHGx","lastName":"jHxHGx"}
  02:36:05.853 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee15d94b9000069b3b7e","customerId":"673fee06b0df5c00019afee5","customer":{"id":null,"firstName":"aTeoa","las
  02:36:08.127 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee18d94b9000069b3b82","customerId":"673fee08b0df5c00019afeeb","customer":{"id":null,"firstName":"dTjFLLTecLu
  02:36:09.941 [front-end] Received response: "{\"firstName\":\"VccPCkTYAKnIx\",\"lastName\":\"VccPCkTYAKnIx\",\"username\":\"VccPCkTYAKnIx\",\"id\":\"673fee02b0df5c00019afeda\",\"_links\
  02:36:12.860 [front-end] Order response: {"id":"673fee1cd94b9000069b3b87","customerId":"673fee0db0df5c00019afefc","customer":{"id":null,"firstName":"YrUAWHZ","lastName":"YrUAWHZ","usern
  02:36:18.301 [front-end] Posting Customer: {"username":"rRAAicI","password":"bESAaUwf","email":"rRAAicI@gmail.com","firstName":"rRAAicI","lastName":"rRAAicI"}
  02:36:20.298 [front-end] Posting Customer: {"username":"IJSMYJkEmzTpk","password":"lVXXPfCYF","email":"IJSMYJkEmzTpk@gmail.com","firstName":"IJSMYJkEmzTpk","lastName":"IJSMYJkEmzTpk"}
  02:36:21.790 [user] ts=2024-11-22T02:36:21.790586768Z caller=middlewares.go:46 method=Register username=cUeWQ email=cUeWQ@gmail.com took=976.437µs
  02:36:25.315 [front-end] Posting Customer: {"username":"DwAEkhQZhxpmE","password":"GHselL","email":"DwAEkhQZhxpmE@gmail.com","firstName":"DwAEkhQZhxpmE","lastName":"DwAEkhQZhxpmE"}
  02:36:26.360 [front-end] Received response: "{\"firstName\":\"eLBzfmmVmZZe\",\"lastName\":\"eLBzfmmVmZZe\",\"username\":\"eLBzfmmVmZZe\",\"id\":\"673fee1bb0df5c00019aff2b\",\"_links\":{
  02:36:29.555 [front-end] Received response: "{\"firstName\":\"pxdYQAxLO\",\"lastName\":\"pxdYQAxLO\",\"username\":\"pxdYQAxLO\",\"id\":\"673fee18b0df5c00019aff1e\",\"_links\":{\"address
  02:36:31.748 [user] ts=2024-11-22T02:36:31.748650678Z caller=middlewares.go:46 method=Register username=iRwGxvLwG email=iRwGxvLwG@gmail.com took=1.090337ms
  02:36:35.106 [front-end] Order response: {"id":"673fee33d94b9000069b3b98","customerId":"673fee1eb0df5c00019aff31","customer":{"id":null,"firstName":"NcGdzriiRpNv","lastName":"NcGdzriiRp
  02:36:36.534 [front-end] Posting Customer: {"username":"pUbZTskS","password":"ulEgyqoobc","email":"pUbZTskS@gmail.com","firstName":"pUbZTskS","lastName":"pUbZTskS"}
  02:36:39.524 [front-end] Posting Customer: {"username":"iNrWVKUay","password":"DrNpiFpQX","email":"iNrWVKUay@gmail.com","firstName":"iNrWVKUay","lastName":"iNrWVKUay"}
  02:36:41.646 [user] ts=2024-11-22T02:36:41.645809533Z caller=middlewares.go:46 method=Register username=pILGhB email=pILGhB@gmail.com took=936.852µs

## p0239
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T08:02:12.454Z
```
{"timestamp":1731916932454729000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  08:02:11.842 [frontend] request complete  (×7)
  08:02:11.848 [frontend] request started  (×6)
  08:02:11.848 [frontend] serving product page  (×4)
  08:02:12.196 [frontend] home
  08:02:12.244 [frontend] ENV_PLATFORM is: aws
  08:02:12.442 [frontend] adding to cart
All services, 30 seconds either side (sampled):
  08:01:42.722 [frontend] request started  (×330)
  08:01:42.731 [cartservice] GetCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×272)
  08:01:42.753 [adservice] received ad request (context_words=[accessories])  (×33)
  08:01:42.933 [frontend] adding to cart  (×40)
  08:01:42.970 [shippingservice] [GetQuote] received request  (×87)
  08:01:42.997 [frontend] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
  08:01:43.032 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"52370","nanos":186643605},"credit_card":{"credit_card_number":"450880959968  (×2)
  08:01:43.033 [paymentservice] }
  08:01:43.773 [adservice] received ad request (context_words=[footwear])  (×18)
  08:01:45.915 [adservice] received ad request (context_words=[hair, beauty])  (×20)
  08:01:46.652 [frontend] ENV_PLATFORM is: aws  (×29)
  08:01:47.549 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"475","nanos":630252110},"credit_card":{"credit_card_number":"48303888182210  (×3)
  08:01:47.552 [shippingservice] [ShipOrder] received request  (×8)
  08:01:47.562 [emailservice] A request to send order confirmation email to wthompson@example.org has been received.
  08:01:59.363 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="CAD"  (×4)
  08:01:59.400 [emailservice] A request to send order confirmation email to jsanchez@example.org has been received.
  08:02:01.038 [checkoutservice] failed to send order confirmation to "jessicamanning@example.net": rpc error: code = Internal desc = Failed to serialize response!
  08:02:15.787 [emailservice] A request to send order confirmation email to mcgeekaren@example.com has been received.
  08:02:22.141 [emailservice] A request to send order confirmation email to christopherevans@example.org has been received.
  08:02:26.026 [checkoutservice] failed to send order confirmation to "megan53@example.net": rpc error: code = Internal desc = Failed to serialize response!
  08:02:40.854 [checkoutservice] failed to send order confirmation to "christophertran@example.net": rpc error: code = Internal desc = Failed to serialize response!

## p0129
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T05:20:06.610Z
```
{"timestamp":1731907206610717700,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-sd8v2","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Getting supported currencies..."}
```
Same service, the 2 minutes before (oldest first):
  05:20:05.146 [currencyservice] conversion request successful  (×13)
  05:20:05.228 [currencyservice] Getting supported currencies...  (×7)
All services, 30 seconds either side (sampled):
  05:19:36.628 [frontend] request started  (×308)
  05:19:36.637 [cartservice] GetCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×260)
  05:19:36.658 [frontend] failed to retrieve ads  (×189)
  05:19:37.085 [frontend] view user cart  (×62)
  05:19:37.625 [frontend] adding to cart  (×28)
  05:19:38.210 [frontend] home  (×36)
  05:19:42.231 [frontend] placing order  (×9)
  05:19:42.263 [paymentservice] Transaction processed: visa ending 8711 Amount: TRY5280.894582045  (×2)
  05:19:42.266 [shippingservice] [ShipOrder] completed request  (×9)
  05:19:42.276 [checkoutservice] order confirmation email sent to "sheriwatts@example.com"
  05:19:43.579 [checkoutservice] order confirmation email sent to "scott02@example.com"
  05:19:44.575 [paymentservice] Transaction processed: visa ending 7018 Amount: EUR361.636444053
  05:19:44.645 [adservice] Stats enabled, but temporarily unavailable
  05:19:44.648 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.
  05:19:46.250 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base
  05:19:47.036 [paymentservice] Transaction processed: visa ending 1440 Amount: GBP1625.977492250  (×2)
  05:19:47.358 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'L9ECAV7KIM']  (×2)
  05:20:04.448 [checkoutservice] [PlaceOrder] user_id="736a09b5-665e-4823-8520-b8602b0bdbff" user_currency="USD"  (×2)
  05:20:04.483 [emailservice] A request to send order confirmation email to julie35@example.com has been received.
  05:20:05.187 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"3211","nanos":70216706},"credit_card":{"credit_card_number":"43963825318558  (×2)
  05:20:05.205 [checkoutservice] order confirmation email sent to "swansonpatricia@example.com"
  05:20:36.225 [emailservice] A request to send order confirmation email to brownmichelle@example.com has been received.

## p0817
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-10T13:15:16.117Z
```
{"timestamp":1733836516117564200,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-vpgpt","node_name":"ip-192-168-51-182.ap-southeast-2.compute.internal","message":"2024-12-10 13:15:16.117  INFO 1 --- [           main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped \"{[/error]}\" onto public org.springframework.http.ResponseEntity<java.util.Map<java.lang.String, java.lang.Object>> org.springframework.boot.autoconfigure.web.BasicErrorController.error(javax.servlet.http.HttpServletRequest)"}
```
Same service, the 2 minutes before (oldest first):
  13:15:07.411 [ts-auth-service] 2024-12-10 13:15:07.411 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip
  13:15:07.501 [ts-auth-service] 2024-12-10 13:15:07.501 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  13:15:08.565 [ts-auth-service] 2024-12-10 13:15:08.565 INFO 1 --- [ main] o.s.i.config.IntegrationRegistrar : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. The
  13:15:11.574 [ts-auth-service] 2024-12-10 13:15:11.573 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def
  13:15:11.666 [ts-auth-service] 2024-12-10 13:15:11.665 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'taskScheduler' has been explicitly defined. Therefore, a de
  13:15:13.072 [ts-auth-service] 2024-12-10 13:15:13.071 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.configuration.ObjectP
  13:15:13.264 [ts-auth-service] 2024-12-10 13:15:13.263 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'objectPostProcessor' of type [org.springframework.security.config.an
  13:15:13.270 [ts-auth-service] 2024-12-10 13:15:13.269 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.access.expression.method.DefaultMethodS
  13:15:13.366 [ts-auth-service] 2024-12-10 13:15:13.365 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.method.configuration.
  13:15:13.379 [ts-auth-service] 2024-12-10 13:15:13.379 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  13:15:13.864 [ts-auth-service] 2024-12-10 13:15:13.863 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact
  13:15:13.865 [ts-auth-service] 2024-12-10 13:15:13.865 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [java.util.Properties] is not e
  13:15:15.410 [ts-auth-service] 2024-12-10 13:15:15.409 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  13:15:16.114 [ts-auth-service] 2024-12-10 13:15:16.113 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users],methods=[GET]}" onto public org.springframework.h
  13:15:16.114 [ts-auth-service] 2024-12-10 13:15:16.114 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/{userId}],methods=[DELETE]}" onto public org.sprin
  13:15:16.114 [ts-auth-service] 2024-12-10 13:15:16.114 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/hello],methods=[GET]}" onto public java.lang.Objec
  13:15:16.115 [ts-auth-service] 2024-12-10 13:15:16.114 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  13:15:16.115 [ts-auth-service] 2024-12-10 13:15:16.115 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth],methods=[POST]}" onto public org.springframework.h
  13:15:16.116 [ts-auth-service] 2024-12-10 13:15:16.115 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth/hello],methods=[GET]}" onto public java.lang.String
  13:15:16.117 [ts-auth-service] 2024-12-10 13:15:16.117 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
All services, 30 seconds either side (sampled):
  13:14:47.755 [ts-admin-basic-info-service] 2024-12-10 13:14:47.755 INFO 1 --- [io-18767-exec-4] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×10)
  13:14:54.705 [ts-auth-service] 2024-12-10 13:14:54.705 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def  (×2)
  13:14:56.704 [ts-auth-service] 2024-12-10 13:14:56.704 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.method.configuration.  (×2)
  13:14:56.833 [ts-travel2-service] 2024-12-10 13:14:56.832 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×12)
  13:14:58.859 [ts-order-service] 2024-12-10 13:14:58.859 ERROR 1 --- [io-12031-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  13:15:01.617 [ts-auth-service] 2024-12-10 13:15:01.616 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]  (×2)
  13:15:03.980 [ts-travel-service] 2024-12-10 13:15:03.980 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×9)
  13:15:06.512 [ts-auth-service] 2024-12-10 13:15:06.512 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClust  (×2)
  13:15:07.041 [ts-travel-service] 2024-12-10 13:15:07.040 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d
  13:15:07.411 [ts-auth-service] 2024-12-10 13:15:07.411 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip  (×2)
  13:15:12.032 [ts-assurance-mongo] {"t":{"$date":"2024-12-10T13:15:12.032+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:12.694 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-10T13:15:12.694+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:13.234 [ts-price-mongo] {"t":{"$date":"2024-12-10T13:15:13.234+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:14.921 [ts-contacts-mongo] {"t":{"$date":"2024-12-10T13:15:14.921+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:15.828 [ts-travel-service] 2024-12-10 13:15:15.828 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)
  13:15:16.114 [ts-auth-service] 2024-12-10 13:15:16.113 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users],methods=[GET]}" onto public org.springframework.h
  13:15:16.501 [ts-auth-service] 2024-12-10 13:15:16.500 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.springframewo
  13:15:18.503 [ts-auth-service] 2024-12-10 13:15:18.503 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  13:15:18.508 [ts-auth-service] 2024-12-10 13:15:18.507 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  13:15:19.366 [ts-travel-service] 2024-12-10 13:15:19.366 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×2)
  13:15:24.400 [ts-auth-service] 2024-12-10 13:15:24.400 INFO 1 --- [ main] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 1 subscriber(s).
  13:15:30.209 [ts-auth-service] 2024-12-10 13:15:30.208 INFO 1 --- [io-12340-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  13:15:32.501 [ts-auth-service] 2024-12-10 13:15:32.500 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×7)
  13:15:32.934 [ts-travel2-service] 2024-12-10 13:15:32.933 ERROR 1 --- [io-16346-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×4)
  13:15:34.962 [ts-admin-basic-info-service] 2024-12-10 13:15:34.961 ERROR 1 --- [io-18767-exec-9] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×3)
  13:15:45.774 [ts-auth-service] 2024-12-10 13:15:45.774 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null
  13:15:45.931 [ts-auth-service] 2024-12-10 13:15:45.931 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 763cdad2-044b-466f-a5dc-11dbb90b599a USER ID

## p0842
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-other-service, 2024-12-08T12:59:48.502Z
```
{"timestamp":1733662788502242600,"container_name":"ts-order-other-service","pod_name":"ts-order-other-service-746fccc88f-cgz4x","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:59:48.502  INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController    : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024"}
```
Same service, the 2 minutes before (oldest first):
  12:59:29.473 [ts-order-other-service] 2024-12-08 12:59:29.473 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=178781  (×3)
  12:59:32.391 [ts-order-other-service] 2024-12-08 12:59:32.390 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:0  (×4)
  12:59:32.393 [ts-order-other-service] 2024-12-08 12:59:32.392 INFO 1 --- [io-12032-exec-9] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×4)
  12:59:32.454 [ts-order-other-service] 2024-12-08 12:59:32.454 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×6)
  12:59:33.996 [ts-order-other-service] 2024-12-08 12:59:33.995 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Security Info Get]
  12:59:41.351 [ts-order-other-service] 2024-12-08 12:59:41.350 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Security Info Get]
  12:59:48.384 [ts-order-other-service] 2024-12-08 12:59:48.384 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM
All services, 30 seconds either side (sampled):
  12:59:19.635 [ts-auth-service] 2024-12-08 12:59:19.634 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×2)
  12:59:19.840 [ts-travel2-service] 2024-12-08 12:59:19.839 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×131)
  12:59:19.877 [ts-basic-service] 2024-12-08 12:59:19.876 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×70)
  12:59:19.949 [ts-seat-service] 2024-12-08 12:59:19.948 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×22)
  12:59:20.011 [ts-travel2-service] 2024-12-08 12:59:20.010 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×24)
  12:59:21.163 [ts-admin-basic-info-service] 2024-12-08 12:59:21.162 INFO 1 --- [io-18767-exec-7] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×11)
  12:59:22.335 [ts-consign-service] 2024-12-08 12:59:22.335 INFO 1 --- [io-16111-exec-8] consign.service.ConsignServiceImpl : The target date is 2024-12-08 12:59:22
  12:59:25.409 [ts-travel-service] 2024-12-08 12:59:25.409 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×17)
  12:59:25.597 [ts-travel-service] 2024-12-08 12:59:25.596 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, tr  (×22)
  12:59:25.657 [ts-seat-service] 2024-12-08 12:59:25.656 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×6)
  12:59:25.830 [ts-order-service] 2024-12-08 12:59:25.830 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×8)
  12:59:26.244 [ts-travel-service] 2024-12-08 12:59:26.243 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×31)
  12:59:29.031 [ts-auth-service] 2024-12-08 12:59:29.031 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×10)
  12:59:33.637 [ts-basic-service] 2024-12-08 12:59:33.637 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe  (×7)
  12:59:33.780 [ts-basic-service] 2024-12-08 12:59:33.780 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×2)
  12:59:33.941 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:59:33 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 11857 "-" "Mozilla/5.0 (Macintosh  (×5)
  12:59:33.974 [ts-security-service] 2024-12-08 12:59:33.973 INFO 1 --- [io-11188-exec-4] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....  (×2)
  12:59:34.012 [ts-preserve-service] 2024-12-08 12:59:34.012 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Contacts Id: 47e015f5-6a9d-41ce-9b3a-e09  (×2)
  12:59:34.318 [ts-preserve-service] 2024-12-08 12:59:34.317 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : TripAllDetail:TripAllDetail(status=false, message=null, tripResponse  (×2)
  12:59:34.425 [ts-seat-service] 2024-12-08 12:59:34.425 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService distributeSeat] The request seat type is economyClass and the t
  12:59:34.445 [ts-preserve-service] 2024-12-08 12:59:34.445 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service][Step 5] Do not need to buy assurance
  12:59:35.729 [ts-travel2-service] 2024-12-08 12:59:35.729 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234  (×3)
  12:59:39.346 [ts-basic-service] 2024-12-08 12:59:39.346 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  12:59:41.771 [ts-seat-service] 2024-12-08 12:59:41.771 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService distributeSeat] The request seat type is confortClass and the t
  12:59:57.167 [ts-admin-basic-info-service] 2024-12-08 12:59:57.167 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×2)
  13:00:12.003 [ts-travel-mongo] {"t":{"$date":"2024-12-08T13:00:12.003+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366281
  13:00:12.914 [ts-travel2-mongo] {"t":{"$date":"2024-12-08T13:00:12.914+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366281
  13:00:16.052 [ts-consign-mongo] {"t":{"$date":"2024-12-08T13:00:16.052+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366281

## p0393
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:26.486Z
```
{"timestamp":1732247186486138400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"statusCode\":500,\"body\":{\"timestamp\":1732247186482,\"status\":500,\"error\":\"Internal Server Error\",\"exception\":\"java.lang.IllegalStateException\",\"message\":\"Unable to create order due to unspecified IO error.\",\"path\":\"/orders\"},\"headers\":{\"x-application-context\":\"orders:80\",\"content-type\":\"application/json;charset=UTF-8\",\"date\":\"Fri, 22 Nov 2024 03:46:26 GMT\",\"x-envoy-upstream-service…"}
```
Same service, the 2 minutes before (oldest first):
  03:46:26.396 [front-end] Request received with body: {}
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:26.404 [front-end] Received response: "{\"firstName\":\"VaPxY\",\"lastName\":\"VaPxY\",\"username\":\"VaPxY\",\"id\":\"673ffe84b0df5c00019b3164\",\"_links\":{\"addresses\":{\"href
  03:46:26.404 [front-end] GET Request to: http://user/customers/673ffe84b0df5c00019b3164/addresses  (×2)
  03:46:26.409 [front-end] { id: '673ffe92b0df5c00019b318e' }
  03:46:26.409 [front-end] 673ffe92b0df5c00019b318e
  03:46:26.409 [front-end] Merging carts for customer id: 673ffe92b0df5c00019b318e and session id: rrS1mEHOo4YitGXARYyweWtoOysIjwDD
  03:46:26.410 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:46:26.410 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe8ab0df5c00019b3179\",\"_links\":{\"
  03:46:26.410 [front-end] [ undefined, undefined ]
  03:46:26.410 [front-end] Posting Order: {"customer":"http://user/customers/673ffe84b0df5c00019b3164","address":"http://user/addresses/673ffe8ab0df5c00019b3177","card":"http://user/cards
  03:46:26.418 [front-end] Carts merged.  (×2)
  03:46:26.418 [front-end] set cookie673ffe92b0df5c00019b318d  (×2)
  03:46:26.418 [front-end] Sent cookies.  (×2)
  03:46:26.420 [front-end] POST /register 200 44.756 ms - 33  (×2)
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×27)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×44)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×58)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×47)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×47)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×45)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×45)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×45)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h

## p0591
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:43:39.500Z
```
{"timestamp":1733597019500381200,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:43:39.500  INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl       : LOGIN USER NEW:admin __ 222222 __ null"}
```
Same service, the 2 minutes before (oldest first):
  18:43:27.867 [ts-auth-service] 2024-12-07 18:43:27.867 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×5)
  18:43:27.867 [ts-auth-service] 2024-12-07 18:43:27.867 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×5)
  18:43:30.140 [ts-auth-service] 2024-12-07 18:43:30.140 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null
  18:43:30.140 [ts-auth-service] 2024-12-07 18:43:30.140 INFO 1 --- [io-12340-exec-6] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  18:43:32.449 [ts-auth-service] 2024-12-07 18:43:32.449 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×4)
  18:43:32.449 [ts-auth-service] 2024-12-07 18:43:32.449 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×4)
All services, 30 seconds either side (sampled):
  18:43:10.027 [ts-auth-service] 2024-12-07 18:43:10.026 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×12)
  18:43:10.181 [ts-auth-service] 2024-12-07 18:43:10.181 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×26)
  18:43:10.195 [ts-admin-travel-service] 2024-12-07 18:43:10.195 ERROR 1 --- [io-16114-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×14)
  18:43:12.206 [ts-admin-basic-info-service] 2024-12-07 18:43:12.205 ERROR 1 --- [io-18767-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×24)
  18:43:12.209 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:43:12 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 500 238 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_  (×13)
  18:43:16.966 [ts-auth-service] 2024-12-07 18:43:16.965 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:43:17.186 [ts-travel2-service] 2024-12-07 18:43:17.186 ERROR 1 --- [io-16346-exec-6] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×14)
  18:43:17.189 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:43:17 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 500 228 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×14)
  18:43:20.617 [ts-auth-service] 2024-12-07 18:43:20.617 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×13)
  18:43:21.806 [ts-travel-service] 2024-12-07 18:43:21.806 ERROR 1 --- [io-12346-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  18:43:24.196 [ts-food-service] 2024-12-07 18:43:24.195 ERROR 1 --- [io-18856-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:43:24.199 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:43:24 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 500 259 "-" "Mozilla/5.0 (Macintosh;   (×2)
  18:43:24.483 [ts-order-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  18:43:27.510 [ts-travel-mongo] {"t":{"$date":"2024-12-07T18:43:27.509+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359700
  18:43:27.675 [ts-config-mongo] {"t":{"$date":"2024-12-07T18:43:27.674+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359700
  18:43:29.983 [ts-food-mongo] {"t":{"$date":"2024-12-07T18:43:29.983+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359700
  18:43:30.013 [ts-station-mongo] {"t":{"$date":"2024-12-07T18:43:30.013+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359701
  18:43:30.636 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T18:43:30.636+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359701
  18:43:30.845 [ts-notification-mongo] {"t":{"$date":"2024-12-07T18:43:30.844+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359701
  18:43:42.115 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T18:43:42.115+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359702
  18:43:42.311 [ts-order-other-mongo] {"t":{"$date":"2024-12-07T18:43:42.311+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359702
  18:43:50.213 [ts-order-other-service] 2024-12-07 18:43:50.212 ERROR 1 --- [io-12032-exec-9] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  18:43:52.077 [ts-auth-service] 2024-12-07 18:43:52.077 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null
  18:43:55.091 [ts-food-service] 2024-12-07 18:43:55.091 ERROR 1 --- [o-18856-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 

## p0713
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-14T05:53:52.502Z
```
{"service":"dbservice1","message":"2021-08-14 05:53:52,502 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | dce6c5bc4c334b72 | f26984e6-fc80-11eb-adc6-0242ac110003-xomaJMly-EYTm8(4?5G7B token generate success token=MTYyODg5MTYzMi41MDE3NzM0OmYyNjk4NGU2LWZjODAtMTFlYi1hZGM2LTAyNDJhYzExMDAwM3hvbWFKTWx5RVlUbTgoND81RzdCOjE2Mjg4OTE2OTIuNTAxNzg0MzoxYzA5M2Q0NmEyM2RiNzg3MjM0YWFmZmY4MTI2ODM1Nw=="}
```
Same service, the 2 minutes before (oldest first):
  05:53:45.994 [dbservice1] INFO ee90f5a2-fc80-11eb-9ffe-0242ac110004-hLXtpSzb-KxJ1VOoDm#-l token generate success token=MTYyODg5MTYyNS45OTQ1NTMzOmVlOTBmNWEyLWZjODAtMTFlYi05ZmZlLTAyNDJhYzE
  05:53:47.502 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  05:53:47.502 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  05:53:47.519 [dbservice1] INFO query = select passwards from username_table where user_name='rAmXuCJg'  (×5)
  05:53:47.595 [dbservice1] INFO ef7b058e-fc80-11eb-998f-0242ac110003-rAmXuCJg-%$eQN0lfASj) token generate success token=MTYyODg5MTYyNy41OTQ3OTplZjdiMDU4ZS1mYzgwLTExZWItOTk4Zi0wMjQyYWMxMTA
  05:53:50.022 [dbservice1] INFO f0ebbefe-fc80-11eb-9f36-0242ac110003-Wwkmbphn-+MclZ6B=^/:C token generate success token=MTYyODg5MTYzMC4wMjIxOTcyOmYwZWJiZWZlLWZjODAtMTFlYi05ZjM2LTAyNDJhYzE
  05:53:50.913 [dbservice1] INFO f16c2b0c-fc80-11eb-aee1-0242ac110003-FMChXPGp-1ZD.v{4)u6AM token generate success token=MTYyODg5MTYzMC45MTI5ODg0OmYxNmMyYjBjLWZjODAtMTFlYi1hZWUxLTAyNDJhYzE
  05:53:51.018 [dbservice1] INFO f18a35a2-fc80-11eb-a2c9-0242ac110004-UVDQSlfP-pIa$R%rCt-+4 token generate success token=MTYyODg5MTYzMS4wMTc3NjcyOmYxOGEzNWEyLWZjODAtMTFlYi1hMmM5LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  05:53:22.502 [dbservice2] INFO query = select passwards from username_table where user_name='BmulXDLf'  (×42)
  05:53:22.897 [webservice2] INFO complete information: {'uuid': 'e11151f6-fc80-11eb-aad6-0242ac110004', 'user_id': 'OYPSuZEk'}  (×38)
  05:53:22.985 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×38)
  05:53:23.152 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×41)
  05:53:23.245 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×37)
  05:53:23.933 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×38)
  05:53:24.013 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×42)
  05:53:24.360 [webservice1] INFO complete information: {'uuid': 'e1f5e1a4-fc80-11eb-87fc-0242ac110003', 'user_id': 'IToaCVWE'}  (×43)
  05:53:24.618 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'e219abb6-fc80-11eb-aea8-0242ac110004'}  (×34)
  05:53:27.642 [mobservice1] INFO info e3c1a8a6-fc80-11eb-8966-0242ac110003:NmlBnobg write success
  05:53:36.482 [dbservice1] INFO e8d77ec4-fc80-11eb-bca4-0242ac110003-qfGXigUn-23/FgZd1mV+c token generate success token=MTYyODg5MTYxNi40ODIyNjI4OmU4ZDc3ZWM0LWZjODAtMTFlYi1iY2E0LTAyNDJhYzE  (×3)
  05:53:37.910 [mobservice1] INFO info e9f2069e-fc80-11eb-b747-0242ac110004:bsnOITed write success
  05:53:39.906 [dbservice1] INFO eaed7498-fc80-11eb-85ec-0242ac110004-glaSXZGO-iB:Guv&kX(1a token generate success token=MTYyODg5MTYxOS45MDY1MTI1OmVhZWQ3NDk4LWZjODAtMTFlYi04NWVjLTAyNDJhYzE
  05:53:42.324 [dbservice2] ERROR password in database of {user} is null, the user is not registered  (×3)
  05:53:44.874 [mobservice2] INFO info ee0ab898-fc80-11eb-a091-0242ac110003:ERSdWpfg write success
  05:53:47.245 [mobservice2] INFO info ef7b058e-fc80-11eb-998f-0242ac110003:rAmXuCJg write success
  05:53:49.202 [dbservice2] INFO f07e39a6-fc80-11eb-9c94-0242ac110004-IFyHcfZd-)BYaIRlCgv21 token generate success token=MTYyODg5MTYyOS4yMDIwOTY3OmYwN2UzOWE2LWZjODAtMTFlYi05Yzk0LTAyNDJhYzE
  05:53:51.384 [mobservice1] INFO info f1f8e61e-fc80-11eb-99b3-0242ac110004:pvNdAbhE write success
  05:53:53.833 [dbservice2] INFO f335af8a-fc80-11eb-abb8-0242ac110003-OURXjiIJ-5Jn{CRus!OS: token generate success token=MTYyODg5MTYzMy44MzM0MjkzOmYzMzVhZjhhLWZjODAtMTFlYi1hYmI4LTAyNDJhYzE
  05:53:56.588 [dbservice2] INFO f4e45700-fc80-11eb-9a55-0242ac110004-ODxjMiJU-a8j<f^QX)sES token generate success token=MTYyODg5MTYzNi41ODgxMTk3OmY0ZTQ1NzAwLWZjODAtMTFlYi05YTU1LTAyNDJhYzE  (×2)
  05:53:59.049 [mobservice2] INFO info f68a11e4-fc80-11eb-9c34-0242ac110004:hCIZuDLt write success
  05:54:01.201 [dbservice2] INFO f7a3d9f2-fc80-11eb-9c25-0242ac110004-UIkWCbjA-+&:uQ8N?i4k* token generate success token=MTYyODg5MTY0MS4yMDA0NDc2OmY3YTNkOWYyLWZjODAtMTFlYi05YzI1LTAyNDJhYzE
  05:54:03.294 [mobservice2] INFO info f90e007e-fc80-11eb-95a2-0242ac110004:ODxjMiJU write success
  05:54:05.560 [mobservice1] INFO info fa6f9fe0-fc80-11eb-a4d3-0242ac110004:XrSheKyp write success
  05:54:07.797 [dbservice1] INFO fb861576-fc80-11eb-98db-0242ac110004-dULDJpwo--J=t5_1H_3.l token generate success token=MTYyODg5MTY0Ny43OTcyMzcyOmZiODYxNTc2LWZjODAtMTFlYi05OGRiLTAyNDJhYzE
  05:54:10.632 [dbservice1] INFO fd2ad8e4-fc80-11eb-b460-0242ac110004-aolWDIFH-Z(_kMcNp^guh token generate success token=MTYyODg5MTY1MC42MzE2MzY6ZmQyYWQ4ZTQtZmM4MC0xMWViLWI0NjAtMDI0MmFjMTE
  05:54:13.328 [dbservice2] INFO febcce6a-fc80-11eb-8a98-0242ac110003-fegJlQaO-}1UbPAK(3:>J token generate success token=MTYyODg5MTY1My4zMjgxMjQ1OmZlYmNjZTZhLWZjODAtMTFlYi04YTk4LTAyNDJhYzE
  05:54:16.240 [mobservice2] INFO info 00b9d9ba-fc81-11eb-9c1f-0242ac110003:iZWtCSMp write success
  05:54:18.434 [webservice2] ERROR an error occurred in the downstream service
  05:54:20.549 [mobservice2] INFO info 035d80cc-fc81-11eb-bfd8-0242ac110004:WRrkiQEt write success

## p0310
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:20:26.530Z
```
{"timestamp":1732245626530072600,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"timestamp\":1732245626527,\"status\":500,\"error\":\"Internal Server Error\",\"exception\":\"java.lang.IllegalStateException\",\"message\":\"Unable to create order due to unspecified IO error.\",\"path\":\"/orders\"}"}
```
Same service, the 2 minutes before (oldest first):
  03:20:26.059 [front-end] POST /register 200 39.427 ms - 33
  03:20:26.062 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff874b0df5c00019b1ee9"}
  03:20:26.072 [front-end] POST /cards 200 - ms - -
  03:20:26.116 [front-end] Attempting to delete cart for user: 673ff874b0df5c00019b1ee9
  03:20:26.166 [front-end] User cart deleted with status: 503
  03:20:26.168 [front-end] DELETE /cart 503 - ms - -
  03:20:26.174 [front-end] Attempting to add to cart: {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","quantity":1}
  03:20:26.183 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  03:20:26.183 [front-end] POST to carts: http://carts/carts/673ff874b0df5c00019b1ee9/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}
  03:20:26.231 [front-end] GET /catalogue 200 - ms - -
  03:20:26.240 [front-end] POST /cart 500 63.073 ms - 64
  03:20:26.462 [front-end] Request received with body: {}
  03:20:26.469 [front-end] Received response: "{\"firstName\":\"tbhaDXI\",\"lastName\":\"tbhaDXI\",\"username\":\"tbhaDXI\",\"id\":\"673ff865b0df5c00019b1ea5\",\"_links\":{\"addresses\":{
  03:20:26.469 [front-end] GET Request to: http://user/customers/673ff865b0df5c00019b1ea5/addresses  (×2)
  03:20:26.475 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:20:26.476 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff86ab0df5c00019b1ec2\",\"_links\":{\"
  03:20:26.476 [front-end] [ undefined, undefined ]
  03:20:26.476 [front-end] Posting Order: {"customer":"http://user/customers/673ff865b0df5c00019b1ea5","address":"http://user/addresses/673ff86ab0df5c00019b1ec1","card":"http://user/cards
  03:20:26.530 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245626527,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×32)
  03:20:06.543 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff  (×49)
  03:20:06.590 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245606587,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×49)
  03:20:06.664 [user] ts=2024-11-22T03:20:06.664037694Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff861b0df5c00019b1e9e took=1.670187ms  (×51)
  03:20:06.789 [front-end] POST to carts: http://carts/carts/673ff861b0df5c00019b1e9e/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}  (×16)
  03:20:06.949 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×3)
  03:20:08.469 [front-end] Posting Customer: {"username":"HNCLfJfsnW","password":"sSvsy","email":"HNCLfJfsnW@gmail.com","firstName":"HNCLfJfsnW","lastName":"HNCLfJfsnW"}
  03:20:08.498 [front-end] set cookie673ff868b0df5c00019b1eb9  (×48)
  03:20:09.096 [front-end] Received response: "{\"firstName\":\"IfuCg\",\"lastName\":\"IfuCg\",\"username\":\"IfuCg\",\"id\":\"673ff851b0df5c00019b1e79\",\"_links\":{\"addresses\":{\"href
  03:20:09.910 [front-end] Posting Customer: {"username":"uQhCpCJIyYL","password":"dElvDjn","email":"uQhCpCJIyYL@gmail.com","firstName":"uQhCpCJIyYL","lastName":"uQhCpCJIyYL"}
  03:20:11.559 [user] ts=2024-11-22T03:20:11.558844653Z caller=middlewares.go:46 method=Register username=xQhxkcD email=xQhxkcD@gmail.com took=1.123618ms
  03:20:14.239 [front-end] Posting Customer: {"username":"burOTnWrVFcFcR","password":"JMCDouKzn","email":"burOTnWrVFcFcR@gmail.com","firstName":"burOTnWrVFcFcR","lastName":"burOTnWrVFcFcR
  03:20:16.376 [front-end] Posting Customer: {"username":"zCHyJV","password":"DBVYLG","email":"zCHyJV@gmail.com","firstName":"zCHyJV","lastName":"zCHyJV"}
  03:20:18.305 [front-end] Received response: "{\"firstName\":\"SxecnNeiPQ\",\"lastName\":\"SxecnNeiPQ\",\"username\":\"SxecnNeiPQ\",\"id\":\"673ff861b0df5c00019b1e9f\",\"_links\":{\"addr
  03:20:20.952 [user] ts=2024-11-22T03:20:20.951976065Z caller=middlewares.go:46 method=Register username=tJMqzAgJI email=tJMqzAgJI@gmail.com took=1.117996ms
  03:20:24.692 [carts] 2024-11-22 03:20:24.692 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  03:20:28.055 [front-end] Received response: "{\"firstName\":\"ihYowTIIUzglApd\",\"lastName\":\"ihYowTIIUzglApd\",\"username\":\"ihYowTIIUzglApd\",\"id\":\"673ff86bb0df5c00019b1ec4\",\"_
  03:20:30.097 [front-end] Posting Customer: {"username":"dStkYebBky","password":"aPZcljShz","email":"dStkYebBky@gmail.com","firstName":"dStkYebBky","lastName":"dStkYebBky"}
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.372 [front-end] Received response: "{\"firstName\":\"CBhyKd\",\"lastName\":\"CBhyKd\",\"username\":\"CBhyKd\",\"id\":\"673ff869b0df5c00019b1eba\",\"_links\":{\"addresses\":{\"h
  03:20:36.743 [front-end] Received response: "{\"firstName\":\"UzagwCTnbpaXVzA\",\"lastName\":\"UzagwCTnbpaXVzA\",\"username\":\"UzagwCTnbpaXVzA\",\"id\":\"673ff86fb0df5c00019b1ed4\",\"_
  03:20:38.171 [session-db] 1:M 22 Nov 2024 03:20:38.171 * Background saving terminated with success
  03:20:41.176 [front-end] Received response: "{\"firstName\":\"dpZIGojLodgB\",\"lastName\":\"dpZIGojLodgB\",\"username\":\"dpZIGojLodgB\",\"id\":\"673ff87bb0df5c00019b1efc\",\"_links\":{
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  03:20:43.391 [carts] 2024-11-22 03:20:43.391 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:20:47.926 [front-end] Posting Customer: {"username":"XYDErsNhuY","password":"RuOOlZc","email":"XYDErsNhuY@gmail.com","firstName":"XYDErsNhuY","lastName":"XYDErsNhuY"}
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/browser/**] onto handler of type [class org.sp
  03:20:51.235 [front-end] Posting Customer: {"username":"cqPFUedoarsUCI","password":"BNbmkot","email":"cqPFUedoarsUCI@gmail.com","firstName":"cqPFUedoarsUCI","lastName":"cqPFUedoarsUCI"}
  03:20:54.518 [front-end] Posting Customer: {"username":"aZnbBrPviPwcYcC","password":"cLxGTi","email":"aZnbBrPviPwcYcC@gmail.com","firstName":"aZnbBrPviPwcYcC","lastName":"aZnbBrPviPwcYc

## p0677
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-11T16:14:44.504Z
```
{"service":"dbservice1","message":"2021-08-11 16:14:44,504 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | f5d0157675197b10 | 2f0af71a-fa7c-11eb-b901-0242ac110004-qyhWbUnC-<FZIvzgO}SA% token generate success token=MTYyODY2OTY4NC41MDM3NTMyOjJmMGFmNzFhLWZhN2MtMTFlYi1iOTAxLTAyNDJhYzExMDAwNHF5aFdiVW5DPEZaSXZ6Z099U0ElOjE2Mjg2Njk3NDQuNTAzNzY0NDo0Yjg4MjAyM2RhYzhhZTk4Mjc1ODVjMmNlMjc0M2U2YQ=="}
```
Same service, the 2 minutes before (oldest first):
  16:14:32.879 [dbservice1] INFO query = select passwards from username_table where user_name='dULDJpwo'  (×4)
  16:14:33.188 [dbservice1] INFO 282de024-fa7c-11eb-b143-0242ac110003-dULDJpwo--J=t5_1H_3.l token generate success token=MTYyODY2OTY3My4xODgwMzc5OjI4MmRlMDI0LWZhN2MtMTFlYi1iMTQzLTAyNDJhYzE
  16:14:36.053 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×6)
  16:14:36.053 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×6)
  16:14:36.240 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  16:14:42.065 [dbservice1] INFO 2d9e2fbe-fa7c-11eb-9a7d-0242ac110003-ODxjMiJU-a8j<f^QX)sES token generate success token=MTYyODY2OTY4Mi4wNjQ5NjQ1OjJkOWUyZmJlLWZhN2MtMTFlYi05YTdkLTAyNDJhYzE
  16:14:42.100 [dbservice1] INFO 2d981fac-fa7c-11eb-bd10-0242ac110004-dnDTbBha-yx8)4Fs?KhJg token generate success token=MTYyODY2OTY4Mi4wOTk3ODc6MmQ5ODFmYWMtZmE3Yy0xMWViLWJkMTAtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  16:14:14.513 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  16:14:14.640 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  16:14:14.691 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×49)
  16:14:14.880 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  16:14:15.022 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '1db709fe-fa7c-11eb-ac0d-0242ac110003'}  (×44)
  16:14:15.759 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×44)
  16:14:16.370 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '1ebeb2f2-fa7c-11eb-a0e3-0242ac110004', 'value': '', 'ex': 10}  (×40)
  16:14:17.140 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×51)
  16:14:18.321 [mobservice2] INFO info 1fb36216-fa7c-11eb-ae78-0242ac110003:IKTgrkvl write success
  16:14:21.082 [mobservice1] INFO info 215bb956-fa7c-11eb-b0c6-0242ac110003:jdpqWsnu write success
  16:14:23.561 [mobservice1] INFO info 22d13f0e-fa7c-11eb-8ccd-0242ac110004:dQcykLhj write success
  16:14:26.322 [dbservice1] INFO 243a0772-fa7c-11eb-8886-0242ac110003-TMBcRIPk-t>ebO}qX)ah8 token generate success token=MTYyODY2OTY2Ni4zMjIyODE6MjQzYTA3NzItZmE3Yy0xMWViLTg4ODYtMDI0MmFjMTE  (×2)
  16:14:28.957 [mobservice1] INFO info 260ab7b8-fa7c-11eb-827b-0242ac110004:SgtQlrMk write success
  16:14:31.466 [mobservice2] INFO info 2788d52a-fa7c-11eb-ae41-0242ac110003:suCOBkmp write success
  16:14:33.486 [webservice1] ERROR an error occurred in the downstream service  (×4)
  16:14:36.882 [dbservice2] INFO 2a11c176-fa7c-11eb-a1fc-0242ac110003-WvNJCdPU-uTnHNJK0W>)$ token generate success token=MTYyODY2OTY3Ni44ODE1ODM3OjJhMTFjMTc2LWZhN2MtMTFlYi1hMWZjLTAyNDJhYzE
  16:14:39.524 [dbservice2] INFO 2c1f1cac-fa7c-11eb-99d4-0242ac110003-AdPXowjJ-4>$2wY*8ErhR token generate success token=MTYyODY2OTY3OS41MjQzNTY4OjJjMWYxY2FjLWZhN2MtMTFlYi05OWQ0LTAyNDJhYzE
  16:14:42.100 [dbservice1] INFO 2d981fac-fa7c-11eb-bd10-0242ac110004-dnDTbBha-yx8)4Fs?KhJg token generate success token=MTYyODY2OTY4Mi4wOTk3ODc6MmQ5ODFmYWMtZmE3Yy0xMWViLWJkMTAtMDI0MmFjMTE
  16:14:44.842 [dbservice2] INFO 2f524e76-fa7c-11eb-bcb2-0242ac110003-JjOStLkT-_GA<:4K/vjX@ token generate success token=MTYyODY2OTY4NC44NDE3ODc2OjJmNTI0ZTc2LWZhN2MtMTFlYi1iY2IyLTAyNDJhYzE
  16:14:47.519 [mobservice2] INFO info 3106ac12-fa7c-11eb-b213-0242ac110004:nxGFAjVa write success
  16:14:50.192 [mobservice2] INFO info 32b452e4-fa7c-11eb-9bd0-0242ac110004:vmFDrneJ write success
  16:14:52.972 [mobservice1] INFO info 345be102-fa7c-11eb-ac76-0242ac110004:LNTWaneB write success
  16:14:55.720 [mobservice1] INFO info 3600392c-fa7c-11eb-8a3c-0242ac110004:JXejhiMl write success
  16:14:58.051 [mobservice1] INFO info 37627316-fa7c-11eb-aa64-0242ac110004:PBSphkoz write success
  16:15:00.774 [dbservice1] INFO 38cf58ea-fa7c-11eb-a0eb-0242ac110004-VxubFBRX-Qgr73J_$>S}{ token generate success token=MTYyODY2OTcwMC43NzM5ODM6MzhjZjU4ZWEtZmE3Yy0xMWViLWEwZWItMDI0MmFjMTE
  16:15:04.073 [dbservice2] INFO 3ad0610c-fa7c-11eb-8d30-0242ac110003-aCdZXfNn-HVB*h$/mtRAv token generate success token=MTYyODY2OTcwNC4wNzMzOTQ6M2FkMDYxMGMtZmE3Yy0xMWViLThkMzAtMDI0MmFjMTE
  16:15:06.278 [dbservice2] INFO 3c210192-fa7c-11eb-ba54-0242ac110003-jHYceNBX-P4kgXJlU1L>S token generate success token=MTYyODY2OTcwNi4yNzgwMDk3OjNjMjEwMTkyLWZhN2MtMTFlYi1iYTU0LTAyNDJhYzE
  16:15:09.900 [dbservice1] INFO 3e3eecfa-fa7c-11eb-bc05-0242ac110003-oYbSglqf-udHk_>z3F5*y token generate success token=MTYyODY2OTcwOS45MDAwNzozZTNlZWNmYS1mYTdjLTExZWItYmMwNS0wMjQyYWMxMTA

## p0115
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:17:31.026Z
```
{"timestamp":1731907051026851000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"ENV_PLATFORM is: aws"}
```
Same service, the 2 minutes before (oldest first):
  05:17:29.264 [frontend] serving product page  (×3)
  05:17:29.276 [frontend] request complete  (×7)
  05:17:29.300 [frontend] request started  (×6)
  05:17:29.300 [frontend] adding to cart
  05:17:29.312 [frontend] view user cart  (×2)
  05:17:30.979 [frontend] home
All services, 30 seconds either side (sampled):
  05:17:01.031 [frontend] request started  (×279)
  05:17:01.041 [cartservice] GetCartAsync called with userId=736a09b5-665e-4823-8520-b8602b0bdbff  (×235)
  05:17:01.065 [adservice] received ad request (context_words=[accessories])  (×15)
  05:17:01.765 [adservice] received ad request (context_words=[kitchen])  (×33)
  05:17:02.245 [shippingservice] [GetQuote] completed request  (×75)
  05:17:02.365 [adservice] received ad request (context_words=[hair, beauty])  (×15)
  05:17:02.381 [frontend] ENV_PLATFORM is: aws  (×32)
  05:17:06.489 [adservice] received ad request (context_words=[clothing, tops])  (×9)
  05:17:16.663 [frontend] placing order  (×6)
  05:17:16.693 [paymentservice] Transaction processed: visa ending 5701 Amount: TRY1792.226454698  (×3)
  05:17:16.696 [shippingservice] [ShipOrder] completed request  (×6)
  05:17:16.706 [checkoutservice] order confirmation email sent to "abowman@example.com"
  05:17:16.825 [checkoutservice] order confirmation email sent to "barbara24@example.com"
  05:17:24.111 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"346","nanos":438559926},"credit_card":{"credit_card_number":"46766376709217  (×2)
  05:17:24.126 [checkoutservice] order confirmation email sent to "adamholder@example.org"
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:40.406 [frontend] failed to retrieve ads  (×47)
  05:17:43.840 [adservice] Tracing enabled but temporarily unavailable  (×2)
  05:17:45.449 [adservice] Exception in thread "main" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000 at io.grpc.netty.NettyServer.start(NettyServer.java:333) at io.g  (×2)
  05:17:49.603 [checkoutservice] order confirmation email sent to "vicki59@example.com"
  05:17:55.262 [paymentservice] Transaction processed: visa ending 8741 Amount: EUR679.655019909

## p0578
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:18.474Z
```
{"timestamp":1733596278474782200,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:18.474  INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl       : LOGIN USER NEW:fdse_microservice __ 111111 __ null"}
```
Same service, the 2 minutes before (oldest first):
  18:31:08.782 [ts-auth-service] 2024-12-07 18:31:08.782 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  18:31:09.063 [ts-auth-service] 2024-12-07 18:31:09.063 INFO 1 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  18:31:09.169 [ts-auth-service] 2024-12-07 18:31:09.168 INFO 1 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  18:31:09.181 [ts-auth-service] 2024-12-07 18:31:09.181 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact
  18:31:09.183 [ts-auth-service] 2024-12-07 18:31:09.183 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [java.util.Properties] is not e
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.466 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : Adding {logging-channel-adapter:_org.springframework.integration.errorLogger} as
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.467 INFO 1 --- [ main] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 1 subscriber(s).
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.467 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : started _org.springframework.integration.errorLogger
  18:31:09.955 [ts-auth-service] 2024-12-07 18:31:09.954 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 12340 (http)
  18:31:10.283 [ts-auth-service] 2024-12-07 18:31:10.283 INFO 1 --- [ main] org.mongodb.driver.connection : Opened connection [connectionId{localValue:2, serverValue:21}] to ts-auth-mongo:27017
  18:31:10.954 [ts-auth-service] 2024-12-07 18:31:10.953 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.907 seconds (JVM running for 71.147)
  18:31:13.283 [ts-auth-service] 2024-12-07 18:31:13.283 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 12340 (http)
  18:31:13.587 [ts-auth-service] 2024-12-07 18:31:13.586 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  18:31:13.587 [ts-auth-service] 2024-12-07 18:31:13.587 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43
  18:31:14.585 [ts-auth-service] 2024-12-07 18:31:14.585 INFO 1 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  18:31:14.585 [ts-auth-service] 2024-12-07 18:31:14.585 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 20107 ms
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  18:31:17.262 [ts-auth-service] 2024-12-07 18:31:17.262 INFO 1 --- [io-12340-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization completed in 100 m
  18:31:18.474 [ts-auth-service] 2024-12-07 18:31:18.474 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null
All services, 30 seconds either side (sampled):
  18:30:49.008 [ts-admin-basic-info-service] 2024-12-07 18:30:49.007 INFO 1 --- [io-18767-exec-7] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×5)
  18:30:50.707 [ts-route-service] 2024-12-07 18:30:50.707 INFO 1 --- [io-11178-exec-6] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×92)
  18:30:50.758 [ts-price-service] 2024-12-07 18:30:50.757 INFO 1 --- [io-16579-exec-2] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×12)
  18:30:50.825 [ts-travel2-service] 2024-12-07 18:30:50.824 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×16)
  18:30:50.873 [ts-seat-service] 2024-12-07 18:30:50.873 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×25)
  18:30:52.263 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:30:52.262+00:00"},"s":"I", "c":"NETWORK", "id":51800, "ctx":"conn20","msg":"client metadata","attr":{"remote":"127.0.0.6:49147","cl  (×4)
  18:30:53.574 [ts-order-other-service] 2024-12-07 18:30:53.574 INFO 1 --- [io-12032-exec-4] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 24  (×7)
  18:30:57.097 [ts-seat-service] 2024-12-07 18:30:57.096 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  18:30:58.080 [ts-price-service] 2024-12-07 18:30:58.080 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×2)
  18:31:00.335 [ts-order-other-service] 2024-12-07 18:31:00.334 ERROR 1 --- [io-12032-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×4)
  18:31:01.656 [ts-auth-service] 2024-12-07 18:31:01.655 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  18:31:03.828 [ts-travel-service] 2024-12-07 18:31:03.828 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×25)
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  18:31:03.871 [ts-auth-service] 2024-12-07 18:31:03.871 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  18:31:03.909 [ts-travel-service] 2024-12-07 18:31:03.909 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×5)
  18:31:04.007 [ts-travel-service] 2024-12-07 18:31:04.006 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×10)
  18:31:05.567 [ts-auth-service] 2024-12-07 18:31:05.566 INFO 1 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in globalExceptionHandler
  18:31:08.782 [ts-auth-service] 2024-12-07 18:31:08.782 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  18:31:10.954 [ts-auth-service] 2024-12-07 18:31:10.953 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.907 seconds (JVM running for 71.147)
  18:31:11.909 [ts-basic-service] 2024-12-07 18:31:11.909 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f
  18:31:12.420 [ts-travel-service] 2024-12-07 18:31:12.420 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan
  18:31:18.474 [ts-auth-service] 2024-12-07 18:31:18.474 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×9)
  18:31:19.676 [ts-travel2-service] 2024-12-07 18:31:19.676 ERROR 1 --- [io-16346-exec-2] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×9)
  18:31:27.257 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:31:27.257+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.270 [ts-admin-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×5)
  18:31:29.947 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:31:29.947+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  18:31:38.105 [ts-admin-travel-service] 2024-12-07 18:31:38.104 ERROR 1 --- [o-16114-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt

## p0164
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T06:25:25.179Z
```
{"timestamp":1731911125179149000,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-svrwm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"AddItemAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432, productId=9SIQT8TOJO, quantity=3"}
```
Same service, the 2 minutes before (oldest first):
  06:25:21.686 [cartservice] GetCartAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0  (×19)
  06:25:22.487 [cartservice] AddItemAsync called with userId=0ae6d9b6-4e7f-4d38-a0eb-042389dcac30, productId=9SIQT8TOJO, quantity=9
All services, 30 seconds either side (sampled):
  06:24:55.188 [frontend] request started  (×310)
  06:24:55.195 [cartservice] GetCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×255)
  06:24:55.214 [shippingservice] [GetQuote] completed request  (×71)
  06:24:55.307 [frontend] serving product page  (×149)
  06:24:56.124 [frontend] home  (×35)
  06:24:56.291 [adservice] received ad request (context_words=[decor, home])  (×21)
  06:24:58.038 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM']  (×3)
  06:24:58.115 [adservice] received ad request (context_words=[footwear])  (×13)
  06:24:58.351 [paymentservice] Transaction processed: visa ending 8043 Amount: GBP2902.531231257  (×2)
  06:24:58.355 [shippingservice] [ShipOrder] completed request  (×14)
  06:24:58.365 [checkoutservice] order confirmation email sent to "lori60@example.net"
  06:25:02.124 [adservice] received ad request (context_words=[hair, beauty])  (×10)
  06:25:06.019 [checkoutservice] order confirmation email sent to "oadams@example.net"
  06:25:16.072 [paymentservice] Transaction processed: visa ending 8818 Amount: JPY48235.492260473  (×3)
  06:25:17.873 [recommendationservice] [Recv ListRecommendations] product_ids=[]  (×2)
  06:25:19.051 [paymentservice] Transaction processed: visa ending 9899 Amount: USD1023.790000000  (×5)
  06:25:27.071 [emailservice] A request to send order confirmation email to ycook@example.org has been received.
  06:25:29.375 [checkoutservice] order confirmation email sent to "kennethsteele@example.org"
  06:25:31.385 [paymentservice] Transaction processed: visa ending 8260 Amount: CAD8967.270871274  (×2)
  06:25:32.790 [emailservice] A request to send order confirmation email to iwagner@example.com has been received.
  06:25:34.880 [checkoutservice] order confirmation email sent to "elizabeth09@example.com"
  06:25:39.048 [paymentservice] Transaction processed: visa ending 9504 Amount: EUR3463.609022585  (×2)
  06:25:39.189 [emailservice] A request to send order confirmation email to kanekimberly@example.org has been received.
  06:25:40.457 [checkoutservice] order confirmation email sent to "dennis73@example.net"
  06:25:52.899 [emailservice] A request to send order confirmation email to davischristy@example.com has been received.

## p0575
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-service, 2024-12-07T18:31:04.504Z
```
{"timestamp":1733596264504178000,"container_name":"ts-order-service","pod_name":"ts-order-service-7596478c9d-4p7wg","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:04.503  INFO 1 --- [io-12031-exec-1] order.controller.OrderController         : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00 GMT 2024 TrainNumber: D1345"}
```
Same service, the 2 minutes before (oldest first):
  18:30:17.347 [ts-order-service] 2024-12-07 18:30:17.347 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×3)
  18:30:17.421 [ts-order-service] 2024-12-07 18:30:17.421 INFO 1 --- [io-12031-exec-7] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×5)
  18:30:17.424 [ts-order-service] 2024-12-07 18:30:17.424 INFO 1 --- [io-12031-exec-7] order.service.OrderServiceImpl : Left ticket info is empty  (×2)
  18:30:31.939 [ts-order-service] 2024-12-07 18:30:31.939 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 
  18:30:31.978 [ts-order-service] 2024-12-07 18:30:31.953 ERROR 1 --- [io-12031-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  18:30:31.978 [ts-order-service] java.lang.IllegalArgumentException: Invalid UUID string: at java.util.UUID.fromString(UUID.java:194) ~[na:1.8.0_402] at order.service.OrderServiceImpl.queryOrde
  18:30:47.230 [ts-order-service] 2024-12-07 18:30:47.230 INFO 1 --- [io-12031-exec-3] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×2)
  18:30:47.299 [ts-order-service] 2024-12-07 18:30:47.299 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160,   (×3)
  18:31:04.056 [ts-order-service] 2024-12-07 18:31:04.056 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024
  18:31:04.078 [ts-order-service] 2024-12-07 18:31:04.078 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160, 
All services, 30 seconds either side (sampled):
  18:30:36.068 [ts-auth-service] 2024-12-07 18:30:36.068 INFO 1 --- [ main] o.s.i.config.IntegrationRegistrar : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. The  (×2)
  18:30:37.767 [ts-basic-service] 2024-12-07 18:30:37.766 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×16)
  18:30:37.816 [ts-basic-service] 2024-12-07 18:30:37.815 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3  (×19)
  18:30:37.888 [ts-travel2-service] 2024-12-07 18:30:37.887 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×24)
  18:30:38.000 [ts-travel2-service] 2024-12-07 18:30:37.999 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6  (×11)
  18:30:40.487 [ts-basic-service] 2024-12-07 18:30:40.487 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×6)
  18:30:40.692 [ts-travel2-service] 2024-12-07 18:30:40.692 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×2)
  18:30:41.733 [ts-basic-service] 2024-12-07 18:30:41.733 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×9)
  18:30:42.403 [ts-food-service] 2024-12-07 18:30:42.403 INFO 1 --- [io-18856-exec-3] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×2)
  18:30:44.984 [ts-travel2-service] 2024-12-07 18:30:44.983 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  18:30:47.149 [ts-travel-service] 2024-12-07 18:30:47.149 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×6)
  18:30:47.235 [ts-order-service] 2024-12-07 18:30:47.234 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 38  (×6)
  18:30:47.299 [ts-order-service] 2024-12-07 18:30:47.299 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160,   (×5)
  18:30:51.661 [ts-auth-service] 2024-12-07 18:30:51.661 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClust
  18:30:57.085 [ts-seat-service] 2024-12-07 18:30:57.085 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×3)
  18:30:58.183 [ts-order-other-service] 2024-12-07 18:30:58.182 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×2)
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.872 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  18:31:04.698 [ts-seat-service] 2024-12-07 18:31:04.698 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  18:31:10.283 [ts-auth-service] 2024-12-07 18:31:10.283 INFO 1 --- [ main] org.mongodb.driver.connection : Opened connection [connectionId{localValue:2, serverValue:21}] to ts-auth-mongo:27017
  18:31:11.879 [ts-travel-service] 2024-12-07 18:31:11.879 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:00:00 GMT 2013  (×6)
  18:31:12.420 [ts-travel-service] 2024-12-07 18:31:12.420 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan
  18:31:19.676 [ts-travel2-service] 2024-12-07 18:31:19.676 ERROR 1 --- [io-16346-exec-2] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×7)
  18:31:27.257 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:31:27.257+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.270 [ts-admin-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  18:31:30.431 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T18:31:30.430+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID

## p0633
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-price-service, 2024-12-07T20:19:35.503Z
```
{"timestamp":1733602775503295200,"container_name":"ts-price-service","pod_name":"ts-price-service-cfd9c8548-k9pwk","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 20:19:35.503  INFO 1 --- [io-16579-exec-6] price.service.PriceServiceImpl           : [Price Service][Find By Route And Train Type] Rote: f3d4d4ef-693b-4456-8eed-59c0d717dd08   Train Type: DongCheOne"}
```
Same service, the 2 minutes before (oldest first):
  20:19:18.188 [ts-price-service] 2024-12-07 20:19:18.188 INFO 1 --- [io-16579-exec-1] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×9)
  20:19:18.190 [ts-price-service] 2024-12-07 20:19:18.190 INFO 1 --- [io-16579-exec-1] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×9)
  20:19:33.374 [ts-price-service] 2024-12-07 20:19:33.374 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef
  20:19:33.376 [ts-price-service] 2024-12-07 20:19:33.376 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]
All services, 30 seconds either side (sampled):
  20:19:05.507 [ts-seat-service] 2024-12-07 20:19:05.507 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×47)
  20:19:05.991 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:19:05 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×20)
  20:19:08.001 [ts-admin-basic-info-service] 2024-12-07 20:19:08.000 INFO 1 --- [io-18767-exec-8] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×9)
  20:19:08.525 [ts-route-service] 2024-12-07 20:19:08.525 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: a3f256c1-0e43-4f7d-9c21-121bf258101f  (×27)
  20:19:12.092 [ts-travel2-service] 2024-12-07 20:19:12.091 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×13)
  20:19:18.169 [ts-basic-service] 2024-12-07 20:19:18.169 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×9)
  20:19:18.207 [ts-order-other-service] 2024-12-07 20:19:18.207 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×15)
  20:19:18.271 [ts-seat-service] 2024-12-07 20:19:18.271 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×17)
  20:19:22.253 [ts-basic-service] 2024-12-07 20:19:22.253 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×4)
  20:19:25.272 [ts-admin-travel-service] 2024-12-07 20:19:25.272 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)
  20:19:27.488 [ts-travel2-service] 2024-12-07 20:19:27.488 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  20:19:27.577 [ts-travel2-service] 2024-12-07 20:19:27.577 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×2)
  20:19:28.209 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T20:19:28.209+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360276
  20:19:31.173 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T20:19:31.173+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360277
  20:19:33.374 [ts-price-service] 2024-12-07 20:19:33.374 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×2)
  20:19:34.144 [ts-order-service] 2024-12-07 20:19:34.144 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×10)
  20:19:34.372 [ts-travel-service] 2024-12-07 20:19:34.372 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:00:00 GMT 2013  (×12)
  20:19:34.875 [ts-basic-service] 2024-12-07 20:19:34.875 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×2)
  20:19:35.072 [ts-order-service] 2024-12-07 20:19:35.072 INFO 1 --- [io-12031-exec-8] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160,   (×5)
  20:19:35.331 [ts-contacts-service] 2024-12-07 20:19:35.331 INFO 1 --- [io-12347-exec-8] contacts.controller.ContactsController : [Contacts Service][Find Contacts By Account Id: 4d2a46c7-71cb-4cf1
  20:19:35.366 [ts-order-service] 2024-12-07 20:19:35.366 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Security Info Get] 4d2a46c7-71cb-4cf1-b5bb-b68406d
  20:19:35.393 [ts-preserve-service] 2024-12-07 20:19:35.393 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Getting....
  20:19:35.467 [ts-basic-service] 2024-12-07 20:19:35.467 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe
  20:19:35.736 [ts-preserve-service] 2024-12-07 20:19:35.736 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Station Name]  (×2)
  20:19:35.877 [ts-order-service] 2024-12-07 20:19:35.877 INFO 1 --- [io-12031-exec-7] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at 
  20:19:35.906 [ts-preserve-service] 2024-12-07 20:19:35.906 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service][Step 7] Do not need to consign
  20:19:40.631 [ts-travel-service] 2024-12-07 20:19:40.631 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1236
  20:19:51.037 [ts-route-service] Error opening zip file or JAR manifest missing : /tmp/opentelemetry-javaagent.jar

## p0456
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service shipping, 2024-11-23T08:06:35.729Z
```
{"timestamp":1732349195729157400,"container_name":"shipping","pod_name":"shipping-58b65f576-rlt9r","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:35.729  INFO [shipping,39cbdccef5aa5050,0c0b4cdf6a425110,false] 7 --- [p-nio-80-exec-5] o.s.d.r.w.RepositoryRestHandlerMapping   : Mapped \"{[/{repository}/{id}/{property}],methods=[PATCH || PUT || POST],consumes=[application/json || application/x-spring-data-compact+json || text/uri-list],produces=[application/hal+json || application/json || application/*+json;charset=UTF-8]}\" ont…"}
```
Same service, the 2 minutes before (oldest first):
  08:06:34.501 [shipping] Adding shipment to queue...  (×2)
  08:06:35.299 [shipping] 2024-11-23 08:06:35.217 INFO [shipping,e1c2cbeaf55280cf,abbcf9c6a7e13ce8,false] 7 --- [p-nio-80-exec-4] o.s.a.r.c.CachingConnectionFactory : Created new connect
  08:06:35.302 [shipping] 2024-11-23 08:06:35.302 INFO [shipping,e1c2cbeaf55280cf,abbcf9c6a7e13ce8,false] 7 --- [p-nio-80-exec-4] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-
  08:06:35.605 [shipping] 2024-11-23 08:06:35.605 INFO [shipping,39cbdccef5aa5050,0c0b4cdf6a425110,false] 7 --- [p-nio-80-exec-5] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ ||   (×3)
  08:06:35.608 [shipping] 2024-11-23 08:06:35.608 INFO [shipping,39cbdccef5aa5050,0c0b4cdf6a425110,false] 7 --- [p-nio-80-exec-5] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{rep  (×13)
All services, 30 seconds either side (sampled):
  08:06:06.238 [catalogue] ts=2024-11-23T08:06:06Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.038236ms  (×61)
  08:06:06.597 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×13)
  08:06:07.004 [shipping] 2024-11-23 08:06:07.004 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/
  08:06:07.065 [front-end] set cookie67418cefa437380001deec8d  (×61)
  08:06:07.469 [front-end] Request received with body: {}  (×62)
  08:06:07.614 [user] ts=2024-11-23T08:06:07.614423361Z caller=middlewares.go:46 method=Register username=ucodWkVEg email=ucodWkVEg@gmail.com took=3.000643ms
  08:06:13.368 [front-end] Posting Customer: {"username":"teNYQYg","password":"RSvopaezd","email":"teNYQYg@gmail.com","firstName":"teNYQYg","lastName":"teNYQYg"}
  08:06:14.614 [shipping] 2024-11-23 08:06:14.614 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as
  08:06:15.803 [carts] 2024-11-23 08:06:15.803 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[DELETE],produces=[applicat
  08:06:15.906 [carts] 2024-11-23 08:06:15.903 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http.
  08:06:17.803 [shipping] 2024-11-23 08:06:17.803 INFO [shipping,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:06:19.102 [carts] 2024-11-23 08:06:19.102 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  08:06:21.902 [carts] 2024-11-23 08:06:21.902 INFO [carts,,,] 7 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  08:06:24.399 [carts] 2024-11-23 08:06:24.399 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server as  (×2)
  08:06:26.904 [front-end] Posting Customer: {"username":"BPBpJa","password":"ItmzyVAteC","email":"BPBpJa@gmail.com","firstName":"BPBpJa","lastName":"BPBpJa"}
  08:06:30.125 [front-end] Posting Customer: {"username":"dRUZXQgdp","password":"cwnWjNOrJ","email":"dRUZXQgdp@gmail.com","firstName":"dRUZXQgdp","lastName":"dRUZXQgdp"}
  08:06:31.898 [carts-db] {"t":{"$date":"2024-11-23T08:06:31.898+00:00"},"s":"I", "c":"COMMAND", "id":51803, "ctx":"conn5","msg":"Slow query","attr":{"type":"command","ns":"data.cart","c  (×7)
  08:06:34.206 [carts-db] {"t":{"$date":"2024-11-23T08:06:34.206+00:00"},"s":"I", "c":"STORAGE", "id":20320, "ctx":"conn18","msg":"createCollection","attr":{"namespace":"data.item","uuid  (×4)
  08:06:35.460 [user] ts=2024-11-23T08:06:35.460766063Z caller=middlewares.go:46 method=Register username=KarxuPo email=KarxuPo@gmail.com took=2.092813ms
  08:06:36.203 [front-end] Order response: {"id":"67418d0c3f77060008864e41","customerId":"67418cf9a437380001deeca9","customer":{"id":null,"firstName":"WPDZdEO","lastName":"WPDZdEO","usern
  08:06:40.900 [queue-master] 2024-11-23 08:06:40.900 WARN 7 --- [enerContainer-1] s.a.r.l.ConditionalRejectingErrorHandler : Execution of Rabbit message listener failed. 
  08:06:42.727 [front-end] Posting Customer: {"username":"gSjFQJm","password":"OxlJt","email":"gSjFQJm@gmail.com","firstName":"gSjFQJm","lastName":"gSjFQJm"}
  08:06:43.932 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d133f77060008864e46","customerId":"67418d02a437380001deecbf","customer":{"id":null,"firstName":"fdgssjehHZF
  08:06:48.331 [user] ts=2024-11-23T08:06:48.331118952Z caller=middlewares.go:46 method=Register username=BmPHiTV email=BmPHiTV@gmail.com took=3.505554ms
  08:06:50.777 [front-end] Posting Customer: {"username":"NSgcFqspcTI","password":"wXFWROad","email":"NSgcFqspcTI@gmail.com","firstName":"NSgcFqspcTI","lastName":"NSgcFqspcTI"}
  08:06:53.745 [front-end] Received response: "{\"firstName\":\"BPBpJa\",\"lastName\":\"BPBpJa\",\"username\":\"BPBpJa\",\"id\":\"67418d02a437380001deecc5\",\"_links\":{\"addresses\":{\"h
  08:06:57.037 [front-end] Posting Customer: {"username":"BNubDLDMJ","password":"vrjABP","email":"BNubDLDMJ@gmail.com","firstName":"BNubDLDMJ","lastName":"BNubDLDMJ"}
  08:07:01.019 [front-end] Posting Customer: {"username":"oEhJNpAenPQ","password":"shPGWpDQKM","email":"oEhJNpAenPQ@gmail.com","firstName":"oEhJNpAenPQ","lastName":"oEhJNpAenPQ"}
  08:07:03.453 [front-end] Posting Customer: {"username":"hHThr","password":"AXeArh","email":"hHThr@gmail.com","firstName":"hHThr","lastName":"hHThr"}

## p0537
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-price-service, 2024-12-07T18:15:19.793Z
```
{"timestamp":1733595319793020700,"container_name":"ts-price-service","pod_name":"ts-price-service-cfd9c8548-s4ptl","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 18:15:19.792  INFO 1 --- [io-16579-exec-3] price.service.PriceServiceImpl           : [Price Service][Find By Route And Train Type] Rote: a3f256c1-0e43-4f7d-9c21-121bf258101f   Train Type: GaoTieOne"}
```
Same service, the 2 minutes before (oldest first):
  18:14:54.014 [ts-price-service] 2024-12-07 18:14:54.013 INFO 1 --- [io-16579-exec-7] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: f3d4d4ef-693b-4456-8ee  (×7)
  18:14:54.017 [ts-price-service] 2024-12-07 18:14:54.017 INFO 1 --- [io-16579-exec-7] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×7)
  18:14:56.095 [ts-price-service] 2024-12-07 18:14:56.094 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: f3d4d4ef-693b-4456-8ee
  18:14:56.098 [ts-price-service] 2024-12-07 18:14:56.097 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]
All services, 30 seconds either side (sampled):
  18:14:53.638 [ts-auth-service] 2024-12-07 18:14:53.637 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×9)
  18:14:53.882 [ts-travel2-service] 2024-12-07 18:14:53.882 INFO 1 --- [io-16346-exec-9] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×9)
  18:14:53.941 [ts-travel-service] 2024-12-07 18:14:53.940 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×17)
  18:14:54.001 [ts-route-service] 2024-12-07 18:14:54.001 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: f3d4d4ef-693b-4456-8eed-59c0d717dd08  (×25)
  18:14:54.037 [ts-basic-service] 2024-12-07 18:14:54.037 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : route.getDistances().size : 2  (×16)
  18:14:54.181 [ts-basic-service] 2024-12-07 18:14:54.180 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×3)
  18:14:54.211 [ts-travel-service] 2024-12-07 18:14:54.211 INFO 1 --- [io-12346-exec-4] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×7)
  18:14:54.393 [ts-travel2-service] 2024-12-07 18:14:54.393 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×18)
  18:14:54.562 [ts-auth-service] 2024-12-07 18:14:54.561 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×11)
  18:14:54.735 [ts-food-service] 2024-12-07 18:14:54.735 INFO 1 --- [io-18856-exec-5] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!  (×2)
  18:14:54.872 [ts-preserve-service] 2024-12-07 18:14:54.872 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security
  18:14:54.915 [ts-security-service] 2024-12-07 18:14:54.914 INFO 1 --- [io-11188-exec-4] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Getting....
  18:14:54.968 [ts-contacts-service] 2024-12-07 18:14:54.968 INFO 1 --- [io-12347-exec-4] contacts.controller.ContactsController : [ContactsService][Contacts Id Print] b0f23465-83b1-4055-b110-ecd14
  18:14:55.184 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:14:55 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×13)
  18:14:56.209 [ts-seat-service] 2024-12-07 18:14:56.209 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService distributeSeat] TrainNumber start with G|D
  18:14:56.304 [ts-order-service] 2024-12-07 18:14:56.304 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Verify Login] Success
  18:14:56.341 [ts-preserve-service] 2024-12-07 18:14:56.341 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Preserve Service][Add food Order] Creating....
  18:14:56.633 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:14:56 +0800] "GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1" 200 202 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×23)
  18:15:01.125 [ts-basic-service] 2024-12-07 18:15:01.125 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×5)
  18:15:01.403 [ts-order-other-service] 2024-12-07 18:15:01.402 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×7)
  18:15:05.919 [ts-admin-travel-service] 2024-12-07 18:15:05.918 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)
  18:15:18.752 [ts-travel-service] 2024-12-07 18:15:18.752 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×11)
  18:15:18.921 [ts-travel-service] 2024-12-07 18:15:18.921 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr  (×6)
  18:15:19.249 [ts-basic-service] 2024-12-07 18:15:19.249 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f  (×2)
  18:15:20.095 [ts-seat-service] 2024-12-07 18:15:20.094 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×2)
  18:15:27.444 [ts-config-mongo] {"t":{"$date":"2024-12-07T18:15:27.444+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359532
  18:15:29.738 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:15:29.738+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359532
  18:15:30.642 [ts-user-mongo] {"t":{"$date":"2024-12-07T18:15:30.642+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359533
  18:15:32.290 [ts-order-service] 2024-12-07 18:15:32.290 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×2)
  18:15:46.488 [ts-basic-service] 2024-12-07 18:15:46.488 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2

## p0501
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:12:46.383Z
```
{"timestamp":1732353166383507500,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:12:46.383434218Z caller=middlewares.go:75 method=GetUsers id=67419c71a437380001df0acb result=1 took=2.520689ms"}
```
Same service, the 2 minutes before (oldest first):
  09:12:41.126 [user] ts=2024-11-23T09:12:41.126436024Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419c7fa437380001df0af6 took=3.854768ms  (×3)
  09:12:41.141 [user] ts=2024-11-23T09:12:41.140985444Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419c7fa437380001df0af6 took=3.893518ms  (×3)
  09:12:41.257 [user] ts=2024-11-23T09:12:41.257612918Z caller=middlewares.go:46 method=Register username=VvKvHi email=VvKvHi@gmail.com took=2.089074ms
  09:12:41.616 [user] ts=2024-11-23T09:12:41.616843221Z caller=middlewares.go:46 method=Register username=HDqViczn email=HDqViczn@gmail.com took=2.935051ms
  09:12:42.498 [user] ts=2024-11-23T09:12:42.498350423Z caller=middlewares.go:75 method=GetUsers id=67419c7aa437380001df0aed result=1 took=2.296282ms  (×5)
  09:12:43.009 [user] ts=2024-11-23T09:12:43.00932296Z caller=middlewares.go:46 method=Register username=QEEzDkzqOx email=QEEzDkzqOx@gmail.com took=2.330056ms  (×4)
  09:12:43.664 [user] ts=2024-11-23T09:12:43.663942953Z caller=middlewares.go:46 method=Register username=aDRJB email=aDRJB@gmail.com took=2.507339ms
  09:12:43.849 [user] ts=2024-11-23T09:12:43.849345453Z caller=middlewares.go:157 method=Health result=2 took=1.877309ms  (×2)
All services, 30 seconds either side (sampled):
  09:12:16.453 [front-end] Request received with body: {}  (×67)
  09:12:16.490 [orders] 2024-11-23 09:12:16.489 ERROR [orders,3266b89985f13148,ea54c9ecacd183e7,false] 7 --- [p-nio-80-exec-4] o.s.d.r.w.RepositoryRestExceptionHandler : Could not read  (×61)
  09:12:16.570 [user] ts=2024-11-23T09:12:16.570311002Z caller=middlewares.go:46 method=Register username=sbpGBAZDwAmmZ email=sbpGBAZDwAmmZ@gmail.com took=2.556064ms  (×33)
  09:12:16.599 [front-end] POST /register 200 35.452 ms - 33  (×59)
  09:12:17.399 [front-end] POST /cards 200 - ms - -  (×62)
  09:12:17.508 [carts] 2024-11-23 09:12:17.508 INFO [carts,9d173ec1a4e051e4,8da0e994855a6361,false] 7 --- [-nio-80-exec-17] w.w.s.cart.controllers.ItemsController : Did not find item.  (×27)
  09:12:18.441 [front-end] Received response: "{\"firstName\":\"rCxmFVCsVUZ\",\"lastName\":\"rCxmFVCsVUZ\",\"username\":\"rCxmFVCsVUZ\",\"id\":\"67419c5fa437380001df0a8b\",\"_links\":{\"a
  09:12:19.688 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×4)
  09:12:20.944 [front-end] Posting Customer: {"username":"FgKsbgzspIL","password":"IrXjLpQr","email":"FgKsbgzspIL@gmail.com","firstName":"FgKsbgzspIL","lastName":"FgKsbgzspIL"}
  09:12:25.599 [front-end] Received response: "{\"firstName\":\"CiYydMIc\",\"lastName\":\"CiYydMIc\",\"username\":\"CiYydMIc\",\"id\":\"67419c61a437380001df0a97\",\"_links\":{\"addresses\
  09:12:26.866 [user] ts=2024-11-23T09:12:26.865963061Z caller=middlewares.go:46 method=Register username=gscExKGkP email=gscExKGkP@gmail.com took=2.651685ms
  09:12:30.986 [front-end] Posting Customer: {"username":"uJdnamoMw","password":"RtOCHR","email":"uJdnamoMw@gmail.com","firstName":"uJdnamoMw","lastName":"uJdnamoMw"}
  09:12:32.964 [front-end] Posting Customer: {"username":"ubmrxZKcM","password":"QnMluh","email":"ubmrxZKcM@gmail.com","firstName":"ubmrxZKcM","lastName":"ubmrxZKcM"}
  09:12:36.074 [front-end] Received response: "{\"firstName\":\"rvWWjkuG\",\"lastName\":\"rvWWjkuG\",\"username\":\"rvWWjkuG\",\"id\":\"67419c6da437380001df0abb\",\"_links\":{\"addresses\
  09:12:38.653 [front-end] Posting Customer: {"username":"MwpBQXhvSX","password":"NHeFX","email":"MwpBQXhvSX@gmail.com","firstName":"MwpBQXhvSX","lastName":"MwpBQXhvSX"}
  09:12:41.257 [user] ts=2024-11-23T09:12:41.257612918Z caller=middlewares.go:46 method=Register username=VvKvHi email=VvKvHi@gmail.com took=2.089074ms
  09:12:45.992 [front-end] Posting Customer: {"username":"QhIvYWMSUvXq","password":"bauJR","email":"QhIvYWMSUvXq@gmail.com","firstName":"QhIvYWMSUvXq","lastName":"QhIvYWMSUvXq"}
  09:12:48.875 [front-end] Posting Customer: {"username":"uzzlQek","password":"JJLNSRrr","email":"uzzlQek@gmail.com","firstName":"uzzlQek","lastName":"uzzlQek"}
  09:12:50.328 [user] ts=2024-11-23T09:12:50.328453855Z caller=middlewares.go:46 method=Register username=OqxPK email=OqxPK@gmail.com took=3.675878ms
  09:12:54.950 [front-end] Received response: "{\"firstName\":\"KHKzkQzAyf\",\"lastName\":\"KHKzkQzAyf\",\"username\":\"KHKzkQzAyf\",\"id\":\"67419c7fa437380001df0af7\",\"_links\":{\"addr
  09:12:57.434 [front-end] Posting Customer: {"username":"gxCNZ","password":"UQftXAjMy","email":"gxCNZ@gmail.com","firstName":"gxCNZ","lastName":"gxCNZ"}
  09:12:58.407 [user] ts=2024-11-23T09:12:58.407085955Z caller=middlewares.go:46 method=Register username=kKldH email=kKldH@gmail.com took=1.881077ms
  09:13:00.692 [front-end] Received response: "{\"firstName\":\"oosumNeUjVvf\",\"lastName\":\"oosumNeUjVvf\",\"username\":\"oosumNeUjVvf\",\"id\":\"67419c85a437380001df0b02\",\"_links\":{
  09:13:02.825 [front-end] Received response: "{\"firstName\":\"HDqViczn\",\"lastName\":\"HDqViczn\",\"username\":\"HDqViczn\",\"id\":\"67419c89a437380001df0b16\",\"_links\":{\"addresses\
  09:13:07.206 [front-end] Received response: "{\"firstName\":\"QhIvYWMSUvXq\",\"lastName\":\"QhIvYWMSUvXq\",\"username\":\"QhIvYWMSUvXq\",\"id\":\"67419c8da437380001df0b1e\",\"_links\":{
  09:13:12.901 [front-end] Received response: "{\"firstName\":\"OFYNhINfZ\",\"lastName\":\"OFYNhINfZ\",\"username\":\"OFYNhINfZ\",\"id\":\"67419c99a437380001df0b4a\",\"_links\":{\"address
  09:13:15.453 [front-end] Received response: "{\"firstName\":\"gBOSRzephpQG\",\"lastName\":\"gBOSRzephpQG\",\"username\":\"gBOSRzephpQG\",\"id\":\"67419c97a437380001df0b41\",\"_links\":{

## p0576
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:05.567Z
```
{"timestamp":1733596265567762400,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:05.566  INFO 1 --- [           main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in globalExceptionHandler"}
```
Same service, the 2 minutes before (oldest first):
  18:31:03.486 [ts-auth-service] 2024-12-07 18:31:03.485 INFO 1 --- [ main] o.s.i.config.IntegrationRegistrar : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. The
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
  18:31:03.868 [ts-auth-service] 2024-12-07 18:31:03.868 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[application/vnd.sprin
  18:31:03.868 [ts-auth-service] 2024-12-07 18:31:03.868 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/vnd.spring-boot.
  18:31:03.868 [ts-auth-service] 2024-12-07 18:31:03.868 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/vnd.spring-bo
  18:31:03.869 [ts-auth-service] 2024-12-07 18:31:03.869 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  18:31:03.869 [ts-auth-service] 2024-12-07 18:31:03.869 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[application/vnd.sprin
  18:31:03.869 [ts-auth-service] 2024-12-07 18:31:03.869 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/auditevents || /auditevents.json],methods=[GET],produces=[applicati
  18:31:03.871 [ts-auth-service] 2024-12-07 18:31:03.871 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.871 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.872 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.872 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics || /metrics.json],methods=[GET],produces=[application/vnd.s
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.872 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/vnd.spring-
  18:31:03.873 [ts-auth-service] 2024-12-07 18:31:03.873 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces=[applicati
  18:31:03.874 [ts-auth-service] 2024-12-07 18:31:03.873 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[application/vnd
  18:31:04.061 [ts-auth-service] 2024-12-07 18:31:04.061 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.boot.actuate.autoconfigure.Manageme
  18:31:05.058 [ts-auth-service] 2024-12-07 18:31:05.057 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.embedded.A
All services, 30 seconds either side (sampled):
  18:30:36.068 [ts-auth-service] 2024-12-07 18:30:36.068 INFO 1 --- [ main] o.s.i.config.IntegrationRegistrar : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. The  (×2)
  18:30:37.767 [ts-basic-service] 2024-12-07 18:30:37.766 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×16)
  18:30:37.816 [ts-basic-service] 2024-12-07 18:30:37.815 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3  (×19)
  18:30:37.888 [ts-travel2-service] 2024-12-07 18:30:37.887 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×24)
  18:30:38.000 [ts-travel2-service] 2024-12-07 18:30:37.999 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6  (×11)
  18:30:40.487 [ts-basic-service] 2024-12-07 18:30:40.487 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×6)
  18:30:40.692 [ts-travel2-service] 2024-12-07 18:30:40.692 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×2)
  18:30:41.733 [ts-basic-service] 2024-12-07 18:30:41.733 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×9)
  18:30:42.403 [ts-food-service] 2024-12-07 18:30:42.403 INFO 1 --- [io-18856-exec-3] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×2)
  18:30:44.984 [ts-travel2-service] 2024-12-07 18:30:44.983 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  18:30:47.149 [ts-travel-service] 2024-12-07 18:30:47.149 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×6)
  18:30:47.235 [ts-order-service] 2024-12-07 18:30:47.234 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 38  (×6)
  18:30:47.299 [ts-order-service] 2024-12-07 18:30:47.299 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160,   (×5)
  18:30:51.661 [ts-auth-service] 2024-12-07 18:30:51.661 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClust
  18:30:57.085 [ts-seat-service] 2024-12-07 18:30:57.085 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×3)
  18:30:58.183 [ts-order-other-service] 2024-12-07 18:30:58.182 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×2)
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.872 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  18:31:04.698 [ts-seat-service] 2024-12-07 18:31:04.698 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  18:31:10.954 [ts-auth-service] 2024-12-07 18:31:10.953 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.907 seconds (JVM running for 71.147)
  18:31:11.909 [ts-basic-service] 2024-12-07 18:31:11.909 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  18:31:19.676 [ts-travel2-service] 2024-12-07 18:31:19.676 ERROR 1 --- [o-16346-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:31:27.403 [ts-travel-mongo] {"t":{"$date":"2024-12-07T18:31:27.403+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:29.428 [ts-assurance-service] 2024-12-07 18:31:29.428 ERROR 1 --- [io-18888-exec-7] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:31:30.519 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T18:31:30.518+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:31.698 [ts-order-service] 2024-12-07 18:31:31.698 ERROR 1 --- [io-12031-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt

## p0695
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-12T11:25:05.500Z
```
{"service":"dbservice1","message":"2021-08-12 11:25:05,500 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | b7c76ceafe00d982 | e2ce81ea-fb1c-11eb-a273-0242ac110004-vLPzKelQ-H:yjVplx2YI= token generate success token=MTYyODczODcwNS41MDAxNDIzOmUyY2U4MWVhLWZiMWMtMTFlYi1hMjczLTAyNDJhYzExMDAwNHZMUHpLZWxRSDp5alZwbHgyWUk9OjE2Mjg3Mzg3NjUuNTAwMTUzOmY2MWJlM2M1MjJmYTIyZDBkYzcyMzQwNzYxYWM2NjQx"}
```
Same service, the 2 minutes before (oldest first):
  11:25:01.210 [dbservice1] INFO query = select passwards from username_table where user_name='ZRAoufan'  (×5)
  11:25:01.301 [dbservice1] INFO e043dcb8-fb1c-11eb-b9b2-0242ac110004-ZRAoufan-@?BJFA*^Cha_ token generate success token=MTYyODczODcwMS4zMDA5ODA2OmUwNDNkY2I4LWZiMWMtMTFlYi1iOWIyLTAyNDJhYzE
  11:25:01.977 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  11:25:01.977 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  11:25:02.087 [dbservice1] INFO e0c8ce50-fb1c-11eb-8ead-0242ac110003-zxoeJtIu--mO?#>J+iEIB token generate success token=MTYyODczODcwMi4wODcxMjE6ZTBjOGNlNTAtZmIxYy0xMWViLThlYWQtMDI0MmFjMTE
  11:25:03.041 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  11:25:03.855 [dbservice1] INFO e1c1eb3e-fb1c-11eb-86d7-0242ac110004-uloJcsne-s12=_60+_kX- token generate success token=MTYyODczODcwMy44NTUyNDE1OmUxYzFlYjNlLWZiMWMtMTFlYi04NmQ3LTAyNDJhYzE
  11:25:04.709 [dbservice1] INFO e24beb36-fb1c-11eb-98c2-0242ac110004-eRTPmDsV-Q!>Vw29I<Kh& token generate success token=MTYyODczODcwNC43MDkwNDUyOmUyNGJlYjM2LWZiMWMtMTFlYi05OGMyLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  11:24:35.567 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  11:24:35.625 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×41)
  11:24:35.668 [webservice1] INFO uuid: d16a731e-fb1c-11eb-aec7-0242ac110003 write redis successfully  (×30)
  11:24:35.793 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×30)
  11:24:36.066 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×25)
  11:24:36.269 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×25)
  11:24:36.820 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×37)
  11:24:37.073 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×37)
  11:24:38.234 [mobservice1] INFO info d2bb33a2-fb1c-11eb-b950-0242ac110004:ICpXWslJ write success
  11:24:40.411 [mobservice1] INFO info d409451e-fb1c-11eb-9560-0242ac110003:YDlrGqAK write success
  11:24:42.860 [dbservice1] INFO d543ae74-fb1c-11eb-85fb-0242ac110003-URMboZjf-a!7vBu@Ms{3G token generate success token=MTYyODczODY4Mi44NjAzNTQyOmQ1NDNhZTc0LWZiMWMtMTFlYi04NWZiLTAyNDJhYzE
  11:24:45.246 [mobservice2] INFO info d6eb6ca8-fb1c-11eb-8fc4-0242ac110004:ciMhOCvb write success
  11:24:53.590 [mobservice2] INFO info dbf1d016-fb1c-11eb-bc66-0242ac110003:QlZMgGXD write success
  11:24:57.043 [logservice2] ERROR get information failed, fail code: 400
  11:24:59.339 [mobservice2] INFO info df5a0dea-fb1c-11eb-938a-0242ac110004:aejQpHvi write success
  11:25:01.744 [mobservice2] INFO info e0c8ce50-fb1c-11eb-8ead-0242ac110003:zxoeJtIu write success
  11:25:03.855 [dbservice1] INFO e1c1eb3e-fb1c-11eb-86d7-0242ac110004-uloJcsne-s12=_60+_kX- token generate success token=MTYyODczODcwMy44NTUyNDE1OmUxYzFlYjNlLWZiMWMtMTFlYi04NmQ3LTAyNDJhYzE  (×2)
  11:25:06.352 [dbservice2] INFO e34afc0c-fb1c-11eb-94d3-0242ac110003-bypSvsJC-Y6tx3Buhf<)p token generate success token=MTYyODczODcwNi4zNTE1NDY1OmUzNGFmYzBjLWZiMWMtMTFlYi05NGQzLTAyNDJhYzE
  11:25:08.683 [dbservice2] INFO e4b49a08-fb1c-11eb-92b9-0242ac110004-SpJzmrVL-uO+f&?:*M^mq token generate success token=MTYyODczODcwOC42ODI4NDU0OmU0YjQ5YTA4LWZiMWMtMTFlYi05MmI5LTAyNDJhYzE
  11:25:11.345 [mobservice2] INFO info e67dc5bc-fb1c-11eb-b4fb-0242ac110004:LNTWaneB write success
  11:25:14.321 [mobservice2] INFO info e845facc-fb1c-11eb-a88f-0242ac110003:vOcCSRZA write success
  11:25:16.756 [mobservice1] INFO info e9b767a6-fb1c-11eb-86da-0242ac110003:TrtKhHmF write success
  11:25:19.408 [dbservice1] INFO eb1ce058-fb1c-11eb-9104-0242ac110003-WstfjpFZ-YcH?Ldv+PQIR token generate success token=MTYyODczODcxOS40MDg1MjE6ZWIxY2UwNTgtZmIxYy0xMWViLTkxMDQtMDI0MmFjMTE
  11:25:21.555 [mobservice1] INFO info ec9e4ec6-fb1c-11eb-96b5-0242ac110003:gQaRFlxY write success
  11:25:24.022 [dbservice2] INFO edaaca56-fb1c-11eb-8ea6-0242ac110004-ySjkNPYT-D^=b(51nchk< token generate success token=MTYyODczODcyNC4wMjE2MjE1OmVkYWFjYTU2LWZiMWMtMTFlYi04ZWE2LTAyNDJhYzE
  11:25:31.914 [dbservice1] INFO f26a6af6-fb1c-11eb-a139-0242ac110003-oYbSglqf-udHk_>z3F5*y token generate success token=MTYyODczODczMS45MTM1NjM1OmYyNmE2YWY2LWZiMWMtMTFlYi1hMTM5LTAyNDJhYzE
  11:25:35.086 [mobservice2] INFO info f48d4cb8-fb1c-11eb-b3f0-0242ac110003:ulnvrqij write success

## p0118
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:17:43.839Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731907063839696600,"container_name":"adservice","pod_name":"adservice-574c5fd7b4-tmkhn","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Stats enabled, but temporarily unavailable"}
```
Same service, the 2 minutes before (oldest first):
  05:17:34.919 [adservice] received ad request (context_words=[footwear])  (×2)
  05:17:34.960 [adservice] received ad request (context_words=[hair, beauty])  (×5)
  05:17:35.730 [adservice] received ad request (context_words=[kitchen])  (×3)
  05:17:36.105 [adservice] received ad request (context_words=[accessories])  (×2)
  05:17:37.384 [adservice] received ad request (context_words=[clothing, tops])  (×3)
  05:17:38.820 [adservice] received ad request (context_words=[])  (×2)
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:40.213 [adservice] *** server shut down
  05:17:43.747 [adservice] AdService starting.
All services, 30 seconds either side (sampled):
  05:17:14.375 [frontend] request started  (×281)
  05:17:14.382 [cartservice] GetCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×239)
  05:17:14.401 [shippingservice] [GetQuote] completed request  (×79)
  05:17:14.842 [frontend] serving product page  (×128)
  05:17:14.988 [frontend] home  (×32)
  05:17:15.286 [adservice] received ad request (context_words=[accessories])  (×10)
  05:17:16.598 [adservice] received ad request (context_words=[kitchen])  (×24)
  05:17:16.663 [frontend] placing order  (×7)
  05:17:16.693 [paymentservice] Transaction processed: visa ending 5701 Amount: TRY1792.226454698  (×4)
  05:17:16.696 [shippingservice] [ShipOrder] completed request  (×7)
  05:17:16.706 [checkoutservice] order confirmation email sent to "abowman@example.com"
  05:17:16.825 [checkoutservice] order confirmation email sent to "barbara24@example.com"
  05:17:24.080 [adservice] received ad request (context_words=[decor, home])  (×6)
  05:17:24.111 [paymentservice] Transaction processed: visa ending 1703 Amount: CAD346.438559926  (×2)
  05:17:25.127 [emailservice] A request to send order confirmation email to coxchristine@example.net has been received.
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:40.406 [frontend] failed to retrieve ads  (×84)
  05:17:43.841 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.  (×2)
  05:17:45.450 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  05:17:53.543 [adservice] Stats enabled, but temporarily unavailable
  05:17:55.262 [paymentservice] Transaction processed: visa ending 8741 Amount: EUR679.655019909
  05:18:02.298 [emailservice] A request to send order confirmation email to caseyhoward@example.com has been received.

## p0286
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:34:01.704Z
```
{"timestamp":1732242841704172800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"673fed99b0df5c00019afd98"}
```
Same service, the 2 minutes before (oldest first):
  02:34:01.138 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fed90b0df5c00019afd82\",\"_links\":{\"  (×2)
  02:34:01.138 [front-end] [ undefined, undefined ]  (×2)
  02:34:01.138 [front-end] Posting Order: {"customer":"http://user/customers/673fed87b0df5c00019afd62","address":"http://user/addresses/673fed90b0df5c00019afd81","card":"http://user/cards  (×2)
  02:34:01.157 [front-end] Carts merged.
  02:34:01.157 [front-end] set cookie673fed99b0df5c00019afd97
  02:34:01.157 [front-end] Sent cookies.
  02:34:01.160 [front-end] POST /register 200 25.503 ms - 33
  02:34:01.175 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed99d94b9000069b3b07","customerId":"673fed87b0df5c00019afd62","customer":{"id":null,"firstName":"KtDORbMQrXF
  02:34:01.175 [front-end] Order response: {"id":"673fed99d94b9000069b3b07","customerId":"673fed87b0df5c00019afd62","customer":{"id":null,"firstName":"KtDORbMQrXFgMTT","lastName":"KtDORbM
  02:34:01.178 [front-end] POST /orders 201 - ms - -
  02:34:01.656 [front-end] Request received with body: {}
  02:34:01.663 [front-end] Received response: "{\"firstName\":\"tiZilkkvzQWQLw\",\"lastName\":\"tiZilkkvzQWQLw\",\"username\":\"tiZilkkvzQWQLw\",\"id\":\"673fed83b0df5c00019afd52\",\"_lin
  02:34:01.663 [front-end] GET Request to: http://user/customers/673fed83b0df5c00019afd52/addresses  (×2)
  02:34:01.671 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:34:01.698 [front-end] Posting Customer: {"username":"lmxkWDWmHgaK","password":"EIoPEL","email":"lmxkWDWmHgaK@gmail.com","firstName":"lmxkWDWmHgaK","lastName":"lmxkWDWmHgaK"}
  02:34:01.704 [front-end] { id: '673fed99b0df5c00019afd98' }
All services, 30 seconds either side (sampled):
  02:33:31.708 [front-end] User cart deleted with status: 202  (×65)
  02:33:31.840 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fed76b0df5c00019afd2c"}  (×64)
  02:33:32.033 [user] ts=2024-11-22T02:33:32.033019384Z caller=middlewares.go:75 method=GetUsers id=673fed68b0df5c00019afd05 result=1 took=976.741µs  (×177)
  02:33:32.151 [shipping] Adding shipment to queue...  (×51)
  02:33:32.205 [front-end] 673fed7cb0df5c00019afd3c  (×62)
  02:33:32.367 [front-end] Order response: {"id":"673fed7cd94b9000069b3af1","customerId":"673fed6bb0df5c00019afd0d","customer":{"id":null,"firstName":"RoQVUJK","lastName":"RoQVUJK","usern
  02:33:34.164 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed7ed94b9000069b3af3","customerId":"673fed69b0df5c00019afd06","customer":{"id":null,"firstName":"geLOLRZuTes
  02:33:36.516 [front-end] Order response: {"id":"673fed80d94b9000069b3af4","customerId":"673fed6cb0df5c00019afd13","customer":{"id":null,"firstName":"fcaqvgi","lastName":"fcaqvgi","usern
  02:33:39.037 [user] ts=2024-11-22T02:33:39.037421577Z caller=middlewares.go:46 method=Register username=ULDviaMi email=ULDviaMi@gmail.com took=976.123µs
  02:33:41.663 [payment] ts=2024-11-22T02:33:41Z caller=logging.go:29 method=Authorise result=false took=7.436µs  (×6)
  02:33:43.457 [front-end] Posting Customer: {"username":"fquUlXT","password":"zwLNQjn","email":"fquUlXT@gmail.com","firstName":"fquUlXT","lastName":"fquUlXT"}
  02:33:46.671 [user] ts=2024-11-22T02:33:46.671189034Z caller=middlewares.go:46 method=Register username=uLMznMqh email=uLMznMqh@gmail.com took=1.022496ms
  02:33:47.326 [front-end] Order response: {"id":"673fed8bd94b9000069b3afb","customerId":"673fed7db0df5c00019afd3d","customer":{"id":null,"firstName":"JQQRJtvdb","lastName":"JQQRJtvdb","u
  02:33:50.417 [front-end] Received response: "{\"firstName\":\"UcprrDqtTboEOD\",\"lastName\":\"UcprrDqtTboEOD\",\"username\":\"UcprrDqtTboEOD\",\"id\":\"673fed79b0df5c00019afd35\",\"_lin
  02:33:52.146 [front-end] Posting Customer: {"username":"zChpPcvAuCjkHis","password":"IcSNuwSXm","email":"zChpPcvAuCjkHis@gmail.com","firstName":"zChpPcvAuCjkHis","lastName":"zChpPcvAuCj
  02:33:56.203 [front-end] Received response: "{\"firstName\":\"MrneIKw\",\"lastName\":\"MrneIKw\",\"username\":\"MrneIKw\",\"id\":\"673fed85b0df5c00019afd5a\",\"_links\":{\"addresses\":{
  02:33:59.003 [user] ts=2024-11-22T02:33:59.003322536Z caller=middlewares.go:46 method=Register username=mHHzjq email=mHHzjq@gmail.com took=1.022618ms
  02:34:01.175 [front-end] Order response: {"id":"673fed99d94b9000069b3b07","customerId":"673fed87b0df5c00019afd62","customer":{"id":null,"firstName":"KtDORbMQrXFgMTT","lastName":"KtDORbM
  02:34:04.063 [front-end] Order response: {"id":"673fed9cd94b9000069b3b0a","customerId":"673fed84b0df5c00019afd59","customer":{"id":null,"firstName":"XBkBDNMeahrbK","lastName":"XBkBDNMea
  02:34:06.745 [front-end] Received response: "{\"firstName\":\"fquUlXT\",\"lastName\":\"fquUlXT\",\"username\":\"fquUlXT\",\"id\":\"673fed87b0df5c00019afd5f\",\"_links\":{\"addresses\":{
  02:34:07.891 [front-end] Posting Customer: {"username":"FPDfkHHcUzTE","password":"QIQUZF","email":"FPDfkHHcUzTE@gmail.com","firstName":"FPDfkHHcUzTE","lastName":"FPDfkHHcUzTE"}
  02:34:11.950 [front-end] Order response: {"id":"673feda3d94b9000069b3b13","customerId":"673fed8ab0df5c00019afd64","customer":{"id":null,"firstName":"uLMznMqh","lastName":"uLMznMqh","use
  02:34:16.625 [front-end] Posting Customer: {"username":"nZgxrZdrCbMnJ","password":"FfUBlyxJ","email":"nZgxrZdrCbMnJ@gmail.com","firstName":"nZgxrZdrCbMnJ","lastName":"nZgxrZdrCbMnJ"}
  02:34:18.444 [front-end] Order response: {"id":"673fedaad94b9000069b3b17","customerId":"673fed9ab0df5c00019afd9a","customer":{"id":null,"firstName":"ARfXRutv","lastName":"ARfXRutv","use
  02:34:19.777 [front-end] Posting Customer: {"username":"fATjtrPxZ","password":"FELWXyOpp","email":"fATjtrPxZ@gmail.com","firstName":"fATjtrPxZ","lastName":"fATjtrPxZ"}
  02:34:21.784 [user] ts=2024-11-22T02:34:21.784392125Z caller=middlewares.go:46 method=Register username=KFkABcT email=KFkABcT@gmail.com took=1.032053ms
  02:34:23.877 [front-end] Posting Customer: {"username":"IWnZyHiEcX","password":"fgHxVbQ","email":"IWnZyHiEcX@gmail.com","firstName":"IWnZyHiEcX","lastName":"IWnZyHiEcX"}
  02:34:27.795 [carts-db] {"t":{"$date":"2024-11-22T02:34:27.795+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224286

## p0363
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:34:17.606Z
```
{"timestamp":1732246457606892500,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:34:17.606781931Z caller=middlewares.go:134 method=GetCards id=673ffbadb0df5c00019b28a7 result=1 took=928.503µs"}
```
Same service, the 2 minutes before (oldest first):
  03:34:14.708 [user] ts=2024-11-22T03:34:14.708564348Z caller=middlewares.go:75 method=GetUsers id=673ffba5b0df5c00019b288e result=1 took=992.797µs  (×8)
  03:34:14.734 [user] ts=2024-11-22T03:34:14.734392345Z caller=middlewares.go:104 method=GetAddresses id=673ffbacb0df5c00019b28a0 result=1 took=1.086588ms
  03:34:14.734 [user] ts=2024-11-22T03:34:14.734599489Z caller=middlewares.go:134 method=GetCards id=673ffbacb0df5c00019b28a1 result=1 took=1.114159ms
  03:34:14.882 [user] ts=2024-11-22T03:34:14.881915617Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffbb0b0df5c00019b28b3 took=1.833118ms  (×3)
  03:34:14.895 [user] ts=2024-11-22T03:34:14.894651575Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffbb0b0df5c00019b28b3 took=1.757833ms  (×3)
  03:34:15.094 [user] ts=2024-11-22T03:34:15.093882742Z caller=middlewares.go:157 method=Health result=2 took=708.078µs  (×2)
  03:34:16.850 [user] ts=2024-11-22T03:34:16.850064666Z caller=middlewares.go:46 method=Register username=cBiHCInttKC email=cBiHCInttKC@gmail.com took=1.042902ms
  03:34:16.879 [user] ts=2024-11-22T03:34:16.879763502Z caller=middlewares.go:46 method=Register username=fXiTCwDoJRK email=fXiTCwDoJRK@gmail.com took=954.362µs
All services, 30 seconds either side (sampled):
  03:33:47.679 [front-end] Posting Customer: {"username":"JpiXwirQ","password":"oZcsjrf","email":"JpiXwirQ@gmail.com","firstName":"JpiXwirQ","lastName":"JpiXwirQ"}
  03:33:48.292 [front-end] Posting Customer: {"username":"KCbzfTD","password":"MmQOdVy","email":"KCbzfTD@gmail.com","firstName":"KCbzfTD","lastName":"KCbzfTD"}
  03:33:48.414 [user] ts=2024-11-22T03:33:48.414140402Z caller=middlewares.go:46 method=Register username=FuoFZaB email=FuoFZaB@gmail.com took=987.11µs
  03:33:49.071 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff  (×60)
  03:33:49.327 [front-end] Received response: "{\"firstName\":\"SUWHgtC\",\"lastName\":\"SUWHgtC\",\"username\":\"SUWHgtC\",\"id\":\"673ffb88b0df5c00019b283d\",\"_links\":{\"addresses\":{
  03:33:51.273 [front-end] Received response: "{\"firstName\":\"ahHiz\",\"lastName\":\"ahHiz\",\"username\":\"ahHiz\",\"id\":\"673ffb8fb0df5c00019b2859\",\"_links\":{\"addresses\":{\"href
  03:33:57.419 [user] ts=2024-11-22T03:33:57.419681309Z caller=middlewares.go:46 method=Register username=msqlFl email=msqlFl@gmail.com took=1.067975ms
  03:34:00.299 [front-end] Posting Customer: {"username":"JBBrMbmKH","password":"jXwDMWlz","email":"JBBrMbmKH@gmail.com","firstName":"JBBrMbmKH","lastName":"JBBrMbmKH"}
  03:34:02.746 [front-end] Posting Customer: {"username":"QnXDnBV","password":"JdZvlASa","email":"QnXDnBV@gmail.com","firstName":"QnXDnBV","lastName":"QnXDnBV"}
  03:34:06.069 [front-end] Posting Customer: {"username":"XtmVoXKnmLWjJv","password":"Bmdwr","email":"XtmVoXKnmLWjJv@gmail.com","firstName":"XtmVoXKnmLWjJv","lastName":"XtmVoXKnmLWjJv"}
  03:34:09.188 [carts] 2024-11-22 03:34:09.187 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  03:34:11.880 [front-end] Received response: "{\"firstName\":\"PEasXcbSYy\",\"lastName\":\"PEasXcbSYy\",\"username\":\"PEasXcbSYy\",\"id\":\"673ffb9ab0df5c00019b286f\",\"_links\":{\"addr
  03:34:13.622 [user] ts=2024-11-22T03:34:13.622270819Z caller=middlewares.go:46 method=Register username=Umaupu email=Umaupu@gmail.com took=1.083971ms
  03:34:17.593 [front-end] Received response: "{\"firstName\":\"JBBrMbmKH\",\"lastName\":\"JBBrMbmKH\",\"username\":\"JBBrMbmKH\",\"id\":\"673ffba8b0df5c00019b2897\",\"_links\":{\"address
  03:34:21.300 [user] ts=2024-11-22T03:34:21.300406401Z caller=middlewares.go:46 method=Register username=WThrLlz email=WThrLlz@gmail.com took=947.281µs
  03:34:24.726 [front-end] Received response: "{\"firstName\":\"KyAFZsVVE\",\"lastName\":\"KyAFZsVVE\",\"username\":\"KyAFZsVVE\",\"id\":\"673ffbb4b0df5c00019b28c7\",\"_links\":{\"address
  03:34:25.988 [carts] 2024-11-22 03:34:25.988 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[OPTIONS],produces=[application/
  03:34:25.993 [carts] 2024-11-22 03:34:25.993 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces=
  03:34:28.320 [front-end] Received response: "{\"firstName\":\"QZykixJJv\",\"lastName\":\"QZykixJJv\",\"username\":\"QZykixJJv\",\"id\":\"673ffbaab0df5c00019b2899\",\"_links\":{\"address
  03:34:29.486 [carts] 2024-11-22 03:34:29.486 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:34:30.138 [front-end] Received response: "{\"firstName\":\"fXiTCwDoJRK\",\"lastName\":\"fXiTCwDoJRK\",\"username\":\"fXiTCwDoJRK\",\"id\":\"673ffbb8b0df5c00019b28d4\",\"_links\":{\"a
  03:34:35.327 [front-end] Posting Customer: {"username":"VXLZy","password":"IbaUfDbV","email":"VXLZy@gmail.com","firstName":"VXLZy","lastName":"VXLZy"}
  03:34:36.993 [front-end] Posting Customer: {"username":"zQvKZ","password":"FuvaONBz","email":"zQvKZ@gmail.com","firstName":"zQvKZ","lastName":"zQvKZ"}
  03:34:39.820 [front-end] Received response: "{\"firstName\":\"ucnVtZA\",\"lastName\":\"ucnVtZA\",\"username\":\"ucnVtZA\",\"id\":\"673ffbbdb0df5c00019b28e4\",\"_links\":{\"addresses\":{
  03:34:42.461 [user] ts=2024-11-22T03:34:42.461375917Z caller=middlewares.go:46 method=Register username=sQJwd email=sQJwd@gmail.com took=1.027405ms
  03:34:43.985 [front-end] Posting Customer: {"username":"BGzhPXmcTRG","password":"UMCnoqAI","email":"BGzhPXmcTRG@gmail.com","firstName":"BGzhPXmcTRG","lastName":"BGzhPXmcTRG"}
  03:34:44.712 [queue-master] 2024-11-22 03:34:44.712 INFO 6 --- [ool-6-thread-38] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×18)
  03:34:45.010 [front-end] Posting Customer: {"username":"aeNMEYsKkqlrZB","password":"PZmEJfbtAm","email":"aeNMEYsKkqlrZB@gmail.com","firstName":"aeNMEYsKkqlrZB","lastName":"aeNMEYsKkqlrZ
  03:34:46.594 [user] ts=2024-11-22T03:34:46.594397422Z caller=middlewares.go:46 method=Register username=vkmSdk email=vkmSdk@gmail.com took=1.006594ms

## p0577
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:18.474Z
```
{"timestamp":1733596278474764800,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:18.474  INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl       : LOGIN USER NEW:fdse_microservice __ 111111 __ null"}
```
Same service, the 2 minutes before (oldest first):
  18:31:08.680 [ts-auth-service] 2024-12-07 18:31:08.680 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.method.configuration.
  18:31:08.782 [ts-auth-service] 2024-12-07 18:31:08.782 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  18:31:09.063 [ts-auth-service] 2024-12-07 18:31:09.063 INFO 1 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  18:31:09.169 [ts-auth-service] 2024-12-07 18:31:09.168 INFO 1 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  18:31:09.181 [ts-auth-service] 2024-12-07 18:31:09.181 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact
  18:31:09.183 [ts-auth-service] 2024-12-07 18:31:09.183 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [java.util.Properties] is not e
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.466 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : Adding {logging-channel-adapter:_org.springframework.integration.errorLogger} as
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.467 INFO 1 --- [ main] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 1 subscriber(s).
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.467 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : started _org.springframework.integration.errorLogger
  18:31:09.955 [ts-auth-service] 2024-12-07 18:31:09.954 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 12340 (http)
  18:31:10.283 [ts-auth-service] 2024-12-07 18:31:10.283 INFO 1 --- [ main] org.mongodb.driver.connection : Opened connection [connectionId{localValue:2, serverValue:21}] to ts-auth-mongo:27017
  18:31:10.954 [ts-auth-service] 2024-12-07 18:31:10.953 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.907 seconds (JVM running for 71.147)
  18:31:13.283 [ts-auth-service] 2024-12-07 18:31:13.283 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 12340 (http)
  18:31:13.587 [ts-auth-service] 2024-12-07 18:31:13.586 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  18:31:13.587 [ts-auth-service] 2024-12-07 18:31:13.587 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43
  18:31:14.585 [ts-auth-service] 2024-12-07 18:31:14.585 INFO 1 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  18:31:14.585 [ts-auth-service] 2024-12-07 18:31:14.585 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 20107 ms
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  18:31:17.262 [ts-auth-service] 2024-12-07 18:31:17.262 INFO 1 --- [io-12340-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization completed in 100 m
All services, 30 seconds either side (sampled):
  18:30:49.008 [ts-admin-basic-info-service] 2024-12-07 18:30:49.007 INFO 1 --- [io-18767-exec-7] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×5)
  18:30:50.707 [ts-route-service] 2024-12-07 18:30:50.707 INFO 1 --- [io-11178-exec-6] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×92)
  18:30:50.758 [ts-price-service] 2024-12-07 18:30:50.757 INFO 1 --- [io-16579-exec-2] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×12)
  18:30:50.825 [ts-travel2-service] 2024-12-07 18:30:50.824 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×16)
  18:30:50.873 [ts-seat-service] 2024-12-07 18:30:50.873 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×25)
  18:30:52.263 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:30:52.262+00:00"},"s":"I", "c":"NETWORK", "id":51800, "ctx":"conn20","msg":"client metadata","attr":{"remote":"127.0.0.6:49147","cl  (×4)
  18:30:53.574 [ts-order-other-service] 2024-12-07 18:30:53.574 INFO 1 --- [io-12032-exec-4] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 24  (×7)
  18:30:57.097 [ts-seat-service] 2024-12-07 18:30:57.096 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  18:30:58.080 [ts-price-service] 2024-12-07 18:30:58.080 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×2)
  18:31:00.335 [ts-order-other-service] 2024-12-07 18:31:00.334 ERROR 1 --- [io-12032-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×4)
  18:31:01.656 [ts-auth-service] 2024-12-07 18:31:01.655 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  18:31:03.828 [ts-travel-service] 2024-12-07 18:31:03.828 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×25)
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  18:31:03.871 [ts-auth-service] 2024-12-07 18:31:03.871 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  18:31:03.909 [ts-travel-service] 2024-12-07 18:31:03.909 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×5)
  18:31:04.007 [ts-travel-service] 2024-12-07 18:31:04.006 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×10)
  18:31:05.567 [ts-auth-service] 2024-12-07 18:31:05.566 INFO 1 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in globalExceptionHandler
  18:31:08.782 [ts-auth-service] 2024-12-07 18:31:08.782 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  18:31:10.954 [ts-auth-service] 2024-12-07 18:31:10.953 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.907 seconds (JVM running for 71.147)
  18:31:11.909 [ts-basic-service] 2024-12-07 18:31:11.909 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f
  18:31:12.420 [ts-travel-service] 2024-12-07 18:31:12.420 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan
  18:31:18.474 [ts-auth-service] 2024-12-07 18:31:18.474 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×9)
  18:31:19.676 [ts-travel2-service] 2024-12-07 18:31:19.676 ERROR 1 --- [io-16346-exec-2] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×9)
  18:31:27.257 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:31:27.257+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.270 [ts-admin-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×5)
  18:31:29.947 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:31:29.947+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  18:31:38.105 [ts-admin-travel-service] 2024-12-07 18:31:38.104 ERROR 1 --- [o-16114-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt

## p0084
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T13:56:14.343Z
```
{"service":"logservice1","message":"2021-08-13 13:56:14,343 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | fa95b684e8f79e3 | the list of all available services are logservice2: http://0.0.0.2:9385"}
```
Same service, the 2 minutes before (oldest first):
  13:56:11.251 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×2)
  13:56:11.252 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '28fe6a98-fbfb-11eb-bc1f-0242ac110004', 'user_id': 'rJNyXqRj'}  (×5)
  13:56:11.842 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  13:56:11.843 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  13:56:11.843 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '295ea516-fbfb-11eb-85e7-0242ac110004'}  (×2)
  13:56:11.902 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385
  13:56:12.749 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×3)
  13:56:12.750 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×3)
All services, 30 seconds either side (sampled):
  13:55:44.379 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×42)
  13:55:44.461 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×39)
  13:55:44.644 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×48)
  13:55:44.774 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×45)
  13:55:45.072 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  13:55:45.910 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×43)
  13:55:46.387 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  13:55:47.364 [mobservice2] INFO info 1accdcfc-fbfb-11eb-968e-0242ac110004:GtreMfPE write success
  13:55:48.107 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  13:55:50.744 [dbservice1] INFO 1c9d8996-fbfb-11eb-a2ce-0242ac110004-OZQbWUnN-JZWKL/bk*-mD token generate success token=MTYyODgzNDE1MC43NDQ1MDM1OjFjOWQ4OTk2LWZiZmItMTFlYi1hMmNlLTAyNDJhYzE
  13:55:53.671 [dbservice1] INFO 1e50175e-fbfb-11eb-8856-0242ac110003-dDmGvhol-!a=hY&k)-9}v token generate success token=MTYyODgzNDE1My42NzEzOTQ2OjFlNTAxNzVlLWZiZmItMTFlYi04ODU2LTAyNDJhYzE
  13:55:56.362 [mobservice2] INFO info 202b5a34-fbfb-11eb-b486-0242ac110003:SjMAKXaq write success
  13:55:59.349 [mobservice2] INFO info 21e65338-fbfb-11eb-bad0-0242ac110004:JZinoGDa write success
  13:56:02.397 [mobservice1] INFO info 23b0dbb6-fbfb-11eb-822d-0242ac110003:ORjBsXZy write success
  13:56:05.154 [mobservice1] INFO info 25668316-fbfb-11eb-836d-0242ac110004:AGLgdhsM write success
  13:56:08.173 [dbservice1] INFO 27018cfc-fbfb-11eb-a643-0242ac110003-PtpxFCHR-o#ehxpV6iN_T token generate success token=MTYyODgzNDE2OC4xNzI2NTk5OjI3MDE4Y2ZjLWZiZmItMTFlYi1hNjQzLTAyNDJhYzE
  13:56:10.559 [dbservice1] INFO 2867e384-fbfb-11eb-b6c6-0242ac110004-TURfmxwe-30x($j9LcmY? token generate success token=MTYyODgzNDE3MC41NTk0Mjc6Mjg2N2UzODQtZmJmYi0xMWViLWI2YzYtMDI0MmFjMTE
  13:56:12.942 [dbservice1] INFO 29da706a-fbfb-11eb-b09d-0242ac110004-WvYxbhDu-gm20&=aH_f%P token generate success token=MTYyODgzNDE3Mi45NDE2NTM1OjI5ZGE3MDZhLWZiZmItMTFlYi1iMDlkLTAyNDJhYzE
  13:56:16.203 [dbservice1] INFO 2bc9c4e8-fbfb-11eb-a5b1-0242ac110003-eJFaBQoW-bScmY_uD{wZ* token generate success token=MTYyODgzNDE3Ni4yMDI3NDA3OjJiYzljNGU4LWZiZmItMTFlYi1hNWIxLTAyNDJhYzE
  13:56:18.940 [dbservice2] INFO 2d6465a6-fbfb-11eb-b77e-0242ac110003-jSevQlNq-y=u7{-jE?dDK token generate success token=MTYyODgzNDE3OC45NDAxNTM6MmQ2NDY1YTYtZmJmYi0xMWViLWI3N2UtMDI0MmFjMTE
  13:56:21.551 [dbservice2] INFO 2ef1be64-fbfb-11eb-bfc7-0242ac110004-zfawCciR-dF$Y@Is}SMDa token generate success token=MTYyODgzNDE4MS41NTA5Nzc3OjJlZjFiZTY0LWZiZmItMTFlYi1iZmM3LTAyNDJhYzE
  13:56:25.677 [mobservice1] INFO info 319f49ec-fbfb-11eb-a296-0242ac110003:bTPjsUVJ write success
  13:56:28.507 [mobservice2] INFO info 33566298-fbfb-11eb-ac61-0242ac110004:YXLKvufE write success
  13:56:30.942 [dbservice2] INFO 34959390-fbfb-11eb-9743-0242ac110003-HTxraybW-3baEXBzdjoV* token generate success token=MTYyODgzNDE5MC45NDE4MzE0OjM0OTU5MzkwLWZiZmItMTFlYi05NzQzLTAyNDJhYzE
  13:56:33.818 [mobservice1] INFO info 3684664a-fbfb-11eb-aa87-0242ac110003:AfSqKhsi write success
  13:56:36.413 [mobservice1] INFO info 380a1d70-fbfb-11eb-a445-0242ac110004:CkWFaQYZ write success
  13:56:38.909 [mobservice1] INFO info 3989733a-fbfb-11eb-a415-0242ac110003:Egncqoka write success
  13:56:42.068 [dbservice2] INFO 3b2a54ca-fbfb-11eb-a086-0242ac110003-XhnipBWc-?SvP1{}M+_9= token generate success token=MTYyODgzNDIwMi4wNjc3ODY6M2IyYTU0Y2EtZmJmYi0xMWViLWEwODYtMDI0MmFjMTE

## p0745
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-23T13:04:58.914Z
```
{"timestamp":1732367098914707700,"container_name":"adservice","pod_name":"adservice-574c5fd7b4-26pcp","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Stats enabled, but temporarily unavailable"}
```
Same service, the 2 minutes before (oldest first):
  13:04:47.957 [adservice] received ad request (context_words=[kitchen])  (×8)
  13:04:48.053 [adservice] received ad request (context_words=[decor, home])  (×2)
  13:04:49.969 [adservice] received ad request (context_words=[])  (×3)
  13:04:50.538 [adservice] received ad request (context_words=[footwear])
  13:04:53.598 [adservice] received ad request (context_words=[accessories])  (×2)
  13:04:54.271 [adservice] received ad request (context_words=[clothing, tops])  (×2)
  13:04:55.301 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  13:04:55.304 [adservice] *** server shut down
All services, 30 seconds either side (sampled):
  13:04:28.914 [cartservice] AddItemAsync called with userId=6129cf10-ed45-447d-9baf-531b5fac192e, productId=1YMWWN1N4O, quantity=7  (×34)
  13:04:28.928 [frontend] view user cart  (×69)
  13:04:28.943 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', '0PUK6V6EV0', 'OLJCESPC7Z', '66VCHSJNUP', '9SIQT8TOJO']  (×213)
  13:04:28.958 [currencyservice] conversion request successful  (×764)
  13:04:28.984 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"592","nanos":337482528},"credit_card":{"credit_card_number":"48053501362098
  13:04:28.988 [shippingservice] [ShipOrder] received request  (×9)
  13:04:28.996 [emailservice] A request to send order confirmation email to dmullins@example.org has been received.
  13:04:29.220 [frontend] serving product page  (×148)
  13:04:29.281 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '9SIQT8TOJO', 'LS4PSXUNUM']  (×2)
  13:04:29.432 [adservice] received ad request (context_words=[])  (×16)
  13:04:30.111 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"2323","nanos":600000000},"credit_card":{"credit_card_number":"4186719947375
  13:04:30.130 [checkoutservice] order confirmation email sent to "bpitts@example.net"
  13:04:31.961 [frontend] setting currency  (×28)
  13:04:37.271 [adservice] received ad request (context_words=[clothing, tops])  (×7)
  13:04:55.304 [adservice] *** server shut down
  13:04:59.000 [adservice] AdService starting.  (×2)
  13:05:00.399 [adservice] Exception in thread "main" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000 at io.grpc.netty.NettyServer.start(NettyServer.java:333) at io.g  (×2)
  13:05:02.995 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"993","nanos":333697488},"credit_card":{"credit_card_number":"49785007864081  (×2)
  13:05:03.010 [checkoutservice] order confirmation email sent to "lutzadam@example.com"
  13:05:05.146 [paymentservice] Transaction processed: visa ending 2645 Amount: CAD122.964344974  (×4)
  13:05:07.129 [emailservice] A request to send order confirmation email to berryryan@example.net has been received.
  13:05:07.924 [emailservice] A request to send order confirmation email to smithcrystal@example.org has been received.
  13:05:11.548 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"419266","nanos":731537048},"credit_card":{"credit_card_number":"46383162621
  13:05:11.562 [checkoutservice] order confirmation email sent to "garyjones@example.net"
  13:05:26.941 [emailservice] A request to send order confirmation email to perkinstimothy@example.com has been received.

## p0296
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:40:25.322Z
```
{"timestamp":1732243225322411800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"GET Request to: http://user/customers/673fef06b0df5c00019b01f7/cards"}
```
Same service, the 2 minutes before (oldest first):
  02:40:24.578 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732243224575,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×2)
  02:40:24.578 [front-end] Order response: {"timestamp":1732243224575,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×2)
  02:40:24.580 [front-end] POST /orders 500 - ms - -  (×2)
  02:40:24.606 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fef10b0df5c00019b021d"}
  02:40:24.614 [front-end] POST /addresses 200 - ms - -
  02:40:24.618 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fef10b0df5c00019b021d"}
  02:40:24.628 [front-end] POST /cards 200 - ms - -
  02:40:24.671 [front-end] Attempting to delete cart for user: 673fef10b0df5c00019b021d
  02:40:24.729 [front-end] User cart deleted with status: 503
  02:40:24.732 [front-end] DELETE /cart 503 - ms - -
  02:40:24.737 [front-end] Attempting to add to cart: {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","quantity":1}
  02:40:24.745 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/
  02:40:24.745 [front-end] POST to carts: http://carts/carts/673fef10b0df5c00019b021d/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}
  02:40:24.785 [front-end] POST /cart 500 44.557 ms - 64
  02:40:25.315 [front-end] Request received with body: {}
  02:40:25.322 [front-end] Received response: "{\"firstName\":\"ezzPzu\",\"lastName\":\"ezzPzu\",\"username\":\"ezzPzu\",\"id\":\"673fef06b0df5c00019b01f7\",\"_links\":{\"addresses\":{\"h
  02:40:25.322 [front-end] GET Request to: http://user/customers/673fef06b0df5c00019b01f7/addresses
All services, 30 seconds either side (sampled):
  02:39:55.352 [catalogue] ts=2024-11-22T02:39:55Z caller=logging.go:85 method=Health result=2 took=26.694µs  (×40)
  02:39:56.165 [front-end] Posting Order: {"customer":"http://user/customers/673feee1b0df5c00019b0187","address":"http://user/addresses/673feeebb0df5c00019b01ad","card":"http://user/cards  (×55)
  02:39:56.187 [shipping] Adding shipment to queue...  (×11)
  02:39:57.094 [user] ts=2024-11-22T02:39:57.093991931Z caller=middlewares.go:157 method=Health result=2 took=735.118µs  (×36)
  02:39:57.218 [front-end] User cart deleted with status: 202  (×57)
  02:39:57.317 [front-end] Posting Customer: {"username":"ETYZxVHejjZYgxn","password":"ZauUyTFP","email":"ETYZxVHejjZYgxn@gmail.com","firstName":"ETYZxVHejjZYgxn","lastName":"ETYZxVHejjZY
  02:39:57.345 [front-end] POST /register 200 26.473 ms - 33  (×60)
  02:39:59.596 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×7)
  02:40:02.106 [user] ts=2024-11-22T02:40:02.106355553Z caller=middlewares.go:46 method=Register username=sleJB email=sleJB@gmail.com took=1.056433ms
  02:40:03.056 [front-end] Posting Customer: {"username":"QUZhAVmEAo","password":"xTGAgkA","email":"QUZhAVmEAo@gmail.com","firstName":"QUZhAVmEAo","lastName":"QUZhAVmEAo"}
  02:40:03.621 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×8)
  02:40:05.868 [front-end] Order response: {"statusCode":201,"body":{"id":"673fef05d94b9000069b3c5d","customerId":"673feef1b0df5c00019b01c1","customer":{"id":null,"firstName":"CReWYhIf","
  02:40:07.329 [front-end] Order response: {"id":"673fef07d94b9000069b3c5f","customerId":"673feef3b0df5c00019b01c4","customer":{"id":null,"firstName":"qfKytXNV","lastName":"qfKytXNV","use
  02:40:10.005 [front-end] Posting Customer: {"username":"zTDIlHCRKIY","password":"bCtsfGXNzk","email":"zTDIlHCRKIY@gmail.com","firstName":"zTDIlHCRKIY","lastName":"zTDIlHCRKIY"}
  02:40:11.017 [queue-master] 2024-11-22 02:40:11.017 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×6)
  02:40:12.903 [front-end] Posting Customer: {"username":"yQlZRwQjGKhOWJI","password":"IaDIr","email":"yQlZRwQjGKhOWJI@gmail.com","firstName":"yQlZRwQjGKhOWJI","lastName":"yQlZRwQjGKhOWJI
  02:40:14.652 [front-end] Received response: "{\"firstName\":\"SLdbS\",\"lastName\":\"SLdbS\",\"username\":\"SLdbS\",\"id\":\"673feef5b0df5c00019b01c8\",\"_links\":{\"addresses\":{\"href
  02:40:18.727 [front-end] Received response: "{\"firstName\":\"WhijhjKUCX\",\"lastName\":\"WhijhjKUCX\",\"username\":\"WhijhjKUCX\",\"id\":\"673feef9b0df5c00019b01d3\",\"_links\":{\"addr
  02:40:20.970 [front-end] Received response: "{\"firstName\":\"KAnwtGKHF\",\"lastName\":\"KAnwtGKHF\",\"username\":\"KAnwtGKHF\",\"id\":\"673fef08b0df5c00019b0200\",\"_links\":{\"address
  02:40:24.538 [front-end] Received response: "{\"firstName\":\"XVANmhFSQ\",\"lastName\":\"XVANmhFSQ\",\"username\":\"XVANmhFSQ\",\"id\":\"673fef03b0df5c00019b01ec\",\"_links\":{\"address
  02:40:25.835 [front-end] Received response: "{\"firstName\":\"gMKrXzQNDOXajBw\",\"lastName\":\"gMKrXzQNDOXajBw\",\"username\":\"gMKrXzQNDOXajBw\",\"id\":\"673fef05b0df5c00019b01f6\",\"_
  02:40:28.331 [front-end] Posting Customer: {"username":"ukxWTTlAYs","password":"jvgxZBKWF","email":"ukxWTTlAYs@gmail.com","firstName":"ukxWTTlAYs","lastName":"ukxWTTlAYs"}
  02:40:30.181 [front-end] Posting Customer: {"username":"yFZCwNFXSRm","password":"zSSpncFU","email":"yFZCwNFXSRm@gmail.com","firstName":"yFZCwNFXSRm","lastName":"yFZCwNFXSRm"}
  02:40:32.835 [user] ts=2024-11-22T02:40:32.834809399Z caller=middlewares.go:46 method=Register username=AamxmpcT email=AamxmpcT@gmail.com took=1.067283ms
  02:40:36.391 [carts] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  02:40:43.454 [front-end] Posting Customer: {"username":"PjLIUTo","password":"kLiZut","email":"PjLIUTo@gmail.com","firstName":"PjLIUTo","lastName":"PjLIUTo"}
  02:40:48.547 [front-end] Posting Customer: {"username":"EQZUb","password":"SnIgPnlc","email":"EQZUb@gmail.com","firstName":"EQZUb","lastName":"EQZUb"}
  02:40:49.288 [user] ts=2024-11-22T02:40:49.288586669Z caller=middlewares.go:46 method=Register username=XbfnMKJk email=XbfnMKJk@gmail.com took=899.246µs
  02:40:51.561 [front-end] Posting Customer: {"username":"akOijWxf","password":"dnuAiBlH","email":"akOijWxf@gmail.com","firstName":"akOijWxf","lastName":"akOijWxf"}
  02:40:54.719 [front-end] Posting Customer: {"username":"ZUbTBmIaCibJoGA","password":"gRqvJ","email":"ZUbTBmIaCibJoGA@gmail.com","firstName":"ZUbTBmIaCibJoGA","lastName":"ZUbTBmIaCibJoGA

## p0484
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:57:00.837Z
```
{"timestamp":1732352220837670700,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"GET Request to: http://user/customers/674198c2a437380001deff4e/cards"}
```
Same service, the 2 minutes before (oldest first):
  08:56:59.448 [front-end] Attempting to delete cart for user: 674198d3a437380001deff98
  08:56:59.468 [front-end] User cart deleted with status: 202
  08:56:59.469 [front-end] DELETE /cart 202 - ms - -
  08:56:59.474 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  08:56:59.484 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  08:56:59.485 [front-end] POST to carts: http://carts/carts/674198d3a437380001deff98/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  08:56:59.524 [front-end] POST /cart 201 - ms - -
  08:57:00.540 [front-end] GET /catalogue 200 - ms - -  (×2)
  08:57:00.720 [front-end] Request received with body: {}  (×2)
  08:57:00.731 [front-end] Received response: "{\"firstName\":\"nuXAdkfqQQTG\",\"lastName\":\"nuXAdkfqQQTG\",\"username\":\"nuXAdkfqQQTG\",\"id\":\"674198caa437380001deff7c\",\"_links\":{
  08:57:00.731 [front-end] GET Request to: http://user/customers/674198caa437380001deff7c/addresses  (×3)
  08:57:00.742 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"674198d0a437380001deff91\",\"_links\":{\"
  08:57:00.743 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67419
  08:57:00.744 [front-end] [ undefined, undefined ]
  08:57:00.744 [front-end] Posting Order: {"customer":"http://user/customers/674198caa437380001deff7c","address":"http://user/addresses/674198d0a437380001deff90","card":"http://user/cards
  08:57:00.836 [front-end] Received response: "{\"firstName\":\"ymztPjpLCMvyH\",\"lastName\":\"ymztPjpLCMvyH\",\"username\":\"ymztPjpLCMvyH\",\"id\":\"674198c2a437380001deff4e\",\"_links\
All services, 30 seconds either side (sampled):
  08:56:58.007 [catalogue] ts=2024-11-23T08:56:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.869902ms  (×36)
  08:56:58.018 [orders] 2024-11-23 08:56:58.018 INFO [orders,6baef7816fdf67ff,4dc9cbe9bd6cff45,false] 8 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Received payment re  (×25)
  08:56:58.029 [front-end] Order response: {"statusCode":201,"body":{"id":"674198da3f77060008865384","customerId":"674198bfa437380001deff45","customer":{"id":null,"firstName":"ztfESzW","l
  08:56:59.388 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674198d3a437380001deff98"}  (×29)
  08:56:59.483 [catalogue] ts=2024-11-23T08:56:59Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.990138  (×27)
  08:57:00.720 [front-end] Request received with body: {}  (×27)
  08:57:00.744 [front-end] Posting Order: {"customer":"http://user/customers/674198caa437380001deff7c","address":"http://user/addresses/674198d0a437380001deff90","card":"http://user/cards  (×27)
  08:57:01.048 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  08:57:01.165 [front-end] 674198dda437380001deffa9  (×33)
  08:57:02.787 [front-end] Received response: "{\"firstName\":\"iEYCUjoH\",\"lastName\":\"iEYCUjoH\",\"username\":\"iEYCUjoH\",\"id\":\"674198c5a437380001deff67\",\"_links\":{\"addresses\
  08:57:03.057 [front-end] Order response: {"statusCode":201,"body":{"id":"674198df3f77060008865387","customerId":"674198caa437380001deff7e","customer":{"id":null,"firstName":"qzkCXXFW","
  08:57:04.140 [front-end] Received response: "{\"firstName\":\"TlHaLWqJVqW\",\"lastName\":\"TlHaLWqJVqW\",\"username\":\"TlHaLWqJVqW\",\"id\":\"674198d0a437380001deff92\",\"_links\":{\"a
  08:57:05.392 [orders] 2024-11-23 08:57:05.392 INFO [orders,3c526066b205402a,acb1c0fc61191c83,false] 8 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×2)
  08:57:07.035 [front-end] Order response: {"statusCode":201,"body":{"id":"674198e33f7706000886538a","customerId":"674198caa437380001deff7d","customer":{"id":null,"firstName":"vidoaLMiMZn
  08:57:08.980 [queue-master] 2024-11-23 08:57:08.980 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×48)
  08:57:09.152 [front-end] Order response: {"id":"674198e53f7706000886538c","customerId":"674198d2a437380001deff95","customer":{"id":null,"firstName":"zUGYrCgol","lastName":"zUGYrCgol","u
  08:57:11.533 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×6)
  08:57:13.005 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  08:57:14.121 [front-end] Posting Customer: {"username":"JCYeKSjM","password":"MYIoBCiY","email":"JCYeKSjM@gmail.com","firstName":"JCYeKSjM","lastName":"JCYeKSjM"}
  08:57:15.678 [front-end] Order response: {"id":"674198eb3f7706000886538f","customerId":"674198cfa437380001deff8c","customer":{"id":null,"firstName":"FygEtnQmntW","lastName":"FygEtnQmntW
  08:57:18.424 [user] ts=2024-11-23T08:57:18.424838811Z caller=middlewares.go:46 method=Register username=bqLFOFtK email=bqLFOFtK@gmail.com took=2.548455ms
  08:57:19.305 [front-end] Received response: "{\"firstName\":\"aXWRmKRnN\",\"lastName\":\"aXWRmKRnN\",\"username\":\"aXWRmKRnN\",\"id\":\"674198d9a437380001deffa4\",\"_links\":{\"address
  08:57:22.096 [front-end] Posting Customer: {"username":"ErqkMC","password":"qwrMe","email":"ErqkMC@gmail.com","firstName":"ErqkMC","lastName":"ErqkMC"}
  08:57:24.110 [front-end] Order response: {"id":"674198f43f77060008865392","customerId":"674198dfa437380001deffad","customer":{"id":null,"firstName":"wqgJPHku","lastName":"wqgJPHku","use
  08:57:25.404 [front-end] Order response: {"id":"674198f53f77060008865393","customerId":"674198e2a437380001deffb0","customer":{"id":null,"firstName":"tVFCKe","lastName":"tVFCKe","usernam
  08:57:26.581 [front-end] Received response: "{\"firstName\":\"aQTVfKPpOQTV\",\"lastName\":\"aQTVfKPpOQTV\",\"username\":\"aQTVfKPpOQTV\",\"id\":\"674198e5a437380001deffb4\",\"_links\":{
  08:57:27.415 [front-end] Order response: {"statusCode":201,"body":{"id":"674198f73f77060008865398","customerId":"674198dda437380001deffa9","customer":{"id":null,"firstName":"eWMmgZPhWLI
  08:57:30.058 [front-end] Order response: {"id":"674198fa3f77060008865399","customerId":"674198e7a437380001deffbe","customer":{"id":null,"firstName":"bVfUCqC","lastName":"bVfUCqC","usern

## p0827
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-08T12:13:37.854Z
```
{"timestamp":1733660017854675700,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-4lplk","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:13:37.854  INFO 1 --- [           main] o.s.i.endpoint.EventDrivenConsumer       : started _org.springframework.integration.errorLogger"}
```
Same service, the 2 minutes before (oldest first):
  12:13:29.577 [ts-route-service] 2024-12-08 12:13:29.576 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[application/vnd.sprin
  12:13:29.654 [ts-route-service] 2024-12-08 12:13:29.653 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  12:13:29.654 [ts-route-service] 2024-12-08 12:13:29.654 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics || /metrics.json],methods=[GET],produces=[application/vnd.s
  12:13:29.654 [ts-route-service] 2024-12-08 12:13:29.654 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/auditevents || /auditevents.json],methods=[GET],produces=[applicati
  12:13:29.655 [ts-route-service] 2024-12-08 12:13:29.655 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[application/vnd
  12:13:29.655 [ts-route-service] 2024-12-08 12:13:29.655 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces=[applicati
  12:13:29.655 [ts-route-service] 2024-12-08 12:13:29.655 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
  12:13:30.668 [ts-route-service] 2024-12-08 12:13:30.668 INFO 1 --- [ main] b.a.s.AuthenticationManagerConfiguration : 
  12:13:30.668 [ts-route-service] Using default security password: 783cfd0c-ae99-482e-93bd-2f472e4d8a11 
  12:13:31.963 [ts-route-service] 2024-12-08 12:13:31.962 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  12:13:32.257 [ts-route-service] 2024-12-08 12:13:32.257 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.springframewo
  12:13:32.257 [ts-route-service] 2024-12-08 12:13:32.257 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springframework.web.s
  12:13:32.365 [ts-route-service] 2024-12-08 12:13:32.365 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class org.springfra
  12:13:32.468 [ts-route-service] 2024-12-08 12:13:32.467 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.boot.actuate.autoconfigure.Manageme
  12:13:34.658 [ts-route-service] 2024-12-08 12:13:34.658 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.embedded.A
  12:13:35.873 [ts-route-service] 2024-12-08 12:13:35.873 INFO 1 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 'taskScheduler'
  12:13:37.459 [ts-route-service] 2024-12-08 12:13:37.459 INFO 1 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  12:13:37.562 [ts-route-service] 2024-12-08 12:13:37.562 INFO 1 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  12:13:37.854 [ts-route-service] 2024-12-08 12:13:37.854 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : Adding {logging-channel-adapter:_org.springframework.integration.errorLogger} as
  12:13:37.854 [ts-route-service] 2024-12-08 12:13:37.854 INFO 1 --- [ main] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-route-service:11178.errorChannel' has 1 subscriber(s).
All services, 30 seconds either side (sampled):
  12:13:09.482 [ts-auth-service] 2024-12-08 12:13:09.482 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×11)
  12:13:09.826 [ts-basic-service] 2024-12-08 12:13:09.826 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×20)
  12:13:09.945 [ts-admin-travel-service] 2024-12-08 12:13:09.943 ERROR 1 --- [io-16114-exec-9] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×7)
  12:13:11.828 [ts-contacts-mongo] {"t":{"$date":"2024-12-08T12:13:11.828+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365999
  12:13:12.038 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-08T12:13:12.037+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365999
  12:13:12.970 [ts-route-service] 2024-12-08 12:13:12.970 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'taskScheduler' has been explicitly defined. Therefore, a de
  12:13:14.467 [ts-route-service] 2024-12-08 12:13:14.467 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.configuration.ObjectP
  12:13:14.969 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:13:14 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×22)
  12:13:18.362 [ts-route-service] 2024-12-08 12:13:18.361 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  12:13:22.867 [ts-food-service] 2024-12-08 12:13:22.867 INFO 1 --- [io-18856-exec-4] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×3)
  12:13:23.262 [ts-route-service] 2024-12-08 12:13:23.261 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-route-mongo:27017 to client view of cluster
  12:13:23.956 [ts-route-service] 2024-12-08 12:13:23.954 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  12:13:27.969 [ts-route-service] 2024-12-08 12:13:27.969 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/swagger-resources]}" onto org.springframework.http.ResponseEnti
  12:13:29.574 [ts-route-service] 2024-12-08 12:13:29.574 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  12:13:29.655 [ts-route-service] 2024-12-08 12:13:29.655 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[application/vnd
  12:13:32.457 [ts-admin-basic-info-service] 2024-12-08 12:13:32.457 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×2)
  12:13:36.931 [ts-inside-payment-service] 2024-12-08 12:13:36.931 INFO 1 --- [io-18673-exec-6] i.controller.InsidePaymentController : [Inside Payment Service][Pay] Pay for: 7e9097ab-1df1-4163-b1eb-81f0f
  12:13:37.880 [ts-basic-service] 2024-12-08 12:13:37.879 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×2)
  12:13:40.658 [ts-route-service] 2024-12-08 12:13:40.658 INFO 1 --- [ main] route.service.RouteServiceImpl : Modify success  (×10)
  12:13:41.242 [ts-consign-service] 2024-12-08 12:13:41.241 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] a9ba52a3-3bfc-4ebd-92e2-  (×2)
  12:13:42.774 [ts-travel-service] 2024-12-08 12:13:42.774 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)
  12:13:53.766 [ts-travel-service] 2024-12-08 12:13:53.766 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×12)
  12:13:54.378 [ts-admin-travel-service] 2024-12-08 12:13:54.377 INFO 1 --- [io-16114-exec-2] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×6)
  12:13:59.108 [ts-basic-service] 2024-12-08 12:13:59.108 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23
  12:13:59.152 [ts-order-other-service] 2024-12-08 12:13:59.151 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 101
  12:13:59.254 [ts-order-other-service] 2024-12-08 12:13:59.249 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=178781  (×4)
  12:14:01.478 [ts-basic-service] 2024-12-08 12:14:01.477 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
  12:14:01.539 [ts-basic-service] 2024-12-08 12:14:01.538 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4
  12:14:04.501 [ts-order-service] 2024-12-08 12:14:04.501 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 135

## p0294
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:38:27.858Z
```
{"timestamp":1732243107858150700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Attempting to delete cart for user: 673fee9db0df5c00019b00bc"}
```
Same service, the 2 minutes before (oldest first):
  02:38:26.002 [front-end] Order response: {"statusCode":201,"body":{"id":"673feea1d94b9000069b3c06","customerId":"673fee90b0df5c00019b0096","customer":{"id":null,"firstName":"OTmchGTAvvr
  02:38:26.002 [front-end] Order response: {"id":"673feea1d94b9000069b3c06","customerId":"673fee90b0df5c00019b0096","customer":{"id":null,"firstName":"OTmchGTAvvrH","lastName":"OTmchGTAvv
  02:38:26.004 [front-end] POST /orders 201 - ms - -  (×2)
  02:38:26.650 [front-end] Request received with body: {}
  02:38:26.658 [front-end] Received response: "{\"firstName\":\"SogMqHGdJMsT\",\"lastName\":\"SogMqHGdJMsT\",\"username\":\"SogMqHGdJMsT\",\"id\":\"673fee90b0df5c00019b0094\",\"_links\":{
  02:38:26.658 [front-end] GET Request to: http://user/customers/673fee90b0df5c00019b0094/addresses  (×2)
  02:38:26.663 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fee96b0df5c00019b00a3\",\"_links\":{\"
  02:38:26.663 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:38:26.663 [front-end] [ undefined, undefined ]
  02:38:26.663 [front-end] Posting Order: {"customer":"http://user/customers/673fee90b0df5c00019b0094","address":"http://user/addresses/673fee96b0df5c00019b00a2","card":"http://user/cards
  02:38:26.693 [front-end] Order response: {"statusCode":201,"body":{"id":"673feea2d94b9000069b3c07","customerId":"673fee90b0df5c00019b0094","customer":{"id":null,"firstName":"SogMqHGdJMs
  02:38:26.693 [front-end] Order response: {"id":"673feea2d94b9000069b3c07","customerId":"673fee90b0df5c00019b0094","customer":{"id":null,"firstName":"SogMqHGdJMsT","lastName":"SogMqHGdJM
  02:38:27.115 [front-end] GET /catalogue 200 - ms - -  (×2)
  02:38:27.744 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fee9db0df5c00019b00bc"}
  02:38:27.753 [front-end] POST /addresses 200 - ms - -
  02:38:27.801 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fee9db0df5c00019b00bc"}
  02:38:27.809 [front-end] POST /cards 200 - ms - -
All services, 30 seconds either side (sampled):
  02:37:58.018 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fee7fb0df5c00019b0064"}  (×60)
  02:37:58.113 [front-end] POST to carts: http://carts/carts/673fee7fb0df5c00019b0064/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}  (×33)
  02:37:58.370 [front-end] Carts merged.  (×57)
  02:38:00.175 [user] ts=2024-11-22T02:38:00.175083094Z caller=middlewares.go:75 method=GetUsers id=673fee70b0df5c00019b003c result=1 took=961.601µs  (×189)
  02:38:00.203 [orders] 2024-11-22 02:38:00.203 INFO [orders,94418f4760008af9,0adcb4604018ec14,false] 6 --- [p-nio-80-exec-1] w.w.s.o.controllers.OrdersController : Received payment re  (×37)
  02:38:01.048 [queue-master] 2024-11-22 02:38:01.048 INFO 6 --- [ool-6-thread-46] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×135)
  02:38:02.302 [front-end] Posting Customer: {"username":"DMOBSBfiqgXj","password":"RCAUznmSM","email":"DMOBSBfiqgXj@gmail.com","firstName":"DMOBSBfiqgXj","lastName":"DMOBSBfiqgXj"}
  02:38:04.900 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×9)
  02:38:07.487 [front-end] Order response: {"id":"673fee8fd94b9000069b3bf3","customerId":"673fee78b0df5c00019b0054","customer":{"id":null,"firstName":"gLTrOHLOOljO","lastName":"gLTrOHLOOl
  02:38:08.855 [front-end] Received response: "{\"firstName\":\"YuYpNZfbSILmU\",\"lastName\":\"YuYpNZfbSILmU\",\"username\":\"YuYpNZfbSILmU\",\"id\":\"673fee73b0df5c00019b0043\",\"_links\
  02:38:11.164 [front-end] Order response: {"id":"673fee93d94b9000069b3bf8","customerId":"673fee7ab0df5c00019b005a","customer":{"id":null,"firstName":"aERlPcwCIQtcOHc","lastName":"aERlPcw
  02:38:13.496 [user] ts=2024-11-22T02:38:13.496249769Z caller=middlewares.go:46 method=Register username=uEVEcke email=uEVEcke@gmail.com took=1.135712ms
  02:38:14.961 [front-end] Order response: {"id":"673fee96d94b9000069b3bfd","customerId":"673fee83b0df5c00019b0069","customer":{"id":null,"firstName":"ezmIoAeeIgVqMW","lastName":"ezmIoAee
  02:38:19.157 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee9bd94b9000069b3c00","customerId":"673fee84b0df5c00019b0071","customer":{"id":null,"firstName":"PRfNWzJMJqg
  02:38:21.705 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee9dd94b9000069b3c03","customerId":"673fee8ab0df5c00019b007f","customer":{"id":null,"firstName":"DMOBSBfiqgX
  02:38:25.771 [user] ts=2024-11-22T02:38:25.771426852Z caller=middlewares.go:46 method=Register username=HTrxgSQ email=HTrxgSQ@gmail.com took=1.052909ms
  02:38:28.114 [front-end] Order response: {"statusCode":201,"body":{"id":"673feea4d94b9000069b3c08","customerId":"673fee8eb0df5c00019b0090","customer":{"id":null,"firstName":"UhAse","las
  02:38:29.340 [user] ts=2024-11-22T02:38:29.340669481Z caller=middlewares.go:46 method=Register username=MJGBC email=MJGBC@gmail.com took=1.034739ms
  02:38:31.091 [front-end] Posting Customer: {"username":"NobBxH","password":"mQEcDCM","email":"NobBxH@gmail.com","firstName":"NobBxH","lastName":"NobBxH"}
  02:38:31.660 [front-end] Order response: {"id":"673feea7d94b9000069b3c0c","customerId":"673fee90b0df5c00019b0095","customer":{"id":null,"firstName":"bMyeICjUYoa","lastName":"bMyeICjUYoa
  02:38:34.851 [front-end] Order response: {"statusCode":201,"body":{"id":"673feeaad94b9000069b3c0f","customerId":"673fee95b0df5c00019b00a1","customer":{"id":null,"firstName":"VFRChrldGSL
  02:38:39.051 [front-end] Order response: {"statusCode":201,"body":{"id":"673feeafd94b9000069b3c12","customerId":"673fee94b0df5c00019b009d","customer":{"id":null,"firstName":"gDbYYMHQ","
  02:38:42.553 [front-end] Order response: {"id":"673feeb2d94b9000069b3c15","customerId":"673feea0b0df5c00019b00c7","customer":{"id":null,"firstName":"ZUEqGwFMOYjiUtY","lastName":"ZUEqGwF
  02:38:44.984 [front-end] Received response: "{\"firstName\":\"SiDDqilFZlRmOh\",\"lastName\":\"SiDDqilFZlRmOh\",\"username\":\"SiDDqilFZlRmOh\",\"id\":\"673feea4b0df5c00019b00cc\",\"_lin
  02:38:48.389 [front-end] Order response: {"id":"673feeb8d94b9000069b3c1a","customerId":"673feea7b0df5c00019b00da","customer":{"id":null,"firstName":"NobBxH","lastName":"NobBxH","usernam
  02:38:49.954 [front-end] Received response: "{\"firstName\":\"HTrxgSQ\",\"lastName\":\"HTrxgSQ\",\"username\":\"HTrxgSQ\",\"id\":\"673feea1b0df5c00019b00c8\",\"_links\":{\"addresses\":{
  02:38:53.396 [user] ts=2024-11-22T02:38:53.395913316Z caller=middlewares.go:46 method=Register username=wFiFnCZ email=wFiFnCZ@gmail.com took=1.013674ms
  02:38:54.547 [front-end] Order response: {"id":"673feebed94b9000069b3c23","customerId":"673feea7b0df5c00019b00dc","customer":{"id":null,"firstName":"jCRdMb","lastName":"jCRdMb","usernam

## p0667
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-11T09:15:38.500Z
```
{"service":"webservice1","message":"2021-08-11 09:15:38,500 | INFO | 0.0.0.1 | webservice1 | web_helper.py -> web_service_resource -> 69 | f1747d10ba13b569 | now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  09:15:34.918 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'a1304f24-fa41-11eb-a72b-0242ac110003', 'value': '', 'ex': 10}  (×3)
  09:15:34.980 [webservice1] INFO uuid: a1304f24-fa41-11eb-a72b-0242ac110003 write redis successfully  (×3)
  09:15:35.084 [webservice1] INFO complete information: {'uuid': 'a1304f24-fa41-11eb-a72b-0242ac110003', 'user_id': 'aJKPGOlh'}  (×3)
  09:15:35.098 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×3)
  09:15:35.098 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
  09:15:36.678 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  09:15:36.678 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×2)
All services, 30 seconds either side (sampled):
  09:15:08.556 [webservice1] INFO complete information: {'uuid': '915fd628-fa41-11eb-9052-0242ac110003', 'user_id': 'NPtZUmhc'}  (×43)
  09:15:08.681 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '915fd628-fa41-11eb-9052-0242ac110003', 'value': 'NPtZUmhc'}  (×32)
  09:15:08.897 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×47)
  09:15:09.009 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×39)
  09:15:09.253 [redisservice2] INFO redis write success  (×80)
  09:15:09.697 [redisservice1] INFO redis读取信息成功, status_code: 200  (×49)
  09:15:09.861 [dbservice2] INFO query = select passwards from username_table where user_name='cvlIGRjC'  (×40)
  09:15:10.384 [redisservice1] INFO service accept, status_code: 200  (×36)
  09:15:11.431 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '92e84ade-fa41-11eb-b652-0242ac110003'}  (×33)
  09:15:12.607 [dbservice1] INFO 937152f2-fa41-11eb-997d-0242ac110004-SzfIWpZE-{_HV.}LO^GnA token generate success token=MTYyODY0NDUxMi42MDc1NjY0OjkzNzE1MmYyLWZhNDEtMTFlYi05OTdkLTAyNDJhYzE
  09:15:14.598 [mobservice2] INFO info 94de8c72-fa41-11eb-98a3-0242ac110003:hRGCgxwP write success  (×2)
  09:15:17.273 [mobservice2] INFO info 96724560-fa41-11eb-8f0a-0242ac110003:CkWFaQYZ write success
  09:15:19.462 [dbservice1] INFO 9768b396-fa41-11eb-ab63-0242ac110004-ISmxpnEs--5/4Hwoa@2dU token generate success token=MTYyODY0NDUxOS40NjIzODk1Ojk3NjhiMzk2LWZhNDEtMTFlYi1hYjYzLTAyNDJhYzE
  09:15:22.176 [dbservice1] INFO 99204d8e-fa41-11eb-885e-0242ac110003-GKtJXRfS-m0M9zQiR3ea( token generate success token=MTYyODY0NDUyMi4xNzU2NDkyOjk5MjA0ZDhlLWZhNDEtMTFlYi04ODVlLTAyNDJhYzE
  09:15:24.701 [dbservice2] INFO 9ab08ba0-fa41-11eb-a658-0242ac110004-zShwUfFn-^YekX}_z?E-@ token generate success token=MTYyODY0NDUyNC43MDE0MDEyOjlhYjA4YmEwLWZhNDEtMTFlYi1hNjU4LTAyNDJhYzE
  09:15:27.488 [mobservice2] INFO info 9c8154d2-fa41-11eb-8b56-0242ac110003:JuoeTjfH write success
  09:15:29.629 [dbservice1] INFO 9da1a90c-fa41-11eb-9a64-0242ac110003-UHcqgbTI-JH<T8XNfd/>@ token generate success token=MTYyODY0NDUyOS42Mjg4ODI0OjlkYTFhOTBjLWZhNDEtMTFlYi05YTY0LTAyNDJhYzE
  09:15:32.311 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  09:15:34.426 [mobservice2] INFO info a0b44410-fa41-11eb-8c08-0242ac110004:xgpqRfCn write success
  09:15:36.581 [dbservice1] INFO a1b9a986-fa41-11eb-a1cf-0242ac110004-mIgaboME-%kKe74{mJnG5 token generate success token=MTYyODY0NDUzNi41ODEwNjE4OmExYjlhOTg2LWZhNDEtMTFlYi1hMWNmLTAyNDJhYzE
  09:15:39.350 [dbservice1] INFO a34e2c18-fa41-11eb-a509-0242ac110003-CzojFELq-MU6*h.QSdBWf token generate success token=MTYyODY0NDUzOS4zNDkwMjM4OmEzNGUyYzE4LWZhNDEtMTFlYi1hNTA5LTAyNDJhYzE
  09:15:41.974 [mobservice1] INFO info a51f1796-fa41-11eb-a961-0242ac110003:IMzHpvSY write success
  09:15:44.327 [mobservice2] INFO info a69318a2-fa41-11eb-ba55-0242ac110004:TKNpsvwU write success
  09:15:46.485 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  09:15:50.952 [dbservice1] INFO aa5471de-fa41-11eb-911c-0242ac110004-GZfYMFec-5$&S1)ZuTxf0 token generate success token=MTYyODY0NDU1MC45NTIxMDAzOmFhNTQ3MWRlLWZhNDEtMTFlYi05MTFjLTAyNDJhYzE
  09:15:57.822 [mobservice2] INFO info aeada764-fa41-11eb-9f64-0242ac110004:vfxYGPRM write success
  09:16:00.347 [mobservice2] INFO info b02175d0-fa41-11eb-b098-0242ac110003:ZkYfGaQs write success
  09:16:02.606 [dbservice2] INFO b1435be0-fa41-11eb-b639-0242ac110003-IYcJLxjh-C-6K2cN5{j}H token generate success token=MTYyODY0NDU2Mi42MDY0NTA4OmIxNDM1YmUwLWZhNDEtMTFlYi1iNjM5LTAyNDJhYzE
  09:16:05.055 [mobservice2] INFO info b2f84680-fa41-11eb-b642-0242ac110004:FTkscPog write success
  09:16:07.410 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat

## p0845
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T04:26:17.740Z
```
{"timestamp":1731903977740392200,"container_name":"adservice","pod_name":"adservice-67c9b847f4-wz6h7","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Tracing enabled but temporarily unavailable"}
```
Same service, the 2 minutes before (oldest first):
  04:26:09.544 [adservice] received ad request (context_words=[kitchen])  (×6)
  04:26:09.566 [adservice] received ad request (context_words=[accessories])  (×3)
  04:26:09.593 [adservice] received ad request (context_words=[clothing, tops])
  04:26:09.618 [adservice] received ad request (context_words=[hair, beauty])
  04:26:10.729 [adservice] received ad request (context_words=[decor, home])
  04:26:10.800 [adservice] received ad request (context_words=[])  (×4)
  04:26:14.190 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  04:26:14.191 [adservice] *** server shut down
  04:26:17.643 [adservice] Stats enabled, but temporarily unavailable
  04:26:17.739 [adservice] AdService starting.
All services, 30 seconds either side (sampled):
  04:25:47.763 [frontend] request started  (×295)
  04:25:47.766 [frontend] home  (×36)
  04:25:47.781 [currencyservice] conversion request successful  (×717)
  04:25:48.291 [frontend] view user cart  (×71)
  04:25:48.316 [shippingservice] [GetQuote] completed request  (×83)
  04:25:48.653 [adservice] received ad request (context_words=[hair, beauty])  (×6)
  04:25:49.099 [frontend] adding to cart  (×23)
  04:25:49.164 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="TRY"  (×2)
  04:25:49.190 [checkoutservice] payment went through (transaction_id: 9f2259b1-70d3-4c82-a614-52a2c26c1bb7)  (×12)
  04:25:49.195 [cartservice] EmptyCartAsync called with userId=0ae6d9b6-4e7f-4d38-a0eb-042389dcac30  (×12)
  04:25:49.202 [frontend] order placed  (×12)
  04:25:53.896 [adservice] received ad request (context_words=[footwear])  (×4)
  04:25:58.955 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"1618","nanos":993365795},"credit_card":{"credit_card_number":"4777636584828  (×2)
  04:25:58.970 [checkoutservice] order confirmation email sent to "thomasfarmer@example.org"
  04:26:03.290 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"481","nanos":720000000},"credit_card":{"credit_card_number":"46971998707907
  04:26:03.305 [checkoutservice] order confirmation email sent to "gonzalezjessica@example.net"
  04:26:04.228 [paymentservice] Transaction processed: visa ending 4902 Amount: GBP900.148865979  (×4)
  04:26:07.877 [emailservice] A request to send order confirmation email to stephaniegregory@example.org has been received.  (×2)
  04:26:08.085 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"516","nanos":718266264},"credit_card":{"credit_card_number":"41048720965937  (×3)
  04:26:08.102 [checkoutservice] order confirmation email sent to "victor92@example.org"
  04:26:14.190 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  04:26:14.635 [frontend] failed to retrieve ads  (×96)
  04:26:17.643 [adservice] Stats enabled, but temporarily unavailable
  04:26:17.742 [adservice] Tracing enabled - Stackdriver exporter initialized.
  04:26:23.952 [checkoutservice] order confirmation email sent to "vegadennis@example.net"
  04:26:41.011 [emailservice] A request to send order confirmation email to vhaynes@example.org has been received.

## p0622
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-food-service, 2024-12-07T20:17:38.802Z
```
{"timestamp":1733602658802064100,"container_name":"ts-food-service","pod_name":"ts-food-service-669668c96d-d4prx","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 20:17:38.801 ERROR 1 --- [io-18856-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is org.springframework.web.client.HttpServerErrorException: 500 Internal Server Error] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  20:16:32.893 [ts-food-service] 2024-12-07 20:16:32.893 INFO 1 --- [io-18856-exec-7] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×2)
  20:16:32.893 [ts-food-service] 2024-12-07 20:16:32.893 INFO 1 --- [io-18856-exec-7] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×2)
  20:16:32.910 [ts-food-service] 2024-12-07 20:16:32.909 INFO 1 --- [io-18856-exec-7] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!  (×2)
  20:16:48.358 [ts-food-service] 2024-12-07 20:16:48.358 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  20:16:48.358 [ts-food-service] 2024-12-07 20:16:48.358 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345
  20:16:48.369 [ts-food-service] 2024-12-07 20:16:48.369 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
All services, 30 seconds either side (sampled):
  20:17:11.966 [ts-admin-basic-info-service] 2024-12-07 20:17:11.965 INFO 1 --- [io-18767-exec-5] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×15)
  20:17:12.372 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:12 +0800] "POST /api/v1/users/login HTTP/1.1" 200 380 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×27)
  20:17:12.412 [ts-travel2-service] 2024-12-07 20:17:12.411 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×9)
  20:17:12.616 [ts-travel-service] 2024-12-07 20:17:12.616 ERROR 1 --- [io-12346-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×15)
  20:17:15.135 [ts-admin-basic-info-service] 2024-12-07 20:17:15.135 INFO 1 --- [io-18767-exec-6] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×13)
  20:17:22.669 [ts-route-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  20:17:27.209 [ts-travel-service] 2024-12-07 20:17:27.209 ERROR 1 --- [o-12346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  20:17:28.498 [ts-route-mongo] {"t":{"$date":"2024-12-07T20:17:28.498+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360264
  20:17:29.626 [ts-auth-service] 2024-12-07 20:17:29.626 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×3)
  20:17:31.156 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T20:17:31.156+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:31.663 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:17:31.663+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:35.032 [ts-route-service] Error opening zip file or JAR manifest missing : /tmp/opentelemetry-javaagent.jar
  20:17:36.164 [ts-route-service] 2024-12-07 20:17:36.163 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def
  20:17:36.472 [ts-inside-payment-service] 2024-12-07 20:17:36.471 INFO 1 --- [io-18673-exec-6] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.
  20:17:37.664 [ts-route-service] 2024-12-07 20:17:37.664 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  20:17:38.763 [ts-food-service] 2024-12-07 20:17:38.763 INFO 1 --- [io-18856-exec-5] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:17:41.056 [ts-route-service] 2024-12-07 20:17:41.055 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 11178 (http)
  20:17:42.999 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T20:17:42.999+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360266
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  20:17:46.959 [ts-route-service] 2024-12-07 20:17:46.957 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes],methods=[GET]}" onto public org.spr
  20:17:51.174 [ts-route-service] 2024-12-07 20:17:51.173 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  20:17:52.759 [ts-route-service] 2024-12-07 20:17:52.759 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[application/vnd.sprin
  20:17:52.762 [ts-route-service] 2024-12-07 20:17:52.762 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  20:17:52.765 [ts-route-service] 2024-12-07 20:17:52.765 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/vnd.spring-bo
  20:17:55.659 [ts-route-service] 2024-12-07 20:17:55.659 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class org.springfra
  20:18:00.870 [ts-route-service] 2024-12-07 20:18:00.870 INFO 1 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  20:18:01.659 [ts-route-service] 2024-12-07 20:18:01.657 INFO 1 --- [ main] d.s.w.p.DocumentationPluginsBootstrapper : Found 1 custom documentation plugin(s)
  20:18:03.854 [ts-route-service] 2024-12-07 20:18:03.853 INFO 1 --- [ main] org.mongodb.driver.connection : Opened connection [connectionId{localValue:2, serverValue:25}] to ts-route-mongo:2701
  20:18:04.554 [ts-route-service] 2024-12-07 20:18:04.554 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: suzhou End: shanghai

## p0751
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service checkoutservice, 2024-11-23T14:22:37.492Z
```
{"timestamp":1732371757492406300,"container_name":"checkoutservice","pod_name":"checkoutservice-7ff8db989f-24vr5","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"failed to send order confirmation to \"ruizdebra@example.net\": rpc error: code = Unavailable desc = upstream connect error or disconnect/reset before headers. retried and the latest reset reason: remote connection failure, transport failure reason: delayed connect error: Connection refused"}
```
Same service, the 2 minutes before (oldest first):
  14:22:00.214 [checkoutservice] [PlaceOrder] user_id="e33cfee9-798f-4567-b115-69c40dce8607" user_currency="GBP"  (×3)
  14:22:00.240 [checkoutservice] payment went through (transaction_id: 941ead0d-f194-4af0-b4a2-7d762606d8d1)  (×6)
  14:22:00.251 [checkoutservice] order confirmation email sent to "amanda28@example.com"
  14:22:03.372 [checkoutservice] [PlaceOrder] user_id="4abf74df-6c0b-4392-bdb0-f19f4d7ff511" user_currency="USD"
  14:22:03.402 [checkoutservice] order confirmation email sent to "jgonzalez@example.org"
  14:22:10.257 [checkoutservice] order confirmation email sent to "wwarren@example.org"
  14:22:21.306 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 14  (×3)
  14:22:21.363 [checkoutservice] failed to send order confirmation to "gmcdonald@example.net": rpc error: code = Unavailable desc = no healthy upstream
  14:22:21.805 [checkoutservice] [PlaceOrder] user_id="5610460a-814f-43e0-96b6-68f36171d3ca" user_currency="CAD"
  14:22:21.846 [checkoutservice] failed to send order confirmation to "kennethhicks@example.com": rpc error: code = Unavailable desc = no healthy upstream
  14:22:37.320 [checkoutservice] [PlaceOrder] user_id="931a1dee-a1ff-459e-84f4-7a7d7e884cd2" user_currency="EUR"
All services, 30 seconds either side (sampled):
  14:22:07.589 [frontend] request started  (×295)
  14:22:07.592 [currencyservice] Getting supported currencies...  (×247)
  14:22:07.598 [currencyservice] conversion request successful  (×607)
  14:22:07.620 [adservice] received ad request (context_words=[kitchen])  (×37)
  14:22:07.644 [adservice] received ad request (context_words=[clothing, tops])  (×17)
  14:22:10.106 [frontend] view user cart  (×70)
  14:22:10.142 [shippingservice] [GetQuote] completed request  (×81)
  14:22:10.153 [frontend] adding to cart  (×29)
  14:22:10.178 [recommendationservice] [Recv ListRecommendations] product_ids=['9SIQT8TOJO', 'LS4PSXUNUM', '2ZYFJ3GM2N', '66VCHSJNUP']  (×3)
  14:22:10.215 [checkoutservice] [PlaceOrder] user_id="25bb09b9-2b30-4535-9291-83c9da063ce4" user_currency="GBP"  (×3)
  14:22:10.242 [paymentservice] Transaction processed: visa ending 2912 Amount: GBP1335.17901806  (×3)
  14:22:10.246 [shippingservice] [ShipOrder] received request  (×11)
  14:22:10.249 [cartservice] EmptyCartAsync called with userId=25bb09b9-2b30-4535-9291-83c9da063ce4  (×11)
  14:22:10.257 [checkoutservice] order confirmation email sent to "wwarren@example.org"
  14:22:10.412 [adservice] received ad request (context_words=[hair, beauty])  (×21)
  14:22:10.897 [frontend] setting currency  (×19)
  14:22:10.929 [frontend] ENV_PLATFORM is: aws  (×26)
  14:22:11.588 [adservice] received ad request (context_words=[footwear])  (×19)
  14:22:12.304 [emailservice] Profiler disabled.  (×3)
  14:22:12.399 [emailservice] AttributeError: '_Server' object has no attribute 'Check'  (×3)
  14:22:21.363 [checkoutservice] failed to send order confirmation to "gmcdonald@example.net": rpc error: code = Unavailable desc = no healthy upstream
  14:22:21.829 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"1929","nanos":358612994},"credit_card":{"credit_card_number":"4896129103593  (×4)
  14:22:21.846 [checkoutservice] failed to send order confirmation to "kennethhicks@example.com": rpc error: code = Unavailable desc = no healthy upstream
  14:22:37.339 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"772","nanos":994250336},"credit_card":{"credit_card_number":"42771504837046
  14:22:37.836 [checkoutservice] [PlaceOrder] user_id="706f37f6-1c4e-4686-b19d-4ff2d2c889ad" user_currency="USD"  (×3)
  14:22:37.856 [paymentservice] Transaction processed: visa ending 4235 Amount: USD372.830000000  (×3)
  14:22:39.750 [checkoutservice] failed to send order confirmation to "jill93@example.org": rpc error: code = Unavailable desc = upstream connect error or disconnect/reset before headers. retri
  14:22:45.738 [checkoutservice] failed to send order confirmation to "cdoyle@example.com": rpc error: code = Unavailable desc = no healthy upstream
  14:22:57.508 [checkoutservice] failed to send order confirmation to "destinydunn@example.org": rpc error: code = Unavailable desc = no healthy upstream
  14:23:04.930 [checkoutservice] failed to send order confirmation to "james96@example.org": rpc error: code = Unavailable desc = no healthy upstream

## p0595
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T20:02:28.765Z
```
{"timestamp":1733601748765595600,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-w6jt4","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:02:28.765  INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl         : [Travel Service][Get Route By Id] Route ID：084837bb-53c8-4438-87c8-0321a4d09917"}
```
Same service, the 2 minutes before (oldest first):
  20:02:24.569 [ts-travel-service] 2024-12-07 20:02:24.569 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan  (×4)
  20:02:24.577 [ts-travel-service] 2024-12-07 20:02:24.577 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：084837bb-53c8-4438-87c8-0321a  (×6)
  20:02:24.584 [ts-travel-service] 2024-12-07 20:02:24.584 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  20:02:24.585 [ts-travel-service] 2024-12-07 20:02:24.584 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  20:02:24.653 [ts-travel-service] 2024-12-07 20:02:24.653 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×2)
  20:02:24.654 [ts-travel-service] 2024-12-07 20:02:24.654 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×2)
  20:02:26.234 [ts-travel-service] 2024-12-07 20:02:26.233 INFO 1 --- [io-12346-exec-5] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  20:02:28.716 [ts-travel-service] 2024-12-07 20:02:28.715 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  20:02:28.742 [ts-travel-service] 2024-12-07 20:02:28.741 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
  20:02:28.758 [ts-travel-service] 2024-12-07 20:02:28.757 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
All services, 30 seconds either side (sampled):
  20:01:59.974 [ts-consign-service] 2024-12-07 20:01:59.974 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : SAVE consign info : ConsignRecord(id=c6db72a1-41a6-41ef-972c-938f481c2
  20:02:01.577 [ts-auth-service] 2024-12-07 20:02:01.577 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×18)
  20:02:01.639 [ts-travel-service] 2024-12-07 20:02:01.638 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×14)
  20:02:01.801 [ts-travel2-service] 2024-12-07 20:02:01.801 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×99)
  20:02:04.745 [ts-travel-service] 2024-12-07 20:02:04.745 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×5)
  20:02:06.196 [ts-basic-service] 2024-12-07 20:02:06.195 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×23)
  20:02:06.301 [ts-basic-service] 2024-12-07 20:02:06.301 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×78)
  20:02:06.389 [ts-travel2-service] 2024-12-07 20:02:06.389 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×18)
  20:02:06.492 [ts-seat-service] 2024-12-07 20:02:06.492 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×40)
  20:02:07.502 [ts-admin-basic-info-service] 2024-12-07 20:02:07.502 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  20:02:07.931 [ts-travel-service] 2024-12-07 20:02:07.930 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×12)
  20:02:08.019 [ts-seat-service] 2024-12-07 20:02:08.019 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×21)
  20:02:08.180 [ts-seat-service] 2024-12-07 20:02:08.180 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×3)
  20:02:08.429 [ts-price-service] 2024-12-07 20:02:08.429 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×2)
  20:02:10.072 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:02:10 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 924 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×4)
  20:02:12.978 [ts-basic-service] 2024-12-07 20:02:12.977 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×4)
  20:02:13.557 [ts-order-service] 2024-12-07 20:02:13.557 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00 
  20:02:18.403 [ts-basic-service] 2024-12-07 20:02:18.403 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×6)
  20:02:21.027 [ts-travel2-service] 2024-12-07 20:02:21.027 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  20:02:24.191 [ts-inside-payment-service] 2024-12-07 20:02:24.191 INFO 1 --- [io-18673-exec-1] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.
  20:02:26.366 [ts-seat-service] 2024-12-07 20:02:26.366 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
  20:02:28.378 [ts-route-mongo] {"t":{"$date":"2024-12-07T20:02:28.377+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360174
  20:02:30.912 [ts-food-mongo] {"t":{"$date":"2024-12-07T20:02:30.911+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360175
  20:02:31.628 [ts-notification-mongo] {"t":{"$date":"2024-12-07T20:02:31.628+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360175
  20:02:33.602 [ts-basic-service] 2024-12-07 20:02:33.602 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270
  20:02:42.742 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T20:02:42.742+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360176
  20:02:53.608 [ts-travel2-service] 2024-12-07 20:02:53.608 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)

## p0187
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T06:48:26.170Z
```
{"timestamp":1731912506170278100,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-svrwm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53"}
```
Same service, the 2 minutes before (oldest first):
  06:48:24.480 [cartservice] GetCartAsync called with userId=0ae6d9b6-4e7f-4d38-a0eb-042389dcac30  (×8)
  06:48:24.564 [cartservice] AddItemAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03, productId=OLJCESPC7Z, quantity=1  (×2)
All services, 30 seconds either side (sampled):
  06:48:24.473 [frontend] request started  (×158)
  06:48:24.477 [currencyservice] Getting supported currencies...  (×130)
  06:48:24.488 [currencyservice] conversion request successful  (×336)
  06:48:24.504 [adservice] received ad request (context_words=[decor, home])  (×7)
  06:48:24.556 [adservice] received ad request (context_words=[accessories])  (×19)
  06:48:24.564 [cartservice] AddItemAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03, productId=OLJCESPC7Z, quantity=1  (×17)
  06:48:24.603 [shippingservice] [GetQuote] received request  (×35)
  06:48:25.170 [adservice] received ad request (context_words=[kitchen])  (×24)
  06:48:26.158 [frontend] setting currency  (×11)
  06:48:26.211 [frontend] ENV_PLATFORM is: aws  (×16)
  06:48:26.901 [adservice] received ad request (context_words=[clothing, tops])  (×3)
  06:48:27.795 [adservice] received ad request (context_words=[hair, beauty])  (×16)
  06:48:30.014 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="JPY"
  06:48:30.051 [paymentservice] Transaction processed: visa ending 4133 Amount: JPY147999.249890397
  06:48:30.054 [shippingservice] [ShipOrder] received request  (×2)
  06:48:30.057 [cartservice] EmptyCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03  (×2)
  06:48:30.063 [checkoutservice] order confirmation email sent to "mccoymelissa@example.net"
  06:48:32.337 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="GBP"
  06:48:32.374 [paymentservice] Transaction processed: visa ending 3003 Amount: GBP1238.66859775
  06:48:32.389 [checkoutservice] order confirmation email sent to "ericlewis@example.org"
