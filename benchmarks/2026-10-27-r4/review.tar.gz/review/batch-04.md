## p0061
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-13T08:44:54.014Z
```
{"service":"redisservice1","message":"2021-08-13 08:44:54,014 | INFO | 0.0.0.1 | redisservice1 | redis_helper.py -> keys_existence_check -> 107 | 3eac9622220eb0 | service refuse, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  08:44:49.517 [redisservice1] INFO redis write success  (×10)
  08:44:49.653 [redisservice1] INFO redis读取信息成功, status_code: 200  (×4)
  08:44:50.150 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×3)
  08:44:50.594 [redisservice1] INFO service accept, status_code: 200
  08:44:52.353 [redisservice1] INFO service refuse, status_code: 200  (×2)
All services, 30 seconds either side (sampled):
  08:44:24.036 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  08:44:24.191 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×51)
  08:44:24.397 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  08:44:24.602 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  08:44:24.719 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×45)
  08:44:24.901 [dbservice1] INFO 9afa9c10-fbcf-11eb-8d8d-0242ac110004-cwbxRDST-+!NhXiR:qd?D token generate success token=MTYyODgxNTQ2NC45MDE1MjU1OjlhZmE5YzEwLWZiY2YtMTFlYi04ZDhkLTAyNDJhYzE
  08:44:25.175 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×47)
  08:44:25.419 [mobservice1] INFO info 9b888a3e-fbcf-11eb-a9aa-0242ac110004:EVBLhgrm write success
  08:44:25.601 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×52)
  08:44:26.933 [mobservice1] INFO info 9c700a3a-fbcf-11eb-a0ed-0242ac110004:qHGVUSPX write success
  08:44:28.697 [redisservice2] INFO service refuse, status_code: 200  (×24)
  08:44:31.017 [mobservice2] INFO info 9ecb5848-fbcf-11eb-aa33-0242ac110003:eyfiDUCK write success  (×2)
  08:44:33.780 [mobservice1] INFO info a0757c32-fbcf-11eb-be76-0242ac110004:rPLoqHhe write success
  08:44:36.606 [mobservice1] INFO info a227f73a-fbcf-11eb-ab2f-0242ac110003:tjrRfeJy write success
  08:44:39.414 [mobservice2] INFO info a3d64852-fbcf-11eb-b160-0242ac110003:ISmxpnEs write success
  08:44:41.914 [mobservice2] INFO info a554269a-fbcf-11eb-b2a4-0242ac110003:RcoJYnsh write success
  08:44:44.705 [dbservice1] INFO a6c9a202-fbcf-11eb-8c0b-0242ac110004-OkyWpDvC-YSR3f{z?a:H/ token generate success token=MTYyODgxNTQ4NC43MDUyNjM5OmE2YzlhMjAyLWZiY2YtMTFlYi04YzBiLTAyNDJhYzE
  08:44:47.473 [mobservice2] INFO info a8a87d5a-fbcf-11eb-88d0-0242ac110004:qhdLCnSU write success
  08:44:50.841 [mobservice1] INFO info aaa6e830-fbcf-11eb-b780-0242ac110003:Jcofhzdp write success
  08:44:54.902 [dbservice1] INFO acbe798a-fbcf-11eb-8602-0242ac110004-WvNJCdPU-uTnHNJK0W>)$ token generate success token=MTYyODgxNTQ5NC45MDIzNjk6YWNiZTc5OGEtZmJjZi0xMWViLTg2MDItMDI0MmFjMTE
  08:44:57.534 [mobservice2] INFO info aea778d2-fbcf-11eb-8191-0242ac110004:hpcKRNdx write success
  08:45:00.631 [mobservice1] INFO info b07c40ac-fbcf-11eb-9e9b-0242ac110003:vUsGrNAF write success
  08:45:02.941 [mobservice1] INFO info b1e9511e-fbcf-11eb-b36d-0242ac110004:McHWnbKA write success
  08:45:05.422 [dbservice1] INFO b323c9ba-fbcf-11eb-a974-0242ac110004-NxPGARft-^DE14W)n(d_& token generate success token=MTYyODgxNTUwNS40MjE3ODkyOmIzMjNjOWJhLWZiY2YtMTFlYi1hOTc0LTAyNDJhYzE
  08:45:07.880 [mobservice1] INFO info b4d37530-fbcf-11eb-b823-0242ac110004:srBKODwN write success
  08:45:10.700 [mobservice1] INFO info b67a6cf4-fbcf-11eb-9e7d-0242ac110004:qyhWbUnC write success
  08:45:13.363 [mobservice2] INFO info b80aa264-fbcf-11eb-a5f0-0242ac110003:pvKgfqae write success
  08:45:16.494 [mobservice2] INFO info b9e0e972-fbcf-11eb-a2b2-0242ac110003:evnbrmSs write success
  08:45:19.536 [dbservice1] INFO bb8b7698-fbcf-11eb-bab1-0242ac110004-QurEfLHx-IHF}iJTM)pEg token generate success token=MTYyODgxNTUxOS41MzYyMjk4OmJiOGI3Njk4LWZiY2YtMTFlYi1iYWIxLTAyNDJhYzE
  08:45:23.657 [dbservice1] INFO bdf9a90e-fbcf-11eb-9603-0242ac110003-rYEevjPt-9g@Kz:0PJDTN token generate success token=MTYyODgxNTUyMy42NTY4NDA4OmJkZjlhOTBlLWZiY2YtMTFlYi05NjAzLTAyNDJhYzE

## p0055
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-13T08:33:03.503Z
```
{"service":"mobservice2","message":"2021-08-13 08:33:03,503 | INFO | 0.0.0.4 | 172.17.0.2 | mobservice2 | b51e6077dc4ed69a | info 0500c03c-fbce-11eb-a08c-0242ac110003:PMIwlKZi write success"}
```
Same service, the 2 minutes before (oldest first):
  08:32:56.766 [mobservice2] INFO info 010eef8a-fbce-11eb-8091-0242ac110003:CqkgPMzS write success
  08:32:58.164 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  08:32:58.164 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  08:32:58.165 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '01f7a78e-fbce-11eb-bc61-0242ac110004'}  (×4)
  08:32:58.207 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '01f7a78e-fbce-11eb-bc61-0242ac110004', 'value': 'UvLPSsVD'}  (×4)
  08:32:58.249 [mobservice2] INFO info 01f7a78e-fbce-11eb-bc61-0242ac110004:UvLPSsVD write success
  08:32:58.922 [mobservice2] INFO info 025c5b7a-fbce-11eb-b60b-0242ac110004:cmBuyeUK write success
  08:33:00.379 [mobservice2] INFO info 033161a8-fbce-11eb-b922-0242ac110003:aRNnXZPl write success
All services, 30 seconds either side (sampled):
  08:32:33.506 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×41)
  08:32:33.735 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×49)
  08:32:33.867 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×48)
  08:32:33.926 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'f3a0b9e6-fbcd-11eb-9c67-0242ac110003', 'value': '', 'ex': 10}  (×45)
  08:32:34.055 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×45)
  08:32:34.142 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×50)
  08:32:34.264 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×40)
  08:32:34.698 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×42)
  08:32:34.865 [redisservice2] INFO service accept, status_code: 200  (×29)
  08:32:37.260 [mobservice1] INFO info f55bc654-fbcd-11eb-a941-0242ac110004:wRjEsaDr write success  (×2)
  08:32:39.275 [dbservice1] INFO f669d2ca-fbcd-11eb-87d5-0242ac110004-hCIZuDLt-F^*JxWUs&YgO token generate success token=MTYyODgxNDc1OS4yNzU1NTU4OmY2NjlkMmNhLWZiY2QtMTFlYi04N2Q1LTAyNDJhYzE
  08:32:42.025 [mobservice2] INFO info f84a2d9c-fbcd-11eb-8744-0242ac110004:OvVHWlKe write success  (×2)
  08:32:44.346 [mobservice2] INFO info f9a1ca9c-fbcd-11eb-a44c-0242ac110004:UoOtrWnu write success
  08:32:51.545 [dbservice1] INFO fdaf69f0-fbcd-11eb-8ac0-0242ac110004-NXVPlvyB-(si6MhI%SkyT token generate success token=MTYyODgxNDc3MS41NDUxNTg6ZmRhZjY5ZjAtZmJjZC0xMWViLThhYzAtMDI0MmFjMTE  (×2)
  08:32:54.120 [mobservice2] INFO info ff81117a-fbcd-11eb-8982-0242ac110004:lkNrGYTL write success
  08:32:57.648 [mobservice1] INFO info 01992d4e-fbce-11eb-87f8-0242ac110004:cqyYsFCP write success
  08:33:01.200 [mobservice1] INFO info 03ac2726-fbce-11eb-bef0-0242ac110003:wYjKshxZ write success
  08:33:04.652 [dbservice1] ERROR password in database of {user} is null, the user is not registered  (×2)
  08:33:07.414 [mobservice2] INFO info 0769231e-fbce-11eb-9ab2-0242ac110003:AOMaRpbl write success
  08:33:09.480 [dbservice1] INFO 0864a202-fbce-11eb-8d38-0242ac110003-LxiphWgj-Y&VDZelm_>vj token generate success token=MTYyODgxNDc4OS40Nzk4MDI0OjA4NjRhMjAyLWZiY2UtMTFlYi04ZDM4LTAyNDJhYzE
  08:33:11.515 [dbservice1] INFO 099b5508-fbce-11eb-aa5f-0242ac110004-QlZMgGXD-Xez_ixZ.U!yo token generate success token=MTYyODgxNDc5MS41MTU1MDM0OjA5OWI1NTA4LWZiY2UtMTFlYi1hYTVmLTAyNDJhYzE
  08:33:13.988 [mobservice2] INFO info 0b490bfc-fbce-11eb-9a14-0242ac110003:VnGSpqai write success
  08:33:16.823 [mobservice2] INFO info 0cfcbcd2-fbce-11eb-8be9-0242ac110003:ItWBCNrc write success
  08:33:19.817 [mobservice1] INFO info 0eb3fa18-fbce-11eb-8a64-0242ac110004:dzcaqmiU write success
  08:33:22.756 [mobservice1] INFO info 1082e69c-fbce-11eb-ae43-0242ac110004:QYryCKLk write success
  08:33:25.841 [dbservice1] INFO 12276ffe-fbce-11eb-a56e-0242ac110004-HytkEBDf-z?M!i}>8wU$F token generate success token=MTYyODgxNDgwNS44NDA3NzI6MTIyNzZmZmUtZmJjZS0xMWViLWE1NmUtMDI0MmFjMTE
  08:33:28.773 [dbservice1] INFO 13d822c6-fbce-11eb-ab7f-0242ac110003-plhmCNjI-Qi)olTmvH02J token generate success token=MTYyODgxNDgwOC43NzI4MTI0OjEzZDgyMmM2LWZiY2UtMTFlYi1hYjdmLTAyNDJhYzE
  08:33:31.368 [mobservice2] INFO info 15a56a64-fbce-11eb-b15f-0242ac110004:pxXmtnLl write success

## p0830
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-other-service, 2024-12-08T12:20:15.504Z
```
{"timestamp":1733660415504957200,"container_name":"ts-order-other-service","pod_name":"ts-order-other-service-746fccc88f-swlz4","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-08 12:20:15.504  INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController    : [Order Other Service][Modify Order Status] Order Id: 4300dd0c-0367-4f81-8463-f33bb2423b56"}
```
Same service, the 2 minutes before (oldest first):
  12:19:54.715 [ts-order-other-service] 2024-12-08 12:19:54.715 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:0  (×3)
  12:19:54.720 [ts-order-other-service] 2024-12-08 12:19:54.720 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 101  (×3)
  12:19:54.795 [ts-order-other-service] 2024-12-08 12:19:54.795 INFO 1 --- [io-12032-exec-8] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×6)
  12:19:54.802 [ts-order-other-service] 2024-12-08 12:19:54.801 INFO 1 --- [io-12032-exec-8] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=178781  (×2)
  12:19:56.441 [ts-order-other-service] 2024-12-08 12:19:56.441 INFO 1 --- [io-12032-exec-1] other.controller.OrderOtherController : [Order Other Service][Security Info Get]
  12:20:15.254 [ts-order-other-service] 2024-12-08 12:20:15.254 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-
  12:20:15.260 [ts-order-other-service] 2024-12-08 12:20:15.260 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou
  12:20:15.260 [ts-order-other-service] 2024-12-08 12:20:15.260 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 112
  12:20:15.417 [ts-order-other-service] 2024-12-08 12:20:15.417 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Stations name list is : Response(status=1, msg=Success, data=[Shang H
  12:20:15.435 [ts-order-other-service] 2024-12-08 12:20:15.435 INFO 1 --- [io-12032-exec-1] other.controller.OrderOtherController : [Order Other Service][Get Order By Id] Order Id: 4300dd0c-0367-4f81
All services, 30 seconds either side (sampled):
  12:19:46.155 [ts-auth-service] 2024-12-08 12:19:46.155 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×14)
  12:19:46.339 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:19:46 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×32)
  12:19:46.424 [ts-travel2-service] 2024-12-08 12:19:46.423 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×133)
  12:19:52.160 [ts-basic-service] 2024-12-08 12:19:52.160 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×17)
  12:19:52.213 [ts-basic-service] 2024-12-08 12:19:52.213 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1  (×14)
  12:19:52.290 [ts-travel2-service] 2024-12-08 12:19:52.290 INFO 1 --- [io-16346-exec-4] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234  (×18)
  12:19:52.427 [ts-seat-service] 2024-12-08 12:19:52.427 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×13)
  12:19:54.273 [ts-travel-service] 2024-12-08 12:19:54.273 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×2)
  12:19:54.834 [ts-basic-service] 2024-12-08 12:19:54.833 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×6)
  12:19:55.404 [ts-admin-basic-info-service] 2024-12-08 12:19:55.403 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×2)
  12:19:56.076 [ts-travel-service] 2024-12-08 12:19:56.075 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×5)
  12:19:56.192 [ts-travel-service] 2024-12-08 12:19:56.191 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×10)
  12:19:56.333 [ts-food-service] 2024-12-08 12:19:56.333 INFO 1 --- [io-18856-exec-5] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!  (×2)
  12:19:56.418 [ts-security-service] 2024-12-08 12:19:56.417 INFO 1 --- [io-11188-exec-4] security.service.SecurityServiceImpl : [Security Service][Get Order Num Info]
  12:19:56.458 [ts-preserve-service] 2024-12-08 12:19:56.457 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Find contacts
  12:19:56.480 [ts-travel-service] 2024-12-08 12:19:56.479 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  12:19:56.890 [ts-seat-service] 2024-12-08 12:19:56.890 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Left ticket info is : Response(status=1, msg=Success, data=LeftTicketInfo{so
  12:19:56.932 [ts-order-service] 2024-12-08 12:19:56.931 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 50.0
  12:19:56.995 [ts-preserve-service] 2024-12-08 12:19:56.995 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Service][Step 7] Do not need to consign
  12:20:02.808 [ts-basic-service] 2024-12-08 12:20:02.808 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×2)
  12:20:08.397 [ts-admin-travel-service] 2024-12-08 12:20:08.397 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×4)
  12:20:11.707 [ts-station-mongo] {"t":{"$date":"2024-12-08T12:20:11.707+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366041
  12:20:13.109 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-08T12:20:13.109+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366041
  12:20:15.260 [ts-order-other-service] 2024-12-08 12:20:15.260 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou
  12:20:19.531 [ts-order-service] 2024-12-08 12:20:19.530 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Query Order][Step 1] Get Orders Number of Account: 139
  12:20:19.761 [ts-consign-service] 2024-12-08 12:20:19.760 INFO 1 --- [io-16111-exec-1] consign.service.ConsignServiceImpl : SAVE consign result : ConsignRecord(id=b9619901-ea78-4a20-a8f9-db53994
  12:20:27.657 [ts-basic-service] 2024-12-08 12:20:27.657 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270
  12:20:28.048 [ts-seat-service] 2024-12-08 12:20:28.047 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1235
  12:20:45.251 [ts-order-other-service] 2024-12-08 12:20:45.251 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 112

## p0644
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T20:29:21.502Z
```
{"timestamp":1733603361502718000,"container_name":"ts-auth-service","pod_name":"ts-auth-service-75dfb9459b-ntppp","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:29:21.502  INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl       : LOGIN USER :admin __ 222222 __ null"}
```
Same service, the 2 minutes before (oldest first):
  20:29:08.633 [ts-auth-service] 2024-12-07 20:29:08.633 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×2)
  20:29:08.633 [ts-auth-service] 2024-12-07 20:29:08.633 INFO 1 --- [io-12340-exec-9] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×2)
  20:29:08.788 [ts-auth-service] 2024-12-07 20:29:08.788 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×5)
  20:29:08.788 [ts-auth-service] 2024-12-07 20:29:08.788 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×5)
  20:29:12.197 [ts-auth-service] 2024-12-07 20:29:12.196 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×3)
  20:29:12.197 [ts-auth-service] 2024-12-07 20:29:12.197 INFO 1 --- [io-12340-exec-4] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×3)
All services, 30 seconds either side (sampled):
  20:28:51.977 [ts-auth-service] 2024-12-07 20:28:51.977 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×11)
  20:28:52.168 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:28:52 +0800] "POST /api/v1/users/login HTTP/1.1" 200 353 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×24)
  20:28:52.228 [ts-travel-service] 2024-12-07 20:28:52.228 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×2)
  20:28:52.266 [ts-route-service] 2024-12-07 20:28:52.265 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×27)
  20:28:53.304 [ts-basic-service] 2024-12-07 20:28:53.303 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×74)
  20:28:53.376 [ts-price-service] 2024-12-07 20:28:53.376 INFO 1 --- [io-16579-exec-6] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×19)
  20:28:53.396 [ts-order-other-service] 2024-12-07 20:28:53.396 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0
  20:28:53.454 [ts-travel2-service] 2024-12-07 20:28:53.454 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×12)
  20:28:53.488 [ts-seat-service] 2024-12-07 20:28:53.488 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×19)
  20:28:53.582 [ts-travel2-service] 2024-12-07 20:28:53.582 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×22)
  20:28:54.437 [ts-travel-service] 2024-12-07 20:28:54.437 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×21)
  20:28:55.558 [ts-admin-basic-info-service] 2024-12-07 20:28:55.558 INFO 1 --- [o-18767-exec-10] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult] 
  20:28:56.132 [ts-basic-service] 2024-12-07 20:28:56.132 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270  (×6)
  20:28:56.189 [ts-seat-service] 2024-12-07 20:28:56.189 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×15)
  20:28:56.317 [ts-travel-service] 2024-12-07 20:28:56.317 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×18)
  20:28:56.421 [ts-seat-service] 2024-12-07 20:28:56.421 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×3)
  20:28:56.790 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:28:56 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 916 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×4)
  20:28:57.663 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:28:57 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 5994 "-" "Mozilla/5.0 (Macintosh;  (×4)
  20:29:04.344 [ts-basic-service] 2024-12-07 20:29:04.344 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×2)
  20:29:04.374 [ts-basic-service] 2024-12-07 20:29:04.374 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×2)
  20:29:08.880 [ts-basic-service] 2024-12-07 20:29:08.880 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×4)
  20:29:11.643 [ts-price-service] 2024-12-07 20:29:11.643 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×2)
  20:29:28.401 [ts-travel-mongo] {"t":{"$date":"2024-12-07T20:29:28.401+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360336
  20:29:31.263 [ts-food-mongo] {"t":{"$date":"2024-12-07T20:29:31.262+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360337
  20:29:31.770 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:29:31.769+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360337
  20:29:38.813 [ts-travel-service] 2024-12-07 20:29:38.813 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  20:29:40.247 [ts-order-service] 2024-12-07 20:29:40.246 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160, 

## p0088
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T15:41:49.562Z
```
{"service":"logservice1","message":"2021-08-13 15:41:49,562 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | d9063279bc989b01 | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  15:41:46.007 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×2)
  15:41:46.007 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': 'e8c43f02-fc09-11eb-b310-0242ac110004', 'user_id': 'uGrcWJOt'}  (×6)
  15:41:46.562 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×4)
  15:41:46.562 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×4)
  15:41:49.334 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387
  15:41:49.334 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service
  15:41:49.335 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'eac8f9be-fc09-11eb-9f5d-0242ac110003'}
  15:41:49.390 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385
All services, 30 seconds either side (sampled):
  15:41:19.803 [dbservice1] INFO d8b7e500-fc09-11eb-9815-0242ac110004-IAqgbwQB-^lEzKvT%j{F_ token generate success token=MTYyODg0MDQ3OS44MDMyMTAzOmQ4YjdlNTAwLWZjMDktMTFlYi05ODE1LTAyNDJhYzE
  15:41:21.001 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×43)
  15:41:21.293 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  15:41:21.458 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×47)
  15:41:21.714 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×42)
  15:41:22.291 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×38)
  15:41:22.497 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×39)
  15:41:24.457 [redisservice1] INFO service accept, status_code: 200  (×34)
  15:41:25.409 [dbservice2] INFO dc54ef8c-fc09-11eb-a8a5-0242ac110003-avTqnNxg-L$C9/.km:^B% token generate success token=MTYyODg0MDQ4NS40MDg3NDIyOmRjNTRlZjhjLWZjMDktMTFlYi1hOGE1LTAyNDJhYzE
  15:41:28.374 [mobservice2] INFO info de47c90e-fc09-11eb-866b-0242ac110003:bykmrCDS write success
  15:41:31.770 [mobservice2] INFO info e059960a-fc09-11eb-b928-0242ac110004:jyDKkYiT write success
  15:41:34.304 [mobservice1] INFO info e1e29e18-fc09-11eb-939e-0242ac110003:GEFNbRmp write success
  15:41:36.876 [mobservice1] INFO info e36bf374-fc09-11eb-a245-0242ac110004:SBgdrmlT write success
  15:41:39.686 [mobservice1] INFO info e518da70-fc09-11eb-976e-0242ac110004:GNrVKoRp write success
  15:41:42.307 [mobservice1] INFO info e6aa0d78-fc09-11eb-9a2c-0242ac110003:xTQdRShl write success
  15:41:44.515 [dbservice2] INFO e7b17be8-fc09-11eb-b0b5-0242ac110003-wdBFovNq-V7}5cRoBi<z3 token generate success token=MTYyODg0MDUwNC41MTQ1NjI4OmU3YjE3YmU4LWZjMDktMTFlYi1iMGI1LTAyNDJhYzE
  15:41:47.092 [dbservice1] INFO e93c6bc6-fc09-11eb-be91-0242ac110004-jhoAGDST-%RJ/0?B1fm4L token generate success token=MTYyODg0MDUwNy4wOTIyNjM6ZTkzYzZiYzYtZmMwOS0xMWViLWJlOTEtMDI0MmFjMTE
  15:41:50.066 [dbservice1] INFO eae7e18a-fc09-11eb-b302-0242ac110004-QSUqdTsv-er_ATbj}/nc7 token generate success token=MTYyODg0MDUxMC4wNjU5MTMyOmVhZTdlMThhLWZjMDktMTFlYi1iMzAyLTAyNDJhYzE
  15:41:52.966 [mobservice1] INFO info ed031430-fc09-11eb-8d8c-0242ac110003:RspMxJbz write success
  15:41:55.551 [mobservice2] INFO info ee8daa68-fc09-11eb-af81-0242ac110004:aILTSXwD write success
  15:41:58.411 [mobservice2] INFO info f041e086-fc09-11eb-9198-0242ac110004:dMOcrJWb write success  (×2)
  15:42:01.196 [mobservice2] INFO info f1e885ca-fc09-11eb-8516-0242ac110003:ZQXfBztT write success  (×2)
  15:42:03.793 [mobservice1] INFO info f3777a72-fc09-11eb-bd82-0242ac110004:rydacQUo write success
  15:42:06.575 [mobservice1] INFO info f51d82c2-fc09-11eb-85b6-0242ac110003:ckaGqjZH write success
  15:42:09.241 [mobservice1] INFO info f6b43978-fc09-11eb-b238-0242ac110003:zLGEjrhw write success
  15:42:12.050 [dbservice2] INFO f82e9bfe-fc09-11eb-b932-0242ac110004-RIklYufT-gZ(@VjR5X^<E token generate success token=MTYyODg0MDUzMi4wNDk4MjAyOmY4MmU5YmZlLWZjMDktMTFlYi1iOTMyLTAyNDJhYzE
  15:42:15.219 [dbservice2] INFO f9e85b56-fc09-11eb-9fc6-0242ac110004-WuXJGtdQ-LCRs.nwO{0!? token generate success token=MTYyODg0MDUzNS4yMTg5NDc0OmY5ZTg1YjU2LWZjMDktMTFlYi05ZmM2LTAyNDJhYzE
  15:42:18.507 [dbservice1] INFO fbfe3974-fc09-11eb-8dcc-0242ac110004-DuxqVwXb-ERb{q2=85rWf token generate success token=MTYyODg0MDUzOC41MDc2MDY6ZmJmZTM5NzQtZmMwOS0xMWViLThkY2MtMDI0MmFjMTE

## p0568
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:30:51.661Z
```
{"timestamp":1733596251661597400,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:30:51.661  INFO 1 --- [           main] org.mongodb.driver.cluster               : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='30000 ms', maxWaitQueueSize=500}"}
```
Same service, the 2 minutes before (oldest first):
  18:30:41.368 [ts-auth-service] 2024-12-07 18:30:41.368 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.method.configuration.
  18:30:41.467 [ts-auth-service] 2024-12-07 18:30:41.466 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  18:30:41.960 [ts-auth-service] 2024-12-07 18:30:41.959 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact
  18:30:41.967 [ts-auth-service] 2024-12-07 18:30:41.967 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [java.util.Properties] is not e
  18:30:45.763 [ts-auth-service] 2024-12-07 18:30:45.763 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 12340 (http)
  18:30:46.661 [ts-auth-service] 2024-12-07 18:30:46.661 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  18:30:46.662 [ts-auth-service] 2024-12-07 18:30:46.661 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43
  18:30:47.673 [ts-auth-service] 2024-12-07 18:30:47.671 INFO 1 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  18:30:47.673 [ts-auth-service] 2024-12-07 18:30:47.673 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 20619 ms
  18:30:49.754 [ts-auth-service] 2024-12-07 18:30:49.754 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricsFilter' to: [/*]  (×8)
  18:30:49.764 [ts-auth-service] 2024-12-07 18:30:49.764 INFO 1 --- [ost-startStop-1] .s.DelegatingFilterProxyRegistrationBean : Mapping filter: 'springSecurityFilterChain' to: [/*]
  18:30:49.764 [ts-auth-service] 2024-12-07 18:30:49.764 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  18:30:51.479 [ts-auth-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
All services, 30 seconds either side (sampled):
  18:30:22.385 [ts-admin-basic-info-service] 2024-12-07 18:30:22.385 INFO 1 --- [io-18767-exec-3] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×9)
  18:30:25.325 [ts-route-service] 2024-12-07 18:30:25.325 INFO 1 --- [io-11178-exec-6] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×145)
  18:30:25.365 [ts-price-service] 2024-12-07 18:30:25.365 INFO 1 --- [io-16579-exec-8] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×18)
  18:30:25.435 [ts-basic-service] 2024-12-07 18:30:25.435 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×4)
  18:30:25.468 [ts-seat-service] 2024-12-07 18:30:25.468 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×17)
  18:30:25.535 [ts-order-other-service] 2024-12-07 18:30:25.534 INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×27)
  18:30:26.114 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:30:26 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 403 145 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×11)
  18:30:26.857 [ts-basic-service] 2024-12-07 18:30:26.856 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×10)
  18:30:28.123 [ts-admin-basic-info-service] 2024-12-07 18:30:28.123 INFO 1 --- [io-18767-exec-5] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×11)
  18:30:29.634 [ts-travel-service] 2024-12-07 18:30:29.634 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×12)
  18:30:30.509 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T18:30:30.509+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359623
  18:30:32.090 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:30:32 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 500 210 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Apple
  18:30:40.509 [ts-order-other-service] 2024-12-07 18:30:40.509 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×3)
  18:30:41.360 [ts-auth-service] 2024-12-07 18:30:41.359 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.access.expression.method.DefaultMethodS  (×2)
  18:30:42.223 [ts-train-mongo] {"t":{"$date":"2024-12-07T18:30:42.223+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359624
  18:30:46.661 [ts-auth-service] 2024-12-07 18:30:46.661 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]  (×2)
  18:30:47.154 [ts-travel-service] 2024-12-07 18:30:47.154 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×5)
  18:30:47.235 [ts-order-service] 2024-12-07 18:30:47.234 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 38  (×6)
  18:30:47.294 [ts-order-service] 2024-12-07 18:30:47.294 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×10)
  18:30:49.764 [ts-auth-service] 2024-12-07 18:30:49.764 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  18:31:00.335 [ts-order-other-service] 2024-12-07 18:31:00.334 ERROR 1 --- [io-12032-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×3)
  18:31:01.654 [ts-auth-service] 2024-12-07 18:31:01.653 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth],methods=[POST]}" onto public org.springframework.h
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.872 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  18:31:04.652 [ts-seat-service] 2024-12-07 18:31:04.652 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×2)
  18:31:09.955 [ts-auth-service] 2024-12-07 18:31:09.954 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 12340 (http)
  18:31:11.720 [ts-order-service] 2024-12-07 18:31:11.720 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : Left ticket info is empty  (×5)
  18:31:12.245 [ts-basic-service] 2024-12-07 18:31:12.245 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2
  18:31:18.568 [ts-auth-service] 2024-12-07 18:31:18.568 INFO 1 --- [io-12340-exec-3] org.mongodb.driver.connection : Opened connection [connectionId{localValue:3, serverValue:22}] to ts-auth-m  (×2)
  18:31:20.890 [ts-travel-service] 2024-12-07 18:31:20.889 ERROR 1 --- [io-12346-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt

## p0282
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:32:45.488Z
```
{"timestamp":1732242765488732000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"GET Request to: http://user/customers/673fed36b0df5c00019afc66/addresses"}
```
Same service, the 2 minutes before (oldest first):
  02:32:44.629 [front-end] 673fed4cb0df5c00019afca0
  02:32:44.629 [front-end] Merging carts for customer id: 673fed4cb0df5c00019afca0 and session id: CEQDt2YFJahazwVpBVo_KO5xdi7G4xSr
  02:32:44.649 [front-end] Carts merged.
  02:32:44.649 [front-end] set cookie673fed4cb0df5c00019afca0
  02:32:44.650 [front-end] Sent cookies.
  02:32:44.652 [front-end] POST /register 200 26.633 ms - 33
  02:32:45.218 [front-end] GET /catalogue 200 - ms - -
  02:32:45.279 [front-end] Request received with body: {}  (×2)
  02:32:45.288 [front-end] Received response: "{\"firstName\":\"bKQpLTpXBryVZc\",\"lastName\":\"bKQpLTpXBryVZc\",\"username\":\"bKQpLTpXBryVZc\",\"id\":\"673fed3db0df5c00019afc76\",\"_lin
  02:32:45.288 [front-end] GET Request to: http://user/customers/673fed3db0df5c00019afc76/addresses  (×2)
  02:32:45.296 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fed42b0df5c00019afc90\",\"_links\":{\"
  02:32:45.297 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:32:45.297 [front-end] [ undefined, undefined ]
  02:32:45.297 [front-end] Posting Order: {"customer":"http://user/customers/673fed3db0df5c00019afc76","address":"http://user/addresses/673fed42b0df5c00019afc8f","card":"http://user/cards
  02:32:45.330 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed4dd94b9000069b3ac2","customerId":"673fed3db0df5c00019afc76","customer":{"id":null,"firstName":"bKQpLTpXBry
  02:32:45.330 [front-end] Order response: {"id":"673fed4dd94b9000069b3ac2","customerId":"673fed3db0df5c00019afc76","customer":{"id":null,"firstName":"bKQpLTpXBryVZc","lastName":"bKQpLTpX
  02:32:45.332 [front-end] POST /orders 201 - ms - -
  02:32:45.488 [front-end] Received response: "{\"firstName\":\"pduQiNEY\",\"lastName\":\"pduQiNEY\",\"username\":\"pduQiNEY\",\"id\":\"673fed36b0df5c00019afc66\",\"_links\":{\"addresses\
All services, 30 seconds either side (sampled):
  02:32:15.488 [user] ts=2024-11-22T02:32:15.488386882Z caller=middlewares.go:75 method=GetUsers id=673fed21b0df5c00019afc26 result=1 took=768.728µs  (×174)
  02:32:15.528 [front-end] Order response: {"id":"673fed2fd94b9000069b3aa6","customerId":"673fed21b0df5c00019afc26","customer":{"id":null,"firstName":"HLVjkrFXedkhjV","lastName":"HLVjkrFX
  02:32:15.620 [front-end] POST /cards 200 - ms - -  (×67)
  02:32:15.816 [front-end] GET /catalogue 200 - ms - -  (×57)
  02:32:16.369 [orders] 2024-11-22 02:32:16.369 INFO [orders,2c62ff386f9dc4b4,f2a1dfc6ca0c2d30,false] 6 --- [-nio-80-exec-14] w.w.s.o.controllers.OrdersController : Sending payment req  (×23)
  02:32:16.768 [user] ts=2024-11-22T02:32:16.768509347Z caller=middlewares.go:46 method=Register username=AdqYAMWq email=AdqYAMWq@gmail.com took=980.02µs
  02:32:17.924 [front-end] Received response: "{\"firstName\":\"jjkxSMjKJesqH\",\"lastName\":\"jjkxSMjKJesqH\",\"username\":\"jjkxSMjKJesqH\",\"id\":\"673fed1cb0df5c00019afc19\",\"_links\
  02:32:19.626 [front-end] Order response: {"id":"673fed33d94b9000069b3aab","customerId":"673fed20b0df5c00019afc23","customer":{"id":null,"firstName":"rGhNgLmLlN","lastName":"rGhNgLmLlN",
  02:32:21.902 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×5)
  02:32:25.198 [front-end] Posting Customer: {"username":"prVOCoDnXP","password":"AsGEiugQqu","email":"prVOCoDnXP@gmail.com","firstName":"prVOCoDnXP","lastName":"prVOCoDnXP"}
  02:32:27.495 [front-end] Order response: {"id":"673fed3bd94b9000069b3ab1","customerId":"673fed2cb0df5c00019afc41","customer":{"id":null,"firstName":"WexGTzaRd","lastName":"WexGTzaRd","u
  02:32:30.175 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed3ed94b9000069b3ab3","customerId":"673fed26b0df5c00019afc38","customer":{"id":null,"firstName":"TlhfkdGaP",
  02:32:32.965 [front-end] Order response: {"id":"673fed40d94b9000069b3ab4","customerId":"673fed28b0df5c00019afc3c","customer":{"id":null,"firstName":"JwvpD","lastName":"JwvpD","username"
  02:32:38.002 [front-end] Order response: {"id":"673fed45d94b9000069b3ab7","customerId":"673fed30b0df5c00019afc50","customer":{"id":null,"firstName":"AdqYAMWq","lastName":"AdqYAMWq","use
  02:32:40.616 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed48d94b9000069b3abb","customerId":"673fed37b0df5c00019afc69","customer":{"id":null,"firstName":"kdYud","las
  02:32:42.373 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed4ad94b9000069b3abf","customerId":"673fed2fb0df5c00019afc4a","customer":{"id":null,"firstName":"bvBldjU","l
  02:32:44.601 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed4cd94b9000069b3ac1","customerId":"673fed34b0df5c00019afc5e","customer":{"id":null,"firstName":"czHqbaSrktN
  02:32:45.607 [front-end] Received response: "{\"firstName\":\"nkUrWpRyOH\",\"lastName\":\"nkUrWpRyOH\",\"username\":\"nkUrWpRyOH\",\"id\":\"673fed34b0df5c00019afc62\",\"_links\":{\"addr
  02:32:48.764 [front-end] Received response: "{\"firstName\":\"WxFwVzCV\",\"lastName\":\"WxFwVzCV\",\"username\":\"WxFwVzCV\",\"id\":\"673fed40b0df5c00019afc88\",\"_links\":{\"addresses\
  02:32:51.500 [user] ts=2024-11-22T02:32:51.500630242Z caller=middlewares.go:46 method=Register username=Xzieij email=Xzieij@gmail.com took=1.041287ms
  02:32:52.219 [front-end] Received response: "{\"firstName\":\"PLfekXETRCoGj\",\"lastName\":\"PLfekXETRCoGj\",\"username\":\"PLfekXETRCoGj\",\"id\":\"673fed41b0df5c00019afc89\",\"_links\
  02:32:55.513 [front-end] Posting Customer: {"username":"yhHqH","password":"lAAlA","email":"yhHqH@gmail.com","firstName":"yhHqH","lastName":"yhHqH"}
  02:33:00.432 [front-end] Received response: "{\"firstName\":\"xGgwqb\",\"lastName\":\"xGgwqb\",\"username\":\"xGgwqb\",\"id\":\"673fed4bb0df5c00019afc9e\",\"_links\":{\"addresses\":{\"h
  02:33:02.370 [user] ts=2024-11-22T02:33:02.370116847Z caller=middlewares.go:46 method=Register username=guFRQCW email=guFRQCW@gmail.com took=1.011935ms
  02:33:06.767 [front-end] Received response: "{\"firstName\":\"phobXOzKq\",\"lastName\":\"phobXOzKq\",\"username\":\"phobXOzKq\",\"id\":\"673fed4eb0df5c00019afca5\",\"_links\":{\"address
  02:33:09.006 [front-end] Received response: "{\"firstName\":\"FnrVar\",\"lastName\":\"FnrVar\",\"username\":\"FnrVar\",\"id\":\"673fed4bb0df5c00019afc9f\",\"_links\":{\"addresses\":{\"h
  02:33:11.966 [front-end] Posting Customer: {"username":"XRuRRjfkcPGa","password":"AEIUYudeh","email":"XRuRRjfkcPGa@gmail.com","firstName":"XRuRRjfkcPGa","lastName":"XRuRRjfkcPGa"}
  02:33:13.175 [front-end] Received response: "{\"firstName\":\"bvrlrgU\",\"lastName\":\"bvrlrgU\",\"username\":\"bvrlrgU\",\"id\":\"673fed53b0df5c00019afcb8\",\"_links\":{\"addresses\":{
  02:33:15.413 [front-end] Posting Customer: {"username":"vNajkcWqDqkPe","password":"gwKfQo","email":"vNajkcWqDqkPe@gmail.com","firstName":"vNajkcWqDqkPe","lastName":"vNajkcWqDqkPe"}

## p0503
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:15:55.432Z
```
{"timestamp":1732353355432114400,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:15:55.432007107Z caller=middlewares.go:75 method=GetUsers id=67419d35a437380001df0d3b result=1 took=2.558613ms"}
```
Same service, the 2 minutes before (oldest first):
  09:15:51.877 [user] ts=2024-11-23T09:15:51.877099554Z caller=middlewares.go:75 method=GetUsers id=67419d36a437380001df0d3c result=1 took=1.362659ms  (×11)
  09:15:52.535 [user] ts=2024-11-23T09:15:52.535190493Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419d42a437380001df0d5a took=4.379856ms  (×3)
  09:15:52.552 [user] ts=2024-11-23T09:15:52.552656718Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419d42a437380001df0d5a took=4.609873ms  (×3)
  09:15:52.645 [user] ts=2024-11-23T09:15:52.645380916Z caller=middlewares.go:46 method=Register username=LeAnb email=LeAnb@gmail.com took=1.905979ms
  09:15:52.849 [user] ts=2024-11-23T09:15:52.849511706Z caller=middlewares.go:157 method=Health result=2 took=2.587617ms  (×2)
All services, 30 seconds either side (sampled):
  09:15:25.531 [front-end] Request received with body: {}  (×63)
  09:15:25.557 [front-end] Posting Order: {"customer":"http://user/customers/67419d19a437380001df0cd7","address":"http://user/addresses/67419d22a437380001df0cfe","card":"http://user/cards  (×63)
  09:15:25.570 [front-end] POST /orders 400 - ms - -  (×63)
  09:15:25.737 [user] ts=2024-11-23T09:15:25.737530352Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419d26a437380001df0d0a took=4.868759ms  (×58)
  09:15:25.815 [front-end] Attempting to add to cart: {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×58)
  09:15:25.865 [front-end] POST /cart 201 - ms - -  (×58)
  09:15:27.512 [front-end] { id: '67419d2fa437380001df0d2a' }  (×55)
  09:15:27.538 [front-end] POST /register 200 34.467 ms - 33  (×55)
  09:15:30.810 [front-end] Received response: "{\"firstName\":\"HZfgGi\",\"lastName\":\"HZfgGi\",\"username\":\"HZfgGi\",\"id\":\"67419d1ba437380001df0ce6\",\"_links\":{\"addresses\":{\"h
  09:15:32.949 [front-end] Received response: "{\"firstName\":\"MQbafTneFzrU\",\"lastName\":\"MQbafTneFzrU\",\"username\":\"MQbafTneFzrU\",\"id\":\"67419d20a437380001df0cf4\",\"_links\":{
  09:15:35.348 [front-end] Received response: "{\"firstName\":\"NRJAZZDXtP\",\"lastName\":\"NRJAZZDXtP\",\"username\":\"NRJAZZDXtP\",\"id\":\"67419d22a437380001df0cfd\",\"_links\":{\"addr
  09:15:39.716 [front-end] Received response: "{\"firstName\":\"iEgwgz\",\"lastName\":\"iEgwgz\",\"username\":\"iEgwgz\",\"id\":\"67419d27a437380001df0d0e\",\"_links\":{\"addresses\":{\"h
  09:15:42.872 [user] ts=2024-11-23T09:15:42.872548052Z caller=middlewares.go:46 method=Register username=gbNeJiwDN email=gbNeJiwDN@gmail.com took=2.188515ms
  09:15:44.306 [user] ts=2024-11-23T09:15:44.3061683Z caller=middlewares.go:46 method=Register username=gnZOiAk email=gnZOiAk@gmail.com took=1.480244ms
  09:15:45.432 [user] ts=2024-11-23T09:15:45.432652592Z caller=middlewares.go:46 method=Register username=mfunLJQI email=mfunLJQI@gmail.com took=2.250135ms
  09:15:48.033 [front-end] Received response: "{\"firstName\":\"aUMalliUy\",\"lastName\":\"aUMalliUy\",\"username\":\"aUMalliUy\",\"id\":\"67419d2ba437380001df0d1c\",\"_links\":{\"address
  09:15:49.829 [front-end] Posting Customer: {"username":"UqWzNSFOIehUr","password":"rryXWcI","email":"UqWzNSFOIehUr@gmail.com","firstName":"UqWzNSFOIehUr","lastName":"UqWzNSFOIehUr"}
  09:15:52.638 [front-end] Posting Customer: {"username":"LeAnb","password":"dZNDpFVgVh","email":"LeAnb@gmail.com","firstName":"LeAnb","lastName":"LeAnb"}
  09:15:56.457 [front-end] Received response: "{\"firstName\":\"vJIgZeDYSNLnir\",\"lastName\":\"vJIgZeDYSNLnir\",\"username\":\"vJIgZeDYSNLnir\",\"id\":\"67419d3aa437380001df0d46\",\"_lin
  09:15:57.092 [front-end] Posting Customer: {"username":"QpCZDgavNfBe","password":"mwvadwI","email":"QpCZDgavNfBe@gmail.com","firstName":"QpCZDgavNfBe","lastName":"QpCZDgavNfBe"}
  09:16:00.567 [front-end] Posting Customer: {"username":"vaWayiqqwKj","password":"GFrsRNpnW","email":"vaWayiqqwKj@gmail.com","firstName":"vaWayiqqwKj","lastName":"vaWayiqqwKj"}
  09:16:02.865 [front-end] Received response: "{\"firstName\":\"NAapPGI\",\"lastName\":\"NAapPGI\",\"username\":\"NAapPGI\",\"id\":\"67419d40a437380001df0d53\",\"_links\":{\"addresses\":{
  09:16:05.682 [front-end] Received response: "{\"firstName\":\"vfUavwEyuD\",\"lastName\":\"vfUavwEyuD\",\"username\":\"vfUavwEyuD\",\"id\":\"67419d3ea437380001df0d4b\",\"_links\":{\"addr
  09:16:08.533 [front-end] Received response: "{\"firstName\":\"XTgfVPCoOuQ\",\"lastName\":\"XTgfVPCoOuQ\",\"username\":\"XTgfVPCoOuQ\",\"id\":\"67419d44a437380001df0d5e\",\"_links\":{\"a
  09:16:13.146 [front-end] Posting Customer: {"username":"jHWew","password":"lJBTaIVIxi","email":"jHWew@gmail.com","firstName":"jHWew","lastName":"jHWew"}
  09:16:14.649 [front-end] Posting Customer: {"username":"WsFIo","password":"MntWqJR","email":"WsFIo@gmail.com","firstName":"WsFIo","lastName":"WsFIo"}
  09:16:18.152 [front-end] Posting Customer: {"username":"jTkgd","password":"OQIBvWzm","email":"jTkgd@gmail.com","firstName":"jTkgd","lastName":"jTkgd"}
  09:16:19.416 [front-end] Posting Customer: {"username":"PXqDsVvt","password":"pJlIMJnFx","email":"PXqDsVvt@gmail.com","firstName":"PXqDsVvt","lastName":"PXqDsVvt"}
  09:16:23.139 [catalogue] ts=2024-11-23T09:16:23Z caller=logging.go:62 method=Get id=510a0d7e-8e83-4193-b483-e27e09ddc34d sock=510a0d7e-8e83-4193-b483-e27e09ddc34d err=null took=4.3998ms

## p0687
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-12T04:06:29.502Z
```
{"service":"redisservice1","message":"2021-08-12 04:06:29,502 | INFO | 0.0.0.1 | 172.17.0.4 | redisservice1 | 3c7eb8a3744f5eec | service accept, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  04:06:24.443 [redisservice1] INFO redis读取信息成功, status_code: 200  (×6)
  04:06:24.708 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×3)
  04:06:24.765 [redisservice1] INFO redis write success  (×8)
  04:06:26.935 [redisservice1] INFO service accept, status_code: 200  (×3)
All services, 30 seconds either side (sampled):
  04:05:59.537 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  04:05:59.675 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '8be62302-fadf-11eb-ac5f-0242ac110003', 'value': '', 'ex': 10}  (×43)
  04:05:59.889 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '8be62302-fadf-11eb-ac5f-0242ac110003'}  (×45)
  04:06:00.152 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×47)
  04:06:00.283 [dbservice1] INFO query = select passwards from username_table where user_name='UIkWCbjA'  (×42)
  04:06:01.689 [mobservice2] INFO info 8ce9e63a-fadf-11eb-a8c3-0242ac110003:tAOPYVGh write success
  04:06:02.101 [dbservice2] INFO 8ce9e63a-fadf-11eb-a8c3-0242ac110003-tAOPYVGh-x0_z<Z&/l9L+ token generate success token=MTYyODcxMjM2Mi4xMDA0Mzc2OjhjZTllNjNhLWZhZGYtMTFlYi1hOGMzLTAyNDJhYzE
  04:06:02.396 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×40)
  04:06:04.878 [mobservice2] INFO info 8ecd2836-fadf-11eb-89cd-0242ac110004:nSPeKIZU write success
  04:06:05.685 [mobservice1] INFO info 8f41ea22-fadf-11eb-bec4-0242ac110004:NWUBeIdk write success
  04:06:08.180 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  04:06:14.328 [dbservice2] INFO 942a1316-fadf-11eb-ab30-0242ac110003-GalEMmnB-.IlZmtSLXko4 token generate success token=MTYyODcxMjM3NC4zMjc2Mjg5Ojk0MmExMzE2LWZhZGYtMTFlYi1hYjMwLTAyNDJhYzE
  04:06:16.816 [dbservice2] INFO 95b4a2d2-fadf-11eb-8e56-0242ac110004-MutpDRNv-Bg}e7&n3q/j+ token generate success token=MTYyODcxMjM3Ni44MTYwNzQ4Ojk1YjRhMmQyLWZhZGYtMTFlYi04ZTU2LTAyNDJhYzE
  04:06:19.361 [dbservice2] INFO 97447b90-fadf-11eb-afb1-0242ac110004-CkWFaQYZ-7JwrWYRM-C^D token generate success token=MTYyODcxMjM3OS4zNjEwMzk6OTc0NDdiOTAtZmFkZi0xMWViLWFmYjEtMDI0MmFjMTE
  04:06:21.861 [mobservice1] INFO info 98e1c9bc-fadf-11eb-9988-0242ac110004:EVBLhgrm write success
  04:06:24.631 [dbservice1] INFO 9a59ed1a-fadf-11eb-bb08-0242ac110003-lqFmKxHv-(E%bNa0f83I5 token generate success token=MTYyODcxMjM4NC42MzExMzU6OWE1OWVkMWEtZmFkZi0xMWViLWJiMDgtMDI0MmFjMTE
  04:06:27.000 [dbservice1] INFO 9bc7960c-fadf-11eb-a5b0-0242ac110004-NFrlOSIe-=YK{V2Rx*D6H token generate success token=MTYyODcxMjM4Ni45OTk5NjgzOjliYzc5NjBjLWZhZGYtMTFlYi1hNWIwLTAyNDJhYzE
  04:06:29.988 [mobservice2] INFO info 9dc666f4-fadf-11eb-b740-0242ac110004:AZDazHog write success
  04:06:32.457 [mobservice1] INFO info 9f306db4-fadf-11eb-bb95-0242ac110004:NnLPEQzC write success
  04:06:35.532 [dbservice1] INFO a0d5fdf0-fadf-11eb-a8a6-0242ac110004-VHLPfDSU-?%<=*FYN4E2+ token generate success token=MTYyODcxMjM5NS41MzE5MDk3OmEwZDVmZGYwLWZhZGYtMTFlYi1hOGE2LTAyNDJhYzE
  04:06:37.998 [dbservice1] INFO a253ad3a-fadf-11eb-9ec9-0242ac110003-rpjRlDAu-{db}FToam8uK token generate success token=MTYyODcxMjM5Ny45OTc3MTg2OmEyNTNhZDNhLWZhZGYtMTFlYi05ZWM5LTAyNDJhYzE
  04:06:40.752 [dbservice2] INFO a3f20c9a-fadf-11eb-935e-0242ac110003-dImbafKg-u#L?}jdp-2_5 token generate success token=MTYyODcxMjQwMC43NTE1NzE6YTNmMjBjOWEtZmFkZi0xMWViLTkzNWUtMDI0MmFjMTE
  04:06:43.919 [dbservice1] INFO a5d68f36-fadf-11eb-9fa8-0242ac110004-AFDxXgnQ-nscvCSy=d^O1 token generate success token=MTYyODcxMjQwMy45MTg5MjQ4OmE1ZDY4ZjM2LWZhZGYtMTFlYi05ZmE4LTAyNDJhYzE
  04:06:46.486 [dbservice2] INFO a75e88ea-fadf-11eb-ba04-0242ac110003-PYaoLpfS-bW9F%P+AUv_Q token generate success token=MTYyODcxMjQwNi40ODU4ODg6YTc1ZTg4ZWEtZmFkZi0xMWViLWJhMDQtMDI0MmFjMTE
  04:06:48.587 [mobservice1] INFO info a8ccfdba-fadf-11eb-8b99-0242ac110004:JXejhiMl write success
  04:06:51.303 [dbservice2] INFO aa470abe-fadf-11eb-af96-0242ac110004-QgokVGXf-IJbkFjEAl(-K token generate success token=MTYyODcxMjQxMS4zMDMyNzM6YWE0NzBhYmUtZmFkZi0xMWViLWFmOTYtMDI0MmFjMTE
  04:06:53.802 [dbservice1] INFO abbb927a-fadf-11eb-a4e0-0242ac110003-qjaJKARf-$Vx*EY-<9!bz token generate success token=MTYyODcxMjQxMy44MDI0NTQyOmFiYmI5MjdhLWZhZGYtMTFlYi1hNGUwLTAyNDJhYzE
  04:06:56.542 [mobservice1] INFO info ad945532-fadf-11eb-9b4e-0242ac110004:lnbVdqst write success
  04:06:59.390 [dbservice1] INFO af0ba69a-fadf-11eb-8a33-0242ac110004-zTZgRokc-qrj>)^%vHmS2 token generate success token=MTYyODcxMjQxOS4zODk4MDQ0OmFmMGJhNjlhLWZhZGYtMTFlYi04YTMzLTAyNDJhYzE

## p0795
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-08T08:40:04.161Z
```
{"timestamp":1733647204161974300,"container_name":"ts-auth-service","pod_name":"ts-auth-service-75dfb9459b-qsspl","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 08:40:04.161  INFO 1 --- [       Thread-5] o.s.i.endpoint.EventDrivenConsumer       : stopped _org.springframework.integration.errorLogger"}
```
Same service, the 2 minutes before (oldest first):
  08:39:54.481 [ts-auth-service] 2024-12-08 08:39:54.481 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  08:39:54.481 [ts-auth-service] 2024-12-08 08:39:54.481 INFO 1 --- [io-12340-exec-8] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  08:39:54.666 [ts-auth-service] 2024-12-08 08:39:54.666 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×4)
  08:39:54.666 [ts-auth-service] 2024-12-08 08:39:54.666 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : 4c7ef37c-e8cb-4d29-aaca-62bd7a8da985 USER ID  (×4)
  08:39:58.201 [ts-auth-service] 2024-12-08 08:39:58.201 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×3)
  08:39:58.201 [ts-auth-service] 2024-12-08 08:39:58.201 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×3)
  08:40:04.157 [ts-auth-service] 2024-12-08 08:40:04.156 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  08:40:04.159 [ts-auth-service] 2024-12-08 08:40:04.158 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  08:40:04.160 [ts-auth-service] 2024-12-08 08:40:04.160 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  08:40:04.161 [ts-auth-service] 2024-12-08 08:40:04.161 INFO 1 --- [ Thread-5] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 0 subscriber(s).
All services, 30 seconds either side (sampled):
  08:39:34.456 [ts-food-service] 2024-12-08 08:39:34.456 INFO 1 --- [io-18856-exec-2] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×3)
  08:39:34.706 [ts-admin-basic-info-service] 2024-12-08 08:39:34.705 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  08:39:39.176 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:39:39 +0800] "POST /api/v1/users/login HTTP/1.1" 200 380 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×10)
  08:39:39.262 [ts-basic-service] 2024-12-08 08:39:39.262 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×21)
  08:39:39.290 [ts-order-other-service] 2024-12-08 08:39:39.290 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:0  (×13)
  08:39:39.367 [ts-order-other-service] 2024-12-08 08:39:39.366 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=208356  (×13)
  08:39:39.519 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:39:39 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 356 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×16)
  08:39:41.578 [ts-travel-service] 2024-12-08 08:39:41.577 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×8)
  08:39:41.626 [ts-basic-service] 2024-12-08 08:39:41.626 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×12)
  08:39:41.672 [ts-travel-service] 2024-12-08 08:39:41.672 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, tr  (×12)
  08:39:41.853 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:39:41 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 200 119 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
  08:39:41.966 [ts-security-service] 2024-12-08 08:39:41.966 INFO 1 --- [io-11188-exec-7] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....
  08:39:42.077 [ts-preserve-service] 2024-12-08 08:39:42.077 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Contacts Id: 47e015f5-6a9d-41ce-9b3a-e09
  08:39:42.155 [ts-basic-service] 2024-12-08 08:39:42.155 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe  (×3)
  08:39:42.349 [ts-seat-service] 2024-12-08 08:39:42.349 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×4)
  08:39:42.459 [ts-travel-service] 2024-12-08 08:39:42.459 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×2)
  08:39:42.495 [ts-preserve-service] 2024-12-08 08:39:42.494 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service][Order Price] Price is: 50.0
  08:39:42.518 [ts-preserve-service] 2024-12-08 08:39:42.518 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service][Add food Order] Creating....
  08:39:45.651 [ts-order-other-service] 2024-12-08 08:39:45.650 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=208356
  08:39:50.849 [ts-travel2-service] 2024-12-08 08:39:50.849 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×18)
  08:39:55.072 [ts-seat-service] 2024-12-08 08:39:55.072 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×5)
  08:39:55.599 [ts-travel-service] 2024-12-08 08:39:55.598 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1236
  08:40:01.457 [ts-travel2-service] 2024-12-08 08:40:01.457 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×3)
  08:40:04.165 [ts-auth-service] 2024-12-08 08:40:04.165 INFO 1 --- [ Thread-5] o.s.j.e.a.AnnotationMBeanExporter : Unregistering JMX-exposed beans on shutdown
  08:40:09.576 [ts-train-mongo] {"t":{"$date":"2024-12-08T08:40:09.576+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364720
  08:40:09.978 [ts-config-mongo] {"t":{"$date":"2024-12-08T08:40:09.978+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364720
  08:40:12.489 [ts-food-map-mongo] {"t":{"$date":"2024-12-08T08:40:12.488+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364721
  08:40:26.028 [ts-basic-service] 2024-12-08 08:40:26.028 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  08:40:30.988 [ts-auth-service] 2024-12-08 08:40:30.988 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'objectPostProcessor' of type [org.springframework.security.config.an

## p0178
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T06:38:41.942Z
```
{"timestamp":1731911921942951000,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  06:38:40.422 [currencyservice] conversion request successful  (×12)
  06:38:40.456 [currencyservice] Getting supported currencies...  (×8)
All services, 30 seconds either side (sampled):
  06:38:12.005 [frontend] request started  (×330)
  06:38:12.010 [cartservice] GetCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×271)
  06:38:12.029 [shippingservice] [GetQuote] completed request  (×82)
  06:38:12.344 [frontend] serving product page  (×153)
  06:38:13.522 [frontend] adding to cart  (×35)
  06:38:13.583 [checkoutservice] [PlaceOrder] user_id="736a09b5-665e-4823-8520-b8602b0bdbff" user_currency="JPY"
  06:38:13.611 [checkoutservice] payment went through (transaction_id: c8683601-ef99-457c-b160-2ed8e07f828c)  (×10)
  06:38:13.615 [cartservice] EmptyCartAsync called with userId=736a09b5-665e-4823-8520-b8602b0bdbff  (×10)
  06:38:13.622 [frontend] order placed  (×10)
  06:38:13.983 [paymentservice] Transaction processed: visa ending 7144 Amount: USD183.920000000  (×4)
  06:38:14.868 [adservice] received ad request (context_words=[kitchen])  (×47)
  06:38:18.042 [frontend] ENV_PLATFORM is: aws  (×36)
  06:38:18.662 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '9SIQT8TOJO', 'LS4PSXUNUM', '6E92ZMYYFZ']  (×4)
  06:38:20.428 [adservice] received ad request (context_words=[clothing, tops])  (×20)
  06:38:22.555 [paymentservice] Transaction processed: visa ending 6520 Amount: GBP485.873086245  (×2)
  06:38:23.740 [emailservice] Profiler disabled.
  06:38:28.239 [checkoutservice] failed to send order confirmation to "meghan56@example.com": rpc error: code = Unavailable desc = no healthy upstream
  06:38:48.653 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="EUR"  (×2)
  06:38:48.757 [checkoutservice] failed to send order confirmation to "victoria22@example.net": rpc error: code = Unavailable desc = no healthy upstream
  06:39:02.335 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="CAD"
  06:39:02.394 [checkoutservice] failed to send order confirmation to "tiffany12@example.org": rpc error: code = Unavailable desc = no healthy upstream

## p0254
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:07.449Z
```
{"timestamp":1732242487449736700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"statusCode\":500,\"body\":{\"timestamp\":1732242487446,\"status\":500,\"error\":\"Internal Server Error\",\"exception\":\"java.lang.IllegalStateException\",\"message\":\"Unable to create order due to unspecified IO error.\",\"path\":\"/orders\"},\"headers\":{\"x-application-context\":\"orders:80\",\"content-type\":\"application/json;charset=UTF-8\",\"date\":\"Fri, 22 Nov 2024 02:28:07 GMT\",\"x-envoy-upstream-service…"}
```
Same service, the 2 minutes before (oldest first):
  02:28:07.175 [front-end] GET /catalogue 200 - ms - -
  02:28:07.287 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2fb0df5c00019af954"}
  02:28:07.297 [front-end] POST /addresses 200 - ms - -
  02:28:07.303 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec2fb0df5c00019af954"}
  02:28:07.311 [front-end] POST /cards 200 - ms - -
  02:28:07.355 [front-end] Attempting to delete cart for user: 673fec2fb0df5c00019af954
  02:28:07.385 [front-end] User cart deleted with status: 503
  02:28:07.388 [front-end] DELETE /cart 503 - ms - -
  02:28:07.394 [front-end] Attempting to add to cart: {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","quantity":1}
  02:28:07.401 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
  02:28:07.401 [front-end] POST to carts: http://carts/carts/673fec2fb0df5c00019af954/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}
  02:28:07.402 [front-end] Request received with body: {}
  02:28:07.408 [front-end] Received response: "{\"firstName\":\"iTdzWTHcUAJJ\",\"lastName\":\"iTdzWTHcUAJJ\",\"username\":\"iTdzWTHcUAJJ\",\"id\":\"673fec22b0df5c00019af923\",\"_links\":{
  02:28:07.408 [front-end] GET Request to: http://user/customers/673fec22b0df5c00019af923/addresses  (×2)
  02:28:07.414 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec2bb0df5c00019af946\",\"_links\":{\"
  02:28:07.414 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:07.414 [front-end] [ undefined, undefined ]
  02:28:07.414 [front-end] Posting Order: {"customer":"http://user/customers/673fec22b0df5c00019af923","address":"http://user/addresses/673fec2bb0df5c00019af945","card":"http://user/cards
  02:28:07.436 [front-end] POST /cart 500 40.001 ms - 64
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×35)
  02:28:03.122 [front-end] GET /catalogue 200 - ms - -  (×40)
  02:28:03.196 [front-end] Received response: "{\"firstName\":\"FbddLnzSA\",\"lastName\":\"FbddLnzSA\",\"username\":\"FbddLnzSA\",\"id\":\"673fec21b0df5c00019af922\",\"_links\":{\"address
  02:28:03.245 [orders] 2024-11-22 02:28:03.244 ERROR [orders,,,] 6 --- [p-nio-80-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×16)
  02:28:03.391 [user] ts=2024-11-22T02:28:03.390808559Z caller=middlewares.go:46 method=Register username=kMzzAppFcYY email=kMzzAppFcYY@gmail.com took=958.317µs  (×5)
  02:28:03.523 [user] ts=2024-11-22T02:28:03.52331003Z caller=middlewares.go:46 method=Register username=sgQXbZQ email=sgQXbZQ@gmail.com took=1.065166ms
  02:28:05.055 [user] ts=2024-11-22T02:28:05.055011754Z caller=middlewares.go:104 method=GetAddresses id=673fec25b0df5c00019af92f result=1 took=781.934µs  (×15)
  02:28:06.796 [front-end] Posting Customer: {"username":"oyShDJ","password":"sWqvpeFZPy","email":"oyShDJ@gmail.com","firstName":"oyShDJ","lastName":"oyShDJ"}
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.451 [carts] 2024-11-22 02:28:10.451 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.377 [front-end] Received response: "{\"firstName\":\"vtFUiCYPGkr\",\"lastName\":\"vtFUiCYPGkr\",\"username\":\"vtFUiCYPGkr\",\"id\":\"673fec2bb0df5c00019af944\",\"_links\":{\"a
  02:28:19.135 [carts] 2024-11-22 02:28:18.940 INFO [carts,cb305558d352107b,fbb223eea295e77c,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×13)
  02:28:21.967 [front-end] Posting Customer: {"username":"PDQejFz","password":"UItpfuss","email":"PDQejFz@gmail.com","firstName":"PDQejFz","lastName":"PDQejFz"}
  02:28:23.046 [orders] 2024-11-22 02:28:23.045 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×5)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.870 [front-end] Received response: "{\"firstName\":\"sgQXbZQ\",\"lastName\":\"sgQXbZQ\",\"username\":\"sgQXbZQ\",\"id\":\"673fec33b0df5c00019af963\",\"_links\":{\"addresses\":{
  02:28:25.536 [carts] 2024-11-22 02:28:25.536 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.ItemsController : Did not find item.  (×10)
  02:28:26.351 [queue-master] Received shipment task: 673fec2db0df5c00019af953  (×14)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39cf","customerId":"673fec36b0df5c00019af96c","customer":{"id":null,"firstName":"oyShDJ","lastName":"oyShDJ","usernam
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.065 [front-end] Order response: {"id":"673fec4ad94b9000069b39d4","customerId":"673fec33b0df5c00019af963","customer":{"id":null,"firstName":"sgQXbZQ","lastName":"sgQXbZQ","usern
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket
  02:28:33.840 [front-end] Posting Customer: {"username":"MywYMGzyoIdhsgg","password":"SiEqM","email":"MywYMGzyoIdhsgg@gmail.com","firstName":"MywYMGzyoIdhsgg","lastName":"MywYMGzyoIdhsgg

## p0733
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-22T12:23:09.037Z
```
{"service":"frontend","operation":"hipstershop.CheckoutService/PlaceOrder","method":"PlaceOrder","status_code":13,"duration_us":35421,"trace_id":"6c1a5489386d4360f0d347e428dcfed7","message":"span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13"}
```
Same service, the 2 minutes before (oldest first):
  12:23:07.846 [frontend] home
  12:23:07.892 [frontend] ENV_PLATFORM is: aws
  12:23:07.897 [frontend] request complete  (×6)
  12:23:08.256 [frontend] request started  (×6)
  12:23:08.256 [frontend] serving product page  (×3)
  12:23:08.969 [frontend] adding to cart
  12:23:08.982 [frontend] view user cart
  12:23:09.037 [frontend] placing order
All services, 30 seconds either side (sampled):
  12:22:39.445 [frontend] request started  (×352)
  12:22:39.449 [frontend] home  (×42)
  12:22:39.464 [currencyservice] conversion request successful  (×804)
  12:22:39.742 [frontend] serving product page  (×147)
  12:22:40.491 [adservice] received ad request (context_words=[accessories])  (×41)
  12:22:40.509 [frontend] view user cart  (×76)
  12:22:40.539 [shippingservice] [GetQuote] completed request  (×90)
  12:22:44.844 [adservice] received ad request (context_words=[decor, home])  (×14)
  12:22:48.106 [checkoutservice] [PlaceOrder] user_id="4685a666-2807-489a-bc47-9c225a054c9e" user_currency="TRY"  (×3)
  12:22:48.140 [checkoutservice] payment went through (transaction_id: e5517cc2-2faf-488c-a1fe-709e9c4ccf59)  (×13)
  12:22:48.149 [cartservice] EmptyCartAsync called with userId=4685a666-2807-489a-bc47-9c225a054c9e  (×13)
  12:22:48.159 [frontend] order placed  (×13)
  12:22:48.864 [paymentservice] Transaction processed: visa ending 6582 Amount: JPY11621.420610630  (×3)
  12:22:49.494 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', '6E92ZMYYFZ', '66VCHSJNUP', 'OLJCESPC7Z']  (×5)
  12:22:49.594 [paymentservice] Transaction processed: visa ending 6505 Amount: CAD2635.831529409  (×5)
  12:22:57.821 [emailservice] A request to send order confirmation email to aanderson@example.org has been received.
  12:23:00.130 [checkoutservice] order confirmation email sent to "jennifermayer@example.org"
  12:23:03.104 [paymentservice] Transaction processed: visa ending 1957 Amount: GBP67.642914637  (×2)
  12:23:04.507 [emailservice] A request to send order confirmation email to floressteven@example.com has been received.
  12:23:06.238 [checkoutservice] order confirmation email sent to "vrussell@example.com"
  12:23:09.070 [paymentservice] UnacceptedCreditCard [Error]: Sorry, we cannot process visa_electron credit cards. Only VISA or MasterCard is accepted. at charge (/usr/src/app/charge.js:74:68)
  12:23:18.779 [emailservice] A request to send order confirmation email to amber87@example.net has been received.
  12:23:20.668 [checkoutservice] order confirmation email sent to "imcdaniel@example.com"
  12:23:24.631 [paymentservice] Transaction processed: visa ending 5709 Amount: EUR78.681999117
  12:23:34.234 [emailservice] A request to send order confirmation email to dperry@example.net has been received.
  12:23:38.655 [checkoutservice] order confirmation email sent to "debbie49@example.org"

## p0416
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T04:00:05.305Z
```
{"timestamp":1732248005305852200,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T04:00:05.305591668Z caller=middlewares.go:46 method=Register username=LfRWJRtiJfQM email=LfRWJRtiJfQM@gmail.com took=1.063367ms"}
```
Same service, the 2 minutes before (oldest first):
  04:00:03.290 [user] ts=2024-11-22T04:00:03.290701097Z caller=middlewares.go:75 method=GetUsers id=674001aeb0df5c00019b3b03 result=1 took=688.634µs  (×8)
  04:00:03.301 [user] ts=2024-11-22T04:00:03.301545241Z caller=middlewares.go:104 method=GetAddresses id=674001b5b0df5c00019b3b1c result=1 took=939.391µs  (×2)
  04:00:03.301 [user] ts=2024-11-22T04:00:03.301656086Z caller=middlewares.go:134 method=GetCards id=674001b5b0df5c00019b3b1d result=1 took=640.266µs  (×3)
  04:00:03.853 [user] ts=2024-11-22T04:00:03.853505422Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=674001bcb0df5c00019b3b35 took=1.674947ms
  04:00:03.867 [user] ts=2024-11-22T04:00:03.867177472Z caller=middlewares.go:118 method=PostCard card=*****3321 user=674001bcb0df5c00019b3b35 took=1.73873ms
  04:00:04.130 [user] ts=2024-11-22T04:00:04.130474042Z caller=middlewares.go:46 method=Register username=fRpqQWoee email=fRpqQWoee@gmail.com took=1.100038ms
  04:00:04.609 [user] ts=2024-11-22T04:00:04.609276157Z caller=middlewares.go:46 method=Register username=AUElEGHPZI email=AUElEGHPZI@gmail.com took=1.010604ms
  04:00:04.751 [user] ts=2024-11-22T04:00:04.750887799Z caller=middlewares.go:75 method=GetUsers id=674001aab0df5c00019b3af2 result=1 took=1.000987ms  (×2)
  04:00:05.045 [user] ts=2024-11-22T04:00:05.045080457Z caller=middlewares.go:104 method=GetAddresses id=674001b8b0df5c00019b3b2b result=1 took=1.041809ms
All services, 30 seconds either side (sampled):
  03:59:35.626 [catalogue] ts=2024-11-22T03:59:35Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.223828ms  (×59)
  03:59:36.060 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×66)
  03:59:36.409 [front-end] 674001a8b0df5c00019b3aee  (×63)
  03:59:36.493 [user] ts=2024-11-22T03:59:36.493641117Z caller=middlewares.go:75 method=GetUsers id=67400195b0df5c00019b3abd result=1 took=879.157µs  (×179)
  03:59:36.515 [carts] 2024-11-22 03:59:36.515 INFO [carts,11cef348f722770b,cd0b4cc5fad9e432,false] 7 --- [-nio-80-exec-19] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×44)
  03:59:36.537 [front-end] Order response: {"id":"674001a8d94b9000069b4a94","customerId":"67400195b0df5c00019b3abd","customer":{"id":null,"firstName":"YZayanyUWFArUx","lastName":"YZayanyU
  03:59:37.649 [front-end] Order response: {"statusCode":201,"body":{"id":"674001a9d94b9000069b4a96","customerId":"67400194b0df5c00019b3ab8","customer":{"id":null,"firstName":"cbNDkeKq","
  03:59:38.336 [front-end] Order response: {"statusCode":201,"body":{"id":"674001aad94b9000069b4a98","customerId":"6740019ab0df5c00019b3aca","customer":{"id":null,"firstName":"BlShGA","la
  03:59:39.418 [front-end] Order response: {"statusCode":201,"body":{"id":"674001abd94b9000069b4a99","customerId":"67400193b0df5c00019b3ab3","customer":{"id":null,"firstName":"ZVKFTVIDK",
  03:59:41.555 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×8)
  03:59:43.217 [front-end] Order response: {"id":"674001afd94b9000069b4a9b","customerId":"6740019fb0df5c00019b3ad9","customer":{"id":null,"firstName":"qYSeFiXINoZFY","lastName":"qYSeFiXIN
  03:59:47.455 [front-end] Posting Customer: {"username":"bNfXZDJMpHh","password":"oIibK","email":"bNfXZDJMpHh@gmail.com","firstName":"bNfXZDJMpHh","lastName":"bNfXZDJMpHh"}
  03:59:49.693 [front-end] Order response: {"timestamp":1732247989691,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×7)
  03:59:52.204 [front-end] Posting Customer: {"username":"pFxugK","password":"slRMeZooj","email":"pFxugK@gmail.com","firstName":"pFxugK","lastName":"pFxugK"}
  03:59:55.580 [front-end] Posting Customer: {"username":"iaGPmuQCvDk","password":"VxtPsYpXYg","email":"iaGPmuQCvDk@gmail.com","firstName":"iaGPmuQCvDk","lastName":"iaGPmuQCvDk"}
  03:59:56.866 [front-end] Posting Customer: {"username":"CFROAmBhLrQb","password":"nkmjoc","email":"CFROAmBhLrQb@gmail.com","firstName":"CFROAmBhLrQb","lastName":"CFROAmBhLrQb"}
  04:00:00.094 [user] ts=2024-11-22T04:00:00.094058937Z caller=middlewares.go:46 method=Register username=vPqtcrSoo email=vPqtcrSoo@gmail.com took=1.374407ms
  04:00:02.401 [front-end] Order response: {"statusCode":201,"body":{"id":"674001c2d94b9000069b4aab","customerId":"674001aeb0df5c00019b3b04","customer":{"id":null,"firstName":"qMmjfONUOwK
  04:00:04.794 [front-end] Order response: {"id":"674001c4d94b9000069b4aad","customerId":"674001aab0df5c00019b3af2","customer":{"id":null,"firstName":"QzDiKkkowmh","lastName":"QzDiKkkowmh
  04:00:06.607 [front-end] Order response: {"id":"674001c6d94b9000069b4ab0","customerId":"674001b7b0df5c00019b3b25","customer":{"id":null,"firstName":"NyUgn","lastName":"NyUgn","username"
  04:00:07.807 [front-end] Received response: "{\"firstName\":\"bNfXZDJMpHh\",\"lastName\":\"bNfXZDJMpHh\",\"username\":\"bNfXZDJMpHh\",\"id\":\"674001b3b0df5c00019b3b18\",\"_links\":{\"a
  04:00:13.707 [front-end] Posting Customer: {"username":"gpreFPTldfdhn","password":"CZiJjj","email":"gpreFPTldfdhn@gmail.com","firstName":"gpreFPTldfdhn","lastName":"gpreFPTldfdhn"}
  04:00:15.027 [front-end] Posting Customer: {"username":"dyBIK","password":"klLCJs","email":"dyBIK@gmail.com","firstName":"dyBIK","lastName":"dyBIK"}
  04:00:17.208 [front-end] Order response: {"id":"674001d1d94b9000069b4ab9","customerId":"674001bcb0df5c00019b3b36","customer":{"id":null,"firstName":"CFROAmBhLrQb","lastName":"CFROAmBhLr
  04:00:19.254 [front-end] Received response: "{\"firstName\":\"rvqurJLu\",\"lastName\":\"rvqurJLu\",\"username\":\"rvqurJLu\",\"id\":\"674001bcb0df5c00019b3b35\",\"_links\":{\"addresses\
  04:00:22.141 [front-end] Posting Customer: {"username":"zHpygbMRBzivH","password":"NXbLfJhU","email":"zHpygbMRBzivH@gmail.com","firstName":"zHpygbMRBzivH","lastName":"zHpygbMRBzivH"}
  04:00:24.520 [front-end] Order response: {"id":"674001d8d94b9000069b4abd","customerId":"674001c4b0df5c00019b3b48","customer":{"id":null,"firstName":"fRpqQWoee","lastName":"fRpqQWoee","u
  04:00:25.970 [front-end] Order response: {"id":"674001d9d94b9000069b4ac0","customerId":"674001c4b0df5c00019b3b49","customer":{"id":null,"firstName":"AUElEGHPZI","lastName":"AUElEGHPZI",
  04:00:28.439 [front-end] Posting Customer: {"username":"lADnzmei","password":"hKcSU","email":"lADnzmei@gmail.com","firstName":"lADnzmei","lastName":"lADnzmei"}
  04:00:33.820 [front-end] Posting Customer: {"username":"tzzZQnlzcJnu","password":"cdvhcIO","email":"tzzZQnlzcJnu@gmail.com","firstName":"tzzZQnlzcJnu","lastName":"tzzZQnlzcJnu"}

## p0455
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T08:06:32.803Z
```
{"timestamp":1732349192803110000,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:32.803  INFO [carts,2647ced1ca3ed2a8,2ee10f17902bcac4,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping   : Mapped \"{[/{repository}/{id}],methods=[GET],produces=[application/hal+json || application/json || application/*+json;charset=UTF-8]}\" onto public org.springframework.http.ResponseEntity<org.springframework.hateoas.Resource<?>> org.springframework.data.res…"}
```
Same service, the 2 minutes before (oldest first):
  08:06:30.800 [carts] 2024-11-23 08:06:30.799 INFO [carts,39cbdccef5aa5050,12923fc32fe9d0c9,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×3)
  08:06:30.800 [carts] 2024-11-23 08:06:30.799 INFO [carts,2a506c95faabcd8b,e8e79719f716f47a,false] 7 --- [-nio-80-exec-14] org.mongodb.driver.connection : Opened connection [connecti  (×7)
  08:06:31.006 [carts] 2024-11-23 08:06:31.006 INFO [carts,a0e69f995d2f669c,f5d1768d8ee773b1,false] 7 --- [-nio-80-exec-17] w.w.s.cart.controllers.CartsController : Merge carts reques
  08:06:32.706 [carts] 2024-11-23 08:06:32.705 INFO [carts,2647ced1ca3ed2a8,2ee10f17902bcac4,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],m  (×3)
  08:06:32.707 [carts] 2024-11-23 08:06:32.707 INFO [carts,2647ced1ca3ed2a8,2ee10f17902bcac4,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{reposi  (×6)
All services, 30 seconds either side (sampled):
  08:06:02.803 [front-end] Attempting to delete cart for user: 67418ce3a437380001deec69  (×54)
  08:06:03.631 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67418ce5a437380001deec6f"}  (×53)
  08:06:04.255 [orders] 2024-11-23 08:06:04.254 ERROR [orders,,,] 8 --- [p-nio-80-exec-7] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×25)
  08:06:05.045 [front-end] Carts merged.  (×56)
  08:06:07.000 [shipping] 2024-11-23 08:06:07.000 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[HEAD],produces=[application/hal+json
  08:06:07.008 [shipping] 2024-11-23 08:06:07.008 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[DELETE],prod
  08:06:07.479 [front-end] Received response: "{\"firstName\":\"zFrpP\",\"lastName\":\"zFrpP\",\"username\":\"zFrpP\",\"id\":\"67418cd8a437380001deec43\",\"_links\":{\"addresses\":{\"href
  08:06:13.021 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×6)
  08:06:14.614 [shipping] 2024-11-23 08:06:14.614 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as
  08:06:15.803 [carts] 2024-11-23 08:06:15.803 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[DELETE],produces=[applicat
  08:06:15.906 [carts] 2024-11-23 08:06:15.903 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http.
  08:06:17.812 [shipping] 2024-11-23 08:06:17.811 INFO [shipping,,,] 7 --- [ main] w.w.s.s.ShippingServiceApplication : Started ShippingServiceApplication in 109.591 seconds (JVM running
  08:06:19.103 [carts] 2024-11-23 08:06:19.102 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applicatio
  08:06:21.939 [front-end] Received response: "{\"firstName\":\"ucodWkVEg\",\"lastName\":\"ucodWkVEg\",\"username\":\"ucodWkVEg\",\"id\":\"67418cefa437380001deec8e\",\"_links\":{\"address
  08:06:24.580 [front-end] Received response: "{\"firstName\":\"djVRqry\",\"lastName\":\"djVRqry\",\"username\":\"djVRqry\",\"id\":\"67418cf2a437380001deec95\",\"_links\":{\"addresses\":{
  08:06:27.104 [carts] 2024-11-23 08:06:27.103 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:06:30.330 [front-end] Posting Customer: {"username":"pFbuHLdxmNq","password":"LQDNwOWSPu","email":"pFbuHLdxmNq@gmail.com","firstName":"pFbuHLdxmNq","lastName":"pFbuHLdxmNq"}
  08:06:32.706 [carts] 2024-11-23 08:06:32.705 INFO [carts,2647ced1ca3ed2a8,2ee10f17902bcac4,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],m  (×3)
  08:06:34.300 [carts] 2024-11-23 08:06:34.299 INFO [carts,25abd08d9dc45d7b,11863dd2db74dc3f,false] 7 --- [-nio-80-exec-18] w.w.s.cart.controllers.ItemsController : Did not find item.  (×20)
  08:06:35.608 [shipping] 2024-11-23 08:06:35.608 INFO [shipping,39cbdccef5aa5050,0c0b4cdf6a425110,false] 7 --- [p-nio-80-exec-5] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{rep  (×24)
  08:06:36.205 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d0b3f77060008864e3d","customerId":"67418ceca437380001deec88","customer":{"id":null,"firstName":"VnaknAEtTvw
  08:06:40.900 [queue-master] Caused by: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket
  08:06:42.919 [payment] ts=2024-11-23T08:06:42Z caller=logging.go:29 method=Authorise result=true took=1.067µs  (×7)
  08:06:46.850 [front-end] Received response: "{\"firstName\":\"VWOjt\",\"lastName\":\"VWOjt\",\"username\":\"VWOjt\",\"id\":\"67418cfaa437380001deecac\",\"_links\":{\"addresses\":{\"href
  08:06:48.501 [front-end] Order response: {"id":"67418d183f77060008864e4b","customerId":"67418d01a437380001deecbd","customer":{"id":null,"firstName":"kwCZmqZcyh","lastName":"kwCZmqZcyh",
  08:06:51.121 [front-end] Order response: {"id":"67418d1b3f77060008864e50","customerId":"67418d05a437380001deeccf","customer":{"id":null,"firstName":"wfUPLOtIGVQmB","lastName":"wfUPLOtIG
  08:06:53.837 [front-end] Received response: "{\"firstName\":\"KarxuPo\",\"lastName\":\"KarxuPo\",\"username\":\"KarxuPo\",\"id\":\"67418d0ba437380001deecdf\",\"_links\":{\"addresses\":{
  08:06:58.945 [front-end] Received response: "{\"firstName\":\"kLCCtcBYAzZly\",\"lastName\":\"kLCCtcBYAzZly\",\"username\":\"kLCCtcBYAzZly\",\"id\":\"67418d04a437380001deeccc\",\"_links\
  08:07:01.096 [front-end] Received response: "{\"firstName\":\"gSjFQJm\",\"lastName\":\"gSjFQJm\",\"username\":\"gSjFQJm\",\"id\":\"67418d12a437380001deecff\",\"_links\":{\"addresses\":{

## p0428
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-23T08:05:32.624Z
```
{"timestamp":1732349132624083700,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-zmfhr","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:05:32.623  INFO 7 --- [enerContainer-1] o.s.a.r.c.CachingConnectionFactory       : Created new connection: SimpleConnection@53c83726 [delegate=amqp://guest@10.100.144.197:5672/, localPort= 38294]"}
```
Same service, the 2 minutes before (oldest first):
  08:05:27.703 [queue-master] 2024-11-23 08:05:27.703 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]}" onto pub
  08:05:27.705 [queue-master] 2024-11-23 08:05:27.705 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/json]}" onto 
  08:05:27.705 [queue-master] 2024-11-23 08:05:27.705 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces=[applicati
  08:05:27.709 [queue-master] 2024-11-23 08:05:27.709 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
  08:05:27.710 [queue-master] 2024-11-23 08:05:27.710 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto public java
  08:05:27.710 [queue-master] 2024-11-23 08:05:27.710 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}" onto publ
  08:05:27.710 [queue-master] 2024-11-23 08:05:27.710 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/json]}" ont
  08:05:27.714 [queue-master] 2024-11-23 08:05:27.714 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/json]}" onto
  08:05:27.717 [queue-master] 2024-11-23 08:05:27.716 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics || /metrics.json],methods=[GET],produces=[application/json]
  08:05:27.717 [queue-master] 2024-11-23 08:05:27.717 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  08:05:27.725 [queue-master] 2024-11-23 08:05:27.725 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[application/jso
  08:05:27.725 [queue-master] 2024-11-23 08:05:27.725 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/prometheus || /prometheus.json],methods=[GET],produces=[text/plain;
  08:05:27.726 [queue-master] 2024-11-23 08:05:27.726 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[application/json]}" o
  08:05:27.726 [queue-master] 2024-11-23 08:05:27.726 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[application/json]}" o
  08:05:30.199 [queue-master] 2024-11-23 08:05:30.199 INFO 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:05:30.401 [queue-master] 2024-11-23 08:05:30.401 INFO 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'connectionFactory' has been autodetected for JMX exposure
  08:05:30.406 [queue-master] 2024-11-23 08:05:30.405 INFO 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'connectionFactory': registering with JMX server as MBean [o
  08:05:30.718 [queue-master] 2024-11-23 08:05:30.718 INFO 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase -2147482648
  08:05:30.803 [queue-master] 2024-11-23 08:05:30.718 INFO 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0  (×2)
All services, 30 seconds either side (sampled):
  08:05:16.044 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418cb4a437380001deebd3"}  (×51)
  08:05:16.760 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×9)
  08:05:17.264 [user] ts=2024-11-23T08:05:17.263792683Z caller=middlewares.go:46 method=Register username=gDHBQkBrIP email=gDHBQkBrIP@gmail.com took=2.137551ms  (×21)
  08:05:17.611 [front-end] POST to carts: http://carts/carts/67418cb4a437380001deebce/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}  (×25)
  08:05:19.109 [shipping] 2024-11-23 08:05:19.109 INFO [shipping,,,] 7 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 35890
  08:05:20.545 [user] ts=2024-11-23T08:05:20.54581224Z caller=middlewares.go:46 method=Register username=rsVXS email=rsVXS@gmail.com took=2.109538ms
  08:05:22.255 [front-end] Received response: "{\"firstName\":\"XEdyeann\",\"lastName\":\"XEdyeann\",\"username\":\"XEdyeann\",\"id\":\"67418caea437380001deebbe\",\"_links\":{\"addresses\
  08:05:26.146 [front-end] GET /catalogue 200 - ms - -  (×40)
  08:05:26.604 [queue-master] 2024-11-23 08:05:26.604 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[application/hal+json
  08:05:26.611 [queue-master] 2024-11-23 08:05:26.611 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],produces=[applica
  08:05:27.710 [queue-master] 2024-11-23 08:05:27.710 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto public java
  08:05:27.912 [carts] 2024-11-23 08:05:27.912 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  08:05:29.090 [orders] 2024-11-23 08:05:29.090 INFO [orders,,,] 8 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respo
  08:05:31.194 [orders] 2024-11-23 08:05:31.193 INFO [orders,,,] 8 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.contex
  08:05:32.620 [rabbitmq] connection <0.553.0> (127.0.0.6:56451 -> 192.168.93.151:5672): user 'guest' authenticated and granted access to vhost '/'
  08:05:35.382 [front-end] Received response: "{\"firstName\":\"iFVPDhisWkusfR\",\"lastName\":\"iFVPDhisWkusfR\",\"username\":\"iFVPDhisWkusfR\",\"id\":\"67418cc0a437380001deebfa\",\"_lin
  08:05:37.558 [user] ts=2024-11-23T08:05:37.55870177Z caller=middlewares.go:46 method=Register username=QTNxlk email=QTNxlk@gmail.com took=2.268833ms
  08:05:39.188 [orders] 2024-11-23 08:05:39.188 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[applicatio
  08:05:39.195 [orders] 2024-11-23 08:05:39.195 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces
  08:05:39.860 [front-end] Received response: "{\"firstName\":\"ZITzoSR\",\"lastName\":\"ZITzoSR\",\"username\":\"ZITzoSR\",\"id\":\"67418cc1a437380001deebfe\",\"_links\":{\"addresses\":{
  08:05:41.191 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto
  08:05:43.228 [queue-master] 2024-11-23 08:05:43.228 INFO 7 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  08:05:44.797 [front-end] Posting Customer: {"username":"MQTmuf","password":"MuFCRVJR","email":"MQTmuf@gmail.com","firstName":"MQTmuf","lastName":"MQTmuf"}
  08:05:47.932 [front-end] Received response: "{\"firstName\":\"LfIsYIKrCRnU\",\"lastName\":\"LfIsYIKrCRnU\",\"username\":\"LfIsYIKrCRnU\",\"id\":\"67418ccba437380001deec22\",\"_links\":{
  08:05:49.794 [orders] 2024-11-23 08:05:49.794 INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],  (×3)
  08:05:51.461 [front-end] Posting Customer: {"username":"JfkloKMY","password":"BAlPTCaswY","email":"JfkloKMY@gmail.com","firstName":"JfkloKMY","lastName":"JfkloKMY"}
  08:05:54.905 [shipping] 2024-11-23 08:05:54.905 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produce
  08:05:55.103 [shipping] 2024-11-23 08:05:55.103 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto publi
  08:05:59.408 [front-end] Posting Customer: {"username":"VWRTM","password":"jtBtF","email":"VWRTM@gmail.com","firstName":"VWRTM","lastName":"VWRTM"}
  08:06:00.500 [carts] 2024-11-23 08:06:00.500 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[DE

## p0415
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:59:50.970Z
```
{"timestamp":1732247990970622500,"container_name":"front-end","pod_name":"front-end-ccbbfbf7f-szg8d","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"POST /register 200 30.064 ms - 33"}
```
Same service, the 2 minutes before (oldest first):
  03:59:50.667 [front-end] Order response: {"statusCode":201,"body":{"id":"674001b6d94b9000069b4aa1","customerId":"674001a1b0df5c00019b3adc","customer":{"id":null,"firstName":"GLmwFtUqrc"
  03:59:50.667 [front-end] Order response: {"id":"674001b6d94b9000069b4aa1","customerId":"674001a1b0df5c00019b3adc","customer":{"id":null,"firstName":"GLmwFtUqrc","lastName":"GLmwFtUqrc",
  03:59:50.668 [front-end] POST /orders 201 - ms - -
  03:59:50.846 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"674001b0b0df5c00019b3b0f"}
  03:59:50.854 [front-end] POST /addresses 200 - ms - -
  03:59:50.860 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674001b0b0df5c00019b3b0f"}
  03:59:50.868 [front-end] POST /cards 200 - ms - -
  03:59:50.917 [front-end] Attempting to delete cart for user: 674001b0b0df5c00019b3b0f
  03:59:50.937 [front-end] User cart deleted with status: 202
  03:59:50.939 [front-end] DELETE /cart 202 - ms - -
  03:59:50.939 [front-end] Posting Customer: {"username":"calZDSUrSvqM","password":"OuosRh","email":"calZDSUrSvqM@gmail.com","firstName":"calZDSUrSvqM","lastName":"calZDSUrSvqM"}
  03:59:50.944 [front-end] Attempting to add to cart: {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  03:59:50.947 [front-end] { id: '674001b6b0df5c00019b3b24' }
  03:59:50.947 [front-end] 674001b6b0df5c00019b3b24
  03:59:50.947 [front-end] Merging carts for customer id: 674001b6b0df5c00019b3b24 and session id: CEQDt2YFJahazwVpBVo_KO5xdi7G4xSr
  03:59:50.955 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca
  03:59:50.955 [front-end] POST to carts: http://carts/carts/674001b0b0df5c00019b3b0f/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}
  03:59:50.969 [front-end] Carts merged.
  03:59:50.969 [front-end] set cookie674001b6b0df5c00019b3b24
  03:59:50.969 [front-end] Sent cookies.
All services, 30 seconds either side (sampled):
  03:59:21.031 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67400193b0df5c00019b3ab3"}  (×56)
  03:59:21.185 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×3)
  03:59:22.022 [front-end] 6740019ab0df5c00019b3aca  (×60)
  03:59:22.288 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67400  (×63)
  03:59:22.352 [catalogue] ts=2024-11-22T03:59:22Z caller=logging.go:85 method=Health result=2 took=26.59µs  (×40)
  03:59:22.996 [queue-master] 2024-11-22 03:59:22.996 ERROR 6 --- [ool-6-thread-31] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×45)
  03:59:24.039 [front-end] Order response: {"statusCode":201,"body":{"id":"6740019cd94b9000069b4a88","customerId":"67400187b0df5c00019b3a80","customer":{"id":null,"firstName":"gnjGn","las
  03:59:26.125 [front-end] Order response: {"statusCode":201,"body":{"id":"6740019ed94b9000069b4a8b","customerId":"6740018cb0df5c00019b3a93","customer":{"id":null,"firstName":"WySFqIKfSpG
  03:59:27.501 [front-end] Posting Customer: {"username":"cDRIjYbNsQqX","password":"NyxnG","email":"cDRIjYbNsQqX@gmail.com","firstName":"cDRIjYbNsQqX","lastName":"cDRIjYbNsQqX"}
  03:59:29.111 [orders-db] {"t":{"$date":"2024-11-22T03:59:29.111+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224796
  03:59:30.441 [front-end] Order response: {"statusCode":201,"body":{"id":"674001a2d94b9000069b4a92","customerId":"67400193b0df5c00019b3ab2","customer":{"id":null,"firstName":"QyFbVbmlR",
  03:59:34.577 [front-end] Posting Customer: {"username":"rMVodoyoDcUd","password":"ZoJhOxRSwn","email":"rMVodoyoDcUd@gmail.com","firstName":"rMVodoyoDcUd","lastName":"rMVodoyoDcUd"}
  03:59:37.470 [front-end] Order response: {"id":"674001a9d94b9000069b4a95","customerId":"67400197b0df5c00019b3ac0","customer":{"id":null,"firstName":"pJYADOpahdfb","lastName":"pJYADOpahd
  03:59:38.493 [front-end] Posting Customer: {"username":"QzDiKkkowmh","password":"zbuZFXr","email":"QzDiKkkowmh@gmail.com","firstName":"QzDiKkkowmh","lastName":"QzDiKkkowmh"}
  03:59:39.457 [queue-master] 2024-11-22 03:59:39.457 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×27)
  03:59:42.743 [user] ts=2024-11-22T03:59:42.743417891Z caller=middlewares.go:46 method=Register username=tyvOHnbaz email=tyvOHnbaz@gmail.com took=812.154µs
  03:59:47.314 [front-end] Order response: {"id":"674001b3d94b9000069b4a9d","customerId":"674001a1b0df5c00019b3adb","customer":{"id":null,"firstName":"LUyqlIvHO","lastName":"LUyqlIvHO","u
  03:59:49.996 [front-end] Order response: {"id":"674001b5d94b9000069b4aa0","customerId":"6740019db0df5c00019b3ad3","customer":{"id":null,"firstName":"OdfZQKJyF","lastName":"OdfZQKJyF","u
  03:59:54.162 [front-end] Order response: {"id":"674001bad94b9000069b4aa2","customerId":"674001a5b0df5c00019b3ae4","customer":{"id":null,"firstName":"dXiPATGXH","lastName":"dXiPATGXH","u
  03:59:56.164 [front-end] Order response: {"id":"674001bcd94b9000069b4aa5","customerId":"674001a9b0df5c00019b3af1","customer":{"id":null,"firstName":"cdiwQUs","lastName":"cdiwQUs","usern
  03:59:57.993 [front-end] Received response: "{\"firstName\":\"tyvOHnbaz\",\"lastName\":\"tyvOHnbaz\",\"username\":\"tyvOHnbaz\",\"id\":\"674001aeb0df5c00019b3b06\",\"_links\":{\"address
  04:00:02.049 [front-end] Received response: "{\"firstName\":\"vjfdmAgfi\",\"lastName\":\"vjfdmAgfi\",\"username\":\"vjfdmAgfi\",\"id\":\"674001aab0df5c00019b3af3\",\"_links\":{\"address
  04:00:04.753 [front-end] Received response: "{\"firstName\":\"QzDiKkkowmh\",\"lastName\":\"QzDiKkkowmh\",\"username\":\"QzDiKkkowmh\",\"id\":\"674001aab0df5c00019b3af2\",\"_links\":{\"a
  04:00:06.607 [front-end] Order response: {"statusCode":201,"body":{"id":"674001c6d94b9000069b4ab0","customerId":"674001b7b0df5c00019b3b25","customer":{"id":null,"firstName":"NyUgn","las
  04:00:07.807 [front-end] Received response: "{\"firstName\":\"bNfXZDJMpHh\",\"lastName\":\"bNfXZDJMpHh\",\"username\":\"bNfXZDJMpHh\",\"id\":\"674001b3b0df5c00019b3b18\",\"_links\":{\"a
  04:00:13.730 [front-end] Posting Customer: {"username":"WcbPQzRZhZfUVj","password":"aUZttTadzR","email":"WcbPQzRZhZfUVj@gmail.com","firstName":"WcbPQzRZhZfUVj","lastName":"WcbPQzRZhZfUV
  04:00:15.626 [front-end] Posting Customer: {"username":"ierRtwnhAyOjVb","password":"fmFYmmr","email":"ierRtwnhAyOjVb@gmail.com","firstName":"ierRtwnhAyOjVb","lastName":"ierRtwnhAyOjVb"}
  04:00:17.872 [user] ts=2024-11-22T04:00:17.872168201Z caller=middlewares.go:46 method=Register username=KaYKgP email=KaYKgP@gmail.com took=1.075152ms

## p0556
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-07T18:24:33.529Z
```
{"timestamp":1733595873529670000,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-srqkn","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 18:24:33.529  INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl  : [Basic Information Service][Check Station Exists] Station Name: Su Zhou"}
```
Same service, the 2 minutes before (oldest first):
  18:24:33.286 [ts-basic-service] 2024-12-07 18:24:33.286 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×5)
  18:24:33.303 [ts-basic-service] 2024-12-07 18:24:33.303 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×3)
  18:24:33.313 [ts-basic-service] 2024-12-07 18:24:33.313 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe
  18:24:33.321 [ts-basic-service] 2024-12-07 18:24:33.321 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69
  18:24:33.327 [ts-basic-service] 2024-12-07 18:24:33.327 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  18:24:33.327 [ts-basic-service] 2024-12-07 18:24:33.327 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4
  18:24:33.337 [ts-basic-service] 2024-12-07 18:24:33.337 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  18:24:33.337 [ts-basic-service] 2024-12-07 18:24:33.337 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×3)
  18:24:33.347 [ts-basic-service] 2024-12-07 18:24:33.347 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
  18:24:33.347 [ts-basic-service] 2024-12-07 18:24:33.347 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1
  18:24:33.347 [ts-basic-service] 2024-12-07 18:24:33.347 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : route.getDistances().size : 2
  18:24:33.367 [ts-basic-service] 2024-12-07 18:24:33.366 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha
All services, 30 seconds either side (sampled):
  18:24:03.863 [ts-admin-basic-info-service] 2024-12-07 18:24:03.863 INFO 1 --- [io-18767-exec-6] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×14)
  18:24:04.071 [ts-travel-service] 2024-12-07 18:24:04.071 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×34)
  18:24:08.704 [ts-travel-service] 2024-12-07 18:24:08.704 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×18)
  18:24:08.802 [ts-travel-service] 2024-12-07 18:24:08.802 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×2)
  18:24:16.131 [ts-auth-service] 2024-12-07 18:24:16.131 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×10)
  18:24:16.386 [ts-price-service] 2024-12-07 18:24:16.386 INFO 1 --- [io-16579-exec-5] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×19)
  18:24:16.494 [ts-seat-service] 2024-12-07 18:24:16.494 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×33)
  18:24:16.546 [ts-travel2-service] 2024-12-07 18:24:16.546 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×22)
  18:24:20.311 [ts-travel2-service] 2024-12-07 18:24:20.311 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  18:24:21.128 [ts-auth-service] 2024-12-07 18:24:21.127 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
  18:24:25.291 [ts-price-service] 2024-12-07 18:24:25.290 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: 0b23bd3e-876a-4af3-b92  (×2)
  18:24:27.205 [ts-seat-service] 2024-12-07 18:24:27.205 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×6)
  18:24:29.579 [ts-basic-service] 2024-12-07 18:24:29.578 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×7)
  18:24:29.783 [ts-order-service] 2024-12-07 18:24:29.783 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×13)
  18:24:30.027 [ts-assurance-service] 2024-12-07 18:24:30.027 INFO 1 --- [o-18888-exec-10] a.controller.AssuranceController : [Assurances Service][Get Assurance Type]
  18:24:30.064 [ts-security-service] 2024-12-07 18:24:30.064 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....
  18:24:30.101 [ts-preserve-service] 2024-12-07 18:24:30.101 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Getting....  (×2)
  18:24:30.395 [ts-order-service] 2024-12-07 18:24:30.395 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 34  (×4)
  18:24:30.729 [ts-user-mongo] {"t":{"$date":"2024-12-07T18:24:30.728+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359587
  18:24:30.917 [ts-inside-payment-service] 2024-12-07 18:24:30.916 INFO 1 --- [io-18673-exec-7] i.service.InsidePaymentServiceImpl : Out pay result: Response(status=1, msg=Pay Success, data=null)
  18:24:31.102 [ts-preserve-service] 2024-12-07 18:24:31.101 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Creating....  (×2)
  18:24:31.186 [ts-preserve-service] 2024-12-07 18:24:31.185 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Cancel Order Service][Get Order By Id]  (×2)
  18:24:33.474 [ts-travel-service] 2024-12-07 18:24:33.474 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  18:24:33.904 [ts-seat-service] 2024-12-07 18:24:33.904 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Left ticket info is : Response(status=1, msg=Success, data=LeftTicketInfo{so
  18:24:42.149 [ts-payment-mongo] {"t":{"$date":"2024-12-07T18:24:42.149+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359588
  18:24:53.016 [ts-preserve-other-service] 2024-12-07 18:24:53.016 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security
  18:24:53.123 [ts-travel2-service] 2024-12-07 18:24:53.122 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [TravelService] [getTripAllDetailInfo] endPlaceID: nanjing
  18:24:53.560 [ts-order-other-service] 2024-12-07 18:24:53.560 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Create Order] Create Order form shanghai --->
  18:24:53.586 [ts-preserve-other-service] 2024-12-07 18:24:53.586 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 7] Do not need to consign

## p0156
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T05:44:49.266Z
```
{"timestamp":1731908689266720300,"container_name":"cartservice","pod_name":"cartservice-59d958f58c-l6zmr","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=33421b66-55b6-413b-9ba9-3230c85c58dc"}
```
Same service, the 2 minutes before (oldest first):
  05:44:44.859 [cartservice] GetCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×18)
  05:44:47.321 [cartservice] AddItemAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4, productId=OLJCESPC7Z, quantity=10000000000
  05:44:47.324 [cartservice] info: Grpc.AspNetCore.Server.ServerCallHandler[7] Error status code 'FailedPrecondition' with detail 'Can't access cart storage. System.OverflowException: Value
All services, 30 seconds either side (sampled):
  05:44:19.624 [frontend] request started  (×267)
  05:44:19.626 [currencyservice] Getting supported currencies...  (×224)
  05:44:19.641 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '66VCHSJNUP', '1YMWWN1N4O', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×192)
  05:44:19.653 [shippingservice] [GetQuote] completed request  (×53)
  05:44:19.659 [frontend] request complete  (×267)
  05:44:19.865 [adservice] received ad request (context_words=[decor, home])  (×21)
  05:44:20.642 [adservice] received ad request (context_words=[accessories])  (×29)
  05:44:20.650 [frontend] span hipstershop.CartService/AddItem failed with gRPC status 9  (×23)
  05:44:20.654 [cartservice] info: Grpc.AspNetCore.Server.ServerCallHandler[7] Error status code 'FailedPrecondition' with detail 'Can't access cart storage. System.OverflowException: Value  (×23)
  05:44:20.659 [frontend] placing order  (×7)
  05:44:20.680 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"21120","nanos":707651923},"credit_card":{"credit_card_number":"475006221986
  05:44:20.682 [checkoutservice] payment went through (transaction_id: 7396d42e-b7cc-4938-ba4e-73ebea4333b0)  (×7)
  05:44:20.683 [shippingservice] [ShipOrder] completed request  (×7)
  05:44:20.694 [emailservice] A request to send order confirmation email to jacquelinewilliams@example.org has been received.
  05:44:20.696 [frontend] order placed  (×7)
  05:44:20.854 [frontend] home  (×30)
  05:44:20.904 [adservice] received ad request (context_words=[])  (×30)
  05:44:22.541 [adservice] received ad request (context_words=[kitchen])  (×54)
  05:44:22.588 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"48","nanos":705044670},"credit_card":{"credit_card_number":"490238439821302  (×2)
  05:44:22.601 [emailservice] A request to send order confirmation email to ryankristin@example.org has been received.
  05:44:23.566 [adservice] received ad request (context_words=[clothing, tops])  (×14)
  05:44:34.855 [checkoutservice] order confirmation email sent to "steven93@example.com"
  05:44:41.950 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="USD"
  05:44:41.964 [paymentservice] Transaction processed: visa ending 1064 Amount: USD8.990000000
  05:44:41.978 [checkoutservice] order confirmation email sent to "youngjessica@example.net"
  05:44:53.765 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"2061","nanos":683034049},"credit_card":{"credit_card_number":"4189136193455  (×3)
  05:44:53.778 [emailservice] A request to send order confirmation email to jacksonrenee@example.org has been received.
  05:44:54.043 [emailservice] A request to send order confirmation email to rbarrera@example.org has been received.
  05:45:08.823 [emailservice] A request to send order confirmation email to broberson@example.org has been received.

## p0355
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:31:20.997Z
```
{"timestamp":1732246280997080800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"673ffb08b0df5c00019b26b8"}
```
Same service, the 2 minutes before (oldest first):
  03:31:20.415 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffaffb0df5c00019b268f\",\"_links\":{\"
  03:31:20.415 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:31:20.415 [front-end] [ undefined, undefined ]
  03:31:20.415 [front-end] Posting Order: {"customer":"http://user/customers/673ffaf5b0df5c00019b2678","address":"http://user/addresses/673ffaffb0df5c00019b268e","card":"http://user/cards
  03:31:20.447 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffb08d94b9000069b45aa","customerId":"673ffaf5b0df5c00019b2678","customer":{"id":null,"firstName":"jMMNqtplqm"
  03:31:20.447 [front-end] Order response: {"id":"673ffb08d94b9000069b45aa","customerId":"673ffaf5b0df5c00019b2678","customer":{"id":null,"firstName":"jMMNqtplqm","lastName":"jMMNqtplqm",
  03:31:20.448 [front-end] POST /orders 201 - ms - -
  03:31:20.724 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffb03b0df5c00019b269e"}
  03:31:20.733 [front-end] POST /addresses 200 - ms - -
  03:31:20.739 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffb03b0df5c00019b269e"}
  03:31:20.748 [front-end] POST /cards 200 - ms - -
  03:31:20.793 [front-end] Attempting to delete cart for user: 673ffb03b0df5c00019b269e
  03:31:20.813 [front-end] User cart deleted with status: 202
  03:31:20.815 [front-end] DELETE /cart 202 - ms - -
  03:31:20.820 [front-end] Attempting to add to cart: {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","quantity":1}
  03:31:20.827 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  03:31:20.827 [front-end] POST to carts: http://carts/carts/673ffb03b0df5c00019b269e/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}
  03:31:20.866 [front-end] POST /cart 201 - ms - -
  03:31:20.991 [front-end] Posting Customer: {"username":"RFgpCcDGC","password":"pNyblYtmE","email":"RFgpCcDGC@gmail.com","firstName":"RFgpCcDGC","lastName":"RFgpCcDGC"}
  03:31:20.997 [front-end] { id: '673ffb08b0df5c00019b26b8' }
All services, 30 seconds either side (sampled):
  03:30:51.006 [front-end] Request received with body: {}  (×54)
  03:30:51.048 [orders] 2024-11-22 03:30:51.048 INFO [orders,3af4cf2aa401e511,c81e37fa35877a5f,false] 6 --- [-nio-80-exec-12] w.w.s.o.controllers.OrdersController : Sending payment req  (×20)
  03:30:51.147 [queue-master] 2024-11-22 03:30:51.143 INFO 6 --- [ool-6-thread-15] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×108)
  03:30:51.212 [front-end] set cookie673ffaebb0df5c00019b265b  (×59)
  03:30:51.440 [front-end] DELETE /cart 202 - ms - -  (×59)
  03:30:52.530 [front-end] POST to carts: http://carts/carts/673ffae3b0df5c00019b263f/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×35)
  03:30:53.978 [front-end] Order response: {"id":"673ffaedd94b9000069b4595","customerId":"673ffad6b0df5c00019b2621","customer":{"id":null,"firstName":"vnHIAcbxhIz","lastName":"vnHIAcbxhIz
  03:30:58.517 [front-end] Received response: "{\"firstName\":\"LdPMEGCeZbPisO\",\"lastName\":\"LdPMEGCeZbPisO\",\"username\":\"LdPMEGCeZbPisO\",\"id\":\"673ffae4b0df5c00019b2641\",\"_lin
  03:31:00.217 [front-end] Received response: "{\"firstName\":\"ikZXRzFGQYnOyE\",\"lastName\":\"ikZXRzFGQYnOyE\",\"username\":\"ikZXRzFGQYnOyE\",\"id\":\"673ffae1b0df5c00019b263c\",\"_lin
  03:31:01.393 [front-end] Order response: {"id":"673ffaf5d94b9000069b459a","customerId":"673ffadcb0df5c00019b262a","customer":{"id":null,"firstName":"VVQsoaKpFlo","lastName":"VVQsoaKpFlo
  03:31:02.736 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffaf6d94b9000069b459d","customerId":"673ffae0b0df5c00019b263b","customer":{"id":null,"firstName":"UTpZBVUbItI
  03:31:05.374 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffaf9d94b9000069b45a0","customerId":"673ffae1b0df5c00019b263d","customer":{"id":null,"firstName":"YkGhtbNhSw"
  03:31:07.215 [user] ts=2024-11-22T03:31:07.215590144Z caller=middlewares.go:46 method=Register username=gPROFlG email=gPROFlG@gmail.com took=1.087114ms
  03:31:11.429 [front-end] Posting Customer: {"username":"WtgyPsWScmmG","password":"qwAOJo","email":"WtgyPsWScmmG@gmail.com","firstName":"WtgyPsWScmmG","lastName":"WtgyPsWScmmG"}
  03:31:13.392 [front-end] Posting Customer: {"username":"EKOiVWQx","password":"KtayVoU","email":"EKOiVWQx@gmail.com","firstName":"EKOiVWQx","lastName":"EKOiVWQx"}
  03:31:15.317 [front-end] Posting Customer: {"username":"yWeHxoecCrW","password":"IXqHWThgZ","email":"yWeHxoecCrW@gmail.com","firstName":"yWeHxoecCrW","lastName":"yWeHxoecCrW"}
  03:31:15.864 [user] ts=2024-11-22T03:31:15.864621633Z caller=middlewares.go:46 method=Register username=FvCWU email=FvCWU@gmail.com took=1.111958ms
  03:31:19.831 [front-end] Posting Customer: {"username":"lZPJTiCB","password":"lQclvY","email":"lZPJTiCB@gmail.com","firstName":"lZPJTiCB","lastName":"lZPJTiCB"}
  03:31:22.034 [front-end] Order response: {"id":"673ffb0ad94b9000069b45ab","customerId":"673ffaf1b0df5c00019b266e","customer":{"id":null,"firstName":"IlkSNTSkO","lastName":"IlkSNTSkO","u
  03:31:25.804 [user] ts=2024-11-22T03:31:25.804270785Z caller=middlewares.go:46 method=Register username=wzyJC email=wzyJC@gmail.com took=1.039333ms
  03:31:29.635 [front-end] Order response: {"id":"673ffb11d94b9000069b45b0","customerId":"673ffb01b0df5c00019b2697","customer":{"id":null,"firstName":"EKOiVWQx","lastName":"EKOiVWQx","use
  03:31:31.545 [front-end] Posting Customer: {"username":"lOBxrXHLsr","password":"kkvenmmy","email":"lOBxrXHLsr@gmail.com","firstName":"lOBxrXHLsr","lastName":"lOBxrXHLsr"}
  03:31:32.709 [front-end] Order response: {"id":"673ffb14d94b9000069b45b6","customerId":"673ffaffb0df5c00019b2690","customer":{"id":null,"firstName":"WtgyPsWScmmG","lastName":"WtgyPsWScm
  03:31:34.909 [queue-master] 2024-11-22 03:31:34.908 INFO 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×9)
  03:31:36.839 [front-end] Received response: "{\"firstName\":\"OGrEEsVIp\",\"lastName\":\"OGrEEsVIp\",\"username\":\"OGrEEsVIp\",\"id\":\"673ffb05b0df5c00019b26a8\",\"_links\":{\"address
  03:31:38.455 [user] ts=2024-11-22T03:31:38.455230892Z caller=middlewares.go:46 method=Register username=vNydxJ email=vNydxJ@gmail.com took=1.070173ms
  03:31:42.072 [front-end] Posting Customer: {"username":"RCsNHvlwh","password":"GFubNEycs","email":"RCsNHvlwh@gmail.com","firstName":"RCsNHvlwh","lastName":"RCsNHvlwh"}
  03:31:43.647 [user] ts=2024-11-22T03:31:43.64738047Z caller=middlewares.go:46 method=Register username=qlqSFqMXh email=qlqSFqMXh@gmail.com took=1.035242ms
  03:31:48.775 [front-end] Posting Customer: {"username":"aauDDkJrjXWDR","password":"sQFdzUXPIT","email":"aauDDkJrjXWDR@gmail.com","firstName":"aauDDkJrjXWDR","lastName":"aauDDkJrjXWDR"}

## p0259
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T02:28:15.136Z
```
{"timestamp":1732242495136857300,"container_name":"carts","pod_name":"carts-78d749cf8c-m7cvk","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-22 02:28:15.041  INFO [carts,,,] 7 --- [           main] works.weave.socks.cart.CartApplication   : Started CartApplication in 160.989 seconds (JVM running for 167.061)"}
```
Same service, the 2 minutes before (oldest first):
  02:28:07.539 [carts] 2024-11-22 02:28:07.538 INFO [carts,,,] 7 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  02:28:10.239 [carts] 2024-11-22 02:28:10.239 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  02:28:10.437 [carts] 2024-11-22 02:28:10.437 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetected
  02:28:10.443 [carts] 2024-11-22 02:28:10.443 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposur  (×2)
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:10.451 [carts] 2024-11-22 02:28:10.451 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  02:28:10.536 [carts] 2024-11-22 02:28:10.536 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX server
  02:28:10.737 [carts] 2024-11-22 02:28:10.737 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server as  (×2)
  02:28:10.943 [carts] 2024-11-22 02:28:10.943 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as MB
  02:28:11.236 [carts] 2024-11-22 02:28:11.236 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering wi
  02:28:13.639 [carts] 2024-11-22 02:28:13.639 INFO [carts,,,] 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×41)
  02:28:03.174 [front-end] User cart deleted with status: 503  (×41)
  02:28:03.202 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×40)
  02:28:03.249 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×17)
  02:28:03.410 [front-end] Carts merged.  (×38)
  02:28:04.973 [front-end] Posting Customer: {"username":"HFHBXn","password":"EOgUhihln","email":"HFHBXn@gmail.com","firstName":"HFHBXn","lastName":"HFHBXn"}
  02:28:05.351 [user] ts=2024-11-22T02:28:05.351787827Z caller=middlewares.go:46 method=Register username=vuOxCKL email=vuOxCKL@gmail.com took=4.581531ms
  02:28:08.095 [front-end] Received response: "{\"firstName\":\"RsyjMQXEZqDOIBa\",\"lastName\":\"RsyjMQXEZqDOIBa\",\"username\":\"RsyjMQXEZqDOIBa\",\"id\":\"673fec1eb0df5c00019af912\",\"_
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:15.696 [front-end] Posting Customer: {"username":"NGQZYvsdKz","password":"rioCzg","email":"NGQZYvsdKz@gmail.com","firstName":"NGQZYvsdKz","lastName":"NGQZYvsdKz"}
  02:28:17.875 [front-end] Posting Customer: {"username":"QGHrdp","password":"lxLAJGrqCj","email":"QGHrdp@gmail.com","firstName":"QGHrdp","lastName":"QGHrdp"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.516 [front-end] Posting Customer: {"username":"FUekuDogRI","password":"vzTsDBt","email":"FUekuDogRI@gmail.com","firstName":"FUekuDogRI","lastName":"FUekuDogRI"}
  02:28:23.161 [shipping] 2024-11-22 02:28:23.160 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  02:28:24.693 [front-end] Received response: "{\"firstName\":\"vuOxCKL\",\"lastName\":\"vuOxCKL\",\"username\":\"vuOxCKL\",\"id\":\"673fec35b0df5c00019af969\",\"_links\":{\"addresses\":{
  02:28:25.471 [front-end] Received response: "{\"firstName\":\"TcTuIokN\",\"lastName\":\"TcTuIokN\",\"username\":\"TcTuIokN\",\"id\":\"673fec32b0df5c00019af95c\",\"_links\":{\"addresses\
  02:28:26.351 [queue-master] Received shipment task: 673fec2db0df5c00019af953  (×23)
  02:28:26.861 [orders] 2024-11-22 02:28:26.861 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] org.mongodb.driver.connection : Opened connection [connect  (×3)
  02:28:26.962 [front-end] Order response: {"id":"673fec4ad94b9000069b39d8","customerId":"673fec2cb0df5c00019af949","customer":{"id":null,"firstName":"KoWsmDtUqsE","lastName":"KoWsmDtUqsE
  02:28:27.060 [front-end] Order response: {"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","lastName":"HFHBXn","usernam
  02:28:30.678 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ed94b9000069b39da","customerId":"673fec35b0df5c00019af968","customer":{"id":null,"firstName":"vvgsHcY","l
  02:28:32.249 [queue-master] org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket-factory-20
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×39)
  02:28:37.545 [front-end] Posting Customer: {"username":"OeZpiPZUn","password":"HBSGorzaQB","email":"OeZpiPZUn@gmail.com","firstName":"OeZpiPZUn","lastName":"OeZpiPZUn"}
  02:28:40.271 [front-end] Received response: "{\"firstName\":\"nbZCdAQyR\",\"lastName\":\"nbZCdAQyR\",\"username\":\"nbZCdAQyR\",\"id\":\"673fec38b0df5c00019af971\",\"_links\":{\"address
  02:28:42.062 [front-end] Received response: "{\"firstName\":\"XaRPipq\",\"lastName\":\"XaRPipq\",\"username\":\"XaRPipq\",\"id\":\"673fec41b0df5c00019af98d\",\"_links\":{\"addresses\":{
  02:28:43.871 [front-end] Received response: "{\"firstName\":\"DOjMvwDWIjkh\",\"lastName\":\"DOjMvwDWIjkh\",\"username\":\"DOjMvwDWIjkh\",\"id\":\"673fec48b0df5c00019af998\",\"_links\":{

## p0483
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-23T08:57:00.772Z, and 1 identical event(s) in the same minute
```
{"timestamp":1732352220772350200,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-zmfhr","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:57:00.772  INFO 7 --- [pool-6-thread-5] o.apache.http.impl.execchain.RetryExec   : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught when processing request to {}->unix://localhost:80: No such file or directory"}
```
Same service, the 2 minutes before (oldest first):
  08:56:58.025 [queue-master] Received shipment task: 674198bfa437380001deff45  (×2)
  08:56:58.025 [queue-master] 2024-11-23 08:56:58.025 INFO 7 --- [pool-6-thread-1] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×2)
  08:56:58.026 [queue-master] 2024-11-23 08:56:58.026 INFO 7 --- [pool-6-thread-1] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×3)
  08:56:58.026 [queue-master] 2024-11-23 08:56:58.026 INFO 7 --- [pool-6-thread-1] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×3)
  08:56:58.026 [queue-master] 2024-11-23 08:56:58.026 ERROR 7 --- [pool-6-thread-1] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.
All services, 30 seconds either side (sampled):
  08:56:58.007 [catalogue] ts=2024-11-23T08:56:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.869902ms  (×36)
  08:56:58.018 [orders] 2024-11-23 08:56:58.018 INFO [orders,6baef7816fdf67ff,4dc9cbe9bd6cff45,false] 8 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Received payment re  (×25)
  08:56:58.029 [front-end] Order response: {"statusCode":201,"body":{"id":"674198da3f77060008865384","customerId":"674198bfa437380001deff45","customer":{"id":null,"firstName":"ztfESzW","l
  08:56:59.388 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674198d3a437380001deff98"}  (×29)
  08:56:59.483 [catalogue] ts=2024-11-23T08:56:59Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.990138  (×27)
  08:57:00.720 [front-end] Request received with body: {}  (×26)
  08:57:00.744 [front-end] Posting Order: {"customer":"http://user/customers/674198caa437380001deff7c","address":"http://user/addresses/674198d0a437380001deff90","card":"http://user/cards  (×26)
  08:57:01.048 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  08:57:01.165 [front-end] 674198dda437380001deffa9  (×33)
  08:57:02.787 [front-end] Received response: "{\"firstName\":\"iEYCUjoH\",\"lastName\":\"iEYCUjoH\",\"username\":\"iEYCUjoH\",\"id\":\"674198c5a437380001deff67\",\"_links\":{\"addresses\
  08:57:03.057 [front-end] Order response: {"statusCode":201,"body":{"id":"674198df3f77060008865387","customerId":"674198caa437380001deff7e","customer":{"id":null,"firstName":"qzkCXXFW","
  08:57:04.140 [front-end] Received response: "{\"firstName\":\"TlHaLWqJVqW\",\"lastName\":\"TlHaLWqJVqW\",\"username\":\"TlHaLWqJVqW\",\"id\":\"674198d0a437380001deff92\",\"_links\":{\"a
  08:57:05.392 [orders] 2024-11-23 08:57:05.392 INFO [orders,3c526066b205402a,acb1c0fc61191c83,false] 8 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×2)
  08:57:07.035 [front-end] Order response: {"statusCode":201,"body":{"id":"674198e33f7706000886538a","customerId":"674198caa437380001deff7d","customer":{"id":null,"firstName":"vidoaLMiMZn
  08:57:08.980 [queue-master] 2024-11-23 08:57:08.980 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×48)
  08:57:09.152 [front-end] Order response: {"id":"674198e53f7706000886538c","customerId":"674198d2a437380001deff95","customer":{"id":null,"firstName":"zUGYrCgol","lastName":"zUGYrCgol","u
  08:57:11.533 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×6)
  08:57:13.005 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  08:57:14.121 [front-end] Posting Customer: {"username":"JCYeKSjM","password":"MYIoBCiY","email":"JCYeKSjM@gmail.com","firstName":"JCYeKSjM","lastName":"JCYeKSjM"}
  08:57:15.678 [front-end] Order response: {"id":"674198eb3f7706000886538f","customerId":"674198cfa437380001deff8c","customer":{"id":null,"firstName":"FygEtnQmntW","lastName":"FygEtnQmntW
  08:57:18.424 [user] ts=2024-11-23T08:57:18.424838811Z caller=middlewares.go:46 method=Register username=bqLFOFtK email=bqLFOFtK@gmail.com took=2.548455ms
  08:57:19.305 [front-end] Received response: "{\"firstName\":\"aXWRmKRnN\",\"lastName\":\"aXWRmKRnN\",\"username\":\"aXWRmKRnN\",\"id\":\"674198d9a437380001deffa4\",\"_links\":{\"address
  08:57:22.096 [front-end] Posting Customer: {"username":"ErqkMC","password":"qwrMe","email":"ErqkMC@gmail.com","firstName":"ErqkMC","lastName":"ErqkMC"}
  08:57:24.110 [front-end] Order response: {"id":"674198f43f77060008865392","customerId":"674198dfa437380001deffad","customer":{"id":null,"firstName":"wqgJPHku","lastName":"wqgJPHku","use
  08:57:25.404 [front-end] Order response: {"id":"674198f53f77060008865393","customerId":"674198e2a437380001deffb0","customer":{"id":null,"firstName":"tVFCKe","lastName":"tVFCKe","usernam
  08:57:26.581 [front-end] Received response: "{\"firstName\":\"aQTVfKPpOQTV\",\"lastName\":\"aQTVfKPpOQTV\",\"username\":\"aQTVfKPpOQTV\",\"id\":\"674198e5a437380001deffb4\",\"_links\":{
  08:57:27.415 [front-end] Order response: {"statusCode":201,"body":{"id":"674198f73f77060008865398","customerId":"674198dda437380001deffa9","customer":{"id":null,"firstName":"eWMmgZPhWLI
  08:57:30.058 [front-end] Order response: {"id":"674198fa3f77060008865399","customerId":"674198e7a437380001deffbe","customer":{"id":null,"firstName":"bVfUCqC","lastName":"bVfUCqC","usern

## p0063
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T08:53:40.313Z
```
{"service":"logservice1","message":"2021-08-13 08:53:40,313 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | 426b4b28302585c2 | the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389"}
```
Same service, the 2 minutes before (oldest first):
  08:53:37.110 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×3)
  08:53:37.111 [logservice1] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': 'e42588f4-fbd0-11eb-a61b-0242ac110003', 'user_id': 'tVZirvSy'}  (×5)
  08:53:37.799 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  08:53:37.799 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  08:53:37.800 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'e4b6a50a-fbd0-11eb-a3ba-0242ac110003'}  (×2)
  08:53:37.862 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×2)
  08:53:37.862 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×2)
  08:53:38.735 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×2)
All services, 30 seconds either side (sampled):
  08:53:10.393 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'd46b9228-fbd0-11eb-a979-0242ac110003', 'value': 'FvDqslOC'}  (×50)
  08:53:10.560 [redisservice2] INFO redis读取信息成功, status_code: 200  (×49)
  08:53:10.648 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  08:53:10.759 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×47)
  08:53:11.013 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×49)
  08:53:11.420 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'd51213aa-fbd0-11eb-8af9-0242ac110003'}  (×41)
  08:53:11.653 [webservice2] INFO complete information: {'uuid': 'd544f69e-fbd0-11eb-aff4-0242ac110004', 'user_id': 'DBUWXtFp'}  (×43)
  08:53:11.911 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×44)
  08:53:12.572 [mobservice2] INFO info d5afa246-fbd0-11eb-95ad-0242ac110003:vYsiTgru write success
  08:53:14.258 [mobservice1] INFO info d6b1cd2c-fbd0-11eb-b95c-0242ac110003:Qygqzmel write success
  08:53:16.376 [dbservice1] INFO d7c0cfb0-fbd0-11eb-9e58-0242ac110003-WyKqhlJd-S5&.)N$_Qvw> token generate success token=MTYyODgxNTk5Ni4zNzYxMDcyOmQ3YzBjZmIwLWZiZDAtMTFlYi05ZTU4LTAyNDJhYzE
  08:53:18.829 [mobservice1] INFO info d97eb434-fbd0-11eb-ad20-0242ac110004:dQvowFzG write success
  08:53:21.555 [dbservice1] INFO dad0cfa2-fbd0-11eb-9d74-0242ac110003-EVBLhgrm-9os/__E:hq47 token generate success token=MTYyODgxNjAwMS41NTUzMzg0OmRhZDBjZmEyLWZiZDAtMTFlYi05ZDc0LTAyNDJhYzE
  08:53:23.769 [dbservice1] INFO dc2d4042-fbd0-11eb-af17-0242ac110004-xXiaofbu-2Yl&jd#+ApZV token generate success token=MTYyODgxNjAwMy43NjkyNDg3OmRjMmQ0MDQyLWZiZDAtMTFlYi1hZjE3LTAyNDJhYzE
  08:53:26.785 [dbservice1] INFO dded3afe-fbd0-11eb-944e-0242ac110004-bCKBvESO-X!*=wdxSZ#fO token generate success token=MTYyODgxNjAwNi43ODUwOTE5OmRkZWQzYWZlLWZiZDAtMTFlYi05NDRlLTAyNDJhYzE
  08:53:29.441 [dbservice1] INFO df7925b8-fbd0-11eb-a1f3-0242ac110003-HMKVRZeu-Kw&{bqcPf=xI token generate success token=MTYyODgxNjAwOS40NDE1OTQ0OmRmNzkyNWI4LWZiZDAtMTFlYi1hMWYzLTAyNDJhYzE
  08:53:32.560 [dbservice1] INFO e15b4820-fbd0-11eb-85ca-0242ac110003-lAeMCLWx-cz5%VZBN6h-A token generate success token=MTYyODgxNjAxMi41NTk4Mzg6ZTE1YjQ4MjAtZmJkMC0xMWViLTg1Y2EtMDI0MmFjMTE
  08:53:34.627 [mobservice1] INFO info e2e11fe4-fbd0-11eb-b5ae-0242ac110003:aZMCtwXA write success
  08:53:37.256 [dbservice1] INFO e42561c6-fbd0-11eb-b9c2-0242ac110003-pfVurBxD-Ztdq=blh$j*M token generate success token=MTYyODgxNjAxNy4yNTYwNjk6ZTQyNTYxYzYtZmJkMC0xMWViLWI5YzItMDI0MmFjMTE
  08:53:39.706 [mobservice1] INFO info e5dfec34-fbd0-11eb-8fdf-0242ac110003:SBgdrmlT write success
  08:53:42.288 [mobservice1] INFO info e771a830-fbd0-11eb-b29d-0242ac110004:bNtPLwUk write success
  08:53:44.950 [dbservice1] INFO e8b63dbe-fbd0-11eb-9404-0242ac110003-JXejhiMl-97R5_3u8cLX? token generate success token=MTYyODgxNjAyNC45NTAwMTk4OmU4YjYzZGJlLWZiZDAtMTFlYi05NDA0LTAyNDJhYzE
  08:53:48.447 [mobservice1] INFO info eb00f99c-fbd0-11eb-8a0e-0242ac110003:kyxZCaug write success
  08:53:52.188 [mobservice2] INFO info ed4cf6a6-fbd0-11eb-a002-0242ac110004:PwhZOREl write success
  08:53:56.763 [mobservice2] INFO info effab92e-fbd0-11eb-8608-0242ac110003:TKNpsvwU write success
  08:53:59.714 [mobservice2] INFO info f1be4276-fbd0-11eb-bbc8-0242ac110003:jHRvwBZi write success
  08:54:02.477 [dbservice1] INFO f3351fa8-fbd0-11eb-90bf-0242ac110004-pVIaJPSL-/6iJQ_4ro#jO token generate success token=MTYyODgxNjA0Mi40NzY4OTk6ZjMzNTFmYTgtZmJkMC0xMWViLTkwYmYtMDI0MmFjMTE

## p0672
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice2, 2021-08-11T13:49:02.627Z
```
{"service":"logservice2","message":"2021-08-11 13:49:02,627 | INFO | 0.0.0.2 | 172.17.0.3 | logservice2 | 40012e53b47a5897 | request http://0.0.0.2:9389/db_login_methods and param={'uuid': 'd4a817da-fa67-11eb-93ed-0242ac110004', 'user_id': 'UHcqgbTI'}"}
```
Same service, the 2 minutes before (oldest first):
  13:48:54.688 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×5)
  13:48:54.689 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×5)
  13:48:54.689 [logservice2] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': 'cfee8f6c-fa67-11eb-bee9-0242ac110003', 'user_id': 'PBSphkoz'}  (×5)
  13:48:59.755 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387
  13:48:59.755 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service
  13:48:59.756 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'd30750f8-fa67-11eb-b4d3-0242ac110004'}
  13:48:59.815 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384
  13:48:59.815 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service
All services, 30 seconds either side (sampled):
  13:48:32.691 [redisservice2] INFO redis读取信息成功, status_code: 200  (×38)
  13:48:32.753 [logservice2] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': 'c2cf532a-fa67-11eb-afc8-0242ac110003', 'user_id': 'mFYdOIbz'}  (×57)
  13:48:32.991 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×27)
  13:48:33.165 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×27)
  13:48:33.297 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'c3492998-fa67-11eb-ba37-0242ac110004', 'value': 'CfHjswnr'}  (×31)
  13:48:33.783 [dbservice2] INFO c3492998-fa67-11eb-ba37-0242ac110004-CfHjswnr-5atn1@V=8r4l token generate success token=MTYyODY2MDkxMy43ODMzNzM4OmMzNDkyOTk4LWZhNjctMTFlYi1iYTM3LTAyNDJhYzE
  13:48:34.202 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×29)
  13:48:34.409 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×24)
  13:48:34.672 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×32)
  13:48:34.981 [mobservice1] INFO info c449b6f0-fa67-11eb-a437-0242ac110003:TzNJoquC write success
  13:48:35.870 [redisservice1] INFO redis读取信息成功, status_code: 200  (×20)
  13:48:39.901 [dbservice1] INFO c6ffe6a8-fa67-11eb-ae94-0242ac110003-eyfiDUCK-zY5%aIh>H9gZ token generate success token=MTYyODY2MDkxOS45MDEwODIzOmM2ZmZlNmE4LWZhNjctMTFlYi1hZTk0LTAyNDJhYzE
  13:48:47.503 [redisservice2] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400
  13:48:48.057 [mobservice1] INFO info cc10a268-fa67-11eb-b640-0242ac110003:EvQlkbnz write success
  13:48:49.723 [mobservice1] INFO info cd0e805e-fa67-11eb-80c6-0242ac110003:qfGXigUn write success
  13:48:51.734 [dbservice1] INFO ce029090-fa67-11eb-88fc-0242ac110003-GohTtSPu-q6u?Dt(_kM$Z token generate success token=MTYyODY2MDkzMS43MzQwMjg2OmNlMDI5MDkwLWZhNjctMTFlYi04OGZjLTAyNDJhYzE
  13:48:54.407 [dbservice2] INFO cfa1faa8-fa67-11eb-89eb-0242ac110004-ulnvrqij-9:#.kKu^Q_1% token generate success token=MTYyODY2MDkzNC40MDc0Nzg2OmNmYTFmYWE4LWZhNjctMTFlYi04OWViLTAyNDJhYzE
  13:48:56.428 [dbservice2] INFO d0d2ada0-fa67-11eb-b2ef-0242ac110004-sOldejxN-St1e7jhY<rcP token generate success token=MTYyODY2MDkzNi40Mjc2MjQ3OmQwZDJhZGEwLWZhNjctMTFlYi1iMmVmLTAyNDJhYzE
  13:49:03.929 [mobservice2] INFO info d5854df8-fa67-11eb-813b-0242ac110003:mgvTPLKy write success
  13:49:08.360 [dbservice1] INFO d7f02d42-fa67-11eb-b7f5-0242ac110003-PBSphkoz-}5fM7Xq4&c/Z token generate success token=MTYyODY2MDk0OC4zNTk2NjM6ZDdmMDJkNDItZmE2Ny0xMWViLWI3ZjUtMDI0MmFjMTE
  13:49:16.779 [mobservice2] ERROR uuid:d6a04ef4-fa67-11eb-ac07-0242ac110004 information has expired, mobile phone login is invalid
  13:49:18.131 [mobservice1] INFO info ddfc0436-fa67-11eb-99a2-0242ac110003:ucARQwLG write success
  13:49:20.092 [dbservice2] INFO dee9be7e-fa67-11eb-88e2-0242ac110003-GOhWXRIV-:-)PYXo0ydqc token generate success token=MTYyODY2MDk2MC4wOTE4MzM0OmRlZTliZTdlLWZhNjctMTFlYi04OGUyLTAyNDJhYzE
  13:49:22.299 [mobservice2] INFO info e05ee9dc-fa67-11eb-9d58-0242ac110004:XUtTqLre write success
  13:49:24.475 [dbservice1] INFO e1840130-fa67-11eb-bc08-0242ac110004-DGlMEFgf-hDX.AML@KH9e token generate success token=MTYyODY2MDk2NC40NzQ5MzM6ZTE4NDAxMzAtZmE2Ny0xMWViLWJjMDgtMDI0MmFjMTE
  13:49:26.101 [dbservice1] INFO e289418a-fa67-11eb-b398-0242ac110003-oYLfmtrx-&koh*.@3{sGE token generate success token=MTYyODY2MDk2Ni4xMDEyNDk3OmUyODk0MThhLWZhNjctMTFlYi1iMzk4LTAyNDJhYzE
  13:49:28.249 [mobservice2] INFO info e409b44a-fa67-11eb-8f0b-0242ac110004:zfawCciR write success
  13:49:30.085 [dbservice1] INFO e4f10e58-fa67-11eb-97e5-0242ac110003-iBHTmjqo-dJ4{f@CPKq8n token generate success token=MTYyODY2MDk3MC4wODUzNjA1OmU0ZjEwZTU4LWZhNjctMTFlYi05N2U1LTAyNDJhYzE
  13:49:32.350 [mobservice1] INFO info e6766bc4-fa67-11eb-bc25-0242ac110003:kyqcgeNB write success

## p0425
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T04:09:06.092Z
```
{"timestamp":1732248546092974300,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T04:09:06.092819494Z caller=middlewares.go:157 method=Health result=2 took=695.047µs"}
```
Same service, the 2 minutes before (oldest first):
  04:09:03.081 [user] ts=2024-11-22T04:09:03.081038366Z caller=middlewares.go:134 method=GetCards id=674003d6b0df5c00019b41a6 result=1 took=979.489µs  (×3)
  04:09:03.093 [user] ts=2024-11-22T04:09:03.093307831Z caller=middlewares.go:157 method=Health result=2 took=720.138µs  (×2)
  04:09:03.120 [user] ts=2024-11-22T04:09:03.120730161Z caller=middlewares.go:46 method=Register username=VLKZctKHAujiUsv email=VLKZctKHAujiUsv@gmail.com took=1.00105ms
  04:09:04.203 [user] ts=2024-11-22T04:09:04.203631361Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=674003d9b0df5c00019b41b1 took=1.726105ms
  04:09:04.217 [user] ts=2024-11-22T04:09:04.217592664Z caller=middlewares.go:118 method=PostCard card=*****3321 user=674003d9b0df5c00019b41b1 took=1.61276ms
  04:09:04.780 [user] ts=2024-11-22T04:09:04.780356733Z caller=middlewares.go:46 method=Register username=tgMBRgWekTcI email=tgMBRgWekTcI@gmail.com took=983.617µs
  04:09:05.623 [user] ts=2024-11-22T04:09:05.622871344Z caller=middlewares.go:75 method=GetUsers id=674003c6b0df5c00019b4183 result=1 took=914.05µs  (×4)
  04:09:05.631 [user] ts=2024-11-22T04:09:05.631652529Z caller=middlewares.go:75 method=GetUsers id=674003c6b0df5c00019b4183 result=1 took=1.122437ms  (×4)
  04:09:05.642 [user] ts=2024-11-22T04:09:05.64182543Z caller=middlewares.go:104 method=GetAddresses id=674003d0b0df5c00019b4192 result=1 took=796.034µs  (×2)
  04:09:05.698 [user] ts=2024-11-22T04:09:05.69845821Z caller=middlewares.go:46 method=Register username=nBpoZO email=nBpoZO@gmail.com took=1.021177ms
All services, 30 seconds either side (sampled):
  04:08:36.093 [user] ts=2024-11-22T04:08:36.093059831Z caller=middlewares.go:157 method=Health result=2 took=810.798µs  (×36)
  04:08:36.270 [catalogue] ts=2024-11-22T04:08:36Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=3.802935  (×51)
  04:08:36.317 [front-end] POST /cart 500 53.882 ms - 70  (×58)
  04:08:36.995 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67400  (×56)
  04:08:37.026 [queue-master] 2024-11-22 04:08:37.026 INFO 6 --- [ool-6-thread-32] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×41)
  04:08:37.081 [front-end] Order response: {"id":"674003c5d94b9000069b4c7c","customerId":"674003b3b0df5c00019b414e","customer":{"id":null,"firstName":"bCoxKZeqTWnSRF","lastName":"bCoxKZeq
  04:08:39.441 [front-end] Received response: "{\"firstName\":\"zgqwDgZ\",\"lastName\":\"zgqwDgZ\",\"username\":\"zgqwDgZ\",\"id\":\"674003b1b0df5c00019b4148\",\"_links\":{\"addresses\":{
  04:08:43.816 [front-end] Received response: "{\"firstName\":\"wzCNcVJu\",\"lastName\":\"wzCNcVJu\",\"username\":\"wzCNcVJu\",\"id\":\"674003b6b0df5c00019b4157\",\"_links\":{\"addresses\
  04:08:45.442 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  04:08:49.266 [front-end] Posting Customer: {"username":"plYDcEtpzw","password":"CypUfGyWq","email":"plYDcEtpzw@gmail.com","firstName":"plYDcEtpzw","lastName":"plYDcEtpzw"}
  04:08:51.421 [front-end] Order response: {"statusCode":201,"body":{"id":"674003d3d94b9000069b4c83","customerId":"674003bcb0df5c00019b416d","customer":{"id":null,"firstName":"iSXAQlNMGPw
  04:08:52.214 [front-end] Posting Customer: {"username":"nhJvqyYZdycfgC","password":"dleMj","email":"nhJvqyYZdycfgC@gmail.com","firstName":"nhJvqyYZdycfgC","lastName":"nhJvqyYZdycfgC"}
  04:08:54.757 [front-end] Order response: {"id":"674003d6d94b9000069b4c87","customerId":"674003c1b0df5c00019b4178","customer":{"id":null,"firstName":"avrSoephIiAOh","lastName":"avrSoephI
  04:08:57.163 [user] ts=2024-11-22T04:08:57.163241222Z caller=middlewares.go:46 method=Register username=POSQalWGW email=POSQalWGW@gmail.com took=927.67µs
  04:09:00.037 [front-end] Posting Customer: {"username":"xUktarEa","password":"VCfmjShw","email":"xUktarEa@gmail.com","firstName":"xUktarEa","lastName":"xUktarEa"}
  04:09:01.660 [front-end] Order response: {"id":"674003ddd94b9000069b4c8a","customerId":"674003cdb0df5c00019b418e","customer":{"id":null,"firstName":"MpGJEymhshea","lastName":"MpGJEymhsh
  04:09:05.698 [user] ts=2024-11-22T04:09:05.69845821Z caller=middlewares.go:46 method=Register username=nBpoZO email=nBpoZO@gmail.com took=1.021177ms
  04:09:06.817 [queue-master] 2024-11-22 04:09:06.817 INFO 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×9)
  04:09:08.488 [front-end] Posting Customer: {"username":"oAqxITKuE","password":"vcPLrAE","email":"oAqxITKuE@gmail.com","firstName":"oAqxITKuE","lastName":"oAqxITKuE"}
  04:09:12.106 [front-end] Received response: "{\"firstName\":\"rJmYQdzPxAmHgIU\",\"lastName\":\"rJmYQdzPxAmHgIU\",\"username\":\"rJmYQdzPxAmHgIU\",\"id\":\"674003d5b0df5c00019b41a0\",\"_
  04:09:14.603 [front-end] Order response: {"statusCode":201,"body":{"id":"674003ead94b9000069b4c94","customerId":"674003d1b0df5c00019b4194","customer":{"id":null,"firstName":"plYDcEtpzw"
  04:09:16.481 [front-end] Received response: "{\"firstName\":\"nhJvqyYZdycfgC\",\"lastName\":\"nhJvqyYZdycfgC\",\"username\":\"nhJvqyYZdycfgC\",\"id\":\"674003d4b0df5c00019b419d\",\"_lin
  04:09:20.117 [front-end] Order response: {"statusCode":201,"body":{"id":"674003f0d94b9000069b4c9a","customerId":"674003d9b0df5c00019b41b5","customer":{"id":null,"firstName":"sSiWUME","l
  04:09:21.793 [front-end] Order response: {"statusCode":201,"body":{"id":"674003f1d94b9000069b4c9c","customerId":"674003d4b0df5c00019b419e","customer":{"id":null,"firstName":"WvrbrQ","la
  04:09:22.594 [front-end] Order response: {"statusCode":201,"body":{"id":"674003f2d94b9000069b4c9f","customerId":"674003d5b0df5c00019b419f","customer":{"id":null,"firstName":"YZWnZm","la
  04:09:25.320 [front-end] Posting Customer: {"username":"FJXsIdiSnhw","password":"sFlnnQyYDl","email":"FJXsIdiSnhw@gmail.com","firstName":"FJXsIdiSnhw","lastName":"FJXsIdiSnhw"}
  04:09:26.920 [front-end] Order response: {"id":"674003f6d94b9000069b4ca5","customerId":"674003deb0df5c00019b41c8","customer":{"id":null,"firstName":"rTanKnjenuTsL","lastName":"rTanKnjen
  04:09:27.952 [front-end] Posting Customer: {"username":"CoCjTpxhjgbJo","password":"ofrgUx","email":"CoCjTpxhjgbJo@gmail.com","firstName":"CoCjTpxhjgbJo","lastName":"CoCjTpxhjgbJo"}
  04:09:31.697 [front-end] Posting Customer: {"username":"JfRnlBZAVqKF","password":"uZVZyzu","email":"JfRnlBZAVqKF@gmail.com","firstName":"JfRnlBZAVqKF","lastName":"JfRnlBZAVqKF"}
  04:09:33.828 [front-end] Order response: {"id":"674003fdd94b9000069b4cac","customerId":"674003e2b0df5c00019b41d4","customer":{"id":null,"firstName":"xyHdlxNYQ","lastName":"xyHdlxNYQ","u

## p0839
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-08T12:51:05.504Z
```
{"timestamp":1733662265504037400,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-xdbjj","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-08 12:51:05.503  INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl       : [Travel Service][Get Route By Id] Route ID：9fc9c261-3263-4bfa-82f8-bb44e06b2f52"}
```
Same service, the 2 minutes before (oldest first):
  12:51:00.869 [ts-travel2-service] 2024-12-08 12:51:00.868 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  12:51:00.895 [ts-travel2-service] 2024-12-08 12:51:00.895 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sun Dec 08 00:00:00 GMT 2024, 
  12:51:00.901 [ts-travel2-service] 2024-12-08 12:51:00.901 INFO 1 --- [io-16346-exec-8] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234
  12:51:00.903 [ts-travel2-service] 2024-12-08 12:51:00.903 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×6)
  12:51:00.914 [ts-travel2-service] 2024-12-08 12:51:00.913 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×6)
  12:51:00.914 [ts-travel2-service] 2024-12-08 12:51:00.914 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  12:51:00.951 [ts-travel2-service] 2024-12-08 12:51:00.951 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0
  12:51:00.959 [ts-travel2-service] 2024-12-08 12:51:00.959 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×2)
All services, 30 seconds either side (sampled):
  12:50:36.534 [ts-auth-service] 2024-12-08 12:50:36.533 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×12)
  12:50:36.738 [ts-route-service] 2024-12-08 12:50:36.737 INFO 1 --- [io-11178-exec-3] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×247)
  12:50:36.784 [ts-price-service] 2024-12-08 12:50:36.784 INFO 1 --- [io-16579-exec-1] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×27)
  12:50:36.866 [ts-travel2-service] 2024-12-08 12:50:36.865 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sun Dec 08 00:00:00 GMT 2024,   (×28)
  12:50:36.914 [ts-seat-service] 2024-12-08 12:50:36.914 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×54)
  12:50:37.674 [ts-food-service] 2024-12-08 12:50:37.674 INFO 1 --- [io-18856-exec-7] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×3)
  12:50:37.722 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:50:37 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 11857 "-" "Mozilla/5.0 (Macintosh  (×3)
  12:50:38.351 [ts-inside-payment-service] 2024-12-08 12:50:38.350 INFO 1 --- [o-18673-exec-10] i.controller.InsidePaymentController : [Inside Payment Service][Pay] Pay for: d8298f7b-07b3-4cb3-a373-7bd6e
  12:50:38.402 [ts-basic-service] 2024-12-08 12:50:38.402 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×16)
  12:50:38.459 [ts-order-service] 2024-12-08 12:50:38.459 INFO 1 --- [io-12031-exec-7] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024  (×25)
  12:50:38.673 [ts-order-service] 2024-12-08 12:50:38.673 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×10)
  12:50:39.092 [ts-seat-service] 2024-12-08 12:50:39.092 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×4)
  12:50:39.176 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:50:39 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 924 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×5)
  12:50:43.412 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:50:43 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×8)
  12:50:49.070 [ts-assurance-service] 2024-12-08 12:50:49.069 INFO 1 --- [io-18888-exec-8] a.controller.AssuranceController : [Assurances Service][Get Assurance Type]
  12:50:49.101 [ts-preserve-other-service] 2024-12-08 12:50:49.101 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Check Account Security] Checking....
  12:50:49.150 [ts-security-service] 2024-12-08 12:50:49.150 INFO 1 --- [io-11188-exec-8] security.service.SecurityServiceImpl : [Security Service][Get Security Config Info]
  12:50:49.174 [ts-preserve-other-service] 2024-12-08 12:50:49.174 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Step 2] Complete
  12:50:49.544 [ts-preserve-other-service] 2024-12-08 12:50:49.544 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Tickets Enough
  12:50:49.713 [ts-seat-service] 2024-12-08 12:50:49.712 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService distributeSeat] Use a new seat number! 925280291
  12:50:49.735 [ts-preserve-other-service] 2024-12-08 12:50:49.735 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 5] Do not need to buy assurance
  12:50:57.591 [ts-auth-service] 2024-12-08 12:50:57.590 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×2)
  12:51:09.352 [ts-route-service] Error opening zip file or JAR manifest missing : /tmp/opentelemetry-javaagent.jar
  12:51:12.210 [ts-user-mongo] {"t":{"$date":"2024-12-08T12:51:12.210+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366227
  12:51:13.941 [ts-security-mongo] {"t":{"$date":"2024-12-08T12:51:13.941+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366227
  12:51:17.194 [ts-travel2-service] 2024-12-08 12:51:17.194 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×2)
  12:51:17.905 [ts-basic-service] 2024-12-08 12:51:17.905 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×6)
  12:51:17.947 [ts-basic-service] 2024-12-08 12:51:17.946 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : route.getDistances().size : 2  (×3)
  12:51:22.761 [ts-basic-service] 2024-12-08 12:51:22.760 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO
  12:51:30.131 [ts-basic-service] 2024-12-08 12:51:30.131 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou

## p0499
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:11:47.742Z
```
{"timestamp":1732353107742195700,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:11:47.742137798Z caller=middlewares.go:75 method=GetUsers id=67419c42a437380001df0a3d result=1 took=1.698324ms"}
```
Same service, the 2 minutes before (oldest first):
  09:11:45.597 [user] ts=2024-11-23T09:11:45.596895666Z caller=middlewares.go:75 method=GetUsers id=67419c3da437380001df0a21 result=1 took=2.489797ms  (×14)
  09:11:46.038 [user] ts=2024-11-23T09:11:46.038333291Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419c48a437380001df0a4c took=4.908487ms
  09:11:46.052 [user] ts=2024-11-23T09:11:46.052480215Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419c48a437380001df0a4c took=3.774459ms
  09:11:46.149 [user] ts=2024-11-23T09:11:46.149061639Z caller=middlewares.go:46 method=Register username=iCzyVxna email=iCzyVxna@gmail.com took=2.268529ms
  09:11:46.220 [user] ts=2024-11-23T09:11:46.220696536Z caller=middlewares.go:46 method=Register username=bcQxHV email=bcQxHV@gmail.com took=2.628897ms
  09:11:46.848 [user] ts=2024-11-23T09:11:46.848859538Z caller=middlewares.go:157 method=Health result=2 took=1.900436ms  (×2)
All services, 30 seconds either side (sampled):
  09:11:17.746 [user] ts=2024-11-23T09:11:17.745607238Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419c2ba437380001df09ec took=4.251589ms  (×65)
  09:11:17.868 [front-end] { id: '67419c35a437380001df0a08' }  (×70)
  09:11:17.891 [front-end] Carts merged.  (×70)
  09:11:17.897 [front-end] GET Request to: http://user/customers/67419c20a437380001df09cf/addresses  (×118)
  09:11:17.919 [carts] 2024-11-23 09:11:17.919 INFO [carts,27fa27343dc20f14,b2b66f6af7296aee,false] 7 --- [-nio-80-exec-18] w.w.s.cart.controllers.ItemsController : Did not find item.  (×33)
  09:11:17.948 [front-end] Order response: {"cause":{"cause":{"cause":null,"message":"Conflicting setter definitions for property \"items\": works.weave.socks.orders.entities.CustomerOrde  (×59)
  09:11:18.455 [user] ts=2024-11-23T09:11:18.455107429Z caller=middlewares.go:46 method=Register username=XsWZAmrZNjL email=XsWZAmrZNjL@gmail.com took=2.766439ms  (×35)
  09:11:20.420 [front-end] Received response: "{\"firstName\":\"wGzjLl\",\"lastName\":\"wGzjLl\",\"username\":\"wGzjLl\",\"id\":\"67419c26a437380001df09df\",\"_links\":{\"addresses\":{\"h
  09:11:21.395 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×10)
  09:11:24.768 [orders-db] {"t":{"$date":"2024-11-23T09:11:24.767+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235308
  09:11:26.698 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×7)
  09:11:27.932 [front-end] Received response: "{\"firstName\":\"LgUTGapEXRLJpb\",\"lastName\":\"LgUTGapEXRLJpb\",\"username\":\"LgUTGapEXRLJpb\",\"id\":\"67419c2ba437380001df09ed\",\"_lin
  09:11:30.986 [front-end] Received response: "{\"firstName\":\"oRrNigKgvxGvvj\",\"lastName\":\"oRrNigKgvxGvvj\",\"username\":\"oRrNigKgvxGvvj\",\"id\":\"67419c28a437380001df09e8\",\"_lin
  09:11:32.599 [front-end] Posting Customer: {"username":"lhgmiffJeDsEQsr","password":"ZYmjc","email":"lhgmiffJeDsEQsr@gmail.com","firstName":"lhgmiffJeDsEQsr","lastName":"lhgmiffJeDsEQsr
  09:11:34.762 [front-end] Received response: "{\"firstName\":\"ChywMOlVcmclv\",\"lastName\":\"ChywMOlVcmclv\",\"username\":\"ChywMOlVcmclv\",\"id\":\"67419c35a437380001df0a04\",\"_links\
  09:11:37.763 [front-end] Received response: "{\"firstName\":\"GXtsuwtMC\",\"lastName\":\"GXtsuwtMC\",\"username\":\"GXtsuwtMC\",\"id\":\"67419c38a437380001df0a11\",\"_links\":{\"address
  09:11:41.676 [front-end] Received response: "{\"firstName\":\"XsWZAmrZNjL\",\"lastName\":\"XsWZAmrZNjL\",\"username\":\"XsWZAmrZNjL\",\"id\":\"67419c36a437380001df0a0b\",\"_links\":{\"a
  09:11:45.571 [user] ts=2024-11-23T09:11:45.570585492Z caller=middlewares.go:46 method=Register username=aZFijWZP email=aZFijWZP@gmail.com took=2.568892ms
  09:11:47.723 [front-end] Received response: "{\"firstName\":\"BsGODrB\",\"lastName\":\"BsGODrB\",\"username\":\"BsGODrB\",\"id\":\"67419c3da437380001df0a22\",\"_links\":{\"addresses\":{
  09:11:51.691 [front-end] Posting Customer: {"username":"JzFDmMcJjRyQxuB","password":"XychPX","email":"JzFDmMcJjRyQxuB@gmail.com","firstName":"JzFDmMcJjRyQxuB","lastName":"JzFDmMcJjRyQxu
  09:11:54.070 [front-end] Received response: "{\"firstName\":\"CEoQrTAJXAByo\",\"lastName\":\"CEoQrTAJXAByo\",\"username\":\"CEoQrTAJXAByo\",\"id\":\"67419c4aa437380001df0a55\",\"_links\
  09:11:58.178 [front-end] Received response: "{\"firstName\":\"UGKypaKxJraOJEY\",\"lastName\":\"UGKypaKxJraOJEY\",\"username\":\"UGKypaKxJraOJEY\",\"id\":\"67419c4ea437380001df0a61\",\"_
  09:12:00.092 [front-end] Received response: "{\"firstName\":\"zeJrRdGTkTvZZmM\",\"lastName\":\"zeJrRdGTkTvZZmM\",\"username\":\"zeJrRdGTkTvZZmM\",\"id\":\"67419c45a437380001df0a46\",\"_
  09:12:04.308 [front-end] Posting Customer: {"username":"vmUOUKKoBJDAWIS","password":"OxFEWf","email":"vmUOUKKoBJDAWIS@gmail.com","firstName":"vmUOUKKoBJDAWIS","lastName":"vmUOUKKoBJDAWI
  09:12:08.090 [user] ts=2024-11-23T09:12:08.090284034Z caller=middlewares.go:46 method=Register username=vIoOiDmX email=vIoOiDmX@gmail.com took=2.608899ms
  09:12:11.071 [front-end] Received response: "{\"firstName\":\"ulhuZAMercb\",\"lastName\":\"ulhuZAMercb\",\"username\":\"ulhuZAMercb\",\"id\":\"67419c54a437380001df0a6e\",\"_links\":{\"a
  09:12:13.153 [front-end] Received response: "{\"firstName\":\"YJCvtEt\",\"lastName\":\"YJCvtEt\",\"username\":\"YJCvtEt\",\"id\":\"67419c57a437380001df0a77\",\"_links\":{\"addresses\":{
  09:12:14.501 [user] ts=2024-11-23T09:12:14.501031913Z caller=middlewares.go:46 method=Register username=EUMzXXa email=EUMzXXa@gmail.com took=1.812721ms
  09:12:15.392 [user] ts=2024-11-23T09:12:15.392367538Z caller=middlewares.go:46 method=Register username=nUDBnIYTM email=nUDBnIYTM@gmail.com took=2.218846ms

## p0409
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:54:43.973Z
```
{"timestamp":1732247683973988600,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"67400083b0df5c00019b377e"}
```
Same service, the 2 minutes before (oldest first):
  03:54:42.986 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  03:54:42.986 [front-end] POST to carts: http://carts/carts/6740007cb0df5c00019b376b/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}
  03:54:43.028 [front-end] POST /cart 201 - ms - -
  03:54:43.735 [front-end] Request received with body: {}
  03:54:43.743 [front-end] Received response: "{\"firstName\":\"klcpCTVZJwqE\",\"lastName\":\"klcpCTVZJwqE\",\"username\":\"klcpCTVZJwqE\",\"id\":\"67400070b0df5c00019b373e\",\"_links\":{
  03:54:43.743 [front-end] GET Request to: http://user/customers/67400070b0df5c00019b373e/addresses  (×2)
  03:54:43.751 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67400
  03:54:43.752 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67400076b0df5c00019b3757\",\"_links\":{\"
  03:54:43.752 [front-end] [ undefined, undefined ]
  03:54:43.752 [front-end] Posting Order: {"customer":"http://user/customers/67400070b0df5c00019b373e","address":"http://user/addresses/67400076b0df5c00019b3756","card":"http://user/cards
  03:54:43.789 [front-end] Order response: {"statusCode":201,"body":{"id":"67400083d94b9000069b499d","customerId":"67400070b0df5c00019b373e","customer":{"id":null,"firstName":"klcpCTVZJwq
  03:54:43.789 [front-end] Order response: {"id":"67400083d94b9000069b499d","customerId":"67400070b0df5c00019b373e","customer":{"id":null,"firstName":"klcpCTVZJwqE","lastName":"klcpCTVZJw
  03:54:43.792 [front-end] POST /orders 201 - ms - -
  03:54:43.922 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6740007cb0df5c00019b376c"}
  03:54:43.930 [front-end] POST /addresses 200 - ms - -
  03:54:43.935 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"6740007cb0df5c00019b376c"}
  03:54:43.943 [front-end] POST /cards 200 - ms - -
  03:54:43.968 [front-end] Posting Customer: {"username":"JNqra","password":"OAWSlt","email":"JNqra@gmail.com","firstName":"JNqra","lastName":"JNqra"}
  03:54:43.973 [front-end] { id: '67400083b0df5c00019b377e' }
All services, 30 seconds either side (sampled):
  03:54:14.524 [catalogue] ts=2024-11-22T03:54:14Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.77284ms  (×63)
  03:54:14.773 [front-end] GET Request to: http://user/customers/67400058b0df5c00019b36f2/addresses  (×122)
  03:54:14.800 [orders] 2024-11-22 03:54:14.800 INFO [orders,9cdf744d282389b7,3926266bf4acb25d,false] 6 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Received payment re  (×36)
  03:54:14.813 [front-end] POST /orders 201 - ms - -  (×61)
  03:54:15.639 [orders] 2024-11-22 03:54:15.639 INFO [orders,b9387ff61e7d5a22,e806314738ecac4a,false] 6 --- [-nio-80-exec-15] w.w.s.o.controllers.OrdersController : Received payment re  (×25)
  03:54:16.459 [front-end] Order response: {"id":"67400068d94b9000069b4985","customerId":"67400053b0df5c00019b36e5","customer":{"id":null,"firstName":"fMyIm","lastName":"fMyIm","username"
  03:54:17.617 [front-end] set cookie67400069b0df5c00019b372b  (×60)
  03:54:19.552 [front-end] Order response: {"id":"6740006bd94b9000069b4987","customerId":"6740005cb0df5c00019b36fd","customer":{"id":null,"firstName":"hKLtLjNPAK","lastName":"hKLtLjNPAK",
  03:54:21.152 [carts] 2024-11-22 03:54:21.151 INFO [carts,832c35364bfd0762,b634aa5366612cbc,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×14)
  03:54:22.894 [front-end] Order response: {"statusCode":201,"body":{"id":"6740006ed94b9000069b498b","customerId":"6740005ab0df5c00019b36f9","customer":{"id":null,"firstName":"WVInJmvARmD
  03:54:26.941 [front-end] Order response: {"statusCode":201,"body":{"id":"67400072d94b9000069b498d","customerId":"6740005bb0df5c00019b36fb","customer":{"id":null,"firstName":"iZsWQjOSNw"
  03:54:28.684 [front-end] Order response: {"statusCode":201,"body":{"id":"67400074d94b9000069b4990","customerId":"6740005eb0df5c00019b3706","customer":{"id":null,"firstName":"YOpmGsGkBwP
  03:54:29.641 [front-end] Received response: "{\"firstName\":\"dtGBiZvkZY\",\"lastName\":\"dtGBiZvkZY\",\"username\":\"dtGBiZvkZY\",\"id\":\"67400061b0df5c00019b3711\",\"_links\":{\"addr
  03:54:31.601 [user] ts=2024-11-22T03:54:31.601187587Z caller=middlewares.go:46 method=Register username=IBlmTXb email=IBlmTXb@gmail.com took=1.026468ms
  03:54:35.847 [front-end] Order response: {"id":"6740007bd94b9000069b4996","customerId":"6740006cb0df5c00019b3735","customer":{"id":null,"firstName":"ISIcp","lastName":"ISIcp","username"
  03:54:38.692 [front-end] Posting Customer: {"username":"ffsRvdAhzVG","password":"sNMeGn","email":"ffsRvdAhzVG@gmail.com","firstName":"ffsRvdAhzVG","lastName":"ffsRvdAhzVG"}
  03:54:40.406 [front-end] Received response: "{\"firstName\":\"UjlsUG\",\"lastName\":\"UjlsUG\",\"username\":\"UjlsUG\",\"id\":\"6740006cb0df5c00019b3734\",\"_links\":{\"addresses\":{\"h
  03:54:43.789 [front-end] Order response: {"id":"67400083d94b9000069b499d","customerId":"67400070b0df5c00019b373e","customer":{"id":null,"firstName":"klcpCTVZJwqE","lastName":"klcpCTVZJw
  03:54:46.120 [front-end] Posting Customer: {"username":"bLqjlAnOuxXk","password":"njrXeKOTO","email":"bLqjlAnOuxXk@gmail.com","firstName":"bLqjlAnOuxXk","lastName":"bLqjlAnOuxXk"}
  03:54:47.628 [user] ts=2024-11-22T03:54:47.628165011Z caller=middlewares.go:46 method=Register username=zrVet email=zrVet@gmail.com took=984.543µs
  03:54:49.868 [front-end] Posting Customer: {"username":"WhZSZaDFNzds","password":"NdggIJTnQ","email":"WhZSZaDFNzds@gmail.com","firstName":"WhZSZaDFNzds","lastName":"WhZSZaDFNzds"}
  03:54:52.059 [front-end] Order response: {"id":"6740008cd94b9000069b49a7","customerId":"67400076b0df5c00019b375a","customer":{"id":null,"firstName":"lZOEogNcFjZoJ","lastName":"lZOEogNcF
  03:54:56.516 [user] ts=2024-11-22T03:54:56.516234289Z caller=middlewares.go:46 method=Register username=ERcOuZt email=ERcOuZt@gmail.com took=821.078µs
  03:54:59.591 [front-end] Posting Customer: {"username":"UCBxcjSHQ","password":"swMjcJgA","email":"UCBxcjSHQ@gmail.com","firstName":"UCBxcjSHQ","lastName":"UCBxcjSHQ"}
  03:55:01.366 [front-end] Order response: {"id":"67400095d94b9000069b49ac","customerId":"67400086b0df5c00019b3784","customer":{"id":null,"firstName":"bLqjlAnOuxXk","lastName":"bLqjlAnOux
  03:55:03.007 [front-end] Order response: {"id":"67400097d94b9000069b49b0","customerId":"6740007fb0df5c00019b3774","customer":{"id":null,"firstName":"WmkRWR","lastName":"WmkRWR","usernam
  03:55:07.528 [front-end] Received response: "{\"firstName\":\"ZdfZUMgwXICqokX\",\"lastName\":\"ZdfZUMgwXICqokX\",\"username\":\"ZdfZUMgwXICqokX\",\"id\":\"67400084b0df5c00019b3780\",\"_
  03:55:09.315 [front-end] Posting Customer: {"username":"jzgvoMcMQKNm","password":"PRcZUoRls","email":"jzgvoMcMQKNm@gmail.com","firstName":"jzgvoMcMQKNm","lastName":"jzgvoMcMQKNm"}

## p0674
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice2, 2021-08-11T14:50:05.567Z
```
{"service":"redisservice2","message":"2021-08-11 14:50:05,567 | ERROR | 0.0.0.2 | redisservice2 | redis_helper.py -> get_value_from_redis -> 67 | 717119067859219d | 二维码已过期， 请刷新重新扫描, status_code: 400"}
```
Same service, the 2 minutes before (oldest first):
  14:49:51.577 [redisservice2] INFO redis读取信息成功, status_code: 200  (×5)
  14:49:52.181 [redisservice2] INFO redis write success  (×7)
  14:49:52.689 [redisservice2] INFO service accept, status_code: 200  (×5)
  14:49:54.325 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×3)
All services, 30 seconds either side (sampled):
  14:49:35.568 [redisservice2] INFO redis write success  (×75)
  14:49:35.719 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×40)
  14:49:35.877 [redisservice1] INFO service accept, status_code: 200  (×29)
  14:49:36.288 [webservice1] INFO complete information: {'uuid': '4aaacf6a-fa70-11eb-9dd5-0242ac110003', 'user_id': 'JKhDNmCb'}  (×38)
  14:49:36.421 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×37)
  14:49:36.557 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×34)
  14:49:36.656 [mobservice1] INFO info 4acb43d0-fa70-11eb-b44f-0242ac110003:rzupZVkA write success
  14:49:36.951 [dbservice1] INFO query = select passwards from username_table where user_name='rzupZVkA'  (×35)
  14:49:38.052 [webservice2] INFO uuid: 4bc52f76-fa70-11eb-87b3-0242ac110004 write redis successfully  (×36)
  14:49:39.425 [mobservice1] INFO info 4c5905ac-fa70-11eb-ac5c-0242ac110004:YRPinNTo write success
  14:49:41.754 [dbservice2] INFO 4d8baefc-fa70-11eb-a008-0242ac110003-oLiIBNFj-n?OKmV7pSb}: token generate success token=MTYyODY2NDU4MS43NTM2MTA4OjRkOGJhZWZjLWZhNzAtMTFlYi1hMDA4LTAyNDJhYzE
  14:49:43.956 [mobservice1] INFO info 4f1e2268-fa70-11eb-bae7-0242ac110004:yODGvlBa write success
  14:49:46.549 [dbservice1] INFO 50706450-fa70-11eb-ac51-0242ac110003-xVDzUigO-B^s:FwmVgy>_ token generate success token=MTYyODY2NDU4Ni41NDg5ODc0OjUwNzA2NDUwLWZhNzAtMTFlYi1hYzUxLTAyNDJhYzE
  14:49:48.713 [mobservice2] INFO info 51f4f318-fa70-11eb-9805-0242ac110004:lkNrGYTL write success
  14:49:51.962 [dbservice1] INFO 53605ada-fa70-11eb-b788-0242ac110004-lrWJDxNP-9E/>y3K^Vtz* token generate success token=MTYyODY2NDU5MS45NjI1ODE6NTM2MDVhZGEtZmE3MC0xMWViLWI3ODgtMDI0MmFjMTE
  14:49:54.974 [dbservice2] INFO 555f26fe-fa70-11eb-ad0c-0242ac110003-dFRVcSCY-l=sf9C-mUi?> token generate success token=MTYyODY2NDU5NC45NzM2MzQyOjU1NWYyNmZlLWZhNzAtMTFlYi1hZDBjLTAyNDJhYzE
  14:50:05.584 [mobservice1] ERROR uuid:558070e8-fa70-11eb-a540-0242ac110003 information has expired, mobile phone login is invalid
  14:50:06.634 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  14:50:09.411 [dbservice2] INFO 5dee9b24-fa70-11eb-a4f2-0242ac110004-OkyWpDvC-YSR3f{z?a:H/ token generate success token=MTYyODY2NDYwOS40MTEzMzc6NWRlZTliMjQtZmE3MC0xMWViLWE0ZjItMDI0MmFjMTE
  14:50:11.818 [mobservice1] INFO info 5fc5238c-fa70-11eb-8d11-0242ac110004:lqFmKxHv write success
  14:50:14.228 [dbservice1] INFO 60f2d880-fa70-11eb-9998-0242ac110003-IYcJLxjh-C-6K2cN5{j}H token generate success token=MTYyODY2NDYxNC4yMjc2NTA0OjYwZjJkODgwLWZhNzAtMTFlYi05OTk4LTAyNDJhYzE
  14:50:16.361 [mobservice1] INFO info 6275a426-fa70-11eb-b613-0242ac110003:AsKCtDoY write success
  14:50:18.647 [dbservice2] INFO 63a0c2b8-fa70-11eb-9ce2-0242ac110003-PDUHwGKg-iz@kbgM>O<wD token generate success token=MTYyODY2NDYxOC42NDY4ODM6NjNhMGMyYjgtZmE3MC0xMWViLTljZTItMDI0MmFjMTE
  14:50:21.165 [mobservice1] INFO info 65486012-fa70-11eb-90c3-0242ac110004:TFXYPaBZ write success
  14:50:23.780 [dbservice2] INFO 668fe6e8-fa70-11eb-9497-0242ac110003-GZfYMFec-5$&S1)ZuTxf0 token generate success token=MTYyODY2NDYyMy43Nzk4NTAyOjY2OGZlNmU4LWZhNzAtMTFlYi05NDk3LTAyNDJhYzE
  14:50:26.820 [mobservice2] INFO info 68ac619a-fa70-11eb-9308-0242ac110004:CkWFaQYZ write success
  14:50:29.108 [dbservice1] INFO 69d8ce46-fa70-11eb-ad02-0242ac110003-WvYxbhDu-gm20&=aH_f%P token generate success token=MTYyODY2NDYyOS4xMDc4ODo2OWQ4Y2U0Ni1mYTcwLTExZWItYWQwMi0wMjQyYWMxMTA
  14:50:31.402 [mobservice2] INFO info 6b6d0b82-fa70-11eb-9530-0242ac110003:weSjQDRC write success
  14:50:34.145 [dbservice1] INFO 6c913baa-fa70-11eb-869b-0242ac110004-zrnyoxBF-Sbqp@TrH_P6c token generate success token=MTYyODY2NDYzNC4xNDQ2NjA1OjZjOTEzYmFhLWZhNzAtMTFlYi04NjliLTAyNDJhYzE

## p0585
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:45.387Z
```
{"timestamp":1733596305387261200,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:45.386  INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl       : nullUSER TOKEN"}
```
Same service, the 2 minutes before (oldest first):
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID
  18:31:36.611 [ts-auth-service] 2024-12-07 18:31:36.611 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null
  18:31:36.611 [ts-auth-service] 2024-12-07 18:31:36.611 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:31:36.778 [ts-auth-service] 2024-12-07 18:31:36.778 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×4)
  18:31:36.778 [ts-auth-service] 2024-12-07 18:31:36.778 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×4)
  18:31:37.923 [ts-auth-service] 2024-12-07 18:31:37.922 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×4)
  18:31:37.923 [ts-auth-service] 2024-12-07 18:31:37.922 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×4)
All services, 30 seconds either side (sampled):
  18:31:16.848 [ts-admin-basic-info-service] 2024-12-07 18:31:16.848 INFO 1 --- [io-18767-exec-1] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  18:31:18.558 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:31:18.558+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:6093  (×2)
  18:31:19.258 [ts-auth-service] 2024-12-07 18:31:19.257 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×22)
  18:31:19.319 [ts-food-service] 2024-12-07 18:31:19.319 INFO 1 --- [io-18856-exec-5] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  18:31:19.335 [ts-travel-service] 2024-12-07 18:31:19.335 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  18:31:19.676 [ts-travel2-service] 2024-12-07 18:31:19.676 ERROR 1 --- [io-16346-exec-2] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×14)
  18:31:19.687 [ts-travel2-service] 2024-12-07 18:31:19.687 ERROR 1 --- [o-16346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  18:31:20.904 [ts-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×4)
  18:31:21.810 [ts-order-other-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×2)
  18:31:27.403 [ts-travel-mongo] {"t":{"$date":"2024-12-07T18:31:27.403+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:27.588 [ts-route-mongo] {"t":{"$date":"2024-12-07T18:31:27.588+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.270 [ts-admin-travel-service] 2024-12-07 18:31:28.269 ERROR 1 --- [io-16114-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×8)
  18:31:29.436 [ts-assurance-service] 2024-12-07 18:31:29.436 ERROR 1 --- [io-18888-exec-7] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×3)
  18:31:29.867 [ts-food-mongo] {"t":{"$date":"2024-12-07T18:31:29.867+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:29.947 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:31:29.947+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:30.627 [ts-security-mongo] {"t":{"$date":"2024-12-07T18:31:30.626+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:31.064 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  18:31:31.698 [ts-order-service] 2024-12-07 18:31:31.698 ERROR 1 --- [io-12031-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:31:32.280 [ts-admin-basic-info-service] 2024-12-07 18:31:32.280 ERROR 1 --- [io-18767-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×16)
  18:31:38.105 [ts-admin-travel-service] 2024-12-07 18:31:38.104 ERROR 1 --- [o-16114-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×2)
  18:31:42.217 [ts-payment-mongo] {"t":{"$date":"2024-12-07T18:31:42.217+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359630
  18:31:44.203 [ts-admin-basic-info-service] 2024-12-07 18:31:44.202 ERROR 1 --- [o-18767-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  18:31:51.595 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:51 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 500 259 "-" "Mozilla/5.0 (Macintosh;   (×2)

## p0011
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T06:06:55.623Z
```
{"service":"dbservice1","message":"2021-08-13 06:06:55,623 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | ca6b96660906fa04 | 9ac36c42-fbb9-11eb-99c1-0242ac110003-OzKQAVJF-y0PH2h:lM}5T token generate success token=MTYyODgwNjAxNS42MjMyNjU1OjlhYzM2YzQyLWZiYjktMTFlYi05OWMxLTAyNDJhYzExMDAwM096S1FBVkpGeTBQSDJoOmxNfTVUOjE2Mjg4MDYwNzUuNjIzMjc2NTo4NDkxZjE1MzFhZTVmYmQ0ZTMxNTM1NTgyNjQwNmJiOA=="}
```
Same service, the 2 minutes before (oldest first):
  06:06:50.555 [dbservice1] INFO 97aef2d8-fbb9-11eb-9ec5-0242ac110003-yfLskzJE-J84Ts3QOwW-* token generate success token=MTYyODgwNjAxMC41NTUyNjE6OTdhZWYyZDgtZmJiOS0xMWViLTllYzUtMDI0MmFjMTE
  06:06:52.141 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  06:06:52.142 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  06:06:52.195 [dbservice1] INFO query = select passwards from username_table where user_name='QgokVGXf'  (×5)
  06:06:52.271 [dbservice1] INFO 98b9cd2e-fbb9-11eb-9bc6-0242ac110004-QgokVGXf-IJbkFjEAl(-K token generate success token=MTYyODgwNjAxMi4yNzEyNzE3Ojk4YjljZDJlLWZiYjktMTFlYi05YmM2LTAyNDJhYzE
  06:06:53.174 [dbservice1] INFO 993f2ce4-fbb9-11eb-98c8-0242ac110004-SNyDIdeO-%$BE{6JCn?Hd token generate success token=MTYyODgwNjAxMy4xNzM4ODAzOjk5M2YyY2U0LWZiYjktMTFlYi05OGM4LTAyNDJhYzE
  06:06:53.232 [dbservice1] INFO 99567444-fbb9-11eb-a8d1-0242ac110004-qhdLCnSU-I!Hg(Dukw}{) token generate success token=MTYyODgwNjAxMy4yMzIwMTc1Ojk5NTY3NDQ0LWZiYjktMTFlYi1hOGQxLTAyNDJhYzE
  06:06:54.031 [dbservice1] INFO 99c6938c-fbb9-11eb-b731-0242ac110003-jliMGRSf-@UO%!NH}$bsm token generate success token=MTYyODgwNjAxNC4wMzEwNDQ6OTljNjkzOGMtZmJiOS0xMWViLWI3MzEtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  06:06:25.629 [redisservice2] INFO redis write success  (×89)
  06:06:25.805 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '894543fa-fbb9-11eb-a526-0242ac110004'}  (×39)
  06:06:26.070 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '894543fa-fbb9-11eb-a526-0242ac110004'}  (×37)
  06:06:26.198 [logservice2] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '894543fa-fbb9-11eb-a526-0242ac110004', 'user_id': 'wRjEsaDr'}  (×81)
  06:06:26.474 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  06:06:26.735 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×42)
  06:06:26.939 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  06:06:27.155 [mobservice1] INFO info 89faf754-fbb9-11eb-b744-0242ac110004:ayOIXsmT write success
  06:06:28.045 [redisservice1] INFO service accept, status_code: 200  (×33)
  06:06:29.868 [dbservice1] ERROR password in database of {user} is null, the user is not registered  (×2)
  06:06:31.512 [dbservice2] INFO 8c6ef5c6-fbb9-11eb-936c-0242ac110003-YTchXgsi-MpkWe@KL3OmU token generate success token=MTYyODgwNTk5MS41MTIzNDEzOjhjNmVmNWM2LWZiYjktMTFlYi05MzZjLTAyNDJhYzE
  06:06:33.583 [mobservice2] INFO info 8dd6de24-fbb9-11eb-bdf8-0242ac110003:gFNpOQjC write success
  06:06:35.999 [mobservice2] INFO info 8f472642-fbb9-11eb-b678-0242ac110003:cwbxRDST write success
  06:06:38.441 [mobservice1] INFO info 90bfbc64-fbb9-11eb-af91-0242ac110003:qfINGhoa write success
  06:06:40.625 [dbservice1] INFO 91cbff46-fbb9-11eb-a2a1-0242ac110004-DGlMEFgf-hDX.AML@KH9e token generate success token=MTYyODgwNjAwMC42MjUyMzc6OTFjYmZmNDYtZmJiOS0xMWViLWEyYTEtMDI0MmFjMTE
  06:06:49.968 [mobservice1] INFO info 9797921e-fbb9-11eb-81e6-0242ac110003:irpbvSZq write success
  06:06:52.271 [dbservice1] INFO 98b9cd2e-fbb9-11eb-9bc6-0242ac110004-QgokVGXf-IJbkFjEAl(-K token generate success token=MTYyODgwNjAxMi4yNzEyNzE3Ojk4YjljZDJlLWZiYjktMTFlYi05YmM2LTAyNDJhYzE
  06:06:54.457 [mobservice1] INFO info 9a4a1e82-fbb9-11eb-8461-0242ac110003:nzavuSKJ write success
  06:06:56.891 [mobservice2] INFO info 9bbb635c-fbb9-11eb-a63f-0242ac110003:VwxKRfZB write success
  06:06:58.858 [dbservice2] INFO 9cb47190-fbb9-11eb-b9ea-0242ac110004-ISXlWuVn-?S9Cz:ye75_r token generate success token=MTYyODgwNjAxOC44NTc3NjI6OWNiNDcxOTAtZmJiOS0xMWViLWI5ZWEtMDI0MmFjMTE  (×2)
  06:07:01.270 [mobservice2] INFO info 9e5a6c3e-fbb9-11eb-a602-0242ac110004:UagLVmBc write success
  06:07:04.054 [mobservice1] INFO info a00afaf8-fbb9-11eb-bf27-0242ac110004:ucEdiNGD write success
  06:07:06.359 [dbservice1] INFO a11d0076-fbb9-11eb-b956-0242ac110004-fErgCUsY-VNdqLDmZ{O}H token generate success token=MTYyODgwNjAyNi4zNTk0MDQzOmExMWQwMDc2LWZiYjktMTFlYi1iOTU2LTAyNDJhYzE
  06:07:08.767 [mobservice2] INFO info a2c8246e-fbb9-11eb-adf3-0242ac110003:fCvhyxME write success
  06:07:11.487 [mobservice2] INFO info a46c9af2-fbb9-11eb-a143-0242ac110003:AwlIqmHD write success
  06:07:13.507 [dbservice1] INFO a5638a24-fbb9-11eb-afa0-0242ac110004-rEZWRTXD-UKb{HBlMXzm2 token generate success token=MTYyODgwNjAzMy41MDc0OTI1OmE1NjM4YTI0LWZiYjktMTFlYi1hZmEwLTAyNDJhYzE
  06:07:15.970 [dbservice2] INFO a6e4dc9a-fbb9-11eb-80e7-0242ac110003-vtpXmFKe-o%tl^Y:5g8X) token generate success token=MTYyODgwNjAzNS45Njk2Mzc5OmE2ZTRkYzlhLWZiYjktMTFlYi04MGU3LTAyNDJhYzE
  06:07:18.694 [mobservice1] INFO info a8c16aec-fbb9-11eb-961c-0242ac110004:RkEDeABl write success
  06:07:21.217 [dbservice1] INFO a9f26b14-fbb9-11eb-9ba3-0242ac110004-btlsWgLd-X^oq#)eu9Fd/ token generate success token=MTYyODgwNjA0MS4yMTczNTY0OmE5ZjI2YjE0LWZiYjktMTFlYi05YmEzLTAyNDJhYzE
  06:07:24.381 [mobservice2] INFO info ac076422-fbb9-11eb-9af9-0242ac110003:jyYHLuNM write success

## p0190
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:48:32.585Z
```
{"timestamp":1731912512585000400,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"serving product page"}
```
Same service, the 2 minutes before (oldest first):
  06:48:31.019 [frontend] request started  (×7)
  06:48:31.019 [frontend] adding to cart  (×2)
  06:48:31.027 [frontend] request complete  (×6)
  06:48:31.030 [frontend] view user cart  (×2)
  06:48:32.233 [frontend] serving product page
  06:48:32.336 [frontend] placing order
  06:48:32.389 [frontend] order placed
All services, 30 seconds either side (sampled):
  06:48:24.473 [frontend] request started  (×188)
  06:48:24.477 [currencyservice] Getting supported currencies...  (×157)
  06:48:24.488 [currencyservice] conversion request successful  (×395)
  06:48:24.504 [adservice] received ad request (context_words=[decor, home])  (×9)
  06:48:24.556 [adservice] received ad request (context_words=[accessories])  (×20)
  06:48:24.564 [cartservice] AddItemAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03, productId=OLJCESPC7Z, quantity=1  (×18)
  06:48:24.603 [shippingservice] [GetQuote] received request  (×45)
  06:48:25.170 [adservice] received ad request (context_words=[kitchen])  (×30)
  06:48:26.158 [frontend] setting currency  (×13)
  06:48:26.211 [frontend] ENV_PLATFORM is: aws  (×18)
  06:48:26.901 [adservice] received ad request (context_words=[clothing, tops])  (×7)
  06:48:27.795 [adservice] received ad request (context_words=[hair, beauty])  (×17)
  06:48:30.014 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="JPY"
  06:48:30.051 [paymentservice] Transaction processed: visa ending 4133 Amount: JPY147999.249890397
  06:48:30.054 [shippingservice] [ShipOrder] received request  (×2)
  06:48:30.057 [cartservice] EmptyCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03  (×2)
  06:48:30.063 [checkoutservice] order confirmation email sent to "mccoymelissa@example.net"
  06:48:32.337 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="GBP"
  06:48:32.374 [paymentservice] Transaction processed: visa ending 3003 Amount: GBP1238.66859775
  06:48:32.389 [checkoutservice] order confirmation email sent to "ericlewis@example.org"

## p0684
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice2, 2021-08-12T00:56:34.502Z
```
{"service":"redisservice2","message":"2021-08-12 00:56:34,502 | INFO | 0.0.0.2 | 172.17.0.4 | redisservice2 | affb2a9341f3012d | redis write success"}
```
Same service, the 2 minutes before (oldest first):
  00:56:30.854 [redisservice2] INFO redis读取信息成功, status_code: 200  (×6)
  00:56:31.013 [redisservice2] INFO service accept, status_code: 200  (×4)
  00:56:31.223 [redisservice2] INFO redis write success  (×7)
  00:56:31.520 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×3)
All services, 30 seconds either side (sampled):
  00:56:05.212 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×33)
  00:56:05.417 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×33)
  00:56:05.679 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×36)
  00:56:05.813 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×35)
  00:56:05.953 [dbservice2] INFO 0445284a-fac5-11eb-a40e-0242ac110003-SpsReQKd-%f.?Hm2-yCzl token generate success token=MTYyODcwMDk2NS45NTMzMDU6MDQ0NTI4NGEtZmFjNS0xMWViLWE0MGUtMDI0MmFjMTE
  00:56:08.584 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×32)
  00:56:11.442 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×28)
  00:56:13.740 [webservice2] INFO uuid: 095045a4-fac5-11eb-819c-0242ac110004 write redis successfully  (×37)
  00:56:13.922 [logservice1] ERROR get information failed, fail code: 400  (×2)
  00:56:14.310 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '098b5f2c-fac5-11eb-b10b-0242ac110003', 'value': 'gtLKWOSc'}  (×37)
  00:56:16.106 [mobservice1] INFO info 0a86286c-fac5-11eb-b2ed-0242ac110003:rZfAFMBU write success
  00:56:18.147 [dbservice2] INFO 0b81e7a6-fac5-11eb-be19-0242ac110004-LiESlVvW-MvOCr>:$DmLK token generate success token=MTYyODcwMDk3OC4xNDY5MjU0OjBiODFlN2E2LWZhYzUtMTFlYi1iZTE5LTAyNDJhYzE
  00:56:20.247 [mobservice2] INFO info 0d09a0f0-fac5-11eb-8420-0242ac110003:OvMizYlS write success
  00:56:22.832 [mobservice2] INFO info 0e872ba0-fac5-11eb-a553-0242ac110004:nHYqImvP write success
  00:56:25.484 [mobservice2] INFO info 10128b5e-fac5-11eb-996d-0242ac110004:qyhWbUnC write success
  00:56:27.326 [mobservice2] INFO info 11459f16-fac5-11eb-9eaf-0242ac110003:CPiYkQrA write success
  00:56:29.357 [dbservice2] INFO 123a5060-fac5-11eb-9715-0242ac110004-URMboZjf-a!7vBu@Ms{3G token generate success token=MTYyODcwMDk4OS4zNTY3OTQ6MTIzYTUwNjAtZmFjNS0xMWViLTk3MTUtMDI0MmFjMTE
  00:56:32.089 [dbservice2] INFO 13ca3756-fac5-11eb-ab36-0242ac110003-yWbZXEez-z1$5aONp@E#j token generate success token=MTYyODcwMDk5Mi4wODg5NDA2OjEzY2EzNzU2LWZhYzUtMTFlYi1hYjM2LTAyNDJhYzE
  00:56:34.931 [mobservice1] INFO info 15c36348-fac5-11eb-b803-0242ac110003:uiZfvcTY write success
  00:56:37.327 [mobservice2] INFO info 172e8046-fac5-11eb-8a5a-0242ac110004:rfqKcNpJ write success
  00:56:39.951 [dbservice2] INFO 189b2362-fac5-11eb-8150-0242ac110004-KXtHNvbZ-Qh<MIBE8TJ9i token generate success token=MTYyODcwMDk5OS45NTE0ODk0OjE4OWIyMzYyLWZhYzUtMTFlYi04MTUwLTAyNDJhYzE
  00:56:42.065 [mobservice2] INFO info 1a0c87fe-fac5-11eb-bb94-0242ac110003:BxzuqLwT write success
  00:56:43.983 [dbservice1] INFO 1afb1022-fac5-11eb-814e-0242ac110004-dMOcrJWb-_!QcK%2x(ubj token generate success token=MTYyODcwMTAwMy45ODMyNjIzOjFhZmIxMDIyLWZhYzUtMTFlYi04MTRlLTAyNDJhYzE
  00:56:54.203 [mobservice2] INFO info 21451220-fac5-11eb-868e-0242ac110004:cqyYsFCP write success
  00:56:57.305 [dbservice1] INFO 22ec59b2-fac5-11eb-9962-0242ac110003-hRGCgxwP-w+ql$pvC=?c> token generate success token=MTYyODcwMTAxNy4zMDQ4NjA2OjIyZWM1OWIyLWZhYzUtMTFlYi05OTYyLTAyNDJhYzE
  00:56:59.927 [mobservice1] INFO info 24a40cfa-fac5-11eb-ac16-0242ac110003:uZlYkfgS write success
  00:57:02.556 [mobservice1] INFO info 26335fd0-fac5-11eb-8957-0242ac110003:AZDazHog write success

## p0177
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:38:00.987Z
```
{"timestamp":1731911880987944700,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"order placed"}
```
Same service, the 2 minutes before (oldest first):
  06:38:00.568 [frontend] order placed
  06:38:00.584 [frontend] request complete  (×6)
  06:38:00.602 [frontend] request started  (×6)
  06:38:00.602 [frontend] serving product page  (×2)
  06:38:00.902 [frontend] home
  06:38:00.909 [frontend] adding to cart
  06:38:00.920 [frontend] view user cart
  06:38:00.943 [frontend] ENV_PLATFORM is: aws
  06:38:00.954 [frontend] placing order
All services, 30 seconds either side (sampled):
  06:37:31.182 [frontend] request started  (×316)
  06:37:31.190 [frontend] view user cart  (×69)
  06:37:31.205 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', 'OLJCESPC7Z', '9SIQT8TOJO', '6E92ZMYYFZ', 'L9ECAV7KIM']  (×215)
  06:37:31.218 [adservice] received ad request (context_words=[clothing, tops])  (×15)
  06:37:32.140 [adservice] received ad request (context_words=[accessories])  (×33)
  06:37:32.384 [frontend] placing order  (×10)
  06:37:32.413 [paymentservice] Transaction processed: visa ending 1970 Amount: CAD276.840392742  (×3)
  06:37:32.416 [shippingservice] [ShipOrder] completed request  (×10)
  06:37:32.424 [checkoutservice] failed to send order confirmation to "wfrey@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:37:35.272 [frontend] setting currency  (×26)
  06:37:35.321 [adservice] received ad request (context_words=[])  (×37)
  06:37:37.663 [adservice] received ad request (context_words=[hair, beauty])  (×16)
  06:38:00.568 [checkoutservice] failed to send order confirmation to "laurenstokes@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:38:00.974 [paymentservice] Transaction processed: visa ending 8009 Amount: EUR361.636444053
  06:38:06.202 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"15758","nanos":351172191},"credit_card":{"credit_card_number":"401299073460  (×2)
  06:38:13.620 [checkoutservice] failed to send order confirmation to "jacquelineclark@example.com": rpc error: code = Unavailable desc = no healthy upstream
  06:38:13.983 [paymentservice] Transaction processed: visa ending 7144 Amount: USD183.920000000  (×2)
  06:38:18.756 [checkoutservice] failed to send order confirmation to "rosalestaylor@example.net": rpc error: code = Unavailable desc = no healthy upstream
  06:38:22.555 [paymentservice] Transaction processed: visa ending 6520 Amount: GBP485.873086245  (×2)
  06:38:23.740 [emailservice] Profiler disabled.
  06:38:28.239 [checkoutservice] failed to send order confirmation to "meghan56@example.com": rpc error: code = Unavailable desc = no healthy upstream

## p0180
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T06:40:57.282Z
```
{"timestamp":1731912057282832000,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-svrwm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43"}
```
Same service, the 2 minutes before (oldest first):
  06:40:53.543 [cartservice] EmptyCartAsync called with userId=adf41e5f-12f6-4c40-88a0-a1bcf421e416  (×2)
  06:40:53.779 [cartservice] GetCartAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4  (×16)
  06:40:53.908 [cartservice] AddItemAsync called with userId=33421b66-55b6-413b-9ba9-3230c85c58dc, productId=OLJCESPC7Z, quantity=2  (×2)
All services, 30 seconds either side (sampled):
  06:40:27.297 [frontend] request started  (×310)
  06:40:27.303 [cartservice] GetCartAsync called with userId=fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a  (×249)
  06:40:27.325 [adservice] received ad request (context_words=[kitchen])  (×51)
  06:40:27.332 [cartservice] AddItemAsync called with userId=fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a, productId=LS4PSXUNUM, quantity=2  (×29)
  06:40:27.364 [shippingservice] [GetQuote] completed request  (×71)
  06:40:27.400 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"40","nanos":663423265},"credit_card":{"credit_card_number":"454695027570143  (×4)
  06:40:27.404 [shippingservice] [ShipOrder] received request  (×11)
  06:40:27.411 [checkoutservice] failed to send order confirmation to "edward09@example.com": rpc error: code = Unavailable desc = no healthy upstream
  06:40:27.665 [adservice] received ad request (context_words=[decor, home])  (×16)
  06:40:27.799 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"2365","nanos":159795640},"credit_card":{"credit_card_number":"4850822491718  (×5)
  06:40:27.824 [adservice] received ad request (context_words=[clothing, tops])  (×15)
  06:40:29.060 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '6E92ZMYYFZ', '9SIQT8TOJO', 'OLJCESPC7Z']  (×2)
  06:40:29.314 [frontend] ENV_PLATFORM is: aws  (×40)
  06:40:34.997 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="CAD"
  06:40:35.044 [checkoutservice] failed to send order confirmation to "brandon35@example.com": rpc error: code = Unavailable desc = no healthy upstream
  06:40:53.535 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"15867","nanos":923927858},"credit_card":{"credit_card_number":"453377377952
  06:40:53.982 [checkoutservice] failed to send order confirmation to "rschroeder@example.net": rpc error: code = Unavailable desc = no healthy upstream
  06:41:11.026 [redis] 1:M 18 Nov 2024 06:41:11.026 * 100 changes in 300 seconds. Saving...
  06:41:11.032 [redis] 66:C 18 Nov 2024 06:41:11.032 * Fork CoW for RDB: current 0 MB, peak 0 MB, average 0 MB
  06:41:15.894 [checkoutservice] failed to send order confirmation to "emily09@example.net": rpc error: code = Unavailable desc = upstream connect error or disconnect/reset before headers. retr
  06:41:17.856 [emailservice] Traceback (most recent call last): File "/email_server/email_server.py", line 199, in <module> start(dummy_mode = True) File "/email_server/email_server.py", li
  06:41:24.992 [checkoutservice] failed to send order confirmation to "jon88@example.com": rpc error: code = Unavailable desc = no healthy upstream

## p0058
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T08:38:41.421Z
```
{"service":"dbservice1","message":"2021-08-13 08:38:41,421 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 20cad5236036e03d | ce428890-fbce-11eb-b333-0242ac110004-AOMaRpbl-TzUn?{3BhA#u token generate success token=MTYyODgxNTEyMS40MjE1OTg0OmNlNDI4ODkwLWZiY2UtMTFlYi1iMzMzLTAyNDJhYzExMDAwNEFPTWFScGJsVHpVbj97M0JoQSN1OjE2Mjg4MTUxODEuNDIxNjA5NjpjOGMyZjdlZTFhMjk3ZTkyYjIyMGNlNzUzZmU5ZjE2NQ=="}
```
Same service, the 2 minutes before (oldest first):
  08:38:38.164 [dbservice1] INFO cc4e5208-fbce-11eb-b940-0242ac110004-mTbzBuLd-&3Xy1pR.2AFO token generate success token=MTYyODgxNTExOC4xNjQyODk3OmNjNGU1MjA4LWZiY2UtMTFlYi1iOTQwLTAyNDJhYzE
  08:38:38.828 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×6)
  08:38:38.828 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×6)
  08:38:38.889 [dbservice1] INFO query = select passwards from username_table where user_name='vtpXmFKe'  (×4)
  08:38:38.965 [dbservice1] INFO ccce4e4a-fbce-11eb-801c-0242ac110003-vtpXmFKe-o%tl^Y:5g8X) token generate success token=MTYyODgxNTExOC45NjUyNDcyOmNjY2U0ZTRhLWZiY2UtMTFlYi04MDFjLTAyNDJhYzE
  08:38:39.888 [dbservice1] INFO cd565876-fbce-11eb-bc0f-0242ac110003-PyWJlfep-iu/am&SCWnFx token generate success token=MTYyODgxNTExOS44ODc4MTk4OmNkNTY1ODc2LWZiY2UtMTFlYi1iYzBmLTAyNDJhYzE
  08:38:39.900 [dbservice1] INFO cd462fe6-fbce-11eb-ae68-0242ac110003-zFRIyZKg-MH4f5}WvX/In token generate success token=MTYyODgxNTExOS44OTkzOTEyOmNkNDYyZmU2LWZiY2UtMTFlYi1hZTY4LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  08:38:11.443 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  08:38:11.493 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': 'bc925396-fbce-11eb-9b3b-0242ac110004', 'user_id': 'sUWAVXFt'}  (×86)
  08:38:11.563 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'bce01c70-fbce-11eb-aad8-0242ac110004', 'value': '', 'ex': 10}  (×42)
  08:38:11.626 [redisservice2] INFO service accept, status_code: 200  (×25)
  08:38:11.754 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×40)
  08:38:12.145 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  08:38:12.242 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  08:38:12.423 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×43)
  08:38:12.612 [mobservice2] INFO info bd47ee22-fbce-11eb-930d-0242ac110003:kmPegpXw write success
  08:38:12.854 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×43)
  08:38:13.760 [dbservice1] INFO bdcd682c-fbce-11eb-9af3-0242ac110003-GmfKwAOM-)X4PM9QtBES/ token generate success token=MTYyODgxNTA5My43NjAzNjg2OmJkY2Q2ODJjLWZiY2UtMTFlYi05YWYzLTAyNDJhYzE
  08:38:15.623 [mobservice2] INFO info bf17c7a4-fbce-11eb-a038-0242ac110003:NdFpoUqE write success
  08:38:19.732 [mobservice2] INFO info c18eca78-fbce-11eb-b7de-0242ac110004:npqwesLI write success
  08:38:28.898 [mobservice2] INFO info c70c485e-fbce-11eb-ba0f-0242ac110004:wcXjOMum write success
  08:38:32.267 [mobservice1] INFO info c8fa0566-fbce-11eb-8f99-0242ac110003:CyQWkovZ write success
  08:38:34.480 [mobservice2] INFO info ca56f482-fbce-11eb-8545-0242ac110003:wpOMLejE write success
  08:38:37.294 [dbservice1] INFO cbbdf6fe-fbce-11eb-a94a-0242ac110004-zrnyoxBF-Sbqp@TrH_P6c token generate success token=MTYyODgxNTExNy4yOTQ1ODc5OmNiYmRmNmZlLWZiY2UtMTFlYi1hOTRhLTAyNDJhYzE
  08:38:39.564 [mobservice1] INFO info cd565876-fbce-11eb-bc0f-0242ac110003:PyWJlfep write success
  08:38:42.389 [mobservice1] INFO info cf043026-fbce-11eb-8300-0242ac110003:qQRWFANX write success  (×3)
  08:38:44.966 [mobservice1] INFO info d08fb7d0-fbce-11eb-846d-0242ac110003:nAxhWmpD write success
  08:38:47.399 [mobservice2] INFO info d2067ea0-fbce-11eb-9800-0242ac110003:TPLgkydZ write success
  08:38:49.318 [dbservice1] INFO d2f35234-fbce-11eb-93ea-0242ac110004-GiuNzrvJ-YnTciU0WR&3p token generate success token=MTYyODgxNTEyOS4zMTc2MjQ6ZDJmMzUyMzQtZmJjZS0xMWViLTkzZWEtMDI0MmFjMTE
  08:38:52.263 [dbservice1] INFO d4b660e8-fbce-11eb-8498-0242ac110003-otxdGLkJ-:i2e%}c)9Xn8 token generate success token=MTYyODgxNTEzMi4yNjMwNDg2OmQ0YjY2MGU4LWZiY2UtMTFlYi04NDk4LTAyNDJhYzE
  08:38:54.506 [dbservice1] INFO d61fdd74-fbce-11eb-9da6-0242ac110004-CPiYkQrA-O&mRE!hKAS{t token generate success token=MTYyODgxNTEzNC41MDYwMDU6ZDYxZmRkNzQtZmJjZS0xMWViLTlkYTYtMDI0MmFjMTE
  08:38:56.514 [dbservice1] INFO d73f4672-fbce-11eb-83bd-0242ac110003-dtYZahVu-L-(wot&?xVCf token generate success token=MTYyODgxNTEzNi41MTQ1MDU2OmQ3M2Y0NjcyLWZiY2UtMTFlYi04M2JkLTAyNDJhYzE
  08:38:59.322 [dbservice1] INFO d8f27f20-fbce-11eb-95ff-0242ac110004-bZJaiYAt-*S+vbf5AyB2- token generate success token=MTYyODgxNTEzOS4zMjIzMDE6ZDhmMjdmMjAtZmJjZS0xMWViLTk1ZmYtMDI0MmFjMTE
  08:39:01.903 [mobservice2] INFO info daa13b7c-fbce-11eb-905e-0242ac110004:oLiIBNFj write success
  08:39:04.998 [dbservice1] INFO dc499758-fbce-11eb-a277-0242ac110004-lkNrGYTL-S$afkB0(o_gn token generate success token=MTYyODgxNTE0NC45OTc4ODU1OmRjNDk5NzU4LWZiY2UtMTFlYi1hMjc3LTAyNDJhYzE
  08:39:07.461 [dbservice1] INFO ddb98936-fbce-11eb-b27b-0242ac110003-JuoeTjfH-</8-1d:T#)+0 token generate success token=MTYyODgxNTE0Ny40NjA5NzpkZGI5ODkzNi1mYmNlLTExZWItYjI3Yi0wMjQyYWMxMTA
  08:39:10.341 [mobservice2] INFO info dfb6889c-fbce-11eb-8c60-0242ac110004:qfGXigUn write success

## p0171
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T06:34:06.045Z
```
{"timestamp":1731911646045614600,"container_name":"adservice","pod_name":"adservice-b9bcc6cc9-sdkf5","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"received ad request (context_words=[accessories])"}
```
Same service, the 2 minutes before (oldest first):
  06:33:59.467 [adservice] received ad request (context_words=[footwear])  (×3)
  06:33:59.529 [adservice] received ad request (context_words=[accessories])  (×5)
  06:34:00.446 [adservice] received ad request (context_words=[kitchen])  (×3)
  06:34:00.567 [adservice] received ad request (context_words=[hair, beauty])  (×3)
  06:34:01.433 [adservice] received ad request (context_words=[])  (×5)
  06:34:05.037 [adservice] received ad request (context_words=[decor, home])
All services, 30 seconds either side (sampled):
  06:33:36.199 [frontend] request started  (×315)
  06:33:36.208 [cartservice] GetCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03  (×262)
  06:33:36.232 [adservice] received ad request (context_words=[hair, beauty])  (×20)
  06:33:36.311 [adservice] received ad request (context_words=[clothing, tops])  (×19)
  06:33:38.877 [shippingservice] [GetQuote] received request  (×78)
  06:33:39.338 [frontend] ENV_PLATFORM is: aws  (×33)
  06:33:39.862 [cartservice] AddItemAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53, productId=LS4PSXUNUM, quantity=3  (×33)
  06:33:42.925 [frontend] placing order  (×11)
  06:33:42.954 [paymentservice] Transaction processed: visa ending 5362 Amount: EUR1091.410880145  (×2)
  06:33:42.959 [shippingservice] [ShipOrder] completed request  (×11)
  06:33:42.968 [checkoutservice] order confirmation email sent to "beth47@example.com"
  06:33:44.101 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"351","nanos":149997339},"credit_card":{"credit_card_number":"47569590739741  (×4)
  06:33:44.113 [checkoutservice] order confirmation email sent to "phillipsteresa@example.net"
  06:33:47.565 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', 'L9ECAV7KIM', '0PUK6V6EV0', 'LS4PSXUNUM']  (×4)
  06:33:54.369 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="CAD"  (×2)
  06:33:54.417 [emailservice] A request to send order confirmation email to robinsonandrew@example.org has been received.
  06:34:10.530 [checkoutservice] order confirmation email sent to "hansonjoshua@example.com"
  06:34:17.778 [emailservice] A request to send order confirmation email to julieperkins@example.com has been received.
  06:34:18.458 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"63","nanos":890000000},"credit_card":{"credit_card_number":"471054125026553
  06:34:18.474 [checkoutservice] order confirmation email sent to "david72@example.com"
  06:34:23.185 [paymentservice] Transaction processed: visa ending 5958 Amount: TRY1229.219976114  (×2)
  06:34:30.287 [emailservice] A request to send order confirmation email to deborah28@example.com has been received.
  06:34:35.872 [emailservice] A request to send order confirmation email to martinezsara@example.net has been received.

## p0708
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-14T01:26:31.503Z
```
{"service":"dbservice1","message":"2021-08-14 01:26:31,503 | INFO | 0.0.0.4 | dbservice1 | permission_operate.py -> permission_operation -> 51 | 45a636f600cfedf7 | now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  01:26:24.230 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×6)
  01:26:24.231 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  01:26:24.373 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  01:26:25.830 [dbservice1] INFO query = select passwards from username_table where user_name='ckaGqjZH'  (×4)
  01:26:25.907 [dbservice1] INFO 95e67b18-fc5b-11eb-a9f1-0242ac110004-ckaGqjZH-{HR_>mq&f6Nx token generate success token=MTYyODg3NTU4NS45MDcyMDc1Ojk1ZTY3YjE4LWZjNWItMTFlYi1hOWYxLTAyNDJhYzE
  01:26:29.169 [dbservice1] INFO 97d09f44-fc5b-11eb-ac83-0242ac110004-PMIwlKZi-7A>JsQ{2D}&1 token generate success token=MTYyODg3NTU4OS4xNjkzMjE6OTdkMDlmNDQtZmM1Yi0xMWViLWFjODMtMDI0MmFjMTE
  01:26:29.914 [dbservice1] INFO 98592a08-fc5b-11eb-9bb6-0242ac110004-hSgYsZXG-G/$bF2i+j:Uw token generate success token=MTYyODg3NTU4OS45MTQyNzczOjk4NTkyYTA4LWZjNWItMTFlYi05YmI2LTAyNDJhYzE
  01:26:30.805 [dbservice1] INFO 98c8a298-fc5b-11eb-8f2e-0242ac110003-VizMUmJR-FY?r-G0Za*AR token generate success token=MTYyODg3NTU5MC44MDUwOTQ1Ojk4YzhhMjk4LWZjNWItMTFlYi04ZjJlLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  01:26:01.517 [redisservice2] INFO redis write success  (×102)
  01:26:01.665 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×44)
  01:26:01.762 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×46)
  01:26:01.898 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×48)
  01:26:02.184 [redisservice1] INFO redis读取信息成功, status_code: 200  (×46)
  01:26:03.006 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '88643b9c-fc5b-11eb-9394-0242ac110004'}  (×51)
  01:26:03.706 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '88eae4bc-fc5b-11eb-9c79-0242ac110004'}  (×48)
  01:26:04.147 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  01:26:04.977 [dbservice2] INFO 8967a47a-fc5b-11eb-bb30-0242ac110004-ocYXAMHN-9(D$TR<G6AB# token generate success token=MTYyODg3NTU2NC45NzY1MTUzOjg5NjdhNDdhLWZjNWItMTFlYi1iYjMwLTAyNDJhYzE
  01:26:07.677 [dbservice2] INFO 8af610c4-fc5b-11eb-a5ae-0242ac110004-uxPlARkn-i2E#w.zXD4HY token generate success token=MTYyODg3NTU2Ny42NzczNTQ2OjhhZjYxMGM0LWZjNWItMTFlYi1hNWFlLTAyNDJhYzE  (×2)
  01:26:10.765 [mobservice1] INFO info 8d0b1896-fc5b-11eb-943d-0242ac110004:lnbVdqst write success
  01:26:13.606 [dbservice2] ERROR password in database of {user} is null, the user is not registered
  01:26:16.299 [dbservice1] INFO 9028aa2a-fc5b-11eb-825f-0242ac110003-KOZoDVJh-B8f#M%=K4gVj token generate success token=MTYyODg3NTU3Ni4yOTg2NzI6OTAyOGFhMmEtZmM1Yi0xMWViLTgyNWYtMDI0MmFjMTE
  01:26:18.801 [mobservice2] INFO info 91dd409c-fc5b-11eb-8bb6-0242ac110003:bZJaiYAt write success
  01:26:21.529 [mobservice2] INFO info 938605dc-fc5b-11eb-8265-0242ac110003:XUtTqLre write success
  01:26:24.056 [mobservice1] INFO info 9504e004-fc5b-11eb-8fe2-0242ac110004:TmVsgowE write success
  01:26:26.369 [mobservice1] INFO info 9666a180-fc5b-11eb-a2de-0242ac110004:uxPlARkn write success
  01:26:29.169 [dbservice1] INFO 97d09f44-fc5b-11eb-ac83-0242ac110004-PMIwlKZi-7A>JsQ{2D}&1 token generate success token=MTYyODg3NTU4OS4xNjkzMjE6OTdkMDlmNDQtZmM1Yi0xMWViLWFjODMtMDI0MmFjMTE
  01:26:31.642 [dbservice1] INFO 9952aa92-fc5b-11eb-9739-0242ac110004-pkIFrtAz-I})K1%yO+*f7 token generate success token=MTYyODg3NTU5MS42NDIzOTY3Ojk5NTJhYTkyLWZjNWItMTFlYi05NzM5LTAyNDJhYzE
  01:26:34.421 [dbservice2] INFO 9aeee5aa-fc5b-11eb-b36b-0242ac110004-PyWJlfep-iu/am&SCWnFx token generate success token=MTYyODg3NTU5NC40MjA2NDk6OWFlZWU1YWEtZmM1Yi0xMWViLWIzNmItMDI0MmFjMTE
  01:26:36.879 [dbservice2] INFO 9c6c6e5c-fc5b-11eb-911a-0242ac110003-CMzFsYZh-4nfMZxAl(ko0 token generate success token=MTYyODg3NTU5Ni44NzkwNDI5OjljNmM2ZTVjLWZjNWItMTFlYi05MTFhLTAyNDJhYzE
  01:26:39.274 [dbservice2] INFO 9ddd8cb2-fc5b-11eb-beab-0242ac110003-LcsBuYDh-t59/!mQe3_&1 token generate success token=MTYyODg3NTU5OS4yNzQzMzE4OjlkZGQ4Y2IyLWZjNWItMTFlYi1iZWFiLTAyNDJhYzE
  01:26:41.882 [dbservice2] INFO 9f77b44e-fc5b-11eb-98c2-0242ac110004-rzupZVkA-Qd<YFATn8+k) token generate success token=MTYyODg3NTYwMS44ODE1NjM0OjlmNzdiNDRlLWZjNWItMTFlYi05OGMyLTAyNDJhYzE
  01:26:44.837 [dbservice1] INFO a11b1304-fc5b-11eb-900c-0242ac110003-tcvLYMig-0-iMCvLR/h*k token generate success token=MTYyODg3NTYwNC44MzcwNzM6YTExYjEzMDQtZmM1Yi0xMWViLTkwMGMtMDI0MmFjMTE
  01:26:47.291 [mobservice2] INFO info a2e5c67a-fc5b-11eb-8979-0242ac110003:IdNORUSj write success
  01:26:50.069 [dbservice1] INFO a4530c84-fc5b-11eb-a463-0242ac110004-IYcJLxjh-C-6K2cN5{j}H token generate success token=MTYyODg3NTYxMC4wNjk0NzExOmE0NTMwYzg0LWZjNWItMTFlYi1hNDYzLTAyNDJhYzE
  01:26:53.041 [mobservice2] INFO info a642a3a6-fc5b-11eb-a954-0242ac110004:NFrlOSIe write success
  01:26:55.885 [mobservice1] INFO info a7fff8c4-fc5b-11eb-aed2-0242ac110004:ZYabGCTS write success
  01:26:58.199 [dbservice1] INFO a936adaa-fc5b-11eb-8af9-0242ac110003-RVxXNljY-cDs.FlES+XiZ token generate success token=MTYyODg3NTYxOC4xOTg3NzA1OmE5MzZhZGFhLWZjNWItMTFlYi04YWY5LTAyNDJhYzE
  01:27:00.531 [dbservice2] INFO aa928a52-fc5b-11eb-b19e-0242ac110004-wzNVdLGu->w?zB:biZ0y_ token generate success token=MTYyODg3NTYyMC41MzEyODc6YWE5MjhhNTItZmM1Yi0xMWViLWIxOWUtMDI0MmFjMTE

## p0064
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T08:56:25.158Z
```
{"service":"dbservice1","message":"2021-08-13 08:56:25,158 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | a97d03bf64e2a02a | 48490928-fbd1-11eb-94d8-0242ac110003-jHYceNBX-P4kgXJlU1L>S token generate success token=MTYyODgxNjE4NS4xNTg1MzE3OjQ4NDkwOTI4LWZiZDEtMTFlYi05NGQ4LTAyNDJhYzExMDAwM2pIWWNlTkJYUDRrZ1hKbFUxTD5TOjE2Mjg4MTYyNDUuMTU4NTQyNjo4ZGMyNjAxNGI3NTgxY2JjMTVkM2M1MDcyMzc0NDU1Mw=="}
```
Same service, the 2 minutes before (oldest first):
  08:56:09.931 [dbservice1] INFO 3f1abd4c-fbd1-11eb-a053-0242ac110003-VHLPfDSU-?%<=*FYN4E2+ token generate success token=MTYyODgxNjE2OS45MzA4OTU6M2YxYWJkNGMtZmJkMS0xMWViLWEwNTMtMDI0MmFjMTE
  08:56:10.751 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:56:10.752 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  08:56:10.806 [dbservice1] INFO query = select passwards from username_table where user_name='uxPlARkn'  (×5)
  08:56:10.886 [dbservice1] INFO 3fb9038a-fbd1-11eb-a331-0242ac110004-uxPlARkn-i2E#w.zXD4HY token generate success token=MTYyODgxNjE3MC44ODU3ODA2OjNmYjkwMzhhLWZiZDEtMTFlYi1hMzMxLTAyNDJhYzE
  08:56:15.530 [dbservice1] INFO 427bfbcc-fbd1-11eb-bd05-0242ac110003-NLUGYXBI-Lmw1G?kYO}b^ token generate success token=MTYyODgxNjE3NS41MzAxNDo0MjdiZmJjYy1mYmQxLTExZWItYmQwNS0wMjQyYWMxMTA
  08:56:16.156 [dbservice1] INFO 42ebeb4e-fbd1-11eb-b24b-0242ac110004-FTkscPog-!K5SR?}hnJW> token generate success token=MTYyODgxNjE3Ni4xNTYzNjg3OjQyZWJlYjRlLWZiZDEtMTFlYi1iMjRiLTAyNDJhYzE
  08:56:21.478 [dbservice1] INFO 4604bb9e-fbd1-11eb-8791-0242ac110003-PtpxFCHR-o#ehxpV6iN_T token generate success token=MTYyODgxNjE4MS40Nzc5Njg1OjQ2MDRiYjllLWZiZDEtMTFlYi04NzkxLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  08:55:55.189 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  08:55:55.329 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  08:55:55.405 [redisservice2] INFO redis读取信息成功, status_code: 200  (×59)
  08:55:55.469 [logservice2] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': '36abb3be-fbd1-11eb-8d75-0242ac110003', 'user_id': 'osKDHrgX'}  (×101)
  08:55:55.535 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×56)
  08:55:55.665 [mobservice1] INFO info 36ee34fa-fbd1-11eb-b053-0242ac110004:bGtJCiAM write success
  08:55:55.875 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×51)
  08:55:56.355 [redisservice2] INFO service refuse, status_code: 200  (×32)
  08:55:57.885 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×53)
  08:55:58.223 [mobservice1] INFO info 3874370c-fbd1-11eb-a07d-0242ac110003:GxrcRlDj write success
  08:56:01.234 [mobservice2] INFO info 3a35b67e-fbd1-11eb-92fa-0242ac110003:EkAYnzMd write success
  08:56:04.208 [dbservice1] INFO 3bbd4b74-fbd1-11eb-879c-0242ac110004-rhVoyqAc-:LnRb/Hg2fzY token generate success token=MTYyODgxNjE2NC4yMDgxNTk6M2JiZDRiNzQtZmJkMS0xMWViLTg3OWMtMDI0MmFjMTE
  08:56:07.504 [mobservice2] INFO info 3dfa1bb0-fbd1-11eb-9cdf-0242ac110004:UEASdwYn write success
  08:56:10.455 [mobservice1] INFO info 3fb9038a-fbd1-11eb-a331-0242ac110004:uxPlARkn write success
  08:56:14.255 [mobservice1] INFO info 41f82040-fbd1-11eb-b7a2-0242ac110003:UoOtrWnu write success
  08:56:17.390 [mobservice2] INFO info 43d15c9c-fbd1-11eb-ab34-0242ac110003:MfgEVxGn write success
  08:56:21.092 [mobservice2] INFO info 4604bb9e-fbd1-11eb-8791-0242ac110003:PtpxFCHR write success
  08:56:24.804 [mobservice1] INFO info 48490928-fbd1-11eb-94d8-0242ac110003:jHYceNBX write success
  08:56:28.488 [mobservice1] INFO info 4a83924e-fbd1-11eb-b0aa-0242ac110004:XUFSBybj write success
  08:56:31.025 [mobservice2] INFO info 4bf6e77a-fbd1-11eb-bec3-0242ac110004:MGhzxsST write success
  08:56:33.763 [mobservice1] INFO info 4d9b7154-fbd1-11eb-9cde-0242ac110003:KrCJbket write success
  08:56:36.969 [mobservice1] INFO info 4f762ce4-fbd1-11eb-b10a-0242ac110003:dNpfZrzW write success
  08:56:40.256 [mobservice2] INFO info 517a85da-fbd1-11eb-8af5-0242ac110004:mMWStTBy write success
  08:56:43.079 [mobservice2] INFO info 5324da98-fbd1-11eb-8452-0242ac110003:AkMRXwoH write success
  08:56:45.882 [mobservice1] INFO info 54d446da-fbd1-11eb-b7cf-0242ac110003:zoYxJZbF write success
  08:56:49.760 [mobservice1] INFO info 573230fe-fbd1-11eb-a5cf-0242ac110004:dMOcrJWb write success
  08:56:51.843 [dbservice1] INFO 582927d8-fbd1-11eb-b452-0242ac110004-xomaJMly-EYTm8(4?5G7B token generate success token=MTYyODgxNjIxMS44NDM0ODY4OjU4MjkyN2Q4LWZiZDEtMTFlYi1iNDUyLTAyNDJhYzE
  08:56:54.908 [mobservice2] INFO info 5a37b378-fbd1-11eb-90d5-0242ac110003:AnasJGMP write success

## p0814
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-ui-dashboard, 2024-12-10T13:14:29.904Z
```
{"timestamp":1733836469904545800,"container_name":"ts-ui-dashboard","pod_name":"ts-ui-dashboard-667c5cdd98-snnmc","node_name":"ip-192-168-88-150.ap-southeast-2.compute.internal","message":"127.0.0.1 - - [10/Dec/2024:21:14:29 +0800] \"POST /api/v1/users/login HTTP/1.1\" 503 19 \"http://localhost:8080/client_login.html\" \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36\""}
```
Same service, the 2 minutes before (oldest first):
  13:14:18.099 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:18 +0800] "POST /api/v1/users/login HTTP/1.1" 200 353 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×5)
  13:14:18.338 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:18 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A
  13:14:18.769 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:18 +0800] "GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1" 200 202 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×3)
  13:14:18.890 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:18 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 54 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×4)
  13:14:19.831 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:19 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 200 1326 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Appl  (×2)
  13:14:19.878 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:19 +0800] "PUT /api/v1/consignservice/consigns HTTP/1.1" 200 410 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebK  (×2)
  13:14:20.978 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:20 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 3056 "-" "Mozilla/5.0 (Macintosh;
  13:14:26.893 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:26 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 64 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWeb  (×2)
All services, 30 seconds either side (sampled):
  13:14:00.207 [ts-food-service] 2024-12-10 13:14:00.207 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  13:14:00.225 [ts-travel-service] 2024-12-10 13:14:00.225 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d  (×29)
  13:14:02.767 [ts-auth-service] 2024-12-10 13:14:02.767 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×6)
  13:14:02.921 [ts-auth-service] 2024-12-10 13:14:02.921 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×9)
  13:14:03.001 [ts-travel2-service] 2024-12-10 13:14:03.001 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×46)
  13:14:04.027 [ts-order-other-service] 2024-12-10 13:14:04.027 INFO 1 --- [io-12032-exec-8] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 3
  13:14:04.094 [ts-inside-payment-service] 2024-12-10 13:14:04.094 INFO 1 --- [io-18673-exec-1] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.
  13:14:04.925 [ts-travel-service] 2024-12-10 13:14:04.925 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×5)
  13:14:04.987 [ts-travel-service] 2024-12-10 13:14:04.986 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  13:14:05.016 [ts-admin-travel-service] 2024-12-10 13:14:05.016 INFO 1 --- [io-16114-exec-2] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×8)
  13:14:08.242 [ts-auth-service] 2024-12-10 13:14:08.241 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  13:14:08.434 [ts-travel-service] 2024-12-10 13:14:08.434 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×16)
  13:14:09.152 [ts-admin-basic-info-service] 2024-12-10 13:14:09.152 INFO 1 --- [io-18767-exec-8] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×8)
  13:14:11.856 [ts-station-mongo] {"t":{"$date":"2024-12-10T13:14:11.856+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383645
  13:14:12.330 [ts-order-other-mongo] {"t":{"$date":"2024-12-10T13:14:12.330+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383645
  13:14:12.685 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-10T13:14:12.685+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383645
  13:14:13.211 [ts-security-mongo] {"t":{"$date":"2024-12-10T13:14:13.211+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383645
  13:14:14.923 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-10T13:14:14.923+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383645
  13:14:15.737 [ts-auth-service] [otel.javaagent 2024-12-10 13:14:15:737 +0000] [main] INFO io.opentelemetry.javaagent.tooling.VersionLogger - opentelemetry-javaagent - version: 1.30.0 . ____ _
  13:14:19.803 [ts-order-service] 2024-12-10 13:14:19.803 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 3  (×2)
  13:14:19.846 [ts-consign-service] 2024-12-10 13:14:19.845 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : Order ID is :5ad7750b-a68b-49c0-a8c0-32776b067703  (×2)
  13:14:19.878 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:19 +0800] "PUT /api/v1/consignservice/consigns HTTP/1.1" 200 410 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebK  (×2)
  13:14:26.893 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:26 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 64 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWeb  (×5)
  13:14:29.458 [ts-auth-service] 2024-12-10 13:14:29.458 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  13:14:29.467 [ts-auth-service] 2024-12-10 13:14:29.466 INFO 1 --- [ Thread-5] o.s.j.e.a.AnnotationMBeanExporter : Unregistering JMX-exposed beans on shutdown
  13:14:32.769 [ts-auth-service] [otel.javaagent 2024-12-10 13:14:32:767 +0000] [main] INFO io.opentelemetry.javaagent.tooling.VersionLogger - opentelemetry-javaagent - version: 2.0.0
  13:14:41.800 [ts-auth-service] 2024-12-10 13:14:41.800 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default  (×2)
  13:14:56.368 [ts-auth-service]  . ____ _ __ _ _ /\\ / ___'_ __ _ _(_)_ __ __ _ \ \ \ \
  13:14:56.801 [ts-auth-service] 2024-12-10 13:14:56.801 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  13:14:58.859 [ts-order-service] java.lang.IllegalArgumentException: Invalid UUID string: at java.util.UUID.fromString(UUID.java:194) ~[na:1.8.0_402] at order.service.OrderServiceImpl.queryOrde

## p0402
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:30.687Z
```
{"timestamp":1732247190687400700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Order: {\"customer\":\"http://user/customers/673ffe80b0df5c00019b315a\",\"address\":\"http://user/addresses/673ffe88b0df5c00019b3170\",\"card\":\"http://user/cards/673ffe88b0df5c00019b3171\",\"items\":\"http://carts/carts/673ffe80b0df5c00019b315a/items\"}"}
```
Same service, the 2 minutes before (oldest first):
  03:46:30.568 [front-end] GET Request to: http://user/customers/673ffe89b0df5c00019b3175/addresses  (×6)
  03:46:30.576 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff  (×2)
  03:46:30.576 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe8eb0df5c00019b3182\",\"_links\":{\"  (×2)
  03:46:30.576 [front-end] [ undefined, undefined ]  (×2)
  03:46:30.576 [front-end] Posting Order: {"customer":"http://user/customers/673ffe89b0df5c00019b3175","address":"http://user/addresses/673ffe8eb0df5c00019b3181","card":"http://user/cards
  03:46:30.630 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732247190628,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:46:30.630 [front-end] Order response: {"timestamp":1732247190628,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:46:30.632 [front-end] POST /orders 500 - ms - -
  03:46:30.670 [front-end] Request received with body: {}  (×2)
  03:46:30.678 [front-end] Received response: "{\"firstName\":\"jwQwxgI\",\"lastName\":\"jwQwxgI\",\"username\":\"jwQwxgI\",\"id\":\"673ffe80b0df5c00019b315a\",\"_links\":{\"addresses\":{
  03:46:30.678 [front-end] Received response: "{\"firstName\":\"cpDbZwGKrTpoxql\",\"lastName\":\"cpDbZwGKrTpoxql\",\"username\":\"cpDbZwGKrTpoxql\",\"id\":\"673ffe7eb0df5c00019b3152\",\"_
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×28)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×49)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×61)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×48)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×49)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×49)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×49)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×49)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h
  03:46:57.285 [carts] 2024-11-22 03:46:57.285 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr
  03:46:57.791 [user] ts=2024-11-22T03:46:57.791031339Z caller=middlewares.go:46 method=Register username=kHKtAIS email=kHKtAIS@gmail.com took=1.166895ms

## p0652
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-11T02:48:00.504Z
```
{"service":"mobservice1","message":"2021-08-11 02:48:00,504 | INFO | 0.0.0.1 | 172.17.0.5 | mobservice1 | e2dd69870c4644da | request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '7c47470c-fa0b-11eb-b68e-0242ac110004', 'value': 'lizwZLCr'}"}
```
Same service, the 2 minutes before (oldest first):
  02:47:54.626 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '78c9e008-fa0b-11eb-a706-0242ac110004', 'value': 'maWzwvqu'}  (×4)
  02:47:54.670 [mobservice1] INFO info 78c9e008-fa0b-11eb-a706-0242ac110004:maWzwvqu write success
  02:47:54.880 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  02:47:54.881 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  02:47:54.881 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '78f8a064-fa0b-11eb-82dc-0242ac110004'}  (×4)
  02:47:55.033 [mobservice1] INFO info 78f8a064-fa0b-11eb-82dc-0242ac110004:iDcvUpmS write success
  02:47:55.770 [mobservice1] INFO info 797ba8a6-fa0b-11eb-9594-0242ac110003:bTcUudlx write success
  02:47:58.197 [mobservice1] INFO info 7ae0163c-fa0b-11eb-8da0-0242ac110004:qHGVUSPX write success
All services, 30 seconds either side (sampled):
  02:47:30.569 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  02:47:30.873 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  02:47:31.001 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×44)
  02:47:31.089 [logservice1] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': '6aa3ef64-fa0b-11eb-8afd-0242ac110004', 'user_id': 'TMBcRIPk'}  (×86)
  02:47:31.407 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '6b23955c-fa0b-11eb-8929-0242ac110003', 'value': '', 'ex': 10}  (×42)
  02:47:31.971 [redisservice2] INFO redis读取信息成功, status_code: 200  (×47)
  02:47:32.509 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  02:47:34.071 [mobservice2] INFO info 6c89380c-fa0b-11eb-acdd-0242ac110004:vpXbgtCB write success
  02:47:34.921 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×42)
  02:47:36.778 [dbservice2] INFO 6de83bee-fa0b-11eb-b234-0242ac110004-bHrMSWsj--%0VNhY.LywK token generate success token=MTYyODYyMTI1Ni43Nzc2MDM5OjZkZTgzYmVlLWZhMGItMTFlYi1iMjM0LTAyNDJhYzE
  02:47:45.237 [mobservice2] INFO info 73336c2c-fa0b-11eb-b7c7-0242ac110003:yODGvlBa write success
  02:47:47.781 [mobservice1] INFO info 74ab360c-fa0b-11eb-a7f2-0242ac110004:eVrbptqN write success
  02:47:50.101 [mobservice1] INFO info 76175b56-fa0b-11eb-b2d1-0242ac110003:gKUmCyre write success
  02:47:52.689 [mobservice2] INFO info 779bf978-fa0b-11eb-a003-0242ac110004:LMIQcrtC write success
  02:47:55.033 [mobservice1] INFO info 78f8a064-fa0b-11eb-82dc-0242ac110004:iDcvUpmS write success
  02:47:57.870 [dbservice2] INFO 7a79cfa8-fa0b-11eb-b63d-0242ac110003-IToaCVWE-}<7sLbog{2vF token generate success token=MTYyODYyMTI3Ny44Njk1Njg2OjdhNzljZmE4LWZhMGItMTFlYi1iNjNkLTAyNDJhYzE
  02:48:00.548 [mobservice1] INFO info 7c47470c-fa0b-11eb-b68e-0242ac110004:lizwZLCr write success
  02:48:03.079 [mobservice2] INFO info 7dd1f554-fa0b-11eb-8580-0242ac110004:igXqQZLm write success
  02:48:05.542 [dbservice1] INFO 7f1caf80-fa0b-11eb-8c5b-0242ac110003-mFYdOIbz-A}O9cl-$UaIV token generate success token=MTYyODYyMTI4NS41NDIzMTUyOjdmMWNhZjgwLWZhMGItMTFlYi04YzViLTAyNDJhYzE
  02:48:07.941 [dbservice2] INFO 8086b14a-fa0b-11eb-b246-0242ac110004-SqZIftDu-2viZseq}_$Ql token generate success token=MTYyODYyMTI4Ny45NDEzNzE6ODA4NmIxNGEtZmEwYi0xMWViLWIyNDYtMDI0MmFjMTE
  02:48:10.177 [dbservice2] INFO 81e103ba-fa0b-11eb-8972-0242ac110004-WstfjpFZ-YcH?Ldv+PQIR token generate success token=MTYyODYyMTI5MC4xNzY0NzMxOjgxZTEwM2JhLWZhMGItMTFlYi04OTcyLTAyNDJhYzE
  02:48:12.694 [dbservice1] INFO 834ce66a-fa0b-11eb-9408-0242ac110003-tdfCvYKb-C%R*^@5Y-oWi token generate success token=MTYyODYyMTI5Mi42OTQxNTY6ODM0Y2U2NmEtZmEwYi0xMWViLTk0MDgtMDI0MmFjMTE
  02:48:15.069 [dbservice2] INFO 84bd1eb6-fa0b-11eb-9a46-0242ac110004-YWGLHvVN-tA-ye_C9<g): token generate success token=MTYyODYyMTI5NS4wNjkwMDg2Ojg0YmQxZWI2LWZhMGItMTFlYi05YTQ2LTAyNDJhYzE
  02:48:17.476 [dbservice2] INFO 8630ccca-fa0b-11eb-9e8d-0242ac110004-IAqgbwQB-^lEzKvT%j{F_ token generate success token=MTYyODYyMTI5Ny40NzU1Nzo4NjMwY2NjYS1mYTBiLTExZWItOWU4ZC0wMjQyYWMxMTA
  02:48:20.041 [mobservice2] INFO info 87edc8f6-fa0b-11eb-b570-0242ac110004:mAIhCgaZ write success
  02:48:22.765 [mobservice1] INFO info 89892d2c-fa0b-11eb-a86a-0242ac110004:YaLWCkue write success
  02:48:25.640 [mobservice1] INFO info 8b43430a-fa0b-11eb-9cbf-0242ac110003:pUwNWoxq write success
  02:48:28.456 [mobservice1] INFO info 8ceeaf6e-fa0b-11eb-864d-0242ac110003:yeMqQbFt write success

## p0557
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-other-service, 2024-12-07T18:26:02.789Z
```
{"timestamp":1733595962789991200,"container_name":"ts-order-other-service","pod_name":"ts-order-other-service-746fccc88f-4lb46","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 18:26:02.789  INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl      : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0"}
```
Same service, the 2 minutes before (oldest first):
  18:25:22.378 [ts-order-other-service] 2024-12-07 18:25:22.377 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×3)
  18:25:40.096 [ts-order-other-service] 2024-12-07 18:25:40.095 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×3)
  18:25:40.098 [ts-order-other-service] 2024-12-07 18:25:40.098 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 23  (×3)
  18:25:40.192 [ts-order-other-service] 2024-12-07 18:25:40.191 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×8)
  18:25:51.512 [ts-order-other-service] 2024-12-07 18:25:51.511 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×2)
  18:25:51.515 [ts-order-other-service] 2024-12-07 18:25:51.514 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0
All services, 30 seconds either side (sampled):
  18:25:32.796 [ts-travel2-service] 2024-12-07 18:25:32.796 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：9fc9c261-3263-4bfa-82f8-bb4  (×17)
  18:25:33.586 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:25:33 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×32)
  18:25:36.093 [ts-admin-travel-service] 2024-12-07 18:25:36.092 INFO 1 --- [io-16114-exec-8] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×14)
  18:25:36.150 [ts-travel-service] 2024-12-07 18:25:36.149 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×15)
  18:25:39.756 [ts-auth-service] 2024-12-07 18:25:39.756 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  18:25:40.036 [ts-basic-service] 2024-12-07 18:25:40.036 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×11)
  18:25:40.075 [ts-price-service] 2024-12-07 18:25:40.074 INFO 1 --- [io-16579-exec-1] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×9)
  18:25:40.098 [ts-order-other-service] 2024-12-07 18:25:40.098 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 23  (×5)
  18:25:40.185 [ts-travel2-service] 2024-12-07 18:25:40.185 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×13)
  18:25:40.222 [ts-seat-service] 2024-12-07 18:25:40.221 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  18:25:40.333 [ts-seat-service] 2024-12-07 18:25:40.333 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×10)
  18:25:42.160 [ts-order-other-mongo] {"t":{"$date":"2024-12-07T18:25:42.160+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359594
  18:25:44.508 [ts-travel-service] 2024-12-07 18:25:44.508 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  18:25:51.474 [ts-basic-service] 2024-12-07 18:25:51.474 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×5)
  18:25:53.386 [ts-price-service] 2024-12-07 18:25:53.386 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef
  18:25:55.702 [ts-basic-service] 2024-12-07 18:25:55.702 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×4)
  18:25:55.825 [ts-basic-service] 2024-12-07 18:25:55.825 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou  (×2)
  18:25:55.890 [ts-travel-service] 2024-12-07 18:25:55.890 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×6)
  18:25:56.516 [ts-travel-service] 2024-12-07 18:25:56.516 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×4)
  18:25:58.429 [ts-travel-service] 2024-12-07 18:25:58.429 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  18:26:01.297 [ts-basic-service] 2024-12-07 18:26:01.297 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  18:26:17.662 [ts-order-service] 2024-12-07 18:26:17.662 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-4cf1-
  18:26:17.832 [ts-consign-service] 2024-12-07 18:26:17.832 INFO 1 --- [io-16111-exec-9] consign.service.ConsignServiceImpl : Order ID is :a09fed17-e9e5-4f3c-b0f5-8ce2912a534c  (×2)
  18:26:22.740 [ts-order-other-service] 2024-12-07 18:26:22.740 INFO 1 --- [io-12032-exec-4] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou
  18:26:27.449 [ts-price-mongo] {"t":{"$date":"2024-12-07T18:26:27.449+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359598
  18:26:29.845 [ts-station-mongo] {"t":{"$date":"2024-12-07T18:26:29.845+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359598
  18:26:30.740 [ts-user-mongo] {"t":{"$date":"2024-12-07T18:26:30.739+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359599

## p0124
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:18:26.909Z
```
{"service":"frontend","operation":"hipstershop.CheckoutService/PlaceOrder","method":"PlaceOrder","status_code":13,"duration_us":54188,"trace_id":"b52573f8a8599bd5184ec1ec9530d37f","message":"span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13"}
```
Same service, the 2 minutes before (oldest first):
  05:18:26.718 [frontend] request started  (×5)
  05:18:26.718 [frontend] setting currency
  05:18:26.718 [frontend] request complete  (×5)
  05:18:26.721 [frontend] home
  05:18:26.769 [frontend] ENV_PLATFORM is: aws
  05:18:26.769 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14  (×2)
  05:18:26.770 [frontend] failed to retrieve ads  (×2)
  05:18:26.793 [frontend] serving product page
  05:18:26.826 [frontend] adding to cart
  05:18:26.839 [frontend] view user cart
All services, 30 seconds either side (sampled):
  05:17:58.058 [frontend] request started  (×292)
  05:17:58.067 [cartservice] GetCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×246)
  05:17:58.087 [frontend] failed to retrieve ads  (×177)
  05:17:58.090 [frontend] adding to cart  (×27)
  05:17:58.127 [shippingservice] [GetQuote] received request  (×68)
  05:17:58.812 [frontend] ENV_PLATFORM is: aws  (×34)
  05:18:02.258 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="TRY"  (×3)
  05:18:02.287 [checkoutservice] payment went through (transaction_id: f6b68b4a-60c3-43ba-a064-a6b85fb7ff1c)  (×7)
  05:18:02.293 [cartservice] EmptyCartAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4  (×7)
  05:18:02.299 [frontend] order placed  (×7)
  05:18:18.646 [adservice] AdService starting.  (×2)
  05:18:18.741 [adservice] Tracing enabled - Stackdriver exporter initialized.  (×2)
  05:18:20.440 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  05:18:22.550 [paymentservice] Transaction processed: visa ending 1783 Amount: GBP1521.300176901
  05:18:25.894 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '0PUK6V6EV0', '6E92ZMYYFZ', '1YMWWN1N4O']  (×6)
  05:18:25.981 [paymentservice] Transaction processed: visa ending 9193 Amount: JPY106183.826626688  (×3)
  05:18:26.910 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13  (×2)
  05:18:26.960 [paymentservice] }
  05:18:32.581 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"1094","nanos":975674484},"credit_card":{"credit_card_number":"4461575195133
  05:18:32.595 [checkoutservice] order confirmation email sent to "tashawolf@example.org"
  05:18:45.410 [emailservice] A request to send order confirmation email to fknox@example.org has been received.
  05:18:49.071 [checkoutservice] order confirmation email sent to "kathy75@example.com"

## p0709
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-14T01:55:24.503Z
```
{"service":"webservice2","message":"2021-08-14 01:55:24,503 | INFO | 0.0.0.3 | 172.17.0.4 | webservice2 | e994d2258deb086f | uuid: a2926a3a-fc5f-11eb-835b-0242ac110004 write redis successfully"}
```
Same service, the 2 minutes before (oldest first):
  01:55:20.811 [webservice2] INFO complete information: {'uuid': 'a04d33e0-fc5f-11eb-ad96-0242ac110004', 'user_id': 'xaMjzAUQ'}  (×3)
  01:55:20.823 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×3)
  01:55:20.824 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  01:55:22.957 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  01:55:22.958 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  01:55:22.958 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'a1ad5b70-fc5f-11eb-b7b6-0242ac110004', 'value': '', 'ex': 10}  (×3)
  01:55:23.016 [webservice2] INFO uuid: a1ad5b70-fc5f-11eb-b7b6-0242ac110004 write redis successfully  (×2)
All services, 30 seconds either side (sampled):
  01:54:54.521 [redisservice1] INFO redis write success  (×92)
  01:54:54.609 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×54)
  01:54:54.729 [mobservice2] INFO info 90a89b96-fc5f-11eb-8f04-0242ac110003:gFNpOQjC write success
  01:54:54.909 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×54)
  01:54:55.066 [dbservice1] INFO query = select passwards from username_table where user_name='gFNpOQjC'  (×47)
  01:54:55.545 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×42)
  01:54:56.231 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '91a63562-fc5f-11eb-928d-0242ac110004'}  (×42)
  01:54:56.485 [logservice2] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×41)
  01:54:57.861 [mobservice2] INFO info 9289d786-fc5f-11eb-993c-0242ac110004:OLdMPCWp write success  (×2)
  01:55:00.429 [dbservice2] INFO 93e4a6ce-fc5f-11eb-ae2e-0242ac110004-Egncqoka-7hZP8@jvo*H} token generate success token=MTYyODg3NzMwMC40Mjg5MDc5OjkzZTRhNmNlLWZjNWYtMTFlYi1hZTJlLTAyNDJhYzE
  01:55:02.976 [dbservice1] INFO 955096d0-fc5f-11eb-bfa6-0242ac110003-ZQXfBztT-3J}/s50kecn{ token generate success token=MTYyODg3NzMwMi45NzY1Njk3Ojk1NTA5NmQwLWZjNWYtMTFlYi1iZmE2LTAyNDJhYzE
  01:55:05.638 [dbservice2] INFO 96f45774-fc5f-11eb-a2e4-0242ac110004-LtXTsDKV-%Zv&u()YBC-S token generate success token=MTYyODg3NzMwNS42Mzc4ODk2Ojk2ZjQ1Nzc0LWZjNWYtMTFlYi1hMmU0LTAyNDJhYzE
  01:55:08.765 [mobservice2] INFO info 99053146-fc5f-11eb-b962-0242ac110004:TebkoQLO write success
  01:55:10.837 [dbservice2] INFO 9a07eb88-fc5f-11eb-b237-0242ac110003-lkNrGYTL-S$afkB0(o_gn token generate success token=MTYyODg3NzMxMC44MzY3NTI3OjlhMDdlYjg4LWZjNWYtMTFlYi1iMjM3LTAyNDJhYzE
  01:55:13.357 [dbservice2] INFO 9b909af4-fc5f-11eb-8b25-0242ac110003-cqyYsFCP-{u08+Rf3e)mW token generate success token=MTYyODg3NzMxMy4zNTczNzY2OjliOTA5YWY0LWZjNWYtMTFlYi04YjI1LTAyNDJhYzE
  01:55:16.633 [dbservice2] INFO 9d7e1468-fc5f-11eb-873f-0242ac110003-YWGLHvVN-tA-ye_C9<g): token generate success token=MTYyODg3NzMxNi42MzI2NjgzOjlkN2UxNDY4LWZjNWYtMTFlYi04NzNmLTAyNDJhYzE
  01:55:19.369 [mobservice2] INFO info 9f58e088-fc5f-11eb-9991-0242ac110003:VUzqydWL write success
  01:55:21.942 [dbservice1] INFO a0b62620-fc5f-11eb-970b-0242ac110003-GZqDYHLc--PqE2macry.D token generate success token=MTYyODg3NzMyMS45NDE5ODk6YTBiNjI2MjAtZmM1Zi0xMWViLTk3MGItMDI0MmFjMTE
  01:55:24.280 [dbservice1] INFO a212d2a2-fc5f-11eb-97a7-0242ac110003-hPlvogHR-K>5beft3ioYy token generate success token=MTYyODg3NzMyNC4yODA0MjphMjEyZDJhMi1mYzVmLTExZWItOTdhNy0wMjQyYWMxMTA
  01:55:26.977 [mobservice1] INFO info a3e320f0-fc5f-11eb-a7b1-0242ac110003:WuXJGtdQ write success
  01:55:29.667 [dbservice2] INFO a5455f44-fc5f-11eb-9ab4-0242ac110004-DrMCTOXU-F$jze2^tHY/U token generate success token=MTYyODg3NzMyOS42NjczMzg2OmE1NDU1ZjQ0LWZjNWYtMTFlYi05YWI0LTAyNDJhYzE
  01:55:32.544 [dbservice2] INFO a6e8c228-fc5f-11eb-8c00-0242ac110003-qwpdAUNi-j-s(4p$@1:Fo token generate success token=MTYyODg3NzMzMi41NDQyNTk1OmE2ZThjMjI4LWZjNWYtMTFlYi04YzAwLTAyNDJhYzE
  01:55:35.073 [mobservice2] INFO info a8b14e86-fc5f-11eb-81c8-0242ac110003:DkpCcNIV write success
  01:55:37.863 [mobservice1] INFO info aa6332d0-fc5f-11eb-b018-0242ac110004:ArxCmQcb write success
  01:55:40.996 [dbservice2] INFO ac003192-fc5f-11eb-9b37-0242ac110003-glaSXZGO-iB:Guv&kX(1a token generate success token=MTYyODg3NzM0MC45OTYzNjI6YWMwMDMxOTItZmM1Zi0xMWViLTliMzctMDI0MmFjMTE
  01:55:43.509 [mobservice2] INFO info adbd5bea-fc5f-11eb-9f5d-0242ac110003:OiYedVug write success
  01:55:45.995 [mobservice2] INFO info af44e7f8-fc5f-11eb-9bf4-0242ac110004:ToeLCkHR write success
  01:55:48.523 [mobservice2] INFO info b0c02dd6-fc5f-11eb-a835-0242ac110004:bGtJCiAM write success
  01:55:51.181 [mobservice2] INFO info b24c445a-fc5f-11eb-b635-0242ac110003:jhHLeyoN write success
  01:55:54.112 [dbservice2] INFO b3daf546-fc5f-11eb-a142-0242ac110004-pYNZrqyR-3KgMrh!TWn59 token generate success token=MTYyODg3NzM1NC4xMTE1MTYyOmIzZGFmNTQ2LWZjNWYtMTFlYi1hMTQyLTAyNDJhYzE
