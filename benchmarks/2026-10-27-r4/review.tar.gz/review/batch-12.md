## p0078
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T12:49:22.504Z
```
{"service":"dbservice2","message":"2021-08-13 12:49:22,504 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | 7c0bb94e4bb05be4 | d370de5c-fbf1-11eb-9103-0242ac110003-aJKPGOlh-2>-vt=SWy$ca token generate success token=MTYyODgzMDE2Mi41MDQwODk2OmQzNzBkZTVjLWZiZjEtMTFlYi05MTAzLTAyNDJhYzExMDAwM2FKS1BHT2xoMj4tdnQ9U1d5JGNhOjE2Mjg4MzAyMjIuNTA0MTAyNTowZDEzMzc4OTRkOTJhODliNDEzZmQ0ZTMyZWY2MTlhOQ=="}
```
Same service, the 2 minutes before (oldest first):
  12:49:14.792 [dbservice2] INFO ced39394-fbf1-11eb-9184-0242ac110003-iBxJIdNQ-&20pUS%?J1T. token generate success token=MTYyODgzMDE1NC43OTIwODAyOmNlZDM5Mzk0LWZiZjEtMTFlYi05MTg0LTAyNDJhYzE
  12:49:17.128 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  12:49:17.128 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  12:49:17.164 [dbservice2] INFO query = select passwards from username_table where user_name='sEtBNqcf'  (×5)
  12:49:17.242 [dbservice2] INFO d045c602-fbf1-11eb-9a60-0242ac110003-sEtBNqcf-k>E%?6gr8{U0 token generate success token=MTYyODgzMDE1Ny4yNDI0NjI0OmQwNDVjNjAyLWZiZjEtMTFlYi05YTYwLTAyNDJhYzE
  12:49:18.015 [dbservice2] INFO d0c4d488-fbf1-11eb-8b6e-0242ac110003-ODxjMiJU-a8j<f^QX)sES token generate success token=MTYyODgzMDE1OC4wMTQ1NTI0OmQwYzRkNDg4LWZiZjEtMTFlYi04YjZlLTAyNDJhYzE
  12:49:18.802 [dbservice2] INFO d13fb068-fbf1-11eb-a48e-0242ac110004-tlangOdN-d){x0D^}g!am token generate success token=MTYyODgzMDE1OC44MDE5OTg2OmQxM2ZiMDY4LWZiZjEtMTFlYi1hNDhlLTAyNDJhYzE
  12:49:21.180 [dbservice2] INFO d2a473a8-fbf1-11eb-a413-0242ac110003-dFRVcSCY-l=sf9C-mUi?> token generate success token=MTYyODgzMDE2MS4xNzk1OTE6ZDJhNDczYTgtZmJmMS0xMWViLWE0MTMtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  12:48:53.311 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  12:48:53.485 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×36)
  12:48:53.726 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×33)
  12:48:53.831 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×32)
  12:48:53.999 [dbservice1] INFO c274c776-fbf1-11eb-8c89-0242ac110004-WHeAwPqY-:4l35ScB>fT1 token generate success token=MTYyODgzMDEzMy45OTg2MTQ1OmMyNzRjNzc2LWZiZjEtMTFlYi04Yzg5LTAyNDJhYzE
  12:48:54.412 [logservice2] ERROR uuid expired, invalid phone request
  12:48:55.178 [redisservice1] INFO service accept, status_code: 200  (×37)
  12:48:55.546 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×42)
  12:48:55.867 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×46)
  12:48:56.599 [mobservice2] INFO info c42c5570-fbf1-11eb-81b4-0242ac110003:TZitjmpu write success
  12:48:58.810 [dbservice1] INFO c54c0162-fbf1-11eb-ae90-0242ac110003-NOPyEIST-YJuqr/b^Sfa% token generate success token=MTYyODgzMDEzOC44MDk3NjQ5OmM1NGMwMTYyLWZiZjEtMTFlYi1hZTkwLTAyNDJhYzE
  12:49:00.663 [dbservice1] INFO c66550b2-fbf1-11eb-8a35-0242ac110003-LcHJSWVC-F0&dSO2HbJD> token generate success token=MTYyODgzMDE0MC42NjI5MjgzOmM2NjU1MGIyLWZiZjEtMTFlYi04YTM1LTAyNDJhYzE
  12:49:03.046 [mobservice1] INFO info c810496c-fbf1-11eb-b166-0242ac110004:mgvTPLKy write success
  12:49:05.430 [dbservice1] INFO c94d1788-fbf1-11eb-b070-0242ac110003-KvxBQDHV-N^C_Y{W4r5#y token generate success token=MTYyODgzMDE0NS40MzA0MzM4OmM5NGQxNzg4LWZiZjEtMTFlYi1iMDcwLTAyNDJhYzE
  12:49:07.932 [mobservice1] INFO info caf07a26-fbf1-11eb-90ca-0242ac110004:cNyGSbzR write success
  12:49:10.258 [dbservice2] INFO cc17a500-fbf1-11eb-be41-0242ac110004-AIKNYSvf-Ju*+9{fYn>Ti token generate success token=MTYyODgzMDE1MC4yNTgxMzE1OmNjMTdhNTAwLWZiZjEtMTFlYi1iZTQxLTAyNDJhYzE
  12:49:12.683 [mobservice2] INFO info cdc9606e-fbf1-11eb-84b1-0242ac110003:FNabDRjg write success
  12:49:14.792 [dbservice2] INFO ced39394-fbf1-11eb-9184-0242ac110003-iBxJIdNQ-&20pUS%?J1T. token generate success token=MTYyODgzMDE1NC43OTIwODAyOmNlZDM5Mzk0LWZiZjEtMTFlYi05MTg0LTAyNDJhYzE
  12:49:16.935 [dbservice1] INFO d0195c20-fbf1-11eb-aeca-0242ac110003-fjEOpuqm-<9>^jfG#2%K@ token generate success token=MTYyODgzMDE1Ni45MzUyNjpkMDE5NWMyMC1mYmYxLTExZWItYWVjYS0wMjQyYWMxMTA
  12:49:19.395 [mobservice1] INFO info d1ceba7e-fbf1-11eb-9c67-0242ac110004:yZPEbHDA write success
  12:49:22.013 [dbservice1] INFO d31f3354-fbf1-11eb-a155-0242ac110004-CSoBqsmk-EAWSvDB%uQV+ token generate success token=MTYyODgzMDE2Mi4wMTI2ODA1OmQzMWYzMzU0LWZiZjEtMTFlYi1hMTU1LTAyNDJhYzE
  12:49:30.863 [dbservice1] INFO d86ac800-fbf1-11eb-ac5a-0242ac110003-bGtJCiAM-5{+Aa/EZ2QN( token generate success token=MTYyODgzMDE3MC44NjI4MDE6ZDg2YWM4MDAtZmJmMS0xMWViLWFjNWEtMDI0MmFjMTE
  12:49:33.632 [dbservice2] INFO d9e9b81c-fbf1-11eb-8408-0242ac110004-GINPAEez-)MwYz!h_S{v> token generate success token=MTYyODgzMDE3My42MzIwOTIyOmQ5ZTliODFjLWZiZjEtMTFlYi04NDA4LTAyNDJhYzE
  12:49:36.217 [mobservice2] INFO info dbcf4a98-fbf1-11eb-89c5-0242ac110004:OxCTRwMa write success
  12:49:38.597 [dbservice2] INFO dd0af916-fbf1-11eb-aabb-0242ac110003-YKwDOXcq-^yVRxMeUlsTA token generate success token=MTYyODgzMDE3OC41OTczNDE4OmRkMGFmOTE2LWZiZjEtMTFlYi1hYWJiLTAyNDJhYzE
  12:49:41.043 [dbservice2] INFO de87e394-fbf1-11eb-9216-0242ac110004-dQvowFzG-=2gZ&G>mSN_{ token generate success token=MTYyODgzMDE4MS4wNDI2MzpkZTg3ZTM5NC1mYmYxLTExZWItOTIxNi0wMjQyYWMxMTA
  12:49:43.464 [dbservice2] INFO dfee570e-fbf1-11eb-ad2e-0242ac110003-yWbZXEez-z1$5aONp@E#j token generate success token=MTYyODgzMDE4My40NjM2OTIyOmRmZWU1NzBlLWZiZjEtMTFlYi1hZDJlLTAyNDJhYzE
  12:49:45.829 [mobservice1] INFO info e1906296-fbf1-11eb-8900-0242ac110003:isocSGgr write success
  12:49:48.269 [dbservice2] INFO e2c32270-fbf1-11eb-9553-0242ac110003-COxkLyBN-!+trM_O$J5qZ token generate success token=MTYyODgzMDE4OC4yNjkzMTE3OmUyYzMyMjcwLWZiZjEtMTFlYi05NTUzLTAyNDJhYzE
  12:49:50.695 [mobservice1] INFO info e4752a50-fbf1-11eb-88d7-0242ac110003:zWnEcpYU write success

## p0292
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:38:13.641Z
```
{"timestamp":1732243093641348900,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Sent cookies."}
```
Same service, the 2 minutes before (oldest first):
  02:38:13.076 [front-end] Attempting to delete cart for user: 673fee8fb0df5c00019b0093
  02:38:13.147 [front-end] User cart deleted with status: 202
  02:38:13.150 [front-end] DELETE /cart 202 - ms - -
  02:38:13.156 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  02:38:13.164 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  02:38:13.164 [front-end] POST to carts: http://carts/carts/673fee8fb0df5c00019b0093/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  02:38:13.440 [front-end] POST /cart 201 - ms - -
  02:38:13.492 [front-end] Posting Customer: {"username":"uEVEcke","password":"DvYWLuB","email":"uEVEcke@gmail.com","firstName":"uEVEcke","lastName":"uEVEcke"}
  02:38:13.499 [front-end] { id: '673fee95b0df5c00019b00a0' }  (×2)
  02:38:13.499 [front-end] 673fee95b0df5c00019b00a0  (×2)
  02:38:13.499 [front-end] Merging carts for customer id: 673fee95b0df5c00019b00a0 and session id: IoDihJVsEau1tU8csX2lNmj90bgxoULw  (×2)
  02:38:13.499 [front-end] Posting Customer: {"username":"VFRChrldGSLfDvo","password":"fEqmYhZnTv","email":"VFRChrldGSLfDvo@gmail.com","firstName":"VFRChrldGSLfDvo","lastName":"VFRChrldGS
  02:38:13.640 [front-end] Carts merged.  (×2)
  02:38:13.640 [front-end] set cookie673fee95b0df5c00019b00a1  (×2)
  02:38:13.640 [front-end] Sent cookies.
All services, 30 seconds either side (sampled):
  02:37:43.657 [front-end] Request received with body: {}  (×56)
  02:37:43.689 [payment] ts=2024-11-22T02:37:43Z caller=logging.go:29 method=Authorise result=true took=844ns  (×38)
  02:37:43.798 [front-end] Received response: "{\"firstName\":\"sKrMgmUrvDGNRi\",\"lastName\":\"sKrMgmUrvDGNRi\",\"username\":\"sKrMgmUrvDGNRi\",\"id\":\"673fee65b0df5c00019b001c\",\"_lin
  02:37:43.884 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fee6db0df5c00019b0033"}  (×62)
  02:37:43.963 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:37:44.283 [carts] 2024-11-22 02:37:44.283 INFO [carts,42c993ce93b32f3d,659e7e73013f3367,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.CartsController : Merge carts reques  (×29)
  02:37:44.462 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee78d94b9000069b3be4","customerId":"673fee62b0df5c00019b000f","customer":{"id":null,"firstName":"uolOOJVTHHQ
  02:37:46.858 [front-end] Posting Customer: {"username":"aERlPcwCIQtcOHc","password":"hJANs","email":"aERlPcwCIQtcOHc@gmail.com","firstName":"aERlPcwCIQtcOHc","lastName":"aERlPcwCIQtcOHc
  02:37:49.868 [front-end] Posting Customer: {"username":"mYcewEF","password":"jiOGcR","email":"mYcewEF@gmail.com","firstName":"mYcewEF","lastName":"mYcewEF"}
  02:37:51.991 [user] ts=2024-11-22T02:37:51.991704256Z caller=middlewares.go:46 method=Register username=KZogxmyI email=KZogxmyI@gmail.com took=981.08µs
  02:37:53.216 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee81d94b9000069b3beb","customerId":"673fee6db0df5c00019b0035","customer":{"id":null,"firstName":"hbShnaBduJJ
  02:37:55.847 [front-end] Order response: {"id":"673fee83d94b9000069b3bee","customerId":"673fee73b0df5c00019b0042","customer":{"id":null,"firstName":"dRtRtCrsx","lastName":"dRtRtCrsx","u
  02:37:59.928 [front-end] Posting Customer: {"username":"NdCRwdn","password":"DJTqdnRniD","email":"NdCRwdn@gmail.com","firstName":"NdCRwdn","lastName":"NdCRwdn"}
  02:38:02.302 [front-end] Posting Customer: {"username":"DMOBSBfiqgXj","password":"RCAUznmSM","email":"DMOBSBfiqgXj@gmail.com","firstName":"DMOBSBfiqgXj","lastName":"DMOBSBfiqgXj"}
  02:38:06.071 [front-end] Order response: {"id":"673fee8ed94b9000069b3bf2","customerId":"673fee75b0df5c00019b004c","customer":{"id":null,"firstName":"senehdf","lastName":"senehdf","usern
  02:38:07.536 [queue-master] 2024-11-22 02:38:07.536 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×27)
  02:38:09.084 [front-end] Order response: {"id":"673fee91d94b9000069b3bf6","customerId":"673fee7db0df5c00019b005f","customer":{"id":null,"firstName":"mYcewEF","lastName":"mYcewEF","usern
  02:38:12.259 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee94d94b9000069b3bf9","customerId":"673fee7eb0df5c00019b0063","customer":{"id":null,"firstName":"FxUbRFKJBRT
  02:38:13.863 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee95d94b9000069b3bfb","customerId":"673fee85b0df5c00019b0074","customer":{"id":null,"firstName":"khpix","las
  02:38:17.358 [front-end] Received response: "{\"firstName\":\"rOaLBcPXehwx\",\"lastName\":\"rOaLBcPXehwx\",\"username\":\"rOaLBcPXehwx\",\"id\":\"673fee80b0df5c00019b0065\",\"_links\":{
  02:38:19.568 [front-end] Received response: "{\"firstName\":\"XCYdmAXSWd\",\"lastName\":\"XCYdmAXSWd\",\"username\":\"XCYdmAXSWd\",\"id\":\"673fee86b0df5c00019b007a\",\"_links\":{\"addr
  02:38:21.705 [front-end] Order response: {"id":"673fee9dd94b9000069b3c03","customerId":"673fee8ab0df5c00019b007f","customer":{"id":null,"firstName":"DMOBSBfiqgXj","lastName":"DMOBSBfiqg
  02:38:25.771 [user] ts=2024-11-22T02:38:25.771426852Z caller=middlewares.go:46 method=Register username=HTrxgSQ email=HTrxgSQ@gmail.com took=1.052909ms
  02:38:28.114 [front-end] Order response: {"statusCode":201,"body":{"id":"673feea4d94b9000069b3c08","customerId":"673fee8eb0df5c00019b0090","customer":{"id":null,"firstName":"UhAse","las
  02:38:29.340 [user] ts=2024-11-22T02:38:29.340669481Z caller=middlewares.go:46 method=Register username=MJGBC email=MJGBC@gmail.com took=1.034739ms
  02:38:31.091 [front-end] Posting Customer: {"username":"NobBxH","password":"mQEcDCM","email":"NobBxH@gmail.com","firstName":"NobBxH","lastName":"NobBxH"}
  02:38:31.660 [front-end] Order response: {"statusCode":201,"body":{"id":"673feea7d94b9000069b3c0c","customerId":"673fee90b0df5c00019b0095","customer":{"id":null,"firstName":"bMyeICjUYoa
  02:38:34.352 [catalogue] ts=2024-11-22T02:38:34Z caller=logging.go:85 method=Health result=2 took=356µs
  02:38:38.757 [front-end] Order response: {"statusCode":201,"body":{"id":"673feeaed94b9000069b3c11","customerId":"673fee96b0df5c00019b00a4","customer":{"id":null,"firstName":"BefZqFmzQJq
  02:38:42.442 [front-end] Order response: {"id":"673feeb2d94b9000069b3c14","customerId":"673fee9bb0df5c00019b00b5","customer":{"id":null,"firstName":"flzgqYzlrTwM","lastName":"flzgqYzlrT

## p0533
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T11:03:56.438Z
```
{"timestamp":1732359836438775600,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 11:03:56.438  INFO [carts,84f2ee6e86affc00,2aedf37ace384622,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.CartsController   : Merge carts request received for ids: 6741b69ca437380001df54e4 and csTQSA54oUdwqMZTuA_ITo-GaSXWaMN4"}
```
Same service, the 2 minutes before (oldest first):
  11:03:47.302 [carts] 2024-11-23 11:03:47.301 INFO [carts,5a0a5bec5562a998,10d7f3b5bd52a0a9,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×6)
  11:03:48.058 [carts] 2024-11-23 11:03:48.058 INFO [carts,0e2f905582406748,4840e505d9e8df9a,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.CartsController : Merge carts reques  (×8)
  11:03:53.496 [carts] 2024-11-23 11:03:53.496 INFO [carts,f3ce51e969a9d6c8,ec6a77284d5e1390,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  11:03:53.506 [carts] 2024-11-23 11:03:53.505 INFO [carts,f3ce51e969a9d6c8,ec6a77284d5e1390,false] 7 --- [-nio-80-exec-11] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
  11:03:56.382 [carts] 2024-11-23 11:03:56.381 INFO [carts,8ec7ce6c89d752ee,d87e8f54055f3ce3,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.ItemsController : Did not find item.
  11:03:56.390 [carts] 2024-11-23 11:03:56.390 INFO [carts,8ec7ce6c89d752ee,d87e8f54055f3ce3,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.cart.CartContentsResource : Adding for user: Car
All services, 30 seconds either side (sampled):
  11:03:26.537 [orders-db] {"t":{"$date":"2024-11-23T11:03:26.537+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235980
  11:03:41.708 [catalogue] ts=2024-11-23T11:03:41Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.12473ms  (×50)
  11:03:47.295 [front-end] 6741b693a437380001df54d0  (×33)
  11:03:47.339 [front-end] Sent cookies.  (×33)
  11:03:50.572 [front-end] Posting Customer: {"username":"qwoiARVJhRxKAZN","password":"cwTMuwAbg","email":"qwoiARVJhRxKAZN@gmail.com","firstName":"qwoiARVJhRxKAZN","lastName":"qwoiARVJhRx
  11:03:53.077 [front-end] Posting Customer: {"username":"ohiMyJ","password":"bmaZgtZm","email":"ohiMyJ@gmail.com","firstName":"ohiMyJ","lastName":"ohiMyJ"}
  11:03:53.362 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"6741b693a437380001df54d0"}  (×21)
  11:03:53.447 [front-end] DELETE /cart 202 - ms - -  (×21)
  11:03:53.496 [carts] 2024-11-23 11:03:53.496 INFO [carts,f3ce51e969a9d6c8,ec6a77284d5e1390,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.ItemsController : Did not find item.  (×8)
  11:03:54.327 [front-end] Posting Customer: {"username":"sXlEVDL","password":"HMbHlgZjP","email":"sXlEVDL@gmail.com","firstName":"sXlEVDL","lastName":"sXlEVDL"}
  11:03:56.206 [front-end] Posting Customer: {"username":"UMZAvxnYnpHGoU","password":"FfrIJE","email":"UMZAvxnYnpHGoU@gmail.com","firstName":"UMZAvxnYnpHGoU","lastName":"UMZAvxnYnpHGoU"}
  11:03:56.408 [user] ts=2024-11-23T11:03:56.408623936Z caller=middlewares.go:46 method=Register username=VtLPAety email=VtLPAety@gmail.com took=2.781795ms
  11:03:56.868 [user] ts=2024-11-23T11:03:56.867597828Z caller=middlewares.go:46 method=Register username=CMODvGO email=CMODvGO@gmail.com took=2.155529ms
  11:03:58.730 [front-end] Posting Customer: {"username":"Wdnxlb","password":"HbtJN","email":"Wdnxlb@gmail.com","firstName":"Wdnxlb","lastName":"Wdnxlb"}
  11:04:00.026 [front-end] Posting Customer: {"username":"bngJcYekpI","password":"jEXnteqw","email":"bngJcYekpI@gmail.com","firstName":"bngJcYekpI","lastName":"bngJcYekpI"}
  11:04:01.293 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×2)
  11:04:03.673 [front-end] Posting Customer: {"username":"QGRnrhxD","password":"VKqMgLfGa","email":"QGRnrhxD@gmail.com","firstName":"QGRnrhxD","lastName":"QGRnrhxD"}
  11:04:05.187 [front-end] Posting Customer: {"username":"SAXswjgxYrKFP","password":"sVkQhMWY","email":"SAXswjgxYrKFP@gmail.com","firstName":"SAXswjgxYrKFP","lastName":"SAXswjgxYrKFP"}
  11:04:06.554 [front-end] Posting Customer: {"username":"ggSSBkW","password":"wnXQTHsltI","email":"ggSSBkW@gmail.com","firstName":"ggSSBkW","lastName":"ggSSBkW"}
  11:04:06.563 [front-end] Posting Order: {"customer":"http://user/customers/6741b693a437380001df54d0","address":"http://user/addresses/6741b699a437380001df54d7","card":"http://user/cards
  11:04:06.594 [orders] 2024-11-23 11:04:06.594 INFO [orders,d2547e3c0edc56de,209e569ea052410f,false] 7 --- [p-nio-80-exec-7] w.w.s.o.controllers.OrdersController : Received payment re
  11:04:06.607 [queue-master] 2024-11-23 11:04:06.607 INFO 7 --- [ool-6-thread-25] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×3)
  11:04:06.612 [front-end] TypeError [ERR_INVALID_ARG_TYPE]: The "chunk" argument must be of type string or an instance of Buffer or Uint8Array. Received undefined at new NodeError (node:
  11:04:06.644 [front-end] npm notice New major version of npm available! 8.19.4 -> 10.9.1
  11:04:06.645 [front-end] npm verb code 1

## p0724
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-14T18:55:01.478Z
```
{"service":"mobservice2","message":"2021-08-14 18:55:01,478 | ERROR | 0.0.0.4 | mobservice2 | mob_helper.py -> mob_info_to_redis -> 88 | dda3e99453b5141d | uuid:0c2f2fb2-fcee-11eb-abfc-0242ac110004 information has expired, mobile phone login is invalid"}
```
Same service, the 2 minutes before (oldest first):
  18:54:49.175 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '0b61761c-fcee-11eb-9d8d-0242ac110004', 'value': 'GYmWSxyu'}  (×4)
  18:54:49.217 [mobservice2] INFO info 0b61761c-fcee-11eb-9d8d-0242ac110004:GYmWSxyu write success
  18:54:49.664 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  18:54:49.665 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  18:54:49.665 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '0bbe5d50-fcee-11eb-88ca-0242ac110003'}  (×4)
  18:54:49.749 [mobservice2] INFO info 0bbe5d50-fcee-11eb-88ca-0242ac110003:uGrcWJOt write success
  18:54:51.986 [mobservice2] INFO info 0d0e0f70-fcee-11eb-ac2e-0242ac110003:lykPtSEm write success
  18:54:54.693 [mobservice2] INFO info 0eb04c1c-fcee-11eb-a853-0242ac110003:gKPfDFAT write success
All services, 30 seconds either side (sampled):
  18:54:31.485 [webservice1] INFO complete information: {'uuid': '00ec90c2-fcee-11eb-b4b9-0242ac110003', 'user_id': 'laVNGIPf'}  (×37)
  18:54:31.606 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×37)
  18:54:31.738 [redisservice2] INFO redis write success  (×78)
  18:54:31.848 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×33)
  18:54:31.941 [logservice1] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': '00f645f4-fcee-11eb-8a78-0242ac110004', 'user_id': 'ycKvOJwP'}  (×79)
  18:54:32.001 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×46)
  18:54:32.280 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '01836e2a-fcee-11eb-85ab-0242ac110004', 'value': '', 'ex': 10}  (×42)
  18:54:32.967 [redisservice2] INFO service accept, status_code: 200  (×37)
  18:54:34.546 [mobservice1] INFO info 02924ae8-fcee-11eb-9934-0242ac110004:FuZbUPph write success
  18:54:35.143 [webservice1] INFO uuid: 03317d02-fcee-11eb-868e-0242ac110003 write redis successfully  (×37)
  18:54:37.259 [dbservice1] INFO 040df70a-fcee-11eb-ba20-0242ac110004-tVZirvSy-RdOP!c4y.62_ token generate success token=MTYyODkzODQ3Ny4yNTk1NTIyOjA0MGRmNzBhLWZjZWUtMTFlYi1iYTIwLTAyNDJhYzE
  18:54:39.664 [dbservice1] INFO 057e6836-fcee-11eb-b6d2-0242ac110003-laVNGIPf-{Z8wE?(U^nzJ token generate success token=MTYyODkzODQ3OS42NjQyODQyOjA1N2U2ODM2LWZjZWUtMTFlYi1iNmQyLTAyNDJhYzE
  18:54:41.926 [mobservice2] INFO info 0706759a-fcee-11eb-b225-0242ac110004:fxyAUSmc write success
  18:54:44.012 [dbservice2] INFO 081b7b10-fcee-11eb-bd6b-0242ac110003-acGlMCEq-XtWM=.lec?n8 token generate success token=MTYyODkzODQ4NC4wMTI0NjMzOjA4MWI3YjEwLWZjZWUtMTFlYi1iZDZiLTAyNDJhYzE
  18:54:46.694 [dbservice2] INFO 0996e416-fcee-11eb-8b8c-0242ac110004-BWZgetyT-GQa#@36(hzOy token generate success token=MTYyODkzODQ4Ni42OTI2NDMyOjA5OTZlNDE2LWZjZWUtMTFlYi04YjhjLTAyNDJhYzE
  18:54:49.217 [mobservice2] INFO info 0b61761c-fcee-11eb-9d8d-0242ac110004:GYmWSxyu write success
  18:54:54.693 [mobservice2] INFO info 0eb04c1c-fcee-11eb-a853-0242ac110003:gKPfDFAT write success
  18:55:01.552 [logservice2] ERROR uuid expired, invalid phone request
  18:55:03.196 [dbservice2] INFO 1386abf0-fcee-11eb-8266-0242ac110003-IMzHpvSY-bhtqgr.x2AfF token generate success token=MTYyODkzODUwMy4xOTU1OTQ6MTM4NmFiZjAtZmNlZS0xMWViLTgyNjYtMDI0MmFjMTE
  18:55:05.584 [dbservice1] INFO 14f0dbd2-fcee-11eb-8de0-0242ac110004-ocYXAMHN-9(D$TR<G6AB# token generate success token=MTYyODkzODUwNS41ODM5MDA3OjE0ZjBkYmQyLWZjZWUtMTFlYi04ZGUwLTAyNDJhYzE
  18:55:07.773 [mobservice1] INFO info 1671606c-fcee-11eb-847a-0242ac110004:eyfiDUCK write success
  18:55:09.735 [dbservice2] INFO 176e0754-fcee-11eb-82ea-0242ac110003-hfWmCetl-sU3(RxISVqF_ token generate success token=MTYyODkzODUwOS43MzQ1MDExOjE3NmUwNzU0LWZjZWUtMTFlYi04MmVhLTAyNDJhYzE
  18:55:12.041 [dbservice2] INFO 18c1891e-fcee-11eb-917c-0242ac110004-YXLKvufE-RlNLZm@n6u!V token generate success token=MTYyODkzODUxMi4wNDA0Njg6MThjMTg5MWUtZmNlZS0xMWViLTkxN2MtMDI0MmFjMTE
  18:55:14.983 [dbservice1] INFO 1a7f144c-fcee-11eb-b430-0242ac110003-ToeLCkHR-(_n2MJ%R.Uw0 token generate success token=MTYyODkzODUxNC45ODMyMTEzOjFhN2YxNDRjLWZjZWUtMTFlYi1iNDMwLTAyNDJhYzE
  18:55:17.433 [mobservice1] INFO info 1c35e072-fcee-11eb-982d-0242ac110004:NChObWPp write success
  18:55:19.882 [mobservice2] INFO info 1da58e30-fcee-11eb-a0cd-0242ac110004:geuyhpUk write success
  18:55:22.388 [mobservice1] INFO info 1f2b6a5e-fcee-11eb-afd9-0242ac110003:nlMAOLaH write success
  18:55:24.290 [dbservice2] INFO 202696d6-fcee-11eb-ba33-0242ac110003-rNfgkPxE-ZI78qlV2ts)U token generate success token=MTYyODkzODUyNC4yODk3OTQ6MjAyNjk2ZDYtZmNlZS0xMWViLWJhMzMtMDI0MmFjMTE
  18:55:27.557 [dbservice1] INFO 22074f0e-fcee-11eb-988e-0242ac110004-gwdEDvWp-lda>CXq^!9O3 token generate success token=MTYyODkzODUyNy41NTY2ODEyOjIyMDc0ZjBlLWZjZWUtMTFlYi05ODhlLTAyNDJhYzE
  18:55:30.844 [mobservice1] INFO info 24335566-fcee-11eb-a801-0242ac110004:rtRkpsfM write success

## p0567
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-07T18:30:40.502Z
```
{"timestamp":1733596240502994700,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-srqkn","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 18:30:40.502  INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl  : startingPlaceId : shanghaiendPlaceId : nanjing"}
```
Same service, the 2 minutes before (oldest first):
  18:30:37.811 [ts-basic-service] 2024-12-07 18:30:37.811 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×5)
  18:30:37.816 [ts-basic-service] 2024-12-07 18:30:37.815 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai
  18:30:37.816 [ts-basic-service] 2024-12-07 18:30:37.815 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3
  18:30:37.816 [ts-basic-service] 2024-12-07 18:30:37.816 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4
  18:30:37.831 [ts-basic-service] 2024-12-07 18:30:37.831 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×5)
  18:30:40.463 [ts-basic-service] 2024-12-07 18:30:40.462 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
  18:30:40.468 [ts-basic-service] 2024-12-07 18:30:40.468 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  18:30:40.472 [ts-basic-service] 2024-12-07 18:30:40.472 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa
  18:30:40.481 [ts-basic-service] 2024-12-07 18:30:40.481 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87
  18:30:40.486 [ts-basic-service] 2024-12-07 18:30:40.486 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  18:30:40.487 [ts-basic-service] 2024-12-07 18:30:40.487 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23
  18:30:40.493 [ts-basic-service] 2024-12-07 18:30:40.493 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
All services, 30 seconds either side (sampled):
  18:30:10.784 [ts-auth-service] 2024-12-07 18:30:10.782 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  18:30:10.992 [ts-route-service] 2024-12-07 18:30:10.992 INFO 1 --- [io-11178-exec-1] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×183)
  18:30:11.069 [ts-admin-travel-service] 2024-12-07 18:30:11.069 INFO 1 --- [io-16114-exec-5] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)
  18:30:11.224 [ts-basic-service] 2024-12-07 18:30:11.223 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×81)
  18:30:11.284 [ts-basic-service] 2024-12-07 18:30:11.284 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×26)
  18:30:11.379 [ts-seat-service] 2024-12-07 18:30:11.378 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×47)
  18:30:11.423 [ts-seat-service] 2024-12-07 18:30:11.423 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×24)
  18:30:11.514 [ts-seat-service] 2024-12-07 18:30:11.514 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×4)
  18:30:13.164 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:30:13 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×23)
  18:30:14.724 [ts-basic-service] 2024-12-07 18:30:14.724 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : startingPlaceId : suzhouendPlaceId : shanghai  (×14)
  18:30:14.802 [ts-order-service] 2024-12-07 18:30:14.801 INFO 1 --- [io-12031-exec-2] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×17)
  18:30:14.985 [ts-price-service] 2024-12-07 18:30:14.985 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×3)
  18:30:15.874 [ts-auth-service] 2024-12-07 18:30:15.874 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : stopped _org.springframework.integration.errorLogger
  18:30:17.150 [ts-seat-service] 2024-12-07 18:30:17.150 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×2)
  18:30:20.543 [ts-food-service] 2024-12-07 18:30:20.543 INFO 1 --- [io-18856-exec-9] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×2)
  18:30:20.962 [ts-seat-service] 2024-12-07 18:30:20.962 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×16)
  18:30:27.484 [ts-price-mongo] {"t":{"$date":"2024-12-07T18:30:27.483+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359622
  18:30:29.883 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T18:30:29.882+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359622
  18:30:30.940 [ts-order-mongo] {"t":{"$date":"2024-12-07T18:30:30.940+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359623
  18:30:40.449 [ts-travel2-service] 2024-12-07 18:30:40.449 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×12)
  18:30:40.700 [ts-travel2-service] 2024-12-07 18:30:40.700 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×4)
  18:30:42.154 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T18:30:42.154+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359624
  18:30:46.661 [ts-auth-service] 2024-12-07 18:30:46.661 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  18:30:47.287 [ts-travel-service] 2024-12-07 18:30:47.287 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha
  18:30:51.661 [ts-auth-service] 2024-12-07 18:30:51.661 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-auth-mongo:27017 to client view of cluster
  18:31:00.392 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:00 +0800] "POST /api/v1/orderOtherService/orderOther/refresh HTTP/1.1" 500 220 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_1  (×2)
  18:31:01.656 [ts-auth-service] 2024-12-07 18:31:01.655 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  18:31:03.868 [ts-auth-service] 2024-12-07 18:31:03.868 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/vnd.spring-boot.
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.872 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/vnd.spring-
  18:31:07.057 [ts-auth-service] 2024-12-07 18:31:07.057 INFO 1 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 'taskScheduler'

## p0170
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:33:16.354Z
```
{"timestamp":1731911596354211300,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  06:33:15.264 [frontend] request complete  (×6)
  06:33:15.918 [frontend] request started  (×7)
  06:33:15.918 [frontend] serving product page  (×4)
  06:33:15.955 [frontend] adding to cart
  06:33:15.966 [frontend] view user cart  (×2)
All services, 30 seconds either side (sampled):
  06:32:47.241 [frontend] request started  (×347)
  06:32:47.250 [cartservice] GetCartAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0  (×285)
  06:32:47.273 [adservice] received ad request (context_words=[clothing, tops])  (×15)
  06:32:47.283 [cartservice] AddItemAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0, productId=66VCHSJNUP, quantity=6  (×45)
  06:32:47.319 [shippingservice] [GetQuote] received request  (×91)
  06:32:48.044 [adservice] received ad request (context_words=[kitchen])  (×62)
  06:32:49.797 [adservice] received ad request (context_words=[])  (×34)
  06:32:51.289 [adservice] received ad request (context_words=[footwear])  (×10)
  06:32:56.254 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="JPY"  (×3)
  06:32:56.285 [checkoutservice] payment went through (transaction_id: 062468e3-dd40-4ff5-ad21-eecc9014971f)  (×14)
  06:32:56.289 [cartservice] EmptyCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121  (×14)
  06:32:56.299 [frontend] order placed  (×14)
  06:32:59.573 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="CAD"  (×4)
  06:32:59.657 [emailservice] A request to send order confirmation email to ehughes@example.net has been received.
  06:33:00.886 [checkoutservice] order confirmation email sent to "robertsstephen@example.com"
  06:33:07.969 [checkoutservice] [PlaceOrder] user_id="acc735c5-72d0-48e6-b237-46a63eac4c4d" user_currency="GBP"  (×5)
  06:33:08.017 [emailservice] A request to send order confirmation email to troy44@example.com has been received.
  06:33:11.465 [checkoutservice] order confirmation email sent to "robertslaura@example.net"
  06:33:16.444 [emailservice] A request to send order confirmation email to kellycollins@example.net has been received.
  06:33:18.252 [checkoutservice] order confirmation email sent to "danielleduke@example.com"
  06:33:25.782 [emailservice] A request to send order confirmation email to xgray@example.com has been received.
  06:33:35.138 [checkoutservice] [PlaceOrder] user_id="b63bea0e-d05f-4589-be71-8fef43557432" user_currency="USD"
  06:33:35.218 [emailservice] A request to send order confirmation email to bryananna@example.net has been received.
  06:33:42.954 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"1091","nanos":410880145},"credit_card":{"credit_card_number":"4915884106565
  06:33:42.968 [checkoutservice] order confirmation email sent to "beth47@example.com"

## p0645
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-service, 2024-12-07T20:29:25.503Z
```
{"timestamp":1733603365503914200,"container_name":"ts-order-service","pod_name":"ts-order-service-7596478c9d-sql8t","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:29:25.503  INFO 1 --- [io-12031-exec-7] order.service.OrderServiceImpl           : Left ticket info is empty"}
```
Same service, the 2 minutes before (oldest first):
  20:29:11.664 [ts-order-service] 2024-12-07 20:29:11.663 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×4)
  20:29:11.710 [ts-order-service] 2024-12-07 20:29:11.710 INFO 1 --- [io-12031-exec-6] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×6)
  20:29:11.714 [ts-order-service] 2024-12-07 20:29:11.713 INFO 1 --- [io-12031-exec-6] order.service.OrderServiceImpl : Left ticket info is empty  (×5)
  20:29:24.989 [ts-order-service] 2024-12-07 20:29:24.989 INFO 1 --- [io-12031-exec-9] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×3)
  20:29:25.118 [ts-order-service] 2024-12-07 20:29:25.118 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024
  20:29:25.122 [ts-order-service] 2024-12-07 20:29:25.121 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is empty
All services, 30 seconds either side (sampled):
  20:28:55.549 [ts-admin-basic-info-service] 2024-12-07 20:28:55.549 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  20:28:56.094 [ts-travel-service] 2024-12-07 20:28:56.092 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×24)
  20:28:56.124 [ts-basic-service] 2024-12-07 20:28:56.124 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：92708982-77  (×3)
  20:28:56.147 [ts-basic-service] 2024-12-07 20:28:56.147 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : startingPlaceId : suzhouendPlaceId : shanghai  (×13)
  20:28:56.186 [ts-travel-service] 2024-12-07 20:28:56.186 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr  (×20)
  20:28:56.210 [ts-seat-service] 2024-12-07 20:28:56.210 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×15)
  20:28:56.323 [ts-travel-service] 2024-12-07 20:28:56.323 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×15)
  20:28:56.381 [ts-order-service] 2024-12-07 20:28:56.380 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×2)
  20:28:56.444 [ts-seat-service] 2024-12-07 20:28:56.444 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  20:28:56.788 [ts-travel-service] 2024-12-07 20:28:56.788 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×19)
  20:28:57.627 [ts-travel-service] 2024-12-07 20:28:57.627 INFO 1 --- [io-12346-exec-1] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×5)
  20:29:04.280 [ts-travel2-service] 2024-12-07 20:29:04.280 INFO 1 --- [io-16346-exec-7] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×10)
  20:29:04.349 [ts-basic-service] 2024-12-07 20:29:04.349 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×2)
  20:29:04.374 [ts-basic-service] 2024-12-07 20:29:04.374 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3  (×2)
  20:29:04.421 [ts-seat-service] 2024-12-07 20:29:04.421 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×18)
  20:29:04.502 [ts-travel2-service] 2024-12-07 20:29:04.502 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236
  20:29:05.696 [ts-auth-service] 2024-12-07 20:29:05.696 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×12)
  20:29:08.633 [ts-auth-service] 2024-12-07 20:29:08.633 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×9)
  20:29:08.968 [ts-order-other-service] 2024-12-07 20:29:08.967 INFO 1 --- [io-12032-exec-9] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=594119  (×6)
  20:29:12.066 [ts-admin-basic-info-service] 2024-12-07 20:29:12.065 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×2)
  20:29:21.713 [ts-travel-service] 2024-12-07 20:29:21.712 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×2)
  20:29:22.646 [ts-basic-service] 2024-12-07 20:29:22.646 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×4)
  20:29:28.519 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-07T20:29:28.519+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360336
  20:29:31.339 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T20:29:31.338+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360337
  20:29:31.927 [ts-user-mongo] {"t":{"$date":"2024-12-07T20:29:31.927+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360337
  20:29:40.086 [ts-basic-service] 2024-12-07 20:29:40.085 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69
  20:29:42.948 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T20:29:42.948+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360338

## p0133
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:25:49.082Z
```
{"timestamp":1731907549082745900,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  05:25:48.899 [frontend] failed to retrieve ads  (×2)
  05:25:48.899 [frontend] request complete  (×6)
  05:25:48.902 [frontend] request started  (×5)
  05:25:48.902 [frontend] adding to cart
  05:25:48.917 [frontend] view user cart
  05:25:48.967 [frontend] placing order
  05:25:48.969 [frontend] serving product page
  05:25:48.998 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14
  05:25:49.013 [frontend] order placed
  05:25:49.079 [frontend] setting currency
All services, 30 seconds either side (sampled):
  05:25:19.248 [frontend] request started  (×313)
  05:25:19.257 [cartservice] GetCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×253)
  05:25:19.278 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14  (×186)
  05:25:21.025 [frontend] adding to cart  (×33)
  05:25:21.066 [shippingservice] [GetQuote] received request  (×67)
  05:25:25.039 [frontend] home  (×40)
  05:25:32.555 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', '6E92ZMYYFZ', '2ZYFJ3GM2N']  (×5)
  05:25:46.716 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="EUR"  (×4)
  05:25:46.752 [checkoutservice] payment went through (transaction_id: 0794a115-bc7c-4925-bcc1-ac98b35ab5c3)  (×9)
  05:25:46.756 [cartservice] EmptyCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×9)
  05:25:46.765 [frontend] order placed  (×9)
  05:25:48.997 [paymentservice] Transaction processed: visa ending 4832 Amount: CAD877.691633787  (×3)
  05:25:53.413 [emailservice] A request to send order confirmation email to ashley15@example.org has been received.
  05:25:55.268 [emailservice] A request to send order confirmation email to sweeneybonnie@example.org has been received.
  05:25:56.038 [redis] 1:M 18 Nov 2024 05:25:56.038 * Background saving started by pid 51
  05:25:56.139 [redis] 1:M 18 Nov 2024 05:25:56.139 * Background saving terminated with success
  05:26:11.888 [emailservice] A request to send order confirmation email to fjordan@example.org has been received.
  05:26:14.061 [emailservice] A request to send order confirmation email to wardpenny@example.org has been received.
  05:26:14.077 [paymentservice] Transaction processed: visa ending 6694 Amount: TRY1256.200078756
  05:26:16.520 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="JPY"
  05:26:16.567 [emailservice] A request to send order confirmation email to davisjoseph@example.org has been received.

## p0588
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:54.573Z
```
{"timestamp":1733596314573376800,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:54.572  INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl       : nullUSER TOKEN"}
```
Same service, the 2 minutes before (oldest first):
  18:31:45.387 [ts-auth-service] 2024-12-07 18:31:45.386 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×4)
  18:31:45.387 [ts-auth-service] 2024-12-07 18:31:45.387 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×4)
  18:31:45.547 [ts-auth-service] 2024-12-07 18:31:45.547 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×3)
  18:31:45.547 [ts-auth-service] 2024-12-07 18:31:45.547 INFO 1 --- [io-12340-exec-8] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×3)
  18:31:49.989 [ts-auth-service] 2024-12-07 18:31:49.989 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null
  18:31:49.989 [ts-auth-service] 2024-12-07 18:31:49.989 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:31:50.181 [ts-auth-service] 2024-12-07 18:31:50.180 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  18:31:50.181 [ts-auth-service] 2024-12-07 18:31:50.181 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID
  18:31:50.319 [ts-auth-service] 2024-12-07 18:31:50.319 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null
  18:31:50.319 [ts-auth-service] 2024-12-07 18:31:50.319 INFO 1 --- [io-12340-exec-1] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
All services, 30 seconds either side (sampled):
  18:31:25.229 [ts-auth-service] 2024-12-07 18:31:25.228 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×12)
  18:31:25.386 [ts-auth-service] 2024-12-07 18:31:25.386 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×23)
  18:31:25.410 [ts-travel2-service] 2024-12-07 18:31:25.409 ERROR 1 --- [io-16346-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×13)
  18:31:27.257 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:31:27.257+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:27.492 [ts-price-mongo] {"t":{"$date":"2024-12-07T18:31:27.492+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.040 [ts-auth-service] 2024-12-07 18:31:28.039 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×11)
  18:31:28.270 [ts-admin-travel-service] 2024-12-07 18:31:28.269 ERROR 1 --- [io-16114-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×10)
  18:31:29.428 [ts-assurance-service] 2024-12-07 18:31:29.428 ERROR 1 --- [io-18888-exec-7] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×3)
  18:31:29.447 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:29 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 500 236 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)  (×3)
  18:31:29.783 [ts-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×3)
  18:31:29.867 [ts-food-mongo] {"t":{"$date":"2024-12-07T18:31:29.867+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:29.897 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T18:31:29.896+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:30.519 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T18:31:30.518+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:30.725 [ts-notification-mongo] {"t":{"$date":"2024-12-07T18:31:30.725+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:31.064 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×3)
  18:31:31.701 [ts-order-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  18:31:32.290 [ts-admin-basic-info-service] 2024-12-07 18:31:32.289 ERROR 1 --- [io-18767-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×20)
  18:31:37.418 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:37 +0800] "GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×11)
  18:31:42.026 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T18:31:42.026+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359630
  18:31:42.218 [ts-order-other-mongo] {"t":{"$date":"2024-12-07T18:31:42.218+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359630
  18:31:44.203 [ts-admin-basic-info-service] 2024-12-07 18:31:44.202 ERROR 1 --- [o-18767-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×3)
  18:31:50.485 [ts-order-other-service] 2024-12-07 18:31:50.485 ERROR 1 --- [io-12032-exec-9] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:31:50.489 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:50 +0800] "POST /api/v1/orderOtherService/orderOther/refresh HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_1
  18:31:51.505 [ts-food-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×3)
  18:32:08.507 [ts-auth-service] 2024-12-07 18:32:08.507 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin

## p0383
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:14.501Z
```
{"timestamp":1732247174501666000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"{ id: '673ffe86b0df5c00019b3168' }"}
```
Same service, the 2 minutes before (oldest first):
  03:46:12.638 [front-end] Posting Order: {"customer":"http://user/customers/673ffe70b0df5c00019b312c","address":"http://user/addresses/673ffe79b0df5c00019b3144","card":"http://user/cards
  03:46:12.672 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732247172669,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×2)
  03:46:12.672 [front-end] Order response: {"timestamp":1732247172669,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×2)
  03:46:12.676 [front-end] POST /orders 500 - ms - -  (×2)
  03:46:13.391 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffe7eb0df5c00019b3152"}
  03:46:13.399 [front-end] POST /addresses 200 - ms - -
  03:46:13.405 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffe7eb0df5c00019b3152"}
  03:46:13.413 [front-end] POST /cards 200 - ms - -
  03:46:13.461 [front-end] Attempting to delete cart for user: 673ffe7eb0df5c00019b3152
  03:46:13.525 [front-end] User cart deleted with status: 503
  03:46:13.527 [front-end] DELETE /cart 503 - ms - -
  03:46:13.534 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  03:46:13.542 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  03:46:13.542 [front-end] POST to carts: http://carts/carts/673ffe7eb0df5c00019b3152/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  03:46:13.621 [front-end] POST /cart 500 83.162 ms - 64
  03:46:14.038 [front-end] GET /catalogue 200 - ms - -
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×19)
  03:46:10.147 [front-end] { id: '673ffe82b0df5c00019b315b' }  (×32)
  03:46:10.189 [front-end] Sent cookies.  (×33)
  03:46:10.811 [front-end] Received response: "{\"firstName\":\"iRQgndFKRWzZ\",\"lastName\":\"iRQgndFKRWzZ\",\"username\":\"iRQgndFKRWzZ\",\"id\":\"673ffe72b0df5c00019b3133\",\"_links\":{
  03:46:10.818 [front-end] [ undefined, undefined ]  (×34)
  03:46:10.848 [orders] 2024-11-22 03:46:10.848 ERROR [orders,,,] 6 --- [-nio-80-exec-12] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×15)
  03:46:10.940 [front-end] Received response: "{\"firstName\":\"jnTZDLVwW\",\"lastName\":\"jnTZDLVwW\",\"username\":\"jnTZDLVwW\",\"id\":\"673ffe65b0df5c00019b3100\",\"_links\":{\"address
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×36)
  03:46:11.285 [front-end] User cart deleted with status: 503  (×36)
  03:46:11.304 [front-end] POST to carts: http://carts/carts/673ffe7bb0df5c00019b3147/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}  (×22)
  03:46:11.500 [catalogue] ts=2024-11-22T03:46:11Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=3.76723m  (×5)
  03:46:12.526 [front-end] Posting Customer: {"username":"YWRstkOr","password":"kgmbhcEA","email":"YWRstkOr@gmail.com","firstName":"YWRstkOr","lastName":"YWRstkOr"}
  03:46:12.669 [orders] 2024-11-22 03:46:12.668 ERROR [orders,,,] 6 --- [p-nio-80-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×19)
  03:46:14.765 [front-end] Received response: "{\"firstName\":\"KxwXfBfUZ\",\"lastName\":\"KxwXfBfUZ\",\"username\":\"KxwXfBfUZ\",\"id\":\"673ffe6fb0df5c00019b3125\",\"_links\":{\"address
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.227 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×7)
  03:46:17.277 [user] ts=2024-11-22T03:46:17.277211334Z caller=middlewares.go:46 method=Register username=ptkQMzQKHy email=ptkQMzQKHy@gmail.com took=1.044122ms  (×7)
  03:46:20.433 [front-end] Received response: "{\"firstName\":\"DHCGNkyEyawp\",\"lastName\":\"DHCGNkyEyawp\",\"username\":\"DHCGNkyEyawp\",\"id\":\"673ffe74b0df5c00019b3136\",\"_links\":{
  03:46:22.962 [user] ts=2024-11-22T03:46:22.961891483Z caller=middlewares.go:46 method=Register username=YNeGDXzX email=YNeGDXzX@gmail.com took=1.087598ms
  03:46:25.988 [front-end] Posting Customer: {"username":"jAAETa","password":"IwsrY","email":"jAAETa@gmail.com","firstName":"jAAETa","lastName":"jAAETa"}
  03:46:26.496 [front-end] Received response: "{\"firstName\":\"gXlVL\",\"lastName\":\"gXlVL\",\"username\":\"gXlVL\",\"id\":\"673ffe80b0df5c00019b3159\",\"_links\":{\"addresses\":{\"href
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.249 [carts-db] {"t":{"$date":"2024-11-22T03:46:29.248+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224718
  03:46:30.113 [front-end] Posting Customer: {"username":"saWqTMkh","password":"METDVZTIFk","email":"saWqTMkh@gmail.com","firstName":"saWqTMkh","lastName":"saWqTMkh"}
  03:46:30.678 [front-end] Received response: "{\"firstName\":\"jwQwxgI\",\"lastName\":\"jwQwxgI\",\"username\":\"jwQwxgI\",\"id\":\"673ffe80b0df5c00019b315a\",\"_links\":{\"addresses\":{
  03:46:32.838 [front-end] Posting Customer: {"username":"ZzayWIHhxNw","password":"FoukoY","email":"ZzayWIHhxNw@gmail.com","firstName":"ZzayWIHhxNw","lastName":"ZzayWIHhxNw"}
  03:46:36.897 [front-end] Posting Customer: {"username":"gOQlBf","password":"ooDdDywNEy","email":"gOQlBf@gmail.com","firstName":"gOQlBf","lastName":"gOQlBf"}
  03:46:39.288 [front-end] Received response: "{\"firstName\":\"YNeGDXzX\",\"lastName\":\"YNeGDXzX\",\"username\":\"YNeGDXzX\",\"id\":\"673ffe8eb0df5c00019b3183\",\"_links\":{\"addresses\
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:42.361 [front-end] Received response: "{\"firstName\":\"UKKtCDfOtWIPTP\",\"lastName\":\"UKKtCDfOtWIPTP\",\"username\":\"UKKtCDfOtWIPTP\",\"id\":\"673ffe90b0df5c00019b3186\",\"_lin

## p0270
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:17.880Z
```
{"timestamp":1732242497880937700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"673fec41b0df5c00019af98c"}
```
Same service, the 2 minutes before (oldest first):
  02:28:17.022 [front-end] POST /addresses 200 - ms - -
  02:28:17.028 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec38b0df5c00019af971"}
  02:28:17.035 [front-end] POST /cards 200 - ms - -
  02:28:17.084 [front-end] Attempting to delete cart for user: 673fec38b0df5c00019af971
  02:28:17.339 [front-end] GET /catalogue 200 - ms - -  (×2)
  02:28:17.369 [front-end] Request received with body: {}
  02:28:17.377 [front-end] Received response: "{\"firstName\":\"vtFUiCYPGkr\",\"lastName\":\"vtFUiCYPGkr\",\"username\":\"vtFUiCYPGkr\",\"id\":\"673fec2bb0df5c00019af944\",\"_links\":{\"a
  02:28:17.377 [front-end] GET Request to: http://user/customers/673fec2bb0df5c00019af944/addresses  (×2)
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec33b0df5c00019af961\",\"_links\":{\"
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:17.383 [front-end] [ undefined, undefined ]
  02:28:17.383 [front-end] Posting Order: {"customer":"http://user/customers/673fec2bb0df5c00019af944","address":"http://user/addresses/673fec33b0df5c00019af960","card":"http://user/cards
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:17.558 [front-end] { id: '673fec41b0df5c00019af98b' }  (×2)
  02:28:17.558 [front-end] 673fec41b0df5c00019af98b
  02:28:17.558 [front-end] Merging carts for customer id: 673fec41b0df5c00019af98b and session id: DJgh-aP7GXWW3SFEl2AnBT8Zgj4ojU2q
  02:28:17.875 [front-end] Posting Customer: {"username":"QGHrdp","password":"lxLAJGrqCj","email":"QGHrdp@gmail.com","firstName":"QGHrdp","lastName":"QGHrdp"}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×44)
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -  (×44)
  02:28:03.203 [front-end] [ undefined, undefined ]  (×45)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×3)
  02:28:07.445 [orders] 2024-11-22 02:28:07.445 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
  02:28:10.277 [front-end] Posting Customer: {"username":"opFqwUnVow","password":"habyXFSF","email":"opFqwUnVow@gmail.com","firstName":"opFqwUnVow","lastName":"opFqwUnVow"}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
  02:28:23.301 [front-end] Received response: "{\"firstName\":\"HFHBXn\",\"lastName\":\"HFHBXn\",\"username\":\"HFHBXn\",\"id\":\"673fec34b0df5c00019af967\",\"_links\":{\"addresses\":{\"h
  02:28:24.999 [rabbitmq] 
  02:28:25.743 [carts] 2024-11-22 02:28:25.743 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×13)
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39d0","customerId":"673fec31b0df5c00019af95b","customer":{"id":null,"firstName":"bCCZHBaYc","lastName":"bCCZHBaYc","u
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×51)
  02:28:37.548 [user] ts=2024-11-22T02:28:37.548591Z caller=middlewares.go:46 method=Register username=OeZpiPZUn email=OeZpiPZUn@gmail.com took=1.009704ms
  02:28:40.321 [front-end] Order response: {"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR","lastName":"nbZCdAQyR","u
  02:28:42.162 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732242522152,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde
  02:28:44.338 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec5cd94b9000069b39e2","customerId":"673fec3ab0df5c00019af974","customer":{"id":null,"firstName":"opFqwUnVow"
  02:28:45.405 [front-end] Posting Customer: {"username":"crSMtAKNWrXaJJx","password":"TlwWXSanSW","email":"crSMtAKNWrXaJJx@gmail.com","firstName":"crSMtAKNWrXaJJx","lastName":"crSMtAKNWr
  02:28:47.575 [front-end] Received response: "{\"firstName\":\"QGHrdp\",\"lastName\":\"QGHrdp\",\"username\":\"QGHrdp\",\"id\":\"673fec41b0df5c00019af98c\",\"_links\":{\"addresses\":{\"h

## p0844
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T04:26:17.643Z
```
{"timestamp":1731903977643370800,"container_name":"adservice","pod_name":"adservice-67c9b847f4-wz6h7","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Stats enabled, but temporarily unavailable"}
```
Same service, the 2 minutes before (oldest first):
  04:26:08.247 [adservice] received ad request (context_words=[])  (×5)
  04:26:09.406 [adservice] received ad request (context_words=[decor, home])  (×2)
  04:26:09.544 [adservice] received ad request (context_words=[kitchen])  (×6)
  04:26:09.566 [adservice] received ad request (context_words=[accessories])  (×3)
  04:26:09.593 [adservice] received ad request (context_words=[clothing, tops])
  04:26:09.618 [adservice] received ad request (context_words=[hair, beauty])
  04:26:14.190 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  04:26:14.191 [adservice] *** server shut down
All services, 30 seconds either side (sampled):
  04:25:47.763 [frontend] request started  (×295)
  04:25:47.766 [frontend] home  (×36)
  04:25:47.781 [currencyservice] conversion request successful  (×717)
  04:25:48.291 [frontend] view user cart  (×71)
  04:25:48.316 [shippingservice] [GetQuote] completed request  (×83)
  04:25:48.653 [adservice] received ad request (context_words=[hair, beauty])  (×6)
  04:25:49.099 [frontend] adding to cart  (×23)
  04:25:49.164 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="TRY"  (×2)
  04:25:49.190 [checkoutservice] payment went through (transaction_id: 9f2259b1-70d3-4c82-a614-52a2c26c1bb7)  (×12)
  04:25:49.195 [cartservice] EmptyCartAsync called with userId=0ae6d9b6-4e7f-4d38-a0eb-042389dcac30  (×12)
  04:25:49.202 [frontend] order placed  (×12)
  04:25:53.896 [adservice] received ad request (context_words=[footwear])  (×4)
  04:25:58.955 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"1618","nanos":993365795},"credit_card":{"credit_card_number":"4777636584828  (×2)
  04:25:58.970 [checkoutservice] order confirmation email sent to "thomasfarmer@example.org"
  04:26:03.290 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"481","nanos":720000000},"credit_card":{"credit_card_number":"46971998707907
  04:26:03.305 [checkoutservice] order confirmation email sent to "gonzalezjessica@example.net"
  04:26:04.228 [paymentservice] Transaction processed: visa ending 4902 Amount: GBP900.148865979  (×4)
  04:26:07.877 [emailservice] A request to send order confirmation email to stephaniegregory@example.org has been received.  (×2)
  04:26:08.085 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"516","nanos":718266264},"credit_card":{"credit_card_number":"41048720965937  (×3)
  04:26:08.102 [checkoutservice] order confirmation email sent to "victor92@example.org"
  04:26:14.190 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  04:26:14.635 [frontend] failed to retrieve ads  (×96)
  04:26:17.739 [adservice] AdService starting.
  04:26:17.742 [adservice] Tracing enabled - Stackdriver exporter initialized.
  04:26:23.952 [checkoutservice] order confirmation email sent to "vegadennis@example.net"
  04:26:41.011 [emailservice] A request to send order confirmation email to vhaynes@example.org has been received.

## p0401
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:30.119Z
```
{"timestamp":1732247190119370000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"DELETE /cart 503 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  03:46:29.429 [front-end] [ undefined, undefined ]
  03:46:29.429 [front-end] Posting Order: {"customer":"http://user/customers/673ffe7db0df5c00019b314a","address":"http://user/addresses/673ffe83b0df5c00019b3160","card":"http://user/cards
  03:46:29.448 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732247189443,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:46:29.448 [front-end] Order response: {"timestamp":1732247189443,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:46:29.450 [front-end] POST /orders 500 - ms - -
  03:46:30.021 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffe8eb0df5c00019b3183"}
  03:46:30.030 [front-end] POST /addresses 200 - ms - -
  03:46:30.035 [front-end] Posting Customer: {"username":"hCQLZMhz","password":"WOsAnFIK","email":"hCQLZMhz@gmail.com","firstName":"hCQLZMhz","lastName":"hCQLZMhz"}
  03:46:30.035 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffe8eb0df5c00019b3183"}
  03:46:30.042 [front-end] { id: '673ffe96b0df5c00019b3197' }
  03:46:30.042 [front-end] 673ffe96b0df5c00019b3197
  03:46:30.042 [front-end] Merging carts for customer id: 673ffe96b0df5c00019b3197 and session id: 2ZHmuG_NvfhHugYyZRXyRtQ_1dh2_Zfi
  03:46:30.044 [front-end] POST /cards 200 - ms - -
  03:46:30.048 [front-end] Attempting to delete cart for user: 673ffe8eb0df5c00019b3183
  03:46:30.087 [front-end] Carts merged.
  03:46:30.087 [front-end] set cookie673ffe96b0df5c00019b3197
  03:46:30.087 [front-end] Sent cookies.
  03:46:30.092 [front-end] POST /register 200 52.387 ms - 33
  03:46:30.113 [front-end] Posting Customer: {"username":"saWqTMkh","password":"METDVZTIFk","email":"saWqTMkh@gmail.com","firstName":"saWqTMkh","lastName":"saWqTMkh"}
  03:46:30.113 [front-end] User cart deleted with status: 503
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×28)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×48)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×60)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×48)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×48)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×49)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×49)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×49)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h
  03:46:57.285 [carts] 2024-11-22 03:46:57.285 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr
  03:46:57.791 [user] ts=2024-11-22T03:46:57.791031339Z caller=middlewares.go:46 method=Register username=kHKtAIS email=kHKtAIS@gmail.com took=1.166895ms

## p0675
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-11T15:27:27.500Z
```
{"service":"dbservice1","message":"2021-08-11 15:27:27,500 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | fe8972459638a1ee | 94151d7c-fa75-11eb-a6f6-0242ac110003-YDlrGqAK-=_&yCx+0Rj}p token generate success token=MTYyODY2Njg0Ny41MDAwODIzOjk0MTUxZDdjLWZhNzUtMTFlYi1hNmY2LTAyNDJhYzExMDAwM1lEbHJHcUFLPV8meUN4KzBSan1wOjE2Mjg2NjY5MDcuNTAwMDkzOjk3MTcyYzBkMmFlNDk0OTRkYjZhNmJjZWFjMTQ3YjE4"}
```
Same service, the 2 minutes before (oldest first):
  15:27:20.715 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  15:27:21.417 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  15:27:21.418 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  15:27:21.475 [dbservice1] INFO query = select passwards from username_table where user_name='pQdlTEwc'  (×5)
  15:27:21.604 [dbservice1] INFO 9089777a-fa75-11eb-82e4-0242ac110003-pQdlTEwc-cW3>kro}_/6x token generate success token=MTYyODY2Njg0MS42MDQwNDU5OjkwODk3NzdhLWZhNzUtMTFlYi04MmU0LTAyNDJhYzE
  15:27:24.684 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  15:27:25.173 [dbservice1] INFO 92ad25ce-fa75-11eb-a04a-0242ac110004-qhdLCnSU-I!Hg(Dukw}{) token generate success token=MTYyODY2Njg0NS4xNzMxMzQ4OjkyYWQyNWNlLWZhNzUtMTFlYi1hMDRhLTAyNDJhYzE
  15:27:26.038 [dbservice1] INFO 932e5158-fa75-11eb-8be0-0242ac110004-DjXaKYNR-/Q*Yd=S2X37R token generate success token=MTYyODY2Njg0Ni4wMzc4Nzc2OjkzMmU1MTU4LWZhNzUtMTFlYi04YmUwLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  15:26:57.500 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  15:26:57.563 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×44)
  15:26:57.665 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  15:26:57.837 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  15:26:57.949 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×46)
  15:26:58.096 [dbservice1] INFO query = select passwards from username_table where user_name='hVyjbRgD'  (×39)
  15:26:58.261 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×42)
  15:26:58.892 [webservice2] INFO uuid: 836e0f92-fa75-11eb-ab8a-0242ac110004 write redis successfully  (×43)
  15:27:01.390 [dbservice1] INFO 846f4e2e-fa75-11eb-b1b5-0242ac110004-kWcbAndl-+K)#TtAh_eL$ token generate success token=MTYyODY2NjgyMS4zOTAzNTA4Ojg0NmY0ZTJlLWZhNzUtMTFlYi1iMWI1LTAyNDJhYzE
  15:27:04.432 [dbservice1] INFO 8647eb02-fa75-11eb-ac22-0242ac110004-dXbvhYuV-XtK?-g9HF@^i token generate success token=MTYyODY2NjgyNC40MzE1NzgyOjg2NDdlYjAyLWZhNzUtMTFlYi1hYzIyLTAyNDJhYzE
  15:27:07.117 [dbservice2] INFO 87d6b26e-fa75-11eb-b893-0242ac110004-URMboZjf-a!7vBu@Ms{3G token generate success token=MTYyODY2NjgyNy4xMTcwMDU2Ojg3ZDZiMjZlLWZhNzUtMTFlYi1iODkzLTAyNDJhYzE
  15:27:10.037 [dbservice1] INFO 89962288-fa75-11eb-afc9-0242ac110003-FWZKSkEd-d*WN%Kbw7ZHk token generate success token=MTYyODY2NjgzMC4wMzczNTE0Ojg5OTYyMjg4LWZhNzUtMTFlYi1hZmM5LTAyNDJhYzE
  15:27:12.794 [mobservice1] INFO info 8b92bde4-fa75-11eb-b051-0242ac110003:xgMQOjrh write success
  15:27:15.291 [mobservice2] INFO info 8d083b5e-fa75-11eb-8a03-0242ac110004:GTqJKEWv write success
  15:27:18.098 [dbservice1] INFO 8e67fac0-fa75-11eb-8854-0242ac110003-EfYjQxDP-^#<7YEpfJHm/ token generate success token=MTYyODY2NjgzOC4wOTg1MjE3OjhlNjdmYWMwLWZhNzUtMTFlYi04ODU0LTAyNDJhYzE
  15:27:20.715 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  15:27:23.010 [mobservice1] INFO info 919a5580-fa75-11eb-8928-0242ac110003:IMzHpvSY write success
  15:27:25.620 [mobservice1] INFO info 932e5158-fa75-11eb-8be0-0242ac110004:DjXaKYNR write success
  15:27:28.823 [dbservice2] INFO 94e3cc94-fa75-11eb-a79c-0242ac110003-EufWiDjO-#9V:p32@F*T^ token generate success token=MTYyODY2Njg0OC44MjI2MTM6OTRlM2NjOTQtZmE3NS0xMWViLWE3OWMtMDI0MmFjMTE
  15:27:31.717 [mobservice2] INFO info 96d0246c-fa75-11eb-9868-0242ac110004:weSjQDRC write success
  15:27:33.839 [dbservice2] INFO 97cd3274-fa75-11eb-a8f9-0242ac110004-qYMpFKOS-3_B8TGV!g<1j token generate success token=MTYyODY2Njg1My44MzkyNTEzOjk3Y2QzMjc0LWZhNzUtMTFlYi1hOGY5LTAyNDJhYzE
  15:27:36.574 [dbservice1] INFO 9962950c-fa75-11eb-9e65-0242ac110003-vRBrHTWY-OlDR1bUog7MV token generate success token=MTYyODY2Njg1Ni41NzM4NTo5OTYyOTUwYy1mYTc1LTExZWItOWU2NS0wMjQyYWMxMTA  (×2)
  15:27:41.354 [dbservice1] INFO 9c4afe62-fa75-11eb-8ac1-0242ac110004-PNQwkDiG-PRdj%k6t@b0J token generate success token=MTYyODY2Njg2MS4zNTQ1MDU1OjljNGFmZTYyLWZhNzUtMTFlYi04YWMxLTAyNDJhYzE
  15:27:43.922 [dbservice2] INFO 9de09d0e-fa75-11eb-88b8-0242ac110004-GrKgOByV-n@*{TE_p^JR3 token generate success token=MTYyODY2Njg2My45MjE1OTY4OjlkZTA5ZDBlLWZhNzUtMTFlYi04OGI4LTAyNDJhYzE
  15:27:46.869 [mobservice2] INFO info 9fd56360-fa75-11eb-8fc1-0242ac110004:EYeCRGvF write success
  15:27:50.296 [mobservice2] INFO info a1ea0476-fa75-11eb-8fbb-0242ac110004:aEBDmkFT write success
  15:27:52.888 [mobservice2] INFO info a3713a12-fa75-11eb-a6e4-0242ac110003:QkrTBEJI write success
  15:27:55.886 [dbservice2] INFO a5073778-fa75-11eb-b76b-0242ac110004-SDgLpeFn-kr3n*Mg_:JQ4 token generate success token=MTYyODY2Njg3NS44ODYzOTg4OmE1MDczNzc4LWZhNzUtMTFlYi1iNzZiLTAyNDJhYzE

## p0519
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:42:24.907Z
```
{"timestamp":1732358544907510300,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"{ id: '6741b190a437380001df4b9c' }"}
```
Same service, the 2 minutes before (oldest first):
  10:42:24.572 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19001dd390007094e0b","customerId":"6741b177a437380001df4b65","customer":{"id":null,"firstName":"SCxrEnxcK",
  10:42:24.572 [front-end] Order response: {"id":"6741b19001dd390007094e0b","customerId":"6741b177a437380001df4b65","customer":{"id":null,"firstName":"SCxrEnxcK","lastName":"SCxrEnxcK","u
  10:42:24.574 [front-end] POST /orders 201 - ms - -  (×2)
  10:42:24.610 [front-end] GET /catalogue 200 - ms - -
  10:42:24.787 [front-end] Request received with body: {}
  10:42:24.803 [front-end] Received response: "{\"firstName\":\"rDzQLwb\",\"lastName\":\"rDzQLwb\",\"username\":\"rDzQLwb\",\"id\":\"6741b176a437380001df4b63\",\"_links\":{\"addresses\":{
  10:42:24.803 [front-end] GET Request to: http://user/customers/6741b176a437380001df4b63/addresses  (×2)
  10:42:24.816 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b17ea437380001df4b78\",\"_links\":{\"
  10:42:24.817 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"6741b
  10:42:24.817 [front-end] [ undefined, undefined ]
  10:42:24.817 [front-end] Posting Order: {"customer":"http://user/customers/6741b176a437380001df4b63","address":"http://user/addresses/6741b17ea437380001df4b77","card":"http://user/cards
  10:42:24.865 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19001dd390007094e0c","customerId":"6741b176a437380001df4b63","customer":{"id":null,"firstName":"rDzQLwb","l
  10:42:24.866 [front-end] Order response: {"id":"6741b19001dd390007094e0c","customerId":"6741b176a437380001df4b63","customer":{"id":null,"firstName":"rDzQLwb","lastName":"rDzQLwb","usern
  10:42:24.898 [front-end] Posting Customer: {"username":"SGHrmQKj","password":"zIZBNLHf","email":"SGHrmQKj@gmail.com","firstName":"SGHrmQKj","lastName":"SGHrmQKj"}
  10:42:24.899 [front-end] Posting Customer: {"username":"juGLviwwFqYBQb","password":"zQvPzNYGzr","email":"juGLviwwFqYBQb@gmail.com","firstName":"juGLviwwFqYBQb","lastName":"juGLviwwFqYBQ
  10:42:24.906 [front-end] { id: '6741b190a437380001df4b9b' }
  10:42:24.906 [front-end] 6741b190a437380001df4b9b
  10:42:24.906 [front-end] Merging carts for customer id: 6741b190a437380001df4b9b and session id: lZi8ze0L37QmX3XWXoMvbm-9aaVTtAgD
All services, 30 seconds either side (sampled):
  10:41:54.918 [front-end] POST /cart 201 - ms - -  (×58)
  10:41:55.036 [orders] 2024-11-23 10:41:55.036 INFO [orders,47fd1dca4b84e5c1,c18ff7783bc0532a,false] 7 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Sending payment req  (×42)
  10:41:55.060 [front-end] POST /orders 201 - ms - -  (×58)
  10:41:55.348 [front-end] Received response: "{\"firstName\":\"eJdSjCrFg\",\"lastName\":\"eJdSjCrFg\",\"username\":\"eJdSjCrFg\",\"id\":\"6741b15da437380001df4b0b\",\"_links\":{\"address
  10:41:55.742 [front-end] DELETE /cart 202 - ms - -  (×57)
  10:41:56.420 [user] ts=2024-11-23T10:41:56.420652696Z caller=middlewares.go:46 method=Register username=isegvIUb email=isegvIUb@gmail.com took=2.019833ms
  10:41:57.383 [catalogue] ts=2024-11-23T10:41:57Z caller=logging.go:85 method=Health result=2 took=26.201µs  (×40)
  10:41:59.267 [front-end] Posting Customer: {"username":"SCxrEnxcK","password":"GJhpSKxG","email":"SCxrEnxcK@gmail.com","firstName":"SCxrEnxcK","lastName":"SCxrEnxcK"}
  10:42:01.504 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×8)
  10:42:03.408 [front-end] Order response: {"id":"6741b17b01dd390007094df9","customerId":"6741b16ba437380001df4b3b","customer":{"id":null,"firstName":"WzPQXTXTGIDm","lastName":"WzPQXTXTGI
  10:42:05.506 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b17d01dd390007094dfc","customerId":"6741b16ba437380001df4b3c","customer":{"id":null,"firstName":"IfOkjlIP","
  10:42:07.717 [front-end] Received response: "{\"firstName\":\"Jbcuqj\",\"lastName\":\"Jbcuqj\",\"username\":\"Jbcuqj\",\"id\":\"6741b168a437380001df4b33\",\"_links\":{\"addresses\":{\"h
  10:42:10.105 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b18201dd390007094e01","customerId":"6741b169a437380001df4b37","customer":{"id":null,"firstName":"kHyjCHYyJ",
  10:42:14.621 [front-end] Posting Customer: {"username":"OePlWpOYf","password":"FgQNXLB","email":"OePlWpOYf@gmail.com","firstName":"OePlWpOYf","lastName":"OePlWpOYf"}
  10:42:17.238 [front-end] Order response: {"id":"6741b18901dd390007094e05","customerId":"6741b176a437380001df4b64","customer":{"id":null,"firstName":"BBoDQLZVQIzI","lastName":"BBoDQLZVQI
  10:42:19.936 [front-end] Posting Customer: {"username":"SlOUiiS","password":"OpdYMEsfX","email":"SlOUiiS@gmail.com","firstName":"SlOUiiS","lastName":"SlOUiiS"}
  10:42:24.050 [front-end] Order response: {"id":"6741b19001dd390007094e0a","customerId":"6741b17ba437380001df4b72","customer":{"id":null,"firstName":"jGtfmTYFLF","lastName":"jGtfmTYFLF",
  10:42:25.944 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19101dd390007094e0d","customerId":"6741b17ba437380001df4b71","customer":{"id":null,"firstName":"FLiqlpA","l
  10:42:27.156 [front-end] Order response: {"id":"6741b19301dd390007094e0e","customerId":"6741b17da437380001df4b73","customer":{"id":null,"firstName":"KHdmtS","lastName":"KHdmtS","usernam
  10:42:29.302 [user] ts=2024-11-23T10:42:29.302868417Z caller=middlewares.go:46 method=Register username=VSfGH email=VSfGH@gmail.com took=2.505112ms
  10:42:32.549 [front-end] Order response: {"id":"6741b19801dd390007094e11","customerId":"6741b183a437380001df4b7f","customer":{"id":null,"firstName":"fMqkVIscpJAub","lastName":"fMqkVIscp
  10:42:34.927 [queue-master] 2024-11-23 10:42:34.927 INFO 7 --- [pool-6-thread-3] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×27)
  10:42:37.725 [user] ts=2024-11-23T10:42:37.725655891Z caller=middlewares.go:46 method=Register username=CUstRIbS email=CUstRIbS@gmail.com took=3.090637ms
  10:42:40.138 [front-end] Received response: "{\"firstName\":\"CydfEIYWaRvI\",\"lastName\":\"CydfEIYWaRvI\",\"username\":\"CydfEIYWaRvI\",\"id\":\"6741b186a437380001df4b88\",\"_links\":{
  10:42:42.271 [front-end] Order response: {"id":"6741b1a201dd390007094e1a","customerId":"6741b18ba437380001df4b92","customer":{"id":null,"firstName":"SlOUiiS","lastName":"SlOUiiS","usern
  10:42:45.471 [front-end] Received response: "{\"firstName\":\"DMOcLvEBWyzQX\",\"lastName\":\"DMOcLvEBWyzQX\",\"username\":\"DMOcLvEBWyzQX\",\"id\":\"6741b196a437380001df4bad\",\"_links\
  10:42:46.780 [user] ts=2024-11-23T10:42:46.780359131Z caller=middlewares.go:46 method=Register username=dkAwy email=dkAwy@gmail.com took=2.497127ms
  10:42:49.638 [user] ts=2024-11-23T10:42:49.637729551Z caller=middlewares.go:46 method=Register username=KvuZWX email=KvuZWX@gmail.com took=2.717357ms
  10:42:52.608 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b1ac01dd390007094e20","customerId":"6741b195a437380001df4baa","customer":{"id":null,"firstName":"VSfGH","las
  10:42:54.358 [front-end] Order response: {"id":"6741b1ae01dd390007094e23","customerId":"6741b193a437380001df4ba1","customer":{"id":null,"firstName":"drIpSVYoFYMY","lastName":"drIpSVYoFY

## p0126
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service checkoutservice, 2024-11-18T05:18:26.957Z
```
{"service":"checkoutservice","operation":"hipstershop.PaymentService/Charge","method":"Charge","status_code":400,"duration_us":5627,"trace_id":"b52573f8a8599bd5184ec1ec9530d37f","message":"span hipstershop.PaymentService/Charge failed with gRPC status 400"}
```
Same service, the 2 minutes before (oldest first):
  05:17:25.086 [checkoutservice] [PlaceOrder] user_id="33421b66-55b6-413b-9ba9-3230c85c58dc" user_currency="TRY"  (×3)
  05:17:25.114 [checkoutservice] payment went through (transaction_id: 58e6f1bc-db23-430b-813e-3fddd976218e)  (×6)
  05:17:25.127 [checkoutservice] order confirmation email sent to "coxchristine@example.net"
  05:17:49.561 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="CAD"
  05:17:49.603 [checkoutservice] order confirmation email sent to "vicki59@example.com"
  05:17:55.239 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="EUR"
  05:17:55.276 [checkoutservice] order confirmation email sent to "alopez@example.org"
  05:18:02.298 [checkoutservice] order confirmation email sent to "caseyhoward@example.com"
  05:18:22.485 [checkoutservice] [PlaceOrder] user_id="fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a" user_currency="GBP"
  05:18:22.564 [checkoutservice] order confirmation email sent to "janetbrown@example.org"
  05:18:25.940 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="JPY"
  05:18:25.994 [checkoutservice] order confirmation email sent to "bradycarla@example.net"
  05:18:26.910 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
All services, 30 seconds either side (sampled):
  05:17:58.058 [frontend] request started  (×292)
  05:17:58.067 [cartservice] GetCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×246)
  05:17:58.087 [frontend] failed to retrieve ads  (×178)
  05:17:58.090 [frontend] adding to cart  (×27)
  05:17:58.127 [shippingservice] [GetQuote] received request  (×68)
  05:17:58.812 [frontend] ENV_PLATFORM is: aws  (×34)
  05:18:02.258 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="TRY"  (×3)
  05:18:02.287 [checkoutservice] payment went through (transaction_id: f6b68b4a-60c3-43ba-a064-a6b85fb7ff1c)  (×7)
  05:18:02.293 [cartservice] EmptyCartAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4  (×7)
  05:18:02.299 [frontend] order placed  (×7)
  05:18:18.646 [adservice] AdService starting.  (×2)
  05:18:18.741 [adservice] Tracing enabled - Stackdriver exporter initialized.  (×2)
  05:18:20.440 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  05:18:22.550 [paymentservice] Transaction processed: visa ending 1783 Amount: GBP1521.300176901
  05:18:25.894 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '0PUK6V6EV0', '6E92ZMYYFZ', '1YMWWN1N4O']  (×6)
  05:18:25.981 [paymentservice] Transaction processed: visa ending 9193 Amount: JPY106183.826626688  (×3)
  05:18:26.910 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
  05:18:26.960 [paymentservice] }
  05:18:32.581 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"1094","nanos":975674484},"credit_card":{"credit_card_number":"4461575195133
  05:18:32.595 [checkoutservice] order confirmation email sent to "tashawolf@example.org"
  05:18:45.410 [emailservice] A request to send order confirmation email to fknox@example.org has been received.
  05:18:49.071 [checkoutservice] order confirmation email sent to "kathy75@example.com"

## p0546
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T18:19:30.751Z
```
{"timestamp":1733595570751123200,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-894nw","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:19:30.750  INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl         : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suzhou, shanghai], distances=[0, 50], startStationId='suzhou', terminalStationId='shanghai'}"}
```
Same service, the 2 minutes before (oldest first):
  18:19:29.213 [ts-travel-service] 2024-12-07 18:19:29.212 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：a3f256c1-0e43-4f7d-9c21-121bf  (×3)
  18:19:29.218 [ts-travel-service] 2024-12-07 18:19:29.218 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
  18:19:29.219 [ts-travel-service] 2024-12-07 18:19:29.219 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan
  18:19:29.231 [ts-travel-service] 2024-12-07 18:19:29.231 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  18:19:29.232 [ts-travel-service] 2024-12-07 18:19:29.231 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  18:19:29.245 [ts-travel-service] 2024-12-07 18:19:29.245 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  18:19:29.246 [ts-travel-service] 2024-12-07 18:19:29.245 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha
  18:19:30.692 [ts-travel-service] 2024-12-07 18:19:30.692 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×4)
  18:19:30.700 [ts-travel-service] 2024-12-07 18:19:30.700 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  18:19:30.701 [ts-travel-service] 2024-12-07 18:19:30.701 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×3)
  18:19:30.718 [ts-travel-service] 2024-12-07 18:19:30.718 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
  18:19:30.732 [ts-travel-service] 2024-12-07 18:19:30.732 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
  18:19:30.750 [ts-travel-service] 2024-12-07 18:19:30.750 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
All services, 30 seconds either side (sampled):
  18:19:00.782 [ts-admin-basic-info-service] 2024-12-07 18:19:00.781 INFO 1 --- [io-18767-exec-9] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×11)
  18:19:01.596 [ts-route-service] 2024-12-07 18:19:01.596 INFO 1 --- [io-11178-exec-8] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×245)
  18:19:01.703 [ts-travel2-service] 2024-12-07 18:19:01.703 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×139)
  18:19:05.562 [ts-basic-service] 2024-12-07 18:19:05.562 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×13)
  18:19:05.619 [ts-order-other-service] 2024-12-07 18:19:05.619 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×3)
  18:19:05.735 [ts-order-other-service] 2024-12-07 18:19:05.735 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×11)
  18:19:06.778 [ts-basic-service] 2024-12-07 18:19:06.778 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×7)
  18:19:07.120 [ts-inside-payment-service] 2024-12-07 18:19:07.119 INFO 1 --- [io-18673-exec-2] i.controller.InsidePaymentController : [Inside Payment Service][Pay] Pay for: e396f188-4000-46aa-b7cb-d41eb
  18:19:12.843 [ts-preserve-other-service] 2024-12-07 18:19:12.843 INFO 1 --- [io-14569-exec-9] p.controller.PreserveOtherController : [Preserve Other Service][Preserve] Account order from Shang Hai ----
  18:19:12.894 [ts-security-service] 2024-12-07 18:19:12.894 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Last One Hour:
  18:19:12.977 [ts-preserve-other-service] 2024-12-07 18:19:12.977 INFO 1 --- [io-14569-exec-9] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Check tickets num
  18:19:13.423 [ts-seat-service] 2024-12-07 18:19:13.422 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×4)
  18:19:14.091 [ts-seat-service] 2024-12-07 18:19:14.091 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService distributeSeat] The request seat type is confortClass and the t  (×2)
  18:19:14.200 [ts-assurance-service] 2024-12-07 18:19:14.199 INFO 1 --- [io-18888-exec-3] assurance.service.AssuranceServiceImpl : [Assurance-Add&Delete-Service][AddAssurance] Success.
  18:19:15.176 [ts-auth-service] 2024-12-07 18:19:15.176 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×3)
  18:19:18.242 [ts-travel-service] 2024-12-07 18:19:18.242 INFO 1 --- [io-12346-exec-1] travel.controller.TravelController : [Travel Service] Query TripResponse  (×3)
  18:19:18.414 [ts-order-service] 2024-12-07 18:19:18.414 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×2)
  18:19:18.680 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:19:18 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 339 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×3)
  18:19:27.387 [ts-price-mongo] {"t":{"$date":"2024-12-07T18:19:27.387+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359556
  18:19:30.042 [ts-travel2-service] 2024-12-07 18:19:30.042 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×2)
  18:19:30.684 [ts-user-mongo] {"t":{"$date":"2024-12-07T18:19:30.684+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359557
  18:19:43.550 [ts-order-service] 2024-12-07 18:19:43.550 INFO 1 --- [io-12031-exec-6] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 29  (×4)
  18:19:43.802 [ts-assurance-service] 2024-12-07 18:19:43.802 INFO 1 --- [io-18888-exec-6] a.controller.AssuranceController : [Assurances Service][Get Assurance Type]
  18:19:43.966 [ts-security-service] 2024-12-07 18:19:43.966 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Last One Hour:
  18:19:44.008 [ts-travel-service] 2024-12-07 18:19:44.008 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  18:19:44.499 [ts-preserve-service] 2024-12-07 18:19:44.498 INFO 1 --- [io-14568-exec-9] preserve.service.PreserveServiceImpl : [Preserve Service][Order] Order Travel Date: Sat Dec 07 00:00:00 GMT
  18:19:44.580 [ts-preserve-service] 2024-12-07 18:19:44.579 INFO 1 --- [io-14568-exec-9] preserve.service.PreserveServiceImpl : [Preserve Service][Step 5] Do not need to buy assurance
  18:19:45.791 [ts-travel2-service] 2024-12-07 18:19:45.791 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236
  18:19:50.742 [ts-basic-service] 2024-12-07 18:19:50.741 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2

## p0430
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T08:05:38.543Z
```
{"timestamp":1732349138543232800,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T08:05:38.543108551Z caller=middlewares.go:75 method=GetUsers id=67418cbda437380001deebef result=1 took=2.405152ms"}
```
Same service, the 2 minutes before (oldest first):
  08:05:36.335 [user] ts=2024-11-23T08:05:36.334921395Z caller=middlewares.go:75 method=GetUsers id=67418cb4a437380001deebd3 result=1 took=2.517974ms  (×9)
  08:05:36.422 [user] ts=2024-11-23T08:05:36.42219905Z caller=middlewares.go:46 method=Register username=HppTvuW email=HppTvuW@gmail.com took=2.855564ms
  08:05:36.422 [user] ts=2024-11-23T08:05:36.422193492Z caller=middlewares.go:46 method=Register username=pSeQWyL email=pSeQWyL@gmail.com took=2.850057ms
  08:05:36.554 [user] ts=2024-11-23T08:05:36.554604193Z caller=middlewares.go:46 method=Register username=COYVDutH email=COYVDutH@gmail.com took=2.874059ms
  08:05:36.620 [user] ts=2024-11-23T08:05:36.620436853Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418cc9a437380001deec1a took=3.572043ms  (×2)
  08:05:36.678 [user] ts=2024-11-23T08:05:36.678283279Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67418cc9a437380001deec1a took=3.13313ms  (×2)
  08:05:37.558 [user] ts=2024-11-23T08:05:37.55870177Z caller=middlewares.go:46 method=Register username=QTNxlk email=QTNxlk@gmail.com took=2.268833ms
  08:05:37.779 [user] ts=2024-11-23T08:05:37.778745472Z caller=middlewares.go:46 method=Register username=uOuKqLBUeqm email=uOuKqLBUeqm@gmail.com took=2.993085ms
  08:05:37.849 [user] ts=2024-11-23T08:05:37.849036052Z caller=middlewares.go:157 method=Health result=2 took=2.4685ms  (×2)
All services, 30 seconds either side (sampled):
  08:05:16.044 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418cb4a437380001deebd3"}  (×55)
  08:05:16.915 [front-end] Request received with body: {}  (×55)
  08:05:17.298 [front-end] Carts merged.  (×56)
  08:05:18.225 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×10)
  08:05:19.548 [user] ts=2024-11-23T08:05:19.547968642Z caller=middlewares.go:46 method=Register username=LqGAWNLJ email=LqGAWNLJ@gmail.com took=1.912621ms
  08:05:21.523 [front-end] Posting Customer: {"username":"ZITzoSR","password":"XDZnPmN","email":"ZITzoSR@gmail.com","firstName":"ZITzoSR","lastName":"ZITzoSR"}
  08:05:25.927 [front-end] Received response: "{\"firstName\":\"codMOMP\",\"lastName\":\"codMOMP\",\"username\":\"codMOMP\",\"id\":\"67418caea437380001deebbc\",\"_links\":{\"addresses\":{
  08:05:26.604 [queue-master] 2024-11-23 08:05:26.604 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[application/hal+json
  08:05:26.614 [queue-master] 2024-11-23 08:05:26.614 INFO 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframework.web.servl
  08:05:27.717 [queue-master] 2024-11-23 08:05:27.716 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics || /metrics.json],methods=[GET],produces=[application/json]
  08:05:28.615 [shipping] 2024-11-23 08:05:28.614 INFO [shipping,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricFilter' to: [/*]  (×6)
  08:05:30.718 [queue-master] 2024-11-23 08:05:30.718 INFO 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase -2147482648
  08:05:32.017 [rabbitmq] 
  08:05:34.107 [queue-master] 2024-11-23 08:05:34.106 INFO 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:05:37.554 [front-end] Posting Customer: {"username":"QTNxlk","password":"qwbekCU","email":"QTNxlk@gmail.com","firstName":"QTNxlk","lastName":"QTNxlk"}
  08:05:39.189 [orders] 2024-11-23 08:05:39.189 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[applicat
  08:05:39.196 [orders] 2024-11-23 08:05:39.196 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicat
  08:05:41.187 [orders] 2024-11-23 08:05:41.187 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application
  08:05:41.198 [orders] 2024-11-23 08:05:41.198 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produce
  08:05:44.686 [orders] 2024-11-23 08:05:44.686 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposu  (×2)
  08:05:47.226 [front-end] Received response: "{\"firstName\":\"kvjRZNQgiVnmkal\",\"lastName\":\"kvjRZNQgiVnmkal\",\"username\":\"kvjRZNQgiVnmkal\",\"id\":\"67418cc2a437380001deebff\",\"_
  08:05:49.793 [orders] 2024-11-23 08:05:49.793 INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/orders
  08:05:51.464 [user] ts=2024-11-23T08:05:51.464834006Z caller=middlewares.go:46 method=Register username=JfkloKMY email=JfkloKMY@gmail.com took=1.963924ms
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/jso
  08:05:55.927 [front-end] Received response: "{\"firstName\":\"vAqpjQQYV\",\"lastName\":\"vAqpjQQYV\",\"username\":\"vAqpjQQYV\",\"id\":\"67418ccba437380001deec21\",\"_links\":{\"address
  08:05:59.705 [front-end] Posting Customer: {"username":"RKNDdSk","password":"qMAtnYqE","email":"RKNDdSk@gmail.com","firstName":"RKNDdSk","lastName":"RKNDdSk"}
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  08:06:06.402 [carts] 2024-11-23 08:06:06.401 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionHa
  08:06:07.004 [shipping] 2024-11-23 08:06:07.004 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/h
  08:06:07.103 [shipping] 2024-11-23 08:06:07.103 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[OPTIONS],produces=[ap

## p0136
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:31:25.800Z
```
{"timestamp":1731907885800199000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  05:31:24.000 [frontend] request complete  (×7)
  05:31:24.021 [frontend] request started  (×6)
  05:31:24.021 [frontend] serving product page  (×4)
  05:31:24.073 [frontend] view user cart
  05:31:24.390 [frontend] home
  05:31:24.438 [frontend] ENV_PLATFORM is: aws
All services, 30 seconds either side (sampled):
  05:31:12.113 [frontend] request started  (×231)
  05:31:12.116 [currencyservice] Getting supported currencies...  (×190)
  05:31:12.130 [currencyservice] conversion request successful  (×533)
  05:31:12.168 [adservice] received ad request (context_words=[])  (×26)
  05:31:12.225 [frontend] setting currency  (×17)
  05:31:13.241 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '1YMWWN1N4O', '0PUK6V6EV0', '9SIQT8TOJO', 'L9ECAV7KIM']  (×156)
  05:31:13.958 [adservice] received ad request (context_words=[kitchen])  (×40)
  05:31:15.546 [adservice] received ad request (context_words=[decor, home])  (×12)
  05:31:16.969 [frontend] adding to cart  (×24)
  05:31:16.983 [frontend] view user cart  (×46)
  05:31:17.008 [shippingservice] [GetQuote] completed request  (×53)
  05:31:17.030 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="EUR"  (×2)
  05:31:17.056 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"139","nanos":655019905},"credit_card":{"credit_card_number":"49231259390927  (×2)
  05:31:17.058 [checkoutservice] payment went through (transaction_id: f193f55b-9ec1-41b5-abef-e610b8b840af)  (×7)
  05:31:17.059 [shippingservice] [ShipOrder] completed request  (×7)
  05:31:17.070 [emailservice] A request to send order confirmation email to curtis26@example.org has been received.
  05:31:17.072 [frontend] order placed  (×7)
  05:31:17.380 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"29721","nanos":50862865},"credit_card":{"credit_card_number":"4397529817152  (×2)
  05:31:17.393 [emailservice] A request to send order confirmation email to beckrobert@example.net has been received.
  05:31:18.456 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '1YMWWN1N4O']
  05:31:18.597 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"2702","nanos":280000000},"credit_card":{"credit_card_number":"4761344760685
  05:31:18.613 [emailservice] A request to send order confirmation email to etate@example.com has been received.
  05:31:20.895 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '66VCHSJNUP', '1YMWWN1N4O']  (×3)
  05:31:31.384 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="TRY"  (×2)
  05:31:31.434 [paymentservice] Transaction processed: visa ending 2674 Amount: TRY7986.543787768  (×2)
  05:31:31.447 [checkoutservice] order confirmation email sent to "ncoleman@example.com"
  05:31:34.240 [checkoutservice] order confirmation email sent to "stephanieadams@example.org"
  05:31:37.485 [checkoutservice] order confirmation email sent to "jeffrey07@example.org"
  05:31:46.696 [checkoutservice] order confirmation email sent to "duranalexander@example.net"

## p0143
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:34:59.487Z
```
{"timestamp":1731908099487374000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  05:34:57.945 [frontend] request started  (×7)
  05:34:57.945 [frontend] serving product page  (×6)
  05:34:57.979 [frontend] request complete  (×6)
  05:34:58.447 [frontend] view user cart
All services, 30 seconds either side (sampled):
  05:34:29.698 [frontend] request started  (×297)
  05:34:29.700 [currencyservice] Getting supported currencies...  (×249)
  05:34:29.715 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', 'L9ECAV7KIM', '1YMWWN1N4O', '66VCHSJNUP', '9SIQT8TOJO']  (×209)
  05:34:29.726 [shippingservice] [GetQuote] completed request  (×73)
  05:34:29.740 [frontend] request complete  (×295)
  05:34:29.770 [adservice] received ad request (context_words=[kitchen])  (×51)
  05:34:31.670 [adservice] received ad request (context_words=[decor, home])  (×13)
  05:34:32.155 [frontend] home  (×31)
  05:34:32.211 [adservice] received ad request (context_words=[])  (×31)
  05:34:32.436 [frontend] adding to cart  (×32)
  05:34:32.870 [adservice] received ad request (context_words=[clothing, tops])  (×15)
  05:34:33.671 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="USD"  (×3)
  05:34:33.694 [paymentservice] Transaction processed: visa ending 0042 Amount: USD307.860000000  (×3)
  05:34:33.698 [shippingservice] [ShipOrder] received request  (×9)
  05:34:33.701 [cartservice] EmptyCartAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add  (×9)
  05:34:33.708 [checkoutservice] order confirmation email sent to "raymond19@example.net"
  05:34:35.403 [frontend] setting currency  (×16)
  05:34:39.650 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"584","nanos":498816456},"credit_card":{"credit_card_number":"45338846186671  (×2)
  05:34:39.665 [emailservice] A request to send order confirmation email to nathan13@example.com has been received.
  05:34:43.550 [emailservice] A request to send order confirmation email to fosterbrian@example.com has been received.
  05:34:43.760 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM']  (×6)
  05:34:44.209 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="EUR"  (×2)
  05:34:44.247 [paymentservice] Transaction processed: visa ending 3215 Amount: EUR361.636444058  (×2)
  05:34:44.259 [checkoutservice] order confirmation email sent to "cisnerosdawn@example.net"
  05:35:09.249 [checkoutservice] order confirmation email sent to "eolson@example.com"
  05:35:10.569 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"111675","nanos":881469295},"credit_card":{"credit_card_number":"46476958730  (×2)
  05:35:10.583 [emailservice] A request to send order confirmation email to brittanybarnett@example.net has been received.
  05:35:20.165 [emailservice] A request to send order confirmation email to jenniferedwards@example.com has been received.
  05:35:23.885 [emailservice] A request to send order confirmation email to dananderson@example.org has been received.
  05:35:25.471 [emailservice] A request to send order confirmation email to isingleton@example.com has been received.

## p0119
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:17:43.840Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731907063840792300,"container_name":"adservice","pod_name":"adservice-574c5fd7b4-tmkhn","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Tracing enabled but temporarily unavailable"}
```
Same service, the 2 minutes before (oldest first):
  05:17:34.960 [adservice] received ad request (context_words=[hair, beauty])  (×5)
  05:17:35.730 [adservice] received ad request (context_words=[kitchen])  (×3)
  05:17:36.105 [adservice] received ad request (context_words=[accessories])  (×2)
  05:17:37.099 [adservice] received ad request (context_words=[footwear])
  05:17:37.384 [adservice] received ad request (context_words=[clothing, tops])  (×3)
  05:17:38.820 [adservice] received ad request (context_words=[])  (×2)
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:40.213 [adservice] *** server shut down
  05:17:43.747 [adservice] AdService starting.
  05:17:43.839 [adservice] Stats enabled, but temporarily unavailable
All services, 30 seconds either side (sampled):
  05:17:14.375 [frontend] request started  (×281)
  05:17:14.382 [cartservice] GetCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×239)
  05:17:14.401 [shippingservice] [GetQuote] completed request  (×79)
  05:17:14.842 [frontend] serving product page  (×128)
  05:17:14.988 [frontend] home  (×32)
  05:17:15.286 [adservice] received ad request (context_words=[accessories])  (×10)
  05:17:16.598 [adservice] received ad request (context_words=[kitchen])  (×24)
  05:17:16.663 [frontend] placing order  (×7)
  05:17:16.693 [paymentservice] Transaction processed: visa ending 5701 Amount: TRY1792.226454698  (×4)
  05:17:16.696 [shippingservice] [ShipOrder] completed request  (×7)
  05:17:16.706 [checkoutservice] order confirmation email sent to "abowman@example.com"
  05:17:16.825 [checkoutservice] order confirmation email sent to "barbara24@example.com"
  05:17:24.080 [adservice] received ad request (context_words=[decor, home])  (×6)
  05:17:24.111 [paymentservice] Transaction processed: visa ending 1703 Amount: CAD346.438559926  (×2)
  05:17:25.127 [emailservice] A request to send order confirmation email to coxchristine@example.net has been received.
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:40.406 [frontend] failed to retrieve ads  (×84)
  05:17:43.841 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.  (×2)
  05:17:45.450 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  05:17:53.543 [adservice] Tracing enabled but temporarily unavailable
  05:17:55.262 [paymentservice] Transaction processed: visa ending 8741 Amount: EUR679.655019909
  05:18:02.298 [emailservice] A request to send order confirmation email to caseyhoward@example.com has been received.

## p0673
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-11T14:09:22.113Z
```
{"service":"redisservice1","message":"2021-08-11 14:09:22,113 | INFO | 0.0.0.1 | 172.17.0.4 | redisservice1 | 3aecd678eedc419b | redis write success"}
```
Same service, the 2 minutes before (oldest first):
  14:09:16.359 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×4)
  14:09:16.409 [redisservice1] INFO redis write success  (×8)
  14:09:16.559 [redisservice1] INFO redis读取信息成功, status_code: 200  (×5)
  14:09:19.433 [redisservice1] INFO service accept, status_code: 200  (×3)
All services, 30 seconds either side (sampled):
  14:08:52.152 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×45)
  14:08:52.317 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×49)
  14:08:52.405 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '99ccba96-fa6a-11eb-bd7a-0242ac110003', 'user_id': 'VyLzqQJk'}  (×83)
  14:08:52.504 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  14:08:52.574 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×38)
  14:08:52.698 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '9a08dd50-fa6a-11eb-8483-0242ac110003'}  (×34)
  14:08:52.984 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  14:08:53.548 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×41)
  14:08:54.195 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×46)
  14:08:55.623 [mobservice2] INFO info 9bca93f4-fa6a-11eb-bda8-0242ac110003:YRPinNTo write success
  14:08:58.344 [mobservice2] INFO info 9d6a26ca-fa6a-11eb-b009-0242ac110004:XKUdarkx write success  (×2)
  14:09:00.227 [mobservice2] INFO info 9e8bbc8a-fa6a-11eb-a3a2-0242ac110003:TrtKhHmF write success
  14:09:02.240 [mobservice1] INFO info 9fc3165c-fa6a-11eb-8a15-0242ac110003:zZMHRjyN write success
  14:09:05.291 [dbservice1] INFO a15c57c6-fa6a-11eb-9e55-0242ac110004-HBUrWkyb-d9v-_CftTxs{ token generate success token=MTYyODY2MjE0NS4yOTA2MjY1OmExNWM1N2M2LWZhNmEtMTFlYi05ZTU1LTAyNDJhYzE
  14:09:07.688 [dbservice2] INFO a2cc05d4-fa6a-11eb-a2d6-0242ac110004-MGhzxsST-cYbH0S^hJFm* token generate success token=MTYyODY2MjE0Ny42ODc2Mzc2OmEyY2MwNWQ0LWZhNmEtMTFlYi1hMmQ2LTAyNDJhYzE
  14:09:10.536 [dbservice1] INFO a480a3b2-fa6a-11eb-9cce-0242ac110004-kOerFKnJ-$Y(ZQN69hFpt token generate success token=MTYyODY2MjE1MC41MzU5NTA0OmE0ODBhM2IyLWZhNmEtMTFlYi05Y2NlLTAyNDJhYzE
  14:09:12.991 [mobservice2] INFO info a627f760-fa6a-11eb-8ab2-0242ac110004:kuaemYbD write success
  14:09:15.083 [dbservice2] INFO a721bb42-fa6a-11eb-bd53-0242ac110003-JkvHOUxm-rOwA5m{>N7*E token generate success token=MTYyODY2MjE1NS4wODI5MjA2OmE3MjFiYjQyLWZhNmEtMTFlYi1iZDUzLTAyNDJhYzE  (×2)
  14:09:17.206 [mobservice2] INFO info a8b26c9a-fa6a-11eb-894f-0242ac110003:vtpXmFKe write success
  14:09:20.909 [dbservice2] INFO aabdf2fc-fa6a-11eb-ab67-0242ac110004-lEKkjfpD-^a37_&?:CJeS token generate success token=MTYyODY2MjE2MC45MDkzMjk0OmFhYmRmMmZjLWZhNmEtMTFlYi1hYjY3LTAyNDJhYzE
  14:09:23.140 [mobservice2] INFO info ac3b9fe4-fa6a-11eb-a186-0242ac110004:sXITPUpy write success
  14:09:25.645 [dbservice1] INFO ad71d27a-fa6a-11eb-93ee-0242ac110003-UagLVmBc-tbTl$8RgueW) token generate success token=MTYyODY2MjE2NS42NDU0MjY1OmFkNzFkMjdhLWZhNmEtMTFlYi05M2VlLTAyNDJhYzE
  14:09:28.318 [dbservice1] INFO af1cbdc4-fa6a-11eb-a1be-0242ac110003-JuoeTjfH-</8-1d:T#)+0 token generate success token=MTYyODY2MjE2OC4zMTgwNjM6YWYxY2JkYzQtZmE2YS0xMWViLWExYmUtMDI0MmFjMTE
  14:09:31.145 [dbservice2] INFO b0ae53e6-fa6a-11eb-ba24-0242ac110004-glaSXZGO-iB:Guv&kX(1a token generate success token=MTYyODY2MjE3MS4xNDUyNDM2OmIwYWU1M2U2LWZhNmEtMTFlYi1iYTI0LTAyNDJhYzE
  14:09:33.464 [dbservice1] INFO b23544ae-fa6a-11eb-9d20-0242ac110003-ZzmSOCgj--Z!lLScPi9</ token generate success token=MTYyODY2MjE3My40NjQ0NTc1OmIyMzU0NGFlLWZhNmEtMTFlYi05ZDIwLTAyNDJhYzE
  14:09:36.316 [mobservice1] INFO info b40ed06a-fa6a-11eb-8ee2-0242ac110004:WuXJGtdQ write success
  14:09:39.103 [dbservice1] INFO b58d414c-fa6a-11eb-9058-0242ac110004-iBnyvbLP-R$>:BM4<a*@! token generate success token=MTYyODY2MjE3OS4xMDMxNDU4OmI1OGQ0MTRjLWZhNmEtMTFlYi05MDU4LTAyNDJhYzE
  14:09:41.481 [dbservice1] INFO b6d818a6-fa6a-11eb-8ab2-0242ac110003-AaVSnOsU-SjgU+V3dBavi token generate success token=MTYyODY2MjE4MS40ODA4NTYyOmI2ZDgxOGE2LWZhNmEtMTFlYi04YWIyLTAyNDJhYzE
  14:09:45.377 [dbservice1] INFO b82511b4-fa6a-11eb-bf5e-0242ac110003-eHFMUigu-^7vWS:ROpGca token generate success token=MTYyODY2MjE4NS4zNzY4NzU6YjgyNTExYjQtZmE2YS0xMWViLWJmNWUtMDI0MmFjMTE
  14:09:49.874 [dbservice2] INFO bbd3a96a-fa6a-11eb-bc98-0242ac110003-WVPTmDGM-P+m#ZGgNRh3= token generate success token=MTYyODY2MjE4OS44NzQyOTI5OmJiZDNhOTZhLWZhNmEtMTFlYi1iYzk4LTAyNDJhYzE

## p0184
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T06:45:17.264Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731912317264905000,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  06:45:15.803 [currencyservice] Getting supported currencies...  (×8)
  06:45:15.813 [currencyservice] conversion request successful  (×12)
All services, 30 seconds either side (sampled):
  06:44:47.371 [frontend] request started  (×331)
  06:44:47.375 [currencyservice] Getting supported currencies...  (×269)
  06:44:47.385 [currencyservice] conversion request successful  (×698)
  06:44:47.403 [adservice] received ad request (context_words=[kitchen])  (×40)
  06:44:47.490 [frontend] adding to cart  (×37)
  06:44:47.502 [frontend] view user cart  (×83)
  06:44:47.530 [shippingservice] [GetQuote] completed request  (×93)
  06:44:47.778 [frontend] home  (×32)
  06:44:47.827 [adservice] received ad request (context_words=[])  (×32)
  06:44:48.482 [adservice] received ad request (context_words=[decor, home])  (×16)
  06:44:49.132 [checkoutservice] [PlaceOrder] user_id="fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a" user_currency="TRY"  (×2)
  06:44:49.150 [paymentservice] Transaction processed: visa ending 2473 Amount: TRY151.587002213  (×2)
  06:44:49.154 [shippingservice] [ShipOrder] received request  (×10)
  06:44:49.157 [cartservice] EmptyCartAsync called with userId=fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a  (×10)
  06:44:49.161 [checkoutservice] failed to send order confirmation to "bryanpineda@example.com": rpc error: code = Unavailable desc = no healthy upstream
  06:44:49.512 [adservice] received ad request (context_words=[footwear])  (×16)
  06:44:51.558 [adservice] received ad request (context_words=[clothing, tops])  (×14)
  06:45:02.320 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="USD"  (×2)
  06:45:02.337 [paymentservice] Transaction processed: visa ending 8310 Amount: USD168.910000000  (×2)
  06:45:11.622 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="GBP"  (×2)
  06:45:11.647 [paymentservice] Transaction processed: visa ending 1532 Amount: GBP218.442127366  (×2)
  06:45:13.160 [checkoutservice] failed to send order confirmation to "markbrown@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:45:19.100 [checkoutservice] [PlaceOrder] user_id="fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a" user_currency="CAD"
  06:45:19.124 [paymentservice] Transaction processed: visa ending 4356 Amount: CAD600.717424148
  06:45:27.222 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="EUR"  (×3)
  06:45:27.243 [paymentservice] Transaction processed: visa ending 7992 Amount: EUR171.508182225  (×3)
  06:45:29.676 [checkoutservice] failed to send order confirmation to "elizabethchavez@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:45:43.092 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '66VCHSJNUP', '9SIQT8TOJO']

## p0773
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T19:28:48.502Z
```
{"timestamp":1732390128502656800,"container_name":"carts","pod_name":"carts-6cdcbc6cd7-8t7np","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 19:28:48.502  INFO [carts,4e021eaac83d67c1,1e1511fefb7ac329,false] 7 --- [-nio-80-exec-16] w.w.s.cart.cart.CartContentsResource     : Adding for user: Cart{id='67422cf09cf498000706e545', customerId='67422ce848485600016b18a4', items=[]}, Item{id='67422cf09cf498000706e546', itemId='d3588630-ad8e-49df-bbd7-3167f7efb246', quantity=1, unitPrice=10.99}"}
```
Same service, the 2 minutes before (oldest first):
  19:28:39.358 [carts] 2024-11-23 19:28:39.358 INFO [carts,b9bfd37dfd89e5e3,0a50af79e60eb332,false] 7 --- [-nio-80-exec-12] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×3)
  19:28:39.541 [carts] 2024-11-23 19:28:39.541 INFO [carts,de5ee0cc01965a45,81e439055e06f2e2,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.controllers.ItemsController : Did not find item.  (×4)
  19:28:39.546 [carts] 2024-11-23 19:28:39.545 INFO [carts,de5ee0cc01965a45,81e439055e06f2e2,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)
  19:28:40.175 [carts] 2024-11-23 19:28:40.175 INFO [carts,f53cbc27bf43ff1b,53e774cbf8b7b918,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.CartsController : Merge carts reques  (×4)
  19:28:44.415 [carts] 2024-11-23 19:28:44.415 INFO [carts,c8812353d3c6b02f,a5e4b109699fe0ce,false] 7 --- [-nio-80-exec-19] w.w.s.cart.controllers.CartsController : Merge carts reques  (×2)
  19:28:46.367 [carts] 2024-11-23 19:28:46.367 INFO [carts,cd8624e9a5115a9c,5b12ca20ab026ed1,false] 7 --- [-nio-80-exec-14] w.w.s.cart.controllers.ItemsController : Did not find item.  (×3)
All services, 30 seconds either side (sampled):
  19:28:18.506 [front-end] User cart deleted with status: 202  (×63)
  19:28:18.609 [user] ts=2024-11-23T19:28:18.608897476Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67422cc948485600016b183c took=11.175258ms  (×62)
  19:28:18.805 [front-end] POST /cart 201 - ms - -  (×63)
  19:28:18.868 [user] ts=2024-11-23T19:28:18.868563159Z caller=middlewares.go:104 method=GetAddresses id=67422cbb48485600016b181e result=1 took=5.903256ms  (×64)
  19:28:19.020 [queue-master] 2024-11-23 19:28:19.020 ERROR 7 --- [pool-6-thread-2] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×16)
  19:28:20.697 [user] ts=2024-11-23T19:28:20.697264053Z caller=middlewares.go:157 method=Health result=2 took=4.390465ms  (×40)
  19:28:22.101 [user] ts=2024-11-23T19:28:22.101779838Z caller=middlewares.go:46 method=Register username=ODupjdzaC email=ODupjdzaC@gmail.com took=5.386574ms
  19:28:25.102 [user] ts=2024-11-23T19:28:25.10217884Z caller=middlewares.go:46 method=Register username=UepLS email=UepLS@gmail.com took=4.714018ms
  19:28:26.384 [front-end] Posting Customer: {"username":"lxvzqKiy","password":"snbBTTgO","email":"lxvzqKiy@gmail.com","firstName":"lxvzqKiy","lastName":"lxvzqKiy"}
  19:28:27.627 [front-end] Posting Customer: {"username":"waSZDFWloU","password":"MqFioGQ","email":"waSZDFWloU@gmail.com","firstName":"waSZDFWloU","lastName":"waSZDFWloU"}
  19:28:29.243 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×10)
  19:28:31.341 [front-end] Received response: "{\"firstName\":\"RJtxPNVuozZUdla\",\"lastName\":\"RJtxPNVuozZUdla\",\"username\":\"RJtxPNVuozZUdla\",\"id\":\"67422ccc48485600016b1848\",\"_
  19:28:32.833 [front-end] Received response: "{\"firstName\":\"OgckOnbTzap\",\"lastName\":\"OgckOnbTzap\",\"username\":\"OgckOnbTzap\",\"id\":\"67422ccc48485600016b1847\",\"_links\":{\"a
  19:28:34.800 [front-end] Order response: {"statusCode":201,"body":{"id":"67422ce24ca85a00070c52be","customerId":"67422cc448485600016b182f","customer":{"id":null,"firstName":"AVmaNtBHLb"
  19:28:39.703 [front-end] Order response: {"statusCode":201,"body":{"id":"67422ce74ca85a00070c52c0","customerId":"67422cd448485600016b1868","customer":{"id":null,"firstName":"VcfGzxmJl",
  19:28:43.037 [front-end] Order response: {"id":"67422ceb4ca85a00070c52c3","customerId":"67422cd548485600016b186c","customer":{"id":null,"firstName":"WpuJLU","lastName":"WpuJLU","usernam
  19:28:45.864 [front-end] Posting Customer: {"username":"OHJyLYohZvggH","password":"nUXMA","email":"OHJyLYohZvggH@gmail.com","firstName":"OHJyLYohZvggH","lastName":"OHJyLYohZvggH"}
  19:28:48.314 [front-end] Order response: {"id":"67422cf04ca85a00070c52c9","customerId":"67422cdf48485600016b188a","customer":{"id":null,"firstName":"hPvOlVxLCvnMH","lastName":"hPvOlVxLC
  19:28:50.989 [user] ts=2024-11-23T19:28:50.989855823Z caller=middlewares.go:46 method=Register username=rMALO email=rMALO@gmail.com took=4.100873ms
  19:28:53.102 [user] ts=2024-11-23T19:28:53.102611755Z caller=middlewares.go:46 method=Register username=KKWAhYMvJ email=KKWAhYMvJ@gmail.com took=5.076263ms
  19:28:55.443 [front-end] Order response: {"statusCode":201,"body":{"id":"67422cf74ca85a00070c52d0","customerId":"67422cde48485600016b1884","customer":{"id":null,"firstName":"pEDeCn","la
  19:28:58.593 [carts-db] {"t":{"$date":"2024-11-23T19:28:58.593+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173239013
  19:29:03.078 [front-end] Received response: "{\"firstName\":\"OHJyLYohZvggH\",\"lastName\":\"OHJyLYohZvggH\",\"username\":\"OHJyLYohZvggH\",\"id\":\"67422ced48485600016b18a8\",\"_links\
  19:29:04.946 [front-end] Received response: "{\"firstName\":\"yoptbaq\",\"lastName\":\"yoptbaq\",\"username\":\"yoptbaq\",\"id\":\"67422cf248485600016b18b4\",\"_links\":{\"addresses\":{
  19:29:07.605 [front-end] Received response: "{\"firstName\":\"hATrgBenNGSq\",\"lastName\":\"hATrgBenNGSq\",\"username\":\"hATrgBenNGSq\",\"id\":\"67422cec48485600016b18a5\",\"_links\":{
  19:29:09.926 [front-end] Received response: "{\"firstName\":\"BjGxD\",\"lastName\":\"BjGxD\",\"username\":\"BjGxD\",\"id\":\"67422cf448485600016b18bc\",\"_links\":{\"addresses\":{\"href
  19:29:11.227 [front-end] Received response: "{\"firstName\":\"WXOxseEQMMlXPGU\",\"lastName\":\"WXOxseEQMMlXPGU\",\"username\":\"WXOxseEQMMlXPGU\",\"id\":\"67422cf648485600016b18c0\",\"_
  19:29:13.515 [front-end] Posting Customer: {"username":"rAJnZvZf","password":"MjyyStx","email":"rAJnZvZf@gmail.com","firstName":"rAJnZvZf","lastName":"rAJnZvZf"}
  19:29:15.425 [front-end] Order response: {"id":"67422d0b4ca85a00070c52e3","customerId":"67422cf948485600016b18ca","customer":{"id":null,"firstName":"MTvHlhuLkGqK","lastName":"MTvHlhuLkG

## p0441
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T08:06:00.502Z
```
{"timestamp":1732349160502406400,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:00.502  INFO [carts,,,] 7 --- [           main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped \"{[/carts/{customerId}/merge],methods=[GET]}\" onto public void works.weave.socks.cart.controllers.CartsController.mergeCarts(java.lang.String,java.lang.String)"}
```
Same service, the 2 minutes before (oldest first):
  08:05:27.910 [carts] 2024-11-23 08:05:27.905 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricsFilter' to: [/*]  (×7)
  08:05:27.910 [carts] 2024-11-23 08:05:27.910 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.c.embedded.FilterRegistrationBean : Mapping filter: 'traceFilter' to: [/*]
  08:05:27.911 [carts] 2024-11-23 08:05:27.911 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'metricsServlet' to [/metrics]
  08:05:27.912 [carts] 2024-11-23 08:05:27.912 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  08:05:30.210 [carts] 2024-11-23 08:05:30.209 INFO [carts,,,] 7 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[carts-db:27017], mode=SINGLE, requiredC
  08:05:31.799 [carts] 2024-11-23 08:05:31.799 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:1}] to
  08:05:31.806 [carts] 2024-11-23 08:05:31.806 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  08:05:45.411 [carts] 2024-11-23 08:05:45.411 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  08:06:00.413 [carts] 2024-11-23 08:06:00.413 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  08:06:00.500 [carts] 2024-11-23 08:06:00.500 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[DE
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[GET],produces=
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
All services, 30 seconds either side (sampled):
  08:05:30.584 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418cc3a437380001deec02"}  (×59)
  08:05:30.781 [user] ts=2024-11-23T08:05:30.781142695Z caller=middlewares.go:75 method=GetUsers id=67418caea437380001deebbb result=1 took=2.110905ms  (×240)
  08:05:31.546 [front-end] Posting Customer: {"username":"vAqpjQQYV","password":"eBRdz","email":"vAqpjQQYV@gmail.com","firstName":"vAqpjQQYV","lastName":"vAqpjQQYV"}
  08:05:32.017 [rabbitmq] 
  08:05:34.107 [queue-master] 2024-11-23 08:05:34.106 INFO 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:05:36.422 [user] ts=2024-11-23T08:05:36.422193492Z caller=middlewares.go:46 method=Register username=pSeQWyL email=pSeQWyL@gmail.com took=2.850057ms
  08:05:39.184 [orders] 2024-11-23 08:05:39.184 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[application/hal+json ||
  08:05:39.195 [orders] 2024-11-23 08:05:39.195 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces
  08:05:40.568 [user] ts=2024-11-23T08:05:40.568586203Z caller=middlewares.go:46 method=Register username=eqACgmjO email=eqACgmjO@gmail.com took=3.106191ms
  08:05:41.195 [orders] 2024-11-23 08:05:41.195 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[app
  08:05:44.685 [orders] 2024-11-23 08:05:44.685 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetecte
  08:05:46.592 [orders] 2024-11-23 08:05:46.592 INFO [orders,,,] 8 --- [ main] w.weave.socks.orders.OrderApplication : Started OrderApplication in 80.202 seconds (JVM running for 83.09
  08:05:49.793 [orders] 2024-11-23 08:05:49.793 INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/orders
  08:05:51.959 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×3)
  08:05:54.910 [shipping] 2024-11-23 08:05:54.910 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[applicati
  08:05:57.198 [shipping] 2024-11-23 08:05:57.110 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.cont
  08:05:59.808 [shipping] 2024-11-23 08:05:59.808 INFO [shipping,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springfram  (×2)
  08:06:04.195 [front-end] Received response: "{\"firstName\":\"MQTmuf\",\"lastName\":\"MQTmuf\",\"username\":\"MQTmuf\",\"id\":\"67418cd8a437380001deec46\",\"_links\":{\"addresses\":{\"h
  08:06:07.000 [shipping] 2024-11-23 08:06:07.000 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[HEAD],produces=[application/hal+json
  08:06:07.009 [shipping] 2024-11-23 08:06:07.009 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[OPTIONS],produces=[ap
  08:06:07.808 [front-end] Posting Customer: {"username":"XJzSyDLxvp","password":"LfpbN","email":"XJzSyDLxvp@gmail.com","firstName":"XJzSyDLxvp","lastName":"XJzSyDLxvp"}
  08:06:14.202 [shipping] 2024-11-23 08:06:14.202 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:06:15.708 [carts] 2024-11-23 08:06:15.707 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[HEAD],produces=[application/hal
  08:06:15.810 [carts] 2024-11-23 08:06:15.810 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[GET],produces=[  (×2)
  08:06:16.825 [front-end] Posting Customer: {"username":"OkxajUZjGhkcaQY","password":"HuzLEVid","email":"OkxajUZjGhkcaQY@gmail.com","firstName":"OkxajUZjGhkcaQY","lastName":"OkxajUZjGhkc
  08:06:19.101 [carts] 2024-11-23 08:06:19.100 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public jav
  08:06:21.902 [carts] 2024-11-23 08:06:21.902 INFO [carts,,,] 7 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  08:06:24.605 [carts] 2024-11-23 08:06:24.603 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering wi
  08:06:27.406 [front-end] Posting Customer: {"username":"bUcof","password":"MTgADaDKGN","email":"bUcof@gmail.com","firstName":"bUcof","lastName":"bUcof"}

## p0435
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-23T08:05:49.794Z
```
{"timestamp":1732349149794610200,"container_name":"orders","pod_name":"orders-7fff6698cb-rlq5k","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-23 08:05:49.794  INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping   : Mapped \"{[/ || ],methods=[HEAD],produces=[application/hal+json || application/json || application/*+json;charset=UTF-8]}\" onto public org.springframework.http.ResponseEntity<?> org.springframework.data.rest.webmvc.RepositoryController.headForRepositories…"}
```
Same service, the 2 minutes before (oldest first):
  08:05:44.691 [orders] 2024-11-23 08:05:44.690 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX serve
  08:05:44.792 [orders] 2024-11-23 08:05:44.791 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server a  (×2)
  08:05:44.886 [orders] 2024-11-23 08:05:44.886 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as M
  08:05:44.894 [orders] 2024-11-23 08:05:44.894 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering w
  08:05:45.989 [orders] 2024-11-23 08:05:45.989 INFO [orders,,,] 8 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  08:05:46.587 [orders] 2024-11-23 08:05:46.586 INFO [orders,,,] 8 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:05:46.592 [orders] 2024-11-23 08:05:46.592 INFO [orders,,,] 8 --- [ main] w.weave.socks.orders.OrderApplication : Started OrderApplication in 80.202 seconds (JVM running for 83.09
  08:05:47.587 [orders] 2024-11-23 08:05:47.587 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  08:05:47.587 [orders] 2024-11-23 08:05:47.587 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization starte
  08:05:47.988 [orders] 2024-11-23 08:05:47.988 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comple
  08:05:49.486 [orders] 2024-11-23 08:05:49.394 ERROR [orders,,,] 8 --- [p-nio-80-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×4)
  08:05:49.486 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×4)
  08:05:49.793 [orders] 2024-11-23 08:05:49.793 INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/orders
All services, 30 seconds either side (sampled):
  08:05:19.849 [user] ts=2024-11-23T08:05:19.849067994Z caller=middlewares.go:157 method=Health result=2 took=2.600764ms  (×40)
  08:05:20.649 [user] ts=2024-11-23T08:05:20.648962527Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67418cb7a437380001deebdf took=3.416226ms  (×60)
  08:05:21.523 [front-end] Posting Customer: {"username":"ZITzoSR","password":"XDZnPmN","email":"ZITzoSR@gmail.com","firstName":"ZITzoSR","lastName":"ZITzoSR"}
  08:05:23.062 [carts-db] {"t":{"$date":"2024-11-23T08:05:23.062+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173234912
  08:05:26.508 [queue-master] 2024-11-23 08:05:26.508 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal+json || ap
  08:05:26.611 [queue-master] 2024-11-23 08:05:26.611 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[application/hal+json
  08:05:27.710 [queue-master] 2024-11-23 08:05:27.710 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}" onto publ
  08:05:28.615 [shipping] 2024-11-23 08:05:28.614 INFO [shipping,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricFilter' to: [/*]  (×6)
  08:05:30.803 [queue-master] 2024-11-23 08:05:30.718 INFO 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0  (×2)
  08:05:32.625 [queue-master] 2024-11-23 08:05:32.625 INFO 7 --- [enerContainer-1] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-durable, auto-delete, or exclusive Queue (shipping-  (×2)
  08:05:36.341 [front-end] Received response: "{\"firstName\":\"LhLfQXTZGiFC\",\"lastName\":\"LhLfQXTZGiFC\",\"username\":\"LhLfQXTZGiFC\",\"id\":\"67418cb4a437380001deebd3\",\"_links\":{
  08:05:39.184 [orders] 2024-11-23 08:05:39.184 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[application/hal+json ||
  08:05:39.196 [orders] 2024-11-23 08:05:39.196 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applica
  08:05:41.188 [orders] 2024-11-23 08:05:41.188 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applicati
  08:05:43.084 [orders] 2024-11-23 08:05:43.084 INFO [orders,,,] 8 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  08:05:44.886 [orders] 2024-11-23 08:05:44.886 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as M
  08:05:49.107 [shipping] 2024-11-23 08:05:49.106 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.spr
  08:05:51.256 [user] ts=2024-11-23T08:05:51.256028158Z caller=middlewares.go:46 method=Register username=ngatc email=ngatc@gmail.com took=2.196043ms
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto publi
  08:05:57.302 [shipping] 2024-11-23 08:05:57.301 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot
  08:06:00.413 [carts] 2024-11-23 08:06:00.413 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  08:06:04.890 [front-end] Received response: "{\"firstName\":\"lRmvkfemO\",\"lastName\":\"lRmvkfemO\",\"username\":\"lRmvkfemO\",\"id\":\"67418cd7a437380001deec42\",\"_links\":{\"address
  08:06:07.003 [shipping] 2024-11-23 08:06:07.003 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[applic
  08:06:07.103 [shipping] 2024-11-23 08:06:07.103 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[text/html]}" onto publ
  08:06:12.607 [front-end] Received response: "{\"firstName\":\"ngatc\",\"lastName\":\"ngatc\",\"username\":\"ngatc\",\"id\":\"67418cdfa437380001deec5c\",\"_links\":{\"addresses\":{\"href
  08:06:15.599 [carts] 2024-11-23 08:06:15.408 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.e
  08:06:15.806 [carts] 2024-11-23 08:06:15.806 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[DE
  08:06:16.710 [front-end] Received response: "{\"firstName\":\"vwAuXUnZkT\",\"lastName\":\"vwAuXUnZkT\",\"username\":\"vwAuXUnZkT\",\"id\":\"67418ce1a437380001deec61\",\"_links\":{\"addr
  08:06:19.102 [carts] 2024-11-23 08:06:19.102 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto 

## p0033
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-13T07:53:01.049Z
```
{"service":"webservice2","message":"2021-08-13 07:53:01,049 | ERROR | 0.0.0.3 | 172.17.0.4 | webservice2 | 65f2b33c82438d25 | an error occurred in the downstream service"}
```
Same service, the 2 minutes before (oldest first):
  07:52:56.847 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×3)
  07:52:56.847 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '6ac75cc4-fbc8-11eb-b96e-0242ac110004', 'value': '', 'ex': 10}  (×3)
  07:52:56.893 [webservice2] INFO uuid: 6ac75cc4-fbc8-11eb-b96e-0242ac110004 write redis successfully  (×3)
  07:52:56.999 [webservice2] INFO complete information: {'uuid': '6ac75cc4-fbc8-11eb-b96e-0242ac110004', 'user_id': 'yaVPzdET'}  (×3)
  07:52:57.008 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×3)
  07:52:57.009 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
  07:52:59.012 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
All services, 30 seconds either side (sampled):
  07:52:31.082 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  07:52:31.312 [dbservice2] INFO 5b055552-fbc8-11eb-989e-0242ac110003-FgWeZKzi-DO)LdaZhiTEI token generate success token=MTYyODgxMjM1MS4zMTE4MjY6NWIwNTU1NTItZmJjOC0xMWViLTk4OWUtMDI0MmFjMTE
  07:52:31.625 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×39)
  07:52:31.853 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×30)
  07:52:31.995 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  07:52:32.564 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '5c2389d6-fbc8-11eb-a50b-0242ac110003', 'value': 'rXbZtUoM'}  (×44)
  07:52:33.241 [webservice2] INFO complete information: {'uuid': '5c99ba3e-fbc8-11eb-a732-0242ac110004', 'user_id': 'zoVLGdbn'}  (×44)
  07:52:33.728 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '5cc4501e-fbc8-11eb-b840-0242ac110004'}  (×52)
  07:52:35.518 [dbservice1] INFO 5da060d6-fbc8-11eb-874f-0242ac110003-maWzwvqu-3>t0ju}R&m^p token generate success token=MTYyODgxMjM1NS41MTgyMzI6NWRhMDYwZDYtZmJjOC0xMWViLTg3NGYtMDI0MmFjMTE
  07:52:37.641 [mobservice2] INFO info 5f1e72f4-fbc8-11eb-94eb-0242ac110003:gSjZMlmO write success
  07:52:39.788 [dbservice1] INFO 6032f2aa-fbc8-11eb-a73f-0242ac110003-sftcByNh--3)PoD^K$Fey token generate success token=MTYyODgxMjM1OS43ODc4MzQyOjYwMzJmMmFhLWZiYzgtMTFlYi1hNzNmLTAyNDJhYzE
  07:52:48.338 [dbservice2] INFO 65322212-fbc8-11eb-90cf-0242ac110004-GBzXyJft-#5tr9S.2Z_EP token generate success token=MTYyODgxMjM2OC4zMzc2NzgyOjY1MzIyMjEyLWZiYzgtMTFlYi05MGNmLTAyNDJhYzE
  07:52:50.883 [mobservice1] INFO info 6709731a-fbc8-11eb-9d74-0242ac110003:xUAQKIOl write success
  07:52:53.663 [mobservice2] INFO info 68b42138-fbc8-11eb-ba5c-0242ac110003:yNHlLvWp write success
  07:52:56.332 [mobservice1] INFO info 6a3cbdee-fbc8-11eb-a556-0242ac110004:OkyWpDvC write success
  07:52:58.874 [mobservice1] INFO info 6bc63df2-fbc8-11eb-a4fa-0242ac110003:ZcstOImC write success
  07:53:01.438 [mobservice1] INFO info 6d515328-fbc8-11eb-a855-0242ac110003:HSRAIxlj write success
  07:53:04.279 [mobservice1] INFO info 6ef19a30-fbc8-11eb-ad19-0242ac110004:tRLZzuQg write success
  07:53:07.019 [mobservice2] INFO info 709fd928-fbc8-11eb-942e-0242ac110004:saHAJjFe write success
  07:53:09.704 [mobservice1] INFO info 723821be-fbc8-11eb-947b-0242ac110004:tTbvdojy write success
  07:53:13.132 [mobservice2] INFO info 744fdf8c-fbc8-11eb-a33d-0242ac110003:JuoeTjfH write success
  07:53:15.462 [mobservice1] INFO info 75aa12f8-fbc8-11eb-ad5d-0242ac110004:XtQAmVaq write success
  07:53:17.691 [mobservice2] INFO info 7701d4ce-fbc8-11eb-b0bc-0242ac110004:suCOBkmp write success
  07:53:20.121 [dbservice2] INFO 784209b2-fbc8-11eb-a161-0242ac110004-wKjLqdJi-KTeo=q$}LdB& token generate success token=MTYyODgxMjQwMC4xMjA5MzQ1Ojc4NDIwOWIyLWZiYzgtMTFlYi1hMTYxLTAyNDJhYzE
  07:53:23.016 [dbservice2] INFO 79f2ba54-fbc8-11eb-8bc4-0242ac110004-UEASdwYn-lX/Z%YE&xQ5: token generate success token=MTYyODgxMjQwMy4wMTY0MzU6NzlmMmJhNTQtZmJjOC0xMWViLThiYzQtMDI0MmFjMTE
  07:53:25.850 [dbservice1] INFO 7ba3cc08-fbc8-11eb-a1e6-0242ac110004-sEtBNqcf-k>E%?6gr8{U0 token generate success token=MTYyODgxMjQwNS44NTA0NTAzOjdiYTNjYzA4LWZiYzgtMTFlYi1hMWU2LTAyNDJhYzE
  07:53:29.202 [mobservice2] INFO info 7de0a428-fbc8-11eb-862b-0242ac110003:GNqpIFum write success

## p0836
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-08T12:48:04.910Z
```
{"timestamp":1733662084910929000,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-gr58j","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:48:04.910  INFO 1 --- [       Thread-5] o.s.i.endpoint.EventDrivenConsumer       : stopped _org.springframework.integration.errorLogger"}
```
Same service, the 2 minutes before (oldest first):
  12:48:02.500 [ts-route-service] 2024-12-08 12:48:02.499 INFO 1 --- [io-11178-exec-6] route.controller.RouteController : Route id: 1367db1f-461e-4ab7-87ad-2bcc05fd9cb7  (×14)
  12:48:04.216 [ts-route-service] 2024-12-08 12:48:04.216 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×2)
  12:48:04.907 [ts-route-service] 2024-12-08 12:48:04.906 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  12:48:04.909 [ts-route-service] 2024-12-08 12:48:04.909 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  12:48:04.910 [ts-route-service] 2024-12-08 12:48:04.909 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  12:48:04.910 [ts-route-service] 2024-12-08 12:48:04.910 INFO 1 --- [ Thread-5] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-route-service:11178.errorChannel' has 0 subscriber(s).
All services, 30 seconds either side (sampled):
  12:47:36.092 [ts-admin-basic-info-service] 2024-12-08 12:47:36.092 INFO 1 --- [io-18767-exec-7] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×12)
  12:47:37.094 [ts-basic-service] 2024-12-08 12:47:37.093 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×4)
  12:47:37.162 [ts-basic-service] 2024-12-08 12:47:37.162 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×12)
  12:47:37.186 [ts-travel2-service] 2024-12-08 12:47:37.186 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×8)
  12:47:37.271 [ts-seat-service] 2024-12-08 12:47:37.271 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×15)
  12:47:37.411 [ts-travel2-service] 2024-12-08 12:47:37.411 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×8)
  12:47:39.774 [ts-auth-service] 2024-12-08 12:47:39.774 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×3)
  12:47:41.537 [ts-travel-service] 2024-12-08 12:47:41.536 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×11)
  12:47:41.581 [ts-travel-service] 2024-12-08 12:47:41.581 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×6)
  12:47:41.641 [ts-order-service] 2024-12-08 12:47:41.641 INFO 1 --- [io-12031-exec-2] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:00:00   (×3)
  12:47:41.751 [ts-travel-service] 2024-12-08 12:47:41.750 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×6)
  12:47:41.856 [ts-assurance-service] 2024-12-08 12:47:41.855 INFO 1 --- [o-18888-exec-10] a.controller.AssuranceController : [Assurances Service][Get Assurance Type]
  12:47:41.897 [ts-security-service] 2024-12-08 12:47:41.897 INFO 1 --- [io-11188-exec-2] security.controller.SecurityController : [Security Service][Check Security] Check Account Id: 4d2a46c7-71cb
  12:47:41.935 [ts-security-service] 2024-12-08 12:47:41.935 INFO 1 --- [io-11188-exec-2] security.service.SecurityServiceImpl : [Security Service] Max In One Hour: 2147483647 Max Not Use: 21474836
  12:47:41.962 [ts-preserve-service] 2024-12-08 12:47:41.962 INFO 1 --- [o-14568-exec-10] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] Check tickets num
  12:47:42.253 [ts-preserve-service] 2024-12-08 12:47:42.253 INFO 1 --- [o-14568-exec-10] preserve.service.PreserveServiceImpl : TripAllDetail:TripAllDetail(status=false, message=null, tripResponse
  12:47:42.374 [ts-seat-service] 2024-12-08 12:47:42.374 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService distributeSeat 1] The result of getTrainTypeResult is Response(
  12:47:42.398 [ts-order-service] 2024-12-08 12:47:42.398 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 50.0
  12:47:42.422 [ts-preserve-service] 2024-12-08 12:47:42.422 INFO 1 --- [o-14568-exec-10] preserve.service.PreserveServiceImpl : [Cancel Order Service][Get Order By Id]
  12:47:52.364 [ts-food-service] 2024-12-08 12:47:52.363 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  12:47:54.599 [ts-travel-service] 2024-12-08 12:47:54.599 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  12:47:56.389 [ts-basic-service] 2024-12-08 12:47:56.389 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×4)
  12:48:02.393 [ts-seat-service] 2024-12-08 12:48:02.392 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  12:48:04.919 [ts-route-mongo] {"t":{"$date":"2024-12-08T12:48:04.919+00:00"},"s":"I", "c":"NETWORK", "id":22944, "ctx":"conn52","msg":"Connection ended","attr":{"remote":"127.0.0.6:41949","u  (×5)
  12:48:10.896 [ts-route-mongo] {"t":{"$date":"2024-12-08T12:48:10.896+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366209
  12:48:12.329 [ts-preserve-mongo] {"t":{"$date":"2024-12-08T12:48:12.329+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366209
  12:48:14.000 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-08T12:48:14.000+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366209
  12:48:16.738 [ts-order-service] 2024-12-08 12:48:16.738 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 155
  12:48:20.179 [ts-food-service] 2024-12-08 12:48:20.178 ERROR 1 --- [io-18856-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 

## p0234
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:57:04.988Z
```
{"timestamp":1731916624988630500,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"view user cart"}
```
Same service, the 2 minutes before (oldest first):
  07:57:03.670 [frontend] order placed
  07:57:03.687 [frontend] request complete  (×7)
  07:57:03.706 [frontend] ENV_PLATFORM is: aws
  07:57:04.734 [frontend] request started  (×6)
  07:57:04.734 [frontend] serving product page  (×4)
  07:57:04.978 [frontend] adding to cart
All services, 30 seconds either side (sampled):
  07:56:35.001 [frontend] request started  (×350)
  07:56:35.004 [frontend] home  (×30)
  07:56:35.018 [currencyservice] conversion request successful  (×693)
  07:56:35.233 [frontend] serving product page  (×165)
  07:56:35.797 [adservice] received ad request (context_words=[accessories])  (×39)
  07:56:37.939 [frontend] adding to cart  (×47)
  07:56:37.975 [shippingservice] [GetQuote] received request  (×89)
  07:56:38.003 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="JPY"  (×3)
  07:56:38.029 [checkoutservice] payment went through (transaction_id: d47def3e-55d2-40c2-8c58-3418df933860)  (×15)
  07:56:38.033 [cartservice] EmptyCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×15)
  07:56:38.041 [checkoutservice] failed to send order confirmation to "uwilliams@example.net": rpc error: code = Internal desc = Failed to serialize response!
  07:56:39.191 [emailservice] A request to send order confirmation email to thompsonelizabeth@example.com has been received.
  07:56:47.006 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="GBP"  (×2)
  07:56:47.038 [emailservice] A request to send order confirmation email to david50@example.net has been received.
  07:56:49.847 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"747","nanos":956153911},"credit_card":{"credit_card_number":"45037840449911
  07:56:49.861 [checkoutservice] failed to send order confirmation to "hubbardamanda@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:56:54.201 [checkoutservice] failed to send order confirmation to "orozcosteven@example.net": rpc error: code = Internal desc = Failed to serialize response!
  07:56:54.755 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"1154","nanos":117647067},"credit_card":{"credit_card_number":"4035626326342  (×3)
  07:56:54.768 [checkoutservice] failed to send order confirmation to "woodschelsea@example.org": rpc error: code = Internal desc = Failed to serialize response!
  07:57:03.668 [emailservice] A request to send order confirmation email to larry83@example.com has been received.
  07:57:05.058 [checkoutservice] failed to send order confirmation to "bradshawbrandon@example.net": rpc error: code = Internal desc = Failed to serialize response!
  07:57:05.323 [paymentservice] Transaction processed: visa ending 9123 Amount: USD64.460000000  (×3)
  07:57:18.896 [checkoutservice] [PlaceOrder] user_id="c216dec4-2181-4773-8cc5-aa587ee59fcc" user_currency="TRY"  (×3)
  07:57:18.936 [emailservice] A request to send order confirmation email to emily09@example.net has been received.
  07:57:23.300 [checkoutservice] failed to send order confirmation to "xsoto@example.net": rpc error: code = Internal desc = Failed to serialize response!
  07:57:23.776 [emailservice] A request to send order confirmation email to derrick59@example.net has been received.
  07:57:28.788 [checkoutservice] failed to send order confirmation to "allenmaria@example.net": rpc error: code = Internal desc = Failed to serialize response!

## p0207
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service recommendationservice, 2024-11-18T07:07:55.909Z
```
{"timestamp":1731913675909629700,"container_name":"recommendationservice","pod_name":"recommendationservice-fdf57f545-q8t5v","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"[Recv ListRecommendations] product_ids=['L9ECAV7KIM', '6E92ZMYYFZ', 'LS4PSXUNUM', '2ZYFJ3GM2N', '9SIQT8TOJO']"}
```
Same service, the 2 minutes before (oldest first):
  07:07:51.678 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '6E92ZMYYFZ', '2ZYFJ3GM2N', '66VCHSJNUP', 'LS4PSXUNUM']  (×20)
All services, 30 seconds either side (sampled):
  07:07:25.932 [frontend] request started  (×321)
  07:07:25.935 [currencyservice] Getting supported currencies...  (×260)
  07:07:25.945 [currencyservice] conversion request successful  (×677)
  07:07:25.962 [adservice] received ad request (context_words=[hair, beauty])  (×23)
  07:07:26.089 [adservice] received ad request (context_words=[decor, home])  (×13)
  07:07:27.350 [adservice] received ad request (context_words=[kitchen])  (×40)
  07:07:27.658 [shippingservice] [GetQuote] received request  (×75)
  07:07:28.799 [frontend] adding to cart  (×38)
  07:07:29.254 [adservice] received ad request (context_words=[clothing, tops])  (×21)
  07:07:30.278 [frontend] setting currency  (×23)
  07:07:30.326 [frontend] ENV_PLATFORM is: aws  (×33)
  07:07:36.503 [adservice] received ad request (context_words=[footwear])  (×18)
  07:07:37.004 [checkoutservice] [PlaceOrder] user_id="c216dec4-2181-4773-8cc5-aa587ee59fcc" user_currency="GBP"  (×2)
  07:07:37.035 [paymentservice] Transaction processed: visa ending 5815 Amount: GBP318.533869083  (×2)
  07:07:37.038 [shippingservice] [ShipOrder] received request  (×9)
  07:07:37.041 [cartservice] EmptyCartAsync called with userId=c216dec4-2181-4773-8cc5-aa587ee59fcc  (×9)
  07:07:37.045 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 14  (×9)
  07:07:43.247 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', '1YMWWN1N4O', '9SIQT8TOJO', '0PUK6V6EV0']
  07:07:43.328 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"825","nanos":484298993},"credit_card":{"credit_card_number":"47792883008113  (×3)
  07:07:43.341 [checkoutservice] failed to send order confirmation to "dgalvan@example.net": rpc error: code = Unavailable desc = no healthy upstream
  07:07:50.805 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="CAD"  (×3)
  07:07:50.830 [paymentservice] Transaction processed: visa ending 9724 Amount: CAD1149.259640868  (×3)
  07:07:54.829 [checkoutservice] failed to send order confirmation to "sparksjessica@example.net": rpc error: code = Unavailable desc = no healthy upstream
  07:08:09.221 [checkoutservice] failed to send order confirmation to "susan81@example.org": rpc error: code = Unavailable desc = no healthy upstream
  07:08:14.008 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="TRY"
  07:08:14.039 [paymentservice] Transaction processed: visa ending 5823 Amount: TRY10882.516488319

## p0382
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:44:01.767Z
```
{"timestamp":1732247041767138300,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /cards 200 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  03:44:01.165 [front-end] 673ffe01b0df5c00019b2fd0
  03:44:01.165 [front-end] Merging carts for customer id: 673ffe01b0df5c00019b2fd0 and session id: WBQmvmG8ZZ73Yt0J1h_a1KN42Tyi_nOi
  03:44:01.190 [front-end] Carts merged.
  03:44:01.190 [front-end] set cookie673ffe01b0df5c00019b2fd0
  03:44:01.190 [front-end] Sent cookies.
  03:44:01.192 [front-end] POST /register 200 32.050 ms - 33
  03:44:01.198 [front-end] Request received with body: {}
  03:44:01.204 [front-end] Received response: "{\"firstName\":\"UddDOtKMb\",\"lastName\":\"UddDOtKMb\",\"username\":\"UddDOtKMb\",\"id\":\"673ffdefb0df5c00019b2f97\",\"_links\":{\"address
  03:44:01.204 [front-end] GET Request to: http://user/customers/673ffdefb0df5c00019b2f97/addresses  (×2)
  03:44:01.211 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffdf6b0df5c00019b2fac\",\"_links\":{\"
  03:44:01.211 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:44:01.211 [front-end] [ undefined, undefined ]
  03:44:01.211 [front-end] Posting Order: {"customer":"http://user/customers/673ffdefb0df5c00019b2f97","address":"http://user/addresses/673ffdf6b0df5c00019b2fab","card":"http://user/cards
  03:44:01.242 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffe01d94b9000069b47e2","customerId":"673ffdefb0df5c00019b2f97","customer":{"id":null,"firstName":"UddDOtKMb",
  03:44:01.242 [front-end] Order response: {"id":"673ffe01d94b9000069b47e2","customerId":"673ffdefb0df5c00019b2f97","customer":{"id":null,"firstName":"UddDOtKMb","lastName":"UddDOtKMb","u
  03:44:01.244 [front-end] POST /orders 201 - ms - -
  03:44:01.741 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffdf7b0df5c00019b2fb4"}
  03:44:01.752 [front-end] POST /addresses 200 - ms - -
  03:44:01.757 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffdf7b0df5c00019b2fb4"}
All services, 30 seconds either side (sampled):
  03:43:31.768 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffddcb0df5c00019b2f69"}  (×35)
  03:43:31.844 [front-end] DELETE /cart 202 - ms - -  (×34)
  03:43:31.885 [carts] 2024-11-22 03:43:31.885 INFO [carts,ea036b26335c640c,02322a5b99a2a120,false] 7 --- [-nio-80-exec-10] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×18)
  03:43:33.670 [front-end] Posting Customer: {"username":"blIFvgmiWUwjwXc","password":"nuWwNPyG","email":"blIFvgmiWUwjwXc@gmail.com","firstName":"blIFvgmiWUwjwXc","lastName":"blIFvgmiWUwj
  03:43:33.700 [front-end] Sent cookies.  (×35)
  03:43:35.050 [front-end] GET Request to: http://user/customers/673ffdd1b0df5c00019b2f3e/addresses  (×60)
  03:43:35.122 [orders] 2024-11-22 03:43:35.122 INFO [orders,7b34aae641f62e27,6efc5be89c575597,false] 6 --- [p-nio-80-exec-3] w.w.s.o.controllers.OrdersController : Sending payment req  (×17)
  03:43:35.135 [queue-master] 2024-11-22 03:43:35.135 ERROR 6 --- [ool-6-thread-31] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×20)
  03:43:35.406 [payment] ts=2024-11-22T03:43:35Z caller=logging.go:29 method=Authorise result=true took=938ns  (×22)
  03:43:36.742 [catalogue] ts=2024-11-22T03:43:36Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.86263m  (×3)
  03:43:38.564 [front-end] Received response: "{\"firstName\":\"cABwWeDaGnbbR\",\"lastName\":\"cABwWeDaGnbbR\",\"username\":\"cABwWeDaGnbbR\",\"id\":\"673ffdd9b0df5c00019b2f5c\",\"_links\
  03:43:39.235 [front-end] Order response: {"timestamp":1732247019233,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×2)
  03:43:41.125 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdedd94b9000069b47cf","customerId":"673ffdd9b0df5c00019b2f5d","customer":{"id":null,"firstName":"ZInGJmtxchc
  03:43:42.955 [front-end] Order response: {"id":"673ffdeed94b9000069b47d0","customerId":"673ffddcb0df5c00019b2f69","customer":{"id":null,"firstName":"qJqohTN","lastName":"qJqohTN","usern
  03:43:44.141 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdf0d94b9000069b47d2","customerId":"673ffddbb0df5c00019b2f68","customer":{"id":null,"firstName":"HevMMaKjFyX
  03:43:45.858 [front-end] Posting Customer: {"username":"FTdWmiR","password":"ewmeaQF","email":"FTdWmiR@gmail.com","firstName":"FTdWmiR","lastName":"FTdWmiR"}
  03:43:46.354 [front-end] Posting Customer: {"username":"IWAEqSWlg","password":"chIOEiw","email":"IWAEqSWlg@gmail.com","firstName":"IWAEqSWlg","lastName":"IWAEqSWlg"}
  03:43:49.058 [front-end] Received response: "{\"firstName\":\"fSOCXj\",\"lastName\":\"fSOCXj\",\"username\":\"fSOCXj\",\"id\":\"673ffddfb0df5c00019b2f6f\",\"_links\":{\"addresses\":{\"h
  03:43:52.733 [front-end] Posting Customer: {"username":"YYEanHYjheUhfcP","password":"AjXTJM","email":"YYEanHYjheUhfcP@gmail.com","firstName":"YYEanHYjheUhfcP","lastName":"YYEanHYjheUhfc
  03:43:56.936 [front-end] Posting Customer: {"username":"rYZsbCAoqORp","password":"IFssVUe","email":"rYZsbCAoqORp@gmail.com","firstName":"rYZsbCAoqORp","lastName":"rYZsbCAoqORp"}
  03:43:57.946 [front-end] Posting Customer: {"username":"ykcYlKEn","password":"MkExLsBRw","email":"ykcYlKEn@gmail.com","firstName":"ykcYlKEn","lastName":"ykcYlKEn"}
  03:43:59.417 [front-end] Posting Customer: {"username":"eVXjpD","password":"PBxrM","email":"eVXjpD@gmail.com","firstName":"eVXjpD","lastName":"eVXjpD"}
  03:44:00.043 [front-end] Received response: "{\"firstName\":\"BRwmTJrGptUzbhq\",\"lastName\":\"BRwmTJrGptUzbhq\",\"username\":\"BRwmTJrGptUzbhq\",\"id\":\"673ffde7b0df5c00019b2f84\",\"_
  03:44:00.622 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffe00d94b9000069b47df","customerId":"673ffdebb0df5c00019b2f8d","customer":{"id":null,"firstName":"hflsfDydBxN
  03:44:01.158 [front-end] Posting Customer: {"username":"GhENipkIeXncKDm","password":"lcpLh","email":"GhENipkIeXncKDm@gmail.com","firstName":"GhENipkIeXncKDm","lastName":"GhENipkIeXncKDm
  03:44:03.552 [user] ts=2024-11-22T03:44:03.552661921Z caller=middlewares.go:46 method=Register username=haODZdNrz email=haODZdNrz@gmail.com took=1.016039ms
  03:44:04.618 [front-end] Received response: "{\"firstName\":\"huiDxUHj\",\"lastName\":\"huiDxUHj\",\"username\":\"huiDxUHj\",\"id\":\"673ffdf1b0df5c00019b2f9b\",\"_links\":{\"addresses\
  03:44:05.140 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["

## p0770
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T19:26:13.898Z
```
{"timestamp":1732389973898450000,"container_name":"carts","pod_name":"carts-78d749cf8c-wdv6t","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-23 19:26:13.897  INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster               : Exception in monitor thread while connecting to server carts-db:27017\n"}
```
Same service, the 2 minutes before (oldest first):
  19:25:55.114 [carts] 2024-11-23 19:25:55.114 INFO [carts,02a6a3ea0dde12e4,b122f616f154d2ce,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)
  19:25:55.312 [carts] 2024-11-23 19:25:55.311 INFO [carts,0e8d52aa35d76f94,11b290f04c83b74d,false] 7 --- [-nio-80-exec-12] w.w.s.cart.controllers.ItemsController : Did not find item.  (×6)
  19:25:55.319 [carts] 2024-11-23 19:25:55.319 INFO [carts,0e8d52aa35d76f94,11b290f04c83b74d,false] 7 --- [-nio-80-exec-12] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×6)
  19:25:56.544 [carts] 2024-11-23 19:25:56.544 INFO [carts,22585a0339557126,71b1ad297d3c2f32,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.controllers.ItemsController : Did not find item.  (×3)
  19:26:09.804 [carts] 2024-11-23 19:26:09.800 INFO [bootstrap,,,] 7 --- [ main] s.c.a.AnnotationConfigApplicationContext : Refreshing org.springframework.context.annotation.Annotatio
All services, 30 seconds either side (sampled):
  19:25:43.914 [front-end] Request received with body: {}  (×60)
  19:25:43.995 [user] ts=2024-11-23T19:25:43.995025004Z caller=middlewares.go:104 method=GetAddresses id=67422c3048485600016b1670 result=1 took=4.708689ms  (×60)
  19:25:44.015 [queue-master] 2024-11-23 19:25:44.015 ERROR 7 --- [ool-6-thread-23] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×12)
  19:25:44.783 [front-end] Order response: {"id":"67422c384ca85a00070c5290","customerId":"67422c2548485600016b164b","customer":{"id":null,"firstName":"aNpOtPaWu","lastName":"aNpOtPaWu","u
  19:25:44.916 [front-end] POST /register 200 31.505 ms - 33  (×65)
  19:25:45.770 [front-end] POST /cards 200 - ms - -  (×59)
  19:25:45.889 [front-end] POST /cart 201 - ms - -  (×19)
  19:25:47.151 [front-end] Order response: {"statusCode":201,"body":{"id":"67422c3b4ca85a00070c5291","customerId":"67422c2648485600016b164e","customer":{"id":null,"firstName":"OImDO","las
  19:25:48.627 [front-end] Order response: {"id":"67422c3c4ca85a00070c5293","customerId":"67422c2948485600016b1652","customer":{"id":null,"firstName":"ZhwbstXk","lastName":"ZhwbstXk","use
  19:25:49.928 [front-end] Posting Customer: {"username":"JDmPsr","password":"dlABLMLKM","email":"JDmPsr@gmail.com","firstName":"JDmPsr","lastName":"JDmPsr"}
  19:25:52.332 [front-end] Received response: "{\"firstName\":\"GJXnBwInYmiun\",\"lastName\":\"GJXnBwInYmiun\",\"username\":\"GJXnBwInYmiun\",\"id\":\"67422c2c48485600016b165c\",\"_links\
  19:25:53.784 [front-end] Posting Customer: {"username":"MhiGNtBI","password":"MVoLJiOxo","email":"MhiGNtBI@gmail.com","firstName":"MhiGNtBI","lastName":"MhiGNtBI"}
  19:25:55.085 [catalogue] ts=2024-11-23T19:25:55Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=4.23601m  (×3)
  19:25:58.539 [front-end] Received response: "{\"firstName\":\"qhWlY\",\"lastName\":\"qhWlY\",\"username\":\"qhWlY\",\"id\":\"67422c3548485600016b167c\",\"_links\":{\"addresses\":{\"href
  19:26:00.513 [user] ts=2024-11-23T19:26:00.513185565Z caller=middlewares.go:46 method=Register username=tgeTntnUl email=tgeTntnUl@gmail.com took=5.153614ms
  19:26:04.045 [user] ts=2024-11-23T19:26:04.045440342Z caller=middlewares.go:46 method=Register username=WzHvdbh email=WzHvdbh@gmail.com took=4.711835ms
  19:26:08.426 [front-end] Received response: "{\"firstName\":\"sTCYcE\",\"lastName\":\"sTCYcE\",\"username\":\"sTCYcE\",\"id\":\"67422c3948485600016b1683\",\"_links\":{\"addresses\":{\"h
  19:26:10.579 [front-end] Posting Customer: {"username":"IEqFcGdxTpdkLZ","password":"veVOs","email":"IEqFcGdxTpdkLZ@gmail.com","firstName":"IEqFcGdxTpdkLZ","lastName":"IEqFcGdxTpdkLZ"}
  19:26:13.726 [front-end] Posting Customer: {"username":"oqMFbrcw","password":"rTOrDGBNQ","email":"oqMFbrcw@gmail.com","firstName":"oqMFbrcw","lastName":"oqMFbrcw"}
  19:26:15.454 [front-end] Posting Customer: {"username":"sLDEXif","password":"elWKX","email":"sLDEXif@gmail.com","firstName":"sLDEXif","lastName":"sLDEXif"}
  19:26:17.581 [front-end] Received response: "{\"firstName\":\"CQQAUaCilPTGBGO\",\"lastName\":\"CQQAUaCilPTGBGO\",\"username\":\"CQQAUaCilPTGBGO\",\"id\":\"67422c4248485600016b16a3\",\"_
  19:26:22.487 [front-end] Posting Customer: {"username":"ZSxSSGOG","password":"tbDkvTdqb","email":"ZSxSSGOG@gmail.com","firstName":"ZSxSSGOG","lastName":"ZSxSSGOG"}
  19:26:26.436 [front-end] Received response: "{\"firstName\":\"WzHvdbh\",\"lastName\":\"WzHvdbh\",\"username\":\"WzHvdbh\",\"id\":\"67422c4c48485600016b16c9\",\"_links\":{\"addresses\":{
  19:26:30.124 [user] ts=2024-11-23T19:26:30.124176536Z caller=middlewares.go:46 method=Register username=iJvIFilL email=iJvIFilL@gmail.com took=4.711514ms
  19:26:35.227 [front-end] Posting Customer: {"username":"IrbETa","password":"uasPavwrMP","email":"IrbETa@gmail.com","firstName":"IrbETa","lastName":"IrbETa"}
  19:26:37.177 [front-end] Posting Customer: {"username":"lZlRgXYJUXWI","password":"tzDsK","email":"lZlRgXYJUXWI@gmail.com","firstName":"lZlRgXYJUXWI","lastName":"lZlRgXYJUXWI"}
  19:26:39.101 [user] ts=2024-11-23T19:26:39.101274852Z caller=middlewares.go:46 method=Register username=GhikAxmVx email=GhikAxmVx@gmail.com took=4.955416ms
  19:26:43.024 [front-end] Received response: "{\"firstName\":\"oqMFbrcw\",\"lastName\":\"oqMFbrcw\",\"username\":\"oqMFbrcw\",\"id\":\"67422c5548485600016b16dd\",\"_links\":{\"addresses\

## p0276
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:23.139Z
```
{"timestamp":1732242503139623400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /register 200 5585.892 ms - 33"}
```
Same service, the 2 minutes before (oldest first):
  02:28:23.049 [front-end] Sent cookies.  (×4)
  02:28:23.049 [front-end] Carts merged.  (×3)
  02:28:23.049 [front-end] set cookie673fec40b0df5c00019af988  (×3)
  02:28:23.050 [front-end] User cart deleted with status: 202
  02:28:23.051 [front-end] POST /register 200 1077.491 ms - 33  (×4)
  02:28:23.051 [front-end] DELETE /cart 202 - ms - -
  02:28:23.066 [front-end] Attempting to add to cart: {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","quantity":1}
  02:28:23.072 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/
  02:28:23.072 [front-end] POST to carts: http://carts/carts/673fec3ab0df5c00019af974/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}
  02:28:23.094 [front-end] GET /catalogue 200 - ms - -
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×48)
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -  (×48)
  02:28:03.203 [front-end] [ undefined, undefined ]  (×48)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×4)
  02:28:07.445 [orders] 2024-11-22 02:28:07.445 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
  02:28:10.277 [front-end] Posting Customer: {"username":"opFqwUnVow","password":"habyXFSF","email":"opFqwUnVow@gmail.com","firstName":"opFqwUnVow","lastName":"opFqwUnVow"}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
  02:28:23.301 [front-end] Received response: "{\"firstName\":\"HFHBXn\",\"lastName\":\"HFHBXn\",\"username\":\"HFHBXn\",\"id\":\"673fec34b0df5c00019af967\",\"_links\":{\"addresses\":{\"h
  02:28:24.999 [rabbitmq] 
  02:28:25.743 [carts] 2024-11-22 02:28:25.743 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×14)
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39d0","customerId":"673fec31b0df5c00019af95b","customer":{"id":null,"firstName":"bCCZHBaYc","lastName":"bCCZHBaYc","u
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×60)
  02:28:37.548 [user] ts=2024-11-22T02:28:37.548591Z caller=middlewares.go:46 method=Register username=OeZpiPZUn email=OeZpiPZUn@gmail.com took=1.009704ms
  02:28:40.321 [front-end] Order response: {"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR","lastName":"nbZCdAQyR","u
  02:28:42.162 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732242522152,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×2)
  02:28:44.338 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec5cd94b9000069b39e2","customerId":"673fec3ab0df5c00019af974","customer":{"id":null,"firstName":"opFqwUnVow"
  02:28:45.405 [front-end] Posting Customer: {"username":"crSMtAKNWrXaJJx","password":"TlwWXSanSW","email":"crSMtAKNWrXaJJx@gmail.com","firstName":"crSMtAKNWrXaJJx","lastName":"crSMtAKNWr
  02:28:47.575 [front-end] Received response: "{\"firstName\":\"QGHrdp\",\"lastName\":\"QGHrdp\",\"username\":\"QGHrdp\",\"id\":\"673fec41b0df5c00019af98c\",\"_links\":{\"addresses\":{\"h
  02:28:50.618 [front-end] Received response: "{\"firstName\":\"XsZRA\",\"lastName\":\"XsZRA\",\"username\":\"XsZRA\",\"id\":\"673fec4ab0df5c00019af99b\",\"_links\":{\"addresses\":{\"href

## p0686
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice2, 2021-08-12T04:01:21.503Z
```
{"service":"redisservice2","message":"2021-08-12 04:01:21,503 | INFO | 0.0.0.2 | 172.17.0.4 | redisservice2 | bae4eb188fd64e39 | redis读取信息成功, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  04:01:14.751 [redisservice2] INFO redis write success  (×7)
  04:01:14.976 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×3)
  04:01:15.257 [redisservice2] INFO service accept, status_code: 200  (×2)
  04:01:15.901 [redisservice2] INFO redis读取信息成功, status_code: 200  (×8)
All services, 30 seconds either side (sampled):
  04:00:52.217 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×41)
  04:00:52.449 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  04:00:52.659 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'd4a3be98-fade-11eb-8f08-0242ac110003'}  (×45)
  04:00:52.869 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  04:00:55.183 [redisservice2] INFO redis write success  (×85)
  04:00:55.807 [dbservice2] INFO d65dee70-fade-11eb-9a27-0242ac110004-ZnrSqIKU-6AR>9IyOXx/3 token generate success token=MTYyODcxMjA1NS44MDcwNjc5OmQ2NWRlZTcwLWZhZGUtMTFlYi05YTI3LTAyNDJhYzE
  04:00:58.803 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×36)
  04:00:59.529 [mobservice1] INFO info d8c563be-fade-11eb-9409-0242ac110004:Bmsjcfbe write success
  04:01:01.448 [mobservice2] INFO info d9c1f4b2-fade-11eb-9990-0242ac110004:PzgvQsFL write success
  04:01:03.755 [mobservice2] INFO info db5563d6-fade-11eb-89db-0242ac110003:BlNycPMr write success
  04:01:06.597 [dbservice1] INFO dcbca7fc-fade-11eb-9d1d-0242ac110004-wzQhcEjW-&q(Z_ECc)a<V token generate success token=MTYyODcxMjA2Ni41OTY3OTc6ZGNiY2E3ZmMtZmFkZS0xMWViLTlkMWQtMDI0MmFjMTE
  04:01:09.056 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  04:01:11.119 [mobservice2] INFO info dfb71a28-fade-11eb-9021-0242ac110003:BdUrVbpI write success
  04:01:13.147 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  04:01:15.808 [mobservice1] INFO info e27b8906-fade-11eb-85e7-0242ac110003:YXLKvufE write success
  04:01:18.538 [mobservice1] INFO info e4175ace-fade-11eb-bbd2-0242ac110003:PNQwkDiG write success
  04:01:21.218 [dbservice2] INFO e57eaa20-fade-11eb-b8c1-0242ac110004-hRGCgxwP-w+ql$pvC=?c> token generate success token=MTYyODcxMjA4MS4yMTc1MDUyOmU1N2VhYTIwLWZhZGUtMTFlYi1iOGMxLTAyNDJhYzE
  04:01:23.480 [dbservice2] INFO e6eade2e-fade-11eb-8848-0242ac110003-zAFcSJGh-WGbA}P/<Tcy7 token generate success token=MTYyODcxMjA4My40Nzk4MTM4OmU2ZWFkZTJlLWZhZGUtMTFlYi04ODQ4LTAyNDJhYzE
  04:01:26.006 [dbservice2] INFO e8577038-fade-11eb-9053-0242ac110004-QSNmqeTf-X!?shln-IxLw token generate success token=MTYyODcxMjA4Ni4wMDU5NDY5OmU4NTc3MDM4LWZhZGUtMTFlYi05MDUzLTAyNDJhYzE
  04:01:28.676 [dbservice2] INFO e9e6020c-fade-11eb-b9a2-0242ac110004-ICpXWslJ-tkrd@G6KNM5v token generate success token=MTYyODcxMjA4OC42NzY1MDIyOmU5ZTYwMjBjLWZhZGUtMTFlYi1iOWEyLTAyNDJhYzE
  04:01:31.342 [dbservice1] INFO eb7c666a-fade-11eb-8bba-0242ac110003-COxkLyBN-!+trM_O$J5qZ token generate success token=MTYyODcxMjA5MS4zNDIyNzUxOmViN2M2NjZhLWZhZGUtMTFlYi04YmJhLTAyNDJhYzE
  04:01:34.199 [dbservice2] INFO ed3e1980-fade-11eb-be24-0242ac110004-zBtAqOdX-dNtBkshuAxiD token generate success token=MTYyODcxMjA5NC4xOTkxMTkzOmVkM2UxOTgwLWZhZGUtMTFlYi1iZTI0LTAyNDJhYzE
  04:01:36.826 [dbservice2] INFO eec800b8-fade-11eb-b5ec-0242ac110004-UOwaWosV-_2b:uq<KZh0F token generate success token=MTYyODcxMjA5Ni44MjYxNzM4OmVlYzgwMGI4LWZhZGUtMTFlYi1iNWVjLTAyNDJhYzE
  04:01:39.185 [dbservice1] INFO f02edb8e-fade-11eb-99a1-0242ac110004-qfINGhoa-rp/<7NyhULi4 token generate success token=MTYyODcxMjA5OS4xODQ3MTYyOmYwMmVkYjhlLWZhZGUtMTFlYi05OWExLTAyNDJhYzE
  04:01:42.032 [mobservice1] INFO info f215e4ba-fade-11eb-b666-0242ac110004:XibEQMJT write success
  04:01:44.910 [dbservice2] INFO f39dcba4-fade-11eb-8297-0242ac110004-HygISCUR-nDh8._Bb7*Ce token generate success token=MTYyODcxMjEwNC45MDk1MDY4OmYzOWRjYmE0LWZhZGUtMTFlYi04Mjk3LTAyNDJhYzE
  04:01:48.041 [dbservice2] INFO f57d5a5c-fade-11eb-8fb9-0242ac110004-zrnyoxBF-Sbqp@TrH_P6c token generate success token=MTYyODcxMjEwOC4wNDA5ODU2OmY1N2Q1YTVjLWZhZGUtMTFlYi04ZmI5LTAyNDJhYzE

## p0757
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T06:34:28.632Z
```
{"timestamp":1732257268632715000,"container_name":"carts","pod_name":"carts-78d749cf8c-x7fnt","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"com.mongodb.MongoSocketOpenException: Exception opening socket\n\tat com.mongodb.connection.SocketStream.open(SocketStream.java:63) ~[mongodb-driver-core-3.2.2.jar!/:na]\n\tat com.mongodb.connection.InternalStreamConnection.open(InternalStreamConnection.java:114) ~[mongodb-driver-core-3.2.2.jar!/:na]\n\tat com.mongodb.connection.DefaultServerMonitor$ServerMonitorRunnable.run(DefaultServerMonitor.java:14…"}
```
Same service, the 2 minutes before (oldest first):
  06:34:14.049 [carts] 2024-11-22 06:34:14.049 INFO [carts,85f08e33478cfdcc,e53a84c5fb874782,false] 7 --- [-nio-80-exec-10] w.w.s.cart.controllers.ItemsController : Did not find item.  (×3)
  06:34:14.054 [carts] 2024-11-22 06:34:14.053 INFO [carts,85f08e33478cfdcc,e53a84c5fb874782,false] 7 --- [-nio-80-exec-10] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×3)
  06:34:15.449 [carts] 2024-11-22 06:34:15.449 INFO [carts,9217e9cbc9e26920,796be3259aa59f9a,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  06:34:15.454 [carts] 2024-11-22 06:34:15.454 INFO [carts,9217e9cbc9e26920,796be3259aa59f9a,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
  06:34:15.463 [carts] 2024-11-22 06:34:15.462 INFO [carts,ab75350dfa59eac5,c1360182b055d96d,false] 7 --- [-nio-80-exec-14] w.w.s.cart.controllers.CartsController : Merge carts reques  (×6)
  06:34:16.497 [carts] 2024-11-22 06:34:16.497 INFO [carts,ad4d97235cefe909,f07fc992d872b33b,false] 7 --- [p-nio-80-exec-9] w.w.s.cart.controllers.CartsController : Merge carts reques  (×3)
  06:34:28.632 [carts] 2024-11-22 06:34:28.632 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Exception in monitor thread while connecting to server carts-db:270
All services, 30 seconds either side (sampled):
  06:33:58.632 [carts] 2024-11-22 06:33:58.632 INFO [carts,78a5263619c16dd4,6fcf450d91558801,false] 7 --- [-nio-80-exec-11] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×10)
  06:33:59.014 [front-end] User cart deleted with status: 202  (×54)
  06:33:59.055 [front-end] { id: '674025d7768f35000114f122' }  (×58)
  06:33:59.431 [front-end] Request received with body: {}  (×57)
  06:33:59.460 [user] ts=2024-11-22T06:33:59.460678246Z caller=middlewares.go:134 method=GetCards id=674025ce768f35000114f107 result=1 took=3.795827ms  (×57)
  06:33:59.478 [queue-master] Received shipment task: 674025c5768f35000114f0e6  (×15)
  06:33:59.483 [front-end] Order response: {"id":"674025d7531af4000701df35","customerId":"674025c4768f35000114f0e0","customer":{"id":null,"firstName":"vbEPCUDAuwhGBON","lastName":"vbEPCUD
  06:34:00.672 [user] ts=2024-11-22T06:34:00.672218502Z caller=middlewares.go:157 method=Health result=2 took=2.458409ms  (×40)
  06:34:01.849 [front-end] POST to carts: http://carts/carts/674025cf768f35000114f10e/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×29)
  06:34:04.887 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×7)
  06:34:06.719 [front-end] Order response: {"id":"674025de531af4000701df3a","customerId":"674025d1768f35000114f112","customer":{"id":null,"firstName":"SkVfq","lastName":"SkVfq","username"
  06:34:08.406 [front-end] Posting Customer: {"username":"eoblhrwisKUWKh","password":"nMmpoT","email":"eoblhrwisKUWKh@gmail.com","firstName":"eoblhrwisKUWKh","lastName":"eoblhrwisKUWKh"}
  06:34:10.978 [front-end] Posting Customer: {"username":"CLvztavBqZzMs","password":"lGhVH","email":"CLvztavBqZzMs@gmail.com","firstName":"CLvztavBqZzMs","lastName":"CLvztavBqZzMs"}
  06:34:13.425 [front-end] Posting Customer: {"username":"MamxkCrkxKz","password":"lmOMA","email":"MamxkCrkxKz@gmail.com","firstName":"MamxkCrkxKz","lastName":"MamxkCrkxKz"}
  06:34:15.867 [front-end] Posting Customer: {"username":"cXgorIbNVx","password":"bzMNhg","email":"cXgorIbNVx@gmail.com","firstName":"cXgorIbNVx","lastName":"cXgorIbNVx"}
  06:34:17.430 [front-end] Received response: "{\"firstName\":\"aQOvOuiac\",\"lastName\":\"aQOvOuiac\",\"username\":\"aQOvOuiac\",\"id\":\"674025d6768f35000114f11c\",\"_links\":{\"address
  06:34:19.647 [front-end] Posting Customer: {"username":"XQjfJgjaxN","password":"UoPBmHlpJ","email":"XQjfJgjaxN@gmail.com","firstName":"XQjfJgjaxN","lastName":"XQjfJgjaxN"}
  06:34:23.043 [user] ts=2024-11-22T06:34:23.043299668Z caller=middlewares.go:46 method=Register username=AhzMVmDC email=AhzMVmDC@gmail.com took=2.866068ms
  06:34:24.734 [user] ts=2024-11-22T06:34:24.734421165Z caller=middlewares.go:46 method=Register username=xZPoptlMd email=xZPoptlMd@gmail.com took=2.160575ms
  06:34:29.510 [front-end] Posting Customer: {"username":"rihiQz","password":"avnMz","email":"rihiQz@gmail.com","firstName":"rihiQz","lastName":"rihiQz"}
  06:34:32.929 [front-end] Received response: "{\"firstName\":\"GqmiLNPOmuQX\",\"lastName\":\"GqmiLNPOmuQX\",\"username\":\"GqmiLNPOmuQX\",\"id\":\"674025eb768f35000114f153\",\"_links\":{
  06:34:36.347 [front-end] Posting Customer: {"username":"vLgISaAaM","password":"hwUhSOiQ","email":"vLgISaAaM@gmail.com","firstName":"vLgISaAaM","lastName":"vLgISaAaM"}
  06:34:39.439 [user] ts=2024-11-22T06:34:39.439701877Z caller=middlewares.go:46 method=Register username=azefvfVc email=azefvfVc@gmail.com took=2.250605ms
  06:34:41.626 [user] ts=2024-11-22T06:34:41.625907119Z caller=middlewares.go:46 method=Register username=gmzbGrIz email=gmzbGrIz@gmail.com took=2.256599ms
  06:34:43.175 [front-end] Posting Customer: {"username":"UmxVKMRgrrQ","password":"eQpjiqwpK","email":"UmxVKMRgrrQ@gmail.com","firstName":"UmxVKMRgrrQ","lastName":"UmxVKMRgrrQ"}
  06:34:47.285 [front-end] Received response: "{\"firstName\":\"jZGRJq\",\"lastName\":\"jZGRJq\",\"username\":\"jZGRJq\",\"id\":\"674025e8768f35000114f14a\",\"_links\":{\"addresses\":{\"h
  06:34:50.373 [front-end] Received response: "{\"firstName\":\"KRIqomMxJllejCw\",\"lastName\":\"KRIqomMxJllejCw\",\"username\":\"KRIqomMxJllejCw\",\"id\":\"674025ed768f35000114f157\",\"_
  06:34:55.433 [front-end] Received response: "{\"firstName\":\"kmOTTiAmqtM\",\"lastName\":\"kmOTTiAmqtM\",\"username\":\"kmOTTiAmqtM\",\"id\":\"674025fb768f35000114f186\",\"_links\":{\"a
  06:34:57.573 [user] ts=2024-11-22T06:34:57.573437929Z caller=middlewares.go:46 method=Register username=xrtJOcF email=xrtJOcF@gmail.com took=2.004871ms

## p0637
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T20:23:56.503Z
```
{"timestamp":1733603036503360800,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-nsc8q","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:23:56.503  INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl             : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital"}
```
Same service, the 2 minutes before (oldest first):
  20:23:54.127 [ts-seat-service] 2024-12-07 20:23:54.127 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×2)
  20:23:54.136 [ts-seat-service] 2024-12-07 20:23:54.136 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  20:23:54.152 [ts-seat-service] 2024-12-07 20:23:54.152 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×2)
  20:23:54.152 [ts-seat-service] 2024-12-07 20:23:54.152 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  20:23:54.164 [ts-seat-service] 2024-12-07 20:23:54.164 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×2)
  20:23:55.330 [ts-seat-service] 2024-12-07 20:23:55.330 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN
  20:23:55.330 [ts-seat-service] 2024-12-07 20:23:55.330 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
  20:23:55.348 [ts-seat-service] 2024-12-07 20:23:55.348 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  20:23:55.361 [ts-seat-service] 2024-12-07 20:23:55.360 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:23:55.379 [ts-seat-service] 2024-12-07 20:23:55.379 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re
  20:23:55.379 [ts-seat-service] 2024-12-07 20:23:55.379 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  20:23:55.386 [ts-seat-service] 2024-12-07 20:23:55.385 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri
  20:23:55.418 [ts-seat-service] 2024-12-07 20:23:55.417 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×2)
  20:23:55.418 [ts-seat-service] 2024-12-07 20:23:55.417 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
All services, 30 seconds either side (sampled):
  20:23:26.508 [ts-travel-service] 2024-12-07 20:23:26.507 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：aefcef3f-3f42-46e8-afd7-6cb2a  (×70)
  20:23:26.571 [ts-travel2-service] 2024-12-07 20:23:26.570 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×171)
  20:23:29.423 [ts-auth-service] 2024-12-07 20:23:29.422 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×3)
  20:23:29.683 [ts-basic-service] 2024-12-07 20:23:29.683 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×10)
  20:23:29.716 [ts-travel2-service] 2024-12-07 20:23:29.715 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×19)
  20:23:29.879 [ts-seat-service] 2024-12-07 20:23:29.878 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×28)
  20:23:30.859 [ts-order-other-service] 2024-12-07 20:23:30.859 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×25)
  20:23:31.052 [ts-seat-service] 2024-12-07 20:23:31.052 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  20:23:31.721 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:23:31.720+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360301
  20:23:33.350 [ts-consign-service] 2024-12-07 20:23:33.350 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : The handle date is 2024-12-07  (×2)
  20:23:34.158 [ts-basic-service] 2024-12-07 20:23:34.158 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×4)
  20:23:34.276 [ts-order-service] 2024-12-07 20:23:34.276 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160,   (×2)
  20:23:34.621 [ts-preserve-service] 2024-12-07 20:23:34.621 INFO 1 --- [io-14568-exec-3] preserve.controller.PreserveController : [Preserve Service][Preserve] Account order from Shang Hai -----> S
  20:23:34.663 [ts-security-service] 2024-12-07 20:23:34.663 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service] Max In One Hour: 2147483647 Max Not Use: 21474836  (×2)
  20:23:34.686 [ts-travel-service] 2024-12-07 20:23:34.686 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  20:23:35.077 [ts-seat-service] 2024-12-07 20:23:35.077 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService distributeSeat] The result of getRouteResult is Success
  20:23:35.181 [ts-preserve-service] 2024-12-07 20:23:35.181 INFO 1 --- [io-14568-exec-3] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 4] Do Order Complete
  20:23:36.240 [ts-food-service] 2024-12-07 20:23:36.239 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  20:23:42.239 [ts-admin-basic-info-service] 2024-12-07 20:23:42.239 INFO 1 --- [io-18767-exec-2] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×5)
  20:23:56.470 [ts-inside-payment-service] 2024-12-07 20:23:56.469 INFO 1 --- [io-18673-exec-2] i.service.InsidePaymentServiceImpl : Out pay result: Response(status=1, msg=Pay Success, data=null)
  20:23:57.372 [ts-order-service] 2024-12-07 20:23:57.372 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : Left ticket info is empty  (×10)
  20:24:02.109 [ts-preserve-other-service] 2024-12-07 20:24:02.109 INFO 1 --- [io-14569-exec-4] p.controller.PreserveOtherController : [Preserve Other Service][Preserve] Account order from Shang Hai ----  (×2)
  20:24:02.148 [ts-preserve-other-service] 2024-12-07 20:24:02.147 INFO 1 --- [io-14569-exec-4] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security Complete.   (×2)
  20:24:02.221 [ts-basic-service] 2024-12-07 20:24:02.221 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×2)
  20:24:02.564 [ts-travel2-service] 2024-12-07 20:24:02.564 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×4)
  20:24:02.690 [ts-order-other-service] 2024-12-07 20:24:02.690 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Create Order] Create Order form shanghai --->  (×2)
  20:24:03.770 [ts-basic-service] 2024-12-07 20:24:03.770 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  20:24:09.969 [ts-order-other-service] 2024-12-07 20:24:09.969 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392
  20:24:15.338 [ts-travel-service] 2024-12-07 20:24:15.338 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan

## p0544
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T18:19:16.988Z
```
{"timestamp":1733595556988247600,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-kwkx6","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:19:16.988  INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl       : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Internal Success, data=1073741804)"}
```
Same service, the 2 minutes before (oldest first):
  18:19:15.385 [ts-travel2-service] 2024-12-07 18:19:15.385 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：20eb7122-3a11-423f-b10a-be0  (×5)
  18:19:15.398 [ts-travel2-service] 2024-12-07 18:19:15.398 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×5)
  18:19:16.606 [ts-travel2-service] 2024-12-07 18:19:16.606 INFO 1 --- [io-16346-exec-6] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  18:19:16.716 [ts-travel2-service] 2024-12-07 18:19:16.716 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  18:19:16.731 [ts-travel2-service] 2024-12-07 18:19:16.730 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  18:19:16.806 [ts-travel2-service] 2024-12-07 18:19:16.806 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  18:19:16.819 [ts-travel2-service] 2024-12-07 18:19:16.819 INFO 1 --- [io-16346-exec-2] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234  (×2)
  18:19:16.830 [ts-travel2-service] 2024-12-07 18:19:16.830 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  18:19:16.882 [ts-travel2-service] 2024-12-07 18:19:16.882 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int
All services, 30 seconds either side (sampled):
  18:18:47.716 [ts-admin-basic-info-service] 2024-12-07 18:18:47.715 INFO 1 --- [io-18767-exec-9] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×12)
  18:18:48.766 [ts-travel-service] 2024-12-07 18:18:48.766 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×28)
  18:18:54.109 [ts-travel-service] 2024-12-07 18:18:54.109 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×36)
  18:18:55.101 [ts-travel-service] 2024-12-07 18:18:55.101 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×15)
  18:18:57.395 [ts-auth-service] 2024-12-07 18:18:57.394 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×3)
  18:18:58.268 [ts-basic-service] 2024-12-07 18:18:58.268 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×19)
  18:18:58.325 [ts-travel2-service] 2024-12-07 18:18:58.325 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×3)
  18:18:58.437 [ts-order-other-service] 2024-12-07 18:18:58.437 INFO 1 --- [io-12032-exec-6] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×26)
  18:18:58.591 [ts-seat-service] 2024-12-07 18:18:58.590 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×15)
  18:19:05.622 [ts-order-other-service] 2024-12-07 18:19:05.622 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 18  (×3)
  18:19:06.924 [ts-order-service] 2024-12-07 18:19:06.924 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Query Order][Step 1] Get Orders Number of Account: 32
  18:19:12.821 [ts-contacts-service] 2024-12-07 18:19:12.821 INFO 1 --- [io-12347-exec-1] contacts.controller.ContactsController : [Contacts Service][Find Contacts By Account Id: 4d2a46c7-71cb-4cf1  (×2)
  18:19:12.865 [ts-order-service] 2024-12-07 18:19:12.865 INFO 1 --- [io-12031-exec-9] order.controller.OrderController : [Order Other Service][Security Info Get] 4d2a46c7-71cb-4cf1-b5bb-b68406d  (×2)
  18:19:12.972 [ts-contacts-service] 2024-12-07 18:19:12.971 INFO 1 --- [io-12347-exec-2] contacts.controller.ContactsController : [ContactsService][Contacts Id Print] d14da0ec-da93-46c3-842d-23fc3  (×2)
  18:19:13.780 [ts-preserve-other-service] 2024-12-07 18:19:13.780 INFO 1 --- [io-14569-exec-9] p.service.PreserveOtherServiceImpl : TripResponse : TripResponse(tripId=Z1234, startingStation=Shang Hai, t
  18:19:14.103 [ts-preserve-other-service] 2024-12-07 18:19:14.103 INFO 1 --- [io-14569-exec-9] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order Price] Price is: 350.0
  18:19:14.203 [ts-preserve-other-service] 2024-12-07 18:19:14.203 INFO 1 --- [io-14569-exec-9] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 6] Do not need to buy food
  18:19:18.380 [ts-basic-service] 2024-12-07 18:19:18.380 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×3)
  18:19:18.523 [ts-order-service] 2024-12-07 18:19:18.523 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×7)
  18:19:27.473 [ts-config-mongo] {"t":{"$date":"2024-12-07T18:19:27.473+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359556
  18:19:30.514 [ts-security-mongo] {"t":{"$date":"2024-12-07T18:19:30.514+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359557
  18:19:43.543 [ts-basic-service] 2024-12-07 18:19:43.543 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa
  18:19:43.734 [ts-seat-service] 2024-12-07 18:19:43.733 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes
  18:19:43.948 [ts-security-service] 2024-12-07 18:19:43.948 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Getting....
  18:19:43.997 [ts-preserve-service] 2024-12-07 18:19:43.997 INFO 1 --- [io-14568-exec-9] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] TripId: D1345
  18:19:44.389 [ts-preserve-service] 2024-12-07 18:19:44.389 INFO 1 --- [io-14568-exec-9] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 4] Do Order
  18:19:44.576 [ts-order-service] 2024-12-07 18:19:44.576 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 50.0
  18:19:44.633 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:19:44 +0800] "POST /api/v1/preserveservice/preserve HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWeb

## p0702
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-12T20:42:36.753Z
```
{"service":"webservice1","message":"2021-08-12 20:42:36,753 | ERROR | 0.0.0.1 | webservice1 | web_helper.py -> web_service_resource -> 210 | 4a982f0fb4a92305 | unknown error occurred, status_code == 200, message:{'message': 'redis write success, keys=bf7c9544-fb6a-11eb-b2e1-0242ac110003, value=', 'status_code': 200}"}
```
Same service, the 2 minutes before (oldest first):
  20:42:04.238 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×3)
  20:42:04.239 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'b25aabe4-fb6a-11eb-a799-0242ac110003', 'value': '', 'ex': 10}  (×3)
  20:42:04.312 [webservice1] INFO uuid: b25aabe4-fb6a-11eb-a799-0242ac110003 write redis successfully  (×3)
  20:42:04.417 [webservice1] INFO complete information: {'uuid': 'b25aabe4-fb6a-11eb-a799-0242ac110003', 'user_id': 'VizMUmJR'}  (×3)
  20:42:04.427 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×3)
  20:42:04.428 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  20:42:26.270 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
All services, 30 seconds either side (sampled):
  20:42:15.678 [webservice2] ERROR unknown error occurred, status_code == 200, message:{'message': 'redis write success, keys=b2e37b7c-fb6a-11eb-8c58-0242ac110004, value=', 'status_code': 2  (×4)
  20:42:15.781 [webservice2] INFO uuid: b933ada8-fb6a-11eb-9fab-0242ac110004 write redis successfully  (×24)
  20:42:15.950 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×31)
  20:42:16.169 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×23)
  20:42:16.230 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×23)
  20:42:16.302 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×22)
  20:42:18.702 [mobservice1] INFO info bac48980-fb6a-11eb-a4c4-0242ac110004:AnasJGMP write success
  20:42:26.316 [webservice1] INFO uuid: bf7c9544-fb6a-11eb-b2e1-0242ac110003 write redis successfully  (×24)
  20:42:26.689 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×25)
  20:42:26.812 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×24)
  20:42:37.231 [mobservice1] INFO info c5ccee26-fb6a-11eb-aef8-0242ac110004:ztuaUykM write success
  20:42:37.897 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×17)
  20:42:38.504 [dbservice1] INFO c648f822-fb6a-11eb-ad30-0242ac110004-vmFDrneJ-_z8e=yfpJqZ5 token generate success token=MTYyODc3MjE1OC41MDQxNDc4OmM2NDhmODIyLWZiNmEtMTFlYi1hZDMwLTAyNDJhYzE  (×2)
  20:42:40.777 [dbservice2] INFO c779c2ee-fb6a-11eb-8bfc-0242ac110004-sUWAVXFt-U.o}Q=LtOC%y token generate success token=MTYyODc3MjE2MC43NzcxNjI4OmM3NzljMmVlLWZiNmEtMTFlYi04YmZjLTAyNDJhYzE
  20:42:41.842 [webservice1] ERROR an error occurred in the downstream service
  20:42:43.855 [mobservice2] INFO info c9bdb740-fb6a-11eb-9902-0242ac110003:AsKCtDoY write success
  20:42:44.802 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  20:42:46.655 [dbservice2] INFO cb35038a-fb6a-11eb-a3be-0242ac110003-otxdGLkJ-:i2e%}c)9Xn8 token generate success token=MTYyODc3MjE2Ni42NTUwMTg6Y2IzNTAzOGEtZmI2YS0xMWViLWEzYmUtMDI0MmFjMTE
  20:42:48.025 [mobservice1] INFO info cc397766-fb6a-11eb-8057-0242ac110004:EQWxHTiy write success
  20:42:50.056 [mobservice1] INFO info cd6de784-fb6a-11eb-8564-0242ac110003:dsqULkKQ write success
  20:42:51.419 [mobservice1] INFO info ce39bf62-fb6a-11eb-97f7-0242ac110003:lebfEIwL write success
  20:42:53.077 [mobservice1] INFO info cf39db0e-fb6a-11eb-88fd-0242ac110004:kLYBXRtg write success
  20:42:55.120 [mobservice2] INFO info d073d420-fb6a-11eb-b5e3-0242ac110003:JIoWshby write success
  20:42:56.943 [mobservice1] INFO info d189f43e-fb6a-11eb-95e5-0242ac110003:OzKQAVJF write success
  20:42:58.584 [mobservice1] INFO info d28b34ba-fb6a-11eb-9703-0242ac110003:pDXcZzKl write success
  20:43:00.047 [mobservice2] INFO info d373c1f8-fb6a-11eb-b671-0242ac110004:bypSvsJC write success
  20:43:01.864 [mobservice1] INFO info d48379da-fb6a-11eb-a3a3-0242ac110004:KvpoNGOC write success
  20:43:03.377 [mobservice1] INFO info d5654ab8-fb6a-11eb-8f6f-0242ac110003:qHGVUSPX write success
  20:43:04.658 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  20:43:06.617 [mobservice1] INFO info d747e3cc-fb6a-11eb-b289-0242ac110003:lTpNeXrC write success

## p0242
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:03.068Z, and 22 identical event(s) in the same minute
```
{"timestamp":1732242483068542500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /cards 200 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}
  02:28:03.053 [front-end] POST /addresses 200 - ms - -
  02:28:03.059 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec2db0df5c00019af953"}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×28)
  02:28:03.122 [front-end] GET /catalogue 200 - ms - -  (×32)
  02:28:03.192 [front-end] POST /cards 200 - ms - -  (×27)
  02:28:03.211 [user] ts=2024-11-22T02:28:03.211690554Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=1.207621ms  (×36)
  02:28:03.252 [front-end] POST /orders 500 - ms - -  (×30)
  02:28:03.410 [front-end] Carts merged.  (×30)
  02:28:04.929 [front-end] Posting Customer: {"username":"JGQXvUjPbFrtK","password":"HtglbTyNG","email":"JGQXvUjPbFrtK@gmail.com","firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPbFrtK"}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:06.800 [user] ts=2024-11-22T02:28:06.800234478Z caller=middlewares.go:46 method=Register username=oyShDJ email=oyShDJ@gmail.com took=993.111µs
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.197 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×3)
  02:28:16.205 [front-end] Received response: "{\"firstName\":\"WiHheQzgSpJzgy\",\"lastName\":\"WiHheQzgSpJzgy\",\"username\":\"WiHheQzgSpJzgy\",\"id\":\"673fec2db0df5c00019af952\",\"_lin
  02:28:17.879 [user] ts=2024-11-22T02:28:17.879034554Z caller=middlewares.go:46 method=Register username=QGHrdp email=QGHrdp@gmail.com took=1.008054ms
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:21.971 [user] ts=2024-11-22T02:28:21.971606392Z caller=middlewares.go:46 method=Register username=PDQejFz email=PDQejFz@gmail.com took=1.195014ms
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=1.213µs  (×4)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.819 [front-end] Received response: "{\"firstName\":\"KoWsmDtUqsE\",\"lastName\":\"KoWsmDtUqsE\",\"username\":\"KoWsmDtUqsE\",\"id\":\"673fec2cb0df5c00019af949\",\"_links\":{\"a
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:25.786 [shipping] 2024-11-22 02:28:25.786 INFO [shipping,fb98be28dae5ea9a,b566bc7933720160,false] 7 --- [p-nio-80-exec-6] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.957 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","l
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFr
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:27.463 [orders-db] {"t":{"$date":"2024-11-22T02:28:27.462+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: java.lang.RuntimeException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock) at com.google.commo
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×12)

## p0324
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:21:03.086Z
```
{"timestamp":1732245663086606000,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:21:03.086  INFO [carts,,,] 7 --- [           main] o.s.b.a.e.mvc.EndpointHandlerMapping     : Mapped \"{[/heapdump || /heapdump.json],methods=[GET],produces=[application/octet-stream]}\" onto public void org.springframework.boot.actuate.endpoint.mvc.HeapdumpMvcEndpoint.invoke(boolean,javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse) throws java.io.IOExceptio…"}
```
Same service, the 2 minutes before (oldest first):
  03:20:59.788 [carts] 2024-11-22 03:20:59.788 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicati
  03:20:59.788 [carts] 2024-11-22 03:20:59.788 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[GET],produces=[  (×2)
  03:20:59.789 [carts] 2024-11-22 03:20:59.789 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],produc
  03:20:59.789 [carts] 2024-11-22 03:20:59.789 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces=
  03:20:59.790 [carts] 2024-11-22 03:20:59.789 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[OPTIONS],produces=[appli
  03:20:59.885 [carts] 2024-11-22 03:20:59.885 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[OPTIONS],produces=[appli
  03:20:59.886 [carts] 2024-11-22 03:20:59.885 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applicati  (×2)
  03:20:59.886 [carts] 2024-11-22 03:20:59.886 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[OPTIONS]}" onto public org.springfram
  03:20:59.886 [carts] 2024-11-22 03:20:59.886 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http.
  03:20:59.887 [carts] 2024-11-22 03:20:59.887 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframewor
  03:20:59.887 [carts] 2024-11-22 03:20:59.887 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[text/html]}" onto public 
  03:21:00.086 [carts] 2024-11-22 03:21:00.086 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionHa
  03:21:00.086 [carts] 2024-11-22 03:21:00.086 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframewo
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applicatio
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public jav
  03:21:03.084 [carts] 2024-11-22 03:21:03.083 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/
  03:21:03.084 [carts] 2024-11-22 03:21:03.084 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  03:21:03.086 [carts] 2024-11-22 03:21:03.085 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applicatio
All services, 30 seconds either side (sampled):
  03:20:33.094 [user] ts=2024-11-22T03:20:33.094037776Z caller=middlewares.go:157 method=Health result=2 took=808.783µs  (×34)
  03:20:33.227 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×34)
  03:20:34.032 [front-end] DELETE /cart 503 - ms - -  (×59)
  03:20:34.536 [front-end] Received response: "{\"firstName\":\"burOTnWrVFcFcR\",\"lastName\":\"burOTnWrVFcFcR\",\"username\":\"burOTnWrVFcFcR\",\"id\":\"673ff86eb0df5c00019b1ed0\",\"_lin
  03:20:36.114 [front-end] { id: '673ff884b0df5c00019b1f0d' }  (×53)
  03:20:37.986 [front-end] Posting Customer: {"username":"WwpBLC","password":"ngXKNthnRa","email":"WwpBLC@gmail.com","firstName":"WwpBLC","lastName":"WwpBLC"}
  03:20:40.151 [user] ts=2024-11-22T03:20:40.151621717Z caller=middlewares.go:46 method=Register username=dOIvn email=dOIvn@gmail.com took=1.048258ms
  03:20:43.388 [carts] 2024-11-22 03:20:43.388 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}/merge],methods=[GET]}" onto publi
  03:20:48.022 [front-end] Received response: "{\"firstName\":\"qXbvoaUIXMc\",\"lastName\":\"qXbvoaUIXMc\",\"username\":\"qXbvoaUIXMc\",\"id\":\"673ff880b0df5c00019b1f06\",\"_links\":{\"a
  03:20:49.809 [front-end] Posting Customer: {"username":"YwTYsSUGcmNRsJY","password":"vPzbHQOPY","email":"YwTYsSUGcmNRsJY@gmail.com","firstName":"YwTYsSUGcmNRsJY","lastName":"YwTYsSUGcmN
  03:20:54.561 [front-end] Posting Customer: {"username":"LNstXzKIIEKneJ","password":"NZVezpyHM","email":"LNstXzKIIEKneJ@gmail.com","firstName":"LNstXzKIIEKneJ","lastName":"LNstXzKIIEKneJ
  03:20:59.096 [front-end] Posting Customer: {"username":"mLiQP","password":"QVvyQW","email":"mLiQP@gmail.com","firstName":"mLiQP","lastName":"mLiQP"}
  03:20:59.689 [carts] 2024-11-22 03:20:59.689 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[applicati
  03:20:59.788 [carts] 2024-11-22 03:20:59.788 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicati
  03:21:01.131 [front-end] Posting Customer: {"username":"isaznhmc","password":"PMQNcLZhlo","email":"isaznhmc@gmail.com","firstName":"isaznhmc","lastName":"isaznhmc"}
  03:21:03.084 [carts] 2024-11-22 03:21:03.084 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  03:21:03.184 [carts] 2024-11-22 03:21:03.183 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces
  03:21:06.309 [front-end] Posting Customer: {"username":"IhtqcyEyd","password":"rqPnI","email":"IhtqcyEyd@gmail.com","firstName":"IhtqcyEyd","lastName":"IhtqcyEyd"}
  03:21:09.238 [front-end] Posting Customer: {"username":"pMqcnDbPZ","password":"kxLei","email":"pMqcnDbPZ@gmail.com","firstName":"pMqcnDbPZ","lastName":"pMqcnDbPZ"}
  03:21:12.165 [front-end] Received response: "{\"firstName\":\"nLZjIlByeidrL\",\"lastName\":\"nLZjIlByeidrL\",\"username\":\"nLZjIlByeidrL\",\"id\":\"673ff898b0df5c00019b1f41\",\"_links\
  03:21:14.093 [front-end] Posting Customer: {"username":"GaVMS","password":"VbNEvaWqm","email":"GaVMS@gmail.com","firstName":"GaVMS","lastName":"GaVMS"}
  03:21:16.220 [front-end] Posting Customer: {"username":"XSDCLJKgyLoxe","password":"WVMgfuZdos","email":"XSDCLJKgyLoxe@gmail.com","firstName":"XSDCLJKgyLoxe","lastName":"XSDCLJKgyLoxe"}
  03:21:18.595 [orders] 2024-11-22 03:21:18.594 INFO [orders,145906930ffa3fb8,359c2f868402564c,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×9)
  03:21:18.617 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8aed94b9000069b438b","customerId":"673ff896b0df5c00019b1f3b","customer":{"id":null,"firstName":"LNstXzKIIEK
  03:21:18.904 [front-end] Order response: {"id":"673ff8aed94b9000069b4390","customerId":"673ff896b0df5c00019b1f3a","customer":{"id":null,"firstName":"aZnbBrPviPwcYcC","lastName":"aZnbBrP
  03:21:19.502 [front-end] Order response: {"id":"673ff8afd94b9000069b4392","customerId":"673ff89eb0df5c00019b1f58","customer":{"id":null,"firstName":"sQAAadzpZlKDfq","lastName":"sQAAadzp
  03:21:20.407 [front-end] Order response: {"id":"673ff8b0d94b9000069b4397","customerId":"673ff899b0df5c00019b1f45","customer":{"id":null,"firstName":"pNgaEfQnfRl","lastName":"pNgaEfQnfRl
  03:21:21.517 [front-end] Order response: {"id":"673ff8b1d94b9000069b4399","customerId":"673ff89db0df5c00019b1f53","customer":{"id":null,"firstName":"EFvIPXnJWRPmy","lastName":"EFvIPXnJW
  03:21:25.703 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b5d94b9000069b439c","customerId":"673ff8a0b0df5c00019b1f5e","customer":{"id":null,"firstName":"qYmtssHEvF"
  03:21:28.688 [carts-db] {"t":{"$date":"2024-11-22T03:21:28.688+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224568

## p0530
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T11:00:28.653Z
```
{"timestamp":1732359628653147100,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 11:00:28.652  INFO [carts,3ad51a678a9e3f56,e5a1fb2b4de04ad3,false] 7 --- [-nio-80-exec-18] w.w.s.cart.controllers.ItemsController   : Did not find item. Creating item for user: 6741b5c4a437380001df5498, Item{id='6741b5ccf074bf0007005861', itemId='3395a43e-2d88-40de-b95f-e00e1502085b', quantity=1, unitPrice=18.0}"}
```
Same service, the 2 minutes before (oldest first):
  11:00:24.247 [carts] 2024-11-23 11:00:24.246 INFO [carts,22e10fd1c7fa35f4,b9ed755bd66e6de5,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.CartsController : Merge carts reques  (×5)
  11:00:24.613 [carts] 2024-11-23 11:00:24.613 INFO [carts,4baf69b3f6ed85f1,e3e5e384f7af6b58,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.ItemsController : Did not find item.  (×3)
  11:00:24.624 [carts] 2024-11-23 11:00:24.623 INFO [carts,4baf69b3f6ed85f1,e3e5e384f7af6b58,false] 7 --- [-nio-80-exec-16] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×3)
  11:00:24.752 [carts] 2024-11-23 11:00:24.752 INFO [carts,d899cb021860ba8b,a1d35d29289a94b3,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×3)
  11:00:25.211 [carts] 2024-11-23 11:00:25.210 INFO [carts,5741a60c85d1cb89,22f99bcade041e88,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.ItemsController : Did not find item.  (×3)
  11:00:25.220 [carts] 2024-11-23 11:00:25.220 INFO [carts,5741a60c85d1cb89,22f99bcade041e88,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×3)
All services, 30 seconds either side (sampled):
  10:59:58.849 [user] ts=2024-11-23T10:59:58.84893206Z caller=middlewares.go:157 method=Health result=2 took=1.833494ms  (×40)
  11:00:11.544 [front-end] Posting Customer: {"username":"RupAdllGjrdNv","password":"zJBnIlEK","email":"RupAdllGjrdNv@gmail.com","firstName":"RupAdllGjrdNv","lastName":"RupAdllGjrdNv"}
  11:00:11.565 [carts] 2024-11-23 11:00:11.564 INFO [carts,5a2e21a486490bc1,97896900cee9f8fe,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.CartsController : Merge carts reques  (×17)
  11:00:12.740 [front-end] Posting Customer: {"username":"hYeBtEGlGq","password":"fSKDYUx","email":"hYeBtEGlGq@gmail.com","firstName":"hYeBtEGlGq","lastName":"hYeBtEGlGq"}
  11:00:14.745 [front-end] Posting Customer: {"username":"XNHqPsYlIlUw","password":"brpClEgE","email":"XNHqPsYlIlUw@gmail.com","firstName":"XNHqPsYlIlUw","lastName":"XNHqPsYlIlUw"}
  11:00:16.620 [front-end] POST /addresses 200 - ms - -  (×18)
  11:00:16.717 [front-end] User cart deleted with status: 202  (×17)
  11:00:16.737 [front-end] POST to carts: http://carts/carts/6741b5bba437380001df548b/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×8)
  11:00:16.816 [user] ts=2024-11-23T11:00:16.816230287Z caller=middlewares.go:46 method=Register username=ZYyOEosw email=ZYyOEosw@gmail.com took=2.034356ms
  11:00:19.981 [front-end] POST to carts: http://carts/carts/6741b5bda437380001df548d/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}  (×9)
  11:00:20.710 [front-end] Posting Customer: {"username":"eciSh","password":"ncDSTD","email":"eciSh@gmail.com","firstName":"eciSh","lastName":"eciSh"}
  11:00:21.686 [front-end] Posting Customer: {"username":"AtPqbXfAZp","password":"EpoZfUN","email":"AtPqbXfAZp@gmail.com","firstName":"AtPqbXfAZp","lastName":"AtPqbXfAZp"}
  11:00:23.865 [catalogue] ts=2024-11-23T11:00:23Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=4.81605m
  11:00:24.738 [front-end] Posting Customer: {"username":"HOLUtFoSuMcUtKu","password":"taAJbEDhs","email":"HOLUtFoSuMcUtKu@gmail.com","firstName":"HOLUtFoSuMcUtKu","lastName":"HOLUtFoSuMc
  11:00:26.495 [orders-db] {"t":{"$date":"2024-11-23T11:00:26.495+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235962
  11:00:27.232 [user] ts=2024-11-23T11:00:27.232650455Z caller=middlewares.go:46 method=Register username=ZloLZze email=ZloLZze@gmail.com took=3.095882ms
  11:00:28.716 [user] ts=2024-11-23T11:00:28.715850808Z caller=middlewares.go:46 method=Register username=LomuEmw email=LomuEmw@gmail.com took=2.094766ms
  11:00:29.613 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  11:00:31.625 [front-end] Posting Customer: {"username":"rbqXF","password":"pcPTGVfA","email":"rbqXF@gmail.com","firstName":"rbqXF","lastName":"rbqXF"}
  11:00:32.066 [front-end] GET Request to: http://user/customers/6741b5bda437380001df548d/addresses  (×4)
  11:00:32.083 [front-end] Received response: "{\"firstName\":\"XNHqPsYlIlUw\",\"lastName\":\"XNHqPsYlIlUw\",\"username\":\"XNHqPsYlIlUw\",\"id\":\"6741b5bea437380001df548f\",\"_links\":{
  11:00:32.150 [orders] 2024-11-23 11:00:32.150 INFO [orders,5a6a0af7afe1a8a3,d3020c3723661a9c,false] 7 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Received payment re
  11:00:32.160 [queue-master] 2024-11-23 11:00:32.160 INFO 7 --- [ool-6-thread-23] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×6)
  11:00:32.165 [front-end] Order response: undefined
  11:00:32.178 [front-end] npm timing command:run-script Completed in 44217ms
  11:00:32.180 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!

## p0475
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:15:23.892Z
```
{"timestamp":1732349723892702000,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"[ undefined, undefined ]"}
```
Same service, the 2 minutes before (oldest first):
  08:15:23.169 [front-end] User cart deleted with status: 202
  08:15:23.170 [front-end] DELETE /cart 202 - ms - -
  08:15:23.177 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  08:15:23.183 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  08:15:23.183 [front-end] POST to carts: http://carts/carts/67418f11a437380001def2ef/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  08:15:23.215 [front-end] Posting Customer: {"username":"SDGnVaI","password":"xoXrMM","email":"SDGnVaI@gmail.com","firstName":"SDGnVaI","lastName":"SDGnVaI"}
  08:15:23.219 [front-end] POST /cart 201 - ms - -
  08:15:23.221 [front-end] { id: '67418f1ba437380001def30c' }
  08:15:23.221 [front-end] 67418f1ba437380001def30c
  08:15:23.221 [front-end] Merging carts for customer id: 67418f1ba437380001def30c and session id: GHvTkbTtNoGtCIrox953o9CDzhrk8AyP
  08:15:23.240 [front-end] Carts merged.
  08:15:23.240 [front-end] set cookie67418f1ba437380001def30c
  08:15:23.240 [front-end] Sent cookies.
  08:15:23.242 [front-end] POST /register 200 24.625 ms - 33
  08:15:23.872 [front-end] Request received with body: {}
  08:15:23.883 [front-end] Received response: "{\"firstName\":\"aTlufYtKJyT\",\"lastName\":\"aTlufYtKJyT\",\"username\":\"aTlufYtKJyT\",\"id\":\"67418f04a437380001def2cc\",\"_links\":{\"a
  08:15:23.883 [front-end] GET Request to: http://user/customers/67418f04a437380001def2cc/addresses  (×2)
  08:15:23.891 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418
  08:15:23.892 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418f0da437380001def2e1\",\"_links\":{\"
All services, 30 seconds either side (sampled):
  08:14:53.893 [user] ts=2024-11-23T08:14:53.893730052Z caller=middlewares.go:46 method=Register username=KVBrETy email=KVBrETy@gmail.com took=2.744821ms
  08:14:54.384 [catalogue] ts=2024-11-23T08:14:54Z caller=logging.go:85 method=Health result=2 took=22.642µs  (×40)
  08:14:54.744 [front-end] User cart deleted with status: 202  (×63)
  08:14:54.882 [front-end] GET Request to: http://user/customers/67418ef0a437380001def291/addresses  (×124)
  08:14:54.918 [queue-master] 2024-11-23 08:14:54.918 INFO 7 --- [pool-6-thread-1] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×16)
  08:14:55.849 [user] ts=2024-11-23T08:14:55.848956669Z caller=middlewares.go:157 method=Health result=2 took=1.997357ms  (×40)
  08:14:57.325 [front-end] Received response: "{\"firstName\":\"PTcjnx\",\"lastName\":\"PTcjnx\",\"username\":\"PTcjnx\",\"id\":\"67418ee6a437380001def273\",\"_links\":{\"addresses\":{\"h
  08:14:59.232 [queue-master] 2024-11-23 08:14:59.232 ERROR 7 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×41)
  08:15:00.025 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f043f77060008865009","customerId":"67418ef5a437380001def29f","customer":{"id":null,"firstName":"NlRCCubEmki
  08:15:02.414 [user] ts=2024-11-23T08:15:02.414810969Z caller=middlewares.go:46 method=Register username=iqBXFIPX email=iqBXFIPX@gmail.com took=1.891265ms
  08:15:05.179 [user] ts=2024-11-23T08:15:05.179843029Z caller=middlewares.go:46 method=Register username=YQCIbXWQ email=YQCIbXWQ@gmail.com took=2.412825ms
  08:15:10.218 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f0e3f7706000886500f","customerId":"67418efba437380001def2af","customer":{"id":null,"firstName":"hluImNKTx",
  08:15:11.855 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f0f3f77060008865012","customerId":"67418ef6a437380001def2a0","customer":{"id":null,"firstName":"PaSCOxuwbl"
  08:15:15.162 [payment] ts=2024-11-23T08:15:15Z caller=logging.go:29 method=Authorise result=false took=7.515µs  (×5)
  08:15:17.399 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f153f77060008865016","customerId":"67418f09a437380001def2d5","customer":{"id":null,"firstName":"YQCIbXWQ","
  08:15:19.108 [catalogue] ts=2024-11-23T08:15:19Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=5.37744m  (×5)
  08:15:21.093 [front-end] Received response: "{\"firstName\":\"AqYoRxQ\",\"lastName\":\"AqYoRxQ\",\"username\":\"AqYoRxQ\",\"id\":\"67418efda437380001def2ba\",\"_links\":{\"addresses\":{
  08:15:23.215 [front-end] Posting Customer: {"username":"SDGnVaI","password":"xoXrMM","email":"SDGnVaI@gmail.com","firstName":"SDGnVaI","lastName":"SDGnVaI"}
  08:15:25.543 [front-end] Posting Customer: {"username":"CzIgnUwvPBjP","password":"QlOfS","email":"CzIgnUwvPBjP@gmail.com","firstName":"CzIgnUwvPBjP","lastName":"CzIgnUwvPBjP"}
  08:15:32.235 [front-end] Posting Customer: {"username":"DJdlMsVNPI","password":"hGtxh","email":"DJdlMsVNPI@gmail.com","firstName":"DJdlMsVNPI","lastName":"DJdlMsVNPI"}
  08:15:33.945 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f253f77060008865022","customerId":"67418f12a437380001def2f0","customer":{"id":null,"firstName":"OklsUjDqBeW
  08:15:36.984 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f283f77060008865025","customerId":"67418f18a437380001def304","customer":{"id":null,"firstName":"IOXiucgdgNJ
  08:15:38.763 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f2a3f77060008865029","customerId":"67418f17a437380001def2fd","customer":{"id":null,"firstName":"VgjTNz","la
  08:15:41.849 [front-end] Received response: "{\"firstName\":\"nOnQrVhXrYY\",\"lastName\":\"nOnQrVhXrYY\",\"username\":\"nOnQrVhXrYY\",\"id\":\"67418f18a437380001def302\",\"_links\":{\"a
  08:15:43.700 [front-end] Received response: "{\"firstName\":\"sKVdDxEyWH\",\"lastName\":\"sKVdDxEyWH\",\"username\":\"sKVdDxEyWH\",\"id\":\"67418f22a437380001def32c\",\"_links\":{\"addr
  08:15:46.264 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f323f77060008865031","customerId":"67418f22a437380001def32b","customer":{"id":null,"firstName":"XyxWm","las
  08:15:48.372 [front-end] Received response: "{\"firstName\":\"GsNltevELW\",\"lastName\":\"GsNltevELW\",\"username\":\"GsNltevELW\",\"id\":\"67418f1ca437380001def30f\",\"_links\":{\"addr
  08:15:51.887 [front-end] Received response: "{\"firstName\":\"KuWIEdrxLXU\",\"lastName\":\"KuWIEdrxLXU\",\"username\":\"KuWIEdrxLXU\",\"id\":\"67418f22a437380001def32d\",\"_links\":{\"a

## p0167
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T06:26:03.628Z
```
{"timestamp":1731911163628505900,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Getting supported currencies..."}
```
Same service, the 2 minutes before (oldest first):
  06:26:02.244 [currencyservice] conversion request successful  (×17)
  06:26:02.699 [currencyservice] Getting supported currencies...  (×3)
All services, 30 seconds either side (sampled):
  06:25:33.629 [frontend] request started  (×326)
  06:25:33.636 [cartservice] GetCartAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43  (×264)
  06:25:33.659 [adservice] received ad request (context_words=[footwear])  (×14)
  06:25:34.573 [frontend] adding to cart  (×35)
  06:25:34.611 [shippingservice] [GetQuote] received request  (×82)
  06:25:34.846 [frontend] placing order  (×15)
  06:25:34.866 [paymentservice] Transaction processed: visa ending 5651 Amount: USD179.900000000  (×3)
  06:25:34.870 [shippingservice] [ShipOrder] completed request  (×15)
  06:25:34.880 [checkoutservice] order confirmation email sent to "elizabeth09@example.com"
  06:25:35.881 [adservice] received ad request (context_words=[kitchen])  (×57)
  06:25:36.854 [frontend] ENV_PLATFORM is: aws  (×34)
  06:25:37.846 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z']
  06:25:39.048 [paymentservice] Transaction processed: visa ending 9504 Amount: EUR3463.609022585  (×4)
  06:25:39.154 [checkoutservice] [PlaceOrder] user_id="33421b66-55b6-413b-9ba9-3230c85c58dc" user_currency="CAD"  (×4)
  06:25:39.189 [emailservice] A request to send order confirmation email to kanekimberly@example.org has been received.
  06:25:40.444 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"110829","nanos":487838165},"credit_card":{"credit_card_number":"42235373682  (×4)
  06:25:40.457 [checkoutservice] order confirmation email sent to "dennis73@example.net"
  06:25:45.683 [checkoutservice] order confirmation email sent to "browngabriela@example.com"
  06:25:58.050 [emailservice] A request to send order confirmation email to nicholasacosta@example.org has been received.
  06:25:58.585 [checkoutservice] order confirmation email sent to "dennisbryant@example.net"
  06:26:04.268 [emailservice] A request to send order confirmation email to audreycunningham@example.net has been received.
  06:26:04.360 [checkoutservice] order confirmation email sent to "dwatson@example.net"
  06:26:08.052 [redis] 63:C 18 Nov 2024 06:26:08.051 * DB saved on disk
  06:26:14.421 [emailservice] A request to send order confirmation email to lisaruiz@example.net has been received.
  06:26:17.488 [checkoutservice] order confirmation email sent to "ivan71@example.org"
  06:26:28.164 [emailservice] A request to send order confirmation email to pperry@example.net has been received.

## p0662
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-11T08:05:18.835Z
```
{"service":"webservice1","message":"2021-08-11 08:05:18,835 | ERROR | 0.0.0.1 | webservice1 | web_helper.py -> web_service_resource -> 100 | 3291546132099111 | get a error [Errno 2] No such file or directory: 'resources/source_file/source_file.csv'"}
```
Same service, the 2 minutes before (oldest first):
  08:05:15.380 [webservice1] ERROR get a error [Errno 2] No such file or directory: 'resources/source_file/source_file.csv'  (×4)
  08:05:15.444 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  08:05:15.445 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  08:05:15.445 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'ce30fc94-fa37-11eb-ac80-0242ac110003', 'value': '', 'ex': 10}  (×4)
  08:05:15.504 [webservice1] INFO uuid: ce30fc94-fa37-11eb-ac80-0242ac110003 write redis successfully  (×4)
All services, 30 seconds either side (sampled):
  08:04:48.888 [webservice2] INFO complete information: {'uuid': 'be4359ee-fa37-11eb-be13-0242ac110004', 'user_id': 'GxrcRlDj'}  (×65)
  08:04:49.043 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'be4359ee-fa37-11eb-be13-0242ac110004', 'value': 'GxrcRlDj'}  (×36)
  08:04:49.140 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'be4359ee-fa37-11eb-be13-0242ac110004'}  (×26)
  08:04:49.248 [logservice2] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×26)
  08:04:49.447 [dbservice1] INFO be4359ee-fa37-11eb-be13-0242ac110004-GxrcRlDj-Lw{tNT75j/%g token generate success token=MTYyODY0MDI4OS40NDY4OTk0OmJlNDM1OWVlLWZhMzctMTFlYi1iZTEzLTAyNDJhYzE
  08:04:49.814 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×29)
  08:04:49.942 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×39)
  08:04:50.097 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  08:04:50.719 [redisservice2] INFO redis读取信息成功, status_code: 200  (×38)
  08:04:51.072 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'bfa9d0d8-fa37-11eb-8b65-0242ac110003', 'value': '', 'ex': 10}  (×61)
  08:04:52.700 [mobservice1] INFO info c063cb8c-fa37-11eb-a0a6-0242ac110004:GZfYMFec write success
  08:04:54.465 [mobservice1] INFO info c16ba69e-fa37-11eb-b50b-0242ac110004:hLXtpSzb write success
  08:04:57.505 [dbservice1] INFO c30ddfda-fa37-11eb-872f-0242ac110004-nRDMHcrY-vKd#<PJBsz+5 token generate success token=MTYyODY0MDI5Ny41MDU0NTM4OmMzMGRkZmRhLWZhMzctMTFlYi04NzJmLTAyNDJhYzE
  08:05:00.797 [dbservice2] INFO c50d4424-fa37-11eb-ab44-0242ac110004-HwOItPMW-n7V8wc%z?O6g token generate success token=MTYyODY0MDMwMC43OTcyMzYyOmM1MGQ0NDI0LWZhMzctMTFlYi1hYjQ0LTAyNDJhYzE
  08:05:07.890 [dbservice1] INFO c93f6734-fa37-11eb-93e7-0242ac110004-MSLIBsQD-SeMQlNBV}$h# token generate success token=MTYyODY0MDMwNy44OTAxMDgzOmM5M2Y2NzM0LWZhMzctMTFlYi05M2U3LTAyNDJhYzE
  08:05:11.271 [dbservice2] INFO cb3a8b2c-fa37-11eb-8834-0242ac110004-QDmAuJjk-EsJd)P:SQx?. token generate success token=MTYyODY0MDMxMS4yNzA0NzQ0OmNiM2E4YjJjLWZhMzctMTFlYi04ODM0LTAyNDJhYzE
  08:05:13.743 [mobservice1] INFO info ccdfa07a-fa37-11eb-8357-0242ac110004:TAFqsYCb write success
  08:05:16.337 [dbservice2] INFO ce4baefe-fa37-11eb-ba1f-0242ac110004-yQDVrgJw-@}*Q:bp)gm/& token generate success token=MTYyODY0MDMxNi4zMzY0MzQxOmNlNGJhZWZlLWZhMzctMTFlYi1iYTFmLTAyNDJhYzE
  08:05:18.551 [dbservice2] INFO cf95b66a-fa37-11eb-87e3-0242ac110004-lEKkjfpD-^a37_&?:CJeS token generate success token=MTYyODY0MDMxOC41NTA3NzM6Y2Y5NWI2NmEtZmEzNy0xMWViLTg3ZTMtMDI0MmFjMTE
  08:05:21.886 [mobservice1] INFO info d1b2eada-fa37-11eb-85f1-0242ac110004:HmUeFxBl write success
  08:05:24.250 [dbservice1] INFO d2fd3fc6-fa37-11eb-aa4b-0242ac110004-pVIaJPSL-/6iJQ_4ro#jO token generate success token=MTYyODY0MDMyNC4yNTA0MzgyOmQyZmQzZmM2LWZhMzctMTFlYi1hYTRiLTAyNDJhYzE
  08:05:26.401 [dbservice2] INFO d44312b6-fa37-11eb-88a5-0242ac110004-vMrkdEDG-%Q+sGheOYc(R token generate success token=MTYyODY0MDMyNi40MDA4MjU1OmQ0NDMxMmI2LWZhMzctMTFlYi04OGE1LTAyNDJhYzE
  08:05:28.634 [mobservice2] INFO info d5d38b24-fa37-11eb-8f9b-0242ac110004:HodXCbQS write success
  08:05:32.034 [mobservice1] INFO info d7cbbce4-fa37-11eb-b1be-0242ac110004:QUpJkdTY write success
  08:05:34.010 [mobservice1] INFO info d904f0a8-fa37-11eb-8bcf-0242ac110004:dIHpsMvT write success
  08:05:36.871 [mobservice1] INFO info dab983aa-fa37-11eb-96db-0242ac110004:PbuDYKEa write success
  08:05:38.958 [mobservice2] INFO info dbf90434-fa37-11eb-93ce-0242ac110004:gQaRFlxY write success
  08:05:41.109 [dbservice2] INFO dd20e6d8-fa37-11eb-8267-0242ac110004-xhUTVXnF-Zmk_pM}XYJ>= token generate success token=MTYyODY0MDM0MS4xMDgzODAzOmRkMjBlNmQ4LWZhMzctMTFlYi04MjY3LTAyNDJhYzE
  08:05:44.160 [mobservice1] INFO info df0a6730-fa37-11eb-bd37-0242ac110004:MXIwargu write success
  08:05:46.781 [dbservice2] INFO e0721032-fa37-11eb-87e8-0242ac110004-lGPfCvhn-%)&.w4tO>XjE token generate success token=MTYyODY0MDM0Ni43ODA3MTE6ZTA3MjEwMzItZmEzNy0xMWViLTg3ZTgtMDI0MmFjMTE

## p0075
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice2, 2021-08-13T09:33:49.906Z
```
{"service":"logservice2","message":"2021-08-13 09:33:49,906 | INFO | 0.0.0.2 | 172.17.0.3 | logservice2 | 45a88c788b0921c0 | the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389"}
```
Same service, the 2 minutes before (oldest first):
  09:33:47.120 [logservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×3)
  09:33:47.121 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '80ccc9ec-fbd6-11eb-b055-0242ac110004'}  (×3)
  09:33:47.175 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×3)
  09:33:47.176 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
  09:33:47.176 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '80ccc9ec-fbd6-11eb-b055-0242ac110004', 'user_id': 'EVqCPZRD'}  (×4)
  09:33:47.914 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  09:33:49.241 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389
  09:33:49.242 [logservice2] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service
All services, 30 seconds either side (sampled):
  09:33:19.908 [mobservice2] INFO info 708bef18-fbd6-11eb-be80-0242ac110004:WRrkiQEt write success
  09:33:20.024 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×33)
  09:33:20.134 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '70a81a80-fbd6-11eb-bcff-0242ac110004', 'value': 'vUsGrNAF'}  (×47)
  09:33:20.879 [dbservice1] INFO 70a81a80-fbd6-11eb-bcff-0242ac110004-vUsGrNAF-saSGFzg5!M2_ token generate success token=MTYyODgxODQwMC44NzkxMTY4OjcwYTgxYTgwLWZiZDYtMTFlYi1iY2ZmLTAyNDJhYzE
  09:33:21.225 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×52)
  09:33:21.390 [redisservice1] INFO redis读取信息成功, status_code: 200  (×44)
  09:33:22.244 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  09:33:22.576 [webservice1] INFO complete information: {'uuid': '724be56a-fbd6-11eb-a726-0242ac110003', 'user_id': 'zFRIyZKg'}  (×39)
  09:33:24.694 [mobservice1] INFO info 737107ea-fbd6-11eb-bc4f-0242ac110003:RUxdhMNy write success
  09:33:27.601 [mobservice2] INFO info 752486d4-fbd6-11eb-8d00-0242ac110003:McHWnbKA write success
  09:33:30.926 [webservice2] ERROR an error occurred in the downstream service  (×5)
  09:33:33.624 [dbservice1] INFO 7865cdda-fbd6-11eb-81d2-0242ac110003-bHrMSWsj--%0VNhY.LywK token generate success token=MTYyODgxODQxMy42MjQ1MTU6Nzg2NWNkZGEtZmJkNi0xMWViLTgxZDItMDI0MmFjMTE
  09:33:35.809 [mobservice2] INFO info 7a0757e4-fbd6-11eb-b68b-0242ac110003:vpUgXqzC write success
  09:33:38.800 [mobservice2] INFO info 7bd19f9e-fbd6-11eb-a70b-0242ac110004:HfPCXKQO write success
  09:33:41.506 [dbservice2] INFO 7d42ae9a-fbd6-11eb-8b87-0242ac110004-GSgbqoFw-Y_*N-71D.6+R token generate success token=MTYyODgxODQyMS41MDYyODo3ZDQyYWU5YS1mYmQ2LTExZWItOGI4Ny0wMjQyYWMxMTA
  09:33:44.767 [dbservice1] INFO 7f231c2c-fbd6-11eb-b578-0242ac110003-eJFaBQoW-bScmY_uD{wZ* token generate success token=MTYyODgxODQyNC43NjY5ODc6N2YyMzFjMmMtZmJkNi0xMWViLWI1NzgtMDI0MmFjMTE
  09:33:47.943 [mobservice2] INFO info 8141316a-fbd6-11eb-9059-0242ac110004:vLPzKelQ write success
  09:33:50.587 [mobservice1] INFO info 82e42716-fbd6-11eb-b093-0242ac110004:LcsBuYDh write success
  09:33:52.984 [mobservice2] INFO info 844a73c6-fbd6-11eb-ac8d-0242ac110004:acGlMCEq write success
  09:33:55.790 [dbservice1] INFO 85b44890-fbd6-11eb-a19c-0242ac110004-OvVHWlKe-(vX2)-M{rxI! token generate success token=MTYyODgxODQzNS43OTA0MDY1Ojg1YjQ0ODkwLWZiZDYtMTFlYi1hMTljLTAyNDJhYzE
  09:33:58.496 [dbservice2] INFO 87442e5a-fbd6-11eb-b198-0242ac110004-qHGVUSPX-2X6L_bVf5*I< token generate success token=MTYyODgxODQzOC40OTU5NDc2Ojg3NDQyZTVhLWZiZDYtMTFlYi1iMTk4LTAyNDJhYzE
  09:34:01.261 [mobservice2] INFO info 891cdaba-fbd6-11eb-bc4d-0242ac110003:GYmWSxyu write success
  09:34:03.893 [dbservice2] INFO 8a9c9b32-fbd6-11eb-9640-0242ac110003-ZDqHGEXv-$Fe*7dcf0>Yv token generate success token=MTYyODgxODQ0My44OTI3NTA3OjhhOWM5YjMyLWZiZDYtMTFlYi05NjQwLTAyNDJhYzE
  09:34:06.856 [dbservice1] INFO 8c12ed90-fbd6-11eb-b9d7-0242ac110003-ITDnZiPv-&/KpJb3*X<kM token generate success token=MTYyODgxODQ0Ni44NTU5MDU1OjhjMTJlZDkwLWZiZDYtMTFlYi1iOWQ3LTAyNDJhYzE
  09:34:10.359 [mobservice1] INFO info 8e961ef2-fbd6-11eb-8d21-0242ac110003:VvLhTogZ write success
  09:34:14.486 [mobservice2] INFO info 9114a2e8-fbd6-11eb-89f7-0242ac110003:QUpJkdTY write success
  09:34:17.854 [mobservice2] INFO info 931c4974-fbd6-11eb-b2fe-0242ac110004:EAoGeZwV write success
