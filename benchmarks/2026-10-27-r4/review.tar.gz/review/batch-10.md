## p0671
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-11T13:22:49.500Z
```
{"service":"dbservice2","message":"2021-08-11 13:22:49,500 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | b6af7420243eccf1 | 2acf8408-fa64-11eb-9cbb-0242ac110004-KmknXdcJ-+YvF(9t@)hj> token generate success token=MTYyODY1OTM2OS40OTk1OTk1OjJhY2Y4NDA4LWZhNjQtMTFlYi05Y2JiLTAyNDJhYzExMDAwNEtta25YZGNKK1l2Rig5dEApaGo-OjE2Mjg2NTk0MjkuNDk5NjEwMjphMTA2ZGFmNTg3M2RmNDEzN2NhYWQ3ZjVmNDY0YTE3NA=="}
```
Same service, the 2 minutes before (oldest first):
  13:22:41.639 [dbservice2] INFO query = select passwards from username_table where user_name='pdAkGNZq'  (×5)
  13:22:41.719 [dbservice2] INFO 262d62b2-fa64-11eb-baec-0242ac110004-pdAkGNZq-7sD/*Q(>%?OT token generate success token=MTYyODY1OTM2MS43MTg3OTcyOjI2MmQ2MmIyLWZhNjQtMTFlYi1iYWVjLTAyNDJhYzE
  13:22:42.271 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  13:22:42.271 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  13:22:42.395 [dbservice2] INFO 269c0ce4-fa64-11eb-8022-0242ac110003-lYAOPtMm-rw)X>-}nmF+E token generate success token=MTYyODY1OTM2Mi4zOTQ5Mzg1OjI2OWMwY2U0LWZhNjQtMTFlYi04MDIyLTAyNDJhYzE
  13:22:43.240 [dbservice2] INFO 271c5cc8-fa64-11eb-b846-0242ac110004-bTcUudlx-Uo$*J-a97Ai} token generate success token=MTYyODY1OTM2My4yMzk5NzQzOjI3MWM1Y2M4LWZhNjQtMTFlYi1iODQ2LTAyNDJhYzE
  13:22:44.118 [dbservice2] INFO 279f06a0-fa64-11eb-8cb9-0242ac110004-EYeCRGvF-qeJXa2xuFhk0 token generate success token=MTYyODY1OTM2NC4xMTc1NTIzOjI3OWYwNmEwLWZhNjQtMTFlYi04Y2I5LTAyNDJhYzE
  13:22:48.572 [dbservice2] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
All services, 30 seconds either side (sampled):
  13:22:19.537 [redisservice1] INFO redis write success  (×98)
  13:22:19.777 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×48)
  13:22:19.980 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×47)
  13:22:20.153 [dbservice1] INFO query = select passwards from username_table where user_name='bHxAGyOk'  (×47)
  13:22:20.496 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×45)
  13:22:20.768 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×42)
  13:22:21.249 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×41)
  13:22:21.574 [dbservice2] INFO query = select passwards from username_table where user_name='ZzmSOCgj'  (×36)
  13:22:23.891 [mobservice2] INFO info 1bcf1306-fa64-11eb-a71a-0242ac110003:MfgEVxGn write success
  13:22:25.777 [dbservice1] INFO 1cb78906-fa64-11eb-b0e4-0242ac110003-IwBSEYcZ-(ytghoMs$0KL token generate success token=MTYyODY1OTM0NS43NzczOTQ1OjFjYjc4OTA2LWZhNjQtMTFlYi1iMGU0LTAyNDJhYzE
  13:22:28.429 [dbservice2] INFO 1e4030a2-fa64-11eb-9b5f-0242ac110003-oYbSglqf-udHk_>z3F5*y token generate success token=MTYyODY1OTM0OC40Mjk0MjU3OjFlNDAzMGEyLWZhNjQtMTFlYi05YjVmLTAyNDJhYzE
  13:22:30.573 [mobservice2] INFO info 1fc14448-fa64-11eb-9549-0242ac110003:kSydCulh write success
  13:22:33.238 [mobservice2] INFO info 2159e530-fa64-11eb-80bf-0242ac110003:DjVLApUI write success
  13:22:35.945 [dbservice2] INFO 22cefd60-fa64-11eb-be86-0242ac110004-bNtPLwUk-te7:(uF=xBg* token generate success token=MTYyODY1OTM1NS45NDQ3NTQ2OjIyY2VmZDYwLWZhNjQtMTFlYi1iZTg2LTAyNDJhYzE
  13:22:38.700 [dbservice2] INFO 245b07aa-fa64-11eb-adb9-0242ac110003-nHYqImvP-O=gXThaHNk%W token generate success token=MTYyODY1OTM1OC42OTk4OjI0NWIwN2FhLWZhNjQtMTFlYi1hZGI5LTAyNDJhYzExMDA
  13:22:41.543 [dbservice2] INFO 260416fa-fa64-11eb-b6a2-0242ac110004-jSevQlNq-y=u7{-jE?dDK token generate success token=MTYyODY1OTM2MS41NDI4MzMzOjI2MDQxNmZhLWZhNjQtMTFlYi1iNmEyLTAyNDJhYzE
  13:22:44.217 [mobservice2] INFO info 27e75b30-fa64-11eb-bd0e-0242ac110004:fVwtyQDn write success
  13:22:47.217 [mobservice2] INFO info 29ad50f0-fa64-11eb-9836-0242ac110003:VLUjOpcK write success
  13:22:50.365 [mobservice2] INFO info 2b85603e-fa64-11eb-a64a-0242ac110003:gFNpOQjC write success
  13:22:53.238 [dbservice1] INFO 2d120c04-fa64-11eb-8e09-0242ac110003-DuxqVwXb-ERb{q2=85rWf token generate success token=MTYyODY1OTM3My4yMzgwNTcxOjJkMTIwYzA0LWZhNjQtMTFlYi04ZTA5LTAyNDJhYzE
  13:22:56.630 [dbservice1] INFO 2f091246-fa64-11eb-a011-0242ac110003-dneSsIED-8P7mNRZk<p&e token generate success token=MTYyODY1OTM3Ni42MzA1NzM6MmYwOTEyNDYtZmE2NC0xMWViLWEwMTEtMDI0MmFjMTE
  13:22:59.720 [dbservice1] INFO 30d52da8-fa64-11eb-adf0-0242ac110004-EvQlkbnz-on9Yhr#0ZdmP token generate success token=MTYyODY1OTM3OS43MjAxOTM0OjMwZDUyZGE4LWZhNjQtMTFlYi1hZGYwLTAyNDJhYzE
  13:23:02.972 [mobservice1] INFO info 3317346c-fa64-11eb-9449-0242ac110003:UIkWCbjA write success
  13:23:05.530 [mobservice2] INFO info 349fd8b6-fa64-11eb-a52c-0242ac110003:bTcUudlx write success
  13:23:08.265 [dbservice1] INFO 36043a3a-fa64-11eb-92bd-0242ac110003-TpPSMOEF-P)x}eV<WmgRs token generate success token=MTYyODY1OTM4OC4yNjQ2NzQyOjM2MDQzYTNhLWZhNjQtMTFlYi05MmJkLTAyNDJhYzE
  13:23:10.897 [dbservice1] INFO 37a21038-fa64-11eb-a566-0242ac110003-cmBuyeUK-ZNQ?-Mu}LOAT token generate success token=MTYyODY1OTM5MC44OTc0NDI2OjM3YTIxMDM4LWZhNjQtMTFlYi1hNTY2LTAyNDJhYzE
  13:23:13.566 [mobservice2] INFO info 39695a3e-fa64-11eb-84fd-0242ac110004:wyIESLrY write success
  13:23:16.409 [mobservice2] INFO info 3b1e17fc-fa64-11eb-b05a-0242ac110003:WstfjpFZ write success
  13:23:19.225 [dbservice1] INFO 3c934ada-fa64-11eb-97dc-0242ac110004-rYEevjPt-9g@Kz:0PJDTN token generate success token=MTYyODY1OTM5OS4yMjU1MzgzOjNjOTM0YWRhLWZhNjQtMTFlYi05N2RjLTAyNDJhYzE

## p0338
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-22T03:21:20.802Z
```
{"timestamp":1732245680802754000,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-nz8kk","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-22 03:21:20.802 ERROR 6 --- [pool-6-thread-8] w.weave.socks.queuemaster.DockerSpawner  : Exception trying to launch/remove worker container. javax.ws.rs.ProcessingException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock)"}
```
Same service, the 2 minutes before (oldest first):
  03:21:20.403 [queue-master] 2024-11-22 03:21:20.402 INFO 6 --- [pool-6-thread-5] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×7)
  03:21:20.403 [queue-master] 2024-11-22 03:21:20.402 INFO 6 --- [pool-6-thread-5] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×7)
  03:21:20.404 [queue-master] 2024-11-22 03:21:20.403 ERROR 6 --- [pool-6-thread-5] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×2)
  03:21:20.404 [queue-master] Received shipment task: 673ff899b0df5c00019b1f45  (×2)
  03:21:20.404 [queue-master] 2024-11-22 03:21:20.404 INFO 6 --- [pool-6-thread-6] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×2)
All services, 30 seconds either side (sampled):
  03:20:51.094 [user] ts=2024-11-22T03:20:51.093850817Z caller=middlewares.go:157 method=Health result=2 took=763.852µs  (×34)
  03:20:51.502 [front-end] GET Request to: http://user/customers/673ff880b0df5c00019b1f04/addresses  (×112)
  03:20:51.556 [user] ts=2024-11-22T03:20:51.556549404Z caller=middlewares.go:104 method=GetAddresses id=673ff883b0df5c00019b1f0b result=1 took=1.037932ms  (×11)
  03:20:51.676 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×8)
  03:20:54.518 [front-end] Posting Customer: {"username":"aZnbBrPviPwcYcC","password":"cLxGTi","email":"aZnbBrPviPwcYcC@gmail.com","firstName":"aZnbBrPviPwcYcC","lastName":"aZnbBrPviPwcYc
  03:20:56.307 [front-end] Posting Customer: {"username":"TxflHMpaWteY","password":"HuykDEusv","email":"TxflHMpaWteY@gmail.com","firstName":"TxflHMpaWteY","lastName":"TxflHMpaWteY"}
  03:20:59.685 [carts] 2024-11-22 03:20:59.684 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[application/hal+json || 
  03:20:59.785 [carts] 2024-11-22 03:20:59.785 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[GE
  03:20:59.886 [carts] 2024-11-22 03:20:59.885 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applicati  (×2)
  03:21:02.584 [front-end] Posting Customer: {"username":"UFhesIA","password":"rCvijGSfoG","email":"UFhesIA@gmail.com","firstName":"UFhesIA","lastName":"UFhesIA"}
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:21:04.427 [front-end] Posting Customer: {"username":"qklQL","password":"OfLCWzLJmr","email":"qklQL@gmail.com","firstName":"qklQL","lastName":"qklQL"}
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetected
  03:21:10.780 [front-end] Received response: "{\"firstName\":\"MGpVgwryvJC\",\"lastName\":\"MGpVgwryvJC\",\"username\":\"MGpVgwryvJC\",\"id\":\"673ff894b0df5c00019b1f32\",\"_links\":{\"a
  03:21:13.304 [front-end] Received response: "{\"firstName\":\"XYDErsNhuY\",\"lastName\":\"XYDErsNhuY\",\"username\":\"XYDErsNhuY\",\"id\":\"673ff88fb0df5c00019b1f26\",\"_links\":{\"addr
  03:21:15.893 [carts-db] {"t":{"$date":"2024-11-22T03:21:15.892+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:5832  (×17)
  03:21:18.289 [carts] 2024-11-22 03:21:18.289 INFO [carts,fb7913950d676f18,6e117eba14b3663e,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{reposi  (×24)
  03:21:18.613 [queue-master] 2024-11-22 03:21:18.613 ERROR 6 --- [ool-6-thread-44] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×27)
  03:21:18.904 [front-end] Order response: {"id":"673ff8aed94b9000069b4390","customerId":"673ff896b0df5c00019b1f3a","customer":{"id":null,"firstName":"aZnbBrPviPwcYcC","lastName":"aZnbBrP
  03:21:19.679 [front-end] Received response: "{\"firstName\":\"qklQL\",\"lastName\":\"qklQL\",\"username\":\"qklQL\",\"id\":\"673ff8a0b0df5c00019b1f61\",\"_links\":{\"addresses\":{\"href
  03:21:20.407 [front-end] Order response: {"id":"673ff8b0d94b9000069b4396","customerId":"673ff893b0df5c00019b1f31","customer":{"id":null,"firstName":"nPklGOsvzh","lastName":"nPklGOsvzh",
  03:21:22.641 [front-end] Received response: "{\"firstName\":\"TxflHMpaWteY\",\"lastName\":\"TxflHMpaWteY\",\"username\":\"TxflHMpaWteY\",\"id\":\"673ff898b0df5c00019b1f40\",\"_links\":{
  03:21:26.847 [front-end] Received response: "{\"firstName\":\"gxEQQKdgPqad\",\"lastName\":\"gxEQQKdgPqad\",\"username\":\"gxEQQKdgPqad\",\"id\":\"673ff89fb0df5c00019b1f5d\",\"_links\":{
  03:21:32.045 [front-end] Posting Customer: {"username":"tEhusfT","password":"HAHzo","email":"tEhusfT@gmail.com","firstName":"tEhusfT","lastName":"tEhusfT"}
  03:21:34.256 [front-end] Order response: {"id":"673ff8bed94b9000069b439f","customerId":"673ff8a8b0df5c00019b1f85","customer":{"id":null,"firstName":"yXmVwShR","lastName":"yXmVwShR","use
  03:21:36.220 [front-end] Received response: "{\"firstName\":\"IhtqcyEyd\",\"lastName\":\"IhtqcyEyd\",\"username\":\"IhtqcyEyd\",\"id\":\"673ff8a2b0df5c00019b1f6d\",\"_links\":{\"address
  03:21:38.509 [front-end] Received response: "{\"firstName\":\"jStfWCKVIxuZsZx\",\"lastName\":\"jStfWCKVIxuZsZx\",\"username\":\"jStfWCKVIxuZsZx\",\"id\":\"673ff8acb0df5c00019b1f92\",\"_
  03:21:42.179 [user] ts=2024-11-22T03:21:42.179090694Z caller=middlewares.go:46 method=Register username=aQnXDQax email=aQnXDQax@gmail.com took=1.031852ms
  03:21:44.661 [user] ts=2024-11-22T03:21:44.661227434Z caller=middlewares.go:46 method=Register username=uJQuaCc email=uJQuaCc@gmail.com took=988.72µs
  03:21:49.448 [front-end] Order response: {"id":"673ff8cdd94b9000069b43ac","customerId":"673ff8b1b0df5c00019b1f9a","customer":{"id":null,"firstName":"XaQgsgBGh","lastName":"XaQgsgBGh","u

## p0726
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-14T18:55:41.502Z
```
{"service":"mobservice2","message":"2021-08-14 18:55:41,502 | INFO | 0.0.0.4 | 172.17.0.2 | mobservice2 | 58792c04c9550354 | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  18:55:37.765 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  18:55:37.765 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  18:55:37.765 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '2865765a-fcee-11eb-8963-0242ac110003'}  (×4)
  18:55:37.819 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '2865765a-fcee-11eb-8963-0242ac110003', 'value': 'NFrlOSIe'}  (×4)
  18:55:37.876 [mobservice2] INFO info 2865765a-fcee-11eb-8963-0242ac110003:NFrlOSIe write success
  18:55:39.080 [mobservice2] INFO info 290c2842-fcee-11eb-8b5c-0242ac110004:OKolGsUM write success
  18:55:39.917 [mobservice2] INFO info 299eff0a-fcee-11eb-ba22-0242ac110003:cUsPLdAz write success
  18:55:40.780 [mobservice2] INFO info 2a1ab7f8-fcee-11eb-8c36-0242ac110004:MxLzTnND write success
All services, 30 seconds either side (sampled):
  18:55:11.542 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  18:55:11.674 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×49)
  18:55:11.811 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×43)
  18:55:11.878 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×43)
  18:55:11.917 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×51)
  18:55:12.263 [webservice2] INFO uuid: 19515ab2-fcee-11eb-b77f-0242ac110004 write redis successfully  (×46)
  18:55:13.308 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×50)
  18:55:14.253 [mobservice1] INFO info 1a507114-fcee-11eb-9e18-0242ac110004:aZMCtwXA write success
  18:55:14.983 [dbservice1] INFO 1a7f144c-fcee-11eb-b430-0242ac110003-ToeLCkHR-(_n2MJ%R.Uw0 token generate success token=MTYyODkzODUxNC45ODMyMTEzOjFhN2YxNDRjLWZjZWUtMTFlYi1iNDMwLTAyNDJhYzE
  18:55:17.507 [mobservice2] INFO info 1c3f353c-fcee-11eb-93b7-0242ac110004:aLCdNFuD write success
  18:55:19.882 [mobservice2] INFO info 1da58e30-fcee-11eb-a0cd-0242ac110004:geuyhpUk write success
  18:55:22.715 [dbservice1] INFO 1f2b6a5e-fcee-11eb-afd9-0242ac110003-nlMAOLaH-.+x$_%GPZ*lV token generate success token=MTYyODkzODUyMi43MTUxOTc6MWYyYjZhNWUtZmNlZS0xMWViLWFmZDktMDI0MmFjMTE
  18:55:25.081 [dbservice2] INFO 2094ddee-fcee-11eb-9258-0242ac110004-lTYxuZoK-3UtL7AG$HnN5 token generate success token=MTYyODkzODUyNS4wODEzODY4OjIwOTRkZGVlLWZjZWUtMTFlYi05MjU4LTAyNDJhYzE
  18:55:28.411 [dbservice1] INFO 2282bbd0-fcee-11eb-80bc-0242ac110004-kWPHSeaC-nKV<}+zw:Zk% token generate success token=MTYyODkzODUyOC40MTA5MjE4OjIyODJiYmQwLWZjZWUtMTFlYi04MGJjLTAyNDJhYzE
  18:55:31.239 [dbservice1] INFO 24335566-fcee-11eb-a801-0242ac110004-rtRkpsfM-ul#Hy_*g:KTb token generate success token=MTYyODkzODUzMS4yMzkwODk1OjI0MzM1NTY2LWZjZWUtMTFlYi1hODAxLTAyNDJhYzE
  18:55:33.540 [dbservice2] INFO 25a79f60-fcee-11eb-b068-0242ac110004-etgkwBmP-D<TlS9enGxsY token generate success token=MTYyODkzODUzMy41Mzk4MjA0OjI1YTc5ZjYwLWZjZWUtMTFlYi1iMDY4LTAyNDJhYzE
  18:55:36.003 [dbservice1] INFO 2712172c-fcee-11eb-bde1-0242ac110003-cgKfeRjJ-?%FBPz^@kcZD token generate success token=MTYyODkzODUzNi4wMDI2MjM2OjI3MTIxNzJjLWZjZWUtMTFlYi1iZGUxLTAyNDJhYzE
  18:55:38.510 [dbservice1] INFO 28861c2a-fcee-11eb-8e30-0242ac110003-GLwvPubR-c9O=AoplwGk_ token generate success token=MTYyODkzODUzOC41MTA1MTY6Mjg4NjFjMmEtZmNlZS0xMWViLThlMzAtMDI0MmFjMTE  (×3)
  18:55:41.161 [dbservice1] INFO 2a1ab7f8-fcee-11eb-8c36-0242ac110004-MxLzTnND-Vr<g@j{uqoD> token generate success token=MTYyODkzODU0MS4xNjA3NDI4OjJhMWFiN2Y4LWZjZWUtMTFlYi04YzM2LTAyNDJhYzE
  18:55:43.872 [dbservice1] INFO 2bbbfa86-fcee-11eb-a93c-0242ac110004-dImbafKg-u#L?}jdp-2_5 token generate success token=MTYyODkzODU0My44NzI1NjgxOjJiYmJmYTg2LWZjZWUtMTFlYi1hOTNjLTAyNDJhYzE
  18:55:46.740 [mobservice2] INFO info 2da96e46-fcee-11eb-a9d2-0242ac110004:LEFinroh write success
  18:55:49.697 [dbservice1] INFO 2f2c535a-fcee-11eb-a292-0242ac110003-DGlMEFgf-hDX.AML@KH9e token generate success token=MTYyODkzODU0OS42OTY3MzgyOjJmMmM1MzVhLWZjZWUtMTFlYi1hMjkyLTAyNDJhYzE
  18:55:52.688 [mobservice2] INFO info 313b2b12-fcee-11eb-a489-0242ac110003:qhdLCnSU write success
  18:55:55.578 [dbservice1] INFO 32aea4c4-fcee-11eb-a361-0242ac110004-DhdfCMlE-06Cn#%rGUWLg token generate success token=MTYyODkzODU1NS41Nzc4MTE3OjMyYWVhNGM0LWZjZWUtMTFlYi1hMzYxLTAyNDJhYzE
  18:55:58.503 [mobservice1] INFO info 34a7e236-fcee-11eb-852a-0242ac110004:wkgeEpUD write success
  18:56:01.255 [dbservice1] INFO 36131f50-fcee-11eb-a2f7-0242ac110003-yjlLtMmx-<?.ZdYVR2js- token generate success token=MTYyODkzODU2MS4yNTU1NDIzOjM2MTMxZjUwLWZjZWUtMTFlYi1hMmY3LTAyNDJhYzE
  18:56:03.812 [dbservice2] INFO 3795bdb0-fcee-11eb-a69f-0242ac110004-NptDIkKG--%hyo201DjM@ token generate success token=MTYyODkzODU2My44MTIyMjQ5OjM3OTViZGIwLWZjZWUtMTFlYi1hNjlmLTAyNDJhYzE
  18:56:06.644 [mobservice1] INFO info 398ba9e0-fcee-11eb-9282-0242ac110003:ropVRsqh write success
  18:56:09.599 [mobservice1] INFO info 3b4aeaca-fcee-11eb-a7c5-0242ac110004:CzojFELq write success

## p0077
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-13T11:04:22.503Z
```
{"service":"mobservice2","message":"2021-08-13 11:04:22,503 | INFO | 0.0.0.4 | 172.17.0.2 | mobservice2 | 30933c897b11bd95 | info 28978b9c-fbe3-11eb-ac7d-0242ac110004:vMrkdEDG write success"}
```
Same service, the 2 minutes before (oldest first):
  11:04:17.908 [mobservice2] INFO info 25d4bf60-fbe3-11eb-9a69-0242ac110003:zepqgvua write success
  11:04:19.649 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  11:04:19.649 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  11:04:19.650 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '26f60c28-fbe3-11eb-9554-0242ac110004'}  (×4)
  11:04:19.704 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '26f60c28-fbe3-11eb-9554-0242ac110004', 'value': 'qwpdAUNi'}  (×4)
  11:04:19.772 [mobservice2] INFO info 26f60c28-fbe3-11eb-9554-0242ac110004:qwpdAUNi write success
  11:04:20.180 [mobservice2] INFO info 272d852c-fbe3-11eb-ba76-0242ac110004:JuoeTjfH write success
  11:04:21.606 [mobservice2] INFO info 280d805a-fbe3-11eb-886d-0242ac110003:GYgLnikZ write success
All services, 30 seconds either side (sampled):
  11:03:53.366 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×37)
  11:03:53.544 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×37)
  11:03:53.696 [mobservice1] INFO info 17650ff2-fbe3-11eb-8eb9-0242ac110004:wzuckBhX write success
  11:03:53.803 [logservice2] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': '17650ff2-fbe3-11eb-8eb9-0242ac110004', 'user_id': 'wzuckBhX'}  (×67)
  11:03:53.855 [dbservice2] INFO query = select passwards from username_table where user_name='wzuckBhX'  (×35)
  11:03:56.544 [webservice1] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×32)
  11:03:56.771 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×34)
  11:03:56.947 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×32)
  11:03:57.563 [mobservice2] INFO info 19b333f6-fbe3-11eb-911f-0242ac110003:HRlmyonZ write success
  11:04:00.006 [dbservice2] INFO 1aea80c6-fbe3-11eb-a6aa-0242ac110003-uGrcWJOt-Qj5b<4P!%R=0 token generate success token=MTYyODgyMzg0MC4wMDU2MToxYWVhODBjNi1mYmUzLTExZWItYTZhYS0wMjQyYWMxMTA
  11:04:02.535 [mobservice1] INFO info 1caa085a-fbe3-11eb-a6a2-0242ac110004:guYIhUdp write success
  11:04:05.688 [mobservice1] INFO info 1e88524e-fbe3-11eb-8875-0242ac110004:hTjCBtGX write success
  11:04:07.954 [dbservice1] INFO 1fb920da-fbe3-11eb-ad56-0242ac110004-YqjgnfMZ-{EM?P_3q2!OW token generate success token=MTYyODgyMzg0Ny45NTQ0NDE1OjFmYjkyMGRhLWZiZTMtMTFlYi1hZDU2LTAyNDJhYzE
  11:04:10.153 [mobservice1] INFO info 212c06bc-fbe3-11eb-b3b9-0242ac110003:vUOZQjfI write success
  11:04:12.425 [dbservice2] INFO 224a508a-fbe3-11eb-a6ff-0242ac110003-jnuiIECt-_JI:sCNEZ%ay token generate success token=MTYyODgyMzg1Mi40MjQ3NDE6MjI0YTUwOGEtZmJlMy0xMWViLWE2ZmYtMDI0MmFjMTE
  11:04:14.993 [mobservice1] INFO info 2401ba1c-fbe3-11eb-9dff-0242ac110003:roAFtIPD write success
  11:04:17.639 [dbservice1] INFO 2576ff10-fbe3-11eb-908c-0242ac110003-TpPSMOEF-P)x}eV<WmgRs token generate success token=MTYyODgyMzg1Ny42Mzg3MDc0OjI1NzZmZjEwLWZiZTMtMTFlYi05MDhjLTAyNDJhYzE
  11:04:20.255 [dbservice1] INFO 26f60c28-fbe3-11eb-9554-0242ac110004-qwpdAUNi-j-s(4p$@1:Fo token generate success token=MTYyODgyMzg2MC4yNTQ3MjU1OjI2ZjYwYzI4LWZiZTMtMTFlYi05NTU0LTAyNDJhYzE
  11:04:23.527 [mobservice1] INFO info 29295338-fbe3-11eb-8581-0242ac110003:cwpAkUMO write success
  11:04:26.395 [mobservice1] INFO info 2adae048-fbe3-11eb-8baa-0242ac110004:NdFpoUqE write success  (×2)
  11:04:28.918 [mobservice1] INFO info 2c56e782-fbe3-11eb-8387-0242ac110003:HRlmyonZ write success
  11:04:30.771 [dbservice2] INFO 2d5752a2-fbe3-11eb-91b2-0242ac110003-eVrbptqN-qVn/ZNM0.hLm token generate success token=MTYyODgyMzg3MC43NzA1MTA3OjJkNTc1MmEyLWZiZTMtMTFlYi05MWIyLTAyNDJhYzE
  11:04:33.426 [mobservice1] INFO info 2f148394-fbe3-11eb-ae92-0242ac110004:bJsneyVk write success
  11:04:35.793 [dbservice2] INFO 301cc97c-fbe3-11eb-9d65-0242ac110003-ZkYfGaQs-EO%p*!{rP$?q token generate success token=MTYyODgyMzg3NS43OTMyNDU6MzAxY2M5N2MtZmJlMy0xMWViLTlkNjUtMDI0MmFjMTE
  11:04:38.816 [mobservice2] INFO info 3253d3e8-fbe3-11eb-bdbf-0242ac110003:jInFtBJp write success
  11:04:42.435 [dbservice1] INFO 34467c78-fbe3-11eb-ba1a-0242ac110003-PYTAOBbU-?_0$ahXc=Yv! token generate success token=MTYyODgyMzg4Mi40MzQ2OTg2OjM0NDY3Yzc4LWZiZTMtMTFlYi1iYTFhLTAyNDJhYzE
  11:04:52.474 [mobservice2] INFO info 3a77455a-fbe3-11eb-8b5d-0242ac110003:bsnOITed write success

## p0308
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:20:17.957Z
```
{"timestamp":1732245617957841700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"statusCode\":500,\"body\":{\"timestamp\":1732245617955,\"status\":500,\"error\":\"Internal Server Error\",\"exception\":\"java.lang.IllegalStateException\",\"message\":\"Unable to create order due to unspecified IO error.\",\"path\":\"/orders\"},\"headers\":{\"x-application-context\":\"orders:80\",\"content-type\":\"application/json;charset=UTF-8\",\"date\":\"Fri, 22 Nov 2024 03:20:17 GMT\",\"x-envoy-upstream-service…"}
```
Same service, the 2 minutes before (oldest first):
  03:20:17.428 [front-end] Carts merged.
  03:20:17.428 [front-end] set cookie673ff871b0df5c00019b1eda
  03:20:17.428 [front-end] Sent cookies.
  03:20:17.430 [front-end] POST /register 200 62.774 ms - 33
  03:20:17.831 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff86bb0df5c00019b1ec4"}
  03:20:17.841 [front-end] POST /addresses 200 - ms - -
  03:20:17.846 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff86bb0df5c00019b1ec4"}
  03:20:17.855 [front-end] POST /cards 200 - ms - -
  03:20:17.885 [front-end] Request received with body: {}
  03:20:17.892 [front-end] Received response: "{\"firstName\":\"wBdnXRcm\",\"lastName\":\"wBdnXRcm\",\"username\":\"wBdnXRcm\",\"id\":\"673ff861b0df5c00019b1e9e\",\"_links\":{\"addresses\
  03:20:17.892 [front-end] GET Request to: http://user/customers/673ff861b0df5c00019b1e9e/addresses  (×2)
  03:20:17.900 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff866b0df5c00019b1eac\",\"_links\":{\"
  03:20:17.900 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:20:17.900 [front-end] [ undefined, undefined ]
  03:20:17.900 [front-end] Posting Order: {"customer":"http://user/customers/673ff861b0df5c00019b1e9e","address":"http://user/addresses/673ff866b0df5c00019b1eab","card":"http://user/cards
  03:20:17.900 [front-end] Attempting to delete cart for user: 673ff86bb0df5c00019b1ec4
  03:20:17.949 [front-end] User cart deleted with status: 503
  03:20:17.951 [front-end] DELETE /cart 503 - ms - -
  03:20:17.957 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×27)
  03:20:06.543 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff854b0df5c00019b1e7f\",\"_links\":{\"  (×44)
  03:20:06.586 [orders] 2024-11-22 03:20:06.586 ERROR [orders,,,] 6 --- [p-nio-80-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×26)
  03:20:06.649 [user] ts=2024-11-22T03:20:06.649242768Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff861b0df5c00019b1e9e took=1.734848ms  (×44)
  03:20:06.769 [front-end] User cart deleted with status: 503  (×44)
  03:20:06.803 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×7)
  03:20:07.186 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×9)
  03:20:08.469 [front-end] Posting Customer: {"username":"HNCLfJfsnW","password":"sSvsy","email":"HNCLfJfsnW@gmail.com","firstName":"HNCLfJfsnW","lastName":"HNCLfJfsnW"}
  03:20:08.498 [front-end] Carts merged.  (×35)
  03:20:09.093 [user] ts=2024-11-22T03:20:09.093533288Z caller=middlewares.go:46 method=Register username=CBhyKd email=CBhyKd@gmail.com took=1.350871ms
  03:20:09.192 [carts] 2024-11-22 03:20:09.192 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  03:20:10.049 [front-end] Posting Customer: {"username":"lPEGqahDSutlQTj","password":"AoWWVDzGsz","email":"lPEGqahDSutlQTj@gmail.com","firstName":"lPEGqahDSutlQTj","lastName":"lPEGqahDSu
  03:20:12.002 [front-end] Received response: "{\"firstName\":\"oVuSYHHeDcohK\",\"lastName\":\"oVuSYHHeDcohK\",\"username\":\"oVuSYHHeDcohK\",\"id\":\"673ff855b0df5c00019b1e85\",\"_links\
  03:20:14.429 [front-end] Posting Customer: {"username":"LWbxoNrjdrYfe","password":"dgukoXmQfq","email":"LWbxoNrjdrYfe@gmail.com","firstName":"LWbxoNrjdrYfe","lastName":"LWbxoNrjdrYfe"}
  03:20:16.376 [front-end] Posting Customer: {"username":"zCHyJV","password":"DBVYLG","email":"zCHyJV@gmail.com","firstName":"zCHyJV","lastName":"zCHyJV"}
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:20.340 [front-end] Posting Customer: {"username":"BBYdunXrngQk","password":"jbihHjN","email":"BBYdunXrngQk@gmail.com","firstName":"BBYdunXrngQk","lastName":"BBYdunXrngQk"}
  03:20:23.473 [front-end] Received response: "{\"firstName\":\"AIHRSQU\",\"lastName\":\"AIHRSQU\",\"username\":\"AIHRSQU\",\"id\":\"673ff863b0df5c00019b1ea2\",\"_links\":{\"addresses\":{
  03:20:26.017 [front-end] Posting Customer: {"username":"HLNoIPafm","password":"sBlBYfK","email":"HLNoIPafm@gmail.com","firstName":"HLNoIPafm","lastName":"HLNoIPafm"}
  03:20:28.421 [front-end] Posting Customer: {"username":"MoGml","password":"PJpiau","email":"MoGml@gmail.com","firstName":"MoGml","lastName":"MoGml"}
  03:20:30.252 [front-end] Posting Customer: {"username":"MKGIsEbVYi","password":"VhFAQhsXw","email":"MKGIsEbVYi@gmail.com","firstName":"MKGIsEbVYi","lastName":"MKGIsEbVYi"}
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.186 [front-end] Received response: "{\"firstName\":\"kgzVKACfUvkHp\",\"lastName\":\"kgzVKACfUvkHp\",\"username\":\"kgzVKACfUvkHp\",\"id\":\"673ff869b0df5c00019b1ebd\",\"_links\
  03:20:36.109 [front-end] Posting Customer: {"username":"HWsmCvxoMrNqX","password":"MJvuU","email":"HWsmCvxoMrNqX@gmail.com","firstName":"HWsmCvxoMrNqX","lastName":"HWsmCvxoMrNqX"}
  03:20:38.070 [session-db] 1:M 22 Nov 2024 03:20:38.070 * Background saving started by pid 32
  03:20:39.079 [user] ts=2024-11-22T03:20:39.079141282Z caller=middlewares.go:46 method=Register username=ELXzX email=ELXzX@gmail.com took=1.044635ms
  03:20:42.525 [front-end] Posting Customer: {"username":"jVIVRgJfOAq","password":"zWZXxq","email":"jVIVRgJfOAq@gmail.com","firstName":"jVIVRgJfOAq","lastName":"jVIVRgJfOAq"}
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:20:43.391 [carts] 2024-11-22 03:20:43.391 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:20:47.743 [front-end] Received response: "{\"firstName\":\"MoGml\",\"lastName\":\"MoGml\",\"username\":\"MoGml\",\"id\":\"673ff87cb0df5c00019b1efd\",\"_links\":{\"addresses\":{\"href

## p0805
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-service, 2024-12-08T09:15:45.507Z
```
{"timestamp":1733649345507493600,"container_name":"ts-order-service","pod_name":"ts-order-service-7596478c9d-4jc2t","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"java.lang.IllegalArgumentException: Invalid UUID string: \n\tat java.util.UUID.fromString(UUID.java:194) ~[na:1.8.0_402]\n\tat order.service.OrderServiceImpl.queryOrders(OrderServiceImpl.java:107) ~[classes!/:1.0]\n\tat order.service.OrderServiceImpl.queryOrdersForRefresh(OrderServiceImpl.java:167) ~[classes!/:1.0]\n\tat order.controller.OrderController.queryOrdersForRefresh(OrderController.java:69) ~[cla…"}
```
Same service, the 2 minutes before (oldest first):
  09:15:26.143 [ts-order-service] 2024-12-08 09:15:26.143 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024  (×4)
  09:15:26.148 [ts-order-service] 2024-12-08 09:15:26.148 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=625927415,   (×4)
  09:15:26.342 [ts-order-service] 2024-12-08 09:15:26.342 INFO 1 --- [io-12031-exec-5] order.controller.OrderController : [Order Other Service][Security Info Get] 4d2a46c7-71cb-4cf1-b5bb-b68406d
  09:15:26.515 [ts-order-service] 2024-12-08 09:15:26.515 INFO 1 --- [io-12031-exec-3] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:00:00 
  09:15:26.519 [ts-order-service] 2024-12-08 09:15:26.519 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 56
  09:15:26.813 [ts-order-service] 2024-12-08 09:15:26.813 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024
  09:15:26.818 [ts-order-service] 2024-12-08 09:15:26.818 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=625927415, 
  09:15:26.843 [ts-order-service] 2024-12-08 09:15:26.843 INFO 1 --- [io-12031-exec-9] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at 
  09:15:26.843 [ts-order-service] 2024-12-08 09:15:26.843 INFO 1 --- [io-12031-exec-9] order.controller.OrderController : [Order Service][Verify Login] Success
  09:15:26.843 [ts-order-service] 2024-12-08 09:15:26.843 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Create Order] Ready Create Order.
  09:15:26.850 [ts-order-service] 2024-12-08 09:15:26.850 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Order Create] Success.
  09:15:26.850 [ts-order-service] 2024-12-08 09:15:26.850 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 50.0
  09:15:45.493 [ts-order-service] 2024-12-08 09:15:45.493 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 
  09:15:45.507 [ts-order-service] 2024-12-08 09:15:45.505 ERROR 1 --- [io-12031-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
All services, 30 seconds either side (sampled):
  09:15:15.512 [ts-admin-travel-service] 2024-12-08 09:15:15.511 INFO 1 --- [io-16114-exec-1] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×5)
  09:15:15.595 [ts-admin-travel-service] 2024-12-08 09:15:15.595 INFO 1 --- [io-16114-exec-1] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×10)
  09:15:17.042 [ts-order-other-service] 2024-12-08 09:15:17.042 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Order By Id] Order Id: d10f2065-65aa-4b6c
  09:15:18.004 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:15:18 +0800] "POST /api/v1/users/login HTTP/1.1" 200 353 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×7)
  09:15:20.187 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:15:20 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 5994 "-" "Mozilla/5.0 (Macintosh;  (×4)
  09:15:20.591 [ts-basic-service] 2024-12-08 09:15:20.591 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×6)
  09:15:20.645 [ts-order-other-service] 2024-12-08 09:15:20.645 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 40  (×10)
  09:15:20.778 [ts-seat-service] 2024-12-08 09:15:20.777 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×18)
  09:15:25.956 [ts-travel-service] 2024-12-08 09:15:25.955 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×16)
  09:15:26.102 [ts-basic-service] 2024-12-08 09:15:26.102 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×2)
  09:15:26.254 [ts-seat-service] 2024-12-08 09:15:26.254 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  09:15:26.313 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:15:26 +0800] "GET /api/v1/contactservice/contacts/account/4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f HTTP/1.1" 200 471 "-" "Mozilla/5.0 
  09:15:26.360 [ts-security-service] 2024-12-08 09:15:26.359 INFO 1 --- [io-11188-exec-7] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Last One Hour:
  09:15:26.383 [ts-preserve-service] 2024-12-08 09:15:26.383 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] Check tickets num
  09:15:26.606 [ts-price-service] 2024-12-08 09:15:26.606 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×2)
  09:15:26.711 [ts-preserve-service] 2024-12-08 09:15:26.711 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : TripResponse:TripResponse(tripId=D1345, startingStation=Shang Hai, t
  09:15:26.818 [ts-order-service] 2024-12-08 09:15:26.818 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=625927415, 
  09:15:26.847 [ts-travel2-service] 2024-12-08 09:15:26.847 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×20)
  09:15:31.405 [ts-auth-service] 2024-12-08 09:15:31.404 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  09:15:31.811 [ts-auth-service] 2024-12-08 09:15:31.811 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:38}] to ts-auth-mongo:2  (×3)
  09:15:40.529 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:15:40 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 403 145 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×11)
  09:15:49.751 [ts-seat-service] 2024-12-08 09:15:49.746 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×5)
  09:15:50.142 [ts-travel-service] 2024-12-08 09:15:50.142 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1236
  09:15:56.293 [ts-auth-service] 2024-12-08 09:15:56.293 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.configuration.ObjectP
  09:16:01.096 [ts-auth-service] 2024-12-08 09:16:01.096 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 12340 (http)
  09:16:04.787 [ts-auth-service] 2024-12-08 09:16:04.787 INFO 1 --- [ost-startStop-1] .s.DelegatingFilterProxyRegistrationBean : Mapping filter: 'springSecurityFilterChain' to: [/*]
  09:16:09.899 [ts-train-mongo] {"t":{"$date":"2024-12-08T09:16:09.899+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364936
  09:16:10.304 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-08T09:16:10.304+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364937
  09:16:13.348 [ts-food-mongo] {"t":{"$date":"2024-12-08T09:16:13.348+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364937

## p0132
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:24:39.309Z
```
{"timestamp":1731907479309140700,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  05:24:38.366 [frontend] view user cart
  05:24:38.401 [frontend] request complete  (×4)
  05:24:38.970 [frontend] request started  (×4)
  05:24:38.970 [frontend] serving product page  (×2)
  05:24:38.987 [frontend] setting currency
  05:24:38.990 [frontend] home
  05:24:38.998 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14  (×3)
  05:24:38.999 [frontend] failed to retrieve ads  (×3)
  05:24:39.036 [frontend] ENV_PLATFORM is: aws
All services, 30 seconds either side (sampled):
  05:24:09.560 [frontend] request started  (×283)
  05:24:09.562 [currencyservice] Getting supported currencies...  (×239)
  05:24:09.574 [currencyservice] conversion request successful  (×691)
  05:24:09.615 [frontend] failed to retrieve ads  (×172)
  05:24:09.619 [frontend] request complete  (×282)
  05:24:09.819 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', 'L9ECAV7KIM', 'OLJCESPC7Z', '66VCHSJNUP', '2ZYFJ3GM2N']  (×195)
  05:24:10.809 [shippingservice] [GetQuote] received request  (×68)
  05:24:10.888 [frontend] setting currency  (×18)
  05:24:11.177 [cartservice] AddItemAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03, productId=0PUK6V6EV0, quantity=2  (×25)
  05:24:25.848 [adservice] Stats enabled, but temporarily unavailable
  05:24:25.850 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.
  05:24:25.940 [adservice] AdService starting.
  05:24:27.544 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base
  05:24:29.538 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="GBP"  (×3)
  05:24:29.575 [paymentservice] Transaction processed: visa ending 4522 Amount: GBP388.442954436  (×2)
  05:24:29.579 [shippingservice] [ShipOrder] received request  (×4)
  05:24:29.582 [cartservice] EmptyCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×4)
  05:24:29.594 [checkoutservice] order confirmation email sent to "williamsanthony@example.org"
  05:24:42.556 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13  (×2)
  05:24:42.603 [paymentservice] }
  05:24:42.607 [frontend] request error
  05:24:47.359 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', '2ZYFJ3GM2N', '9SIQT8TOJO', '66VCHSJNUP']  (×2)
  05:24:52.883 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"44027","nanos":3981379},"credit_card":{"credit_card_number":"49677054823682  (×2)
  05:24:52.897 [emailservice] A request to send order confirmation email to abbottlucas@example.com has been received.
  05:24:54.344 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP']
  05:25:01.848 [checkoutservice] order confirmation email sent to "muellerhannah@example.com"
  05:25:05.499 [checkoutservice] order confirmation email sent to "bdavis@example.com"

## p0514
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:40:52.608Z
```
{"timestamp":1732358452608326000,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"Posting Card: {\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"userID\":\"6741b12ea437380001df4a80\"}"}
```
Same service, the 2 minutes before (oldest first):
  10:40:51.671 [front-end] Carts merged.  (×3)
  10:40:51.671 [front-end] set cookie6741b133a437380001df4a8d  (×3)
  10:40:51.672 [front-end] Sent cookies.  (×3)
  10:40:51.672 [front-end] POST /register 200 47.303 ms - 33  (×3)
  10:40:52.009 [front-end] GET /catalogue 200 - ms - -  (×2)
  10:40:52.138 [front-end] Posting Customer: {"username":"YBQIvbmr","password":"BPOxjQ","email":"YBQIvbmr@gmail.com","firstName":"YBQIvbmr","lastName":"YBQIvbmr"}
  10:40:52.146 [front-end] { id: '6741b134a437380001df4a8f' }
  10:40:52.146 [front-end] 6741b134a437380001df4a8f
  10:40:52.146 [front-end] Merging carts for customer id: 6741b134a437380001df4a8f and session id: dM_Q6epNQzXJhVbSGZDBgoO58-oMCsdj
  10:40:52.590 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b12ea437380001df4a80"}
  10:40:52.603 [front-end] POST /addresses 200 - ms - -
All services, 30 seconds either side (sampled):
  10:40:51.001 [user] ts=2024-11-23T10:40:51.001253583Z caller=middlewares.go:75 method=GetUsers id=6741b123a437380001df4a67 result=1 took=2.561807ms  (×127)
  10:40:51.057 [front-end] Request received with body: {}  (×34)
  10:40:51.115 [front-end] POST /cards 200 - ms - -  (×35)
  10:40:51.243 [carts] 2024-11-23 10:40:51.243 INFO [carts,d2c2e6abee6853ca,7c11b7f04a005886,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×16)
  10:40:51.650 [carts] 2024-11-23 10:40:51.644 INFO [carts,ce28dad27a7f1e73,b550dd7d93e87a62,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×21)
  10:40:52.715 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×4)
  10:40:54.042 [carts] 2024-11-23 10:40:54.042 INFO [carts,55279b5e8192e632,8c77ccf18a9ceab9,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.ItemsController : Did not find item.  (×19)
  10:40:55.439 [front-end] Posting Customer: {"username":"RWEKCzZbyoL","password":"eCgDEu","email":"RWEKCzZbyoL@gmail.com","firstName":"RWEKCzZbyoL","lastName":"RWEKCzZbyoL"}
  10:40:57.337 [orders] 2024-11-23 10:40:57.337 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+jso
  10:40:57.345 [orders] 2024-11-23 10:40:57.345 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[applicatio
  10:40:57.435 [orders] 2024-11-23 10:40:57.435 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicat
  10:40:57.546 [orders] 2024-11-23 10:40:57.546 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http
  10:40:58.821 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  10:40:59.450 [orders] 2024-11-23 10:40:59.450 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=
  10:40:59.540 [orders] 2024-11-23 10:40:59.540 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[app
  10:41:02.850 [front-end] Posting Customer: {"username":"oljxrbkvgRPchx","password":"KICnrSMycj","email":"oljxrbkvgRPchx@gmail.com","firstName":"oljxrbkvgRPchx","lastName":"oljxrbkvgRPch
  10:41:04.149 [orders] 2024-11-23 10:41:04.149 INFO [orders,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering w
  10:41:06.939 [orders] 2024-11-23 10:41:06.843 INFO [orders,,,] 7 --- [p-nio-80-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization starte
  10:41:08.897 [front-end] Received response: "{\"firstName\":\"FoMnUsWRwtr\",\"lastName\":\"FoMnUsWRwtr\",\"username\":\"FoMnUsWRwtr\",\"id\":\"6741b133a437380001df4a8e\",\"_links\":{\"a
  10:41:09.781 [front-end] Posting Customer: {"username":"gzAwltOvrAOlwZ","password":"mvbfevmrG","email":"gzAwltOvrAOlwZ@gmail.com","firstName":"gzAwltOvrAOlwZ","lastName":"gzAwltOvrAOlwZ
  10:41:10.346 [queue-master] 2024-11-23 10:41:10.346 INFO 7 --- [ool-6-thread-24] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×18)
  10:41:10.951 [orders-db] {"t":{"$date":"2024-11-23T10:41:10.951+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:4145  (×10)
  10:41:11.658 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b14601dd390007094dcc","customerId":"6741b12ea437380001df4a7f","customer":{"id":null,"firstName":"vDSVmUfFkYR
  10:41:11.740 [front-end] Order response: {"id":"6741b14601dd390007094dcb","customerId":"6741b135a437380001df4a95","customer":{"id":null,"firstName":"oMOnLjzHZXUV","lastName":"oMOnLjzHZX
  10:41:11.746 [front-end] Order response: {"id":"6741b14601dd390007094dcd","customerId":"6741b133a437380001df4a8d","customer":{"id":null,"firstName":"PMMsVPkCBtB","lastName":"PMMsVPkCBtB
  10:41:13.508 [user] ts=2024-11-23T10:41:13.508595513Z caller=middlewares.go:46 method=Register username=AQxdn email=AQxdn@gmail.com took=2.184408ms
  10:41:15.043 [front-end] Order response: {"id":"6741b14a01dd390007094dd4","customerId":"6741b132a437380001df4a8a","customer":{"id":null,"firstName":"mfkgXqTHaTye","lastName":"mfkgXqTHaT
  10:41:17.757 [front-end] Received response: "{\"firstName\":\"RPAyWJFRkAtx\",\"lastName\":\"RPAyWJFRkAtx\",\"username\":\"RPAyWJFRkAtx\",\"id\":\"6741b138a437380001df4aa1\",\"_links\":{
  10:41:20.018 [front-end] Received response: "{\"firstName\":\"qqkRVDrhVVQ\",\"lastName\":\"qqkRVDrhVVQ\",\"username\":\"qqkRVDrhVVQ\",\"id\":\"6741b138a437380001df4aa2\",\"_links\":{\"a

## p0528
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T11:00:21.042Z
```
{"timestamp":1732359621042657800,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 11:00:21.042  INFO [carts,667ed3b0f11acc5d,568ce2b4ab1c3bed,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource     : Adding for user: Cart{id='6741b5c5f074bf0007005838', customerId='6741b5bea437380001df548f', items=[]}, Item{id='6741b5c5f074bf0007005839', itemId='819e1fbf-8b7e-4f6d-811f-693534916a8b', quantity=1, unitPrice=14.0}"}
```
Same service, the 2 minutes before (oldest first):
  11:00:11.565 [carts] 2024-11-23 11:00:11.564 INFO [carts,5a2e21a486490bc1,97896900cee9f8fe,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.CartsController : Merge carts reques  (×7)
  11:00:14.760 [carts] 2024-11-23 11:00:14.760 INFO [carts,230bb97a8583f04f,1e30eb415282c253,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.CartsController : Merge carts reques  (×4)
  11:00:16.771 [carts] 2024-11-23 11:00:16.771 INFO [carts,79c3cca9307c8053,e419857b0ee43efe,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.controllers.ItemsController : Did not find item.  (×3)
  11:00:16.780 [carts] 2024-11-23 11:00:16.780 INFO [carts,79c3cca9307c8053,e419857b0ee43efe,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
  11:00:20.013 [carts] 2024-11-23 11:00:20.013 INFO [carts,d5126330e55b94df,bcb3e2fed3927393,false] 7 --- [-nio-80-exec-17] w.w.s.cart.controllers.ItemsController : Did not find item.
  11:00:20.023 [carts] 2024-11-23 11:00:20.022 INFO [carts,d5126330e55b94df,bcb3e2fed3927393,false] 7 --- [-nio-80-exec-17] w.w.s.cart.cart.CartContentsResource : Adding for user: Car
All services, 30 seconds either side (sampled):
  10:59:51.383 [catalogue] ts=2024-11-23T10:59:51Z caller=logging.go:85 method=Health result=2 took=26.422µs  (×40)
  11:00:11.544 [front-end] Posting Customer: {"username":"RupAdllGjrdNv","password":"zJBnIlEK","email":"RupAdllGjrdNv@gmail.com","firstName":"RupAdllGjrdNv","lastName":"RupAdllGjrdNv"}
  11:00:11.565 [carts] 2024-11-23 11:00:11.564 INFO [carts,5a2e21a486490bc1,97896900cee9f8fe,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.CartsController : Merge carts reques  (×17)
  11:00:12.740 [front-end] Posting Customer: {"username":"hYeBtEGlGq","password":"fSKDYUx","email":"hYeBtEGlGq@gmail.com","firstName":"hYeBtEGlGq","lastName":"hYeBtEGlGq"}
  11:00:14.745 [front-end] Posting Customer: {"username":"XNHqPsYlIlUw","password":"brpClEgE","email":"XNHqPsYlIlUw@gmail.com","firstName":"XNHqPsYlIlUw","lastName":"XNHqPsYlIlUw"}
  11:00:16.620 [front-end] POST /addresses 200 - ms - -  (×18)
  11:00:16.717 [front-end] User cart deleted with status: 202  (×17)
  11:00:16.737 [front-end] POST to carts: http://carts/carts/6741b5bba437380001df548b/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×8)
  11:00:16.816 [user] ts=2024-11-23T11:00:16.816230287Z caller=middlewares.go:46 method=Register username=ZYyOEosw email=ZYyOEosw@gmail.com took=2.034356ms
  11:00:19.981 [front-end] POST to carts: http://carts/carts/6741b5bda437380001df548d/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}  (×9)
  11:00:20.710 [front-end] Posting Customer: {"username":"eciSh","password":"ncDSTD","email":"eciSh@gmail.com","firstName":"eciSh","lastName":"eciSh"}
  11:00:21.686 [front-end] Posting Customer: {"username":"AtPqbXfAZp","password":"EpoZfUN","email":"AtPqbXfAZp@gmail.com","firstName":"AtPqbXfAZp","lastName":"AtPqbXfAZp"}
  11:00:23.865 [catalogue] ts=2024-11-23T11:00:23Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=4.81605m
  11:00:24.738 [front-end] Posting Customer: {"username":"HOLUtFoSuMcUtKu","password":"taAJbEDhs","email":"HOLUtFoSuMcUtKu@gmail.com","firstName":"HOLUtFoSuMcUtKu","lastName":"HOLUtFoSuMc
  11:00:26.495 [orders-db] {"t":{"$date":"2024-11-23T11:00:26.495+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235962
  11:00:27.232 [user] ts=2024-11-23T11:00:27.232650455Z caller=middlewares.go:46 method=Register username=ZloLZze email=ZloLZze@gmail.com took=3.095882ms
  11:00:28.716 [user] ts=2024-11-23T11:00:28.715850808Z caller=middlewares.go:46 method=Register username=LomuEmw email=LomuEmw@gmail.com took=2.094766ms
  11:00:29.613 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  11:00:31.625 [front-end] Posting Customer: {"username":"rbqXF","password":"pcPTGVfA","email":"rbqXF@gmail.com","firstName":"rbqXF","lastName":"rbqXF"}
  11:00:32.066 [front-end] GET Request to: http://user/customers/6741b5bda437380001df548d/addresses  (×4)
  11:00:32.083 [front-end] Received response: "{\"firstName\":\"XNHqPsYlIlUw\",\"lastName\":\"XNHqPsYlIlUw\",\"username\":\"XNHqPsYlIlUw\",\"id\":\"6741b5bea437380001df548f\",\"_links\":{
  11:00:32.150 [orders] 2024-11-23 11:00:32.150 INFO [orders,5a6a0af7afe1a8a3,d3020c3723661a9c,false] 7 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Received payment re
  11:00:32.160 [queue-master] 2024-11-23 11:00:32.160 INFO 7 --- [ool-6-thread-23] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×6)
  11:00:32.165 [front-end] Order response: undefined
  11:00:32.178 [front-end] npm timing command:run-script Completed in 44217ms
  11:00:32.180 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!

## p0410
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:55:06.403Z
```
{"timestamp":1732247706403009800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /register 200 29.130 ms - 33"}
```
Same service, the 2 minutes before (oldest first):
  03:55:05.025 [front-end] Merging carts for customer id: 67400099b0df5c00019b37bf and session id: wE1CcwIlgRMgbNxr6juWBQFR0eGzVJQ8  (×3)
  03:55:05.047 [front-end] Carts merged.  (×3)
  03:55:05.047 [front-end] set cookie67400099b0df5c00019b37bf  (×3)
  03:55:05.047 [front-end] Sent cookies.  (×3)
  03:55:05.050 [front-end] POST /register 200 27.717 ms - 33
  03:55:05.060 [front-end] POST /cart 201 - ms - -
  03:55:06.368 [front-end] Posting Customer: {"username":"qbnymTwz","password":"jZFQouJjj","email":"qbnymTwz@gmail.com","firstName":"qbnymTwz","lastName":"qbnymTwz"}
  03:55:06.371 [front-end] Posting Customer: {"username":"xHhaNlFsQAy","password":"OIGDl","email":"xHhaNlFsQAy@gmail.com","firstName":"xHhaNlFsQAy","lastName":"xHhaNlFsQAy"}
  03:55:06.374 [front-end] { id: '6740009ab0df5c00019b37c0' }  (×2)
  03:55:06.374 [front-end] 6740009ab0df5c00019b37c0  (×2)
All services, 30 seconds either side (sampled):
  03:54:36.516 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67400076b0df5c00019b3755"}  (×59)
  03:54:36.621 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×13)
  03:54:36.737 [front-end] Carts merged.  (×59)
  03:54:36.960 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×6)
  03:54:38.256 [front-end] GET Request to: http://user/customers/6740006ab0df5c00019b372f/addresses  (×120)
  03:54:38.290 [queue-master] Received shipment task: 6740006ab0df5c00019b372f  (×50)
  03:54:38.899 [front-end] Received response: "{\"firstName\":\"mNqta\",\"lastName\":\"mNqta\",\"username\":\"mNqta\",\"id\":\"67400069b0df5c00019b372c\",\"_links\":{\"addresses\":{\"href
  03:54:39.852 [user] ts=2024-11-22T03:54:39.851972455Z caller=middlewares.go:75 method=GetUsers id=6740006db0df5c00019b373a result=1 took=1.15841ms  (×41)
  03:54:40.826 [user] ts=2024-11-22T03:54:40.82638563Z caller=middlewares.go:46 method=Register username=IJgNuM email=IJgNuM@gmail.com took=1.13292ms
  03:54:43.789 [front-end] Order response: {"id":"67400083d94b9000069b499d","customerId":"67400070b0df5c00019b373e","customer":{"id":null,"firstName":"klcpCTVZJwqE","lastName":"klcpCTVZJw
  03:54:46.108 [front-end] Order response: {"statusCode":201,"body":{"id":"67400086d94b9000069b499f","customerId":"67400073b0df5c00019b3746","customer":{"id":null,"firstName":"EPTofxIqcDs
  03:54:46.289 [front-end] Order response: {"statusCode":201,"body":{"id":"67400086d94b9000069b49a1","customerId":"6740006db0df5c00019b3736","customer":{"id":null,"firstName":"XHyNniAvWDr
  03:54:48.691 [front-end] Received response: "{\"firstName\":\"XMMMRHpRIc\",\"lastName\":\"XMMMRHpRIc\",\"username\":\"XMMMRHpRIc\",\"id\":\"67400071b0df5c00019b3741\",\"_links\":{\"addr
  03:54:50.455 [front-end] Posting Customer: {"username":"VnbFXfXUp","password":"YoQAXgrkmI","email":"VnbFXfXUp@gmail.com","firstName":"VnbFXfXUp","lastName":"VnbFXfXUp"}
  03:54:52.085 [front-end] Order response: {"statusCode":201,"body":{"id":"6740008cd94b9000069b49a8","customerId":"6740007cb0df5c00019b376b","customer":{"id":null,"firstName":"sXjNWPrqwSl
  03:54:56.512 [front-end] Posting Customer: {"username":"ERcOuZt","password":"oepxNI","email":"ERcOuZt@gmail.com","firstName":"ERcOuZt","lastName":"ERcOuZt"}
  03:54:58.495 [front-end] Order response: {"statusCode":201,"body":{"id":"67400092d94b9000069b49aa","customerId":"6740007eb0df5c00019b3770","customer":{"id":null,"firstName":"fggKxaEgC",
  03:55:00.869 [front-end] Order response: {"statusCode":201,"body":{"id":"67400094d94b9000069b49ab","customerId":"67400087b0df5c00019b378d","customer":{"id":null,"firstName":"zrVet","las
  03:55:02.066 [front-end] Received response: "{\"firstName\":\"IJgNuM\",\"lastName\":\"IJgNuM\",\"username\":\"IJgNuM\",\"id\":\"67400080b0df5c00019b3777\",\"_links\":{\"addresses\":{\"h
  03:55:06.371 [front-end] Posting Customer: {"username":"xHhaNlFsQAy","password":"OIGDl","email":"xHhaNlFsQAy@gmail.com","firstName":"xHhaNlFsQAy","lastName":"xHhaNlFsQAy"}
  03:55:07.842 [front-end] Order response: {"id":"6740009bd94b9000069b49b3","customerId":"67400084b0df5c00019b3781","customer":{"id":null,"firstName":"JEUIxdXSQXaVo","lastName":"JEUIxdXSQ
  03:55:10.709 [front-end] Order response: {"id":"6740009ed94b9000069b49b6","customerId":"6740008ab0df5c00019b3791","customer":{"id":null,"firstName":"VnbFXfXUp","lastName":"VnbFXfXUp","u
  03:55:14.192 [front-end] Posting Customer: {"username":"esgXSGReaQKjndM","password":"OVJABwX","email":"esgXSGReaQKjndM@gmail.com","firstName":"esgXSGReaQKjndM","lastName":"esgXSGReaQKjn
  03:55:18.539 [front-end] Posting Customer: {"username":"pSHlC","password":"LXzFM","email":"pSHlC@gmail.com","firstName":"pSHlC","lastName":"pSHlC"}
  03:55:20.669 [user] ts=2024-11-22T03:55:20.669090816Z caller=middlewares.go:75 method=GetUsers id=67400092b0df5c00019b37ac result=1 took=670µs
  03:55:21.985 [front-end] Posting Customer: {"username":"cTypZ","password":"GjyeP","email":"cTypZ@gmail.com","firstName":"cTypZ","lastName":"cTypZ"}
  03:55:25.650 [front-end] Order response: {"id":"674000add94b9000069b49c0","customerId":"6740009ab0df5c00019b37c1","customer":{"id":null,"firstName":"xHhaNlFsQAy","lastName":"xHhaNlFsQAy
  03:55:26.743 [front-end] Order response: {"statusCode":201,"body":{"id":"674000aed94b9000069b49c3","customerId":"67400091b0df5c00019b37a9","customer":{"id":null,"firstName":"bWhVmmnajAZ
  03:55:29.454 [carts-db] {"t":{"$date":"2024-11-22T03:55:29.453+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224772
  03:55:34.439 [front-end] Received response: "{\"firstName\":\"esgXSGReaQKjndM\",\"lastName\":\"esgXSGReaQKjndM\",\"username\":\"esgXSGReaQKjndM\",\"id\":\"674000a2b0df5c00019b37da\",\"_

## p0352
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:27:42.396Z
```
{"timestamp":1732246062396331800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Request received with body: {}"}
```
Same service, the 2 minutes before (oldest first):
  03:27:42.327 [front-end] POST /cards 200 - ms - -
  03:27:42.345 [front-end] Posting Customer: {"username":"LRCjsc","password":"dLbFi","email":"LRCjsc@gmail.com","firstName":"LRCjsc","lastName":"LRCjsc"}
  03:27:42.349 [front-end] Posting Customer: {"username":"BgPsShb","password":"EYxJFTy","email":"BgPsShb@gmail.com","firstName":"BgPsShb","lastName":"BgPsShb"}
  03:27:42.351 [front-end] { id: '673ffa2eb0df5c00019b2412' }  (×2)
  03:27:42.351 [front-end] 673ffa2eb0df5c00019b2412  (×2)
  03:27:42.351 [front-end] Merging carts for customer id: 673ffa2eb0df5c00019b2412 and session id: y5_hKG3jcMa48JRLX0HxhdItvM_uuPGj  (×2)
  03:27:42.372 [front-end] Attempting to delete cart for user: 673ffa24b0df5c00019b23fc
  03:27:42.373 [front-end] Carts merged.  (×2)
  03:27:42.373 [front-end] set cookie673ffa2eb0df5c00019b2412  (×2)
  03:27:42.373 [front-end] Sent cookies.  (×2)
  03:27:42.375 [front-end] POST /register 200 28.709 ms - 33  (×2)
  03:27:42.387 [front-end] User cart deleted with status: 202
  03:27:42.390 [front-end] DELETE /cart 202 - ms - -
All services, 30 seconds either side (sampled):
  03:27:12.467 [front-end] Request received with body: {}  (×62)
  03:27:12.501 [payment] ts=2024-11-22T03:27:12Z caller=logging.go:29 method=Authorise result=true took=840ns  (×41)
  03:27:12.707 [user] ts=2024-11-22T03:27:12.706937446Z caller=middlewares.go:46 method=Register username=zMGfGiXRujo email=zMGfGiXRujo@gmail.com took=951.223µs  (×12)
  03:27:12.967 [user] ts=2024-11-22T03:27:12.967295423Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffa0bb0df5c00019b23b0 took=1.634687ms  (×60)
  03:27:13.090 [carts] 2024-11-22 03:27:13.090 INFO [carts,4a97cc2ef77bdead,84c7db765af655c3,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.ItemsController : Did not find item.  (×27)
  03:27:13.843 [payment] ts=2024-11-22T03:27:13Z caller=logging.go:40 method=Health result=1 took=7.099µs  (×40)
  03:27:16.539 [front-end] Posting Customer: {"username":"HIBdGX","password":"Ufavzrjs","email":"HIBdGX@gmail.com","firstName":"HIBdGX","lastName":"HIBdGX"}
  03:27:17.698 [front-end] Order response: {"id":"673ffa15d94b9000069b44ce","customerId":"673ff9fbb0df5c00019b237f","customer":{"id":null,"firstName":"kBTWAyi","lastName":"kBTWAyi","usern
  03:27:18.104 [front-end] Order response: {"id":"673ffa16d94b9000069b44d0","customerId":"673ff9fdb0df5c00019b2386","customer":{"id":null,"firstName":"MZNwuRjKqACeny","lastName":"MZNwuRjK
  03:27:20.461 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×6)
  03:27:22.275 [front-end] Received response: "{\"firstName\":\"rPQpztl\",\"lastName\":\"rPQpztl\",\"username\":\"rPQpztl\",\"id\":\"673ffa04b0df5c00019b2395\",\"_links\":{\"addresses\":{
  03:27:24.226 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa1cd94b9000069b44d8","customerId":"673ffa07b0df5c00019b23a2","customer":{"id":null,"firstName":"xlvbebpfNew
  03:27:28.283 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×6)
  03:27:30.096 [front-end] Posting Customer: {"username":"nGjBMNmEiSw","password":"FvWxYhklfT","email":"nGjBMNmEiSw@gmail.com","firstName":"nGjBMNmEiSw","lastName":"nGjBMNmEiSw"}
  03:27:33.117 [front-end] Received response: "{\"firstName\":\"UanScqGYLbDK\",\"lastName\":\"UanScqGYLbDK\",\"username\":\"UanScqGYLbDK\",\"id\":\"673ffa12b0df5c00019b23cd\",\"_links\":{
  03:27:36.345 [front-end] Received response: "{\"firstName\":\"nnaTmmb\",\"lastName\":\"nnaTmmb\",\"username\":\"nnaTmmb\",\"id\":\"673ffa19b0df5c00019b23e2\",\"_links\":{\"addresses\":{
  03:27:40.480 [front-end] Posting Customer: {"username":"HcUwYy","password":"DJQLI","email":"HcUwYy@gmail.com","firstName":"HcUwYy","lastName":"HcUwYy"}
  03:27:43.258 [front-end] Posting Customer: {"username":"JHzHdENGHDq","password":"xFrJxtii","email":"JHzHdENGHDq@gmail.com","firstName":"JHzHdENGHDq","lastName":"JHzHdENGHDq"}
  03:27:45.026 [front-end] Order response: {"id":"673ffa31d94b9000069b44e8","customerId":"673ffa22b0df5c00019b23f3","customer":{"id":null,"firstName":"ACtrKB","lastName":"ACtrKB","usernam
  03:27:50.201 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa36d94b9000069b44ea","customerId":"673ffa1cb0df5c00019b23e9","customer":{"id":null,"firstName":"npslbPuDDeQ
  03:27:52.340 [front-end] Order response: {"id":"673ffa38d94b9000069b44ec","customerId":"673ffa22b0df5c00019b23f2","customer":{"id":null,"firstName":"nGjBMNmEiSw","lastName":"nGjBMNmEiSw
  03:27:54.353 [front-end] Posting Customer: {"username":"YKTDGnd","password":"VmkQjXpNmL","email":"YKTDGnd@gmail.com","firstName":"YKTDGnd","lastName":"YKTDGnd"}
  03:27:58.337 [queue-master] 2024-11-22 03:27:58.335 INFO 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×9)
  03:28:01.910 [front-end] Posting Customer: {"username":"DMbgRiN","password":"AgrvYcwjpp","email":"DMbgRiN@gmail.com","firstName":"DMbgRiN","lastName":"DMbgRiN"}
  03:28:03.627 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa43d94b9000069b44f4","customerId":"673ffa2eb0df5c00019b2413","customer":{"id":null,"firstName":"BgPsShb","l
  03:28:05.504 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa45d94b9000069b44f7","customerId":"673ffa2fb0df5c00019b2415","customer":{"id":null,"firstName":"JHzHdENGHDq
  03:28:07.015 [front-end] Received response: "{\"firstName\":\"pcilM\",\"lastName\":\"pcilM\",\"username\":\"pcilM\",\"id\":\"673ffa35b0df5c00019b242b\",\"_links\":{\"addresses\":{\"href
  03:28:08.450 [user] ts=2024-11-22T03:28:08.450104453Z caller=middlewares.go:46 method=Register username=DIsDFybaB email=DIsDFybaB@gmail.com took=1.102301ms
  03:28:11.308 [front-end] Order response: {"id":"673ffa4bd94b9000069b44fe","customerId":"673ffa37b0df5c00019b242e","customer":{"id":null,"firstName":"yvPwZXtnc","lastName":"yvPwZXtnc","u

## p0007
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice2, 2021-08-13T01:59:04.503Z
```
{"service":"logservice2","message":"2021-08-13 01:59:04,503 | INFO | 0.0.0.2 | 172.17.0.3 | logservice2 | 3fe6c06b3bb19cbe | request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'fb186db8-fb96-11eb-a9a3-0242ac110003'}"}
```
Same service, the 2 minutes before (oldest first):
  01:59:01.440 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×2)
  01:59:01.441 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×2)
  01:59:01.441 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': 'f92ace60-fb96-11eb-a6b4-0242ac110004', 'user_id': 'LNTWaneB'}  (×5)
  01:59:02.300 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×3)
  01:59:02.300 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×3)
  01:59:02.644 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  01:59:02.645 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  01:59:02.645 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'f9f9b252-fb96-11eb-9765-0242ac110003'}
All services, 30 seconds either side (sampled):
  01:58:36.158 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  01:58:36.328 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×39)
  01:58:36.572 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  01:58:36.713 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×43)
  01:58:36.916 [dbservice1] INFO ea6bc6e0-fb96-11eb-a1f5-0242ac110004-jInFtBJp-DGIo(X0%xJVQ token generate success token=MTYyODc5MTExNi45MTU4MTY1OmVhNmJjNmUwLWZiOTYtMTFlYi1hMWY1LTAyNDJhYzE
  01:58:37.838 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×42)
  01:58:38.702 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×37)
  01:58:38.959 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×38)
  01:58:39.654 [mobservice2] INFO info ec438d04-fb96-11eb-8cee-0242ac110004:yHBRGerA write success
  01:58:40.767 [dbservice2] INFO eccc0c38-fb96-11eb-abcf-0242ac110004-ISmxpnEs--5/4Hwoa@2dU token generate success token=MTYyODc5MTEyMC43NjcyMDgzOmVjY2MwYzM4LWZiOTYtMTFlYi1hYmNmLTAyNDJhYzE
  01:58:42.616 [dbservice1] INFO edd3f3de-fb96-11eb-9ef6-0242ac110004-hVyjbRgD-f%@HSIq-)KE2 token generate success token=MTYyODc5MTEyMi42MTU2ODk6ZWRkM2YzZGUtZmI5Ni0xMWViLTllZjYtMDI0MmFjMTE
  01:58:45.071 [mobservice1] INFO info ef7f7f6e-fb96-11eb-b4f1-0242ac110004:kxDurOQh write success
  01:58:47.028 [dbservice1] INFO f07785ba-fb96-11eb-9ad7-0242ac110004-zBtAqOdX-dNtBkshuAxiD token generate success token=MTYyODc5MTEyNy4wMjc2MzMyOmYwNzc4NWJhLWZiOTYtMTFlYi05YWQ3LTAyNDJhYzE  (×3)
  01:58:50.143 [mobservice2] INFO info f286fca0-fb96-11eb-9c4a-0242ac110003:AizeDahx write success
  01:58:52.356 [dbservice1] INFO f3a190fa-fb96-11eb-a07d-0242ac110003-HnGradOx-(__e)A>@p8fF token generate success token=MTYyODc5MTEzMi4zNTYxNTU6ZjNhMTkwZmEtZmI5Ni0xMWViLWEwN2QtMDI0MmFjMTE
  01:58:54.615 [mobservice1] INFO info f52a0f10-fb96-11eb-8e60-0242ac110004:HytkEBDf write success
  01:58:57.136 [mobservice1] INFO info f6a6bf64-fb96-11eb-a68c-0242ac110004:pUwNWoxq write success
  01:58:59.737 [mobservice2] INFO info f83d9eba-fb96-11eb-a182-0242ac110003:tdfCvYKb write success
  01:59:02.150 [mobservice1] INFO info f9b7ecf0-fb96-11eb-b866-0242ac110003:IFyHcfZd write success
  01:59:04.022 [dbservice2] INFO faa566f6-fb96-11eb-ab55-0242ac110004-vUJXxywj-uoW{8P@>ag5V token generate success token=MTYyODc5MTE0NC4wMjI1Mjk6ZmFhNTY2ZjYtZmI5Ni0xMWViLWFiNTUtMDI0MmFjMTE
  01:59:06.063 [mobservice1] INFO info fc0dae2c-fb96-11eb-92e4-0242ac110003:igXqQZLm write success
  01:59:08.835 [dbservice2] INFO fd767f5a-fb96-11eb-b632-0242ac110004-FvDqslOC-J$0(?)uHF_Z. token generate success token=MTYyODc5MTE0OC44MzQ1NjQyOmZkNzY3ZjVhLWZiOTYtMTFlYi1iNjMyLTAyNDJhYzE
  01:59:11.164 [mobservice1] INFO info ff149716-fb96-11eb-a772-0242ac110003:JIoWshby write success
  01:59:13.622 [dbservice2] INFO 0056a8d0-fb97-11eb-a1bb-0242ac110003-bHxAGyOk-FAxou7R(_OT- token generate success token=MTYyODc5MTE1My42MjIyNzYzOjAwNTZhOGQwLWZiOTctMTFlYi1hMWJiLTAyNDJhYzE
  01:59:15.463 [mobservice2] INFO info 01a9c79e-fb97-11eb-bdd7-0242ac110003:jyDKkYiT write success
  01:59:17.209 [dbservice1] INFO 0285e83c-fb97-11eb-8237-0242ac110003-otxdGLkJ-:i2e%}c)9Xn8 token generate success token=MTYyODc5MTE1Ny4yMDkyNzUyOjAyODVlODNjLWZiOTctMTFlYi04MjM3LTAyNDJhYzE
  01:59:19.628 [mobservice1] INFO info 04202c7a-fb97-11eb-b196-0242ac110003:vUsGrNAF write success
  01:59:21.799 [dbservice1] INFO 053c21d6-fb97-11eb-bcca-0242ac110003-NChObWPp-ABNnZD}T2zO{ token generate success token=MTYyODc5MTE2MS43OTkxODA1OjA1M2MyMWQ2LWZiOTctMTFlYi1iY2NhLTAyNDJhYzE
  01:59:23.817 [mobservice2] INFO info 069fa16a-fb97-11eb-9c80-0242ac110003:avTqnNxg write success
  01:59:28.465 [dbservice2] INFO 092ae6b0-fb97-11eb-9077-0242ac110004-JTPZbGUX-owRC0.<$@!D) token generate success token=MTYyODc5MTE2OC40NjUyMTc4OjA5MmFlNmIwLWZiOTctMTFlYi05MDc3LTAyNDJhYzE

## p0598
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-07T20:03:13.199Z
```
{"timestamp":1733601793199249000,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-kh5wd","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 20:03:13.199  INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl  : [Basic Information Service][Query For Station Id] Station Id: Nan Jing"}
```
Same service, the 2 minutes before (oldest first):
  20:03:10.545 [ts-basic-service] 2024-12-07 20:03:10.545 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×5)
  20:03:11.020 [ts-basic-service] 2024-12-07 20:03:11.020 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha
  20:03:11.040 [ts-basic-service] 2024-12-07 20:03:11.040 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×4)
  20:03:11.116 [ts-basic-service] 2024-12-07 20:03:11.116 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×2)
  20:03:11.129 [ts-basic-service] 2024-12-07 20:03:11.129 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe
  20:03:11.137 [ts-basic-service] 2024-12-07 20:03:11.137 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69
  20:03:11.148 [ts-basic-service] 2024-12-07 20:03:11.148 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  20:03:11.148 [ts-basic-service] 2024-12-07 20:03:11.148 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4
  20:03:11.166 [ts-basic-service] 2024-12-07 20:03:11.166 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  20:03:11.180 [ts-basic-service] 2024-12-07 20:03:11.179 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
  20:03:11.180 [ts-basic-service] 2024-12-07 20:03:11.179 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1
  20:03:11.180 [ts-basic-service] 2024-12-07 20:03:11.179 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : route.getDistances().size : 2
All services, 30 seconds either side (sampled):
  20:02:43.648 [ts-auth-service] 2024-12-07 20:02:43.648 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×15)
  20:02:43.991 [ts-travel2-service] 2024-12-07 20:02:43.991 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×132)
  20:02:44.096 [ts-basic-service] 2024-12-07 20:02:44.095 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×7)
  20:02:44.209 [ts-seat-service] 2024-12-07 20:02:44.209 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×27)
  20:02:44.272 [ts-seat-service] 2024-12-07 20:02:44.272 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×48)
  20:02:47.213 [ts-travel-service] 2024-12-07 20:02:47.213 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×17)
  20:02:48.459 [ts-travel-service] 2024-12-07 20:02:48.459 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Travel Service] Query TripResponse  (×5)
  20:02:48.614 [ts-order-service] 2024-12-07 20:02:48.614 INFO 1 --- [io-12031-exec-2] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×12)
  20:02:48.927 [ts-travel-service] 2024-12-07 20:02:48.927 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×18)
  20:02:49.589 [ts-basic-service] 2024-12-07 20:02:49.589 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieT  (×2)
  20:02:53.414 [ts-admin-basic-info-service] 2024-12-07 20:02:53.413 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin 
  20:02:53.649 [ts-seat-service] 2024-12-07 20:02:53.649 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×10)
  20:02:56.269 [ts-admin-basic-info-service] 2024-12-07 20:02:56.269 INFO 1 --- [io-18767-exec-1] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×7)
  20:03:00.299 [ts-basic-service] 2024-12-07 20:03:00.299 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×2)
  20:03:02.570 [ts-travel-service] 2024-12-07 20:03:02.569 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan  (×5)
  20:03:11.180 [ts-basic-service] 2024-12-07 20:03:11.179 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou  (×4)
  20:03:11.699 [ts-contacts-service] 2024-12-07 20:03:11.699 INFO 1 --- [io-12347-exec-5] contacts.controller.ContactsController : [ContactsService][VerifyLogin] Success
  20:03:13.903 [ts-security-service] 2024-12-07 20:03:13.903 INFO 1 --- [io-11188-exec-3] security.controller.SecurityController : [Security Service][Check Security] Check Account Id: 4d2a46c7-71cb
  20:03:13.992 [ts-preserve-service] 2024-12-07 20:03:13.992 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security Complete
  20:03:14.183 [ts-preserve-service] 2024-12-07 20:03:14.183 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting...
  20:03:15.429 [ts-preserve-service] 2024-12-07 20:03:15.429 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Station Name]  (×2)
  20:03:15.657 [ts-order-service] 2024-12-07 20:03:15.657 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at 
  20:03:16.361 [ts-assurance-service] 2024-12-07 20:03:16.360 INFO 1 --- [io-18888-exec-5] assurance.service.AssuranceServiceImpl : [Assurance-Add&Delete-Service][AddAssurance] Success.
  20:03:16.596 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:03:16 +0800] "POST /api/v1/preserveservice/preserve HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWeb
  20:03:18.449 [ts-consign-service] 2024-12-07 20:03:18.449 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : The target date is 2024-12-07 20:03:18
  20:03:28.372 [ts-config-mongo] {"t":{"$date":"2024-12-07T20:03:28.371+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360180
  20:03:31.344 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T20:03:31.344+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360181
  20:03:42.731 [ts-order-other-service] 2024-12-07 20:03:42.730 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392

## p0668
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-11T09:57:19.502Z
```
{"service":"dbservice1","message":"2021-08-11 09:57:19,502 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | fbfbea3e85b5fb34 | 75467694-fa47-11eb-8551-0242ac110003-QghyctJY-PkMVvH8?+4Z= token generate success token=MTYyODY0NzAzOS41MDIwODU3Ojc1NDY3Njk0LWZhNDctMTFlYi04NTUxLTAyNDJhYzExMDAwM1FnaHljdEpZUGtNVnZIOD8rNFo9OjE2Mjg2NDcwOTkuNTAyMDk1NTo0YTZhZDE5NmUyNzA4NzE2MzBjNzBmYjAzZTU4ZDBiOA=="}
```
Same service, the 2 minutes before (oldest first):
  09:57:13.061 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  09:57:15.452 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  09:57:15.452 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  09:57:15.503 [dbservice1] INFO query = select passwards from username_table where user_name='ISmxpnEs'  (×5)
  09:57:15.589 [dbservice1] INFO 734137ee-fa47-11eb-9344-0242ac110003-ISmxpnEs--5/4Hwoa@2dU token generate success token=MTYyODY0NzAzNS41ODg5NjY4OjczNDEzN2VlLWZhNDctMTFlYi05MzQ0LTAyNDJhYzE
  09:57:16.396 [dbservice1] INFO 73c9d70c-fa47-11eb-ae6f-0242ac110003-evnbrmSs-gom=Yi$#jkD3 token generate success token=MTYyODY0NzAzNi4zOTU4ODM2OjczYzlkNzBjLWZhNDctMTFlYi1hZTZmLTAyNDJhYzE
  09:57:18.147 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  09:57:19.316 [dbservice1] INFO 755282f4-fa47-11eb-894b-0242ac110003-kpLnyIUm-c(41=Eiw?7IQ token generate success token=MTYyODY0NzAzOS4zMTU4NDkzOjc1NTI4MmY0LWZhNDctMTFlYi04OTRiLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  09:56:49.522 [dbservice1] INFO query = select passwards from username_table where user_name='HYsctkhi'  (×31)
  09:56:49.691 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×27)
  09:56:49.854 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×26)
  09:56:50.047 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×26)
  09:56:50.316 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×33)
  09:56:50.737 [mobservice2] INFO info 64a54aea-fa47-11eb-b32b-0242ac110003:LiESlVvW write success
  09:56:50.932 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×43)
  09:56:51.750 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×36)
  09:56:52.037 [redisservice2] INFO redis读取信息成功, status_code: 200  (×30)
  09:56:53.259 [dbservice1] INFO 65f4b732-fa47-11eb-80af-0242ac110004-CZFJjyRk-1QN4a<C{jpM> token generate success token=MTYyODY0NzAxMy4yNTk1ODgyOjY1ZjRiNzMyLWZhNDctMTFlYi04MGFmLTAyNDJhYzE
  09:56:56.250 [mobservice2] INFO info 67f7402c-fa47-11eb-80e3-0242ac110004:XHisUhbp write success
  09:56:59.493 [dbservice1] INFO 69349b88-fa47-11eb-a030-0242ac110003-ropVRsqh-hActS-H+f9_x token generate success token=MTYyODY0NzAxOS40OTMxNDU3OjY5MzQ5Yjg4LWZhNDctMTFlYi1hMDMwLTAyNDJhYzE  (×2)
  09:57:01.595 [mobservice2] INFO info 6b2ee092-fa47-11eb-83a8-0242ac110003:gwdEDvWp write success
  09:57:04.503 [dbservice1] INFO 6c5ea3d0-fa47-11eb-882f-0242ac110004-NhtsWobx->YgS8K?XxrDn token generate success token=MTYyODY0NzAyNC41MDM1MTk6NmM1ZWEzZDAtZmE0Ny0xMWViLTg4MmYtMDI0MmFjMTE
  09:57:07.261 [dbservice1] INFO 6e3edf26-fa47-11eb-b788-0242ac110003-oYbSglqf-udHk_>z3F5*y token generate success token=MTYyODY0NzAyNy4yNjEwNTU1OjZlM2VkZjI2LWZhNDctMTFlYi1iNzg4LTAyNDJhYzE
  09:57:09.721 [dbservice1] INFO 6fcb449c-fa47-11eb-b6d7-0242ac110003-FyRfJQAa-tv12UD<Z*7Oy token generate success token=MTYyODY0NzAyOS43MjEyMzQ4OjZmY2I0NDljLWZhNDctMTFlYi1iNmQ3LTAyNDJhYzE
  09:57:12.556 [mobservice1] INFO info 71b8d2b0-fa47-11eb-af7e-0242ac110003:CeJfdxpR write success
  09:57:14.704 [dbservice2] INFO 72c5cb40-fa47-11eb-9cf3-0242ac110003-STAzgDjZ-8aLzC?wGpT=- token generate success token=MTYyODY0NzAzNC43MDQzNjEyOjcyYzVjYjQwLWZhNDctMTFlYi05Y2YzLTAyNDJhYzE
  09:57:16.855 [mobservice1] INFO info 74454a2c-fa47-11eb-9dfc-0242ac110004:URvXGzml write success
  09:57:19.777 [mobservice2] INFO info 76040542-fa47-11eb-9937-0242ac110004:ZcstOImC write success
  09:57:23.001 [mobservice2] INFO info 77ed86bc-fa47-11eb-99f8-0242ac110003:IvLqACZF write success
  09:57:32.318 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  09:57:35.400 [dbservice2] INFO 7ef43532-fa47-11eb-95a4-0242ac110004-OzKQAVJF-y0PH2h:lM}5T token generate success token=MTYyODY0NzA1NS4zOTk2MjQzOjdlZjQzNTMyLWZhNDctMTFlYi05NWE0LTAyNDJhYzE
  09:57:38.294 [dbservice1] INFO 80ce5fc2-fa47-11eb-b951-0242ac110004-TMBcRIPk-t>ebO}qX)ah8 token generate success token=MTYyODY0NzA1OC4yOTQxMzk0OjgwY2U1ZmMyLWZhNDctMTFlYi1iOTUxLTAyNDJhYzE
  09:57:41.341 [dbservice2] INFO 828160d0-fa47-11eb-b782-0242ac110003-QDmAuJjk-EsJd)P:SQx?. token generate success token=MTYyODY0NzA2MS4zNDA2NTU2OjgyODE2MGQwLWZhNDctMTFlYi1iNzgyLTAyNDJhYzE
  09:57:44.039 [dbservice1] INFO 84396ba2-fa47-11eb-9f12-0242ac110003-FpcKvnCm-UjT*)>?iS97{ token generate success token=MTYyODY0NzA2NC4wMzkwMzQ2Ojg0Mzk2YmEyLWZhNDctMTFlYi05ZjEyLTAyNDJhYzE
  09:57:46.807 [dbservice2] INFO 85cb4ae4-fa47-11eb-a368-0242ac110004-RvaUsgNC-mT$@KrBb)Ax/ token generate success token=MTYyODY0NzA2Ni44MDczMDc3Ojg1Y2I0YWU0LWZhNDctMTFlYi1hMzY4LTAyNDJhYzE

## p0372
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:39:38.080Z
```
{"timestamp":1732246778080978400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Attempting to add to cart: {\"id\":\"837ab141-399e-4c1f-9abc-bace40296bac\",\"quantity\":1}"}
```
Same service, the 2 minutes before (oldest first):
  03:39:37.034 [front-end] POST /cart 201 - ms - -  (×2)
  03:39:37.064 [front-end] GET /catalogue 200 - ms - -
  03:39:37.922 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffcefb0df5c00019b2c7e"}  (×2)
  03:39:37.930 [front-end] POST /addresses 200 - ms - -  (×2)
  03:39:37.936 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffcefb0df5c00019b2c7e"}  (×2)
  03:39:37.945 [front-end] POST /cards 200 - ms - -  (×2)
  03:39:37.992 [front-end] Attempting to delete cart for user: 673ffcefb0df5c00019b2c7e  (×2)
  03:39:38.010 [front-end] User cart deleted with status: 202  (×2)
  03:39:38.012 [front-end] DELETE /cart 202 - ms - -  (×2)
  03:39:38.019 [front-end] Attempting to add to cart: {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","quantity":1}
  03:39:38.025 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata
  03:39:38.025 [front-end] POST to carts: http://carts/carts/673ffcefb0df5c00019b2c7e/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}
All services, 30 seconds either side (sampled):
  03:39:08.084 [front-end] Attempting to delete cart for user: 673ffcd4b0df5c00019b2c2c  (×66)
  03:39:08.552 [front-end] Received response: "{\"firstName\":\"zegmicVMdH\",\"lastName\":\"zegmicVMdH\",\"username\":\"zegmicVMdH\",\"id\":\"673ffcc7b0df5c00019b2c04\",\"_links\":{\"addr
  03:39:08.589 [shipping] Adding shipment to queue...  (×56)
  03:39:08.760 [user] ts=2024-11-22T03:39:08.76033937Z caller=middlewares.go:46 method=Register username=UOjWt email=UOjWt@gmail.com took=994.715µs
  03:39:08.861 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffcd3b0df5c00019b2c26"}  (×66)
  03:39:10.174 [front-end] Order response: {"id":"673ffcded94b9000069b46cf","customerId":"673ffcc8b0df5c00019b2c07","customer":{"id":null,"firstName":"UpTtzGVHzP","lastName":"UpTtzGVHzP",
  03:39:11.026 [user] ts=2024-11-22T03:39:11.026732427Z caller=middlewares.go:104 method=GetAddresses id=673ffccdb0df5c00019b2c16 result=1 took=1.133191ms  (×21)
  03:39:12.473 [front-end] Received response: "{\"firstName\":\"GaxcniHZByPfG\",\"lastName\":\"GaxcniHZByPfG\",\"username\":\"GaxcniHZByPfG\",\"id\":\"673ffcc9b0df5c00019b2c08\",\"_links\
  03:39:13.623 [front-end] Order response: {"id":"673ffce1d94b9000069b46d4","customerId":"673ffcccb0df5c00019b2c0f","customer":{"id":null,"firstName":"YxbOgFIbs","lastName":"YxbOgFIbs","u
  03:39:15.199 [front-end] Order response: {"id":"673ffce3d94b9000069b46d6","customerId":"673ffcd1b0df5c00019b2c23","customer":{"id":null,"firstName":"IRtWRPzkM","lastName":"IRtWRPzkM","u
  03:39:19.592 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffce7d94b9000069b46d8","customerId":"673ffcd2b0df5c00019b2c24","customer":{"id":null,"firstName":"KGumOVUSvWi
  03:39:21.141 [front-end] Posting Customer: {"username":"uvCAvrihsPL","password":"BkIbgj","email":"uvCAvrihsPL@gmail.com","firstName":"uvCAvrihsPL","lastName":"uvCAvrihsPL"}
  03:39:26.962 [front-end] Order response: {"id":"673ffceed94b9000069b46dc","customerId":"673ffcd8b0df5c00019b2c32","customer":{"id":null,"firstName":"ORTrSbc","lastName":"ORTrSbc","usern
  03:39:28.728 [orders-db] {"t":{"$date":"2024-11-22T03:39:28.728+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224676
  03:39:31.004 [front-end] Received response: "{\"firstName\":\"UOjWt\",\"lastName\":\"UOjWt\",\"username\":\"UOjWt\",\"id\":\"673ffcdcb0df5c00019b2c40\",\"_links\":{\"addresses\":{\"href
  03:39:32.324 [front-end] Received response: "{\"firstName\":\"VqMIpsdF\",\"lastName\":\"VqMIpsdF\",\"username\":\"VqMIpsdF\",\"id\":\"673ffcd6b0df5c00019b2c2d\",\"_links\":{\"addresses\
  03:39:32.965 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffcf4d94b9000069b46e5","customerId":"673ffcdeb0df5c00019b2c44","customer":{"id":null,"firstName":"mUbzBcySRBe
  03:39:34.868 [front-end] Order response: {"id":"673ffcf6d94b9000069b46e7","customerId":"673ffce0b0df5c00019b2c4b","customer":{"id":null,"firstName":"WAFZmo","lastName":"WAFZmo","usernam
  03:39:35.882 [front-end] Order response: {"id":"673ffcf7d94b9000069b46eb","customerId":"673ffce4b0df5c00019b2c59","customer":{"id":null,"firstName":"IkXRgyRkvRTbA","lastName":"IkXRgyRkv
  03:39:39.123 [user] ts=2024-11-22T03:39:39.123097831Z caller=middlewares.go:46 method=Register username=bMBBSp email=bMBBSp@gmail.com took=1.033137ms
  03:39:43.156 [front-end] Posting Customer: {"username":"XLODWlEKV","password":"qGwBTPW","email":"XLODWlEKV@gmail.com","firstName":"XLODWlEKV","lastName":"XLODWlEKV"}
  03:39:44.830 [user] ts=2024-11-22T03:39:44.830769866Z caller=middlewares.go:46 method=Register username=wYirEdaal email=wYirEdaal@gmail.com took=1.036548ms
  03:39:48.928 [front-end] Order response: {"id":"673ffd04d94b9000069b46f4","customerId":"673ffcf1b0df5c00019b2c85","customer":{"id":null,"firstName":"uFHUUyeMisfu","lastName":"uFHUUyeMis
  03:39:50.454 [user] ts=2024-11-22T03:39:50.454567893Z caller=middlewares.go:46 method=Register username=jqPTxwV email=jqPTxwV@gmail.com took=923.101µs
  03:39:51.619 [front-end] Posting Customer: {"username":"ADiRptjjjzr","password":"cHCxThxt","email":"ADiRptjjjzr@gmail.com","firstName":"ADiRptjjjzr","lastName":"ADiRptjjjzr"}
  03:39:55.512 [front-end] Order response: {"id":"673ffd0bd94b9000069b46fc","customerId":"673ffcf6b0df5c00019b2c96","customer":{"id":null,"firstName":"MMmvJm","lastName":"MMmvJm","usernam
  03:39:57.880 [user] ts=2024-11-22T03:39:57.879948791Z caller=middlewares.go:46 method=Register username=yMWWcvvG email=yMWWcvvG@gmail.com took=1.023565ms
  03:40:02.813 [front-end] Received response: "{\"firstName\":\"RjsIIOhuq\",\"lastName\":\"RjsIIOhuq\",\"username\":\"RjsIIOhuq\",\"id\":\"673ffcffb0df5c00019b2cbb\",\"_links\":{\"address
  03:40:07.368 [front-end] Received response: "{\"firstName\":\"XLODWlEKV\",\"lastName\":\"XLODWlEKV\",\"username\":\"XLODWlEKV\",\"id\":\"673ffcffb0df5c00019b2cb9\",\"_links\":{\"address

## p0051
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-13T08:16:18.504Z
```
{"service":"redisservice1","message":"2021-08-13 08:16:18,504 | INFO | 0.0.0.1 | 172.17.0.4 | redisservice1 | 7ac275344b03fed | service refuse, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  08:16:15.443 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×5)
  08:16:15.496 [redisservice1] INFO redis write success  (×9)
  08:16:15.633 [redisservice1] INFO redis读取信息成功, status_code: 200  (×4)
  08:16:15.901 [redisservice1] INFO service accept, status_code: 200  (×2)
All services, 30 seconds either side (sampled):
  08:15:48.595 [webservice2] INFO complete information: {'uuid': '9c4d3bbc-fbcb-11eb-8e10-0242ac110004', 'user_id': 'rAmXuCJg'}  (×43)
  08:15:48.706 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×38)
  08:15:48.931 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×36)
  08:15:48.995 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×57)
  08:15:49.489 [redisservice1] INFO redis write success  (×80)
  08:15:52.406 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×41)
  08:15:55.387 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  08:15:55.539 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×29)
  08:15:58.253 [redisservice1] INFO service refuse, status_code: 200  (×17)
  08:15:59.504 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×41)
  08:16:01.285 [mobservice2] INFO info a3c7e068-fbcb-11eb-ace6-0242ac110004:rydacQUo write success
  08:16:04.732 [mobservice1] INFO info a5bb2f9c-fbcb-11eb-9144-0242ac110003:jnuiIECt write success
  08:16:07.827 [dbservice1] INFO a7639d52-fbcb-11eb-89a8-0242ac110004-jIBRSGcQ-)ERfPKel{cTt token generate success token=MTYyODgxMzc2Ny44MjY2MTk5OmE3NjM5ZDUyLWZiY2ItMTFlYi04OWE4LTAyNDJhYzE
  08:16:10.867 [mobservice2] INFO info a97960ea-fbcb-11eb-a8a2-0242ac110003:FNabDRjg write success
  08:16:13.121 [mobservice1] INFO info aac7c856-fbcb-11eb-bd8d-0242ac110004:ZPMYDESe write success
  08:16:15.601 [mobservice1] INFO info ac4ddf3a-fbcb-11eb-aa65-0242ac110004:AFDxXgnQ write success
  08:16:18.249 [dbservice1] INFO adbad1fc-fbcb-11eb-a6b4-0242ac110003-GBzXyJft-#5tr9S.2Z_EP token generate success token=MTYyODgxMzc3OC4yNDkwOTgzOmFkYmFkMWZjLWZiY2ItMTFlYi1hNmI0LTAyNDJhYzE
  08:16:20.988 [mobservice2] INFO info af7b79f6-fbcb-11eb-a194-0242ac110004:OVLDMHZf write success
  08:16:23.869 [dbservice1] INFO b0f5b7f6-fbcb-11eb-89c3-0242ac110003-bypSvsJC-Y6tx3Buhf<)p token generate success token=MTYyODgxMzc4My44NjkwMzYyOmIwZjViN2Y2LWZiY2ItMTFlYi04OWMzLTAyNDJhYzE
  08:16:26.418 [dbservice1] INFO b281d0f0-fbcb-11eb-b880-0242ac110003-LPlrKejU-L/x6%5@H{.!- token generate success token=MTYyODgxMzc4Ni40MTc2MjY5OmIyODFkMGYwLWZiY2ItMTFlYi1iODgwLTAyNDJhYzE
  08:16:29.831 [mobservice2] INFO info b4b50112-fbcb-11eb-9f37-0242ac110004:vOcCSRZA write success
  08:16:32.617 [mobservice2] INFO info b66f7780-fbcb-11eb-806f-0242ac110003:vNyVfPiM write success
  08:16:35.493 [mobservice1] INFO info b829c4f4-fbcb-11eb-b115-0242ac110004:mPzNQvtl write success
  08:16:38.098 [mobservice2] INFO info b9b3cc5c-fbcb-11eb-b769-0242ac110004:dsqULkKQ write success
  08:16:40.465 [mobservice2] INFO info bb1d6698-fbcb-11eb-a6f7-0242ac110003:pfVurBxD write success
  08:16:43.901 [mobservice1] INFO info bd32db7a-fbcb-11eb-99cf-0242ac110004:gKUmCyre write success
  08:16:47.062 [dbservice1] INFO becc9c96-fbcb-11eb-8eb1-0242ac110003-HytkEBDf-z?M!i}>8wU$F token generate success token=MTYyODgxMzgwNy4wNjE4MzQzOmJlY2M5Yzk2LWZiY2ItMTFlYi04ZWIxLTAyNDJhYzE

## p0631
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T20:18:44.876Z
```
{"timestamp":1733602724876688000,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-f7tv2","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 20:18:44.876  INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl       : [Travel Other Service][Get Route By Id] Success."}
```
Same service, the 2 minutes before (oldest first):
  20:18:44.199 [ts-travel2-service] 2024-12-07 20:18:44.199 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0
  20:18:44.204 [ts-travel2-service] 2024-12-07 20:18:44.204 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×2)
  20:18:44.204 [ts-travel2-service] 2024-12-07 20:18:44.204 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：9fc9c261-3263-4bfa-82f8-bb4  (×6)
  20:18:44.262 [ts-travel2-service] 2024-12-07 20:18:44.261 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×5)
  20:18:44.617 [ts-travel2-service] 2024-12-07 20:18:44.617 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [TravelService] [getTripAllDetailInfo] gtdi info: TripAllDetailInfo(tr
  20:18:44.710 [ts-travel2-service] 2024-12-07 20:18:44.709 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [TravelService] [getTripAllDetailInfo] endPlaceID: nanjing
  20:18:44.791 [ts-travel2-service] 2024-12-07 20:18:44.791 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  20:18:44.799 [ts-travel2-service] 2024-12-07 20:18:44.798 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  20:18:44.850 [ts-travel2-service] 2024-12-07 20:18:44.850 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024, 
  20:18:44.863 [ts-travel2-service] 2024-12-07 20:18:44.863 INFO 1 --- [io-16346-exec-3] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234
All services, 30 seconds either side (sampled):
  20:18:14.991 [ts-admin-basic-info-service] 2024-12-07 20:18:14.991 INFO 1 --- [io-18767-exec-2] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×12)
  20:18:15.108 [ts-travel2-service] 2024-12-07 20:18:15.107 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×133)
  20:18:15.168 [ts-price-service] 2024-12-07 20:18:15.168 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: 0b23bd3e-876a-4af3-b92  (×4)
  20:18:15.190 [ts-order-other-service] 2024-12-07 20:18:15.190 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 54  (×12)
  20:18:15.265 [ts-seat-service] 2024-12-07 20:18:15.265 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×26)
  20:18:15.386 [ts-seat-service] 2024-12-07 20:18:15.386 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×19)
  20:18:15.568 [ts-route-service] 2024-12-07 20:18:15.568 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 1367db1f-461e-4ab7-87ad-2bcc05fd9cb7  (×27)
  20:18:21.318 [ts-basic-service] 2024-12-07 20:18:21.318 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×11)
  20:18:22.674 [ts-travel-service] 2024-12-07 20:18:22.673 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×17)
  20:18:22.755 [ts-order-service] 2024-12-07 20:18:22.755 INFO 1 --- [io-12031-exec-5] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×7)
  20:18:22.880 [ts-order-service] 2024-12-07 20:18:22.879 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is empty  (×2)
  20:18:23.068 [ts-travel-service] 2024-12-07 20:18:23.068 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×18)
  20:18:23.511 [ts-seat-service] 2024-12-07 20:18:23.511 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×2)
  20:18:24.057 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:18:24 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 916 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×3)
  20:18:26.066 [ts-food-service] 2024-12-07 20:18:26.066 INFO 1 --- [io-18856-exec-1] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×3)
  20:18:27.284 [ts-seat-service] 2024-12-07 20:18:27.284 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  20:18:30.921 [ts-auth-mongo] {"t":{"$date":"2024-12-07T20:18:30.921+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360271
  20:18:31.788 [ts-notification-mongo] {"t":{"$date":"2024-12-07T20:18:31.788+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360271
  20:18:38.198 [ts-travel2-service] 2024-12-07 20:18:38.198 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×4)
  20:18:43.221 [ts-payment-mongo] {"t":{"$date":"2024-12-07T20:18:43.221+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360272
  20:18:44.504 [ts-contacts-service] 2024-12-07 20:18:44.504 INFO 1 --- [io-12347-exec-4] contacts.controller.ContactsController : [Contacts Service][Find Contacts By Account Id: 4d2a46c7-71cb-4cf1
  20:18:44.535 [ts-security-service] 2024-12-07 20:18:44.535 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service][Get Order Num Info]
  20:18:44.598 [ts-preserve-other-service] 2024-12-07 20:18:44.597 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security Complete. 
  20:18:44.612 [ts-preserve-other-service] 2024-12-07 20:18:44.612 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] TripId: Z1234
  20:18:45.027 [ts-preserve-other-service] 2024-12-07 20:18:45.027 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Tickets Enough
  20:18:45.089 [ts-basic-service] 2024-12-07 20:18:45.089 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  20:18:45.155 [ts-seat-service] 2024-12-07 20:18:45.155 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService distributeSeat] The request seat type is confortClass and the t
  20:18:45.169 [ts-preserve-other-service] 2024-12-07 20:18:45.168 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order Complete
  20:18:45.225 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:18:45 +0800] "POST /api/v1/preserveotherservice/preserveOther HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7
  20:18:59.349 [ts-order-service] 2024-12-07 20:18:59.349 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160,   (×2)

## p0810
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-08T09:21:17.503Z
```
{"timestamp":1733649677503404300,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h4k7r","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-08 09:21:17.503  INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl     : UsernamePasswordAuthenticationToken  username :admin"}
```
Same service, the 2 minutes before (oldest first):
  09:21:00.021 [ts-auth-service] 2024-12-08 09:21:00.021 INFO 1 --- [io-12340-exec-8] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×3)
  09:21:00.205 [ts-auth-service] 2024-12-08 09:21:00.205 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×4)
  09:21:00.205 [ts-auth-service] 2024-12-08 09:21:00.205 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×4)
  09:21:07.445 [ts-auth-service] 2024-12-08 09:21:07.445 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×2)
  09:21:07.445 [ts-auth-service] 2024-12-08 09:21:07.445 INFO 1 --- [io-12340-exec-9] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  09:21:07.940 [ts-auth-service] 2024-12-08 09:21:07.939 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null
  09:21:07.940 [ts-auth-service] 2024-12-08 09:21:07.940 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  09:21:08.098 [ts-auth-service] 2024-12-08 09:21:08.098 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  09:21:08.098 [ts-auth-service] 2024-12-08 09:21:08.098 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4c7ef37c-e8cb-4d29-aaca-62bd7a8da985 USER ID
  09:21:10.700 [ts-auth-service] 2024-12-08 09:21:10.700 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
All services, 30 seconds either side (sampled):
  09:20:47.931 [ts-admin-basic-info-service] 2024-12-08 09:20:47.931 ERROR 1 --- [io-18767-exec-7] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×27)
  09:20:47.934 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:20:47 +0800] "GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×15)
  09:20:48.981 [ts-auth-service] 2024-12-08 09:20:48.981 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
  09:20:49.202 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:20:49 +0800] "POST /api/v1/users/login HTTP/1.1" 200 134 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×23)
  09:20:49.215 [ts-admin-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×12)
  09:20:51.314 [ts-admin-basic-info-service] 2024-12-08 09:20:51.313 ERROR 1 --- [o-18767-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×3)
  09:20:53.896 [ts-auth-service] 2024-12-08 09:20:53.896 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×21)
  09:20:59.506 [ts-auth-service] 2024-12-08 09:20:59.505 INFO 1 --- [io-12340-exec-4] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×11)
  09:20:59.825 [ts-travel2-service] 2024-12-08 09:20:59.824 ERROR 1 --- [io-16346-exec-4] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×10)
  09:20:59.828 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:20:59 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 500 228 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×11)
  09:21:05.231 [ts-order-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×3)
  09:21:06.244 [ts-travel-service] 2024-12-08 09:21:06.243 ERROR 1 --- [o-12346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  09:21:09.005 [ts-route-mongo] {"t":{"$date":"2024-12-08T09:21:09.005+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364966
  09:21:09.256 [ts-food-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×3)
  09:21:09.944 [ts-train-mongo] {"t":{"$date":"2024-12-08T09:21:09.944+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364966
  09:21:10.164 [ts-order-other-mongo] {"t":{"$date":"2024-12-08T09:21:10.164+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364967
  09:21:10.241 [ts-station-mongo] {"t":{"$date":"2024-12-08T09:21:10.241+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364967
  09:21:10.356 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-08T09:21:10.356+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364967
  09:21:11.411 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-08T09:21:11.411+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364967
  09:21:12.139 [ts-assurance-mongo] {"t":{"$date":"2024-12-08T09:21:12.139+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364967
  09:21:12.915 [ts-consign-price-mongo] {"t":{"$date":"2024-12-08T09:21:12.914+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364967
  09:21:13.501 [ts-consign-mongo] {"t":{"$date":"2024-12-08T09:21:13.500+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364967
  09:21:21.215 [ts-travel2-service] 2024-12-08 09:21:21.215 ERROR 1 --- [o-16346-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  09:21:23.228 [ts-travel-service] 2024-12-08 09:21:23.227 ERROR 1 --- [io-12346-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×3)
  09:21:40.524 [ts-order-other-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo

## p0599
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T20:03:15.603Z
```
{"timestamp":1733601795603770000,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-nsc8q","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:03:15.603  INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl             : Left ticket info is : Response(status=1, msg=Success, data=LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160, startStation=shanghai, destStation=suzhou), Ticket(seatNo=1662088091, startStation=shanghai, destStation=suzhou), Ticket(seatNo=518320891, startStation=shanghai, destStation=suzhou), Ticket(s…"}
```
Same service, the 2 minutes before (oldest first):
  20:03:14.938 [ts-seat-service] 2024-12-07 20:03:14.938 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×2)
  20:03:14.938 [ts-seat-service] 2024-12-07 20:03:14.938 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
  20:03:14.962 [ts-seat-service] 2024-12-07 20:03:14.962 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  20:03:14.973 [ts-seat-service] 2024-12-07 20:03:14.973 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  20:03:14.990 [ts-seat-service] 2024-12-07 20:03:14.990 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×2)
  20:03:14.990 [ts-seat-service] 2024-12-07 20:03:14.990 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  20:03:15.001 [ts-seat-service] 2024-12-07 20:03:15.001 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×2)
  20:03:15.092 [ts-seat-service] 2024-12-07 20:03:15.092 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:03:15.171 [ts-seat-service] 2024-12-07 20:03:15.170 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re
  20:03:15.171 [ts-seat-service] 2024-12-07 20:03:15.171 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  20:03:15.179 [ts-seat-service] 2024-12-07 20:03:15.179 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri
  20:03:15.295 [ts-seat-service] 2024-12-07 20:03:15.295 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345
  20:03:15.355 [ts-seat-service] 2024-12-07 20:03:15.355 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes
  20:03:15.567 [ts-seat-service] 2024-12-07 20:03:15.566 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService distributeSeat] TrainNumber start with G|D
  20:03:15.586 [ts-seat-service] 2024-12-07 20:03:15.586 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService distributeSeat] The result of getRouteResult is Success
All services, 30 seconds either side (sampled):
  20:02:46.971 [ts-auth-service] 2024-12-07 20:02:46.970 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×8)
  20:02:47.237 [ts-travel-service] 2024-12-07 20:02:47.237 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×15)
  20:02:47.377 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:02:47 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×9)
  20:02:48.568 [ts-basic-service] 2024-12-07 20:02:48.568 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270  (×5)
  20:02:48.616 [ts-travel-service] 2024-12-07 20:02:48.616 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×12)
  20:02:48.789 [ts-seat-service] 2024-12-07 20:02:48.789 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×25)
  20:02:49.367 [ts-seat-service] 2024-12-07 20:02:49.366 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×3)
  20:02:51.243 [ts-auth-service] 2024-12-07 20:02:51.242 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×15)
  20:02:51.611 [ts-order-other-service] 2024-12-07 20:02:51.611 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×15)
  20:02:51.727 [ts-seat-service] 2024-12-07 20:02:51.727 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×20)
  20:02:53.414 [ts-admin-basic-info-service] 2024-12-07 20:02:53.413 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin 
  20:02:53.649 [ts-seat-service] 2024-12-07 20:02:53.649 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×12)
  20:02:56.269 [ts-admin-basic-info-service] 2024-12-07 20:02:56.269 INFO 1 --- [io-18767-exec-1] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×7)
  20:03:00.299 [ts-basic-service] 2024-12-07 20:03:00.299 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×2)
  20:03:02.570 [ts-travel-service] 2024-12-07 20:03:02.569 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan  (×5)
  20:03:11.180 [ts-basic-service] 2024-12-07 20:03:11.179 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou  (×4)
  20:03:11.699 [ts-contacts-service] 2024-12-07 20:03:11.699 INFO 1 --- [io-12347-exec-5] contacts.controller.ContactsController : [ContactsService][VerifyLogin] Success
  20:03:13.903 [ts-security-service] 2024-12-07 20:03:13.903 INFO 1 --- [io-11188-exec-3] security.controller.SecurityController : [Security Service][Check Security] Check Account Id: 4d2a46c7-71cb
  20:03:13.992 [ts-preserve-service] 2024-12-07 20:03:13.992 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security Complete
  20:03:14.183 [ts-preserve-service] 2024-12-07 20:03:14.183 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting...
  20:03:15.429 [ts-preserve-service] 2024-12-07 20:03:15.429 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Station Name]  (×2)
  20:03:15.657 [ts-order-service] 2024-12-07 20:03:15.657 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Service][Verify Login] Success
  20:03:16.457 [ts-preserve-service] 2024-12-07 20:03:16.457 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service][Step 5] Buy Assurance Success
  20:03:18.064 [ts-order-service] 2024-12-07 20:03:18.064 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-4cf1-
  20:03:18.473 [ts-consign-service] 2024-12-07 20:03:18.473 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : SAVE consign info : ConsignRecord(id=052c9ca8-6361-4e87-9618-17aa478b8
  20:03:28.386 [ts-route-mongo] {"t":{"$date":"2024-12-07T20:03:28.385+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360180
  20:03:31.469 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T20:03:31.469+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360181
  20:03:42.749 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T20:03:42.749+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360182
  20:03:44.353 [ts-order-other-service] 2024-12-07 20:03:44.353 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou

## p0268
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:17.558Z
```
{"timestamp":1732242497558264300,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Merging carts for customer id: 673fec41b0df5c00019af98b and session id: DJgh-aP7GXWW3SFEl2AnBT8Zgj4ojU2q"}
```
Same service, the 2 minutes before (oldest first):
  02:28:16.536 [front-end] GET /catalogue 200 - ms - -  (×4)
  02:28:17.014 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec38b0df5c00019af971"}
  02:28:17.022 [front-end] POST /addresses 200 - ms - -
  02:28:17.028 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec38b0df5c00019af971"}
  02:28:17.035 [front-end] POST /cards 200 - ms - -
  02:28:17.084 [front-end] Attempting to delete cart for user: 673fec38b0df5c00019af971
  02:28:17.369 [front-end] Request received with body: {}
  02:28:17.377 [front-end] Received response: "{\"firstName\":\"vtFUiCYPGkr\",\"lastName\":\"vtFUiCYPGkr\",\"username\":\"vtFUiCYPGkr\",\"id\":\"673fec2bb0df5c00019af944\",\"_links\":{\"a
  02:28:17.377 [front-end] GET Request to: http://user/customers/673fec2bb0df5c00019af944/addresses  (×2)
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec33b0df5c00019af961\",\"_links\":{\"
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:17.383 [front-end] [ undefined, undefined ]
  02:28:17.383 [front-end] Posting Order: {"customer":"http://user/customers/673fec2bb0df5c00019af944","address":"http://user/addresses/673fec33b0df5c00019af960","card":"http://user/cards
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:17.558 [front-end] { id: '673fec41b0df5c00019af98b' }
  02:28:17.558 [front-end] 673fec41b0df5c00019af98b
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×44)
  02:28:03.174 [front-end] User cart deleted with status: 503  (×43)
  02:28:03.202 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×43)
  02:28:03.249 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×17)
  02:28:03.410 [front-end] Carts merged.  (×44)
  02:28:04.973 [front-end] Posting Customer: {"username":"HFHBXn","password":"EOgUhihln","email":"HFHBXn@gmail.com","firstName":"HFHBXn","lastName":"HFHBXn"}
  02:28:05.351 [user] ts=2024-11-22T02:28:05.351787827Z caller=middlewares.go:46 method=Register username=vuOxCKL email=vuOxCKL@gmail.com took=4.581531ms
  02:28:08.095 [front-end] Received response: "{\"firstName\":\"RsyjMQXEZqDOIBa\",\"lastName\":\"RsyjMQXEZqDOIBa\",\"username\":\"RsyjMQXEZqDOIBa\",\"id\":\"673fec1eb0df5c00019af912\",\"_
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×6)
  02:28:15.136 [carts] 2024-11-22 02:28:15.041 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 160.989 seconds (JVM running for 167.0
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:22.317 [front-end] Received response: "{\"firstName\":\"JGQXvUjPbFrtK\",\"lastName\":\"JGQXvUjPbFrtK\",\"username\":\"JGQXvUjPbFrtK\",\"id\":\"673fec34b0df5c00019af964\",\"_links\
  02:28:23.143 [orders] 2024-11-22 02:28:23.143 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×10)
  02:28:24.588 [shipping] Adding shipment to queue...  (×25)
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:26.156 [front-end] POST /cart 201 - ms - -  (×28)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d8","customerId":"673fec2cb0df5c00019af949","customer":{"id":null,"firstName":"KoWsmDtUqsE
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:30.547 [front-end] Received response: "{\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\",\"username\":\"vvgsHcY\",\"id\":\"673fec35b0df5c00019af968\",\"_links\":{\"addresses\":{
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.645 [queue-master] 2024-11-22 02:28:32.645 INFO 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×16)
  02:28:37.005 [user] ts=2024-11-22T02:28:37.005380807Z caller=middlewares.go:46 method=Register username=XTqSaA email=XTqSaA@gmail.com took=624.562µs
  02:28:40.136 [front-end] Order response: {"id":"673fec58d94b9000069b39dc","customerId":"673fec41b0df5c00019af98b","customer":{"id":null,"firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe",
  02:28:41.723 [user] ts=2024-11-22T02:28:41.723279742Z caller=middlewares.go:46 method=Register username=yaELjpCD email=yaELjpCD@gmail.com took=1.302265ms
  02:28:43.812 [front-end] Order response: {"id":"673fec5bd94b9000069b39e0","customerId":"673fec47b0df5c00019af996","customer":{"id":null,"firstName":"bhZuEQ","lastName":"bhZuEQ","usernam
  02:28:45.163 [front-end] Received response: "{\"firstName\":\"oqYeDriHaX\",\"lastName\":\"oqYeDriHaX\",\"username\":\"oqYeDriHaX\",\"id\":\"673fec49b0df5c00019af999\",\"_links\":{\"addr
  02:28:46.749 [front-end] Posting Customer: {"username":"kSaYlXePgdj","password":"miJFSQiUAg","email":"kSaYlXePgdj@gmail.com","firstName":"kSaYlXePgdj","lastName":"kSaYlXePgdj"}

## p0625
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-07T20:17:51.174Z
```
{"timestamp":1733602671174489300,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-9ll65","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:17:51.174  INFO 1 --- [           main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped \"{[/error]}\" onto public org.springframework.http.ResponseEntity<java.util.Map<java.lang.String, java.lang.Object>> org.springframework.boot.autoconfigure.web.BasicErrorController.error(javax.servlet.http.HttpServletRequest)"}
```
Same service, the 2 minutes before (oldest first):
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] .s.DelegatingFilterProxyRegistrationBean : Mapping filter: 'springSecurityFilterChain' to: [/*]
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'webRequestLoggingFilter' to: [/*]  (×2)
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  20:17:46.368 [ts-route-service] 2024-12-07 20:17:46.368 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-route-mongo:27017], mode=MULTIPLE, requiredClus
  20:17:46.369 [ts-route-service] 2024-12-07 20:17:46.368 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-route-mongo:27017 to client view of cluster
  20:17:46.954 [ts-route-service] 2024-12-07 20:17:46.954 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:24}] to ts-route-
  20:17:46.959 [ts-route-service] 2024-12-07 20:17:46.957 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip
  20:17:46.960 [ts-route-service] 2024-12-07 20:17:46.959 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  20:17:51.165 [ts-route-service] 2024-12-07 20:17:51.165 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes],methods=[POST]}" onto public org.sp
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.165 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{startId}/{terminalId}],methods=[GET
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{routeId}],methods=[DELETE]}" onto p
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{routeId}],methods=[GET]}" onto publ
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes],methods=[GET]}" onto public org.spr
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/welcome],methods=[GET]}" onto public java.l
  20:17:51.168 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/v2/api-docs],methods=[GET],produces=[application/json || applic
  20:17:51.171 [ts-route-service] 2024-12-07 20:17:51.170 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/swagger-resources]}" onto org.springframework.http.ResponseEnti
  20:17:51.172 [ts-route-service] 2024-12-07 20:17:51.171 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/configuration/ui]}" onto org.springframework.http.ResponseEntit
  20:17:51.172 [ts-route-service] 2024-12-07 20:17:51.172 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/configuration/security]}" onto org.springframework.http.Respons
  20:17:51.174 [ts-route-service] 2024-12-07 20:17:51.173 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
All services, 30 seconds either side (sampled):
  20:17:21.221 [ts-auth-service] 2024-12-07 20:17:21.221 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×12)
  20:17:21.406 [ts-basic-service] 2024-12-07 20:17:21.405 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×17)
  20:17:21.793 [ts-travel-service] 2024-12-07 20:17:21.793 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×27)
  20:17:24.657 [ts-route-service] 2024-12-07 20:17:24.657 INFO 1 --- [ main] route.RouteApplication : No active profile set, falling back to default profiles: default
  20:17:28.414 [ts-price-mongo] {"t":{"$date":"2024-12-07T20:17:28.413+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360264
  20:17:29.626 [ts-auth-service] 2024-12-07 20:17:29.626 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×3)
  20:17:31.474 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T20:17:31.474+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:35.032 [ts-route-service] Error opening zip file or JAR manifest missing : /tmp/opentelemetry-javaagent.jar
  20:17:36.448 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:36 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 200 31992 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) App
  20:17:37.664 [ts-route-service] 2024-12-07 20:17:37.664 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  20:17:38.802 [ts-food-service] org.springframework.web.client.HttpServerErrorException: 500 Internal Server Error at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Def
  20:17:42.857 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T20:17:42.857+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360266
  20:17:46.369 [ts-route-service] 2024-12-07 20:17:46.368 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-route-mongo:27017 to client view of cluster
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{routeId}],methods=[GET]}" onto publ
  20:17:52.758 [ts-route-service] 2024-12-07 20:17:52.757 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics || /metrics.json],methods=[GET],produces=[application/vnd.s
  20:17:52.762 [ts-route-service] 2024-12-07 20:17:52.762 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  20:17:53.879 [ts-travel2-service] 2024-12-07 20:17:53.878 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  20:17:57.960 [ts-basic-service] 2024-12-07 20:17:57.959 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su 
  20:18:01.659 [ts-route-service] 2024-12-07 20:18:01.657 INFO 1 --- [ main] d.s.w.p.DocumentationPluginsBootstrapper : Found 1 custom documentation plugin(s)
  20:18:04.265 [ts-route-service] 2024-12-07 20:18:04.265 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: taiyuan End: shanghai
  20:18:09.561 [ts-route-service] 2024-12-07 20:18:09.560 INFO 1 --- [io-11178-exec-3] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×41)
  20:18:10.466 [ts-travel-service] 2024-12-07 20:18:10.465 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×3)
  20:18:11.789 [ts-basic-service] 2024-12-07 20:18:11.789 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×2)
  20:18:11.820 [ts-order-other-service] 2024-12-07 20:18:11.820 INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×2)
  20:18:11.911 [ts-seat-service] 2024-12-07 20:18:11.911 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  20:18:11.988 [ts-seat-service] 2024-12-07 20:18:11.988 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×3)
  20:18:12.051 [ts-travel2-service] 2024-12-07 20:18:12.051 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×4)
  20:18:15.448 [ts-order-other-service] 2024-12-07 20:18:15.448 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Get Order By Id] Order Id: 0326c0cb-84c6-4b7b

## p0138
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:31:32.440Z
```
{"timestamp":1731907892440825000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"view user cart"}
```
Same service, the 2 minutes before (oldest first):
  05:31:31.682 [frontend] view user cart
  05:31:31.748 [frontend] request complete  (×6)
  05:31:31.877 [frontend] request started  (×6)
  05:31:31.877 [frontend] serving product page  (×2)
  05:31:32.095 [frontend] home  (×2)
  05:31:32.123 [frontend] setting currency
  05:31:32.150 [frontend] ENV_PLATFORM is: aws  (×2)
All services, 30 seconds either side (sampled):
  05:31:12.113 [frontend] request started  (×257)
  05:31:12.116 [currencyservice] Getting supported currencies...  (×213)
  05:31:12.130 [currencyservice] conversion request successful  (×587)
  05:31:12.168 [adservice] received ad request (context_words=[])  (×29)
  05:31:12.225 [frontend] setting currency  (×19)
  05:31:13.241 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '1YMWWN1N4O', '0PUK6V6EV0', '9SIQT8TOJO', 'L9ECAV7KIM']  (×175)
  05:31:13.958 [adservice] received ad request (context_words=[kitchen])  (×44)
  05:31:15.546 [adservice] received ad request (context_words=[decor, home])  (×14)
  05:31:16.969 [frontend] adding to cart  (×25)
  05:31:16.983 [frontend] view user cart  (×48)
  05:31:17.008 [shippingservice] [GetQuote] completed request  (×56)
  05:31:17.030 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="EUR"  (×2)
  05:31:17.056 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"139","nanos":655019905},"credit_card":{"credit_card_number":"49231259390927  (×2)
  05:31:17.058 [checkoutservice] payment went through (transaction_id: f193f55b-9ec1-41b5-abef-e610b8b840af)  (×7)
  05:31:17.059 [shippingservice] [ShipOrder] completed request  (×7)
  05:31:17.070 [emailservice] A request to send order confirmation email to curtis26@example.org has been received.
  05:31:17.072 [frontend] order placed  (×7)
  05:31:17.380 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"29721","nanos":50862865},"credit_card":{"credit_card_number":"4397529817152  (×2)
  05:31:17.393 [emailservice] A request to send order confirmation email to beckrobert@example.net has been received.
  05:31:18.456 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '1YMWWN1N4O']  (×2)
  05:31:18.597 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"2702","nanos":280000000},"credit_card":{"credit_card_number":"4761344760685
  05:31:18.613 [emailservice] A request to send order confirmation email to etate@example.com has been received.
  05:31:20.895 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '66VCHSJNUP', '1YMWWN1N4O']  (×3)
  05:31:31.384 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="TRY"  (×2)
  05:31:31.434 [paymentservice] Transaction processed: visa ending 2674 Amount: TRY7986.543787768  (×2)
  05:31:31.447 [checkoutservice] order confirmation email sent to "ncoleman@example.com"
  05:31:34.240 [checkoutservice] order confirmation email sent to "stephanieadams@example.org"
  05:31:37.485 [checkoutservice] order confirmation email sent to "jeffrey07@example.org"
  05:31:46.696 [checkoutservice] order confirmation email sent to "duranalexander@example.net"

## p0280
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T02:31:04.885Z
```
{"timestamp":1732242664885036800,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T02:31:04.884289838Z caller=middlewares.go:75 method=GetUsers id=673fecd5b0df5c00019afb42 result=1 took=982.926µs"}
```
Same service, the 2 minutes before (oldest first):
  02:31:02.848 [user] ts=2024-11-22T02:31:02.848485587Z caller=middlewares.go:75 method=GetUsers id=673feccab0df5c00019afb1c result=1 took=782.784µs  (×9)
  02:31:02.858 [user] ts=2024-11-22T02:31:02.858459434Z caller=middlewares.go:134 method=GetCards id=673fecd3b0df5c00019afb37 result=1 took=680.558µs
  02:31:02.858 [user] ts=2024-11-22T02:31:02.858467709Z caller=middlewares.go:104 method=GetAddresses id=673fecd3b0df5c00019afb36 result=1 took=967.908µs  (×3)
  02:31:02.859 [user] ts=2024-11-22T02:31:02.858855648Z caller=middlewares.go:75 method=GetUsers id=673feccab0df5c00019afb1c result=1 took=1.194403ms
  02:31:02.990 [user] ts=2024-11-22T02:31:02.989996307Z caller=middlewares.go:134 method=GetCards id=673fecd3b0df5c00019afb39 result=1 took=1.189627ms
  02:31:03.093 [user] ts=2024-11-22T02:31:03.093152689Z caller=middlewares.go:157 method=Health result=2 took=798.715µs  (×2)
  02:31:04.538 [user] ts=2024-11-22T02:31:04.538707535Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673fece2b0df5c00019afb63 took=1.777615ms
  02:31:04.552 [user] ts=2024-11-22T02:31:04.552662043Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673fece2b0df5c00019afb63 took=1.455247ms
  02:31:04.574 [user] ts=2024-11-22T02:31:04.574757784Z caller=middlewares.go:46 method=Register username=JfsaDEpOG email=JfsaDEpOG@gmail.com took=990.911µs
All services, 30 seconds either side (sampled):
  02:30:35.432 [front-end] Posting Customer: {"username":"sbsjsrCvlTmxJ","password":"TmnTiQ","email":"sbsjsrCvlTmxJ@gmail.com","firstName":"sbsjsrCvlTmxJ","lastName":"sbsjsrCvlTmxJ"}
  02:30:35.706 [front-end] Posting Customer: {"username":"djQATWy","password":"zGmGpplr","email":"djQATWy@gmail.com","firstName":"djQATWy","lastName":"djQATWy"}
  02:30:35.989 [orders] 2024-11-22 02:30:35.989 INFO [orders,c62edd0d14862ec0,2dc49dbc80b91128,false] 6 --- [p-nio-80-exec-3] w.w.s.o.controllers.OrdersController : Sending payment req  (×37)
  02:30:36.057 [front-end] Posting Customer: {"username":"GWGgtzEhCRKx","password":"lnUEwNzqZF","email":"GWGgtzEhCRKx@gmail.com","firstName":"GWGgtzEhCRKx","lastName":"GWGgtzEhCRKx"}
  02:30:36.316 [front-end] Posting Customer: {"username":"QFBhfSRAmMH","password":"uzqZGNv","email":"QFBhfSRAmMH@gmail.com","firstName":"QFBhfSRAmMH","lastName":"QFBhfSRAmMH"}
  02:30:37.013 [front-end] Order response: {"statusCode":201,"body":{"id":"673feccdd94b9000069b3a49","customerId":"673fecb8b0df5c00019afae6","customer":{"id":null,"firstName":"wgnrtzu","l
  02:30:37.389 [front-end] Attempting to add to cart: {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","quantity":1}  (×60)
  02:30:38.859 [front-end] Received response: "{\"firstName\":\"OSnscCZopmSK\",\"lastName\":\"OSnscCZopmSK\",\"username\":\"OSnscCZopmSK\",\"id\":\"673fecb2b0df5c00019afad8\",\"_links\":{
  02:30:39.873 [front-end] Posting Customer: {"username":"sxaQwNVapnJmG","password":"YaMtvlig","email":"sxaQwNVapnJmG@gmail.com","firstName":"sxaQwNVapnJmG","lastName":"sxaQwNVapnJmG"}
  02:30:40.968 [front-end] Received response: "{\"firstName\":\"LtfIYs\",\"lastName\":\"LtfIYs\",\"username\":\"LtfIYs\",\"id\":\"673fecb5b0df5c00019afae0\",\"_links\":{\"addresses\":{\"h
  02:30:44.272 [front-end] Received response: "{\"firstName\":\"nKMvIhSMzWzMMbZ\",\"lastName\":\"nKMvIhSMzWzMMbZ\",\"username\":\"nKMvIhSMzWzMMbZ\",\"id\":\"673fecc3b0df5c00019afb06\",\"_
  02:30:45.820 [front-end] Posting Customer: {"username":"EykSJIfFjmCBI","password":"paOUHqKR","email":"EykSJIfFjmCBI@gmail.com","firstName":"EykSJIfFjmCBI","lastName":"EykSJIfFjmCBI"}
  02:30:48.556 [front-end] Order response: {"statusCode":201,"body":{"id":"673fecd8d94b9000069b3a57","customerId":"673fecc2b0df5c00019afb05","customer":{"id":null,"firstName":"yZipUyWKrXG
  02:30:51.301 [front-end] Order response: {"id":"673fecdbd94b9000069b3a59","customerId":"673fecccb0df5c00019afb21","customer":{"id":null,"firstName":"GWGgtzEhCRKx","lastName":"GWGgtzEhCR
  02:30:56.029 [front-end] Posting Customer: {"username":"rELSnLBjLXmJ","password":"QvgpMqCkKm","email":"rELSnLBjLXmJ@gmail.com","firstName":"rELSnLBjLXmJ","lastName":"rELSnLBjLXmJ"}
  02:30:59.165 [front-end] Received response: "{\"firstName\":\"NCSOeCpIj\",\"lastName\":\"NCSOeCpIj\",\"username\":\"NCSOeCpIj\",\"id\":\"673fecccb0df5c00019afb25\",\"_links\":{\"address
  02:31:01.396 [front-end] Posting Customer: {"username":"SlQVnoRsUxXq","password":"uJCbHCnl","email":"SlQVnoRsUxXq@gmail.com","firstName":"SlQVnoRsUxXq","lastName":"SlQVnoRsUxXq"}
  02:31:02.883 [front-end] Order response: {"statusCode":201,"body":{"id":"673fece6d94b9000069b3a63","customerId":"673feccab0df5c00019afb1c","customer":{"id":null,"firstName":"kPcMhms","l
  02:31:04.911 [front-end] Order response: {"statusCode":201,"body":{"id":"673fece8d94b9000069b3a65","customerId":"673fecd5b0df5c00019afb42","customer":{"id":null,"firstName":"ONtxcnPMZ",
  02:31:08.474 [front-end] Order response: {"statusCode":201,"body":{"id":"673fececd94b9000069b3a68","customerId":"673fecd0b0df5c00019afb2d","customer":{"id":null,"firstName":"HRXHxNrozuy
  02:31:10.567 [front-end] Posting Customer: {"username":"xkfFQx","password":"rRPny","email":"xkfFQx@gmail.com","firstName":"xkfFQx","lastName":"xkfFQx"}
  02:31:11.890 [user] ts=2024-11-22T02:31:11.890087344Z caller=middlewares.go:46 method=Register username=HlMKMqe email=HlMKMqe@gmail.com took=1.088039ms
  02:31:16.409 [front-end] Posting Customer: {"username":"vOngQKyZc","password":"TxFUVDpg","email":"vOngQKyZc@gmail.com","firstName":"vOngQKyZc","lastName":"vOngQKyZc"}
  02:31:18.687 [front-end] Order response: {"statusCode":201,"body":{"id":"673fecf6d94b9000069b3a71","customerId":"673fece3b0df5c00019afb67","customer":{"id":null,"firstName":"QEBhPhFKZZi
  02:31:21.280 [front-end] Order response: {"id":"673fecf9d94b9000069b3a74","customerId":"673fece0b0df5c00019afb5e","customer":{"id":null,"firstName":"rELSnLBjLXmJ","lastName":"rELSnLBjLX
  02:31:24.769 [front-end] Received response: "{\"firstName\":\"JfsaDEpOG\",\"lastName\":\"JfsaDEpOG\",\"username\":\"JfsaDEpOG\",\"id\":\"673fece8b0df5c00019afb71\",\"_links\":{\"address
  02:31:27.720 [carts-db] {"t":{"$date":"2024-11-22T02:31:27.720+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224268
  02:31:29.925 [front-end] Posting Customer: {"username":"ffIqqRGdZ","password":"RWJtZqs","email":"ffIqqRGdZ@gmail.com","firstName":"ffIqqRGdZ","lastName":"ffIqqRGdZ"}
  02:31:31.879 [front-end] Order response: {"id":"673fed03d94b9000069b3a7e","customerId":"673fecf1b0df5c00019afb8e","customer":{"id":null,"firstName":"RRzRe","lastName":"RRzRe","username"

## p0582
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-admin-basic-info-service, 2024-12-07T18:31:32.290Z
```
{"timestamp":1733596292290409000,"container_name":"ts-admin-basic-info-service","pod_name":"ts-admin-basic-info-service-87bf97b79-r6scf","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:32.289 ERROR 1 --- [io-18767-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception\n"}
```
Same service, the 2 minutes before (oldest first):
  18:30:44.242 [ts-admin-basic-info-service] 2024-12-07 18:30:44.242 INFO 1 --- [io-18767-exec-8] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×6)
  18:30:47.992 [ts-admin-basic-info-service] 2024-12-07 18:30:47.992 INFO 1 --- [io-18767-exec-6] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×6)
  18:30:47.998 [ts-admin-basic-info-service] 2024-12-07 18:30:47.998 INFO 1 --- [io-18767-exec-6] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×6)
  18:30:54.348 [ts-admin-basic-info-service] 2024-12-07 18:30:54.348 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin 
  18:31:32.280 [ts-admin-basic-info-service] 2024-12-07 18:31:32.280 ERROR 1 --- [io-18767-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
All services, 30 seconds either side (sampled):
  18:31:02.450 [ts-admin-basic-info-service] 2024-12-07 18:31:02.450 INFO 1 --- [io-18767-exec-8] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×3)
  18:31:03.835 [ts-route-service] 2024-12-07 18:31:03.835 INFO 1 --- [io-11178-exec-8] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×56)
  18:31:03.854 [ts-travel-service] 2024-12-07 18:31:03.854 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×8)
  18:31:03.869 [ts-auth-service] 2024-12-07 18:31:03.869 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  18:31:03.873 [ts-auth-service] 2024-12-07 18:31:03.873 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces=[applicati
  18:31:03.905 [ts-basic-service] 2024-12-07 18:31:03.905 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou  (×2)
  18:31:03.950 [ts-seat-service] 2024-12-07 18:31:03.950 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×3)
  18:31:04.007 [ts-travel-service] 2024-12-07 18:31:04.006 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×10)
  18:31:04.652 [ts-seat-service] 2024-12-07 18:31:04.652 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×2)
  18:31:06.635 [ts-basic-service] 2024-12-07 18:31:06.634 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×28)
  18:31:06.737 [ts-order-other-service] 2024-12-07 18:31:06.736 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×3)
  18:31:06.805 [ts-order-other-service] 2024-12-07 18:31:06.805 INFO 1 --- [io-12032-exec-8] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×7)
  18:31:06.909 [ts-travel2-service] 2024-12-07 18:31:06.909 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6  (×4)
  18:31:07.952 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:07 +0800] "POST /api/v1/orderOtherService/orderOther/refresh HTTP/1.1" 500 220 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_1  (×4)
  18:31:09.181 [ts-auth-service] 2024-12-07 18:31:09.181 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact
  18:31:10.954 [ts-auth-service] 2024-12-07 18:31:10.953 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.907 seconds (JVM running for 71.147)
  18:31:11.694 [ts-seat-service] 2024-12-07 18:31:11.694 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×5)
  18:31:12.106 [ts-seat-service] 2024-12-07 18:31:12.106 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da
  18:31:13.587 [ts-auth-service] 2024-12-07 18:31:13.586 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  18:31:18.568 [ts-auth-service] 2024-12-07 18:31:18.568 INFO 1 --- [io-12340-exec-3] org.mongodb.driver.connection : Opened connection [connectionId{localValue:3, serverValue:22}] to ts-auth-m  (×2)
  18:31:19.676 [ts-travel2-service] 2024-12-07 18:31:19.676 ERROR 1 --- [io-16346-exec-2] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×11)
  18:31:21.810 [ts-order-other-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×2)
  18:31:28.268 [ts-admin-travel-service] 2024-12-07 18:31:28.268 ERROR 1 --- [io-16114-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×6)
  18:31:29.879 [ts-consign-mongo] {"t":{"$date":"2024-12-07T18:31:29.879+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:30.788 [ts-user-mongo] {"t":{"$date":"2024-12-07T18:31:30.788+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:31.703 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:31 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 500 229 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Apple
  18:31:42.217 [ts-payment-mongo] {"t":{"$date":"2024-12-07T18:31:42.217+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359630

## p0422
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T04:08:03.942Z
```
{"timestamp":1732248483942121200,"container_name":"front-end","pod_name":"front-end-ccbbfbf7f-szg8d","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"set cookie674003a3b0df5c00019b4112"}
```
Same service, the 2 minutes before (oldest first):
  04:08:03.266 [front-end] { id: '674003a3b0df5c00019b4110' }  (×3)
  04:08:03.266 [front-end] 674003a3b0df5c00019b4110  (×3)
  04:08:03.266 [front-end] Merging carts for customer id: 674003a3b0df5c00019b4110 and session id: jnISKiTRaFwdCJHUn8WYbMXUHWIOX3JL  (×3)
  04:08:03.292 [front-end] Carts merged.  (×3)
  04:08:03.293 [front-end] set cookie674003a3b0df5c00019b4110  (×2)
  04:08:03.293 [front-end] Sent cookies.  (×2)
  04:08:03.293 [front-end] POST /register 200 34.078 ms - 33  (×2)
  04:08:03.384 [front-end] Posting Customer: {"username":"DbigCh","password":"VIPEbntsg","email":"DbigCh@gmail.com","firstName":"DbigCh","lastName":"DbigCh"}
  04:08:03.911 [front-end] Posting Customer: {"username":"CrgKatnF","password":"WnVkgGQA","email":"CrgKatnF@gmail.com","firstName":"CrgKatnF","lastName":"CrgKatnF"}
All services, 30 seconds either side (sampled):
  04:07:33.953 [front-end] Posting Customer: {"username":"ufjrsrnfdv","password":"IHEcNa","email":"ufjrsrnfdv@gmail.com","firstName":"ufjrsrnfdv","lastName":"ufjrsrnfdv"}
  04:07:34.347 [front-end] Received response: "{\"firstName\":\"andijlOlPeiF\",\"lastName\":\"andijlOlPeiF\",\"username\":\"andijlOlPeiF\",\"id\":\"67400370b0df5c00019b4073\",\"_links\":{
  04:07:34.379 [orders] 2024-11-22 04:07:34.379 INFO [orders,5a444f9c4f47e776,4012b4fb3ce36048,false] 6 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Received payment re  (×36)
  04:07:34.405 [front-end] Order response: {"id":"67400386d94b9000069b4c3d","customerId":"67400371b0df5c00019b4077","customer":{"id":null,"firstName":"bKUJFztdrgdPeV","lastName":"bKUJFztd
  04:07:35.185 [user] ts=2024-11-22T04:07:35.184934858Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=6740037fb0df5c00019b40a7 took=1.816942ms  (×64)
  04:07:35.300 [front-end] POST to carts: http://carts/carts/67400380b0df5c00019b40a8/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×37)
  04:07:36.272 [user] ts=2024-11-22T04:07:36.272772785Z caller=middlewares.go:46 method=Register username=Qyygx email=Qyygx@gmail.com took=1.004693ms
  04:07:38.092 [front-end] Posting Customer: {"username":"WitKkcFZwL","password":"WtLeQeFezF","email":"WitKkcFZwL@gmail.com","firstName":"WitKkcFZwL","lastName":"WitKkcFZwL"}
  04:07:41.320 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  04:07:44.054 [front-end] Posting Customer: {"username":"bPueE","password":"OPhVcMRp","email":"bPueE@gmail.com","firstName":"bPueE","lastName":"bPueE"}
  04:07:46.015 [front-end] Posting Customer: {"username":"jkSTeHj","password":"fjGLoQAviA","email":"jkSTeHj@gmail.com","firstName":"jkSTeHj","lastName":"jkSTeHj"}
  04:07:49.432 [front-end] Received response: "{\"firstName\":\"zVnijz\",\"lastName\":\"zVnijz\",\"username\":\"zVnijz\",\"id\":\"6740037fb0df5c00019b40a7\",\"_links\":{\"addresses\":{\"h
  04:07:51.682 [front-end] Posting Customer: {"username":"NZPUWaPb","password":"sqqVzva","email":"NZPUWaPb@gmail.com","firstName":"NZPUWaPb","lastName":"NZPUWaPb"}
  04:07:53.450 [front-end] Order response: {"statusCode":201,"body":{"id":"67400399d94b9000069b4c4f","customerId":"67400380b0df5c00019b40a8","customer":{"id":null,"firstName":"gbedOMPJVGt
  04:07:55.715 [front-end] Order response: {"id":"6740039bd94b9000069b4c51","customerId":"67400388b0df5c00019b40c7","customer":{"id":null,"firstName":"FjEGNtd","lastName":"FjEGNtd","usern
  04:07:57.570 [front-end] Order response: {"statusCode":201,"body":{"id":"6740039dd94b9000069b4c55","customerId":"67400388b0df5c00019b40c6","customer":{"id":null,"firstName":"Qyygx","las
  04:08:02.014 [front-end] Posting Customer: {"username":"PeYmis","password":"EFpQBzV","email":"PeYmis@gmail.com","firstName":"PeYmis","lastName":"PeYmis"}
  04:08:04.224 [front-end] Order response: {"statusCode":201,"body":{"id":"674003a4d94b9000069b4c59","customerId":"6740038eb0df5c00019b40e0","customer":{"id":null,"firstName":"oRGAeskxzcD
  04:08:07.863 [user] ts=2024-11-22T04:08:07.863140454Z caller=middlewares.go:46 method=Register username=VqKMVwMkB email=VqKMVwMkB@gmail.com took=1.067727ms
  04:08:10.180 [front-end] Received response: "{\"firstName\":\"sjPfoLtijhkpMU\",\"lastName\":\"sjPfoLtijhkpMU\",\"username\":\"sjPfoLtijhkpMU\",\"id\":\"67400397b0df5c00019b40f5\",\"_lin
  04:08:12.183 [front-end] Order response: {"id":"674003acd94b9000069b4c5d","customerId":"6740039ab0df5c00019b40fe","customer":{"id":null,"firstName":"CBaAMlCgiW","lastName":"CBaAMlCgiW",
  04:08:13.725 [user] ts=2024-11-22T04:08:13.725264068Z caller=middlewares.go:46 method=Register username=VjqVALl email=VjqVALl@gmail.com took=935.753µs
  04:08:18.573 [front-end] Order response: {"statusCode":201,"body":{"id":"674003b2d94b9000069b4c62","customerId":"6740039eb0df5c00019b4104","customer":{"id":null,"firstName":"hLKvNzgPEYx
  04:08:20.756 [front-end] Posting Customer: {"username":"ILWOEKIzKoEnfrW","password":"OFmwdmTc","email":"ILWOEKIzKoEnfrW@gmail.com","firstName":"ILWOEKIzKoEnfrW","lastName":"ILWOEKIzKoEn
  04:08:22.210 [front-end] Order response: {"statusCode":201,"body":{"id":"674003b6d94b9000069b4c69","customerId":"674003a3b0df5c00019b4112","customer":{"id":null,"firstName":"CrgKatnF","
  04:08:25.792 [user] ts=2024-11-22T04:08:25.791841682Z caller=middlewares.go:46 method=Register username=HCKCy email=HCKCy@gmail.com took=1.189033ms
  04:08:28.799 [front-end] Received response: "{\"firstName\":\"TplQFHJ\",\"lastName\":\"TplQFHJ\",\"username\":\"TplQFHJ\",\"id\":\"674003a5b0df5c00019b411b\",\"_links\":{\"addresses\":{
  04:08:29.301 [orders-db] {"t":{"$date":"2024-11-22T04:08:29.300+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224850
  04:08:32.409 [front-end] Posting Customer: {"username":"JiQocuIHaDKr","password":"yvwvSQYJ","email":"JiQocuIHaDKr@gmail.com","firstName":"JiQocuIHaDKr","lastName":"JiQocuIHaDKr"}

## p0448
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service shipping, 2024-11-23T08:06:11.912Z
```
{"timestamp":1732349171912852500,"container_name":"shipping","pod_name":"shipping-58b65f576-rlt9r","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:11.912  INFO [shipping,,,] 7 --- [           main] o.s.s.c.ThreadPoolTaskScheduler          : Initializing ExecutorService "}
```
Same service, the 2 minutes before (oldest first):
  08:06:07.007 [shipping] 2024-11-23 08:06:07.007 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT
  08:06:07.007 [shipping] 2024-11-23 08:06:07.007 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=
  08:06:07.008 [shipping] 2024-11-23 08:06:07.008 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[DELETE],prod
  08:06:07.008 [shipping] 2024-11-23 08:06:07.008 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[GET],produce
  08:06:07.009 [shipping] 2024-11-23 08:06:07.009 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[OPTIONS],produces=[ap
  08:06:07.099 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[appli
  08:06:07.099 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applic
  08:06:07.099 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[GET],produce  (×2)
  08:06:07.100 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],pro
  08:06:07.100 [shipping] 2024-11-23 08:06:07.100 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produc
  08:06:07.103 [shipping] 2024-11-23 08:06:07.102 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframe
  08:06:07.103 [shipping] 2024-11-23 08:06:07.103 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[text/html]}" onto publ
  08:06:07.103 [shipping] 2024-11-23 08:06:07.103 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[OPTIONS],produces=[ap
  08:06:07.103 [shipping] 2024-11-23 08:06:07.103 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applic  (×2)
  08:06:07.104 [shipping] 2024-11-23 08:06:07.103 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[OPTIONS]}" onto public org.springf
  08:06:07.105 [shipping] 2024-11-23 08:06:07.105 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.ht
  08:06:07.299 [shipping] 2024-11-23 08:06:07.298 INFO [shipping,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptio
  08:06:07.299 [shipping] 2024-11-23 08:06:07.299 INFO [shipping,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springfram
All services, 30 seconds either side (sampled):
  08:05:41.931 [front-end] Request received with body: {}  (×58)
  08:05:42.953 [front-end] Received response: "{\"firstName\":\"LqGAWNLJ\",\"lastName\":\"LqGAWNLJ\",\"username\":\"LqGAWNLJ\",\"id\":\"67418cbfa437380001deebf9\",\"_links\":{\"addresses\
  08:05:43.570 [front-end] Attempting to delete cart for user: 67418cd0a437380001deec2e  (×65)
  08:05:44.588 [orders] 2024-11-23 08:05:44.587 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:05:45.631 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×14)
  08:05:49.010 [shipping] 2024-11-23 08:05:49.009 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/shipping],methods=[POST]}" onto public works.weav
  08:05:49.992 [user] ts=2024-11-23T08:05:49.992147424Z caller=middlewares.go:104 method=GetAddresses id=67418cd0a437380001deec30 result=1 took=1.797568ms  (×51)
  08:05:54.265 [front-end] Posting Customer: {"username":"imiXj","password":"mbjOThU","email":"imiXj@gmail.com","firstName":"imiXj","lastName":"imiXj"}
  08:05:55.008 [shipping] 2024-11-23 08:05:55.007 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applica
  08:05:57.540 [front-end] Posting Customer: {"username":"wgwvbFuCgu","password":"jthSvQsfs","email":"wgwvbFuCgu@gmail.com","firstName":"wgwvbFuCgu","lastName":"wgwvbFuCgu"}
  08:06:00.402 [shipping] 2024-11-23 08:06:00.402 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class
  08:06:04.195 [front-end] Received response: "{\"firstName\":\"MQTmuf\",\"lastName\":\"MQTmuf\",\"username\":\"MQTmuf\",\"id\":\"67418cd8a437380001deec46\",\"_links\":{\"addresses\":{\"h
  08:06:07.000 [shipping] 2024-11-23 08:06:06.999 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+j
  08:06:07.007 [shipping] 2024-11-23 08:06:07.007 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT
  08:06:07.603 [front-end] Posting Customer: {"username":"ucodWkVEg","password":"qgiOJg","email":"ucodWkVEg@gmail.com","firstName":"ucodWkVEg","lastName":"ucodWkVEg"}
  08:06:13.586 [front-end] Received response: "{\"firstName\":\"psXVPVgRfTd\",\"lastName\":\"psXVPVgRfTd\",\"username\":\"psXVPVgRfTd\",\"id\":\"67418cdda437380001deec55\",\"_links\":{\"a
  08:06:15.603 [carts] 2024-11-23 08:06:15.603 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.actu
  08:06:15.805 [carts] 2024-11-23 08:06:15.805 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[DELETE],produce
  08:06:16.401 [shipping] 2024-11-23 08:06:16.400 INFO [shipping,,,] 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase -2147482648
  08:06:19.002 [carts] 2024-11-23 08:06:19.002 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  08:06:19.274 [front-end] Posting Customer: {"username":"ctDNRPS","password":"kZNuA","email":"ctDNRPS@gmail.com","firstName":"ctDNRPS","lastName":"ctDNRPS"}
  08:06:24.004 [carts] 2024-11-23 08:06:24.003 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:06:26.093 [front-end] Received response: "{\"firstName\":\"XJzSyDLxvp\",\"lastName\":\"XJzSyDLxvp\",\"username\":\"XJzSyDLxvp\",\"id\":\"67418cefa437380001deec90\",\"_links\":{\"addr
  08:06:28.351 [front-end] Received response: "{\"firstName\":\"VnaknAEtTvwY\",\"lastName\":\"VnaknAEtTvwY\",\"username\":\"VnaknAEtTvwY\",\"id\":\"67418ceca437380001deec88\",\"_links\":{
  08:06:31.705 [carts-db] {"t":{"$date":"2024-11-23T08:06:31.705+00:00"},"s":"I", "c":"STORAGE", "id":20320, "ctx":"conn4","msg":"createCollection","attr":{"namespace":"data.cart","uuidD  (×8)
  08:06:32.828 [shipping] 2024-11-23 08:06:32.828 INFO [shipping,,,] 7 --- [p-nio-80-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization star
  08:06:34.918 [rabbitmq] accepting AMQP connection <0.573.0> (127.0.0.6:57579 -> 192.168.93.151:5672) 
  08:06:36.198 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d0b3f77060008864e3f","customerId":"67418cf2a437380001deec94","customer":{"id":null,"firstName":"SPVlWNNsjee
  08:06:40.396 [front-end] Posting Customer: {"username":"ehjzbOPHpDjC","password":"qwbmwOfmZE","email":"ehjzbOPHpDjC@gmail.com","firstName":"ehjzbOPHpDjC","lastName":"ehjzbOPHpDjC"}
  08:06:41.695 [front-end] Received response: "{\"firstName\":\"teNYQYg\",\"lastName\":\"teNYQYg\",\"username\":\"teNYQYg\",\"id\":\"67418cf5a437380001deec9b\",\"_links\":{\"addresses\":{

## p0451
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-23T08:06:16.482Z
```
{"timestamp":1732349176482107400,"container_name":"orders","pod_name":"orders-7fff6698cb-rlq5k","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:16.481 ERROR [orders,,,] 8 --- [p-nio-80-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalStateException: Unable to create order due to unspecified IO error.] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  08:06:07.524 [orders] 2024-11-23 08:06:07.523 ERROR [orders,,,] 8 --- [p-nio-80-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×9)
  08:06:07.524 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×10)
  08:06:13.958 [orders] 2024-11-23 08:06:13.958 ERROR [orders,,,] 8 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
All services, 30 seconds either side (sampled):
  08:05:46.584 [catalogue] ts=2024-11-23T08:05:46Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.29542ms  (×59)
  08:05:47.631 [user] ts=2024-11-23T08:05:47.631272964Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418cd4a437380001deec3c took=5.603144ms  (×59)
  08:05:48.736 [payment] ts=2024-11-23T08:05:48Z caller=logging.go:40 method=Health result=1 took=6.722µs  (×40)
  08:05:49.280 [front-end] Sent cookies.  (×62)
  08:05:50.768 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×8)
  08:05:54.899 [shipping] 2024-11-23 08:05:54.899 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produ
  08:05:55.028 [user] ts=2024-11-23T08:05:55.027714889Z caller=middlewares.go:46 method=Register username=brTpfrzj email=brTpfrzj@gmail.com took=2.180901ms
  08:05:57.540 [front-end] Posting Customer: {"username":"wgwvbFuCgu","password":"jthSvQsfs","email":"wgwvbFuCgu@gmail.com","firstName":"wgwvbFuCgu","lastName":"wgwvbFuCgu"}
  08:06:00.402 [shipping] 2024-11-23 08:06:00.402 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class
  08:06:04.195 [front-end] Received response: "{\"firstName\":\"MQTmuf\",\"lastName\":\"MQTmuf\",\"username\":\"MQTmuf\",\"id\":\"67418cd8a437380001deec46\",\"_links\":{\"addresses\":{\"h
  08:06:07.000 [shipping] 2024-11-23 08:06:06.999 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+j
  08:06:07.007 [shipping] 2024-11-23 08:06:07.007 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT
  08:06:07.603 [front-end] Posting Customer: {"username":"ucodWkVEg","password":"qgiOJg","email":"ucodWkVEg@gmail.com","firstName":"ucodWkVEg","lastName":"ucodWkVEg"}
  08:06:13.374 [user] ts=2024-11-23T08:06:13.374609026Z caller=middlewares.go:46 method=Register username=teNYQYg email=teNYQYg@gmail.com took=2.529487ms
  08:06:15.130 [front-end] Received response: "{\"firstName\":\"RSyStLrwvSRDG\",\"lastName\":\"RSyStLrwvSRDG\",\"username\":\"RSyStLrwvSRDG\",\"id\":\"67418ce1a437380001deec62\",\"_links\
  08:06:15.805 [carts] 2024-11-23 08:06:15.804 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[GE
  08:06:15.906 [carts] 2024-11-23 08:06:15.904 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[text/html]}" onto public 
  08:06:18.955 [user] ts=2024-11-23T08:06:18.95496322Z caller=middlewares.go:46 method=Register username=VWOjt email=VWOjt@gmail.com took=2.434446ms
  08:06:19.105 [carts] 2024-11-23 08:06:19.104 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  08:06:22.980 [front-end] Received response: "{\"firstName\":\"LeJTlhMOCH\",\"lastName\":\"LeJTlhMOCH\",\"username\":\"LeJTlhMOCH\",\"id\":\"67418ce3a437380001deec69\",\"_links\":{\"addr
  08:06:25.637 [front-end] Posting Customer: {"username":"HRFgUBgyU","password":"iGVSOf","email":"HRFgUBgyU@gmail.com","firstName":"HRFgUBgyU","lastName":"HRFgUBgyU"}
  08:06:28.000 [carts] 2024-11-23 08:06:27.999 INFO [carts,,,] 7 --- [p-nio-80-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  08:06:30.705 [carts] 2024-11-23 08:06:30.705 INFO [carts,993241630eccab18,e1237bff67df759e,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×8)
  08:06:32.806 [orders] 2024-11-23 08:06:32.806 INFO [orders,fbcebf8ef5e82428,6d050ec4f8a03a61,false] 8 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Received payment re  (×10)
  08:06:34.719 [front-end] POST /cart 201 - ms - -  (×23)
  08:06:35.986 [orders-db] {"t":{"$date":"2024-11-23T08:06:35.986+00:00"},"s":"I", "c":"STORAGE", "id":20320, "ctx":"conn5","msg":"createCollection","attr":{"namespace":"data.customerOrde  (×5)
  08:06:39.627 [front-end] Posting Customer: {"username":"ErFfEEVmz","password":"xXhfhSu","email":"ErFfEEVmz@gmail.com","firstName":"ErFfEEVmz","lastName":"ErFfEEVmz"}
  08:06:41.163 [front-end] Received response: "{\"firstName\":\"OkxajUZjGhkcaQY\",\"lastName\":\"OkxajUZjGhkcaQY\",\"username\":\"OkxajUZjGhkcaQY\",\"id\":\"67418cf8a437380001deeca8\",\"_
  08:06:43.776 [front-end] Received response: "{\"firstName\":\"GXUtAA\",\"lastName\":\"GXUtAA\",\"username\":\"GXUtAA\",\"id\":\"67418cf8a437380001deeca7\",\"_links\":{\"addresses\":{\"h

## p0769
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service catalogue, 2024-11-23T19:26:03.931Z
```
{"timestamp":1732389963931775000,"container_name":"catalogue","pod_name":"catalogue-b98c66547-xwt5f","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T19:26:03Z caller=logging.go:85 method=Health result=2 took=20.503µs"}
```
Same service, the 2 minutes before (oldest first):
  19:25:57.931 [catalogue] ts=2024-11-23T19:25:57Z caller=logging.go:85 method=Health result=2 took=25.918µs  (×5)
  19:25:58.666 [catalogue] ts=2024-11-23T19:25:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=3.686667ms  (×6)
  19:25:59.030 [catalogue] ts=2024-11-23T19:25:59Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=4.527187  (×9)
All services, 30 seconds either side (sampled):
  19:25:33.931 [catalogue] ts=2024-11-23T19:25:33Z caller=logging.go:85 method=Health result=2 took=43.097µs  (×41)
  19:25:34.033 [catalogue] ts=2024-11-23T19:25:34Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=5.349677  (×60)
  19:25:34.882 [user] ts=2024-11-23T19:25:34.88217573Z caller=middlewares.go:75 method=GetUsers id=67422c1648485600016b1623 result=1 took=4.970467ms  (×244)
  19:25:34.936 [payment] ts=2024-11-23T19:25:34Z caller=logging.go:29 method=Authorise result=false took=7.042µs  (×4)
  19:25:35.486 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×9)
  19:25:36.751 [queue-master] 2024-11-23 19:25:36.751 ERROR 7 --- [ool-6-thread-15] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×20)
  19:25:37.009 [front-end] Merging carts for customer id: 67422c3148485600016b1672 and session id: NlJlmze5BiZC0-kNiTbzrevfyuz68kIo  (×57)
  19:25:39.319 [front-end] Order response: {"statusCode":201,"body":{"id":"67422c334ca85a00070c5287","customerId":"67422c2348485600016b1647","customer":{"id":null,"firstName":"TAnloyqVQEX
  19:25:39.978 [front-end] Order response: {"statusCode":201,"body":{"id":"67422c334ca85a00070c5289","customerId":"67422c1e48485600016b1637","customer":{"id":null,"firstName":"LuwbwReMowK
  19:25:41.291 [user] ts=2024-11-23T19:25:41.29119221Z caller=middlewares.go:46 method=Register username=qhWlY email=qhWlY@gmail.com took=4.737052ms
  19:25:43.652 [front-end] Order response: {"id":"67422c374ca85a00070c528d","customerId":"67422c2348485600016b1648","customer":{"id":null,"firstName":"XKiGD","lastName":"XKiGD","username"
  19:25:44.884 [front-end] Posting Customer: {"username":"RERtqeJ","password":"ryWFN","email":"RERtqeJ@gmail.com","firstName":"RERtqeJ","lastName":"RERtqeJ"}
  19:25:47.591 [front-end] Received response: "{\"firstName\":\"yaLKPdl\",\"lastName\":\"yaLKPdl\",\"username\":\"yaLKPdl\",\"id\":\"67422c2a48485600016b1655\",\"_links\":{\"addresses\":{
  19:25:49.027 [user] ts=2024-11-23T19:25:49.027063932Z caller=middlewares.go:46 method=Register username=dSpnzjvZV email=dSpnzjvZV@gmail.com took=5.690162ms
  19:25:50.575 [user] ts=2024-11-23T19:25:50.575166303Z caller=middlewares.go:46 method=Register username=VVHDXt email=VVHDXt@gmail.com took=4.694283ms
  19:25:52.392 [front-end] Order response: {"id":"67422c404ca85a00070c5296","customerId":"67422c2c48485600016b165d","customer":{"id":null,"firstName":"JhuCh","lastName":"JhuCh","username"
  19:25:56.973 [front-end] Order response: {"id":"67422c444ca85a00070c5297","customerId":"67422c3348485600016b167b","customer":{"id":null,"firstName":"sBqll","lastName":"sBqll","username"
  19:26:00.267 [front-end] Received response: "{\"firstName\":\"tUoqE\",\"lastName\":\"tUoqE\",\"username\":\"tUoqE\",\"id\":\"67422c3148485600016b1672\",\"_links\":{\"addresses\":{\"href
  19:26:01.678 [user] ts=2024-11-23T19:26:01.678208421Z caller=middlewares.go:46 method=Register username=QGveaEFvl email=QGveaEFvl@gmail.com took=5.104741ms
  19:26:05.342 [front-end] Received response: "{\"firstName\":\"HhpbGtMdbLNh\",\"lastName\":\"HhpbGtMdbLNh\",\"username\":\"HhpbGtMdbLNh\",\"id\":\"67422c3748485600016b167f\",\"_links\":{
  19:26:09.620 [front-end] Received response: "{\"firstName\":\"RvmTgs\",\"lastName\":\"RvmTgs\",\"username\":\"RvmTgs\",\"id\":\"67422c3d48485600016b168e\",\"_links\":{\"addresses\":{\"h
  19:26:12.225 [front-end] Received response: "{\"firstName\":\"AnfITfpoSgHTzM\",\"lastName\":\"AnfITfpoSgHTzM\",\"username\":\"AnfITfpoSgHTzM\",\"id\":\"67422c3e48485600016b1690\",\"_lin
  19:26:13.898 [carts] Caused by: java.net.ConnectException: Connection refused (Connection refused) at java.net.PlainSocketImpl.socketConnect(Native Method) ~[na:1.8.0_131] at java.n
  19:26:15.639 [user] ts=2024-11-23T19:26:15.638931858Z caller=middlewares.go:46 method=Register username=ELtTnecX email=ELtTnecX@gmail.com took=5.429568ms
  19:26:18.357 [user] ts=2024-11-23T19:26:18.35784749Z caller=middlewares.go:46 method=Register username=qAmnBz email=qAmnBz@gmail.com took=4.806248ms
  19:26:22.683 [front-end] Posting Customer: {"username":"EtSIzsYUhk","password":"CfVwL","email":"EtSIzsYUhk@gmail.com","firstName":"EtSIzsYUhk","lastName":"EtSIzsYUhk"}
  19:26:27.037 [front-end] Received response: "{\"firstName\":\"QfoArW\",\"lastName\":\"QfoArW\",\"username\":\"QfoArW\",\"id\":\"67422c5448485600016b16db\",\"_links\":{\"addresses\":{\"h
  19:26:30.904 [front-end] Received response: "{\"firstName\":\"IEqFcGdxTpdkLZ\",\"lastName\":\"IEqFcGdxTpdkLZ\",\"username\":\"IEqFcGdxTpdkLZ\",\"id\":\"67422c5248485600016b16d7\",\"_lin

## p0681
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-12T00:33:33.503Z
```
{"service":"dbservice2","message":"2021-08-12 00:33:33,503 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | 4b7c31f61aef5aa4 | de1e99ec-fac1-11eb-a7b7-0242ac110004-IjgwExRc-SL&dYC@_yX^8 token generate success token=MTYyODY5OTYxMy41MDI0Nzg2OmRlMWU5OWVjLWZhYzEtMTFlYi1hN2I3LTAyNDJhYzExMDAwNElqZ3dFeFJjU0wmZFlDQF95WF44OjE2Mjg2OTk2NzMuNTAyNDkzNjozYmQ2OTVkNWQxZjAxOTZkMzZjYjBjNTM3ZmY2ZDQxOQ=="}
```
Same service, the 2 minutes before (oldest first):
  00:33:23.360 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×6)
  00:33:23.375 [dbservice2] INFO query = select passwards from username_table where user_name='xXiaofbu'  (×4)
  00:33:23.452 [dbservice2] INFO d832d2aa-fac1-11eb-becb-0242ac110004-xXiaofbu-2Yl&jd#+ApZV token generate success token=MTYyODY5OTYwMy40NTIwNzE3OmQ4MzJkMmFhLWZhYzEtMTFlYi1iZWNiLTAyNDJhYzE
  00:33:24.868 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  00:33:24.963 [dbservice2] INFO d9139db2-fac1-11eb-b1b3-0242ac110004-cgKfeRjJ-?%FBPz^@kcZD token generate success token=MTYyODY5OTYwNC45NjI1NjU0OmQ5MTM5ZGIyLWZhYzEtMTFlYi1iMWIzLTAyNDJhYzE
  00:33:27.796 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×2)
  00:33:32.265 [dbservice2] INFO dd748894-fac1-11eb-8fe9-0242ac110003-URMboZjf-a!7vBu@Ms{3G token generate success token=MTYyODY5OTYxMi4yNjUzMTQzOmRkNzQ4ODk0LWZhYzEtMTFlYi04ZmU5LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  00:33:03.544 [dbservice2] INFO cc4c9cf0-fac1-11eb-9636-0242ac110004-hCIZuDLt-F^*JxWUs&YgO token generate success token=MTYyODY5OTU4My41NDQyMzk1OmNjNGM5Y2YwLWZhYzEtMTFlYi05NjM2LTAyNDJhYzE
  00:33:03.845 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×43)
  00:33:04.090 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×45)
  00:33:04.194 [logservice1] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': 'cccce87e-fac1-11eb-a738-0242ac110004', 'user_id': 'rcwlDFam'}  (×83)
  00:33:04.585 [mobservice2] INFO info cd24f29e-fac1-11eb-8736-0242ac110004:yjlLtMmx write success
  00:33:05.765 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'cdd645b2-fac1-11eb-a5fa-0242ac110004', 'value': 'oGQcxZEF'}  (×47)
  00:33:06.403 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×40)
  00:33:07.724 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  00:33:08.341 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×38)
  00:33:09.694 [mobservice1] INFO info d033b2b8-fac1-11eb-8d3c-0242ac110003:SBgdrmlT write success
  00:33:11.645 [dbservice1] INFO d11ef1e2-fac1-11eb-99f7-0242ac110004-kHIDhMnd-h+i/nz=N}69% token generate success token=MTYyODY5OTU5MS42NDQ2ODE3OmQxMWVmMWUyLWZhYzEtMTFlYi05OWY3LTAyNDJhYzE
  00:33:14.172 [dbservice2] INFO d2a6876e-fac1-11eb-89b1-0242ac110003-HygISCUR-nDh8._Bb7*Ce token generate success token=MTYyODY5OTU5NC4xNzE4NDczOmQyYTY4NzZlLWZhYzEtMTFlYi04OWIxLTAyNDJhYzE
  00:33:16.631 [dbservice2] INFO d4187aee-fac1-11eb-b8ce-0242ac110003-QNgzxusO-msv)gRlMu=0. token generate success token=MTYyODY5OTU5Ni42MzEyMDgyOmQ0MTg3YWVlLWZhYzEtMTFlYi1iOGNlLTAyNDJhYzE
  00:33:19.368 [dbservice2] INFO d5906d00-fac1-11eb-a30d-0242ac110004-TAFqsYCb-Tg=w38JHoFAy token generate success token=MTYyODY5OTU5OS4zNjgxODI6ZDU5MDZkMDAtZmFjMS0xMWViLWEzMGQtMDI0MmFjMTE  (×3)
  00:33:22.186 [dbservice2] INFO d774d818-fac1-11eb-9e31-0242ac110003-kOerFKnJ-$Y(ZQN69hFpt token generate success token=MTYyODY5OTYwMi4xODYzNTA4OmQ3NzRkODE4LWZhYzEtMTFlYi05ZTMxLTAyNDJhYzE
  00:33:27.796 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×2)
  00:33:33.883 [dbservice1] INFO de69df92-fac1-11eb-8e66-0242ac110004-RvTnrFIP-:ZzxcU>5O1Jw token generate success token=MTYyODY5OTYxMy44ODMxODQ6ZGU2OWRmOTItZmFjMS0xMWViLThlNjYtMDI0MmFjMTE
  00:33:36.619 [mobservice1] INFO info e037a728-fac1-11eb-819c-0242ac110003:CwasWDxu write success
  00:33:39.321 [mobservice1] INFO info e1cd4930-fac1-11eb-981e-0242ac110004:dlznWOTR write success
  00:33:42.033 [dbservice1] INFO e32c3458-fac1-11eb-a389-0242ac110004-dDmGvhol-!a=hY&k)-9}v token generate success token=MTYyODY5OTYyMi4wMzMxNzQ6ZTMyYzM0NTgtZmFjMS0xMWViLWEzODktMDI0MmFjMTE
  00:33:44.920 [dbservice1] INFO e4ed8e7c-fac1-11eb-8be1-0242ac110004-jliMGRSf-@UO%!NH}$bsm token generate success token=MTYyODY5OTYyNC45MTk2OTYzOmU0ZWQ4ZTdjLWZhYzEtMTFlYi04YmUxLTAyNDJhYzE
  00:33:47.643 [mobservice1] INFO info e6cb4a54-fac1-11eb-8633-0242ac110004:IToaCVWE write success
  00:33:50.301 [mobservice2] INFO info e863d0fc-fac1-11eb-b17b-0242ac110004:AnasJGMP write success
  00:33:53.453 [mobservice1] INFO info ea3013aa-fac1-11eb-b658-0242ac110004:lkNrGYTL write success
  00:33:56.222 [mobservice1] INFO info ebd319b4-fac1-11eb-8367-0242ac110003:RIklYufT write success
  00:33:59.162 [mobservice1] INFO info eda1c272-fac1-11eb-92f3-0242ac110003:WvNJCdPU write success
  00:34:01.848 [dbservice2] INFO ef048e60-fac1-11eb-af03-0242ac110004-tpRwcUuS-!3hEKu1y{sDW token generate success token=MTYyODY5OTY0MS44NDc3MzY0OmVmMDQ4ZTYwLWZhYzEtMTFlYi1hZjAzLTAyNDJhYzE

## p0186
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:48:26.162Z
```
{"timestamp":1731912506162377000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"home"}
```
Same service, the 2 minutes before (oldest first):
  06:48:24.631 [frontend] request complete  (×7)
  06:48:25.113 [frontend] request started  (×7)
  06:48:25.113 [frontend] serving product page  (×3)
  06:48:25.665 [frontend] adding to cart
  06:48:25.677 [frontend] view user cart
  06:48:26.158 [frontend] setting currency
All services, 30 seconds either side (sampled):
  06:48:24.473 [frontend] request started  (×158)
  06:48:24.477 [currencyservice] Getting supported currencies...  (×130)
  06:48:24.488 [currencyservice] conversion request successful  (×336)
  06:48:24.504 [adservice] received ad request (context_words=[decor, home])  (×7)
  06:48:24.556 [adservice] received ad request (context_words=[accessories])  (×19)
  06:48:24.564 [cartservice] AddItemAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03, productId=OLJCESPC7Z, quantity=1  (×17)
  06:48:24.603 [shippingservice] [GetQuote] received request  (×35)
  06:48:25.170 [adservice] received ad request (context_words=[kitchen])  (×24)
  06:48:26.158 [frontend] setting currency  (×11)
  06:48:26.213 [adservice] received ad request (context_words=[])  (×16)
  06:48:27.213 [adservice] received ad request (context_words=[footwear])  (×10)
  06:48:29.771 [frontend] home  (×15)
  06:48:30.014 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="JPY"
  06:48:30.051 [paymentservice] Transaction processed: visa ending 4133 Amount: JPY147999.249890397
  06:48:30.054 [shippingservice] [ShipOrder] received request  (×2)
  06:48:30.057 [cartservice] EmptyCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03  (×2)
  06:48:30.063 [checkoutservice] order confirmation email sent to "mccoymelissa@example.net"
  06:48:32.337 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="GBP"
  06:48:32.374 [paymentservice] Transaction processed: visa ending 3003 Amount: GBP1238.66859775
  06:48:32.389 [checkoutservice] order confirmation email sent to "ericlewis@example.org"

## p0518
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:42:19.979Z
```
{"timestamp":1732358539979457000,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"Sent cookies."}
```
Same service, the 2 minutes before (oldest first):
  10:42:19.791 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  10:42:19.791 [front-end] POST to carts: http://carts/carts/6741b186a437380001df4b87/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}
  10:42:19.794 [front-end] { id: '6741b18ba437380001df4b91' }  (×3)
  10:42:19.794 [front-end] 6741b18ba437380001df4b91  (×3)
  10:42:19.794 [front-end] Merging carts for customer id: 6741b18ba437380001df4b91 and session id: l3waOL3bBSR-X-OovXFRKSwKqWy2qmOC  (×3)
  10:42:19.828 [front-end] Carts merged.  (×2)
  10:42:19.828 [front-end] set cookie6741b18ba437380001df4b91  (×2)
  10:42:19.828 [front-end] Sent cookies.
  10:42:19.829 [front-end] POST /register 200 42.762 ms - 33
  10:42:19.845 [front-end] POST /cart 201 - ms - -
  10:42:19.936 [front-end] Posting Customer: {"username":"SlOUiiS","password":"OpdYMEsfX","email":"SlOUiiS@gmail.com","firstName":"SlOUiiS","lastName":"SlOUiiS"}
  10:42:19.947 [front-end] Posting Customer: {"username":"RIAVrKz","password":"FyNLWoFcm","email":"RIAVrKz@gmail.com","firstName":"RIAVrKz","lastName":"RIAVrKz"}
All services, 30 seconds either side (sampled):
  10:41:50.020 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b163a437380001df4b1e"}  (×59)
  10:41:50.127 [front-end] User cart deleted with status: 202  (×59)
  10:41:50.204 [user] ts=2024-11-23T10:41:50.204410193Z caller=middlewares.go:75 method=GetUsers id=6741b15ca437380001df4b0a result=1 took=2.316436ms  (×228)
  10:41:50.250 [orders] 2024-11-23 10:41:50.250 INFO [orders,e18e708728efb8b9,d8f87c65d6ace17e,false] 7 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Received payment re  (×42)
  10:41:50.908 [front-end] POST to carts: http://carts/carts/6741b164a437380001df4b21/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}  (×29)
  10:41:51.101 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b16f01dd390007094dec","customerId":"6741b154a437380001df4af4","customer":{"id":null,"firstName":"tLrtQt","la
  10:41:51.259 [front-end] Carts merged.  (×59)
  10:41:52.277 [catalogue] ts=2024-11-23T10:41:52Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.299173ms  (×56)
  10:41:54.852 [front-end] Received response: "{\"firstName\":\"lTyDxVi\",\"lastName\":\"lTyDxVi\",\"username\":\"lTyDxVi\",\"id\":\"6741b15fa437380001df4b14\",\"_links\":{\"addresses\":{
  10:41:55.759 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×11)
  10:41:57.157 [front-end] Order response: {"id":"6741b17501dd390007094df4","customerId":"6741b15ca437380001df4b07","customer":{"id":null,"firstName":"VkjiwmTiXIs","lastName":"VkjiwmTiXIs
  10:42:00.355 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b17801dd390007094df6","customerId":"6741b165a437380001df4b2c","customer":{"id":null,"firstName":"VHERO","las
  10:42:02.282 [front-end] Order response: {"id":"6741b17a01dd390007094df8","customerId":"6741b163a437380001df4b1e","customer":{"id":null,"firstName":"AsWOJvoKNL","lastName":"AsWOJvoKNL",
  10:42:05.001 [front-end] Received response: "{\"firstName\":\"sjfrIBFtnOMwhK\",\"lastName\":\"sjfrIBFtnOMwhK\",\"username\":\"sjfrIBFtnOMwhK\",\"id\":\"6741b16aa437380001df4b3a\",\"_lin
  10:42:06.357 [front-end] Posting Customer: {"username":"DjEHXcoqHgWxYbC","password":"dYGzfOac","email":"DjEHXcoqHgWxYbC@gmail.com","firstName":"DjEHXcoqHgWxYbC","lastName":"DjEHXcoqHgWx
  10:42:08.984 [payment] ts=2024-11-23T10:42:08Z caller=logging.go:29 method=Authorise result=false took=7.002µs  (×4)
  10:42:13.530 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b18501dd390007094e02","customerId":"6741b16fa437380001df4b4a","customer":{"id":null,"firstName":"DSAgaYnbcBN
  10:42:17.181 [front-end] Received response: "{\"firstName\":\"BBoDQLZVQIzI\",\"lastName\":\"BBoDQLZVQIzI\",\"username\":\"BBoDQLZVQIzI\",\"id\":\"6741b176a437380001df4b64\",\"_links\":{
  10:42:18.245 [front-end] Order response: {"id":"6741b18a01dd390007094e08","customerId":"6741b175a437380001df4b60","customer":{"id":null,"firstName":"vqiGwzuJlekI","lastName":"vqiGwzuJle
  10:42:23.996 [front-end] Received response: "{\"firstName\":\"jGtfmTYFLF\",\"lastName\":\"jGtfmTYFLF\",\"username\":\"jGtfmTYFLF\",\"id\":\"6741b17ba437380001df4b72\",\"_links\":{\"addr
  10:42:24.904 [user] ts=2024-11-23T10:42:24.904623485Z caller=middlewares.go:46 method=Register username=SGHrmQKj email=SGHrmQKj@gmail.com took=2.263575ms
  10:42:27.029 [front-end] Posting Customer: {"username":"drIpSVYoFYMY","password":"YGkAbaE","email":"drIpSVYoFYMY@gmail.com","firstName":"drIpSVYoFYMY","lastName":"drIpSVYoFYMY"}
  10:42:29.218 [front-end] Posting Customer: {"username":"mGHHyeKOwbUN","password":"QBuLJML","email":"mGHHyeKOwbUN@gmail.com","firstName":"mGHHyeKOwbUN","lastName":"mGHHyeKOwbUN"}
  10:42:32.458 [front-end] Received response: "{\"firstName\":\"fMqkVIscpJAub\",\"lastName\":\"fMqkVIscpJAub\",\"username\":\"fMqkVIscpJAub\",\"id\":\"6741b183a437380001df4b7f\",\"_links\
  10:42:34.942 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19a01dd390007094e14","customerId":"6741b186a437380001df4b87","customer":{"id":null,"firstName":"OePlWpOYf",
  10:42:38.441 [front-end] Posting Customer: {"username":"qxMKJWILAB","password":"nPYAMbLTCN","email":"qxMKJWILAB@gmail.com","firstName":"qxMKJWILAB","lastName":"qxMKJWILAB"}
  10:42:40.192 [front-end] Order response: {"id":"6741b1a001dd390007094e17","customerId":"6741b186a437380001df4b88","customer":{"id":null,"firstName":"CydfEIYWaRvI","lastName":"CydfEIYWaR
  10:42:43.085 [front-end] Posting Customer: {"username":"UILHEiEVVssclad","password":"ZqCUxOuP","email":"UILHEiEVVssclad@gmail.com","firstName":"UILHEiEVVssclad","lastName":"UILHEiEVVssc
  10:42:45.526 [front-end] Order response: {"id":"6741b1a501dd390007094e1c","customerId":"6741b196a437380001df4bad","customer":{"id":null,"firstName":"DMOcLvEBWyzQX","lastName":"DMOcLvEBW
  10:42:47.181 [front-end] Posting Customer: {"username":"EuaRkWCg","password":"mitRj","email":"EuaRkWCg@gmail.com","firstName":"EuaRkWCg","lastName":"EuaRkWCg"}

## p0824
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-08T12:12:37.429Z
```
{"timestamp":1733659957429401300,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-bkz2d","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:12:37.429  INFO 1 --- [       Thread-5] o.s.i.channel.PublishSubscribeChannel    : Channel 'ts-route-service:11178.errorChannel' has 0 subscriber(s)."}
```
Same service, the 2 minutes before (oldest first):
  12:12:32.046 [ts-route-service] 2024-12-08 12:12:32.046 INFO 1 --- [io-11178-exec-2] route.controller.RouteController : Route id: d693a2c5-ef87-4a3c-bef8-600b43f62c68  (×15)
  12:12:35.949 [ts-route-service] 2024-12-08 12:12:35.949 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: d693a2c5-ef87-4a3c-bef8-600b43f62c68  (×2)
  12:12:37.425 [ts-route-service] 2024-12-08 12:12:37.424 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  12:12:37.428 [ts-route-service] 2024-12-08 12:12:37.428 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  12:12:37.428 [ts-route-service] 2024-12-08 12:12:37.428 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
All services, 30 seconds either side (sampled):
  12:12:08.239 [ts-admin-basic-info-service] 2024-12-08 12:12:08.239 INFO 1 --- [io-18767-exec-3] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×9)
  12:12:11.823 [ts-auth-mongo] {"t":{"$date":"2024-12-08T12:12:11.823+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365993
  12:12:13.032 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-08T12:12:13.032+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365993
  12:12:13.534 [ts-price-mongo] {"t":{"$date":"2024-12-08T12:12:13.534+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173365993
  12:12:13.591 [ts-basic-service] 2024-12-08 12:12:13.590 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×15)
  12:12:13.638 [ts-basic-service] 2024-12-08 12:12:13.638 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×9)
  12:12:13.693 [ts-seat-service] 2024-12-08 12:12:13.693 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×24)
  12:12:13.738 [ts-seat-service] 2024-12-08 12:12:13.738 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×23)
  12:12:13.846 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:12:13 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 343 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×15)
  12:12:14.915 [ts-travel2-service] 2024-12-08 12:12:14.915 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  12:12:15.030 [ts-seat-service] 2024-12-08 12:12:15.030 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  12:12:16.219 [ts-travel-service] 2024-12-08 12:12:16.218 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×15)
  12:12:16.373 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:12:16 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5514 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×2)
  12:12:19.072 [ts-consign-service] 2024-12-08 12:12:19.072 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] 7c8f5e53-ba3e-4f0f-a40d-
  12:12:21.392 [ts-admin-basic-info-service] 2024-12-08 12:12:21.392 INFO 1 --- [io-18767-exec-6] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×8)
  12:12:23.497 [ts-basic-service] 2024-12-08 12:12:23.497 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×2)
  12:12:23.649 [ts-seat-service] 2024-12-08 12:12:23.649 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×5)
  12:12:25.258 [ts-travel-service] 2024-12-08 12:12:25.258 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×4)
  12:12:25.313 [ts-order-service] 2024-12-08 12:12:25.313 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024  (×6)
  12:12:25.473 [ts-travel-service] 2024-12-08 12:12:25.473 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×6)
  12:12:25.536 [ts-basic-service] 2024-12-08 12:12:25.536 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : suzhouendPlaceId : shanghai
  12:12:25.590 [ts-travel-service] 2024-12-08 12:12:25.590 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan
  12:12:29.030 [ts-food-service] 2024-12-08 12:12:29.029 INFO 1 --- [io-18856-exec-6] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!  (×2)
  12:12:31.011 [ts-basic-service] 2024-12-08 12:12:31.011 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23
  12:12:37.428 [ts-route-service] 2024-12-08 12:12:37.428 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  12:12:37.446 [ts-travel-service] 2024-12-08 12:12:37.446 INFO 1 --- [io-12346-exec-1] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×3)
  12:12:38.845 [ts-admin-travel-service] org.springframework.web.client.HttpServerErrorException: 500 Internal Server Error at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Def  (×6)
  12:12:40.474 [ts-route-service] [otel.javaagent 2024-12-08 12:12:40:474 +0000] [main] INFO io.opentelemetry.javaagent.tooling.VersionLogger - opentelemetry-javaagent - version: 2.0.0 . ____ _ 
  12:13:01.263 [ts-route-service] 2024-12-08 12:13:01.263 INFO 1 --- [ main] route.RouteApplication : No active profile set, falling back to default profiles: default

## p0027
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-13T07:30:31.010Z
```
{"service":"redisservice1","message":"2021-08-13 07:30:31,010 | INFO | 0.0.0.1 | 172.17.0.4 | redisservice1 | 31733fd6f8eaaf12 | service accept, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  07:30:25.162 [redisservice1] INFO redis读取信息成功, status_code: 200  (×5)
  07:30:25.206 [redisservice1] INFO redis write success  (×10)
  07:30:25.313 [redisservice1] INFO service accept, status_code: 200  (×2)
  07:30:25.434 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×3)
All services, 30 seconds either side (sampled):
  07:30:01.015 [redisservice2] INFO redis write success  (×84)
  07:30:01.170 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×59)
  07:30:01.409 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  07:30:01.626 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  07:30:01.745 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×44)
  07:30:02.205 [redisservice1] INFO service accept, status_code: 200  (×51)
  07:30:02.810 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×29)
  07:30:03.703 [dbservice1] INFO 37f66e46-fbc5-11eb-8f98-0242ac110004-ztuaUykM-dE:?f1Sbn.l^ token generate success token=MTYyODgxMTAwMy43MDMyNzg1OjM3ZjY2ZTQ2LWZiYzUtMTFlYi04Zjk4LTAyNDJhYzE
  07:30:04.999 [mobservice1] INFO info 38dc0a50-fbc5-11eb-bbc0-0242ac110004:QzCIyEtF write success
  07:30:07.522 [dbservice1] INFO 3a387d0c-fbc5-11eb-ba83-0242ac110003-dUFBYtEJ-L:#7fucXYzK- token generate success token=MTYyODgxMTAwNy41MjIwMTIyOjNhMzg3ZDBjLWZiYzUtMTFlYi1iYTgzLTAyNDJhYzE
  07:30:09.698 [mobservice2] INFO info 3bb96452-fbc5-11eb-bde8-0242ac110003:FKekGBJU write success
  07:30:12.314 [mobservice2] INFO info 3d40cc70-fbc5-11eb-8e2a-0242ac110004:lTYxuZoK write success
  07:30:14.945 [mobservice1] INFO info 3ec3a50e-fbc5-11eb-a7ef-0242ac110004:kLYBXRtg write success
  07:30:17.516 [mobservice1] INFO info 4050122c-fbc5-11eb-bc91-0242ac110004:THZxeBPz write success
  07:30:19.885 [mobservice2] INFO info 41ca94e2-fbc5-11eb-b2ad-0242ac110003:CMzFsYZh write success
  07:30:22.502 [dbservice2] INFO 4319388a-fbc5-11eb-ac71-0242ac110004-CfHjswnr-5atn1@V=8r4l token generate success token=MTYyODgxMTAyMi41MDE0OTY2OjQzMTkzODhhLWZiYzUtMTFlYi1hYzcxLTAyNDJhYzE
  07:30:24.987 [mobservice2] INFO info 44cb588e-fbc5-11eb-a477-0242ac110004:iZWtCSMp write success
  07:30:27.873 [mobservice1] INFO info 467fb508-fbc5-11eb-8116-0242ac110003:lebfEIwL write success
  07:30:30.641 [mobservice2] INFO info 48312e72-fbc5-11eb-98c4-0242ac110003:edQqtaui write success
  07:30:33.659 [mobservice1] INFO info 49def6a0-fbc5-11eb-9627-0242ac110004:frspTAey write success
  07:30:36.304 [dbservice2] INFO 4b547604-fbc5-11eb-adf7-0242ac110003-nlMAOLaH-.+x$_%GPZ*lV token generate success token=MTYyODgxMTAzNi4zMDQwODg6NGI1NDc2MDQtZmJjNS0xMWViLWFkZjctMDI0MmFjMTE
  07:30:38.880 [dbservice1] INFO 4cdbb2d0-fbc5-11eb-800b-0242ac110004-wzuckBhX-M8t1WKXj9vHT token generate success token=MTYyODgxMTAzOC44ODAxODI6NGNkYmIyZDAtZmJjNS0xMWViLTgwMGItMDI0MmFjMTE  (×2)
  07:30:41.372 [dbservice2] INFO 4e5bd32e-fbc5-11eb-9719-0242ac110004-EQWxHTiy-(_nq1GO.M5R6 token generate success token=MTYyODgxMTA0MS4zNzIyOTA0OjRlNWJkMzJlLWZiYzUtMTFlYi05NzE5LTAyNDJhYzE
  07:30:44.095 [mobservice1] INFO info 50292a08-fbc5-11eb-8c0e-0242ac110004:pUwNWoxq write success
  07:30:50.856 [mobservice2] INFO info 543fff2c-fbc5-11eb-8d91-0242ac110003:HnGradOx write success
  07:30:53.429 [dbservice2] INFO 558f5562-fbc5-11eb-bbc0-0242ac110004-laBJUtSP-E8m<2RIzvG_e token generate success token=MTYyODgxMTA1My40Mjg4NjQ1OjU1OGY1NTYyLWZiYzUtMTFlYi1iYmMwLTAyNDJhYzE
  07:30:56.210 [mobservice2] INFO info 5767aff6-fbc5-11eb-8564-0242ac110003:tWMvxnLr write success
  07:30:58.726 [mobservice1] INFO info 58e25980-fbc5-11eb-b1f0-0242ac110004:OVhMJowB write success

## p0791
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T20:43:56.201Z
```
{"timestamp":1732394636201781000,"container_name":"front-end","pod_name":"front-end-f77549869-gbrgw","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"npm ERR! command sh -c -- node server.js"}
```
Same service, the 2 minutes before (oldest first):
  20:43:56.196 [front-end] npm timing command:run-script Completed in 820010ms
  20:43:56.196 [front-end] npm timing command:start Completed in 820087ms
  20:43:56.197 [front-end] npm notice   (×2)
  20:43:56.197 [front-end] npm notice New major version of npm available! 8.19.4 -> 10.9.1
  20:43:56.197 [front-end] npm notice Changelog: <https://github.com/npm/cli/releases/tag/v10.9.1>
  20:43:56.197 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!
  20:43:56.199 [front-end] npm verb stack Error: command failed
  20:43:56.199 [front-end] npm verb stack at ChildProcess.<anonymous> (/usr/local/lib/node_modules/npm/node_modules/@npmcli/promise-spawn/lib/index.js:63:27)
  20:43:56.199 [front-end] npm verb stack at ChildProcess.emit (node:events:513:28)
  20:43:56.199 [front-end] npm verb stack at maybeClose (node:internal/child_process:1100:16)
  20:43:56.199 [front-end] npm verb stack at Process.ChildProcess._handle.onexit (node:internal/child_process:304:5)
  20:43:56.199 [front-end] npm verb pkgid microservices-demo-front-end@0.0.1
  20:43:56.199 [front-end] npm verb cwd /usr/src/app
  20:43:56.199 [front-end] npm verb Linux 5.10.227-219.884.amzn2.x86_64
  20:43:56.199 [front-end] npm verb node v16.20.2
  20:43:56.200 [front-end] npm verb npm v8.19.4
  20:43:56.200 [front-end] npm ERR! path /usr/src/app
  20:43:56.201 [front-end] npm ERR! command failed
  20:43:56.201 [front-end] npm ERR! signal SIGTERM
All services, 30 seconds either side (sampled):
  20:43:26.602 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67423e6848485600016b4dee"}  (×61)
  20:43:26.650 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67423e5c48485600016b4dc6\",\"_links\":{\"  (×55)
  20:43:26.678 [queue-master] 2024-11-23 20:43:26.678 INFO 7 --- [ool-6-thread-24] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×81)
  20:43:26.717 [catalogue] ts=2024-11-23T20:43:26Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=5.324115  (×51)
  20:43:27.083 [carts] 2024-11-23 20:43:27.082 INFO [carts,251acdcde5635ecb,d8b937904898ac8d,false] 6 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×32)
  20:43:27.931 [catalogue] ts=2024-11-23T20:43:27Z caller=logging.go:85 method=Health result=2 took=25.188µs  (×40)
  20:43:28.997 [front-end] Order response: {"id":"67423e704ca85a00070c6232","customerId":"67423e5c48485600016b4dc7","customer":{"id":null,"firstName":"jsCNkxwYYyef","lastName":"jsCNkxwYYy
  20:43:34.096 [user] ts=2024-11-23T20:43:34.096106916Z caller=middlewares.go:46 method=Register username=bILYhc email=bILYhc@gmail.com took=5.749588ms
  20:43:36.848 [front-end] Received response: "{\"firstName\":\"HGkBwdf\",\"lastName\":\"HGkBwdf\",\"username\":\"HGkBwdf\",\"id\":\"67423e6548485600016b4de2\",\"_links\":{\"addresses\":{
  20:43:38.614 [front-end] npm info using npm@8.19.4  (×2)
  20:43:38.615 [front-end] npm timing config:load:user Completed in 1ms  (×2)
  20:43:38.615 [front-end] npm timing npm:load:setTitle Completed in 0ms  (×2)
  20:43:38.804 [front-end] > microservices-demo-front-end@0.0.1 start  (×2)
  20:43:40.614 [front-end] Using the redis based session manager  (×2)
  20:43:41.302 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e7d4ca85a00070c623a","customerId":"67423e6548485600016b4de5","customer":{"id":null,"firstName":"NYxxCuBu","
  20:43:42.588 [front-end] Posting Customer: {"username":"iFbDWBYwKgB","password":"xYyfS","email":"iFbDWBYwKgB@gmail.com","firstName":"iFbDWBYwKgB","lastName":"iFbDWBYwKgB"}
  20:43:43.625 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e7f4ca85a00070c623f","customerId":"67423e6848485600016b4ded","customer":{"id":null,"firstName":"mwCsrQqSuLK
  20:43:45.076 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e814ca85a00070c6242","customerId":"67423e6b48485600016b4dfd","customer":{"id":null,"firstName":"HnfwP","las
  20:43:46.190 [front-end] Order response: {"id":"67423e824ca85a00070c6244","customerId":"67423e6c48485600016b4e01","customer":{"id":null,"firstName":"oevYNrzlhVs","lastName":"oevYNrzlhVs
  20:43:50.745 [front-end] Received response: "{\"firstName\":\"OeRiOYxQG\",\"lastName\":\"OeRiOYxQG\",\"username\":\"OeRiOYxQG\",\"id\":\"67423e6f48485600016b4e0a\",\"_links\":{\"address
  20:43:52.635 [queue-master] 2024-11-23 20:43:52.635 INFO 7 --- [pool-6-thread-3] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×3)
  20:43:55.586 [front-end] Received response: "{\"firstName\":\"KlUZKgugvMgw\",\"lastName\":\"KlUZKgugvMgw\",\"username\":\"KlUZKgugvMgw\",\"id\":\"67423e7748485600016b4e28\",\"_links\":{
  20:43:56.199 [front-end] npm verb stack at ChildProcess.emit (node:events:513:28)
  20:43:56.202 [front-end] npm verb exit 1
  20:44:00.614 [carts-db] {"t":{"$date":"2024-11-23T20:44:00.614+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173239464
  20:44:05.506 [front-end] Posting Customer: {"username":"LrzknHXn","password":"pkvqFBu","email":"LrzknHXn@gmail.com","firstName":"LrzknHXn","lastName":"LrzknHXn"}
  20:44:09.020 [front-end] Posting Order: {"customer":"http://user/customers/67423e8348485600016b4e4a","address":null,"card":null,"items":"http://carts/carts/67423e8348485600016b4e4a/item  (×3)
  20:44:13.628 [user] ts=2024-11-23T20:44:13.628246773Z caller=middlewares.go:46 method=Register username=IHVhJbg email=IHVhJbg@gmail.com took=4.491254ms
  20:44:18.402 [front-end] Posting Customer: {"username":"ZHkxe","password":"yRiRZs","email":"ZHkxe@gmail.com","firstName":"ZHkxe","lastName":"ZHkxe"}
  20:44:22.070 [front-end] Received response: "{\"firstName\":\"jwdqjMXXKLuVVy\",\"lastName\":\"jwdqjMXXKLuVVy\",\"username\":\"jwdqjMXXKLuVVy\",\"id\":\"67423e9148485600016b4e62\",\"_lin

## p0010
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T02:59:20.502Z
```
{"service":"dbservice1","message":"2021-08-13 02:59:20,502 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 15d5f2dadefadb7c | query = select passwards from username_table where user_name='mIgaboME'"}
```
Same service, the 2 minutes before (oldest first):
  02:59:13.520 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×7)
  02:59:13.520 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×7)
  02:59:13.590 [dbservice1] INFO query = select passwards from username_table where user_name='maWzwvqu'  (×3)
  02:59:13.666 [dbservice1] INFO 62145e5c-fb9f-11eb-86fc-0242ac110003-maWzwvqu-3>t0ju}R&m^p token generate success token=MTYyODc5NDc1My42NjU3NDQ1OjYyMTQ1ZTVjLWZiOWYtMTFlYi04NmZjLTAyNDJhYzE
  02:59:15.442 [dbservice1] INFO 631d2f5e-fb9f-11eb-92bc-0242ac110004-FyPTBMJg-Zjy9.L?*GlNe token generate success token=MTYyODc5NDc1NS40NDIyMTI4OjYzMWQyZjVlLWZiOWYtMTFlYi05MmJjLTAyNDJhYzE
  02:59:17.126 [dbservice1] INFO 642bb546-fb9f-11eb-ba23-0242ac110003-TmVsgowE-I_9$o_yjBE3% token generate success token=MTYyODc5NDc1Ny4xMjYyOTU6NjQyYmI1NDYtZmI5Zi0xMWViLWJhMjMtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  02:58:50.990 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×41)
  02:58:51.152 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×40)
  02:58:51.327 [mobservice1] INFO info 55075854-fb9f-11eb-9121-0242ac110003:CSoBqsmk write success
  02:58:51.438 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '55075854-fb9f-11eb-9121-0242ac110003', 'user_id': 'CSoBqsmk'}  (×81)
  02:58:51.561 [redisservice1] INFO service accept, status_code: 200  (×40)
  02:58:53.919 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×41)
  02:58:54.106 [mobservice2] INFO info 56abe36e-fb9f-11eb-bd53-0242ac110004:SNyDIdeO write success
  02:58:57.055 [redisservice2] INFO redis读取信息成功, status_code: 200  (×43)
  02:58:58.938 [dbservice2] INFO 59580f20-fb9f-11eb-8313-0242ac110003-PtpxFCHR-o#ehxpV6iN_T token generate success token=MTYyODc5NDczOC45Mzc1ODA4OjU5NTgwZjIwLWZiOWYtMTFlYi04MzEzLTAyNDJhYzE
  02:59:00.131 [dbservice1] INFO 5a09be3c-fb9f-11eb-a3e7-0242ac110004-NvzARtmh-E(qKg}c6DI&4 token generate success token=MTYyODc5NDc0MC4xMzExMzc2OjVhMDliZTNjLWZiOWYtMTFlYi1hM2U3LTAyNDJhYzE
  02:59:02.185 [dbservice2] INFO 5b4ab44a-fb9f-11eb-b2a2-0242ac110003-kdncspNK-/mUDr*ZR)9Ls token generate success token=MTYyODc5NDc0Mi4xODQ2NzE6NWI0YWI0NGEtZmI5Zi0xMWViLWIyYTItMDI0MmFjMTE  (×2)
  02:59:04.306 [dbservice1] INFO 5c72c9ac-fb9f-11eb-acd2-0242ac110003-oJIvjPYZ-D^aCEpjQ4J*l token generate success token=MTYyODc5NDc0NC4zMDYxMzI6NWM3MmM5YWMtZmI5Zi0xMWViLWFjZDItMDI0MmFjMTE
  02:59:06.534 [mobservice1] INFO info 5e16a634-fb9f-11eb-b242-0242ac110004:bNtPLwUk write success  (×2)
  02:59:08.946 [dbservice1] INFO 5f4120d4-fb9f-11eb-93d5-0242ac110003-YqjgnfMZ-{EM?P_3q2!OW token generate success token=MTYyODc5NDc0OC45NDU2NDMyOjVmNDEyMGQ0LWZiOWYtMTFlYi05M2Q1LTAyNDJhYzE  (×2)
  02:59:11.472 [mobservice2] INFO info 60fd31f6-fb9f-11eb-b8ff-0242ac110004:PVFHnXol write success
  02:59:14.418 [mobservice2] INFO info 62bd73fc-fb9f-11eb-b0af-0242ac110004:rBRUpNGT write success
  02:59:17.126 [dbservice1] INFO 642bb546-fb9f-11eb-ba23-0242ac110003-TmVsgowE-I_9$o_yjBE3% token generate success token=MTYyODc5NDc1Ny4xMjYyOTU6NjQyYmI1NDYtZmI5Zi0xMWViLWJhMjMtMDI0MmFjMTE
  02:59:19.231 [mobservice2] INFO info 65af4676-fb9f-11eb-9ce3-0242ac110003:yKfSAmta write success
  02:59:21.486 [dbservice2] INFO 66bc70ac-fb9f-11eb-87e5-0242ac110004-jHRvwBZi-&*URqDJ1T%i) token generate success token=MTYyODc5NDc2MS40ODYxOTY6NjZiYzcwYWMtZmI5Zi0xMWViLTg3ZTUtMDI0MmFjMTE
  02:59:23.668 [mobservice2] INFO info 684afb50-fb9f-11eb-b051-0242ac110003:cgKfeRjJ write success
  02:59:26.268 [mobservice1] INFO info 69d37e70-fb9f-11eb-b5fe-0242ac110003:yktWxlrq write success
  02:59:28.945 [mobservice1] INFO info 6b686750-fb9f-11eb-8b8b-0242ac110004:lmvshOqT write success
  02:59:31.072 [dbservice1] INFO 6c7ffeaa-fb9f-11eb-81cb-0242ac110004-oYbSglqf-udHk_>z3F5*y token generate success token=MTYyODc5NDc3MS4wNzE4MjE1OjZjN2ZmZWFhLWZiOWYtMTFlYi04MWNiLTAyNDJhYzE
  02:59:33.429 [mobservice2] INFO info 6e14393e-fb9f-11eb-8e8b-0242ac110003:NPtZUmhc write success
  02:59:35.373 [dbservice1] INFO 6f15dbda-fb9f-11eb-b4d9-0242ac110004-CWflULak-k45a%Ng8.W1z token generate success token=MTYyODc5NDc3NS4zNzMzNjY2OjZmMTVkYmRhLWZiOWYtMTFlYi1iNGQ5LTAyNDJhYzE
  02:59:38.077 [dbservice1] INFO 708dd288-fb9f-11eb-bfe6-0242ac110004-iOlErWzF-X$zLG%<H6fR9 token generate success token=MTYyODc5NDc3OC4wNzcxODM3OjcwOGRkMjg4LWZiOWYtMTFlYi1iZmU2LTAyNDJhYzE
  02:59:40.589 [dbservice1] INFO 7222f3e4-fb9f-11eb-b4cc-0242ac110003-EGieKLYv-(sU}efdiGT?1 token generate success token=MTYyODc5NDc4MC41ODkxNzo3MjIyZjNlNC1mYjlmLTExZWItYjRjYy0wMjQyYWMxMTA
  02:59:43.427 [mobservice1] INFO info 740df7e4-fb9f-11eb-ac7c-0242ac110003:lTYxuZoK write success
  02:59:46.352 [dbservice1] INFO 759c2afe-fb9f-11eb-9334-0242ac110004-cwbxRDST-+!NhXiR:qd?D token generate success token=MTYyODc5NDc4Ni4zNTE5NjMzOjc1OWMyYWZlLWZiOWYtMTFlYi05MzM0LTAyNDJhYzE
  02:59:49.549 [dbservice1] INFO 77721168-fb9f-11eb-81d0-0242ac110003-RVeouDMj-(Nah*B8-w4n1 token generate success token=MTYyODc5NDc4OS41NDkxOTM0Ojc3NzIxMTY4LWZiOWYtMTFlYi04MWQwLTAyNDJhYzE

## p0630
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T20:18:43.948Z
```
{"timestamp":1733602723948994300,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-nsc8q","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:18:43.948  INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl             : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainNumber='Z1234', startStation='shanghai', destStation='nanjing', seatType=2}"}
```
Same service, the 2 minutes before (oldest first):
  20:18:38.225 [ts-seat-service] 2024-12-07 20:18:38.225 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×3)
  20:18:38.263 [ts-seat-service] 2024-12-07 20:18:38.262 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×3)
  20:18:38.273 [ts-seat-service] 2024-12-07 20:18:38.273 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×3)
  20:18:38.288 [ts-seat-service] 2024-12-07 20:18:38.287 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×3)
  20:18:38.288 [ts-seat-service] 2024-12-07 20:18:38.287 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  20:18:38.297 [ts-seat-service] 2024-12-07 20:18:38.297 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  20:18:39.454 [ts-seat-service] 2024-12-07 20:18:39.454 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×2)
  20:18:39.492 [ts-seat-service] 2024-12-07 20:18:39.492 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
All services, 30 seconds either side (sampled):
  20:18:14.285 [ts-admin-basic-info-service] 2024-12-07 20:18:14.285 INFO 1 --- [io-18767-exec-3] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×12)
  20:18:15.083 [ts-basic-service] 2024-12-07 20:18:15.083 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×84)
  20:18:15.164 [ts-basic-service] 2024-12-07 20:18:15.164 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×21)
  20:18:15.187 [ts-order-other-service] 2024-12-07 20:18:15.187 INFO 1 --- [io-12032-exec-6] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×12)
  20:18:15.245 [ts-travel2-service] 2024-12-07 20:18:15.244 INFO 1 --- [io-16346-exec-1] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234  (×27)
  20:18:15.295 [ts-travel2-service] 2024-12-07 20:18:15.294 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×24)
  20:18:15.453 [ts-inside-payment-service] 2024-12-07 20:18:15.453 INFO 1 --- [io-18673-exec-1] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.
  20:18:21.318 [ts-basic-service] 2024-12-07 20:18:21.318 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×11)
  20:18:22.674 [ts-travel-service] 2024-12-07 20:18:22.673 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×17)
  20:18:22.755 [ts-order-service] 2024-12-07 20:18:22.755 INFO 1 --- [io-12031-exec-5] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×7)
  20:18:22.880 [ts-order-service] 2024-12-07 20:18:22.879 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is empty  (×2)
  20:18:23.068 [ts-travel-service] 2024-12-07 20:18:23.068 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×18)
  20:18:23.511 [ts-seat-service] 2024-12-07 20:18:23.511 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×2)
  20:18:24.057 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:18:24 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 916 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×3)
  20:18:26.066 [ts-food-service] 2024-12-07 20:18:26.066 INFO 1 --- [io-18856-exec-1] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×3)
  20:18:27.284 [ts-seat-service] 2024-12-07 20:18:27.284 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  20:18:30.921 [ts-auth-mongo] {"t":{"$date":"2024-12-07T20:18:30.921+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360271
  20:18:31.788 [ts-notification-mongo] {"t":{"$date":"2024-12-07T20:18:31.788+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360271
  20:18:38.198 [ts-travel2-service] 2024-12-07 20:18:38.198 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×4)
  20:18:43.221 [ts-payment-mongo] {"t":{"$date":"2024-12-07T20:18:43.221+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360272
  20:18:44.504 [ts-contacts-service] 2024-12-07 20:18:44.504 INFO 1 --- [io-12347-exec-4] contacts.controller.ContactsController : [Contacts Service][Find Contacts By Account Id: 4d2a46c7-71cb-4cf1
  20:18:44.535 [ts-security-service] 2024-12-07 20:18:44.535 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service][Get Order Num Info]
  20:18:44.598 [ts-preserve-other-service] 2024-12-07 20:18:44.597 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security Complete. 
  20:18:44.612 [ts-preserve-other-service] 2024-12-07 20:18:44.612 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] TripId: Z1234
  20:18:45.027 [ts-preserve-other-service] 2024-12-07 20:18:45.027 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Tickets Enough
  20:18:45.089 [ts-basic-service] 2024-12-07 20:18:45.089 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  20:18:45.155 [ts-seat-service] 2024-12-07 20:18:45.155 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService distributeSeat] The request seat type is confortClass and the t
  20:18:45.169 [ts-preserve-other-service] 2024-12-07 20:18:45.168 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order Complete
  20:18:45.225 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:18:45 +0800] "POST /api/v1/preserveotherservice/preserveOther HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7
  20:18:59.349 [ts-order-service] 2024-12-07 20:18:59.349 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160,   (×2)

## p0332
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:21:11.685Z
```
{"timestamp":1732245671685750800,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:21:11.685  INFO [carts,,,] 7 --- [           main] o.s.c.support.DefaultLifecycleProcessor  : Starting beans in phase 0"}
```
Same service, the 2 minutes before (oldest first):
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto 
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public j
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  03:21:03.184 [carts] 2024-11-22 03:21:03.183 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces
  03:21:03.285 [carts] 2024-11-22 03:21:03.285 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/
  03:21:06.490 [carts] 2024-11-22 03:21:06.489 INFO [carts,,,] 7 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  03:21:08.790 [carts] 2024-11-22 03:21:08.790 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetected
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposur  (×2)
  03:21:08.986 [carts] 2024-11-22 03:21:08.986 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  03:21:08.987 [carts] 2024-11-22 03:21:08.987 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  03:21:08.990 [carts] 2024-11-22 03:21:08.990 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX server
  03:21:09.189 [carts] 2024-11-22 03:21:09.188 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server as  (×2)
  03:21:09.293 [carts] 2024-11-22 03:21:09.293 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as MB
  03:21:09.390 [carts] 2024-11-22 03:21:09.390 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering wi
All services, 30 seconds either side (sampled):
  03:20:41.715 [front-end] Attempting to delete cart for user: 673ff880b0df5c00019b1f05  (×55)
  03:20:42.531 [front-end] { id: '673ff88ab0df5c00019b1f20' }  (×58)
  03:20:42.708 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff879b0df5c00019b1ef6\",\"_links\":{\"  (×55)
  03:20:43.387 [carts] 2024-11-22 03:20:43.386 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[DE
  03:20:46.187 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff884b0df5c00019b1f0d"}  (×54)
  03:20:47.759 [user] ts=2024-11-22T03:20:47.758527808Z caller=middlewares.go:104 method=GetAddresses id=673ff884b0df5c00019b1f0e result=1 took=1.207293ms  (×13)
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/**] onto handler of type [class org.s
  03:20:54.187 [user] ts=2024-11-22T03:20:54.187188415Z caller=middlewares.go:46 method=Register username=kJMPYF email=kJMPYF@gmail.com took=953.987µs
  03:20:58.176 [front-end] Received response: "{\"firstName\":\"MpDJxkmv\",\"lastName\":\"MpDJxkmv\",\"username\":\"MpDJxkmv\",\"id\":\"673ff87eb0df5c00019b1f00\",\"_links\":{\"addresses\
  03:20:59.689 [carts] 2024-11-22 03:20:59.689 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[application
  03:20:59.788 [carts] 2024-11-22 03:20:59.788 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicati
  03:21:01.131 [front-end] Posting Customer: {"username":"isaznhmc","password":"PMQNcLZhlo","email":"isaznhmc@gmail.com","firstName":"isaznhmc","lastName":"isaznhmc"}
  03:21:03.084 [carts] 2024-11-22 03:21:03.084 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  03:21:03.184 [carts] 2024-11-22 03:21:03.183 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces
  03:21:06.312 [user] ts=2024-11-22T03:21:06.312657046Z caller=middlewares.go:46 method=Register username=IhtqcyEyd email=IhtqcyEyd@gmail.com took=950.203µs
  03:21:09.266 [front-end] Received response: "{\"firstName\":\"DnjBelnPao\",\"lastName\":\"DnjBelnPao\",\"username\":\"DnjBelnPao\",\"id\":\"673ff890b0df5c00019b1f29\",\"_links\":{\"addr
  03:21:12.426 [front-end] Received response: "{\"firstName\":\"mLiQP\",\"lastName\":\"mLiQP\",\"username\":\"mLiQP\",\"id\":\"673ff89bb0df5c00019b1f4c\",\"_links\":{\"addresses\":{\"href
  03:21:15.278 [user] ts=2024-11-22T03:21:15.27845523Z caller=middlewares.go:46 method=Register username=xlSpYB email=xlSpYB@gmail.com took=1.032808ms
  03:21:17.489 [front-end] Received response: "{\"firstName\":\"kJMPYF\",\"lastName\":\"kJMPYF\",\"username\":\"kJMPYF\",\"id\":\"673ff896b0df5c00019b1f37\",\"_links\":{\"addresses\":{\"h
  03:21:18.612 [queue-master] Received shipment task: 673ff896b0df5c00019b1f3b  (×29)
  03:21:18.809 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8aed94b9000069b438f","customerId":"673ff89db0df5c00019b1f52","customer":{"id":null,"firstName":"isaznhmc","
  03:21:19.500 [queue-master] 2024-11-22 03:21:19.500 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×27)
  03:21:20.204 [front-end] Order response: {"id":"673ff8b0d94b9000069b4395","customerId":"673ff8a0b0df5c00019b1f61","customer":{"id":null,"firstName":"qklQL","lastName":"qklQL","username"
  03:21:21.517 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b1d94b9000069b4399","customerId":"673ff89db0df5c00019b1f53","customer":{"id":null,"firstName":"EFvIPXnJWRP
  03:21:25.703 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b5d94b9000069b439c","customerId":"673ff8a0b0df5c00019b1f5e","customer":{"id":null,"firstName":"qYmtssHEvF"
  03:21:28.773 [front-end] Posting Customer: {"username":"xyFLJGPDL","password":"UczPYeLIR","email":"xyFLJGPDL@gmail.com","firstName":"xyFLJGPDL","lastName":"xyFLJGPDL"}
  03:21:34.214 [front-end] Received response: "{\"firstName\":\"yXmVwShR\",\"lastName\":\"yXmVwShR\",\"username\":\"yXmVwShR\",\"id\":\"673ff8a8b0df5c00019b1f85\",\"_links\":{\"addresses\
  03:21:35.705 [user] ts=2024-11-22T03:21:35.705489689Z caller=middlewares.go:46 method=Register username=mtTZvDvJ email=mtTZvDvJ@gmail.com took=999.918µs
  03:21:38.430 [front-end] Posting Customer: {"username":"jjXedtx","password":"XLowgQe","email":"jjXedtx@gmail.com","firstName":"jjXedtx","lastName":"jjXedtx"}
  03:21:41.276 [front-end] Posting Customer: {"username":"VaXJYznhb","password":"GxhYZM","email":"VaXJYznhb@gmail.com","firstName":"VaXJYznhb","lastName":"VaXJYznhb"}

## p0816
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-other-service, 2024-12-10T13:15:13.591Z
```
{"timestamp":1733836513591715300,"container_name":"ts-order-other-service","pod_name":"ts-order-other-service-746fccc88f-fp4xn","node_name":"ip-192-168-29-227.ap-southeast-2.compute.internal","message":"2024-12-10 13:15:13.590 ERROR 1 --- [io-12032-exec-7] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalArgumentException: Invalid UUID string: ] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  13:14:04.022 [ts-order-other-service] 2024-12-10 13:14:04.022 INFO 1 --- [io-12032-exec-8] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-
  13:14:04.027 [ts-order-other-service] 2024-12-10 13:14:04.027 INFO 1 --- [io-12032-exec-8] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou
  13:14:04.027 [ts-order-other-service] 2024-12-10 13:14:04.027 INFO 1 --- [io-12032-exec-8] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 3
  13:14:04.054 [ts-order-other-service] 2024-12-10 13:14:04.053 INFO 1 --- [io-12032-exec-8] other.service.OrderOtherServiceImpl : Stations name list is : Response(status=1, msg=Success, data=[Shang H
  13:14:04.082 [ts-order-other-service] 2024-12-10 13:14:04.082 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Get Order By Id] Order Id: cb941cb1-0754-4229
  13:15:13.578 [ts-order-other-service] 2024-12-10 13:15:13.578 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 
All services, 30 seconds either side (sampled):
  13:14:43.731 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:43 +0800] "POST /api/v1/users/login HTTP/1.1" 503 19 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel M  (×17)
  13:14:43.893 [ts-travel-service] 2024-12-10 13:14:43.893 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×4)
  13:14:44.918 [ts-food-service] 2024-12-10 13:14:44.917 INFO 1 --- [io-18856-exec-7] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×5)
  13:14:44.955 [ts-travel-service] 2024-12-10 13:14:44.954 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×5)
  13:14:51.931 [ts-admin-basic-info-service] 2024-12-10 13:14:51.931 INFO 1 --- [io-18767-exec-5] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×10)
  13:14:56.602 [ts-auth-service] 2024-12-10 13:14:56.601 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'objectPostProcessor' of type [org.springframework.security.config.an  (×2)
  13:14:56.822 [ts-travel2-service] 2024-12-10 13:14:56.822 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×12)
  13:14:58.773 [ts-auth-service] 2024-12-10 13:14:58.773 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default
  13:15:00.732 [ts-admin-basic-info-service] 2024-12-10 13:15:00.732 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  13:15:02.618 [ts-auth-service] 2024-12-10 13:15:02.617 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 20113 ms  (×2)
  13:15:06.513 [ts-auth-service] 2024-12-10 13:15:06.512 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-auth-mongo:27017 to client view of cluster  (×2)
  13:15:07.206 [ts-auth-mongo] {"t":{"$date":"2024-12-10T13:15:07.205+00:00"},"s":"I", "c":"NETWORK", "id":51800, "ctx":"conn19","msg":"client metadata","attr":{"remote":"127.0.0.6:50713","cl  (×3)
  13:15:11.832 [ts-config-mongo] {"t":{"$date":"2024-12-10T13:15:11.831+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:12.340 [ts-order-other-mongo] {"t":{"$date":"2024-12-10T13:15:12.340+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:13.119 [ts-route-mongo] {"t":{"$date":"2024-12-10T13:15:13.119+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:13.578 [ts-order-other-service] 2024-12-10 13:15:13.578 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 
  13:15:14.931 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-10T13:15:14.931+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:15.848 [ts-travel-service] 2024-12-10 13:15:15.848 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
  13:15:16.115 [ts-auth-service] 2024-12-10 13:15:16.114 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  13:15:16.501 [ts-auth-service] 2024-12-10 13:15:16.501 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springframework.web.s
  13:15:18.503 [ts-auth-service] 2024-12-10 13:15:18.503 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  13:15:18.507 [ts-auth-service] 2024-12-10 13:15:18.507 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  13:15:18.509 [ts-auth-service] 2024-12-10 13:15:18.509 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[application/vnd.sprin
  13:15:24.000 [ts-auth-service] 2024-12-10 13:15:23.919 INFO 1 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  13:15:25.700 [ts-auth-service] 2024-12-10 13:15:25.700 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.612 seconds (JVM running for 70.582)
  13:15:31.612 [ts-auth-service] 2024-12-10 13:15:31.611 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×4)
  13:15:32.911 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:15:32 +0800] "POST /api/v1/users/login HTTP/1.1" 200 146 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×6)
  13:15:32.934 [ts-travel2-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×4)
  13:15:34.962 [ts-admin-basic-info-service] 2024-12-10 13:15:34.961 ERROR 1 --- [io-18767-exec-9] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×3)

## p0419
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T04:05:42.741Z
```
{"timestamp":1732248342741877000,"container_name":"front-end","pod_name":"front-end-ccbbfbf7f-szg8d","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"firstName\\\":\\\"gKrEwqywFB\\\",\\\"lastName\\\":\\\"gKrEwqywFB\\\",\\\"username\\\":\\\"gKrEwqywFB\\\",\\\"id\\\":\\\"674002ffb0df5c00019b3f0a\\\",\\\"_links\\\":{\\\"addresses\\\":{\\\"href\\\":\\\"http://user/customers/674002ffb0df5c00019b3f0a/addresses\\\"},\\\"cards\\\":{\\\"href\\\":\\\"http://user/customers/674002ffb0df5c00019b3f0a/cards\\\"},\\\"customer\\\":{\\\"href\\\":\\\"http://user/customers/674002ffb0df5c00019b3f0a\\\"},\\\"self\\…"}
```
Same service, the 2 minutes before (oldest first):
  04:05:42.272 [front-end] Received response: "{\"firstName\":\"xQBpj\",\"lastName\":\"xQBpj\",\"username\":\"xQBpj\",\"id\":\"67400306b0df5c00019b3f29\",\"_links\":{\"addresses\":{\"href
  04:05:42.272 [front-end] GET Request to: http://user/customers/67400306b0df5c00019b3f29/addresses  (×2)
  04:05:42.279 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6740030eb0df5c00019b3f45\",\"_links\":{\"
  04:05:42.279 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67400
  04:05:42.279 [front-end] [ undefined, undefined ]
  04:05:42.279 [front-end] Posting Order: {"customer":"http://user/customers/67400306b0df5c00019b3f29","address":"http://user/addresses/6740030eb0df5c00019b3f44","card":"http://user/cards
  04:05:42.303 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732248342302,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde
  04:05:42.303 [front-end] Order response: {"timestamp":1732248342302,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli
  04:05:42.304 [front-end] POST /orders 406 - ms - -
  04:05:42.637 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6740030db0df5c00019b3f42"}
  04:05:42.644 [front-end] POST /addresses 200 - ms - -
  04:05:42.650 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"6740030db0df5c00019b3f42"}
  04:05:42.657 [front-end] POST /cards 200 - ms - -
  04:05:42.664 [front-end] GET /catalogue 200 - ms - -
  04:05:42.708 [front-end] Attempting to delete cart for user: 6740030db0df5c00019b3f42
  04:05:42.727 [front-end] User cart deleted with status: 202
  04:05:42.728 [front-end] DELETE /cart 202 - ms - -
  04:05:42.732 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  04:05:42.734 [front-end] Request received with body: {}
All services, 30 seconds either side (sampled):
  04:05:12.775 [catalogue] ts=2024-11-22T04:05:12Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.044767ms  (×66)
  04:05:12.870 [user] ts=2024-11-22T04:05:12.870694963Z caller=middlewares.go:134 method=GetCards id=674002eeb0df5c00019b3eda result=1 took=1.149622ms  (×11)
  04:05:12.895 [front-end] POST /orders 201 - ms - -  (×61)
  04:05:13.168 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×7)
  04:05:13.598 [catalogue] ts=2024-11-22T04:05:13Z caller=logging.go:62 method=Get id=837ab141-399e-4c1f-9abc-bace40296bac sock=837ab141-399e-4c1f-9abc-bace40296bac err=null took=4.54999m  (×9)
  04:05:14.174 [front-end] Posting Customer: {"username":"NBPEYmcJUDQpMo","password":"frNSCebA","email":"NBPEYmcJUDQpMo@gmail.com","firstName":"NBPEYmcJUDQpMo","lastName":"NBPEYmcJUDQpMo"
  04:05:15.399 [front-end] Posting Customer: {"username":"udwNnIveQcQOI","password":"rRZvMjdx","email":"udwNnIveQcQOI@gmail.com","firstName":"udwNnIveQcQOI","lastName":"udwNnIveQcQOI"}
  04:05:17.413 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×6)
  04:05:19.489 [front-end] Posting Customer: {"username":"gKrEwqywFB","password":"JzfsyBdd","email":"gKrEwqywFB@gmail.com","firstName":"gKrEwqywFB","lastName":"gKrEwqywFB"}
  04:05:20.325 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×7)
  04:05:22.323 [front-end] Received response: "{\"firstName\":\"QHyPcDaeBFkHA\",\"lastName\":\"QHyPcDaeBFkHA\",\"username\":\"QHyPcDaeBFkHA\",\"id\":\"674002efb0df5c00019b3edd\",\"_links\
  04:05:26.018 [front-end] Posting Customer: {"username":"xQBpj","password":"iRaKsCNbp","email":"xQBpj@gmail.com","firstName":"xQBpj","lastName":"xQBpj"}
  04:05:29.923 [front-end] Received response: "{\"firstName\":\"gLHmRzjJiSslEt\",\"lastName\":\"gLHmRzjJiSslEt\",\"username\":\"gLHmRzjJiSslEt\",\"id\":\"674002f6b0df5c00019b3ef1\",\"_lin
  04:05:31.562 [front-end] Order response: {"id":"6740030bd94b9000069b4bcd","customerId":"674002f6b0df5c00019b3ef0","customer":{"id":null,"firstName":"WgBReySxLOim","lastName":"WgBReySxLO
  04:05:32.930 [front-end] Received response: "{\"firstName\":\"GXAlLUklXkp\",\"lastName\":\"GXAlLUklXkp\",\"username\":\"GXAlLUklXkp\",\"id\":\"674002feb0df5c00019b3f09\",\"_links\":{\"a
  04:05:36.697 [front-end] Order response: {"statusCode":201,"body":{"id":"67400310d94b9000069b4bd2","customerId":"674002feb0df5c00019b3f08","customer":{"id":null,"firstName":"XrdykZSmCYN
  04:05:40.436 [front-end] Received response: "{\"firstName\":\"NBPEYmcJUDQpMo\",\"lastName\":\"NBPEYmcJUDQpMo\",\"username\":\"NBPEYmcJUDQpMo\",\"id\":\"674002fab0df5c00019b3efb\",\"_lin
  04:05:42.178 [user] ts=2024-11-22T04:05:42.177905957Z caller=middlewares.go:46 method=Register username=dSVtoGBo email=dSVtoGBo@gmail.com took=961.003µs
  04:05:45.212 [front-end] Received response: "{\"firstName\":\"BOTSy\",\"lastName\":\"BOTSy\",\"username\":\"BOTSy\",\"id\":\"67400301b0df5c00019b3f17\",\"_links\":{\"addresses\":{\"href
  04:05:46.328 [front-end] Received response: "{\"firstName\":\"JsBmCmQInxgHMm\",\"lastName\":\"JsBmCmQInxgHMm\",\"username\":\"JsBmCmQInxgHMm\",\"id\":\"67400302b0df5c00019b3f18\",\"_lin
  04:05:47.706 [front-end] Order response: {"statusCode":201,"body":{"id":"6740031bd94b9000069b4bdd","customerId":"67400302b0df5c00019b3f19","customer":{"id":null,"firstName":"dnGvozKvzTH
  04:05:48.793 [front-end] Order response: {"id":"6740031cd94b9000069b4be0","customerId":"67400304b0df5c00019b3f20","customer":{"id":null,"firstName":"GrITboHjJIr","lastName":"GrITboHjJIr
  04:05:50.997 [front-end] Posting Customer: {"username":"aBfDST","password":"lEkaJzZ","email":"aBfDST@gmail.com","firstName":"aBfDST","lastName":"aBfDST"}
  04:05:53.687 [front-end] Order response: {"statusCode":201,"body":{"id":"67400321d94b9000069b4be7","customerId":"6740030eb0df5c00019b3f46","customer":{"id":null,"firstName":"jYRlic","la
  04:05:56.132 [user] ts=2024-11-22T04:05:56.132148626Z caller=middlewares.go:46 method=Register username=lqnHa email=lqnHa@gmail.com took=1.038118ms
  04:06:00.428 [front-end] Received response: "{\"firstName\":\"dSVtoGBo\",\"lastName\":\"dSVtoGBo\",\"username\":\"dSVtoGBo\",\"id\":\"67400316b0df5c00019b3f5f\",\"_links\":{\"addresses\
  04:06:02.126 [user] ts=2024-11-22T04:06:02.126204994Z caller=middlewares.go:46 method=Register username=xcZygmJv email=xcZygmJv@gmail.com took=943.74µs
  04:06:07.550 [front-end] Posting Customer: {"username":"IjrkvKDbzJHxGM","password":"BkQxfTYRH","email":"IjrkvKDbzJHxGM@gmail.com","firstName":"IjrkvKDbzJHxGM","lastName":"IjrkvKDbzJHxGM
  04:06:09.880 [front-end] Posting Customer: {"username":"ThhqB","password":"OjjseE","email":"ThhqB@gmail.com","firstName":"ThhqB","lastName":"ThhqB"}
  04:06:12.645 [front-end] Received response: "{\"firstName\":\"UaKEd\",\"lastName\":\"UaKEd\",\"username\":\"UaKEd\",\"id\":\"67400322b0df5c00019b3f7d\",\"_links\":{\"addresses\":{\"href

## p0032
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-13T07:52:55.113Z
```
{"service":"webservice2","message":"2021-08-13 07:52:55,113 | ERROR | 0.0.0.3 | 172.17.0.4 | webservice2 | 8755aed72bdeaf0c | an error occurred in the downstream service"}
```
Same service, the 2 minutes before (oldest first):
  07:52:50.456 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×3)
  07:52:50.456 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '66f81e80-fbc8-11eb-a90a-0242ac110004', 'value': '', 'ex': 10}  (×3)
  07:52:50.554 [webservice2] INFO uuid: 66f81e80-fbc8-11eb-a90a-0242ac110004 write redis successfully  (×3)
  07:52:50.660 [webservice2] INFO complete information: {'uuid': '66f81e80-fbc8-11eb-a90a-0242ac110004', 'user_id': 'lGPfCvhn'}  (×3)
  07:52:50.670 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×3)
  07:52:50.671 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
  07:52:52.882 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
All services, 30 seconds either side (sampled):
  07:52:25.114 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×33)
  07:52:25.171 [logservice2] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×33)
  07:52:25.383 [dbservice1] INFO 57931224-fbc8-11eb-9837-0242ac110004-bHxAGyOk-FAxou7R(_OT- token generate success token=MTYyODgxMjM0NS4zODM1NTc2OjU3OTMxMjI0LWZiYzgtMTFlYi05ODM3LTAyNDJhYzE
  07:52:25.733 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×39)
  07:52:25.944 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×32)
  07:52:26.342 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  07:52:26.753 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×51)
  07:52:27.534 [mobservice2] INFO info 591dc71a-fbc8-11eb-8aca-0242ac110004:zFRIyZKg write success
  07:52:29.118 [mobservice1] INFO info 5a0c65aa-fbc8-11eb-bafa-0242ac110004:lVPouHjM write success
  07:52:31.800 [mobservice1] INFO info 5ba239e4-fbc8-11eb-a540-0242ac110003:HRlmyonZ write success
  07:52:34.281 [mobservice2] INFO info 5d22ae5c-fbc8-11eb-b377-0242ac110003:rcwlDFam write success
  07:52:36.914 [dbservice1] INFO 5e7520aa-fbc8-11eb-b156-0242ac110004-SsCTdeWm-_B0WQK16v:#? token generate success token=MTYyODgxMjM1Ni45MTM4MzUzOjVlNzUyMGFhLWZiYzgtMTFlYi1iMTU2LTAyNDJhYzE
  07:52:39.450 [webservice2] ERROR an error occurred in the downstream service  (×2)
  07:52:47.967 [mobservice2] INFO info 65322212-fbc8-11eb-90cf-0242ac110004:GBzXyJft write success
  07:52:50.457 [dbservice2] INFO 6695ef30-fbc8-11eb-aad3-0242ac110004-ICpXWslJ-tkrd@G6KNM5v token generate success token=MTYyODgxMjM3MC40NTcxMzYyOjY2OTVlZjMwLWZiYzgtMTFlYi1hYWQzLTAyNDJhYzE
  07:52:53.223 [mobservice2] INFO info 686a7966-fbc8-11eb-890f-0242ac110004:oneLisuW write success
  07:52:55.508 [mobservice1] INFO info 69c6b414-fbc8-11eb-8537-0242ac110004:FgWeZKzi write success
  07:52:58.039 [mobservice1] INFO info 6b47dd22-fbc8-11eb-b468-0242ac110003:PvCnuEHJ write success
  07:53:00.581 [mobservice1] INFO info 6ccba5fc-fbc8-11eb-ab40-0242ac110004:QPshVMni write success
  07:53:03.211 [mobservice2] INFO info 6e5f1548-fbc8-11eb-9db9-0242ac110004:kPDTFpxO write success
  07:53:06.087 [mobservice2] INFO info 701794d2-fbc8-11eb-bea0-0242ac110003:fivLrDpw write success
  07:53:08.770 [mobservice2] INFO info 71b25b4c-fbc8-11eb-bb3e-0242ac110003:vUGVxSct write success
  07:53:11.887 [dbservice1] INFO 7350ced4-fbc8-11eb-88ae-0242ac110004-AnasJGMP-Q?)$%dAI{qjZ token generate success token=MTYyODgxMjM5MS44ODcxMjc6NzM1MGNlZDQtZmJjOC0xMWViLTg4YWUtMDI0MmFjMTE
  07:53:14.722 [mobservice1] INFO info 753d6176-fbc8-11eb-ae47-0242ac110003:NXYiMcPr write success
  07:53:17.268 [dbservice2] INFO 7690432c-fbc8-11eb-831d-0242ac110004-OBgRIvmU-{eaD^f2GlVBk token generate success token=MTYyODgxMjM5Ny4yNjgyMTY0Ojc2OTA0MzJjLWZiYzgtMTFlYi04MzFkLTAyNDJhYzE
  07:53:19.778 [mobservice2] INFO info 784209b2-fbc8-11eb-a161-0242ac110004:wKjLqdJi write success
  07:53:22.650 [mobservice2] INFO info 79e9be72-fbc8-11eb-87c6-0242ac110004:ICtSnKPU write success

## p0669
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-11T12:08:18.141Z
```
{"service":"webservice2","message":"2021-08-11 12:08:18,141 | ERROR | 0.0.0.3 | webservice2 | web_helper.py -> web_service_resource -> 100 | 501671306868611d | get a error [Errno 2] No such file or directory: 'resources/source_file/source_file.csv'"}
```
Same service, the 2 minutes before (oldest first):
  12:08:15.697 [webservice2] ERROR get a error [Errno 2] No such file or directory: 'resources/source_file/source_file.csv'  (×4)
  12:08:16.499 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  12:08:16.500 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  12:08:16.500 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'c12d503e-fa59-11eb-a94f-0242ac110004', 'value': '', 'ex': 10}  (×4)
  12:08:16.556 [webservice2] INFO uuid: c12d503e-fa59-11eb-a94f-0242ac110004 write redis successfully  (×4)
All services, 30 seconds either side (sampled):
  12:07:48.193 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×27)
  12:07:48.243 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': 'b00841a6-fa59-11eb-9971-0242ac110003', 'user_id': 'glaSXZGO'}  (×58)
  12:07:48.366 [dbservice1] INFO query = select passwards from username_table where user_name='glaSXZGO'  (×32)
  12:07:48.577 [redisservice1] INFO redis write success  (×94)
  12:07:53.543 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'b37e4fce-fa59-11eb-a6ff-0242ac110003', 'value': '', 'ex': 10}  (×58)
  12:07:53.794 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×32)
  12:07:54.095 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×23)
  12:07:58.030 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×25)
  12:07:58.265 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'b609640e-fa59-11eb-b771-0242ac110003'}  (×31)
  12:07:59.595 [mobservice1] INFO info b6e441dc-fa59-11eb-9ee1-0242ac110003:XKUdarkx write success
  12:08:01.344 [mobservice1] INFO info b7eb7d84-fa59-11eb-8850-0242ac110003:FTkscPog write success
  12:08:05.196 [dbservice1] INFO b9ee2ac8-fa59-11eb-8b6b-0242ac110003-EGieKLYv-(sU}efdiGT?1 token generate success token=MTYyODY1NDg4NS4xOTY2MTk1OmI5ZWUyYWM4LWZhNTktMTFlYi04YjZiLTAyNDJhYzE
  12:08:06.906 [dbservice1] INFO bb07714e-fa59-11eb-aec0-0242ac110003-DhKfSuMF-Vc<a5J!Q>m{2 token generate success token=MTYyODY1NDg4Ni45MDY1ODQ6YmIwNzcxNGUtZmE1OS0xMWViLWFlYzAtMDI0MmFjMTE  (×2)
  12:08:10.074 [dbservice2] INFO bce8fd84-fa59-11eb-a891-0242ac110003-fegJlQaO-}1UbPAK(3:>J token generate success token=MTYyODY1NDg5MC4wNzM2MzI1OmJjZThmZDg0LWZhNTktMTFlYi1hODkxLTAyNDJhYzE
  12:08:12.861 [dbservice1] INFO be8a6524-fa59-11eb-ad38-0242ac110003-XWkAGNLi-ZF0Q*-Nk7xJ< token generate success token=MTYyODY1NDg5Mi44NjEyNDM1OmJlOGE2NTI0LWZhNTktMTFlYi1hZDM4LTAyNDJhYzE
  12:08:15.036 [mobservice1] INFO info c0178778-fa59-11eb-bcea-0242ac110003:gKPfDFAT write success
  12:08:17.075 [dbservice1] INFO c119b4b6-fa59-11eb-818f-0242ac110003-SYUdXTMn-#?+cKu8b!U&_ token generate success token=MTYyODY1NDg5Ny4wNzQ3NjE5OmMxMTliNGI2LWZhNTktMTFlYi04MThmLTAyNDJhYzE
  12:08:22.304 [mobservice2] INFO info c4698448-fa59-11eb-b92e-0242ac110003:vEGoarin write success
  12:08:25.433 [dbservice2] INFO c606c838-fa59-11eb-a984-0242ac110003-wzuckBhX-M8t1WKXj9vHT token generate success token=MTYyODY1NDkwNS40MzI3MTE4OmM2MDZjODM4LWZhNTktMTFlYi1hOTg0LTAyNDJhYzE  (×2)
  12:08:27.663 [dbservice2] INFO c7646e24-fa59-11eb-bd14-0242ac110003-JTPZbGUX-owRC0.<$@!D) token generate success token=MTYyODY1NDkwNy42NjI3MjY5OmM3NjQ2ZTI0LWZhNTktMTFlYi1iZDE0LTAyNDJhYzE
  12:08:29.897 [dbservice1] INFO c88494a0-fa59-11eb-82b2-0242ac110003-eJFaBQoW-bScmY_uD{wZ* token generate success token=MTYyODY1NDkwOS44OTczMjI0OmM4ODQ5NGEwLWZhNTktMTFlYi04MmIyLTAyNDJhYzE
  12:08:32.994 [mobservice2] INFO info cac546c4-fa59-11eb-baee-0242ac110003:efoEbcGO write success
  12:08:36.139 [mobservice2] INFO info cca6d886-fa59-11eb-babe-0242ac110003:DLQYKJTg write success
  12:08:38.894 [mobservice2] INFO info ce4c0de6-fa59-11eb-94e3-0242ac110003:yWbZXEez write success
  12:08:40.984 [dbservice1] INFO cf219542-fa59-11eb-baaf-0242ac110003-IKAZGYCc-njNx6uZ3V<P_ token generate success token=MTYyODY1NDkyMC45ODM2NDI2OmNmMjE5NTQyLWZhNTktMTFlYi1iYWFmLTAyNDJhYzE
  12:08:43.771 [dbservice1] INFO d1035b34-fa59-11eb-93d8-0242ac110003-roAFtIPD-=sjpw>m*#Pav token generate success token=MTYyODY1NDkyMy43NzA1NDUyOmQxMDM1YjM0LWZhNTktMTFlYi05M2Q4LTAyNDJhYzE
  12:08:46.248 [dbservice2] INFO d273dd0e-fa59-11eb-b4e8-0242ac110003-MSLIBsQD-SeMQlNBV}$h# token generate success token=MTYyODY1NDkyNi4yNDgxMTpkMjczZGQwZS1mYTU5LTExZWItYjRlOC0wMjQyYWMxMTA

## p0731
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-14T21:12:28.775Z
```
{"service":"dbservice2","message":"2021-08-14 21:12:28,775 | ERROR | 0.0.0.2 | dbservice2 | db_helper.py -> sql_ano_prob -> 93 | 7284134934504916 | (pymysql.err.OperationalError) (1054, \"Unknown column 'system_data_time' in 'field list'\")[SQL: select service_name, system_data_time, system_cpu_utilization, system_memory_usage,system_disk_usage, disk_io_read_count, disk_io_write_count,system_network, network_io_read_count, network_io…"}
```
Same service, the 2 minutes before (oldest first):
  21:12:23.835 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×6)
  21:12:23.835 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×6)
  21:12:23.938 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  21:12:24.907 [dbservice2] INFO query = select passwards from username_table where user_name='sidCWlhf'  (×3)
  21:12:24.984 [dbservice2] INFO 43fe0978-fd01-11eb-ae75-0242ac110004-sidCWlhf-orzl%H40:d-Q token generate success token=MTYyODk0Njc0NC45ODQyOTI6NDNmZTA5NzgtZmQwMS0xMWViLWFlNzUtMDI0MmFjMTE
  21:12:25.579 [dbservice2] INFO 445d4be0-fd01-11eb-9585-0242ac110004-ockFwOnC-_0K6_54f^L?M token generate success token=MTYyODk0Njc0NS41NzkwMDY0OjQ0NWQ0YmUwLWZkMDEtMTFlYi05NTg1LTAyNDJhYzE
  21:12:26.339 [dbservice2] INFO 44d6266e-fd01-11eb-b0fa-0242ac110004-ALRXkDds-%t(^UlzPXqY& token generate success token=MTYyODk0Njc0Ni4zMzkyNDk6NDRkNjI2NmUtZmQwMS0xMWViLWIwZmEtMDI0MmFjMTE
  21:12:27.757 [dbservice2] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
All services, 30 seconds either side (sampled):
  21:11:58.835 [dbservice1] INFO query = select passwards from username_table where user_name='JKhDNmCb'  (×47)
  21:11:58.938 [logservice2] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×41)
  21:11:59.357 [redisservice2] INFO redis write success  (×101)
  21:11:59.629 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×36)
  21:11:59.822 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×50)
  21:12:00.321 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  21:12:00.485 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '35986aea-fd01-11eb-b49a-0242ac110003'}  (×40)
  21:12:01.206 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×44)
  21:12:02.581 [dbservice2] INFO 368e932a-fd01-11eb-8388-0242ac110004-NFBuWbaS-u*8p#x?OjmgL token generate success token=MTYyODk0NjcyMi41ODA5NzY6MzY4ZTkzMmEtZmQwMS0xMWViLTgzODgtMDI0MmFjMTE
  21:12:04.778 [webservice2] ERROR an error occurred in the downstream service  (×6)
  21:12:07.592 [dbservice1] INFO 398f0b9a-fd01-11eb-98aa-0242ac110003-DkpCcNIV-s{?DpLMc_698 token generate success token=MTYyODk0NjcyNy41OTIyOTE0OjM5OGYwYjlhLWZkMDEtMTFlYi05OGFhLTAyNDJhYzE
  21:12:10.299 [dbservice1] INFO 3b2f13f0-fd01-11eb-b95c-0242ac110003-qYMpFKOS-3_B8TGV!g<1j token generate success token=MTYyODk0NjczMC4yOTg3MDgyOjNiMmYxM2YwLWZkMDEtMTFlYi1iOTVjLTAyNDJhYzE
  21:12:13.035 [mobservice1] INFO info 3d1a63b8-fd01-11eb-91e8-0242ac110004:xYHiSMPL write success
  21:12:15.621 [mobservice2] INFO info 3ea3e1f0-fd01-11eb-b833-0242ac110003:QTpUuoqV write success
  21:12:18.372 [dbservice1] INFO 401a4286-fd01-11eb-9bc8-0242ac110004-gbcoxmjO-PiD?ruzgAOCS token generate success token=MTYyODk0NjczOC4zNzE2Nzc6NDAxYTQyODYtZmQwMS0xMWViLTliYzgtMDI0MmFjMTE
  21:12:20.779 [dbservice2] INFO 418aabce-fd01-11eb-b146-0242ac110004-ockFwOnC-_0K6_54f^L?M token generate success token=MTYyODk0Njc0MC43Nzg1NjY0OjQxOGFhYmNlLWZkMDEtMTFlYi1iMTQ2LTAyNDJhYzE  (×2)
  21:12:23.152 [dbservice1] INFO 42f0e14a-fd01-11eb-a558-0242ac110004-DhKfSuMF-Vc<a5J!Q>m{2 token generate success token=MTYyODk0Njc0My4xNTIyMTo0MmYwZTE0YS1mZDAxLTExZWItYTU1OC0wMjQyYWMxMTA
  21:12:26.734 [mobservice2] INFO info 454aaf84-fd01-11eb-9ea6-0242ac110003:OiYedVug write success
  21:12:29.539 [dbservice2] INFO 46be245e-fd01-11eb-a7e4-0242ac110003-BlNycPMr-X$O4_}b1+_(N token generate success token=MTYyODk0Njc0OS41Mzg2NjYyOjQ2YmUyNDVlLWZkMDEtMTFlYi1hN2U0LTAyNDJhYzE
  21:12:31.976 [dbservice1] INFO 4825b3fc-fd01-11eb-ba92-0242ac110004-fiNWCoaq-R92=3TN.}J8v token generate success token=MTYyODk0Njc1MS45NzU4ODA5OjQ4MjViM2ZjLWZkMDEtMTFlYi1iYTkyLTAyNDJhYzE
  21:12:34.642 [dbservice1] INFO 49bd0e54-fd01-11eb-adaf-0242ac110004-QlZMgGXD-Xez_ixZ.U!yo token generate success token=MTYyODk0Njc1NC42NDI0MTc3OjQ5YmQwZTU0LWZkMDEtMTFlYi1hZGFmLTAyNDJhYzE
  21:12:37.189 [dbservice2] INFO 4b4c86fa-fd01-11eb-8faf-0242ac110003-WRrkiQEt-6aT9E1w<+@(I token generate success token=MTYyODk0Njc1Ny4xODkwODY0OjRiNGM4NmZhLWZkMDEtMTFlYi04ZmFmLTAyNDJhYzE
  21:12:39.888 [dbservice2] INFO 4cd9c6d6-fd01-11eb-82c2-0242ac110004-SzfIWpZE-{_HV.}LO^GnA token generate success token=MTYyODk0Njc1OS44ODg0MDU6NGNkOWM2ZDYtZmQwMS0xMWViLTgyYzItMDI0MmFjMTE
  21:12:42.486 [dbservice1] INFO 4e6817c8-fd01-11eb-a1d8-0242ac110003-gtLKWOSc-hjD2_FZ_9Qmn token generate success token=MTYyODk0Njc2Mi40ODYzMDk1OjRlNjgxN2M4LWZkMDEtMTFlYi1hMWQ4LTAyNDJhYzE  (×2)
  21:12:45.200 [dbservice2] INFO 4ff6ca08-fd01-11eb-87a2-0242ac110004-CSoBqsmk-EAWSvDB%uQV+ token generate success token=MTYyODk0Njc2NS4yMDAwOTc4OjRmZjZjYTA4LWZkMDEtMTFlYi04N2EyLTAyNDJhYzE
  21:12:48.491 [mobservice2] INFO info 52380b1a-fd01-11eb-82e7-0242ac110004:JdtfzjpK write success
  21:12:51.464 [dbservice2] INFO 53c3822a-fd01-11eb-b4e1-0242ac110003-QPYaeVWt-4EbCnjLW>+T* token generate success token=MTYyODk0Njc3MS40NjQxMzQ1OjUzYzM4MjJhLWZkMDEtMTFlYi1iNGUxLTAyNDJhYzE
  21:12:53.888 [dbservice1] INFO 553bfb3c-fd01-11eb-9264-0242ac110003-mCkaEIVe-%4QxON(snAYv token generate success token=MTYyODk0Njc3My44ODgwNzc3OjU1M2JmYjNjLWZkMDEtMTFlYi05MjY0LTAyNDJhYzE
  21:12:56.493 [dbservice1] INFO 56b1b588-fd01-11eb-aacf-0242ac110004-laVNGIPf-{Z8wE?(U^nzJ token generate success token=MTYyODk0Njc3Ni40OTI4NDU6NTZiMWI1ODgtZmQwMS0xMWViLWFhY2YtMDI0MmFjMTE

## p0438
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service catalogue, 2024-11-23T08:05:54.433Z
```
{"timestamp":1732349154433572000,"container_name":"catalogue","pod_name":"catalogue-b98c66547-vcsvp","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T08:05:54Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=4.524162ms"}
```
Same service, the 2 minutes before (oldest first):
  08:05:46.584 [catalogue] ts=2024-11-23T08:05:46Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.29542ms  (×10)
  08:05:47.776 [catalogue] ts=2024-11-23T08:05:47Z caller=logging.go:62 method=Get id=a0a4f044-b040-410d-8ead-4de0446aec7e sock=a0a4f044-b040-410d-8ead-4de0446aec7e err=null took=5.750935  (×4)
  08:05:48.384 [catalogue] ts=2024-11-23T08:05:48Z caller=logging.go:85 method=Health result=2 took=26.084µs  (×6)
All services, 30 seconds either side (sampled):
  08:05:24.437 [front-end] User cart deleted with status: 503  (×62)
  08:05:25.646 [user] ts=2024-11-23T08:05:25.646463671Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418cbda437380001deebf2 took=4.932395ms  (×61)
  08:05:25.925 [front-end] Received response: "{\"firstName\":\"TVUrjnogtP\",\"lastName\":\"TVUrjnogtP\",\"username\":\"TVUrjnogtP\",\"id\":\"67418caea437380001deebbd\",\"_links\":{\"addr
  08:05:26.603 [queue-master] 2024-11-23 08:05:26.602 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[GET],produces=[application/hal+json |
  08:05:26.614 [queue-master] 2024-11-23 08:05:26.614 INFO 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframework.web.servl
  08:05:27.710 [queue-master] 2024-11-23 08:05:27.710 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}" onto publ
  08:05:28.549 [front-end] Posting Customer: {"username":"hXEwrKNJwlXqYDy","password":"OVhCj","email":"hXEwrKNJwlXqYDy@gmail.com","firstName":"hXEwrKNJwlXqYDy","lastName":"hXEwrKNJwlXqYDy
  08:05:30.742 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×5)
  08:05:32.618 [shipping] 2024-11-23 08:05:32.618 INFO [shipping,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-m
  08:05:35.434 [user] ts=2024-11-23T08:05:35.43411161Z caller=middlewares.go:46 method=Register username=WoyOvB email=WoyOvB@gmail.com took=2.178584ms
  08:05:38.557 [front-end] Posting Customer: {"username":"lYvQmmCWwWuvT","password":"cBYjNxlFd","email":"lYvQmmCWwWuvT@gmail.com","firstName":"lYvQmmCWwWuvT","lastName":"lYvQmmCWwWuvT"}
  08:05:39.192 [orders] 2024-11-23 08:05:39.192 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[D
  08:05:39.287 [orders] 2024-11-23 08:05:39.286 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[text/html]}" onto public
  08:05:41.192 [orders] 2024-11-23 08:05:41.192 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/j
  08:05:44.588 [orders] 2024-11-23 08:05:44.587 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:05:47.226 [front-end] Received response: "{\"firstName\":\"kvjRZNQgiVnmkal\",\"lastName\":\"kvjRZNQgiVnmkal\",\"username\":\"kvjRZNQgiVnmkal\",\"id\":\"67418cc2a437380001deebff\",\"_
  08:05:49.803 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732349149591,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×40)
  08:05:53.444 [front-end] Posting Customer: {"username":"vwAuXUnZkT","password":"UibSxdV","email":"vwAuXUnZkT@gmail.com","firstName":"vwAuXUnZkT","lastName":"vwAuXUnZkT"}
  08:05:55.008 [shipping] 2024-11-23 08:05:55.007 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applica
  08:05:58.911 [front-end] Received response: "{\"firstName\":\"eqACgmjO\",\"lastName\":\"eqACgmjO\",\"username\":\"eqACgmjO\",\"id\":\"67418cd4a437380001deec3c\",\"_links\":{\"addresses\
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  08:06:05.306 [carts] 2024-11-23 08:06:05.304 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.sp
  08:06:07.004 [shipping] 2024-11-23 08:06:07.003 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/x
  08:06:07.103 [shipping] 2024-11-23 08:06:07.103 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[text/html]}" onto publ
  08:06:12.361 [front-end] Received response: "{\"firstName\":\"brTpfrzj\",\"lastName\":\"brTpfrzj\",\"username\":\"brTpfrzj\",\"id\":\"67418ce3a437380001deec68\",\"_links\":{\"addresses\
  08:06:14.712 [shipping] 2024-11-23 08:06:14.711 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering
  08:06:15.805 [carts] 2024-11-23 08:06:15.805 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[GET],produces=[  (×2)
  08:06:16.403 [shipping] 2024-11-23 08:06:16.402 INFO [shipping,,,] 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0  (×2)
  08:06:19.008 [carts] 2024-11-23 08:06:19.008 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  08:06:20.737 [front-end] Received response: "{\"firstName\":\"vZvbgNwwdo\",\"lastName\":\"vZvbgNwwdo\",\"username\":\"vZvbgNwwdo\",\"id\":\"67418ceaa437380001deec7f\",\"_links\":{\"addr

## p0182
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service shippingservice, 2024-11-18T06:42:01.368Z
```
{"timestamp":1731912121368977700,"container_name":"shippingservice","pod_name":"shippingservice-547ddf469c-vjbwz","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"[GetQuote] received request"}
```
Same service, the 2 minutes before (oldest first):
  06:41:53.316 [shippingservice] [GetQuote] received request  (×9)
  06:41:53.316 [shippingservice] [GetQuote] completed request  (×9)
  06:41:53.376 [shippingservice] [ShipOrder] received request
  06:41:53.376 [shippingservice] [ShipOrder] completed request
All services, 30 seconds either side (sampled):
  06:41:31.963 [frontend] request started  (×290)
  06:41:31.966 [currencyservice] Getting supported currencies...  (×243)
  06:41:32.040 [currencyservice] conversion request successful  (×628)
  06:41:32.265 [adservice] received ad request (context_words=[])  (×30)
  06:41:32.588 [frontend] setting currency  (×17)
  06:41:32.820 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '0PUK6V6EV0', 'OLJCESPC7Z', 'L9ECAV7KIM', '6E92ZMYYFZ']  (×204)
  06:41:33.388 [adservice] received ad request (context_words=[hair, beauty])  (×14)
  06:41:33.396 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=2ZYFJ3GM2N, quantity=3  (×30)
  06:41:33.437 [shippingservice] [GetQuote] received request  (×74)
  06:41:34.027 [frontend] placing order  (×10)
  06:41:34.050 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"341","nanos":408505085},"credit_card":{"credit_card_number":"44494476578268  (×2)
  06:41:34.053 [checkoutservice] payment went through (transaction_id: 81b63547-762f-4014-891f-5c30241851c5)  (×10)
  06:41:34.054 [shippingservice] [ShipOrder] completed request  (×10)
  06:41:34.060 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 14  (×10)
  06:41:34.062 [frontend] order placed  (×10)
  06:41:35.052 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"4649","nanos":408485696},"credit_card":{"credit_card_number":"4664705077616  (×3)
  06:41:35.064 [checkoutservice] failed to send order confirmation to "susan01@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:41:37.380 [adservice] received ad request (context_words=[footwear])  (×17)
  06:41:38.149 [adservice] received ad request (context_words=[clothing, tops])  (×13)
  06:41:40.955 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"1100","nanos":999557729},"credit_card":{"credit_card_number":"4897624225753  (×3)
  06:41:40.966 [checkoutservice] failed to send order confirmation to "waustin@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:41:44.049 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '66VCHSJNUP', '0PUK6V6EV0']  (×4)
  06:41:53.343 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="CAD"
  06:41:53.372 [paymentservice] Transaction processed: visa ending 9626 Amount: CAD921.744155677
  06:42:03.678 [checkoutservice] failed to send order confirmation to "rhodesscott@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:42:11.332 [adservice] received ad request (context_words=[decor, home])  (×8)
  06:42:16.897 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"526","nanos":860000000},"credit_card":{"credit_card_number":"48009994213468
  06:42:16.908 [checkoutservice] failed to send order confirmation to "reyesjohn@example.org": rpc error: code = Unavailable desc = no healthy upstream

## p0305
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:20:14.729Z
```
{"timestamp":1732245614729350100,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /cart 500 36.881 ms - 64"}
```
Same service, the 2 minutes before (oldest first):
  03:20:14.576 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff865b0df5c00019b1eaa"}
  03:20:14.583 [front-end] Received response: "{\"firstName\":\"jcjcoJsqivyV\",\"lastName\":\"jcjcoJsqivyV\",\"username\":\"jcjcoJsqivyV\",\"id\":\"673ff860b0df5c00019b1e9a\",\"_links\":{
  03:20:14.583 [front-end] GET Request to: http://user/customers/673ff860b0df5c00019b1e9a/addresses  (×2)
  03:20:14.585 [front-end] POST /addresses 200 - ms - -
  03:20:14.589 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff868b0df5c00019b1eb8\",\"_links\":{\"
  03:20:14.590 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff865b0df5c00019b1eaa"}
  03:20:14.590 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:20:14.590 [front-end] [ undefined, undefined ]
  03:20:14.590 [front-end] Posting Order: {"customer":"http://user/customers/673ff860b0df5c00019b1e9a","address":"http://user/addresses/673ff868b0df5c00019b1eb7","card":"http://user/cards
  03:20:14.598 [front-end] POST /cards 200 - ms - -
  03:20:14.645 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245614642,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:20:14.645 [front-end] Order response: {"timestamp":1732245614642,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:20:14.647 [front-end] POST /orders 500 - ms - -
  03:20:14.649 [front-end] Attempting to delete cart for user: 673ff865b0df5c00019b1eaa
  03:20:14.682 [front-end] User cart deleted with status: 503
  03:20:14.685 [front-end] DELETE /cart 503 - ms - -
  03:20:14.691 [front-end] Attempting to add to cart: {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","quantity":1}
  03:20:14.697 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/
  03:20:14.697 [front-end] POST to carts: http://carts/carts/673ff865b0df5c00019b1eaa/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×25)
  03:20:06.543 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff854b0df5c00019b1e7f\",\"_links\":{\"  (×41)
  03:20:06.586 [orders] 2024-11-22 03:20:06.586 ERROR [orders,,,] 6 --- [p-nio-80-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×24)
  03:20:06.649 [user] ts=2024-11-22T03:20:06.649242768Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff861b0df5c00019b1e9e took=1.734848ms  (×42)
  03:20:06.769 [front-end] User cart deleted with status: 503  (×42)
  03:20:06.803 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×6)
  03:20:07.186 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×9)
  03:20:08.469 [front-end] Posting Customer: {"username":"HNCLfJfsnW","password":"sSvsy","email":"HNCLfJfsnW@gmail.com","firstName":"HNCLfJfsnW","lastName":"HNCLfJfsnW"}
  03:20:08.498 [front-end] Carts merged.  (×34)
  03:20:09.093 [user] ts=2024-11-22T03:20:09.093533288Z caller=middlewares.go:46 method=Register username=CBhyKd email=CBhyKd@gmail.com took=1.350871ms
  03:20:09.192 [carts] 2024-11-22 03:20:09.192 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  03:20:10.049 [front-end] Posting Customer: {"username":"lPEGqahDSutlQTj","password":"AoWWVDzGsz","email":"lPEGqahDSutlQTj@gmail.com","firstName":"lPEGqahDSutlQTj","lastName":"lPEGqahDSu
  03:20:12.002 [front-end] Received response: "{\"firstName\":\"oVuSYHHeDcohK\",\"lastName\":\"oVuSYHHeDcohK\",\"username\":\"oVuSYHHeDcohK\",\"id\":\"673ff855b0df5c00019b1e85\",\"_links\
  03:20:14.429 [front-end] Posting Customer: {"username":"LWbxoNrjdrYfe","password":"dgukoXmQfq","email":"LWbxoNrjdrYfe@gmail.com","firstName":"LWbxoNrjdrYfe","lastName":"LWbxoNrjdrYfe"}
  03:20:16.376 [front-end] Posting Customer: {"username":"zCHyJV","password":"DBVYLG","email":"zCHyJV@gmail.com","firstName":"zCHyJV","lastName":"zCHyJV"}
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:20.340 [front-end] Posting Customer: {"username":"BBYdunXrngQk","password":"jbihHjN","email":"BBYdunXrngQk@gmail.com","firstName":"BBYdunXrngQk","lastName":"BBYdunXrngQk"}
  03:20:23.473 [front-end] Received response: "{\"firstName\":\"AIHRSQU\",\"lastName\":\"AIHRSQU\",\"username\":\"AIHRSQU\",\"id\":\"673ff863b0df5c00019b1ea2\",\"_links\":{\"addresses\":{
  03:20:26.017 [front-end] Posting Customer: {"username":"HLNoIPafm","password":"sBlBYfK","email":"HLNoIPafm@gmail.com","firstName":"HLNoIPafm","lastName":"HLNoIPafm"}
  03:20:28.421 [front-end] Posting Customer: {"username":"MoGml","password":"PJpiau","email":"MoGml@gmail.com","firstName":"MoGml","lastName":"MoGml"}
  03:20:30.252 [front-end] Posting Customer: {"username":"MKGIsEbVYi","password":"VhFAQhsXw","email":"MKGIsEbVYi@gmail.com","firstName":"MKGIsEbVYi","lastName":"MKGIsEbVYi"}
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.186 [front-end] Received response: "{\"firstName\":\"kgzVKACfUvkHp\",\"lastName\":\"kgzVKACfUvkHp\",\"username\":\"kgzVKACfUvkHp\",\"id\":\"673ff869b0df5c00019b1ebd\",\"_links\
  03:20:36.109 [front-end] Posting Customer: {"username":"HWsmCvxoMrNqX","password":"MJvuU","email":"HWsmCvxoMrNqX@gmail.com","firstName":"HWsmCvxoMrNqX","lastName":"HWsmCvxoMrNqX"}
  03:20:38.070 [session-db] 1:M 22 Nov 2024 03:20:38.070 * Background saving started by pid 32
  03:20:39.079 [user] ts=2024-11-22T03:20:39.079141282Z caller=middlewares.go:46 method=Register username=ELXzX email=ELXzX@gmail.com took=1.044635ms
  03:20:42.525 [front-end] Posting Customer: {"username":"jVIVRgJfOAq","password":"zWZXxq","email":"jVIVRgJfOAq@gmail.com","firstName":"jVIVRgJfOAq","lastName":"jVIVRgJfOAq"}
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:20:43.391 [carts] 2024-11-22 03:20:43.391 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
