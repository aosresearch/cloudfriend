## p0818
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-10T13:15:16.501Z
```
{"timestamp":1733836516501584000,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-vpgpt","node_name":"ip-192-168-51-182.ap-southeast-2.compute.internal","message":"2024-12-10 13:15:16.500  INFO 1 --- [           main] o.s.w.s.handler.SimpleUrlHandlerMapping  : Mapped URL path [/webjars/**] onto handler of type [class org.springframework.web.servlet.resource.ResourceHttpRequestHandler]"}
```
Same service, the 2 minutes before (oldest first):
  13:15:07.501 [ts-auth-service] 2024-12-10 13:15:07.501 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  13:15:08.565 [ts-auth-service] 2024-12-10 13:15:08.565 INFO 1 --- [ main] o.s.i.config.IntegrationRegistrar : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. The
  13:15:11.574 [ts-auth-service] 2024-12-10 13:15:11.573 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def
  13:15:11.666 [ts-auth-service] 2024-12-10 13:15:11.665 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'taskScheduler' has been explicitly defined. Therefore, a de
  13:15:13.072 [ts-auth-service] 2024-12-10 13:15:13.071 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.configuration.ObjectP
  13:15:13.264 [ts-auth-service] 2024-12-10 13:15:13.263 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'objectPostProcessor' of type [org.springframework.security.config.an
  13:15:13.270 [ts-auth-service] 2024-12-10 13:15:13.269 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.access.expression.method.DefaultMethodS
  13:15:13.366 [ts-auth-service] 2024-12-10 13:15:13.365 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.method.configuration.
  13:15:13.379 [ts-auth-service] 2024-12-10 13:15:13.379 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  13:15:13.864 [ts-auth-service] 2024-12-10 13:15:13.863 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact
  13:15:13.865 [ts-auth-service] 2024-12-10 13:15:13.865 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [java.util.Properties] is not e
  13:15:15.410 [ts-auth-service] 2024-12-10 13:15:15.409 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  13:15:16.114 [ts-auth-service] 2024-12-10 13:15:16.113 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users],methods=[GET]}" onto public org.springframework.h
  13:15:16.114 [ts-auth-service] 2024-12-10 13:15:16.114 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/{userId}],methods=[DELETE]}" onto public org.sprin
  13:15:16.114 [ts-auth-service] 2024-12-10 13:15:16.114 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/hello],methods=[GET]}" onto public java.lang.Objec
  13:15:16.115 [ts-auth-service] 2024-12-10 13:15:16.114 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  13:15:16.115 [ts-auth-service] 2024-12-10 13:15:16.115 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth],methods=[POST]}" onto public org.springframework.h
  13:15:16.116 [ts-auth-service] 2024-12-10 13:15:16.115 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth/hello],methods=[GET]}" onto public java.lang.String
  13:15:16.117 [ts-auth-service] 2024-12-10 13:15:16.117 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  13:15:16.117 [ts-auth-service] 2024-12-10 13:15:16.117 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
All services, 30 seconds either side (sampled):
  13:14:47.755 [ts-admin-basic-info-service] 2024-12-10 13:14:47.755 INFO 1 --- [io-18767-exec-4] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×10)
  13:14:54.705 [ts-auth-service] 2024-12-10 13:14:54.705 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def  (×2)
  13:14:56.704 [ts-auth-service] 2024-12-10 13:14:56.704 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.method.configuration.  (×2)
  13:14:56.833 [ts-travel2-service] 2024-12-10 13:14:56.832 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×12)
  13:14:58.859 [ts-order-service] 2024-12-10 13:14:58.859 ERROR 1 --- [io-12031-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  13:15:01.617 [ts-auth-service] 2024-12-10 13:15:01.616 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]  (×2)
  13:15:03.980 [ts-travel-service] 2024-12-10 13:15:03.980 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×9)
  13:15:06.512 [ts-auth-service] 2024-12-10 13:15:06.512 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClust  (×2)
  13:15:07.041 [ts-travel-service] 2024-12-10 13:15:07.040 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d
  13:15:07.411 [ts-auth-service] 2024-12-10 13:15:07.411 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip  (×2)
  13:15:12.032 [ts-assurance-mongo] {"t":{"$date":"2024-12-10T13:15:12.032+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:12.694 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-10T13:15:12.694+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:13.234 [ts-price-mongo] {"t":{"$date":"2024-12-10T13:15:13.234+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:14.921 [ts-contacts-mongo] {"t":{"$date":"2024-12-10T13:15:14.921+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:15.828 [ts-travel-service] 2024-12-10 13:15:15.828 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)
  13:15:16.114 [ts-auth-service] 2024-12-10 13:15:16.113 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users],methods=[GET]}" onto public org.springframework.h
  13:15:16.117 [ts-auth-service] 2024-12-10 13:15:16.117 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  13:15:18.503 [ts-auth-service] 2024-12-10 13:15:18.503 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  13:15:18.508 [ts-auth-service] 2024-12-10 13:15:18.507 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  13:15:19.366 [ts-travel-service] 2024-12-10 13:15:19.366 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×2)
  13:15:24.400 [ts-auth-service] 2024-12-10 13:15:24.400 INFO 1 --- [ main] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 1 subscriber(s).
  13:15:30.209 [ts-auth-service] 2024-12-10 13:15:30.208 INFO 1 --- [io-12340-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  13:15:32.501 [ts-auth-service] 2024-12-10 13:15:32.500 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×7)
  13:15:32.934 [ts-travel2-service] 2024-12-10 13:15:32.933 ERROR 1 --- [io-16346-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×5)
  13:15:34.962 [ts-admin-basic-info-service] 2024-12-10 13:15:34.961 ERROR 1 --- [io-18767-exec-9] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×3)
  13:15:45.774 [ts-auth-service] 2024-12-10 13:15:45.774 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null
  13:15:45.931 [ts-auth-service] 2024-12-10 13:15:45.931 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 763cdad2-044b-466f-a5dc-11dbb90b599a USER ID

## p0749
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-23T14:18:42.917Z
```
{"timestamp":1732371522917821400,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-x6hg8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"AddItemAsync called with userId=69da4256-dda1-4804-8ebf-4dca622316e6, productId=2ZYFJ3GM2N, quantity=7"}
```
Same service, the 2 minutes before (oldest first):
  14:18:40.631 [cartservice] GetCartAsync called with userId=706f37f6-1c4e-4686-b19d-4ff2d2c889ad  (×17)
  14:18:42.144 [cartservice] AddItemAsync called with userId=48ab811e-292b-4e0c-aa9b-b8f85d1e86a4, productId=2ZYFJ3GM2N, quantity=5  (×2)
  14:18:42.427 [cartservice] EmptyCartAsync called with userId=49b488ed-4e7d-4d19-ac52-cb9ad89d3309
All services, 30 seconds either side (sampled):
  14:18:12.933 [frontend] request started  (×294)
  14:18:12.940 [cartservice] GetCartAsync called with userId=e33cfee9-798f-4567-b115-69c40dce8607  (×252)
  14:18:12.964 [adservice] received ad request (context_words=[decor, home])  (×15)
  14:18:13.267 [frontend] home  (×34)
  14:18:13.586 [frontend] view user cart  (×71)
  14:18:14.632 [adservice] received ad request (context_words=[clothing, tops])  (×17)
  14:18:16.236 [adservice] received ad request (context_words=[footwear])  (×17)
  14:18:17.673 [frontend] placing order  (×7)
  14:18:17.692 [paymentservice] Transaction processed: visa ending 5876 Amount: CAD70.802519236
  14:18:17.696 [shippingservice] [ShipOrder] completed request  (×7)
  14:18:17.705 [checkoutservice] order confirmation email sent to "ugreene@example.org"
  14:18:22.724 [checkoutservice] [PlaceOrder] user_id="6e17f999-1f44-47b4-93f0-534a09a0d813" user_currency="EUR"  (×2)
  14:18:22.759 [emailservice] A request to send order confirmation email to robertstamara@example.net has been received.
  14:18:28.540 [checkoutservice] [PlaceOrder] user_id="48ab811e-292b-4e0c-aa9b-b8f85d1e86a4" user_currency="JPY"
  14:18:28.581 [emailservice] A request to send order confirmation email to ashleyrodriguez@example.com has been received.
  14:18:31.130 [checkoutservice] order confirmation email sent to "morgangill@example.org"
  14:18:42.420 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"93","nanos":483344537},"credit_card":{"credit_card_number":"467836699810349  (×2)
  14:18:42.435 [checkoutservice] order confirmation email sent to "pamela21@example.com"
  14:19:03.356 [checkoutservice] [PlaceOrder] user_id="e33cfee9-798f-4567-b115-69c40dce8607" user_currency="USD"
  14:19:03.392 [emailservice] A request to send order confirmation email to sherriallen@example.com has been received.
  14:19:12.096 [redis] 1:M 23 Nov 2024 14:19:12.096 * Background saving started by pid 49
  14:19:12.197 [redis] 1:M 23 Nov 2024 14:19:12.197 * Background saving terminated with success

## p0176
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:36:26.526Z
```
{"timestamp":1731911786526258000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"order placed"}
```
Same service, the 2 minutes before (oldest first):
  06:36:25.847 [frontend] request complete  (×6)
  06:36:25.978 [frontend] request started  (×7)
  06:36:25.978 [frontend] serving product page  (×4)
  06:36:26.404 [frontend] adding to cart
  06:36:26.416 [frontend] view user cart
  06:36:26.475 [frontend] placing order
All services, 30 seconds either side (sampled):
  06:35:56.526 [frontend] request started  (×328)
  06:35:56.532 [cartservice] GetCartAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add  (×266)
  06:35:56.549 [shippingservice] [GetQuote] completed request  (×89)
  06:35:57.350 [frontend] serving product page  (×141)
  06:35:57.478 [frontend] setting currency  (×24)
  06:35:57.529 [adservice] received ad request (context_words=[])  (×36)
  06:35:59.143 [frontend] adding to cart  (×38)
  06:36:01.958 [frontend] placing order  (×12)
  06:36:01.979 [paymentservice] Transaction processed: visa ending 8010 Amount: JPY74792.350287706  (×5)
  06:36:01.983 [shippingservice] [ShipOrder] completed request  (×12)
  06:36:01.990 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 14  (×12)
  06:36:08.357 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', 'OLJCESPC7Z']  (×5)
  06:36:10.064 [redis] 1:M 18 Nov 2024 06:36:10.064 * Background saving started by pid 65
  06:36:10.166 [redis] 1:M 18 Nov 2024 06:36:10.166 * Background saving terminated with success
  06:36:11.241 [paymentservice] Transaction processed: visa ending 5476 Amount: EUR393.551525877  (×3)
  06:36:17.933 [checkoutservice] failed to send order confirmation to "johnsonjames@example.net": rpc error: code = Unavailable desc = no healthy upstream
  06:36:19.286 [paymentservice] Transaction processed: visa ending 5818 Amount: USD710.310000000  (×2)
  06:36:26.476 [checkoutservice] [PlaceOrder] user_id="33421b66-55b6-413b-9ba9-3230c85c58dc" user_currency="GBP"
  06:36:26.525 [checkoutservice] failed to send order confirmation to "moralesnicolas@example.com": rpc error: code = Unavailable desc = no healthy upstream
  06:36:42.513 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="CAD"
  06:36:42.558 [checkoutservice] failed to send order confirmation to "koliver@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:36:48.754 [emailservice] Traceback (most recent call last): File "/email_server/email_server.py", line 199, in <module> start(dummy_mode = True) File "/email_server/email_server.py", li
  06:36:55.707 [checkoutservice] failed to send order confirmation to "tannermark@example.net": rpc error: code = Unavailable desc = no healthy upstream

## p0711
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-14T02:15:47.502Z
```
{"service":"webservice2","message":"2021-08-14 02:15:47,502 | INFO | 0.0.0.3 | 172.17.0.4 | webservice2 | cdae0a33dc2988aa | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  02:15:44.670 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  02:15:44.671 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '79df8dae-fc62-11eb-a775-0242ac110004', 'value': '', 'ex': 10}  (×3)
  02:15:44.731 [webservice2] INFO uuid: 79df8dae-fc62-11eb-a775-0242ac110004 write redis successfully  (×3)
  02:15:44.837 [webservice2] INFO complete information: {'uuid': '79df8dae-fc62-11eb-a775-0242ac110004', 'user_id': 'XUtTqLre'}  (×3)
  02:15:44.844 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×3)
  02:15:44.844 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
  02:15:44.982 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
All services, 30 seconds either side (sampled):
  02:15:17.563 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×50)
  02:15:17.753 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  02:15:17.996 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '69b7cbe4-fc62-11eb-82e2-0242ac110004'}  (×43)
  02:15:18.143 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  02:15:18.441 [webservice1] INFO uuid: 6a354fce-fc62-11eb-a145-0242ac110003 write redis successfully  (×44)
  02:15:18.846 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×52)
  02:15:19.077 [dbservice2] INFO 6a354fce-fc62-11eb-a145-0242ac110003-GVawnFOc-VvLan.=:lYq> token generate success token=MTYyODg3ODUxOS4wNzY3MzE0OjZhMzU0ZmNlLWZjNjItMTFlYi1hMTQ1LTAyNDJhYzE
  02:15:19.934 [dbservice2] INFO 6ab74cd6-fc62-11eb-a2b1-0242ac110004-tTbvdojy-ck-aO0rUmB.1 token generate success token=MTYyODg3ODUxOS45MzM1NjQ6NmFiNzRjZDYtZmM2Mi0xMWViLWEyYjEtMDI0MmFjMTE
  02:15:21.506 [dbservice1] INFO 6bbc23fe-fc62-11eb-95c6-0242ac110004-EAoGeZwV-fb^z8tm>W.Jk token generate success token=MTYyODg3ODUyMS41MDU4Nzg3OjZiYmMyM2ZlLWZjNjItMTFlYi05NWM2LTAyNDJhYzE
  02:15:24.280 [mobservice1] INFO info 6d8c0686-fc62-11eb-bd4d-0242ac110004:HmUeFxBl write success
  02:15:26.253 [webservice1] ERROR an error occurred in the downstream service
  02:15:28.558 [dbservice1] INFO 6fd64bd6-fc62-11eb-839c-0242ac110003-AkaZFCps-BVsW974Lbmjc token generate success token=MTYyODg3ODUyOC41NTc4MTkxOjZmZDY0YmQ2LWZjNjItMTFlYi04MzljLTAyNDJhYzE  (×2)
  02:15:31.058 [dbservice1] INFO 716179ee-fc62-11eb-92f6-0242ac110004-ztuaUykM-dE:?f1Sbn.l^ token generate success token=MTYyODg3ODUzMS4wNTgyMjM3OjcxNjE3OWVlLWZjNjItMTFlYi05MmY2LTAyNDJhYzE
  02:15:33.949 [dbservice1] INFO 7311a16a-fc62-11eb-9cfb-0242ac110004-IjgwExRc-SL&dYC@_yX^8 token generate success token=MTYyODg3ODUzMy45NDkxMzg0OjczMTFhMTZhLWZjNjItMTFlYi05Y2ZiLTAyNDJhYzE
  02:15:36.593 [mobservice1] INFO info 74df09c4-fc62-11eb-851e-0242ac110004:rYEevjPt write success
  02:15:39.407 [mobservice1] INFO info 767ea53c-fc62-11eb-ad1e-0242ac110003:xhUTVXnF write success
  02:15:41.681 [dbservice2] INFO 77c2f56a-fc62-11eb-8c87-0242ac110004-jnuiIECt-_JI:sCNEZ%ay token generate success token=MTYyODg3ODU0MS42ODExMDA4Ojc3YzJmNTZhLWZjNjItMTFlYi04Yzg3LTAyNDJhYzE
  02:15:44.094 [dbservice1] INFO 7925368e-fc62-11eb-828c-0242ac110003-tWMvxnLr-}L^r$XBv-x0J token generate success token=MTYyODg3ODU0NC4wOTM3Njg6NzkyNTM2OGUtZmM2Mi0xMWViLTgyOGMtMDI0MmFjMTE
  02:15:46.470 [dbservice2] INFO 7a841c02-fc62-11eb-9ca9-0242ac110003-NFBuWbaS-u*8p#x?OjmgL token generate success token=MTYyODg3ODU0Ni40Njk2OTgyOjdhODQxYzAyLWZjNjItMTFlYi05Y2E5LTAyNDJhYzE
  02:15:49.244 [dbservice1] INFO 7c364d18-fc62-11eb-ac54-0242ac110004-OMLuHZEe-zUGYQa}urZJ/ token generate success token=MTYyODg3ODU0OS4yNDM5ODg4OjdjMzY0ZDE4LWZjNjItMTFlYi1hYzU0LTAyNDJhYzE
  02:15:51.581 [dbservice1] INFO 7d89dd42-fc62-11eb-be59-0242ac110003-xVDzUigO-B^s:FwmVgy>_ token generate success token=MTYyODg3ODU1MS41ODEyOTI0OjdkODlkZDQyLWZjNjItMTFlYi1iZTU5LTAyNDJhYzE
  02:15:54.401 [dbservice2] INFO 7f4078da-fc62-11eb-ba44-0242ac110004-JZinoGDa-nw4#7?JZCUe) token generate success token=MTYyODg3ODU1NC40MDA5NzA1OjdmNDA3OGRhLWZjNjItMTFlYi1iYTQ0LTAyNDJhYzE
  02:15:57.009 [mobservice2] INFO info 81013682-fc62-11eb-bf7b-0242ac110003:rxiVPwZL write success
  02:15:59.690 [mobservice2] INFO info 82a1ca88-fc62-11eb-a0b7-0242ac110003:CPiYkQrA write success
  02:16:02.463 [mobservice2] INFO info 84470ce0-fc62-11eb-9f3c-0242ac110003:QPYaeVWt write success
  02:16:04.860 [mobservice2] INFO info 85bb6fb2-fc62-11eb-ac6a-0242ac110004:nulqIiBE write success
  02:16:07.296 [mobservice2] INFO info 872bfd62-fc62-11eb-a822-0242ac110003:cSnIQPJM write success
  02:16:10.653 [mobservice1] INFO info 892ee8f4-fc62-11eb-b623-0242ac110004:JTPZbGUX write success
  02:16:13.019 [mobservice2] INFO info 8a9c1464-fc62-11eb-8df6-0242ac110004:uZrYXDKb write success
  02:16:15.661 [mobservice1] INFO info 8c27f1ae-fc62-11eb-8792-0242ac110004:pdAkGNZq write success

## p0605
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-preserve-other-service, 2024-12-07T20:04:45.031Z
```
{"timestamp":1733601885031457300,"container_name":"ts-preserve-other-service","pod_name":"ts-preserve-other-service-7cf4c487d7-qmstq","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 20:04:45.031  INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl       : [Preserve Other Service][Order] Order Travel Date: Sat Dec 07 00:00:00 GMT 2024"}
```
Same service, the 2 minutes before (oldest first):
  20:04:44.424 [ts-preserve-other-service] 2024-12-07 20:04:44.424 INFO 1 --- [io-14569-exec-2] p.controller.PreserveOtherController : [Preserve Other Service][Preserve] Account order from Shang Hai ----
  20:04:44.424 [ts-preserve-other-service] 2024-12-07 20:04:44.424 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Verify Login] Success
  20:04:44.424 [ts-preserve-other-service] 2024-12-07 20:04:44.424 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security
  20:04:44.424 [ts-preserve-other-service] 2024-12-07 20:04:44.424 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Check Account Security] Checking....
  20:04:44.486 [ts-preserve-other-service] 2024-12-07 20:04:44.486 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security Complete. 
  20:04:44.486 [ts-preserve-other-service] 2024-12-07 20:04:44.486 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 2] Find contacts
  20:04:44.486 [ts-preserve-other-service] 2024-12-07 20:04:44.486 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 2] Contacts Id: d14da0ec-da93-46c3-842d
  20:04:44.486 [ts-preserve-other-service] 2024-12-07 20:04:44.486 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Contacts By Id is] Getting....
  20:04:44.502 [ts-preserve-other-service] 2024-12-07 20:04:44.501 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Step 2] Complete
  20:04:44.502 [ts-preserve-other-service] 2024-12-07 20:04:44.501 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Check tickets num
  20:04:44.502 [ts-preserve-other-service] 2024-12-07 20:04:44.501 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] TripId: Z1234
  20:04:44.502 [ts-preserve-other-service] 2024-12-07 20:04:44.502 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting....
  20:04:44.879 [ts-preserve-other-service] 2024-12-07 20:04:44.879 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : TripAllDetail : TripAllDetail(status=false, message=null, tripResponse
  20:04:44.879 [ts-preserve-other-service] 2024-12-07 20:04:44.879 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : TripResponse : TripResponse(tripId=Z1234, startingStation=Shang Hai, t
  20:04:44.879 [ts-preserve-other-service] 2024-12-07 20:04:44.879 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Tickets Enough
  20:04:44.879 [ts-preserve-other-service] 2024-12-07 20:04:44.879 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order
  20:04:44.879 [ts-preserve-other-service] 2024-12-07 20:04:44.879 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Station By Name]  (×2)
All services, 30 seconds either side (sampled):
  20:04:15.122 [ts-auth-service] 2024-12-07 20:04:15.121 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×13)
  20:04:15.353 [ts-basic-service] 2024-12-07 20:04:15.353 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×35)
  20:04:15.413 [ts-basic-service] 2024-12-07 20:04:15.413 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4  (×28)
  20:04:15.564 [ts-seat-service] 2024-12-07 20:04:15.563 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×3)
  20:04:15.681 [ts-order-other-service] 2024-12-07 20:04:15.681 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×4)
  20:04:16.022 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:04:16 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×24)
  20:04:21.589 [ts-admin-travel-service] 2024-12-07 20:04:21.589 INFO 1 --- [io-16114-exec-6] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×10)
  20:04:21.791 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:04:21 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×11)
  20:04:26.574 [ts-order-other-service] 2024-12-07 20:04:26.574 INFO 1 --- [io-12032-exec-2] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 54  (×2)
  20:04:28.080 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T20:04:28.080+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360186
  20:04:28.930 [ts-travel-service] 2024-12-07 20:04:28.930 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d  (×8)
  20:04:29.946 [ts-basic-service] 2024-12-07 20:04:29.946 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou  (×4)
  20:04:30.195 [ts-travel-service] 2024-12-07 20:04:30.195 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×24)
  20:04:30.735 [ts-contacts-service] 2024-12-07 20:04:30.734 INFO 1 --- [io-12347-exec-7] contacts.controller.ContactsController : [Contacts Service][Find Contacts By Account Id: 4d2a46c7-71cb-4cf1
  20:04:30.786 [ts-security-service] 2024-12-07 20:04:30.786 INFO 1 --- [io-11188-exec-3] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Last One Hour: 21 To  (×2)
  20:04:30.815 [ts-preserve-service] 2024-12-07 20:04:30.815 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Getting....
  20:04:31.013 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T20:04:31.012+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360187
  20:04:31.428 [ts-seat-service] 2024-12-07 20:04:31.427 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Left ticket info is : Response(status=1, msg=Success, data=LeftTicketInfo{so  (×2)
  20:04:31.475 [ts-preserve-service] 2024-12-07 20:04:31.475 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 4] Do Order Complete
  20:04:31.517 [ts-preserve-service] 2024-12-07 20:04:31.517 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service]
  20:04:34.630 [ts-basic-service] 2024-12-07 20:04:34.630 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270  (×4)
  20:04:34.987 [ts-basic-service] 2024-12-07 20:04:34.987 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: aefc
  20:04:42.397 [ts-travel2-service] 2024-12-07 20:04:42.397 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  20:04:43.070 [ts-payment-mongo] {"t":{"$date":"2024-12-07T20:04:43.070+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360188
  20:04:44.486 [ts-preserve-other-service] 2024-12-07 20:04:44.486 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 2] Find contacts
  20:04:44.879 [ts-preserve-other-service] 2024-12-07 20:04:44.879 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Tickets Enough
  20:04:45.121 [ts-order-other-service] 2024-12-07 20:04:45.121 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : [Order Other Service][Order Create] Success.
  20:04:56.800 [ts-travel-service] 2024-12-07 20:04:56.800 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×2)
  20:05:01.887 [ts-order-service] 2024-12-07 20:05:01.887 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-4cf1-
  20:05:12.216 [ts-basic-service] 2024-12-07 20:05:12.216 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×2)

## p0829
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-08T12:15:03.502Z
```
{"timestamp":1733660103502745300,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-4lplk","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:15:03.502  INFO 1 --- [io-11178-exec-1] route.controller.RouteController         : Route id: f3d4d4ef-693b-4456-8eed-59c0d717dd08"}
```
Same service, the 2 minutes before (oldest first):
  12:14:59.286 [ts-route-service] 2024-12-08 12:14:59.285 INFO 1 --- [io-11178-exec-4] route.controller.RouteController : Route id: 20eb7122-3a11-423f-b10a-be0dc5bce7db  (×18)
  12:14:59.939 [ts-route-service] 2024-12-08 12:14:59.939 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: f3d4d4ef-693b-4456-8eed-59c0d717dd08  (×2)
All services, 30 seconds either side (sampled):
  12:14:33.575 [ts-auth-service] 2024-12-08 12:14:33.575 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×8)
  12:14:33.850 [ts-route-service] 2024-12-08 12:14:33.850 INFO 1 --- [io-11178-exec-6] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×212)
  12:14:33.965 [ts-price-service] 2024-12-08 12:14:33.965 INFO 1 --- [io-16579-exec-1] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×13)
  12:14:34.038 [ts-travel2-service] 2024-12-08 12:14:34.037 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sun Dec 08 00:00:00 GMT 2024,   (×6)
  12:14:34.068 [ts-seat-service] 2024-12-08 12:14:34.068 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×10)
  12:14:34.206 [ts-travel2-service] 2024-12-08 12:14:34.206 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×6)
  12:14:37.260 [ts-travel-service] 2024-12-08 12:14:37.260 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×14)
  12:14:37.339 [ts-food-service] 2024-12-08 12:14:37.338 INFO 1 --- [io-18856-exec-7] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!  (×6)
  12:14:45.588 [ts-travel2-service] 2024-12-08 12:14:45.587 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×6)
  12:14:52.016 [ts-order-other-service] 2024-12-08 12:14:52.015 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×3)
  12:14:52.376 [ts-travel-service] 2024-12-08 12:14:52.376 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×3)
  12:14:54.328 [ts-basic-service] 2024-12-08 12:14:54.328 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：92708982-77
  12:14:54.420 [ts-seat-service] 2024-12-08 12:14:54.419 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×9)
  12:14:54.606 [ts-basic-service] 2024-12-08 12:14:54.606 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: aefc
  12:14:55.703 [ts-admin-travel-service] 2024-12-08 12:14:55.702 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×2)
  12:14:59.937 [ts-basic-service] 2024-12-08 12:14:59.936 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×3)
  12:15:00.151 [ts-order-service] 2024-12-08 12:15:00.151 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=625927415, 
  12:15:00.226 [ts-preserve-service] 2024-12-08 12:15:00.226 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security
  12:15:00.263 [ts-security-service] 2024-12-08 12:15:00.263 INFO 1 --- [io-11188-exec-2] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Last One Hour:
  12:15:00.279 [ts-contacts-service] 2024-12-08 12:15:00.278 INFO 1 --- [io-12347-exec-8] contacts.service.ContactsServiceImpl : FIND CONTACTS BY ID: 10fc4588-94c4-4e14-b67c-338ecd236df4
  12:15:00.668 [ts-seat-service] 2024-12-08 12:15:00.667 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes
  12:15:00.724 [ts-preserve-service] 2024-12-08 12:15:00.724 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 4] Do Order
  12:15:00.875 [ts-preserve-service] 2024-12-08 12:15:00.875 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service][Order Price] Price is: 22.5
  12:15:00.894 [ts-preserve-service] 2024-12-08 12:15:00.894 INFO 1 --- [io-14568-exec-7] preserve.service.PreserveServiceImpl : [Preserve Service][Step 6] Do not need to buy food
  12:15:11.653 [ts-travel-mongo] {"t":{"$date":"2024-12-08T12:15:11.653+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366011
  12:15:12.154 [ts-config-mongo] {"t":{"$date":"2024-12-08T12:15:12.153+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366011
  12:15:14.389 [ts-order-service] 2024-12-08 12:15:14.389 INFO 1 --- [io-12031-exec-6] order.service.OrderServiceImpl : [Order Service][Query Order][Step 1] Get Orders Number of Account: 137
  12:15:14.603 [ts-consign-price-mongo] {"t":{"$date":"2024-12-08T12:15:14.602+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366011
  12:15:15.919 [ts-order-service] 2024-12-08 12:15:15.919 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 137
  12:15:25.888 [ts-route-service] Error occurred during initialization of VM

## p0195
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:52:14.995Z
```
{"timestamp":1731912734995142400,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  06:52:14.272 [frontend] adding to cart  (×2)
  06:52:14.282 [frontend] request complete  (×6)
  06:52:14.285 [frontend] request started  (×6)
  06:52:14.285 [frontend] view user cart  (×2)
  06:52:14.356 [frontend] serving product page  (×2)
  06:52:14.443 [frontend] placing order
  06:52:14.479 [frontend] order placed
All services, 30 seconds either side (sampled):
  06:51:45.067 [frontend] request started  (×345)
  06:51:45.074 [cartservice] GetCartAsync called with userId=736a09b5-665e-4823-8520-b8602b0bdbff  (×281)
  06:51:45.096 [shippingservice] [GetQuote] completed request  (×99)
  06:51:45.602 [frontend] setting currency  (×20)
  06:51:45.653 [adservice] received ad request (context_words=[])  (×32)
  06:51:45.869 [adservice] received ad request (context_words=[accessories])  (×35)
  06:51:46.001 [adservice] received ad request (context_words=[kitchen])  (×47)
  06:51:49.572 [frontend] placing order  (×15)
  06:51:49.593 [paymentservice] Transaction processed: visa ending 2959 Amount: TRY590.203288820  (×5)
  06:51:49.596 [shippingservice] [ShipOrder] completed request  (×15)
  06:51:49.607 [checkoutservice] order confirmation email sent to "williamsgregory@example.org"
  06:51:51.232 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"272","nanos":92578499},"credit_card":{"credit_card_number":"414622544930505  (×5)
  06:51:51.246 [checkoutservice] order confirmation email sent to "vanessa27@example.net"
  06:51:51.593 [paymentservice] Transaction processed: visa ending 9328 Amount: CAD1098.302167176
  06:51:52.910 [adservice] received ad request (context_words=[clothing, tops])  (×17)
  06:51:54.980 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="USD"  (×2)
  06:51:55.017 [emailservice] A request to send order confirmation email to mchan@example.com has been received.
  06:52:00.889 [emailservice] A request to send order confirmation email to rebeccacolon@example.org has been received.
  06:52:06.071 [emailservice] A request to send order confirmation email to cindy33@example.com has been received.
  06:52:09.085 [checkoutservice] order confirmation email sent to "lisa88@example.com"
  06:52:13.852 [emailservice] A request to send order confirmation email to pjones@example.net has been received.
  06:52:14.478 [checkoutservice] order confirmation email sent to "rebecca12@example.net"
  06:52:22.591 [paymentservice] Transaction processed: visa ending 5671 Amount: EUR863.989385237
  06:52:26.905 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', 'LS4PSXUNUM']
  06:52:43.596 [emailservice] A request to send order confirmation email to rogeradams@example.com has been received.
  06:52:44.380 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"28162","nanos":434321219},"credit_card":{"credit_card_number":"423703687081
  06:52:44.394 [checkoutservice] order confirmation email sent to "russellpeterson@example.org"

## p0761
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T06:36:29.928Z
```
{"timestamp":1732257389928282400,"container_name":"front-end","pod_name":"front-end-f77549869-mxq2p","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Customer: {\"username\":\"oomfx\",\"password\":\"XKRcnwShlv\",\"email\":\"oomfx@gmail.com\",\"firstName\":\"oomfx\",\"lastName\":\"oomfx\"}"}
```
Same service, the 2 minutes before (oldest first):
  06:36:29.523 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  06:36:29.532 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  06:36:29.532 [front-end] POST to carts: http://carts/carts/67402667768f35000114f2c5/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  06:36:29.590 [front-end] POST /cart 500 65.326 ms - 64
  06:36:29.652 [front-end] Request received with body: {}
  06:36:29.663 [front-end] Received response: "{\"firstName\":\"lCVRQAoMpWbKu\",\"lastName\":\"lCVRQAoMpWbKu\",\"username\":\"lCVRQAoMpWbKu\",\"id\":\"67402657768f35000114f29d\",\"_links\
  06:36:29.663 [front-end] GET Request to: http://user/customers/67402657768f35000114f29d/addresses  (×2)
  06:36:29.673 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67402
  06:36:29.673 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67402660768f35000114f2bd\",\"_links\":{\"
  06:36:29.673 [front-end] [ undefined, undefined ]
  06:36:29.673 [front-end] Posting Order: {"customer":"http://user/customers/67402657768f35000114f29d","address":"http://user/addresses/67402660768f35000114f2bc","card":"http://user/cards
  06:36:29.729 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732257389726,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  06:36:29.729 [front-end] Order response: {"timestamp":1732257389726,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  06:36:29.731 [front-end] POST /orders 500 - ms - -
  06:36:29.830 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67402664768f35000114f2c1"}
  06:36:29.842 [front-end] POST /addresses 200 - ms - -
  06:36:29.850 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67402664768f35000114f2c1"}
  06:36:29.861 [front-end] POST /cards 200 - ms - -
  06:36:29.906 [front-end] Attempting to delete cart for user: 67402664768f35000114f2c1
All services, 30 seconds either side (sampled):
  06:36:00.088 [front-end] Posting Customer: {"username":"xPyjjw","password":"VKKKZtMHah","email":"xPyjjw@gmail.com","firstName":"xPyjjw","lastName":"xPyjjw"}
  06:36:00.374 [user] ts=2024-11-22T06:36:00.373944965Z caller=middlewares.go:46 method=Register username=ccxNplpTJvD email=ccxNplpTJvD@gmail.com took=2.486968ms  (×34)
  06:36:01.026 [front-end] Posting Customer: {"username":"GFDGHAQNB","password":"PLLNcz","email":"GFDGHAQNB@gmail.com","firstName":"GFDGHAQNB","lastName":"GFDGHAQNB"}
  06:36:02.372 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×4)
  06:36:03.008 [front-end] Posting Order: {"customer":"http://user/customers/6740263e768f35000114f251","address":"http://user/addresses/67402645768f35000114f261","card":"http://user/cards  (×60)
  06:36:04.792 [front-end] Received response: "{\"firstName\":\"GhEwFimaROGg\",\"lastName\":\"GhEwFimaROGg\",\"username\":\"GhEwFimaROGg\",\"id\":\"6740263d768f35000114f249\",\"_links\":{
  06:36:08.751 [front-end] Received response: "{\"firstName\":\"GQtIWpeB\",\"lastName\":\"GQtIWpeB\",\"username\":\"GQtIWpeB\",\"id\":\"67402646768f35000114f263\",\"_links\":{\"addresses\
  06:36:14.175 [front-end] Received response: "{\"firstName\":\"vetHfOa\",\"lastName\":\"vetHfOa\",\"username\":\"vetHfOa\",\"id\":\"67402646768f35000114f265\",\"_links\":{\"addresses\":{
  06:36:15.592 [carts] 2024-11-22 06:36:15.592 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}/merge],methods=[GET]}" onto publi
  06:36:18.326 [front-end] Posting Customer: {"username":"UnudfNZcONvPeKl","password":"cvJmjU","email":"UnudfNZcONvPeKl@gmail.com","firstName":"UnudfNZcONvPeKl","lastName":"UnudfNZcONvPeK
  06:36:21.291 [carts] 2024-11-22 06:36:21.290 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/**] onto handler of type [class org.s
  06:36:24.806 [user] ts=2024-11-22T06:36:24.806025955Z caller=middlewares.go:46 method=Register username=uMXWIJl email=uMXWIJl@gmail.com took=2.881647ms
  06:36:31.711 [front-end] Posting Customer: {"username":"XeXhSPvQ","password":"FiKQIAR","email":"XeXhSPvQ@gmail.com","firstName":"XeXhSPvQ","lastName":"XeXhSPvQ"}
  06:36:33.687 [carts] 2024-11-22 06:36:33.686 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[HEAD],produces=[application/hal+json ||
  06:36:33.693 [carts] 2024-11-22 06:36:33.693 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal
  06:36:33.887 [carts] 2024-11-22 06:36:33.886 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[OPTIONS],produces=[appli
  06:36:36.716 [front-end] Received response: "{\"firstName\":\"dCFkcIHMRAivey\",\"lastName\":\"dCFkcIHMRAivey\",\"username\":\"dCFkcIHMRAivey\",\"id\":\"67402661768f35000114f2be\",\"_lin
  06:36:37.991 [carts] 2024-11-22 06:36:37.984 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  06:36:39.359 [front-end] Posting Customer: {"username":"mvtxLxKZ","password":"GBXWIs","email":"mvtxLxKZ@gmail.com","firstName":"mvtxLxKZ","lastName":"mvtxLxKZ"}
  06:36:41.608 [front-end] Posting Customer: {"username":"KGRzDjrSMA","password":"gRwVMaLJ","email":"KGRzDjrSMA@gmail.com","firstName":"KGRzDjrSMA","lastName":"KGRzDjrSMA"}
  06:36:44.890 [carts] 2024-11-22 06:36:44.890 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  06:36:46.065 [user] ts=2024-11-22T06:36:46.065674254Z caller=middlewares.go:46 method=Register username=KzfLt email=KzfLt@gmail.com took=1.745616ms
  06:36:49.275 [front-end] Received response: "{\"firstName\":\"PjpPeaepMvYna\",\"lastName\":\"PjpPeaepMvYna\",\"username\":\"PjpPeaepMvYna\",\"id\":\"67402673768f35000114f2e9\",\"_links\
  06:36:51.924 [user] ts=2024-11-22T06:36:51.924175277Z caller=middlewares.go:46 method=Register username=yymIsxhZQ email=yymIsxhZQ@gmail.com took=3.035993ms
  06:36:54.530 [front-end] Posting Customer: {"username":"bWcnardbgoBc","password":"VfyUhdtKb","email":"bWcnardbgoBc@gmail.com","firstName":"bWcnardbgoBc","lastName":"bWcnardbgoBc"}
  06:36:55.019 [front-end] Order response: {"statusCode":201,"body":{"id":"67402687531af4000701df43","customerId":"6740266e768f35000114f2dc","customer":{"id":null,"firstName":"kFddDixbQqO
  06:36:55.402 [front-end] Order response: {"statusCode":201,"body":{"id":"67402687531af4000701df48","customerId":"6740266e768f35000114f2da","customer":{"id":null,"firstName":"zzhAJquKxRC
  06:36:57.115 [front-end] Received response: "{\"firstName\":\"FWfmnVb\",\"lastName\":\"FWfmnVb\",\"username\":\"FWfmnVb\",\"id\":\"67402678768f35000114f2fb\",\"_links\":{\"addresses\":{
  06:36:58.899 [queue-master] 2024-11-22 06:36:58.899 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×3)

## p0385
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:15.025Z
```
{"timestamp":1732247175025950200,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"statusCode\":500,\"body\":{\"timestamp\":1732247175023,\"status\":500,\"error\":\"Internal Server Error\",\"exception\":\"java.lang.IllegalStateException\",\"message\":\"Unable to create order due to unspecified IO error.\",\"path\":\"/orders\"},\"headers\":{\"x-application-context\":\"orders:80\",\"content-type\":\"application/json;charset=UTF-8\",\"date\":\"Fri, 22 Nov 2024 03:46:14 GMT\",\"x-envoy-upstream-service…"}
```
Same service, the 2 minutes before (oldest first):
  03:46:14.840 [front-end] POST /cart 500 57.487 ms - 64
  03:46:14.842 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732247174839,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:46:14.842 [front-end] Order response: {"timestamp":1732247174839,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:46:14.844 [front-end] POST /orders 500 - ms - -
  03:46:14.946 [front-end] Request received with body: {}  (×2)
  03:46:14.954 [front-end] Received response: "{\"firstName\":\"nytoOYn\",\"lastName\":\"nytoOYn\",\"username\":\"nytoOYn\",\"id\":\"673ffe6bb0df5c00019b3119\",\"_links\":{\"addresses\":{
  03:46:14.954 [front-end] GET Request to: http://user/customers/673ffe6bb0df5c00019b3119/addresses  (×4)
  03:46:14.960 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe73b0df5c00019b3135\",\"_links\":{\"  (×2)
  03:46:14.961 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff  (×2)
  03:46:14.961 [front-end] [ undefined, undefined ]  (×2)
  03:46:14.961 [front-end] Posting Order: {"customer":"http://user/customers/673ffe6bb0df5c00019b3119","address":"http://user/addresses/673ffe73b0df5c00019b3134","card":"http://user/cards  (×2)
  03:46:14.981 [front-end] Received response: "{\"firstName\":\"ynLhnXzGFGSlwdn\",\"lastName\":\"ynLhnXzGFGSlwdn\",\"username\":\"ynLhnXzGFGSlwdn\",\"id\":\"673ffe78b0df5c00019b3142\",\"_
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×19)
  03:46:10.147 [front-end] { id: '673ffe82b0df5c00019b315b' }  (×33)
  03:46:10.189 [front-end] Sent cookies.  (×33)
  03:46:10.811 [front-end] Received response: "{\"firstName\":\"iRQgndFKRWzZ\",\"lastName\":\"iRQgndFKRWzZ\",\"username\":\"iRQgndFKRWzZ\",\"id\":\"673ffe72b0df5c00019b3133\",\"_links\":{
  03:46:10.818 [front-end] [ undefined, undefined ]  (×34)
  03:46:10.848 [orders] 2024-11-22 03:46:10.848 ERROR [orders,,,] 6 --- [-nio-80-exec-12] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×15)
  03:46:10.940 [front-end] Received response: "{\"firstName\":\"jnTZDLVwW\",\"lastName\":\"jnTZDLVwW\",\"username\":\"jnTZDLVwW\",\"id\":\"673ffe65b0df5c00019b3100\",\"_links\":{\"address
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×37)
  03:46:11.285 [front-end] User cart deleted with status: 503  (×37)
  03:46:11.304 [front-end] POST to carts: http://carts/carts/673ffe7bb0df5c00019b3147/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}  (×23)
  03:46:11.500 [catalogue] ts=2024-11-22T03:46:11Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=3.76723m  (×5)
  03:46:12.526 [front-end] Posting Customer: {"username":"YWRstkOr","password":"kgmbhcEA","email":"YWRstkOr@gmail.com","firstName":"YWRstkOr","lastName":"YWRstkOr"}
  03:46:12.669 [orders] 2024-11-22 03:46:12.668 ERROR [orders,,,] 6 --- [p-nio-80-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×19)
  03:46:14.765 [front-end] Received response: "{\"firstName\":\"KxwXfBfUZ\",\"lastName\":\"KxwXfBfUZ\",\"username\":\"KxwXfBfUZ\",\"id\":\"673ffe6fb0df5c00019b3125\",\"_links\":{\"address
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.227 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×7)
  03:46:17.277 [user] ts=2024-11-22T03:46:17.277211334Z caller=middlewares.go:46 method=Register username=ptkQMzQKHy email=ptkQMzQKHy@gmail.com took=1.044122ms  (×7)
  03:46:20.433 [front-end] Received response: "{\"firstName\":\"DHCGNkyEyawp\",\"lastName\":\"DHCGNkyEyawp\",\"username\":\"DHCGNkyEyawp\",\"id\":\"673ffe74b0df5c00019b3136\",\"_links\":{
  03:46:22.962 [user] ts=2024-11-22T03:46:22.961891483Z caller=middlewares.go:46 method=Register username=YNeGDXzX email=YNeGDXzX@gmail.com took=1.087598ms
  03:46:25.988 [front-end] Posting Customer: {"username":"jAAETa","password":"IwsrY","email":"jAAETa@gmail.com","firstName":"jAAETa","lastName":"jAAETa"}
  03:46:26.496 [front-end] Received response: "{\"firstName\":\"gXlVL\",\"lastName\":\"gXlVL\",\"username\":\"gXlVL\",\"id\":\"673ffe80b0df5c00019b3159\",\"_links\":{\"addresses\":{\"href
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.249 [carts-db] {"t":{"$date":"2024-11-22T03:46:29.248+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224718
  03:46:30.113 [front-end] Posting Customer: {"username":"saWqTMkh","password":"METDVZTIFk","email":"saWqTMkh@gmail.com","firstName":"saWqTMkh","lastName":"saWqTMkh"}
  03:46:30.678 [front-end] Received response: "{\"firstName\":\"jwQwxgI\",\"lastName\":\"jwQwxgI\",\"username\":\"jwQwxgI\",\"id\":\"673ffe80b0df5c00019b315a\",\"_links\":{\"addresses\":{
  03:46:32.838 [front-end] Posting Customer: {"username":"ZzayWIHhxNw","password":"FoukoY","email":"ZzayWIHhxNw@gmail.com","firstName":"ZzayWIHhxNw","lastName":"ZzayWIHhxNw"}
  03:46:36.897 [front-end] Posting Customer: {"username":"gOQlBf","password":"ooDdDywNEy","email":"gOQlBf@gmail.com","firstName":"gOQlBf","lastName":"gOQlBf"}
  03:46:39.288 [front-end] Received response: "{\"firstName\":\"YNeGDXzX\",\"lastName\":\"YNeGDXzX\",\"username\":\"YNeGDXzX\",\"id\":\"673ffe8eb0df5c00019b3183\",\"_links\":{\"addresses\
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:42.361 [front-end] Received response: "{\"firstName\":\"UKKtCDfOtWIPTP\",\"lastName\":\"UKKtCDfOtWIPTP\",\"username\":\"UKKtCDfOtWIPTP\",\"id\":\"673ffe90b0df5c00019b3186\",\"_lin

## p0807
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-08T09:15:57.503Z
```
{"timestamp":1733649357503573000,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-gwfvc","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 09:15:57.502  INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl       : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Internal Success, data=1073741823)"}
```
Same service, the 2 minutes before (oldest first):
  09:15:53.342 [ts-travel2-service] 2024-12-08 09:15:53.342 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×7)
  09:15:53.347 [ts-travel2-service] 2024-12-08 09:15:53.346 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×7)
  09:15:57.305 [ts-travel2-service] 2024-12-08 09:15:57.305 INFO 1 --- [io-16346-exec-1] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  09:15:57.410 [ts-travel2-service] 2024-12-08 09:15:57.410 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  09:15:57.418 [ts-travel2-service] 2024-12-08 09:15:57.418 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  09:15:57.453 [ts-travel2-service] 2024-12-08 09:15:57.452 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sun Dec 08 00:00:00 GMT 2024, 
  09:15:57.461 [ts-travel2-service] 2024-12-08 09:15:57.460 INFO 1 --- [io-16346-exec-6] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236
  09:15:57.471 [ts-travel2-service] 2024-12-08 09:15:57.471 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
All services, 30 seconds either side (sampled):
  09:15:29.873 [ts-food-service] 2024-12-08 09:15:29.873 INFO 1 --- [io-18856-exec-1] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×4)
  09:15:30.952 [ts-auth-service] 2024-12-08 09:15:30.951 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  09:15:31.168 [ts-route-service] 2024-12-08 09:15:31.168 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: d693a2c5-ef87-4a3c-bef8-600b43f62c68  (×15)
  09:15:31.216 [ts-price-service] 2024-12-08 09:15:31.215 INFO 1 --- [io-16579-exec-4] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×16)
  09:15:31.246 [ts-travel2-service] 2024-12-08 09:15:31.245 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×11)
  09:15:31.340 [ts-seat-service] 2024-12-08 09:15:31.340 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×15)
  09:15:31.438 [ts-travel-service] 2024-12-08 09:15:31.438 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×5)
  09:15:31.801 [ts-auth-service] 2024-12-08 09:15:31.799 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  09:15:32.590 [ts-admin-basic-info-service] 2024-12-08 09:15:32.590 INFO 1 --- [io-18767-exec-6] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×12)
  09:15:33.233 [ts-basic-service] 2024-12-08 09:15:33.232 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×6)
  09:15:33.411 [ts-travel2-service] 2024-12-08 09:15:33.411 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  09:15:40.445 [ts-order-other-service] 2024-12-08 09:15:40.444 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×2)
  09:15:49.601 [ts-travel-service] 2024-12-08 09:15:49.600 INFO 1 --- [io-12346-exec-6] travel.controller.TravelController : [Travel Service] Query TripResponse  (×3)
  09:15:49.716 [ts-order-service] 2024-12-08 09:15:49.716 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×5)
  09:15:49.904 [ts-travel-service] 2024-12-08 09:15:49.904 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×6)
  09:15:50.144 [ts-travel-service] 2024-12-08 09:15:50.144 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：a3f256c1-0e43-4f7d-9c21-121bf  (×2)
  09:15:54.593 [ts-auth-service] 2024-12-08 09:15:54.593 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def  (×2)
  09:15:57.387 [ts-basic-service] 2024-12-08 09:15:57.387 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×4)
  09:16:01.724 [ts-basic-service] 2024-12-08 09:16:01.723 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe
  09:16:02.591 [ts-auth-service] 2024-12-08 09:16:02.590 INFO 1 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext  (×2)
  09:16:07.387 [ts-auth-service] 2024-12-08 09:16:07.387 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip
  09:16:10.140 [ts-order-other-service] 2024-12-08 09:16:10.140 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×2)
  09:16:11.861 [ts-price-mongo] {"t":{"$date":"2024-12-08T09:16:11.861+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364937
  09:16:15.979 [ts-auth-service] 2024-12-08 09:16:15.897 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users],methods=[GET]}" onto public org.springframework.h
  09:16:18.386 [ts-auth-service] 2024-12-08 09:16:18.385 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[application/vnd.sprin
  09:16:18.391 [ts-auth-service] 2024-12-08 09:16:18.391 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  09:16:20.977 [ts-travel2-service] 2024-12-08 09:16:20.977 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  09:16:21.903 [ts-basic-service] 2024-12-08 09:16:21.903 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4
  09:16:24.280 [ts-auth-service] 2024-12-08 09:16:24.280 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : Adding {logging-channel-adapter:_org.springframework.integration.errorLogger} as

## p0820
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-admin-basic-info-service, 2024-12-10T13:27:38.042Z
```
{"timestamp":1733837258042187500,"container_name":"ts-admin-basic-info-service","pod_name":"ts-admin-basic-info-service-87bf97b79-2gh44","node_name":"ip-192-168-64-253.ap-southeast-2.compute.internal","message":"2024-12-10 13:27:38.041 ERROR 1 --- [io-18767-exec-6] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception\n"}
```
Same service, the 2 minutes before (oldest first):
  13:27:15.744 [ts-admin-basic-info-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×7)
  13:27:19.754 [ts-admin-basic-info-service] 2024-12-10 13:27:19.754 ERROR 1 --- [io-18767-exec-8] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×6)
  13:27:19.755 [ts-admin-basic-info-service] 2024-12-10 13:27:19.755 ERROR 1 --- [io-18767-exec-8] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×5)
  13:27:21.040 [ts-admin-basic-info-service] 2024-12-10 13:27:21.040 ERROR 1 --- [o-18767-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  13:27:21.041 [ts-admin-basic-info-service] 2024-12-10 13:27:21.041 ERROR 1 --- [o-18767-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
All services, 30 seconds either side (sampled):
  13:27:08.348 [ts-admin-basic-info-service] 2024-12-10 13:27:08.347 ERROR 1 --- [io-18767-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×20)
  13:27:08.351 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:08 +0800] "GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×12)
  13:27:09.625 [ts-auth-service] 2024-12-10 13:27:09.625 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×22)
  13:27:09.641 [ts-travel2-service] 2024-12-10 13:27:09.641 ERROR 1 --- [o-16346-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  13:27:09.644 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:09 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 500 228 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×13)
  13:27:10.732 [ts-admin-travel-service] 2024-12-10 13:27:10.732 ERROR 1 --- [io-16114-exec-7] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×11)
  13:27:10.736 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:10 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 500 233 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×12)
  13:27:11.950 [ts-order-mongo] {"t":{"$date":"2024-12-10T13:27:11.950+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:12.151 [ts-assurance-mongo] {"t":{"$date":"2024-12-10T13:27:12.150+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:12.457 [ts-order-other-mongo] {"t":{"$date":"2024-12-10T13:27:12.456+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:12.482 [ts-order-other-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  13:27:12.650 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-10T13:27:12.650+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:12.819 [ts-notification-mongo] {"t":{"$date":"2024-12-10T13:27:12.819+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:13.326 [ts-security-mongo] {"t":{"$date":"2024-12-10T13:27:13.326+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:13.347 [ts-price-mongo] {"t":{"$date":"2024-12-10T13:27:13.346+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:15.045 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-10T13:27:15.045+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:15.213 [ts-consign-mongo] {"t":{"$date":"2024-12-10T13:27:15.213+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383723
  13:27:15.543 [ts-food-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×4)
  13:27:20.497 [ts-auth-service] 2024-12-10 13:27:20.497 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  13:27:20.714 [ts-auth-service] 2024-12-10 13:27:20.714 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×3)
  13:27:21.742 [ts-order-service] 2024-12-10 13:27:21.742 ERROR 1 --- [io-12031-exec-8] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  13:27:21.747 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:21 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 500 229 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Apple
  13:27:41.459 [ts-travel-service] 2024-12-10 13:27:41.458 ERROR 1 --- [io-12346-exec-1] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  13:27:41.462 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:41 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 500 227 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe

## p0073
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T09:12:47.438Z
```
{"service":"dbservice1","message":"2021-08-13 09:12:47,438 | INFO | 0.0.0.4 | dbservice1 | permission_operate.py -> permission_operation -> 35 | b77883f6bad2ecb2 | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  09:12:37.961 [dbservice1] INFO query = select passwards from username_table where user_name='qjaJKARf'  (×5)
  09:12:37.965 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  09:12:37.966 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  09:12:38.038 [dbservice1] INFO 8c0f69c0-fbd3-11eb-96a8-0242ac110003-qjaJKARf-$Vx*EY-<9!bz token generate success token=MTYyODgxNzE1OC4wMzgxNTQxOjhjMGY2OWMwLWZiZDMtMTFlYi05NmE4LTAyNDJhYzE
  09:12:38.068 [dbservice1] INFO 8c24cbbc-fbd3-11eb-a17e-0242ac110003-uiZfvcTY-6xlZ>er?yf*z token generate success token=MTYyODgxNzE1OC4wNjc4NTU2OjhjMjRjYmJjLWZiZDMtMTFlYi1hMTdlLTAyNDJhYzE
  09:12:39.703 [dbservice1] INFO 8d1b95dc-fbd3-11eb-a53e-0242ac110004-laVNGIPf-{Z8wE?(U^nzJ token generate success token=MTYyODgxNzE1OS43MDI4ODQ3OjhkMWI5NWRjLWZiZDMtMTFlYi1hNTNlLTAyNDJhYzE
  09:12:43.486 [dbservice1] INFO 8f70ce10-fbd3-11eb-87d6-0242ac110004-suCOBkmp-=SHq@W8nJ7Me token generate success token=MTYyODgxNzE2My40ODU3MjE4OjhmNzBjZTEwLWZiZDMtMTFlYi04N2Q2LTAyNDJhYzE
  09:12:45.203 [dbservice1] INFO 906457c4-fbd3-11eb-8958-0242ac110004-CyDlcYMP-RIuS(51-$4.P token generate success token=MTYyODgxNzE2NS4yMDI2OTczOjkwNjQ1N2M0LWZiZDMtMTFlYi04OTU4LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  09:12:17.488 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  09:12:17.671 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '802d6b8e-fbd3-11eb-af8b-0242ac110003', 'value': 'IAqgbwQB'}  (×49)
  09:12:17.781 [logservice1] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': '8021ee62-fbd3-11eb-811b-0242ac110004', 'user_id': 'FKekGBJU'}  (×84)
  09:12:17.925 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×46)
  09:12:18.219 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×44)
  09:12:18.594 [mobservice2] INFO info 80c71fd6-fbd3-11eb-ab1d-0242ac110004:ZzmSOCgj write success  (×2)
  09:12:19.769 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×35)
  09:12:20.342 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '820b3508-fbd3-11eb-a2e3-0242ac110003', 'value': '', 'ex': 10}  (×40)
  09:12:21.146 [dbservice2] INFO 820b3508-fbd3-11eb-a2e3-0242ac110003-OURXjiIJ-5Jn{CRus!OS: token generate success token=MTYyODgxNzE0MS4xNDYwMzc4OjgyMGIzNTA4LWZiZDMtMTFlYi1hMmUzLTAyNDJhYzE
  09:12:23.615 [dbservice1] INFO 8393f2de-fbd3-11eb-a858-0242ac110004-MGhzxsST-cYbH0S^hJFm* token generate success token=MTYyODgxNzE0My42MTQ2MTg4OjgzOTNmMmRlLWZiZDMtMTFlYi1hODU4LTAyNDJhYzE
  09:12:26.592 [dbservice1] INFO 852fcd3e-fbd3-11eb-b3f6-0242ac110003-yQDVrgJw-@}*Q:bp)gm/& token generate success token=MTYyODgxNzE0Ni41OTE2NTQ1Ojg1MmZjZDNlLWZiZDMtMTFlYi1iM2Y2LTAyNDJhYzE
  09:12:29.135 [mobservice1] INFO info 87048fa0-fbd3-11eb-b9bd-0242ac110003:lrWJDxNP write success
  09:12:31.994 [mobservice2] INFO info 88b6c80e-fbd3-11eb-ab63-0242ac110004:jInFtBJp write success
  09:12:34.510 [dbservice1] INFO 8a00b09e-fbd3-11eb-9099-0242ac110004-laBJUtSP-E8m<2RIzvG_e token generate success token=MTYyODgxNzE1NC41MTAyMDY6OGEwMGIwOWUtZmJkMy0xMWViLTkwOTktMDI0MmFjMTE
  09:12:37.142 [dbservice1] INFO 8b8cc02e-fbd3-11eb-a162-0242ac110004-kWcbAndl-+K)#TtAh_eL$ token generate success token=MTYyODgxNzE1Ny4xNDI0MTE6OGI4Y2MwMmUtZmJkMy0xMWViLWExNjItMDI0MmFjMTE
  09:12:40.092 [mobservice1] INFO info 8d9fbae2-fbd3-11eb-a49b-0242ac110004:aejQpHvi write success
  09:12:41.929 [dbservice2] INFO 8e8bf506-fbd3-11eb-9a0e-0242ac110003-vfxYGPRM-*!fkZnj8N{}6 token generate success token=MTYyODgxNzE2MS45Mjg5OTE4OjhlOGJmNTA2LWZiZDMtMTFlYi05YTBlLTAyNDJhYzE
  09:12:44.266 [dbservice2] INFO 8fd6cb84-fbd3-11eb-a769-0242ac110003-NWUBeIdk-FGOw@=Id6nPZ token generate success token=MTYyODgxNzE2NC4yNjYzMDA0OjhmZDZjYjg0LWZiZDMtMTFlYi1hNzY5LTAyNDJhYzE
  09:12:47.857 [mobservice1] INFO info 92499dba-fbd3-11eb-9e30-0242ac110004:kmlOKZGI write success
  09:12:50.163 [mobservice1] INFO info 939b495c-fbd3-11eb-8759-0242ac110003:lmvshOqT write success
  09:12:52.667 [mobservice1] INFO info 951ab0ba-fbd3-11eb-add1-0242ac110003:TFaxVQiG write success
  09:12:55.133 [mobservice2] INFO info 96894ad8-fbd3-11eb-bd26-0242ac110003:iBxJIdNQ write success
  09:12:57.754 [dbservice1] INFO 97e15344-fbd3-11eb-a511-0242ac110003-WYjcLizJ-pZYv_kf^:i!E token generate success token=MTYyODgxNzE3Ny43NTQwMDM1Ojk3ZTE1MzQ0LWZiZDMtMTFlYi1hNTExLTAyNDJhYzE
  09:13:00.735 [mobservice1] INFO info 99eb1404-fbd3-11eb-9b6f-0242ac110003:ydgXkaYo write success
  09:13:03.818 [dbservice1] INFO 9b450828-fbd3-11eb-9d1b-0242ac110003-WyKqhlJd-S5&.)N$_Qvw> token generate success token=MTYyODgxNzE4My44MTg0MTc1OjliNDUwODI4LWZiZDMtMTFlYi05ZDFiLTAyNDJhYzE
  09:13:09.060 [mobservice2] INFO info 9ed89ea0-fbd3-11eb-b9fc-0242ac110004:nfPDGSVr write success
  09:13:15.997 [dbservice1] INFO a2c564ee-fbd3-11eb-b536-0242ac110004-ckaGqjZH-{HR_>mq&f6Nx token generate success token=MTYyODgxNzE5NS45OTc1NzYyOmEyYzU2NGVlLWZiZDMtMTFlYi1iNTM2LTAyNDJhYzE

## p0743
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-23T12:54:21.914Z
```
{"timestamp":1732366461914306300,"container_name":"frontend","pod_name":"frontend-588fbcd66b-ssq9c","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"request error"}
```
Same service, the 2 minutes before (oldest first):
  12:54:21.425 [frontend] home  (×2)
  12:54:21.454 [frontend] ENV_PLATFORM is: aws
  12:54:21.458 [frontend] request complete  (×5)
  12:54:21.653 [frontend] request started  (×6)
  12:54:21.653 [frontend] view user cart  (×2)
  12:54:21.787 [frontend] serving product page
  12:54:21.822 [frontend] adding to cart
  12:54:21.883 [frontend] placing order
  12:54:21.883 [frontend] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
All services, 30 seconds either side (sampled):
  12:53:51.918 [emailservice] A request to send order confirmation email to michael04@example.com has been received.
  12:53:51.927 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', 'OLJCESPC7Z', 'LS4PSXUNUM', '9SIQT8TOJO', '0PUK6V6EV0']  (×223)
  12:53:52.227 [frontend] request started  (×325)
  12:53:52.236 [currencyservice] conversion request successful  (×722)
  12:53:52.635 [adservice] received ad request (context_words=[footwear])  (×14)
  12:53:52.653 [frontend] view user cart  (×66)
  12:53:52.696 [frontend] placing order  (×12)
  12:53:52.724 [paymentservice] Transaction processed: visa ending 1497 Amount: USD378.370000000  (×2)
  12:53:52.729 [shippingservice] [ShipOrder] completed request  (×11)
  12:53:52.740 [checkoutservice] order confirmation email sent to "mariahzuniga@example.com"
  12:53:53.152 [adservice] received ad request (context_words=[clothing, tops])  (×21)
  12:53:53.958 [frontend] ENV_PLATFORM is: aws  (×34)
  12:53:55.057 [redis] 1:M 23 Nov 2024 12:53:55.056 * Background saving started by pid 32
  12:53:55.111 [adservice] received ad request (context_words=[hair, beauty])  (×14)
  12:53:55.205 [checkoutservice] order confirmation email sent to "brent81@example.net"
  12:53:55.800 [paymentservice] Transaction processed: visa ending 4849 Amount: EUR131.729323311  (×3)
  12:53:57.531 [checkoutservice] [PlaceOrder] user_id="706f37f6-1c4e-4686-b19d-4ff2d2c889ad" user_currency="GBP"  (×2)
  12:53:57.561 [emailservice] A request to send order confirmation email to jimmylowe@example.org has been received.
  12:54:08.026 [emailservice] A request to send order confirmation email to cartertheresa@example.org has been received.
  12:54:14.122 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"152175","nanos":313579492},"credit_card":{"credit_card_number":"42833216059  (×3)
  12:54:14.136 [checkoutservice] order confirmation email sent to "tracy54@example.org"
  12:54:16.618 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"698","nanos":502937650},"credit_card":{"credit_card_number":"44377804832301
  12:54:16.632 [checkoutservice] order confirmation email sent to "julie54@example.com"
  12:54:21.908 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  12:54:22.123 [checkoutservice] [PlaceOrder] user_id="931a1dee-a1ff-459e-84f4-7a7d7e884cd2" user_currency="CAD"
  12:54:22.149 [emailservice] A request to send order confirmation email to paulskinner@example.net has been received.
  12:54:41.548 [checkoutservice] order confirmation email sent to "zgarner@example.com"
  12:54:48.896 [emailservice] A request to send order confirmation email to websterchristopher@example.org has been received.

## p0079
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T12:55:19.503Z
```
{"service":"dbservice1","message":"2021-08-13 12:55:19,503 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | ccfc6d6c9d22d929 | a828d5dc-fbf2-11eb-9c18-0242ac110004-vaHXLtfK-J{}mY-&CAUgk token generate success token=MTYyODgzMDUxOS41MDMzNzA4OmE4MjhkNWRjLWZiZjItMTFlYi05YzE4LTAyNDJhYzExMDAwNHZhSFhMdGZLSnt9bVktJkNBVWdrOjE2Mjg4MzA1NzkuNTAzMzgxNToxOWUyMWZhMmM5MmUyYTE1MmUyMmEzZDFjYmM5YjgyOQ=="}
```
Same service, the 2 minutes before (oldest first):
  12:55:14.715 [dbservice1] INFO a5644ed0-fbf2-11eb-b0d8-0242ac110003-vaHXLtfK-J{}mY-&CAUgk token generate success token=MTYyODgzMDUxNC43MTUzMDI3OmE1NjQ0ZWQwLWZiZjItMTFlYi1iMGQ4LTAyNDJhYzE
  12:55:16.106 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  12:55:16.106 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  12:55:16.121 [dbservice1] INFO query = select passwards from username_table where user_name='IcmKxDtR'  (×5)
  12:55:16.252 [dbservice1] INFO a642e0dc-fbf2-11eb-b285-0242ac110004-IcmKxDtR-(sNA2Lk}!7uX token generate success token=MTYyODgzMDUxNi4yNTI1NzE2OmE2NDJlMGRjLWZiZjItMTFlYi1iMjg1LTAyNDJhYzE
  12:55:16.345 [dbservice1] INFO a652e338-fbf2-11eb-96ba-0242ac110003-QNgzxusO-msv)gRlMu=0. token generate success token=MTYyODgzMDUxNi4zNDU1ODc1OmE2NTJlMzM4LWZiZjItMTFlYi05NmJhLTAyNDJhYzE
  12:55:17.796 [dbservice1] INFO a7367b0c-fbf2-11eb-9ffa-0242ac110004-MutpDRNv-Bg}e7&n3q/j+ token generate success token=MTYyODgzMDUxNy43OTYxNDY0OmE3MzY3YjBjLWZiZjItMTFlYi05ZmZhLTAyNDJhYzE
  12:55:19.229 [dbservice1] INFO a804dab0-fbf2-11eb-969a-0242ac110004-nfPDGSVr-sB^m$N*}!Tf1 token generate success token=MTYyODgzMDUxOS4yMjg2MzQ0OmE4MDRkYWIwLWZiZjItMTFlYi05NjlhLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  12:54:49.507 [webservice2] INFO complete information: {'uuid': '96ab461e-fbf2-11eb-bd06-0242ac110004', 'user_id': 'rBRUpNGT'}  (×41)
  12:54:49.682 [redisservice1] INFO redis write success  (×86)
  12:54:49.822 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '96ab461e-fbf2-11eb-bd06-0242ac110004', 'user_id': 'rBRUpNGT'}  (×81)
  12:54:50.005 [dbservice2] INFO 96ab461e-fbf2-11eb-bd06-0242ac110004-rBRUpNGT-X#yR8U%07q5( token generate success token=MTYyODgzMDQ5MC4wMDQ3MjY6OTZhYjQ2MWUtZmJmMi0xMWViLWJkMDYtMDI0MmFjMTE
  12:54:50.374 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×39)
  12:54:50.655 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×40)
  12:54:51.133 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '978ef3fa-fbf2-11eb-ba89-0242ac110004', 'value': 'fFkndIOY'}  (×39)
  12:54:52.139 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×38)
  12:54:53.566 [mobservice2] INFO info 98fa250c-fbf2-11eb-ab77-0242ac110004:tbBdwIhl write success
  12:54:55.455 [dbservice2] INFO 99ee0bfe-fbf2-11eb-af72-0242ac110003-wpiyObsr-WJ.&AIR!3rPn token generate success token=MTYyODgzMDQ5NS40NTUyMDQyOjk5ZWUwYmZlLWZiZjItMTFlYi1hZjcyLTAyNDJhYzE
  12:54:58.017 [dbservice1] INFO 9b6e326a-fbf2-11eb-ab5d-0242ac110004-wYjKshxZ-pi?8Y%r*o7nJ token generate success token=MTYyODgzMDQ5OC4wMTY5NDE1OjliNmUzMjZhLWZiZjItMTFlYi1hYjVkLTAyNDJhYzE
  12:55:00.476 [dbservice1] INFO 9cdfc032-fbf2-11eb-8624-0242ac110004-BrtsWueY-U<o(drDvlHsR token generate success token=MTYyODgzMDUwMC40NzYwMDk4OjljZGZjMDMyLWZiZjItMTFlYi04NjI0LTAyNDJhYzE
  12:55:03.896 [dbservice2] INFO 9ebb5b28-fbf2-11eb-bc8e-0242ac110004-lyRPLEHD-<.x92hGQ1Zm! token generate success token=MTYyODgzMDUwMy44OTU5NDIyOjllYmI1YjI4LWZiZjItMTFlYi1iYzhlLTAyNDJhYzE
  12:55:13.172 [dbservice2] INFO a47baf9a-fbf2-11eb-979c-0242ac110004-ERSdWpfg-}+z_vs-*ICuQ token generate success token=MTYyODgzMDUxMy4xNzE5NzA2OmE0N2JhZjlhLWZiZjItMTFlYi05NzljLTAyNDJhYzE
  12:55:15.120 [mobservice2] INFO info a5d8b1ee-fbf2-11eb-bc46-0242ac110003:LeQUvMXs write success
  12:55:17.420 [mobservice2] INFO info a7367b0c-fbf2-11eb-9ffa-0242ac110004:MutpDRNv write success
  12:55:20.689 [mobservice1] INFO info a9245484-fbf2-11eb-9b68-0242ac110003:Qygqzmel write success
  12:55:23.297 [mobservice2] INFO info aab666ac-fbf2-11eb-a17e-0242ac110004:ToeLCkHR write success
  12:55:26.109 [dbservice1] INFO ac28e7ee-fbf2-11eb-b0e8-0242ac110004-UlXetfSn-i#KQO@L$Ef9X token generate success token=MTYyODgzMDUyNi4xMDkxMzU2OmFjMjhlN2VlLWZiZjItMTFlYi1iMGU4LTAyNDJhYzE
  12:55:28.537 [dbservice1] INFO ad9bc704-fbf2-11eb-8051-0242ac110003-PYaoLpfS-bW9F%P+AUv_Q token generate success token=MTYyODgzMDUyOC41MzcxNjIzOmFkOWJjNzA0LWZiZjItMTFlYi04MDUxLTAyNDJhYzE
  12:55:31.348 [dbservice2] INFO af334970-fbf2-11eb-9709-0242ac110003-jyDKkYiT-TZobU^va5MEt token generate success token=MTYyODgzMDUzMS4zNDgxMDQyOmFmMzM0OTcwLWZiZjItMTFlYi05NzA5LTAyNDJhYzE
  12:55:33.838 [dbservice2] INFO b0c4cb24-fbf2-11eb-99be-0242ac110004-lrWJDxNP-9E/>y3K^Vtz* token generate success token=MTYyODgzMDUzMy44Mzc1OTAyOmIwYzRjYjI0LWZiZjItMTFlYi05OWJlLTAyNDJhYzE
  12:55:36.393 [dbservice2] INFO b246c8bc-fbf2-11eb-9b6c-0242ac110003-GtoYwjTK-f!Aq7{}_JxO# token generate success token=MTYyODgzMDUzNi4zOTMxODIzOmIyNDZjOGJjLWZiZjItMTFlYi05YjZjLTAyNDJhYzE
  12:55:38.887 [mobservice2] INFO info b3f3bbca-fbf2-11eb-a6d6-0242ac110003:sJSHvCwD write success  (×2)
  12:55:41.507 [mobservice2] INFO info b58d2fa2-fbf2-11eb-8855-0242ac110004:KaeOhoMc write success
  12:55:43.974 [mobservice1] INFO info b708f596-fbf2-11eb-af72-0242ac110004:RvaUsgNC write success
  12:55:47.150 [mobservice1] INFO info b8e7df44-fbf2-11eb-a0b2-0242ac110004:MGhzxsST write success

## p0309
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-22T03:20:21.040Z
```
{"timestamp":1732245621040632800,"container_name":"orders","pod_name":"orders-5fd66f9688-2x7kx","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-22 03:20:21.040 ERROR [orders,,,] 6 --- [p-nio-80-exec-7] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalStateException: Unable to create order due to unspecified IO error.] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  03:20:14.642 [orders] 2024-11-22 03:20:14.641 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×4)
  03:20:14.642 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×10)
  03:20:15.115 [orders] 2024-11-22 03:20:15.115 ERROR [orders,,,] 6 --- [p-nio-80-exec-9] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×6)
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×29)
  03:20:06.543 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff  (×46)
  03:20:06.590 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245606587,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×46)
  03:20:06.664 [user] ts=2024-11-22T03:20:06.664037694Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff861b0df5c00019b1e9e took=1.670187ms  (×46)
  03:20:06.789 [front-end] POST to carts: http://carts/carts/673ff861b0df5c00019b1e9e/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}  (×12)
  03:20:06.949 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×3)
  03:20:08.469 [front-end] Posting Customer: {"username":"HNCLfJfsnW","password":"sSvsy","email":"HNCLfJfsnW@gmail.com","firstName":"HNCLfJfsnW","lastName":"HNCLfJfsnW"}
  03:20:08.498 [front-end] set cookie673ff868b0df5c00019b1eb9  (×39)
  03:20:09.096 [front-end] Received response: "{\"firstName\":\"IfuCg\",\"lastName\":\"IfuCg\",\"username\":\"IfuCg\",\"id\":\"673ff851b0df5c00019b1e79\",\"_links\":{\"addresses\":{\"href
  03:20:09.910 [front-end] Posting Customer: {"username":"uQhCpCJIyYL","password":"dElvDjn","email":"uQhCpCJIyYL@gmail.com","firstName":"uQhCpCJIyYL","lastName":"uQhCpCJIyYL"}
  03:20:11.559 [user] ts=2024-11-22T03:20:11.558844653Z caller=middlewares.go:46 method=Register username=xQhxkcD email=xQhxkcD@gmail.com took=1.123618ms
  03:20:14.239 [front-end] Posting Customer: {"username":"burOTnWrVFcFcR","password":"JMCDouKzn","email":"burOTnWrVFcFcR@gmail.com","firstName":"burOTnWrVFcFcR","lastName":"burOTnWrVFcFcR
  03:20:16.376 [front-end] Posting Customer: {"username":"zCHyJV","password":"DBVYLG","email":"zCHyJV@gmail.com","firstName":"zCHyJV","lastName":"zCHyJV"}
  03:20:18.305 [front-end] Received response: "{\"firstName\":\"SxecnNeiPQ\",\"lastName\":\"SxecnNeiPQ\",\"username\":\"SxecnNeiPQ\",\"id\":\"673ff861b0df5c00019b1e9f\",\"_links\":{\"addr
  03:20:20.952 [user] ts=2024-11-22T03:20:20.951976065Z caller=middlewares.go:46 method=Register username=tJMqzAgJI email=tJMqzAgJI@gmail.com took=1.117996ms
  03:20:24.692 [carts] 2024-11-22 03:20:24.692 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  03:20:28.055 [front-end] Received response: "{\"firstName\":\"ihYowTIIUzglApd\",\"lastName\":\"ihYowTIIUzglApd\",\"username\":\"ihYowTIIUzglApd\",\"id\":\"673ff86bb0df5c00019b1ec4\",\"_
  03:20:30.097 [front-end] Posting Customer: {"username":"dStkYebBky","password":"aPZcljShz","email":"dStkYebBky@gmail.com","firstName":"dStkYebBky","lastName":"dStkYebBky"}
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.372 [front-end] Received response: "{\"firstName\":\"CBhyKd\",\"lastName\":\"CBhyKd\",\"username\":\"CBhyKd\",\"id\":\"673ff869b0df5c00019b1eba\",\"_links\":{\"addresses\":{\"h
  03:20:36.743 [front-end] Received response: "{\"firstName\":\"UzagwCTnbpaXVzA\",\"lastName\":\"UzagwCTnbpaXVzA\",\"username\":\"UzagwCTnbpaXVzA\",\"id\":\"673ff86fb0df5c00019b1ed4\",\"_
  03:20:38.171 [session-db] 1:M 22 Nov 2024 03:20:38.171 * Background saving terminated with success
  03:20:41.176 [front-end] Received response: "{\"firstName\":\"dpZIGojLodgB\",\"lastName\":\"dpZIGojLodgB\",\"username\":\"dpZIGojLodgB\",\"id\":\"673ff87bb0df5c00019b1efc\",\"_links\":{
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  03:20:43.391 [carts] 2024-11-22 03:20:43.391 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:20:47.926 [front-end] Posting Customer: {"username":"XYDErsNhuY","password":"RuOOlZc","email":"XYDErsNhuY@gmail.com","firstName":"XYDErsNhuY","lastName":"XYDErsNhuY"}
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/browser/**] onto handler of type [class org.sp

## p0206
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:01:22.582Z
```
{"timestamp":1731913282582012200,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  07:01:20.841 [frontend] request started  (×6)
  07:01:20.841 [frontend] home
  07:01:20.843 [frontend] request complete  (×7)
  07:01:20.846 [frontend] adding to cart
  07:01:20.850 [frontend] serving product page  (×3)
  07:01:20.857 [frontend] view user cart
  07:01:20.911 [frontend] ENV_PLATFORM is: aws
All services, 30 seconds either side (sampled):
  07:00:52.584 [currencyservice] conversion request successful  (×744)
  07:00:52.893 [frontend] serving product page  (×143)
  07:00:52.914 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', 'OLJCESPC7Z', '0PUK6V6EV0', '6E92ZMYYFZ', '2ZYFJ3GM2N']  (×218)
  07:00:53.037 [adservice] received ad request (context_words=[clothing, tops])  (×11)
  07:00:54.058 [frontend] adding to cart  (×32)
  07:00:54.094 [shippingservice] [GetQuote] received request  (×85)
  07:00:56.518 [frontend] home  (×37)
  07:00:57.185 [adservice] received ad request (context_words=[decor, home])  (×17)
  07:00:57.844 [emailservice] Traceback (most recent call last): File "/email_server/email_server.py", line 199, in <module> start(dummy_mode = True) File "/email_server/email_server.py", li  (×2)
  07:01:03.592 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="EUR"  (×7)
  07:01:03.623 [checkoutservice] payment went through (transaction_id: cd3412f9-a893-4594-afe8-8c44626a3b78)  (×13)
  07:01:03.628 [cartservice] EmptyCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×13)
  07:01:03.634 [frontend] order placed  (×13)
  07:01:09.256 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"5251","nanos":665634788},"credit_card":{"credit_card_number":"4380362476687  (×4)
  07:01:11.752 [checkoutservice] [PlaceOrder] user_id="fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a" user_currency="USD"  (×2)
  07:01:11.793 [checkoutservice] failed to send order confirmation to "courtney92@example.com": rpc error: code = Unavailable desc = no healthy upstream
  07:01:15.082 [redis] 1:M 18 Nov 2024 07:01:15.081 * 100 changes in 300 seconds. Saving...
  07:01:15.087 [redis] 70:C 18 Nov 2024 07:01:15.087 * Fork CoW for RDB: current 0 MB, peak 0 MB, average 0 MB
  07:01:24.304 [checkoutservice] failed to send order confirmation to "warnerkatrina@example.org": rpc error: code = Unavailable desc = upstream connect error or disconnect/reset before headers
  07:01:35.228 [checkoutservice] failed to send order confirmation to "cgomez@example.org": rpc error: code = Unavailable desc = no healthy upstream
  07:01:48.392 [checkoutservice] failed to send order confirmation to "ronald53@example.org": rpc error: code = Unavailable desc = no healthy upstream

## p0384
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:46:14.671Z
```
{"timestamp":1732247174671433700,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:46:14.671209446Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffe7eb0df5c00019b3155 took=1.6814ms"}
```
Same service, the 2 minutes before (oldest first):
  03:46:12.096 [user] ts=2024-11-22T03:46:12.095372357Z caller=middlewares.go:157 method=Health result=2 took=1.005228ms  (×2)
  03:46:12.141 [user] ts=2024-11-22T03:46:12.141108416Z caller=middlewares.go:46 method=Register username=VaPxY email=VaPxY@gmail.com took=1.01883ms
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:12.601 [user] ts=2024-11-22T03:46:12.600878168Z caller=middlewares.go:75 method=GetUsers id=673ffe71b0df5c00019b312f result=1 took=950.28µs  (×6)
  03:46:12.616 [user] ts=2024-11-22T03:46:12.616058263Z caller=middlewares.go:134 method=GetCards id=673ffe7bb0df5c00019b3149 result=1 took=632.266µs  (×2)
  03:46:12.616 [user] ts=2024-11-22T03:46:12.616552195Z caller=middlewares.go:104 method=GetAddresses id=673ffe7bb0df5c00019b3148 result=1 took=1.497758ms
  03:46:12.634 [user] ts=2024-11-22T03:46:12.634580647Z caller=middlewares.go:75 method=GetUsers id=673ffe70b0df5c00019b312c result=1 took=1.030687ms  (×2)
  03:46:12.645 [user] ts=2024-11-22T03:46:12.644976466Z caller=middlewares.go:104 method=GetAddresses id=673ffe79b0df5c00019b3144 result=1 took=953.561µs
  03:46:13.395 [user] ts=2024-11-22T03:46:13.395568647Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffe7eb0df5c00019b3152 took=1.772231ms  (×2)
  03:46:13.409 [user] ts=2024-11-22T03:46:13.409601056Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffe7eb0df5c00019b3152 took=1.637823ms
  03:46:14.500 [user] ts=2024-11-22T03:46:14.50025495Z caller=middlewares.go:46 method=Register username=cnldH email=cnldH@gmail.com took=924.018µs
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×19)
  03:46:10.147 [front-end] { id: '673ffe82b0df5c00019b315b' }  (×33)
  03:46:10.189 [front-end] Sent cookies.  (×33)
  03:46:10.811 [front-end] Received response: "{\"firstName\":\"iRQgndFKRWzZ\",\"lastName\":\"iRQgndFKRWzZ\",\"username\":\"iRQgndFKRWzZ\",\"id\":\"673ffe72b0df5c00019b3133\",\"_links\":{
  03:46:10.818 [front-end] [ undefined, undefined ]  (×34)
  03:46:10.848 [orders] 2024-11-22 03:46:10.848 ERROR [orders,,,] 6 --- [-nio-80-exec-12] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×15)
  03:46:10.940 [front-end] Received response: "{\"firstName\":\"jnTZDLVwW\",\"lastName\":\"jnTZDLVwW\",\"username\":\"jnTZDLVwW\",\"id\":\"673ffe65b0df5c00019b3100\",\"_links\":{\"address
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×36)
  03:46:11.285 [front-end] User cart deleted with status: 503  (×36)
  03:46:11.304 [front-end] POST to carts: http://carts/carts/673ffe7bb0df5c00019b3147/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}  (×22)
  03:46:11.500 [catalogue] ts=2024-11-22T03:46:11Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=3.76723m  (×5)
  03:46:12.526 [front-end] Posting Customer: {"username":"YWRstkOr","password":"kgmbhcEA","email":"YWRstkOr@gmail.com","firstName":"YWRstkOr","lastName":"YWRstkOr"}
  03:46:12.669 [orders] 2024-11-22 03:46:12.668 ERROR [orders,,,] 6 --- [p-nio-80-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×19)
  03:46:14.765 [front-end] Received response: "{\"firstName\":\"KxwXfBfUZ\",\"lastName\":\"KxwXfBfUZ\",\"username\":\"KxwXfBfUZ\",\"id\":\"673ffe6fb0df5c00019b3125\",\"_links\":{\"address
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.227 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×7)
  03:46:17.277 [user] ts=2024-11-22T03:46:17.277211334Z caller=middlewares.go:46 method=Register username=ptkQMzQKHy email=ptkQMzQKHy@gmail.com took=1.044122ms  (×7)
  03:46:20.433 [front-end] Received response: "{\"firstName\":\"DHCGNkyEyawp\",\"lastName\":\"DHCGNkyEyawp\",\"username\":\"DHCGNkyEyawp\",\"id\":\"673ffe74b0df5c00019b3136\",\"_links\":{
  03:46:22.962 [user] ts=2024-11-22T03:46:22.961891483Z caller=middlewares.go:46 method=Register username=YNeGDXzX email=YNeGDXzX@gmail.com took=1.087598ms
  03:46:25.988 [front-end] Posting Customer: {"username":"jAAETa","password":"IwsrY","email":"jAAETa@gmail.com","firstName":"jAAETa","lastName":"jAAETa"}
  03:46:26.496 [front-end] Received response: "{\"firstName\":\"gXlVL\",\"lastName\":\"gXlVL\",\"username\":\"gXlVL\",\"id\":\"673ffe80b0df5c00019b3159\",\"_links\":{\"addresses\":{\"href
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.249 [carts-db] {"t":{"$date":"2024-11-22T03:46:29.248+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224718
  03:46:30.113 [front-end] Posting Customer: {"username":"saWqTMkh","password":"METDVZTIFk","email":"saWqTMkh@gmail.com","firstName":"saWqTMkh","lastName":"saWqTMkh"}
  03:46:30.678 [front-end] Received response: "{\"firstName\":\"jwQwxgI\",\"lastName\":\"jwQwxgI\",\"username\":\"jwQwxgI\",\"id\":\"673ffe80b0df5c00019b315a\",\"_links\":{\"addresses\":{
  03:46:32.838 [front-end] Posting Customer: {"username":"ZzayWIHhxNw","password":"FoukoY","email":"ZzayWIHhxNw@gmail.com","firstName":"ZzayWIHhxNw","lastName":"ZzayWIHhxNw"}
  03:46:36.897 [front-end] Posting Customer: {"username":"gOQlBf","password":"ooDdDywNEy","email":"gOQlBf@gmail.com","firstName":"gOQlBf","lastName":"gOQlBf"}
  03:46:39.288 [front-end] Received response: "{\"firstName\":\"YNeGDXzX\",\"lastName\":\"YNeGDXzX\",\"username\":\"YNeGDXzX\",\"id\":\"673ffe8eb0df5c00019b3183\",\"_links\":{\"addresses\
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:42.361 [front-end] Received response: "{\"firstName\":\"UKKtCDfOtWIPTP\",\"lastName\":\"UKKtCDfOtWIPTP\",\"username\":\"UKKtCDfOtWIPTP\",\"id\":\"673ffe90b0df5c00019b3186\",\"_lin

## p0041
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-13T08:00:01.213Z
```
{"service":"redisservice1","message":"2021-08-13 08:00:01,213 | INFO | 0.0.0.1 | 172.17.0.4 | redisservice1 | 650afb69e5001a4a | service refuse, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  07:59:56.937 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×4)
  07:59:56.994 [redisservice1] INFO redis write success  (×6)
  07:59:57.042 [redisservice1] INFO service accept, status_code: 200  (×7)
  07:59:57.113 [redisservice1] INFO redis读取信息成功, status_code: 200  (×3)
All services, 30 seconds either side (sampled):
  07:59:31.221 [webservice1] INFO uuid: 55ca140a-fbc9-11eb-ab89-0242ac110003 write redis successfully  (×38)
  07:59:31.443 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '55ca4f6a-fbc9-11eb-9d8c-0242ac110003'}  (×42)
  07:59:31.609 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  07:59:31.734 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×42)
  07:59:31.789 [dbservice2] INFO query = select passwards from username_table where user_name='PBlgjmAH'  (×18)
  07:59:32.032 [webservice2] INFO uuid: 564a7564-fbc9-11eb-b80a-0242ac110004 write redis successfully  (×35)
  07:59:32.255 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '564a7564-fbc9-11eb-b80a-0242ac110004', 'value': 'SjMAKXaq'}  (×30)
  07:59:33.127 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×31)
  07:59:33.359 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×3)
  07:59:34.909 [dbservice2] INFO 579f00d8-fbc9-11eb-bc9b-0242ac110004-TdjVXoHa-%Gy+D.NQ!s7p token generate success token=MTYyODgxMjc3NC45MDg5Njk5OjU3OWYwMGQ4LWZiYzktMTFlYi1iYzliLTAyNDJhYzE
  07:59:36.443 [dbservice1] INFO 58925c56-fbc9-11eb-82ba-0242ac110003-pyWndFNv-k$0)mK!%.@XT token generate success token=MTYyODgxMjc3Ni40NDM1NDI6NTg5MjVjNTYtZmJjOS0xMWViLTgyYmEtMDI0MmFjMTE
  07:59:38.602 [mobservice1] INFO info 5a0a5296-fbc9-11eb-8ce9-0242ac110003:AIKNYSvf write success
  07:59:40.541 [dbservice2] INFO 5af7e3b2-fbc9-11eb-94f0-0242ac110004-HfPCXKQO-ko9a.361RV:P token generate success token=MTYyODgxMjc4MC41NDEyOTQ4OjVhZjdlM2IyLWZiYzktMTFlYi05NGYwLTAyNDJhYzE
  07:59:42.939 [dbservice1] INFO 5c67f5a2-fbc9-11eb-9d01-0242ac110003-tjrRfeJy-t5EnZ!FmiUq{ token generate success token=MTYyODgxMjc4Mi45Mzg5MzQzOjVjNjdmNWEyLWZiYzktMTFlYi05ZDAxLTAyNDJhYzE
  07:59:46.025 [dbservice2] INFO 5e3f5d16-fbc9-11eb-8d23-0242ac110004-JdtfzjpK-tGDi)ny2^q0o token generate success token=MTYyODgxMjc4Ni4wMjQ0MzYyOjVlM2Y1ZDE2LWZiYzktMTFlYi04ZDIzLTAyNDJhYzE
  07:59:56.161 [redisservice1] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400
  07:59:56.977 [mobservice2] INFO info 64ff81e4-fbc9-11eb-909c-0242ac110003:CWflULak write success
  07:59:59.246 [mobservice2] INFO info 66585c8c-fbc9-11eb-bb91-0242ac110003:ITDnZiPv write success
  08:00:01.227 [dbservice2] ERROR service refuse  (×21)
  08:00:03.260 [mobservice1] INFO info 68bbf1dc-fbc9-11eb-8304-0242ac110003:gQaRFlxY write success
  08:00:05.953 [redisservice1] INFO service refuse, status_code: 200  (×10)
  08:00:08.717 [mobservice2] INFO info 6bfabe3c-fbc9-11eb-b484-0242ac110004:KmknXdcJ write success
  08:00:11.946 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  08:00:16.141 [mobservice2] INFO info 706adb5a-fbc9-11eb-83ab-0242ac110003:NAVbZmOn write success
  08:00:18.829 [dbservice1] INFO 71d5a13c-fbc9-11eb-89e4-0242ac110003-hTjCBtGX-eJrbTQXfMu<_ token generate success token=MTYyODgxMjgxOC44Mjg2Mjg1OjcxZDVhMTNjLWZiYzktMTFlYi04OWU0LTAyNDJhYzE
  08:00:22.500 [mobservice2] INFO info 7426d9ba-fbc9-11eb-ad36-0242ac110003:NxPGARft write success

## p0717
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-14T13:31:37.500Z
```
{"service":"dbservice2","message":"2021-08-14 13:31:37,500 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | dc9d6bf6a1757f78 | e4d13a32-fcc0-11eb-80c9-0242ac110003-NWUBeIdk-FGOw@=Id6nPZ token generate success token=MTYyODkxOTA5Ny40OTk4NDQ4OmU0ZDEzYTMyLWZjYzAtMTFlYi04MGM5LTAyNDJhYzExMDAwM05XVUJlSWRrRkdPd0A9SWQ2blBaOjE2Mjg5MTkxNTcuNDk5ODU3Mjo5ZTRiMGQ1ZTBlYTc4YTNjYWIwNTMyY2Q1OTIxNzUwYw=="}
```
Same service, the 2 minutes before (oldest first):
  13:31:31.999 [dbservice2] INFO e18b3c10-fcc0-11eb-8d7e-0242ac110003-AayKrPBU-k+hW(sN=wMO4 token generate success token=MTYyODkxOTA5MS45OTg1Nzk3OmUxOGIzYzEwLWZjYzAtMTFlYi04ZDdlLTAyNDJhYzE
  13:31:32.699 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  13:31:32.699 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  13:31:32.743 [dbservice2] INFO query = select passwards from username_table where user_name='NEhHktDw'  (×5)
  13:31:32.826 [dbservice2] INFO e2064806-fcc0-11eb-b8a9-0242ac110004-NEhHktDw-V3.Dx4)O+_o7 token generate success token=MTYyODkxOTA5Mi44MjU1NTg0OmUyMDY0ODA2LWZjYzAtMTFlYi1iOGE5LTAyNDJhYzE
  13:31:33.519 [dbservice2] INFO e28118d8-fcc0-11eb-b4ef-0242ac110003-VwxKRfZB-6<qdQnhm*LTF token generate success token=MTYyODkxOTA5My41MTkzMzU1OmUyODExOGQ4LWZjYzAtMTFlYi1iNGVmLTAyNDJhYzE
  13:31:34.362 [dbservice2] INFO e2ef00a0-fcc0-11eb-aa55-0242ac110004-GZfYMFec-5$&S1)ZuTxf0 token generate success token=MTYyODkxOTA5NC4zNjI1Mzk1OmUyZWYwMGEwLWZjYzAtMTFlYi1hYTU1LTAyNDJhYzE
  13:31:35.886 [dbservice2] INFO e3ddbb8c-fcc0-11eb-9353-0242ac110004-dnDTbBha-yx8)4Fs?KhJg token generate success token=MTYyODkxOTA5NS44ODY0MTAyOmUzZGRiYjhjLWZjYzAtMTFlYi05MzUzLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  13:31:07.548 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×35)
  13:31:07.623 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'd33bef24-fcc0-11eb-996f-0242ac110003', 'value': 'lEKkjfpD'}  (×34)
  13:31:07.806 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×31)
  13:31:07.909 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×30)
  13:31:08.019 [mobservice2] INFO info d36f1372-fcc0-11eb-aa2e-0242ac110003:AmhGSJRK write success
  13:31:08.291 [redisservice2] INFO redis write success  (×70)
  13:31:08.745 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×35)
  13:31:10.006 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×34)
  13:31:10.430 [mobservice1] INFO info d4db9b2c-fcc0-11eb-b791-0242ac110004:eJFaBQoW write success
  13:31:11.249 [dbservice1] INFO d5265b8a-fcc0-11eb-952d-0242ac110004-lGPfCvhn-%)&.w4tO>XjE token generate success token=MTYyODkxOTA3MS4yNDg2NTE1OmQ1MjY1YjhhLWZjYzAtMTFlYi05NTJkLTAyNDJhYzE
  13:31:13.763 [mobservice1] INFO info d6d624ba-fcc0-11eb-9567-0242ac110004:dNrOSsHL write success
  13:31:16.074 [dbservice1] INFO d7fe293c-fcc0-11eb-9517-0242ac110003-HBUrWkyb-d9v-_CftTxs{ token generate success token=MTYyODkxOTA3Ni4wNzM5MDYyOmQ3ZmUyOTNjLWZjYzAtMTFlYi05NTE3LTAyNDJhYzE
  13:31:18.243 [mobservice1] INFO info d9886362-fcc0-11eb-b217-0242ac110004:WQyFOAmB write success
  13:31:20.270 [dbservice1] INFO da897846-fcc0-11eb-9732-0242ac110003-CMzFsYZh-4nfMZxAl(ko0 token generate success token=MTYyODkxOTA4MC4yNjk4OTI1OmRhODk3ODQ2LWZjYzAtMTFlYi05NzMyLTAyNDJhYzE
  13:31:22.663 [mobservice2] INFO info dc28f726-fcc0-11eb-b1ea-0242ac110003:xXiaofbu write success
  13:31:24.807 [mobservice1] INFO info dd7037a2-fcc0-11eb-888b-0242ac110003:DhdfCMlE write success
  13:31:26.870 [dbservice2] INFO de7c26e2-fcc0-11eb-b2e7-0242ac110004-RkEDeABl-sC5<pVEN#w:8 token generate success token=MTYyODkxOTA4Ni44Njk5MzE1OmRlN2MyNmUyLWZjYzAtMTFlYi1iMmU3LTAyNDJhYzE
  13:31:29.071 [mobservice2] INFO info dffb7d6a-fcc0-11eb-ba05-0242ac110003:LcHJSWVC write success
  13:31:31.643 [dbservice1] INFO e1524ffe-fcc0-11eb-9c86-0242ac110004-GrKgOByV-n@*{TE_p^JR3 token generate success token=MTYyODkxOTA5MS42NDMyNDA1OmUxNTI0ZmZlLWZjYzAtMTFlYi05Yzg2LTAyNDJhYzE
  13:31:33.940 [mobservice1] INFO info e2ef00a0-fcc0-11eb-aa55-0242ac110004:GZfYMFec write success
  13:31:35.886 [dbservice2] INFO e3ddbb8c-fcc0-11eb-9353-0242ac110004-dnDTbBha-yx8)4Fs?KhJg token generate success token=MTYyODkxOTA5NS44ODY0MTAyOmUzZGRiYjhjLWZjYzAtMTFlYi05MzUzLTAyNDJhYzE
  13:31:38.411 [dbservice1] INFO e54bacd6-fcc0-11eb-b9e7-0242ac110003-GwpUdJLR-<=#>pyVh.A$d token generate success token=MTYyODkxOTA5OC40MTExNDg6ZTU0YmFjZDYtZmNjMC0xMWViLWI5ZTctMDI0MmFjMTE
  13:31:40.706 [mobservice2] INFO info e6e34356-fcc0-11eb-9583-0242ac110003:CjhYTZqf write success
  13:31:51.373 [mobservice2] INFO info ed4929fe-fcc0-11eb-bce7-0242ac110003:tpRwcUuS write success
  13:31:54.323 [mobservice2] INFO info eefd86c8-fcc0-11eb-9ad5-0242ac110003:SjMAKXaq write success
  13:31:59.898 [mobservice1] INFO info f25ca588-fcc0-11eb-b2ae-0242ac110004:GKtJXRfS write success
  13:32:06.555 [mobservice2] ERROR uuid:efcc94fe-fcc0-11eb-9561-0242ac110003 information has expired, mobile phone login is invalid

## p0262
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:15.701Z
```
{"timestamp":1732242495701615400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Merging carts for customer id: 673fec3fb0df5c00019af986 and session id: m7tqqWakHxD90sn69NbpFpdgCpaxFP3Y"}
```
Same service, the 2 minutes before (oldest first):
  02:28:14.185 [front-end] DELETE /cart 503 - ms - -
  02:28:14.190 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  02:28:14.191 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242494188,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:14.191 [front-end] Order response: {"timestamp":1732242494188,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:14.194 [front-end] POST /orders 500 - ms - -
  02:28:14.197 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  02:28:14.197 [front-end] POST to carts: http://carts/carts/673fec34b0df5c00019af967/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  02:28:14.238 [front-end] POST /cart 500 46.629 ms - 64
  02:28:14.311 [front-end] Posting Customer: {"username":"AIwPgMB","password":"ciKTe","email":"AIwPgMB@gmail.com","firstName":"AIwPgMB","lastName":"AIwPgMB"}
  02:28:14.317 [front-end] { id: '673fec3eb0df5c00019af985' }  (×2)
  02:28:14.317 [front-end] 673fec3eb0df5c00019af985  (×2)
  02:28:14.317 [front-end] Merging carts for customer id: 673fec3eb0df5c00019af985 and session id: y5_hKG3jcMa48JRLX0HxhdItvM_uuPGj
  02:28:14.337 [front-end] Carts merged.
  02:28:14.337 [front-end] set cookie673fec3eb0df5c00019af985
  02:28:14.337 [front-end] Sent cookies.
  02:28:14.339 [front-end] POST /register 200 27.005 ms - 33
  02:28:15.632 [front-end] GET /catalogue 200 - ms - -
  02:28:15.696 [front-end] Posting Customer: {"username":"NGQZYvsdKz","password":"rioCzg","email":"NGQZYvsdKz@gmail.com","firstName":"NGQZYvsdKz","lastName":"NGQZYvsdKz"}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×41)
  02:28:03.174 [front-end] User cart deleted with status: 503  (×41)
  02:28:03.202 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×42)
  02:28:03.249 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×17)
  02:28:03.410 [front-end] Carts merged.  (×39)
  02:28:04.973 [front-end] Posting Customer: {"username":"HFHBXn","password":"EOgUhihln","email":"HFHBXn@gmail.com","firstName":"HFHBXn","lastName":"HFHBXn"}
  02:28:05.351 [user] ts=2024-11-22T02:28:05.351787827Z caller=middlewares.go:46 method=Register username=vuOxCKL email=vuOxCKL@gmail.com took=4.581531ms
  02:28:08.095 [front-end] Received response: "{\"firstName\":\"RsyjMQXEZqDOIBa\",\"lastName\":\"RsyjMQXEZqDOIBa\",\"username\":\"RsyjMQXEZqDOIBa\",\"id\":\"673fec1eb0df5c00019af912\",\"_
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:15.136 [carts] 2024-11-22 02:28:15.041 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 160.989 seconds (JVM running for 167.0
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:22.317 [front-end] Received response: "{\"firstName\":\"JGQXvUjPbFrtK\",\"lastName\":\"JGQXvUjPbFrtK\",\"username\":\"JGQXvUjPbFrtK\",\"id\":\"673fec34b0df5c00019af964\",\"_links\
  02:28:23.143 [orders] 2024-11-22 02:28:23.143 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×9)
  02:28:24.588 [shipping] Adding shipment to queue...  (×24)
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:26.156 [front-end] POST /cart 201 - ms - -  (×26)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d8","customerId":"673fec2cb0df5c00019af949","customer":{"id":null,"firstName":"KoWsmDtUqsE
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:30.547 [front-end] Received response: "{\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\",\"username\":\"vvgsHcY\",\"id\":\"673fec35b0df5c00019af968\",\"_links\":{\"addresses\":{
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.645 [queue-master] 2024-11-22 02:28:32.645 INFO 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×15)
  02:28:37.005 [user] ts=2024-11-22T02:28:37.005380807Z caller=middlewares.go:46 method=Register username=XTqSaA email=XTqSaA@gmail.com took=624.562µs
  02:28:40.136 [front-end] Order response: {"id":"673fec58d94b9000069b39dc","customerId":"673fec41b0df5c00019af98b","customer":{"id":null,"firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe",
  02:28:41.723 [user] ts=2024-11-22T02:28:41.723279742Z caller=middlewares.go:46 method=Register username=yaELjpCD email=yaELjpCD@gmail.com took=1.302265ms
  02:28:43.812 [front-end] Order response: {"id":"673fec5bd94b9000069b39e0","customerId":"673fec47b0df5c00019af996","customer":{"id":null,"firstName":"bhZuEQ","lastName":"bhZuEQ","usernam
  02:28:45.163 [front-end] Received response: "{\"firstName\":\"oqYeDriHaX\",\"lastName\":\"oqYeDriHaX\",\"username\":\"oqYeDriHaX\",\"id\":\"673fec49b0df5c00019af999\",\"_links\":{\"addr

## p0541
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-preserve-other-service, 2024-12-07T18:17:39.495Z
```
{"timestamp":1733595459495824000,"container_name":"ts-preserve-other-service","pod_name":"ts-preserve-other-service-7cf4c487d7-fctlp","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:17:39.495  INFO 1 --- [io-14569-exec-5] p.controller.PreserveOtherController     : [Preserve Other Service][Preserve] Account  order from Shang Hai -----> Nan Jing at Sat Dec 07 00:00:00 GMT 2024"}
```
Same service, the 2 minutes before (oldest first):
  18:17:37.995 [ts-preserve-other-service] 2024-12-07 18:17:37.994 INFO 1 --- [io-14569-exec-5] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  18:17:37.995 [ts-preserve-other-service] 2024-12-07 18:17:37.995 INFO 1 --- [io-14569-exec-5] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  18:17:38.095 [ts-preserve-other-service] 2024-12-07 18:17:38.095 INFO 1 --- [io-14569-exec-5] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization completed in 100 m
All services, 30 seconds either side (sampled):
  18:17:09.500 [ts-basic-service] 2024-12-07 18:17:09.499 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×16)
  18:17:09.602 [ts-travel-service] 2024-12-07 18:17:09.602 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×19)
  18:17:09.717 [ts-travel-service] 2024-12-07 18:17:09.717 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 06:48:00 GMT 2013  (×16)
  18:17:09.852 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:17:09 +0800] "GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1" 200 202 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×21)
  18:17:09.921 [ts-travel-service] 2024-12-07 18:17:09.921 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×8)
  18:17:10.263 [ts-seat-service] 2024-12-07 18:17:10.263 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×18)
  18:17:12.566 [ts-order-other-service] 2024-12-07 18:17:12.566 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Get Order By Id] Order Id: 7778b836-a5dd-46c3
  18:17:14.410 [ts-travel-service] 2024-12-07 18:17:14.409 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×16)
  18:17:14.732 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:17:14 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 3056 "-" "Mozilla/5.0 (Macintosh;  (×3)
  18:17:22.893 [ts-basic-service] 2024-12-07 18:17:22.892 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×12)
  18:17:23.037 [ts-travel2-service] 2024-12-07 18:17:23.036 INFO 1 --- [io-16346-exec-5] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×25)
  18:17:24.377 [ts-travel-service] 2024-12-07 18:17:24.377 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=nanjing)  (×7)
  18:17:24.480 [ts-basic-service] 2024-12-07 18:17:24.480 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 4  (×4)
  18:17:25.232 [ts-basic-service] 2024-12-07 18:17:25.232 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2
  18:17:25.938 [ts-order-other-service] 2024-12-07 18:17:25.938 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×10)
  18:17:27.322 [ts-basic-service] 2024-12-07 18:17:27.321 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×6)
  18:17:29.704 [ts-food-mongo] {"t":{"$date":"2024-12-07T18:17:29.704+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359544
  18:17:30.664 [ts-user-mongo] {"t":{"$date":"2024-12-07T18:17:30.664+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359545
  18:17:31.308 [ts-travel-service] 2024-12-07 18:17:31.308 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×2)
  18:17:37.543 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:17:37 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 200 119 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
  18:17:38.095 [ts-preserve-other-service] 2024-12-07 18:17:38.095 INFO 1 --- [io-14569-exec-5] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization completed in 100 m
  18:17:39.925 [ts-order-other-service] 2024-12-07 18:17:39.924 INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController : [Order Other Service][Security Info Get]
  18:17:39.998 [ts-contacts-service] 2024-12-07 18:17:39.997 INFO 1 --- [io-12347-exec-7] contacts.service.ContactsServiceImpl : FIND CONTACTS BY ID: d14da0ec-da93-46c3-842d-23fc37f2c919
  18:17:41.083 [ts-preserve-other-service] 2024-12-07 18:17:41.082 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : TripResponse : TripResponse(tripId=Z1234, startingStation=Shang Hai, t
  18:17:41.391 [ts-seat-service] 2024-12-07 18:17:41.391 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService distributeSeat] Use a new seat number! 1124724082
  18:17:41.604 [ts-assurance-service] 2024-12-07 18:17:41.603 INFO 1 --- [io-18888-exec-9] assurance.service.AssuranceServiceImpl : [Assurance-Add&Delete-Service][AddAssurance] Success.
  18:17:42.002 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:17:42 +0800] "POST /api/v1/preserveotherservice/preserveOther HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7
  18:17:44.775 [ts-admin-travel-service] 2024-12-07 18:17:44.774 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)

## p0273
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:22.552Z
```
{"timestamp":1732242502552292000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /register 200 4675.058 ms - 33"}
```
Same service, the 2 minutes before (oldest first):
  02:28:22.324 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:22.324 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec3db0df5c00019af980\",\"_links\":{\"
  02:28:22.324 [front-end] [ undefined, undefined ]
  02:28:22.324 [front-end] Posting Order: {"customer":"http://user/customers/673fec34b0df5c00019af964","address":"http://user/addresses/673fec3cb0df5c00019af97f","card":"http://user/cards
  02:28:22.389 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec3eb0df5c00019af985"}
  02:28:22.400 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242502396,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:22.400 [front-end] Order response: {"timestamp":1732242502396,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:22.400 [front-end] POST /addresses 200 - ms - -
  02:28:22.401 [front-end] POST /orders 500 - ms - -
  02:28:22.405 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec3eb0df5c00019af985"}
  02:28:22.413 [front-end] POST /cards 200 - ms - -
  02:28:22.419 [front-end] GET /catalogue 200 - ms - -
  02:28:22.461 [front-end] Attempting to delete cart for user: 673fec3eb0df5c00019af985
  02:28:22.516 [front-end] Posting Customer: {"username":"FUekuDogRI","password":"vzTsDBt","email":"FUekuDogRI@gmail.com","firstName":"FUekuDogRI","lastName":"FUekuDogRI"}
  02:28:22.521 [front-end] { id: '673fec46b0df5c00019af994' }
  02:28:22.521 [front-end] 673fec46b0df5c00019af994
  02:28:22.521 [front-end] Merging carts for customer id: 673fec46b0df5c00019af994 and session id: KkZrOzNoqKgxA2YV9xemsYfowSvZTYBW
  02:28:22.550 [front-end] Carts merged.
  02:28:22.550 [front-end] set cookie673fec41b0df5c00019af98c
  02:28:22.550 [front-end] Sent cookies.
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×48)
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -  (×48)
  02:28:03.203 [front-end] [ undefined, undefined ]  (×48)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×4)
  02:28:07.445 [orders] 2024-11-22 02:28:07.445 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
  02:28:10.277 [front-end] Posting Customer: {"username":"opFqwUnVow","password":"habyXFSF","email":"opFqwUnVow@gmail.com","firstName":"opFqwUnVow","lastName":"opFqwUnVow"}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
  02:28:23.301 [front-end] Received response: "{\"firstName\":\"HFHBXn\",\"lastName\":\"HFHBXn\",\"username\":\"HFHBXn\",\"id\":\"673fec34b0df5c00019af967\",\"_links\":{\"addresses\":{\"h
  02:28:24.999 [rabbitmq] 
  02:28:25.743 [carts] 2024-11-22 02:28:25.743 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×14)
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39d0","customerId":"673fec31b0df5c00019af95b","customer":{"id":null,"firstName":"bCCZHBaYc","lastName":"bCCZHBaYc","u
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×60)
  02:28:37.548 [user] ts=2024-11-22T02:28:37.548591Z caller=middlewares.go:46 method=Register username=OeZpiPZUn email=OeZpiPZUn@gmail.com took=1.009704ms
  02:28:40.321 [front-end] Order response: {"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR","lastName":"nbZCdAQyR","u
  02:28:42.162 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732242522152,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×2)
  02:28:44.338 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec5cd94b9000069b39e2","customerId":"673fec3ab0df5c00019af974","customer":{"id":null,"firstName":"opFqwUnVow"
  02:28:45.405 [front-end] Posting Customer: {"username":"crSMtAKNWrXaJJx","password":"TlwWXSanSW","email":"crSMtAKNWrXaJJx@gmail.com","firstName":"crSMtAKNWrXaJJx","lastName":"crSMtAKNWr
  02:28:47.575 [front-end] Received response: "{\"firstName\":\"QGHrdp\",\"lastName\":\"QGHrdp\",\"username\":\"QGHrdp\",\"id\":\"673fec41b0df5c00019af98c\",\"_links\":{\"addresses\":{\"h
  02:28:50.618 [front-end] Received response: "{\"firstName\":\"XsZRA\",\"lastName\":\"XsZRA\",\"username\":\"XsZRA\",\"id\":\"673fec4ab0df5c00019af99b\",\"_links\":{\"addresses\":{\"href

## p0801
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-08T08:40:53.389Z
```
{"timestamp":1733647253389806600,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-7kts9","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-08 08:40:53.389  INFO 1 --- [           main] o.s.b.a.e.mvc.EndpointHandlerMapping     : Mapped \"{[/heapdump || /heapdump.json],methods=[GET],produces=[application/octet-stream]}\" onto public void org.springframework.boot.actuate.endpoint.mvc.HeapdumpMvcEndpoint.invoke(boolean,javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse) throws java.io.IOException,javax.ser…"}
```
Same service, the 2 minutes before (oldest first):
  08:40:48.174 [ts-auth-service] 2024-12-08 08:40:48.173 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.access.expression.method.DefaultMethodS
  08:40:48.185 [ts-auth-service] 2024-12-08 08:40:48.184 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.method.configuration.
  08:40:48.277 [ts-auth-service] 2024-12-08 08:40:48.277 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  08:40:48.675 [ts-auth-service] 2024-12-08 08:40:48.674 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact
  08:40:48.677 [ts-auth-service] 2024-12-08 08:40:48.676 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [java.util.Properties] is not e
  08:40:50.385 [ts-auth-service] 2024-12-08 08:40:50.385 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  08:40:50.997 [ts-auth-service] 2024-12-08 08:40:50.996 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  08:40:51.079 [ts-auth-service] 2024-12-08 08:40:51.078 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users],methods=[GET]}" onto public org.springframework.h
  08:40:51.079 [ts-auth-service] 2024-12-08 08:40:51.079 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/{userId}],methods=[DELETE]}" onto public org.sprin
  08:40:51.079 [ts-auth-service] 2024-12-08 08:40:51.079 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/hello],methods=[GET]}" onto public java.lang.Objec
  08:40:51.080 [ts-auth-service] 2024-12-08 08:40:51.080 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth],methods=[POST]}" onto public org.springframework.h
  08:40:51.081 [ts-auth-service] 2024-12-08 08:40:51.080 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth/hello],methods=[GET]}" onto public java.lang.String
  08:40:51.082 [ts-auth-service] 2024-12-08 08:40:51.082 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  08:40:51.082 [ts-auth-service] 2024-12-08 08:40:51.082 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  08:40:51.389 [ts-auth-service] 2024-12-08 08:40:51.388 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.springframewo
  08:40:51.389 [ts-auth-service] 2024-12-08 08:40:51.388 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springframework.web.s
  08:40:51.586 [ts-auth-service] 2024-12-08 08:40:51.585 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class org.springfra
  08:40:52.383 [ts-auth-service] 2024-12-08 08:40:52.383 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 12340 (http)
  08:40:52.780 [ts-auth-service] 2024-12-08 08:40:52.779 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  08:40:52.781 [ts-auth-service] 2024-12-08 08:40:52.780 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43
All services, 30 seconds either side (sampled):
  08:40:25.296 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:40:25 +0800] "POST /api/v1/users/login HTTP/1.1" 503 19 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel M  (×15)
  08:40:25.369 [ts-basic-service] 2024-12-08 08:40:25.369 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87
  08:40:25.393 [ts-travel2-service] 2024-12-08 08:40:25.392 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×7)
  08:40:25.461 [ts-order-other-service] 2024-12-08 08:40:25.461 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×16)
  08:40:25.522 [ts-route-service] 2024-12-08 08:40:25.522 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×9)
  08:40:26.028 [ts-basic-service] 2024-12-08 08:40:26.028 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×2)
  08:40:26.245 [ts-basic-service] 2024-12-08 08:40:26.245 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×5)
  08:40:28.780 [ts-seat-service] 2024-12-08 08:40:28.779 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
  08:40:30.992 [ts-auth-service] 2024-12-08 08:40:30.992 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.access.expression.method.DefaultMethodS  (×2)
  08:40:33.022 [ts-travel2-service] 2024-12-08 08:40:33.022 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×2)
  08:40:33.646 [ts-travel-service] 2024-12-08 08:40:33.646 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×2)
  08:40:33.695 [ts-basic-service] 2024-12-08 08:40:33.695 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×3)
  08:40:33.760 [ts-travel-service] 2024-12-08 08:40:33.760 INFO 1 --- [io-12346-exec-9] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×6)
  08:40:33.860 [ts-order-service] 2024-12-08 08:40:33.860 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=625927415,   (×4)
  08:40:35.275 [ts-basic-service] 2024-12-08 08:40:35.275 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing
  08:40:39.575 [ts-seat-service] 2024-12-08 08:40:39.574 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  08:40:42.680 [ts-order-other-service] 2024-12-08 08:40:42.679 INFO 1 --- [io-12032-exec-8] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 
  08:40:43.535 [ts-travel-service] 2024-12-08 08:40:43.535 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
  08:40:44.810 [ts-order-other-service] 2024-12-08 08:40:44.809 ERROR 1 --- [o-12032-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  08:40:51.079 [ts-auth-service] 2024-12-08 08:40:51.079 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/hello],methods=[GET]}" onto public java.lang.Objec
  08:40:53.391 [ts-auth-service] 2024-12-08 08:40:53.391 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/vnd.spring-boot.
  08:40:53.397 [ts-auth-service] 2024-12-08 08:40:53.396 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  08:40:59.092 [ts-auth-service] 2024-12-08 08:40:59.091 INFO 1 --- [ main] o.s.i.endpoint.EventDrivenConsumer : Adding {logging-channel-adapter:_org.springframework.integration.errorLogger} as
  08:41:04.191 [ts-auth-service] 2024-12-08 08:41:04.191 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×8)
  08:41:05.792 [ts-admin-travel-service] 2024-12-08 08:41:05.792 ERROR 1 --- [io-16114-exec-8] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×2)
  08:41:09.704 [ts-auth-mongo] {"t":{"$date":"2024-12-08T08:41:09.703+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364726
  08:41:10.819 [ts-admin-basic-info-service] 2024-12-08 08:41:10.819 ERROR 1 --- [io-18767-exec-1] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×2)
  08:41:11.537 [ts-price-mongo] {"t":{"$date":"2024-12-08T08:41:11.537+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364727
  08:41:14.909 [ts-auth-service] 2024-12-08 08:41:14.909 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN

## p0725
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-14T18:55:12.503Z
```
{"service":"mobservice2","message":"2021-08-14 18:55:12,503 | INFO | 0.0.0.4 | 172.17.0.2 | mobservice2 | d930574f0b34621f | request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '19515ab2-fcee-11eb-b77f-0242ac110004', 'value': 'HkuCdjLo'}"}
```
Same service, the 2 minutes before (oldest first):
  18:55:08.552 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '16f5476a-fcee-11eb-9bbb-0242ac110004', 'value': 'FuZbUPph'}  (×4)
  18:55:08.594 [mobservice2] INFO info 16f5476a-fcee-11eb-9bbb-0242ac110004:FuZbUPph write success
  18:55:08.738 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  18:55:08.739 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  18:55:08.739 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '17194c0a-fcee-11eb-8e2d-0242ac110004'}  (×4)
  18:55:08.834 [mobservice2] INFO info 17194c0a-fcee-11eb-8e2d-0242ac110004:AsKCtDoY write success
  18:55:11.705 [mobservice2] INFO info 18c1891e-fcee-11eb-917c-0242ac110004:YXLKvufE write success
  18:55:11.793 [mobservice2] INFO info 18d5b970-fcee-11eb-b95d-0242ac110003:GrKgOByV write success
All services, 30 seconds either side (sampled):
  18:54:42.545 [webservice2] INFO complete information: {'uuid': '0788902a-fcee-11eb-980e-0242ac110004', 'user_id': 'OSENDWPb'}  (×42)
  18:54:42.725 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '0788902a-fcee-11eb-980e-0242ac110004', 'value': 'OSENDWPb'}  (×34)
  18:54:42.870 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×39)
  18:54:43.032 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×38)
  18:54:43.118 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  18:54:43.252 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '07d36578-fcee-11eb-a91f-0242ac110003', 'value': 'kWPHSeaC'}  (×45)
  18:54:43.499 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×41)
  18:54:43.878 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×46)
  18:54:44.944 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  18:54:46.403 [mobservice2] INFO info 098f503e-fcee-11eb-8c56-0242ac110004:OMLuHZEe write success
  18:54:48.962 [mobservice2] INFO info 0b35ba68-fcee-11eb-8201-0242ac110004:fLyAPDBT write success
  18:54:52.243 [dbservice2] INFO 0d0e0f70-fcee-11eb-ac2e-0242ac110003-lykPtSEm-Uo4)Bv3.0QsS token generate success token=MTYyODkzODQ5Mi4yNDMwMTI0OjBkMGUwZjcwLWZjZWUtMTFlYi1hYzJlLTAyNDJhYzE
  18:55:01.478 [mobservice2] ERROR uuid:0c2f2fb2-fcee-11eb-abfc-0242ac110004 information has expired, mobile phone login is invalid
  18:55:02.829 [mobservice2] INFO info 1386abf0-fcee-11eb-8266-0242ac110003:IMzHpvSY write success
  18:55:04.517 [mobservice1] INFO info 147d74e4-fcee-11eb-99af-0242ac110003:KvxBQDHV write success
  18:55:06.425 [dbservice1] INFO 156cfcc6-fcee-11eb-acf4-0242ac110003-HTNvoKmL-kb7d.AGJ+n32 token generate success token=MTYyODkzODUwNi40MjQ5MDk4OjE1NmNmY2M2LWZjZWUtMTFlYi1hY2Y0LTAyNDJhYzE
  18:55:08.902 [dbservice2] INFO 16f5476a-fcee-11eb-9bbb-0242ac110004-FuZbUPph-9In_s$eHajw5 token generate success token=MTYyODkzODUwOC45MDE3Mjg5OjE2ZjU0NzZhLWZjZWUtMTFlYi05YmJiLTAyNDJhYzE
  18:55:11.267 [dbservice2] INFO 18577ec0-fcee-11eb-aa83-0242ac110004-zWnEcpYU-G1q:v_n5M!k^ token generate success token=MTYyODkzODUxMS4yNjY5MzAzOjE4NTc3ZWMwLWZjZWUtMTFlYi1hYTgzLTAyNDJhYzE
  18:55:14.253 [mobservice1] INFO info 1a507114-fcee-11eb-9e18-0242ac110004:aZMCtwXA write success
  18:55:16.235 [dbservice1] INFO 1b49c8fe-fcee-11eb-b4b8-0242ac110003-AMGHfWVz-IboWt}1>NAEC token generate success token=MTYyODkzODUxNi4yMzUzNDI3OjFiNDljOGZlLWZjZWUtMTFlYi1iNGI4LTAyNDJhYzE
  18:55:18.337 [mobservice1] INFO info 1cc599ce-fcee-11eb-b84c-0242ac110003:fLyAPDBT write success
  18:55:20.714 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  18:55:23.250 [mobservice1] INFO info 1fa3a05a-fcee-11eb-8a7d-0242ac110004:jDuLxAwt write success
  18:55:25.559 [mobservice1] INFO info 211314d4-fcee-11eb-99d1-0242ac110003:FyRfJQAa write success
  18:55:29.061 [mobservice2] INFO info 23191436-fcee-11eb-a807-0242ac110003:tdfCvYKb write success
  18:55:31.663 [mobservice2] INFO info 24b881fa-fcee-11eb-84bf-0242ac110003:mAIhCgaZ write success
  18:55:34.013 [mobservice1] INFO info 2617869a-fcee-11eb-b187-0242ac110004:CfHjswnr write success
  18:55:36.003 [dbservice1] INFO 2712172c-fcee-11eb-bde1-0242ac110003-cgKfeRjJ-?%FBPz^@kcZD token generate success token=MTYyODkzODUzNi4wMDI2MjM2OjI3MTIxNzJjLWZjZWUtMTFlYi1iZGUxLTAyNDJhYzE
  18:55:38.239 [dbservice1] INFO 2865765a-fcee-11eb-8963-0242ac110003-NFrlOSIe-=YK{V2Rx*D6H token generate success token=MTYyODkzODUzOC4yMzkwNTk0OjI4NjU3NjVhLWZjZWUtMTFlYi04OTYzLTAyNDJhYzE
  18:55:40.780 [mobservice2] INFO info 2a1ab7f8-fcee-11eb-8c36-0242ac110004:MxLzTnND write success

## p0202
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:57:53.555Z
```
{"timestamp":1731913073555342800,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"serving product page"}
```
Same service, the 2 minutes before (oldest first):
  06:57:52.097 [frontend] home  (×2)
  06:57:52.144 [frontend] ENV_PLATFORM is: aws  (×2)
  06:57:52.147 [frontend] request complete  (×6)
  06:57:52.442 [frontend] request started  (×6)
  06:57:52.442 [frontend] serving product page  (×2)
  06:57:52.565 [frontend] setting currency
  06:57:52.743 [frontend] view user cart
All services, 30 seconds either side (sampled):
  06:57:23.669 [frontend] request started  (×333)
  06:57:23.673 [frontend] home  (×28)
  06:57:23.687 [currencyservice] conversion request successful  (×688)
  06:57:23.725 [frontend] view user cart  (×72)
  06:57:23.748 [shippingservice] [GetQuote] completed request  (×85)
  06:57:23.870 [adservice] received ad request (context_words=[kitchen])  (×59)
  06:57:26.939 [adservice] received ad request (context_words=[accessories])  (×28)
  06:57:27.841 [adservice] received ad request (context_words=[decor, home])  (×22)
  06:57:35.237 [frontend] placing order  (×13)
  06:57:35.274 [paymentservice] Transaction processed: visa ending 8826 Amount: GBP274.754188403  (×2)
  06:57:35.277 [shippingservice] [ShipOrder] completed request  (×13)
  06:57:35.291 [checkoutservice] order confirmation email sent to "lindarasmussen@example.net"
  06:57:40.744 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"11147","nanos":62353903},"credit_card":{"credit_card_number":"4833814864981
  06:57:40.760 [checkoutservice] order confirmation email sent to "paulamitchell@example.org"
  06:57:50.701 [paymentservice] Transaction processed: visa ending 0224 Amount: CAD575.104870416  (×2)
  06:57:51.552 [checkoutservice] [PlaceOrder] user_id="b63bea0e-d05f-4589-be71-8fef43557432" user_currency="USD"  (×4)
  06:57:51.601 [emailservice] A request to send order confirmation email to ljones@example.net has been received.
  06:57:59.414 [checkoutservice] order confirmation email sent to "john72@example.com"
  06:58:07.031 [paymentservice] Transaction processed: visa ending 5464 Amount: JPY18550.220256938
  06:58:11.550 [emailservice] A request to send order confirmation email to kevin94@example.com has been received.
  06:58:16.950 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"175","nanos":488721809},"credit_card":{"credit_card_number":"40970474614919  (×3)
  06:58:16.965 [checkoutservice] order confirmation email sent to "timothywise@example.com"
  06:58:18.327 [emailservice] A request to send order confirmation email to dennis76@example.com has been received.
  06:58:19.477 [checkoutservice] order confirmation email sent to "hebertjames@example.com"
  06:58:19.729 [emailservice] A request to send order confirmation email to smithkyle@example.net has been received.

## p0489
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:57:07.646Z
```
{"timestamp":1732352227646883000,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"Posting Customer: {\"username\":\"wWVXfxc\",\"password\":\"MWeTANl\",\"email\":\"wWVXfxc@gmail.com\",\"firstName\":\"wWVXfxc\",\"lastName\":\"wWVXfxc\"}"}
```
Same service, the 2 minutes before (oldest first):
  08:57:06.986 [front-end] GET Request to: http://user/customers/674198caa437380001deff7d/cards
  08:57:06.999 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"674198d3a437380001deff9a\",\"_links\":{\"
  08:57:07.000 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67419
  08:57:07.000 [front-end] [ undefined, undefined ]
  08:57:07.000 [front-end] Posting Order: {"customer":"http://user/customers/674198caa437380001deff7d","address":"http://user/addresses/674198d3a437380001deff99","card":"http://user/cards
  08:57:07.035 [front-end] Order response: {"statusCode":201,"body":{"id":"674198e33f7706000886538a","customerId":"674198caa437380001deff7d","customer":{"id":null,"firstName":"vidoaLMiMZn
  08:57:07.035 [front-end] Order response: {"id":"674198e33f7706000886538a","customerId":"674198caa437380001deff7d","customer":{"id":null,"firstName":"vidoaLMiMZn","lastName":"vidoaLMiMZn
  08:57:07.037 [front-end] POST /orders 201 - ms - -
  08:57:07.130 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"674198d9a437380001deffa4"}
  08:57:07.141 [front-end] POST /addresses 200 - ms - -
  08:57:07.146 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674198d9a437380001deffa4"}
  08:57:07.156 [front-end] POST /cards 200 - ms - -
  08:57:07.204 [front-end] Attempting to delete cart for user: 674198d9a437380001deffa4
  08:57:07.223 [front-end] User cart deleted with status: 202
  08:57:07.224 [front-end] DELETE /cart 202 - ms - -
  08:57:07.229 [front-end] Attempting to add to cart: {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","quantity":1}
  08:57:07.239 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
  08:57:07.239 [front-end] POST to carts: http://carts/carts/674198d9a437380001deffa4/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}
  08:57:07.277 [front-end] POST /cart 201 - ms - -
  08:57:07.360 [front-end] GET /catalogue 200 - ms - -
All services, 30 seconds either side (sampled):
  08:56:58.007 [catalogue] ts=2024-11-23T08:56:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.869902ms  (×43)
  08:56:58.025 [queue-master] Received shipment task: 674198bfa437380001deff45  (×34)
  08:56:59.331 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"674198d3a437380001deff98"}  (×37)
  08:56:59.474 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×37)
  08:57:00.731 [front-end] Received response: "{\"firstName\":\"nuXAdkfqQQTG\",\"lastName\":\"nuXAdkfqQQTG\",\"username\":\"nuXAdkfqQQTG\",\"id\":\"674198caa437380001deff7c\",\"_links\":{
  08:57:00.838 [front-end] Order response: {"id":"674198dc3f77060008865385","customerId":"674198caa437380001deff7c","customer":{"id":null,"firstName":"nuXAdkfqQQTG","lastName":"nuXAdkfqQQ
  08:57:01.163 [user] ts=2024-11-23T08:57:01.163824603Z caller=middlewares.go:46 method=Register username=eWMmgZPhWLI email=eWMmgZPhWLI@gmail.com took=2.820248ms  (×21)
  08:57:02.787 [front-end] Received response: "{\"firstName\":\"iEYCUjoH\",\"lastName\":\"iEYCUjoH\",\"username\":\"iEYCUjoH\",\"id\":\"674198c5a437380001deff67\",\"_links\":{\"addresses\
  08:57:03.104 [front-end] Received response: "{\"firstName\":\"ssJdfJXeVtH\",\"lastName\":\"ssJdfJXeVtH\",\"username\":\"ssJdfJXeVtH\",\"id\":\"674198cca437380001deff89\",\"_links\":{\"a
  08:57:05.233 [front-end] Received response: "{\"firstName\":\"LEiit\",\"lastName\":\"LEiit\",\"username\":\"LEiit\",\"id\":\"674198c8a437380001deff74\",\"_links\":{\"addresses\":{\"href
  08:57:06.986 [front-end] Received response: "{\"firstName\":\"vidoaLMiMZn\",\"lastName\":\"vidoaLMiMZn\",\"username\":\"vidoaLMiMZn\",\"id\":\"674198caa437380001deff7d\",\"_links\":{\"a
  08:57:08.980 [queue-master] 2024-11-23 08:57:08.980 ERROR 7 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×27)
  08:57:09.328 [front-end] Order response: {"id":"674198e53f7706000886538d","customerId":"674198c9a437380001deff7b","customer":{"id":null,"firstName":"gwVURDHGhHvUnO","lastName":"gwVURDHG
  08:57:11.879 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×2)
  08:57:14.128 [user] ts=2024-11-23T08:57:14.127979514Z caller=middlewares.go:46 method=Register username=JCYeKSjM email=JCYeKSjM@gmail.com took=1.895564ms
  08:57:17.122 [user] ts=2024-11-23T08:57:17.12212485Z caller=middlewares.go:46 method=Register username=ATXpLlnRT email=ATXpLlnRT@gmail.com took=2.378879ms
  08:57:19.255 [front-end] Order response: {"statusCode":201,"body":{"id":"674198ef3f77060008865390","customerId":"674198d8a437380001deffa3","customer":{"id":null,"firstName":"yuarl","las
  08:57:22.096 [front-end] Posting Customer: {"username":"ErqkMC","password":"qwrMe","email":"ErqkMC@gmail.com","firstName":"ErqkMC","lastName":"ErqkMC"}
  08:57:24.489 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×2)
  08:57:25.861 [front-end] Received response: "{\"firstName\":\"wWVXfxc\",\"lastName\":\"wWVXfxc\",\"username\":\"wWVXfxc\",\"id\":\"674198e3a437380001deffb3\",\"_links\":{\"addresses\":{
  08:57:27.390 [front-end] Order response: {"id":"674198f73f77060008865397","customerId":"674198eaa437380001deffc4","customer":{"id":null,"firstName":"JCYeKSjM","lastName":"JCYeKSjM","use
  08:57:30.231 [front-end] Received response: "{\"firstName\":\"ltRDZ\",\"lastName\":\"ltRDZ\",\"username\":\"ltRDZ\",\"id\":\"674198dfa437380001deffab\",\"_links\":{\"addresses\":{\"href
  08:57:30.964 [user] ts=2024-11-23T08:57:30.964481457Z caller=middlewares.go:46 method=Register username=YKtzb email=YKtzb@gmail.com took=2.402772ms
  08:57:33.963 [front-end] Order response: {"statusCode":201,"body":{"id":"674198fd3f7706000886539d","customerId":"674198eda437380001deffcd","customer":{"id":null,"firstName":"lKilrPhwmDT
  08:57:35.913 [user] ts=2024-11-23T08:57:35.913548175Z caller=middlewares.go:46 method=Register username=KxeHJrfV email=KxeHJrfV@gmail.com took=2.309395ms
  08:57:36.495 [front-end] Order response: {"statusCode":201,"body":{"id":"674199003f770600088653a1","customerId":"674198f2a437380001deffe1","customer":{"id":null,"firstName":"AdZvMNo","l
  08:57:36.937 [front-end] Order response: {"statusCode":201,"body":{"id":"674199003f770600088653a3","customerId":"674198eca437380001deffcb","customer":{"id":null,"firstName":"RLzoBPdIEDT
  08:57:37.612 [front-end] Order response: {"statusCode":201,"body":{"id":"674199013f770600088653a5","customerId":"674198e5a437380001deffb5","customer":{"id":null,"firstName":"JARRXMlClyv

## p0803
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-08T08:54:31.292Z
```
{"timestamp":1733648071292343600,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-54fv6","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-08 08:54:31.291 ERROR 1 --- [io-16346-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception\n"}
```
Same service, the 2 minutes before (oldest first):
  08:54:00.106 [ts-travel2-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×7)
  08:54:07.733 [ts-travel2-service] 2024-12-08 08:54:07.733 ERROR 1 --- [io-16346-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×7)
  08:54:07.734 [ts-travel2-service] 2024-12-08 08:54:07.733 ERROR 1 --- [io-16346-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×6)
All services, 30 seconds either side (sampled):
  08:54:01.519 [ts-admin-basic-info-service] 2024-12-08 08:54:01.519 ERROR 1 --- [io-18767-exec-6] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×15)
  08:54:01.522 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:54:01 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 500 238 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_  (×8)
  08:54:04.116 [ts-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×3)
  08:54:05.137 [ts-admin-basic-info-service] 2024-12-08 08:54:05.136 ERROR 1 --- [o-18767-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  08:54:06.793 [ts-auth-service] 2024-12-08 08:54:06.793 INFO 1 --- [io-12340-exec-8] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×4)
  08:54:07.083 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:54:07 +0800] "POST /api/v1/users/login HTTP/1.1" 200 134 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×15)
  08:54:07.210 [ts-admin-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×6)
  08:54:07.520 [ts-auth-service] 2024-12-08 08:54:07.520 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×9)
  08:54:07.734 [ts-travel2-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×9)
  08:54:08.745 [ts-order-service] 2024-12-08 08:54:08.744 ERROR 1 --- [io-12031-exec-9] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  08:54:08.747 [ts-route-mongo] {"t":{"$date":"2024-12-08T08:54:08.747+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364804
  08:54:09.836 [ts-auth-mongo] {"t":{"$date":"2024-12-08T08:54:09.835+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364804
  08:54:09.906 [ts-user-mongo] {"t":{"$date":"2024-12-08T08:54:09.906+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364804
  08:54:10.025 [ts-station-mongo] {"t":{"$date":"2024-12-08T08:54:10.025+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364805
  08:54:10.126 [ts-config-mongo] {"t":{"$date":"2024-12-08T08:54:10.126+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364805
  08:54:10.395 [ts-auth-service] 2024-12-08 08:54:10.395 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×2)
  08:54:11.152 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-08T08:54:11.152+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364805
  08:54:11.778 [ts-assurance-mongo] {"t":{"$date":"2024-12-08T08:54:11.778+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364805
  08:54:12.634 [ts-food-map-mongo] {"t":{"$date":"2024-12-08T08:54:12.633+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364805
  08:54:13.183 [ts-consign-mongo] {"t":{"$date":"2024-12-08T08:54:13.183+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364805
  08:54:23.924 [ts-food-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo

## p0048
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T08:08:36.502Z
```
{"service":"dbservice1","message":"2021-08-13 08:08:36,502 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 2d6a685d2e1380b7 | 9a4178fc-fbca-11eb-b2ab-0242ac110003-DkpCcNIV-s{?DpLMc_698 token generate success token=MTYyODgxMzMxNi41MDIxODc3OjlhNDE3OGZjLWZiY2EtMTFlYi1iMmFiLTAyNDJhYzExMDAwM0RrcENjTklWc3s_RHBMTWNfNjk4OjE2Mjg4MTMzNzYuNTAyMTk4NzpkZDI2YTZhYjE1NmE0ZTU4OWUyZTRhZjA4Y2M3N2FlZg=="}
```
Same service, the 2 minutes before (oldest first):
  08:08:22.476 [dbservice1] INFO 920b69e0-fbca-11eb-ab30-0242ac110003-PvCnuEHJ-a<IPE/Kuy=io token generate success token=MTYyODgxMzMwMi40NzU4NTQ6OTIwYjY5ZTAtZmJjYS0xMWViLWFiMzAtMDI0MmFjMTE
  08:08:25.444 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:08:25.444 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  08:08:25.484 [dbservice1] INFO query = select passwards from username_table where user_name='xhrnIDOM'  (×5)
  08:08:25.565 [dbservice1] INFO 93e5a8b6-fbca-11eb-b1c0-0242ac110003-xhrnIDOM-BZQ+M*L^EHNg token generate success token=MTYyODgxMzMwNS41NjUyODM4OjkzZTVhOGI2LWZiY2EtMTFlYi1iMWMwLTAyNDJhYzE
  08:08:26.463 [dbservice1] INFO 94725b76-fbca-11eb-9693-0242ac110004-auOjVYlz-t3EAa4YQHpjM token generate success token=MTYyODgxMzMwNi40NjMwNDYzOjk0NzI1Yjc2LWZiY2EtMTFlYi05NjkzLTAyNDJhYzE
  08:08:30.471 [dbservice1] INFO 96dd970e-fbca-11eb-afa9-0242ac110003-UvLPSsVD-.<G1NWlu%(J2 token generate success token=MTYyODgxMzMxMC40NzEyOTU2Ojk2ZGQ5NzBlLWZiY2EtMTFlYi1hZmE5LTAyNDJhYzE
  08:08:33.358 [dbservice1] INFO 9889fd18-fbca-11eb-8f53-0242ac110003-kWcbAndl-+K)#TtAh_eL$ token generate success token=MTYyODgxMzMxMy4zNTc5NTQzOjk4ODlmZDE4LWZiY2EtMTFlYi04ZjUzLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  08:08:06.534 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  08:08:06.742 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×45)
  08:08:06.941 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×40)
  08:08:07.080 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×47)
  08:08:07.251 [redisservice1] INFO redis读取信息成功, status_code: 200  (×44)
  08:08:07.319 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×41)
  08:08:07.442 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×45)
  08:08:07.556 [dbservice1] INFO query = select passwards from username_table where user_name='fErgCUsY'  (×42)
  08:08:07.815 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×46)
  08:08:10.191 [mobservice1] INFO info 8aed8a30-fbca-11eb-b376-0242ac110003:GalEMmnB write success
  08:08:12.599 [dbservice1] INFO 8c35ac38-fbca-11eb-bf64-0242ac110004-iZWtCSMp-M5*>4^fm-6c) token generate success token=MTYyODgxMzI5Mi41OTg5OTc4OjhjMzVhYzM4LWZiY2EtMTFlYi1iZjY0LTAyNDJhYzE
  08:08:15.666 [mobservice2] INFO info 8e38405e-fbca-11eb-91cd-0242ac110004:vpUgXqzC write success
  08:08:18.807 [mobservice1] INFO info 9010bfa0-fbca-11eb-97c0-0242ac110003:GZqDYHLc write success
  08:08:21.884 [mobservice1] INFO info 91d9474e-fbca-11eb-bbcd-0242ac110004:mwbCGSva write success
  08:08:24.824 [mobservice1] INFO info 93b356b8-fbca-11eb-836e-0242ac110004:btlsWgLd write success
  08:08:27.603 [mobservice2] INFO info 95582dfe-fbca-11eb-8fd4-0242ac110003:wRdieUHE write success
  08:08:35.847 [mobservice2] INFO info 9a4178fc-fbca-11eb-b2ab-0242ac110003:DkpCcNIV write success
  08:08:40.396 [mobservice2] INFO info 9cfca490-fbca-11eb-947f-0242ac110004:EVBLhgrm write success
  08:08:42.696 [dbservice1] INFO 9e05b566-fbca-11eb-a1bf-0242ac110003-OxCTRwMa-k_/@Xz-^t>_M token generate success token=MTYyODgxMzMyMi42OTYwODY2OjllMDViNTY2LWZiY2EtMTFlYi1hMWJmLTAyNDJhYzE
  08:08:45.390 [mobservice1] INFO info 9ff9b106-fbca-11eb-8202-0242ac110003:ZKnXGxAN write success
  08:08:48.272 [mobservice1] INFO info a1ae338c-fbca-11eb-be73-0242ac110004:DGlMEFgf write success
  08:08:50.926 [dbservice1] INFO a306d2de-fbca-11eb-87e6-0242ac110003-hpcKRNdx-E5o4m%SA(zhR token generate success token=MTYyODgxMzMzMC45MjYwNjUyOmEzMDZkMmRlLWZiY2EtMTFlYi04N2U2LTAyNDJhYzE
  08:08:53.414 [dbservice1] INFO a475bfe0-fbca-11eb-9494-0242ac110003-nAxhWmpD-Rz0a{-P@5/:o token generate success token=MTYyODgxMzMzMy40MTQzMDUyOmE0NzViZmUwLWZiY2EtMTFlYi05NDk0LTAyNDJhYzE
  08:08:56.238 [dbservice1] INFO a63486ea-fbca-11eb-a9de-0242ac110003-mPzNQvtl-&2kNG-z9.n:M token generate success token=MTYyODgxMzMzNi4yMzg1MDQ6YTYzNDg2ZWEtZmJjYS0xMWViLWE5ZGUtMDI0MmFjMTE
  08:08:58.983 [mobservice2] INFO info a807a8ee-fbca-11eb-994e-0242ac110004:lGYXifIM write success
  08:09:01.891 [mobservice1] INFO info a9bf2d88-fbca-11eb-b7e6-0242ac110003:AGLgdhsM write success
  08:09:05.247 [dbservice1] INFO ab8e641c-fbca-11eb-b830-0242ac110003-LEFinroh-?3)7EF(w&Kpe token generate success token=MTYyODgxMzM0NS4yNDc0MDI0OmFiOGU2NDFjLWZiY2EtMTFlYi1iODMwLTAyNDJhYzE

## p0026
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T07:27:43.351Z
```
{"service":"dbservice1","message":"2021-08-13 07:27:43,351 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 7221776133e3340 | e42c6d38-fbc4-11eb-95e0-0242ac110004-SjMAKXaq-9iISt>qQZ7<X token generate success token=MTYyODgxMDg2My4zNTE0ODM2OmU0MmM2ZDM4LWZiYzQtMTFlYi05NWUwLTAyNDJhYzExMDAwNFNqTUFLWGFxOWlJU3Q-cVFaNzxYOjE2Mjg4MTA5MjMuMzUxNDk1OmNmODg2ZTU0ZTVkNjhlMTQ2NmIxMmE5MTU2YzA1M2U4"}
```
Same service, the 2 minutes before (oldest first):
  07:27:37.809 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×6)
  07:27:37.824 [dbservice1] INFO query = select passwards from username_table where user_name='EYeCRGvF'  (×5)
  07:27:37.900 [dbservice1] INFO e1013e90-fbc4-11eb-90fd-0242ac110004-EYeCRGvF-qeJXa2xuFhk0 token generate success token=MTYyODgxMDg1Ny44OTk4MDE1OmUxMDEzZTkwLWZiYzQtMTFlYi05MGZkLTAyNDJhYzE
  07:27:38.589 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  07:27:38.724 [dbservice1] INFO e183baaa-fbc4-11eb-9eea-0242ac110003-nSPeKIZU-A8Tm^z_:7_LP token generate success token=MTYyODgxMDg1OC43MjQyNDk2OmUxODNiYWFhLWZiYzQtMTFlYi05ZWVhLTAyNDJhYzE
  07:27:40.401 [dbservice1] INFO e25bab86-fbc4-11eb-8ff6-0242ac110004-TZitjmpu-mst6l#5yM=Sd token generate success token=MTYyODgxMDg2MC40MDA5NDQ1OmUyNWJhYjg2LWZiYzQtMTFlYi04ZmY2LTAyNDJhYzE
  07:27:40.474 [dbservice1] INFO e27ea2b2-fbc4-11eb-afc5-0242ac110004-pQdlTEwc-cW3>kro}_/6x token generate success token=MTYyODgxMDg2MC40NzQyMzg5OmUyN2VhMmIyLWZiYzQtMTFlYi1hZmM1LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  07:27:14.132 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×34)
  07:27:14.294 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×34)
  07:27:14.460 [mobservice2] INFO info d33fe13a-fbc4-11eb-80d2-0242ac110004:oJIvjPYZ write success
  07:27:14.579 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×39)
  07:27:14.638 [logservice1] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': 'd33fe13a-fbc4-11eb-80d2-0242ac110004', 'user_id': 'oJIvjPYZ'}  (×63)
  07:27:17.184 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×26)
  07:27:19.786 [webservice1] INFO uuid: d697a688-fbc4-11eb-960e-0242ac110003 write redis successfully  (×30)
  07:27:19.951 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'd697a688-fbc4-11eb-960e-0242ac110003'}  (×34)
  07:27:20.276 [dbservice2] INFO query = select passwards from username_table where user_name='kXfZVAUx'  (×34)
  07:27:20.997 [webservice2] ERROR an error occurred in the downstream service  (×3)
  07:27:21.555 [redisservice2] INFO redis读取信息成功, status_code: 200  (×26)
  07:27:22.204 [mobservice2] INFO info d7dbfc24-fbc4-11eb-80f4-0242ac110004:qYMpFKOS write success
  07:27:23.832 [mobservice1] INFO info d8da496e-fbc4-11eb-995e-0242ac110003:WzpeuShd write success
  07:27:25.969 [dbservice2] INFO d9dd56d0-fbc4-11eb-b3a8-0242ac110003-ITinMyWu-yv/ef>@J!O?L token generate success token=MTYyODgxMDg0NS45Njg5NzpkOWRkNTZkMC1mYmM0LTExZWItYjNhOC0wMjQyYWMxMTA
  07:27:28.187 [dbservice2] INFO db2ec596-fbc4-11eb-a7d4-0242ac110004-zfawCciR-dF$Y@Is}SMDa token generate success token=MTYyODgxMDg0OC4xODY5NzU3OmRiMmVjNTk2LWZiYzQtMTFlYi1hN2Q0LTAyNDJhYzE
  07:27:30.321 [mobservice1] INFO info dcaf424c-fbc4-11eb-b5b8-0242ac110004:HkLmPgZU write success
  07:27:31.904 [mobservice1] INFO info dda39a90-fbc4-11eb-bb04-0242ac110003:NhtsWobx write success
  07:27:34.336 [mobservice2] INFO info df150aa8-fbc4-11eb-8327-0242ac110004:ZYabGCTS write success
  07:27:35.996 [mobservice1] INFO info e014783a-fbc4-11eb-b0bb-0242ac110003:nqLzRCkG write success
  07:27:38.307 [mobservice2] INFO info e183baaa-fbc4-11eb-9eea-0242ac110003:nSPeKIZU write success
  07:27:40.401 [dbservice1] INFO e25bab86-fbc4-11eb-8ff6-0242ac110004-TZitjmpu-mst6l#5yM=Sd token generate success token=MTYyODgxMDg2MC40MDA5NDQ1OmUyNWJhYjg2LWZiYzQtMTFlYi04ZmY2LTAyNDJhYzE
  07:27:49.073 [dbservice1] INFO e7a78222-fbc4-11eb-868a-0242ac110004-vyNKmojf-tObRnCdzeI&j token generate success token=MTYyODgxMDg2OS4wNzI5NDY1OmU3YTc4MjIyLWZiYzQtMTFlYi04NjhhLTAyNDJhYzE
  07:27:50.593 [mobservice2] INFO info e8c9a3c4-fbc4-11eb-a2be-0242ac110004:iBnyvbLP write success
  07:27:52.198 [mobservice2] INFO info e9c35496-fbc4-11eb-947a-0242ac110003:PYaoLpfS write success
  07:27:54.441 [mobservice1] INFO info eb0a4eb8-fbc4-11eb-8485-0242ac110004:UEASdwYn write success
  07:27:56.287 [mobservice1] INFO info ec19e980-fbc4-11eb-99c3-0242ac110004:vYsiTgru write success
  07:27:58.074 [mobservice1] INFO info ed261a10-fbc4-11eb-9bcb-0242ac110004:ocwNidgD write success
  07:28:00.557 [dbservice1] INFO ee833866-fbc4-11eb-8043-0242ac110003-SpsReQKd-%f.?Hm2-yCzl token generate success token=MTYyODgxMDg4MC41NTY2ODgzOmVlODMzODY2LWZiYzQtMTFlYi04MDQzLTAyNDJhYzE
  07:28:02.837 [dbservice1] INFO efdf7ac6-fbc4-11eb-be88-0242ac110004-wkgeEpUD-oq&=dQCzk7R4 token generate success token=MTYyODgxMDg4Mi44MzczOTg4OmVmZGY3YWM2LWZiYzQtMTFlYi1iZTg4LTAyNDJhYzE
  07:28:06.149 [dbservice2] INFO f1d6e59e-fbc4-11eb-8949-0242ac110004-qepNbChc-fH.oSuxnyI{B token generate success token=MTYyODgxMDg4Ni4xNDkyNjI0OmYxZDZlNTllLWZiYzQtMTFlYi04OTQ5LTAyNDJhYzE

## p0760
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T06:35:38.387Z
```
{"timestamp":1732257338387645700,"container_name":"carts","pod_name":"carts-6cdcbc6cd7-kqnt9","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 06:35:38.387  INFO [carts,,,] 7 --- [           main] org.mongodb.driver.cluster               : Cluster created with settings {hosts=[carts-db:27017], mode=SINGLE, requiredClusterType=UNKNOWN, serverSelectionTimeout='10000 ms', maxWaitQueueSize=500}"}
```
Same service, the 2 minutes before (oldest first):
  06:35:04.091 [carts] 2024-11-22 06:35:04.091 WARN [carts,,,] 7 --- [ main] o.s.c.a.ConfigurationClassPostProcessor : Cannot enhance @Configuration bean definition 'refreshScope' sin
  06:35:06.590 [carts] 2024-11-22 06:35:06.589 INFO [carts,,,] 7 --- [ main] o.s.cloud.context.scope.GenericScope : BeanFactory id=063d23b5-fa4f-330e-8afb-cdf6f03b608e
  06:35:08.586 [carts] 2024-11-22 06:35:08.586 INFO [carts,,,] 7 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.cloud.sleuth.instrument.async.AsyncDe
  06:35:12.891 [carts] 2024-11-22 06:35:12.890 INFO [carts,,,] 7 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.cloud.autoconfigure.ConfigurationProp
  06:35:13.285 [carts] 2024-11-22 06:35:13.284 INFO [carts,,,] 7 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.cloud.sleuth.instrument.web.TraceWebA
  06:35:21.895 [carts] 2024-11-22 06:35:21.894 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 80 (http)
  06:35:22.188 [carts] 2024-11-22 06:35:22.188 INFO [carts,,,] 7 --- [ main] o.apache.catalina.core.StandardService : Starting service Tomcat
  06:35:22.284 [carts] 2024-11-22 06:35:22.284 INFO [carts,,,] 7 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.11
  06:35:23.486 [carts] 2024-11-22 06:35:23.485 INFO [carts,,,] 7 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  06:35:23.486 [carts] 2024-11-22 06:35:23.486 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 42000 ms
  06:35:34.884 [carts] 2024-11-22 06:35:34.883 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricsFilter' to: [/*]  (×7)
  06:35:34.884 [carts] 2024-11-22 06:35:34.884 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.c.embedded.FilterRegistrationBean : Mapping filter: 'traceFilter' to: [/*]
  06:35:34.885 [carts] 2024-11-22 06:35:34.885 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'metricsServlet' to [/metrics]
  06:35:34.887 [carts] 2024-11-22 06:35:34.887 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
All services, 30 seconds either side (sampled):
  06:35:08.406 [front-end] Request received with body: {}  (×59)
  06:35:08.436 [user] ts=2024-11-22T06:35:08.435921586Z caller=middlewares.go:134 method=GetCards id=67402610768f35000114f1bf result=1 took=2.619155ms  (×59)
  06:35:08.532 [payment] ts=2024-11-22T06:35:08Z caller=logging.go:40 method=Health result=1 took=5.355µs  (×40)
  06:35:09.323 [front-end] 6740261d768f35000114f1f3  (×60)
  06:35:09.843 [front-end] Received response: "{\"firstName\":\"bLeDcg\",\"lastName\":\"bLeDcg\",\"username\":\"bLeDcg\",\"id\":\"67402609768f35000114f1ab\",\"_links\":{\"addresses\":{\"h
  06:35:10.037 [user] ts=2024-11-22T06:35:10.03720374Z caller=middlewares.go:46 method=Register username=PUFmTDZ email=PUFmTDZ@gmail.com took=1.967552ms
  06:35:10.092 [front-end] POST /cart 500 19.238 ms - 64  (×57)
  06:35:12.891 [carts] 2024-11-22 06:35:12.890 INFO [carts,,,] 7 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.cloud.autoconfigure.ConfigurationProp
  06:35:14.342 [front-end] Posting Customer: {"username":"kjAdzbkAAN","password":"ocncI","email":"kjAdzbkAAN@gmail.com","firstName":"kjAdzbkAAN","lastName":"kjAdzbkAAN"}
  06:35:16.126 [front-end] Posting Customer: {"username":"PYhbcWJsj","password":"ZyMkPPhoA","email":"PYhbcWJsj@gmail.com","firstName":"PYhbcWJsj","lastName":"PYhbcWJsj"}
  06:35:18.308 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×7)
  06:35:21.895 [carts] 2024-11-22 06:35:21.894 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 80 (http)
  06:35:22.775 [user] ts=2024-11-22T06:35:22.775394362Z caller=middlewares.go:46 method=Register username=GPfzqV email=GPfzqV@gmail.com took=3.253773ms
  06:35:24.374 [front-end] Received response: "{\"firstName\":\"BDLKCzZJHIu\",\"lastName\":\"BDLKCzZJHIu\",\"username\":\"BDLKCzZJHIu\",\"id\":\"67402617768f35000114f1dc\",\"_links\":{\"a
  06:35:29.994 [front-end] Posting Customer: {"username":"nkDFO","password":"mTZln","email":"nkDFO@gmail.com","firstName":"nkDFO","lastName":"nkDFO"}
  06:35:32.416 [front-end] Received response: "{\"firstName\":\"PYhbcWJsj\",\"lastName\":\"PYhbcWJsj\",\"username\":\"PYhbcWJsj\",\"id\":\"67402624768f35000114f206\",\"_links\":{\"address
  06:35:35.627 [front-end] Received response: "{\"firstName\":\"nQHEd\",\"lastName\":\"nQHEd\",\"username\":\"nQHEd\",\"id\":\"67402625768f35000114f209\",\"_links\":{\"addresses\":{\"href
  06:35:38.928 [front-end] Received response: "{\"firstName\":\"OeWGgPkPne\",\"lastName\":\"OeWGgPkPne\",\"username\":\"OeWGgPkPne\",\"id\":\"67402622768f35000114f200\",\"_links\":{\"addr
  06:35:40.909 [orders-db] {"t":{"$date":"2024-11-22T06:35:40.908+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173225734
  06:35:42.941 [front-end] Received response: "{\"firstName\":\"bazQUsmjddKzl\",\"lastName\":\"bazQUsmjddKzl\",\"username\":\"bazQUsmjddKzl\",\"id\":\"67402629768f35000114f210\",\"_links\
  06:35:46.551 [front-end] Received response: "{\"firstName\":\"uFkQeSxWtoEnw\",\"lastName\":\"uFkQeSxWtoEnw\",\"username\":\"uFkQeSxWtoEnw\",\"id\":\"6740262b768f35000114f21a\",\"_links\
  06:35:50.262 [front-end] Received response: "{\"firstName\":\"uUlYxuBMHTWeVX\",\"lastName\":\"uUlYxuBMHTWeVX\",\"username\":\"uUlYxuBMHTWeVX\",\"id\":\"67402636768f35000114f237\",\"_lin
  06:35:52.389 [front-end] Posting Customer: {"username":"pKluDm","password":"tvULC","email":"pKluDm@gmail.com","firstName":"pKluDm","lastName":"pKluDm"}
  06:35:53.713 [front-end] Received response: "{\"firstName\":\"lPJMFb\",\"lastName\":\"lPJMFb\",\"username\":\"lPJMFb\",\"id\":\"67402638768f35000114f23b\",\"_links\":{\"addresses\":{\"h
  06:35:56.914 [user] ts=2024-11-22T06:35:56.913943191Z caller=middlewares.go:46 method=Register username=jXGQWkWVU email=jXGQWkWVU@gmail.com took=2.370047ms
  06:35:59.751 [user] ts=2024-11-22T06:35:59.751447194Z caller=middlewares.go:46 method=Register username=EXgBv email=EXgBv@gmail.com took=2.217626ms
  06:36:01.032 [user] ts=2024-11-22T06:36:01.032554917Z caller=middlewares.go:46 method=Register username=GFDGHAQNB email=GFDGHAQNB@gmail.com took=2.949412ms
  06:36:05.059 [front-end] Received response: "{\"firstName\":\"szNEwlf\",\"lastName\":\"szNEwlf\",\"username\":\"szNEwlf\",\"id\":\"67402645768f35000114f260\",\"_links\":{\"addresses\":{

## p0066
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T08:56:43.395Z
```
{"service":"dbservice1","message":"2021-08-13 08:56:43,395 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | d222cfa9a87f5c73 | 5324da98-fbd1-11eb-8452-0242ac110003-AkMRXwoH-{X3w%&jNaR_s token generate success token=MTYyODgxNjIwMy4zOTUwOTM0OjUzMjRkYTk4LWZiZDEtMTFlYi04NDUyLTAyNDJhYzExMDAwM0FrTVJYd29Ie1gzdyUmak5hUl9zOjE2Mjg4MTYyNjMuMzk1MTA0NDpmZTMxMWM3Y2Y0MGNhOGFkZjYwNzRkMmZjOTdmNzRiNg=="}
```
Same service, the 2 minutes before (oldest first):
  08:56:35.657 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  08:56:39.340 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:56:39.340 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  08:56:39.359 [dbservice1] INFO query = select passwards from username_table where user_name='xjYUMcml'  (×5)
  08:56:39.435 [dbservice1] INFO 50c64ade-fbd1-11eb-a9a0-0242ac110003-xjYUMcml-^4(_{v<kmK}e token generate success token=MTYyODgxNjE5OS40MzUxNzM3OjUwYzY0YWRlLWZiZDEtMTFlYi1hOWEwLTAyNDJhYzE
  08:56:40.632 [dbservice1] INFO 517a85da-fbd1-11eb-8af5-0242ac110004-mMWStTBy-K=7!ICE-naiw token generate success token=MTYyODgxNjIwMC42MzE5NjI6NTE3YTg1ZGEtZmJkMS0xMWViLThhZjUtMDI0MmFjMTE
  08:56:41.715 [dbservice1] INFO 52202b84-fbd1-11eb-882b-0242ac110003-HSRAIxlj-CuIYqAwN&?x) token generate success token=MTYyODgxNjIwMS43MTUxMTc1OjUyMjAyYjg0LWZiZDEtMTFlYi04ODJiLTAyNDJhYzE
  08:56:42.476 [dbservice1] INFO 529e744e-fbd1-11eb-b027-0242ac110004-ZDqHGEXv-$Fe*7dcf0>Yv token generate success token=MTYyODgxNjIwMi40NzY0NjQ3OjUyOWU3NDRlLWZiZDEtMTFlYi1iMDI3LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  08:56:13.449 [redisservice1] INFO redis write success  (×101)
  08:56:13.623 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×49)
  08:56:13.728 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×50)
  08:56:13.859 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '41f82040-fbd1-11eb-b7a2-0242ac110003', 'value': '', 'ex': 10}  (×49)
  08:56:14.138 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×53)
  08:56:14.656 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×50)
  08:56:14.894 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×46)
  08:56:15.124 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '427bfbcc-fbd1-11eb-bd05-0242ac110003'}  (×51)
  08:56:15.395 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×52)
  08:56:16.552 [mobservice1] INFO info 4366652c-fbd1-11eb-a61c-0242ac110004:bypSvsJC write success
  08:56:20.279 [mobservice1] INFO info 459e064c-fbd1-11eb-94c8-0242ac110004:OYPSuZEk write success
  08:56:23.525 [mobservice1] INFO info 4789ad30-fbd1-11eb-a961-0242ac110003:rwdmTblM write success
  08:56:26.371 [mobservice2] INFO info 492c04da-fbd1-11eb-a9a9-0242ac110003:ZQXfBztT write success
  08:56:29.486 [mobservice2] INFO info 4b126fd2-fbd1-11eb-90f4-0242ac110004:wRdieUHE write success
  08:56:32.314 [dbservice1] INFO 4c6f0eda-fbd1-11eb-8de8-0242ac110003-TEzNtqXJ-hX%YBAgR(yzj token generate success token=MTYyODgxNjE5Mi4zMTM3NjQ4OjRjNmYwZWRhLWZiZDEtMTFlYi04ZGU4LTAyNDJhYzE
  08:56:35.164 [mobservice1] INFO info 4e7f3e7a-fbd1-11eb-bbc5-0242ac110004:LVQPlZAt write success
  08:56:39.041 [mobservice1] INFO info 50c64ade-fbd1-11eb-a9a0-0242ac110003:xjYUMcml write success
  08:56:42.120 [mobservice2] INFO info 529e744e-fbd1-11eb-b027-0242ac110004:ZDqHGEXv write success
  08:56:44.994 [mobservice2] INFO info 54502e36-fbd1-11eb-8307-0242ac110003:zoVLGdbn write success
  08:56:47.663 [mobservice2] INFO info 55de8e3c-fbd1-11eb-9280-0242ac110003:rJyVYctH write success
  08:56:51.311 [mobservice1] INFO info 5817c34e-fbd1-11eb-a673-0242ac110003:pvKgfqae write success
  08:56:54.088 [mobservice1] INFO info 59bd3396-fbd1-11eb-b9ff-0242ac110003:tWbvgBRJ write success
  08:56:56.340 [mobservice1] INFO info 5b1b2644-fbd1-11eb-9c67-0242ac110004:uLFWxbvM write success
  08:56:59.138 [mobservice1] INFO info 5cc5af50-fbd1-11eb-92cf-0242ac110003:laVNGIPf write success
  08:57:01.043 [dbservice1] INFO 5db1ffe0-fbd1-11eb-b782-0242ac110004-QgokVGXf-IJbkFjEAl(-K token generate success token=MTYyODgxNjIyMS4wNDMwOTE6NWRiMWZmZTAtZmJkMS0xMWViLWI3ODItMDI0MmFjMTE
  08:57:03.897 [mobservice2] INFO info 5f8de40a-fbd1-11eb-9103-0242ac110003:mVtTqAor write success
  08:57:06.902 [mobservice1] INFO info 616203c4-fbd1-11eb-9d6c-0242ac110003:lTpNeXrC write success
  08:57:09.445 [mobservice2] INFO info 62e6964c-fbd1-11eb-8423-0242ac110004:bAuaLHTx write success
  08:57:11.903 [dbservice1] INFO 641e18a0-fbd1-11eb-9c53-0242ac110003-cwbxRDST-+!NhXiR:qd?D token generate success token=MTYyODgxNjIzMS45MDI5NzY6NjQxZTE4YTAtZmJkMS0xMWViLTljNTMtMDI0MmFjMTE

## p0560
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T18:28:09.750Z
```
{"timestamp":1733596089750632700,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-ndkkb","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 18:28:09.749  INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl             : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainNumber='Z1234', startStation='shanghai', destStation='nanjing', seatType=2}"}
```
Same service, the 2 minutes before (oldest first):
  18:28:06.931 [ts-seat-service] 2024-12-07 18:28:06.930 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×3)
  18:28:06.942 [ts-seat-service] 2024-12-07 18:28:06.942 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×3)
  18:28:06.954 [ts-seat-service] 2024-12-07 18:28:06.953 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×3)
  18:28:06.971 [ts-seat-service] 2024-12-07 18:28:06.971 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×3)
  18:28:06.971 [ts-seat-service] 2024-12-07 18:28:06.971 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  18:28:06.980 [ts-seat-service] 2024-12-07 18:28:06.979 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  18:28:09.285 [ts-seat-service] 2024-12-07 18:28:09.284 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×2)
  18:28:09.319 [ts-seat-service] 2024-12-07 18:28:09.318 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
All services, 30 seconds either side (sampled):
  18:27:39.933 [ts-auth-service] 2024-12-07 18:27:39.932 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×10)
  18:27:40.238 [ts-travel2-service] 2024-12-07 18:27:40.238 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×144)
  18:27:40.290 [ts-basic-service] 2024-12-07 18:27:40.290 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×9)
  18:27:40.383 [ts-seat-service] 2024-12-07 18:27:40.382 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×25)
  18:27:40.430 [ts-seat-service] 2024-12-07 18:27:40.430 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×36)
  18:27:41.997 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T18:27:41.996+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359606
  18:27:43.631 [ts-travel-service] 2024-12-07 18:27:43.631 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×52)
  18:27:43.739 [ts-seat-service] 2024-12-07 18:27:43.739 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×11)
  18:27:43.873 [ts-seat-service] 2024-12-07 18:27:43.872 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da
  18:27:43.928 [ts-travel-service] 2024-12-07 18:27:43.928 INFO 1 --- [io-12346-exec-1] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  18:27:43.970 [ts-basic-service] 2024-12-07 18:27:43.970 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×8)
  18:27:44.335 [ts-basic-service] 2024-12-07 18:27:44.334 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×3)
  18:27:47.695 [ts-order-other-service] 2024-12-07 18:27:47.695 INFO 1 --- [io-12032-exec-5] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou  (×2)
  18:27:49.027 [ts-seat-service] 2024-12-07 18:27:49.027 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×7)
  18:27:54.389 [ts-admin-travel-service] 2024-12-07 18:27:54.389 INFO 1 --- [io-16114-exec-2] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×12)
  18:27:58.183 [ts-travel-service] 2024-12-07 18:27:58.183 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d  (×6)
  18:28:09.152 [ts-order-other-service] 2024-12-07 18:28:09.152 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×2)
  18:28:09.493 [ts-preserve-other-service] 2024-12-07 18:28:09.493 INFO 1 --- [o-14569-exec-10] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security
  18:28:09.534 [ts-security-service] 2024-12-07 18:28:09.534 INFO 1 --- [io-11188-exec-8] security.service.SecurityServiceImpl : [Security Service][Get Security Config Info]
  18:28:09.584 [ts-preserve-other-service] 2024-12-07 18:28:09.584 INFO 1 --- [o-14569-exec-10] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Check tickets num
  18:28:09.975 [ts-preserve-other-service] 2024-12-07 18:28:09.975 INFO 1 --- [o-14569-exec-10] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order] Order Travel Date: Sat Dec 07 00:00:00
  18:28:10.034 [ts-order-other-service] 2024-12-07 18:28:10.033 INFO 1 --- [io-12032-exec-8] other.controller.OrderOtherController : [Order Other Service][Verify Login] Success
  18:28:10.061 [ts-preserve-other-service] 2024-12-07 18:28:10.061 INFO 1 --- [o-14569-exec-10] p.service.PreserveOtherServiceImpl : [Preserve Service]
  18:28:18.722 [ts-consign-service] 2024-12-07 18:28:18.722 INFO 1 --- [io-16111-exec-7] consign.service.ConsignServiceImpl : Order ID is :a24988bc-43ba-4540-bb12-f150a3abb1af
  18:28:20.770 [ts-travel-service] 2024-12-07 18:28:20.770 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×7)
  18:28:20.958 [ts-travel-service] 2024-12-07 18:28:20.958 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×6)
  18:28:27.450 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-07T18:28:27.450+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359610
  18:28:30.390 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T18:28:30.390+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359611

## p0691
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-12T08:22:22.343Z
```
{"service":"mobservice2","message":"2021-08-12 08:22:22,343 | WARNING | 0.0.0.4 | mobservice2 | mob_helper.py -> mob_info_to_redis -> 31 | 5f0c36f73a9b4785 | wait for 11 seconds for follow-up operations to simulate the login failure of the QR code expired"}
```
Same service, the 2 minutes before (oldest first):
  08:22:17.453 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  08:22:17.453 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  08:22:17.454 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '599fa17e-fb03-11eb-82b5-0242ac110003'}  (×4)
  08:22:17.515 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '599fa17e-fb03-11eb-82b5-0242ac110003', 'value': 'evnbrmSs'}  (×4)
  08:22:17.557 [mobservice2] INFO info 599fa17e-fb03-11eb-82b5-0242ac110003:evnbrmSs write success
  08:22:19.170 [mobservice2] INFO info 5a98a102-fb03-11eb-ad47-0242ac110004:uyXNixVj write success
  08:22:19.990 [mobservice2] INFO info 5b0f5afe-fb03-11eb-9b80-0242ac110003:HTxraybW write success
  08:22:21.517 [mobservice2] INFO info 5bfc4f9e-fb03-11eb-bc97-0242ac110003:dsqULkKQ write success
All services, 30 seconds either side (sampled):
  08:21:52.361 [redisservice1] INFO redis write success  (×75)
  08:21:52.485 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×46)
  08:21:52.596 [redisservice2] INFO service accept, status_code: 200  (×46)
  08:21:52.938 [webservice1] INFO complete information: {'uuid': '4b0f7364-fb03-11eb-9cc9-0242ac110003', 'user_id': 'JUvKDVWZ'}  (×38)
  08:21:53.070 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×35)
  08:21:53.303 [webservice2] INFO uuid: 4b526d22-fb03-11eb-988c-0242ac110004 write redis successfully  (×41)
  08:21:53.506 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '4b526d22-fb03-11eb-988c-0242ac110004'}  (×36)
  08:21:53.911 [dbservice1] INFO query = select passwards from username_table where user_name='YKwDOXcq'  (×28)
  08:21:54.155 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×32)
  08:21:55.890 [dbservice2] INFO 4c854160-fb03-11eb-92da-0242ac110003-PuHhfCZO-GImoA>p7EnU6 token generate success token=MTYyODcyNzcxNS44OTAzNjc6NGM4NTQxNjAtZmIwMy0xMWViLTkyZGEtMDI0MmFjMTE
  08:21:58.021 [mobservice1] INFO info 4dfb69ca-fb03-11eb-8ea0-0242ac110004:dQcykLhj write success
  08:22:00.126 [dbservice1] INFO 4efbc216-fb03-11eb-b352-0242ac110003-ISmxpnEs--5/4Hwoa@2dU token generate success token=MTYyODcyNzcyMC4xMjYzODQ6NGVmYmMyMTYtZmIwMy0xMWViLWIzNTItMDI0MmFjMTE
  08:22:02.483 [mobservice2] INFO info 5091fc4e-fb03-11eb-bf26-0242ac110003:pkIFrtAz write success
  08:22:04.540 [webservice2] ERROR an error occurred in the downstream service
  08:22:06.656 [mobservice2] INFO info 531f17d0-fb03-11eb-b9fe-0242ac110003:aFPAvDqO write success
  08:22:08.771 [dbservice2] INFO 542fc80e-fb03-11eb-bfe5-0242ac110003-McTYFJZL-%V$y^s+B#Qo* token generate success token=MTYyODcyNzcyOC43NzEzODY5OjU0MmZjODBlLWZiMDMtMTFlYi1iZmU1LTAyNDJhYzE
  08:22:11.321 [dbservice1] INFO 559e895a-fb03-11eb-8dc1-0242ac110003-EVBLhgrm-9os/__E:hq47 token generate success token=MTYyODcyNzczMS4zMjA3NjYyOjU1OWU4OTVhLWZiMDMtMTFlYi04ZGMxLTAyNDJhYzE
  08:22:13.853 [mobservice1] INFO info 575ddb6a-fb03-11eb-bfff-0242ac110003:NuWOPqyE write success
  08:22:16.008 [mobservice1] INFO info 58b08418-fb03-11eb-af4d-0242ac110004:VpEUCejs write success
  08:22:17.894 [dbservice1] INFO 599fa17e-fb03-11eb-82b5-0242ac110003-evnbrmSs-gom=Yi$#jkD3 token generate success token=MTYyODcyNzczNy44OTQ0ODgzOjU5OWZhMTdlLWZiMDMtMTFlYi04MmI1LTAyNDJhYzE
  08:22:19.990 [mobservice2] INFO info 5b0f5afe-fb03-11eb-9b80-0242ac110003:HTxraybW write success
  08:22:22.772 [dbservice2] INFO 5c80a0d2-fb03-11eb-a95f-0242ac110004-UHcqgbTI-JH<T8XNfd/>@ token generate success token=MTYyODcyNzc0Mi43NzIyMTM1OjVjODBhMGQyLWZiMDMtMTFlYi1hOTVmLTAyNDJhYzE
  08:22:33.429 [redisservice1] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400  (×2)
  08:22:34.482 [dbservice2] INFO 6372692a-fb03-11eb-87a1-0242ac110003-zrnyoxBF-Sbqp@TrH_P6c token generate success token=MTYyODcyNzc1NC40ODE5NjY3OjYzNzI2OTJhLWZiMDMtMTFlYi04N2ExLTAyNDJhYzE
  08:22:37.195 [dbservice2] INFO 65179e08-fb03-11eb-8f26-0242ac110003-NGJTlZWq-Ke:g$c+JP/iq token generate success token=MTYyODcyNzc1Ny4xOTQ1Mzo2NTE3OWUwOC1mYjAzLTExZWItOGYyNi0wMjQyYWMxMTA
  08:22:39.794 [dbservice1] INFO 66ae37d6-fb03-11eb-8e14-0242ac110004-lkNrGYTL-S$afkB0(o_gn token generate success token=MTYyODcyNzc1OS43OTQxNjg6NjZhZTM3ZDYtZmIwMy0xMWViLThlMTQtMDI0MmFjMTE
  08:22:42.268 [dbservice2] INFO 68259906-fb03-11eb-ae33-0242ac110004-FvDqslOC-J$0(?)uHF_Z. token generate success token=MTYyODcyNzc2Mi4yNjgyNTI4OjY4MjU5OTA2LWZiMDMtMTFlYi1hZTMzLTAyNDJhYzE
  08:22:44.951 [dbservice2] INFO 69b38422-fb03-11eb-9962-0242ac110004-avTqnNxg-L$C9/.km:^B% token generate success token=MTYyODcyNzc2NC45NTE0ODI6NjliMzg0MjItZmIwMy0xMWViLTk5NjItMDI0MmFjMTE
  08:22:48.181 [mobservice2] INFO info 6be1f030-fb03-11eb-8232-0242ac110003:EVjMdevk write success
  08:22:50.284 [dbservice2] INFO 6ce968be-fb03-11eb-a7e1-0242ac110003-CfHjswnr-5atn1@V=8r4l token generate success token=MTYyODcyNzc3MC4yODQyNjc6NmNlOTY4YmUtZmIwMy0xMWViLWE3ZTEtMDI0MmFjMTE

## p0531
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T11:00:29.307Z
```
{"timestamp":1732359629307755300,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 11:00:29.307  INFO [carts,588f253ce7379f0e,463a5a820ad6005e,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.CartsController   : Merge carts request received for ids: 6741b5cda437380001df54c0 and lZi8ze0L37QmX3XWXoMvbm-9aaVTtAgD"}
```
Same service, the 2 minutes before (oldest first):
  11:00:24.752 [carts] 2024-11-23 11:00:24.752 INFO [carts,d899cb021860ba8b,a1d35d29289a94b3,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×6)
  11:00:25.211 [carts] 2024-11-23 11:00:25.210 INFO [carts,5741a60c85d1cb89,22f99bcade041e88,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.ItemsController : Did not find item.  (×3)
  11:00:25.220 [carts] 2024-11-23 11:00:25.220 INFO [carts,5741a60c85d1cb89,22f99bcade041e88,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×3)
  11:00:26.021 [carts] 2024-11-23 11:00:26.021 INFO [carts,93d7a7478b285e79,133f2cff44060101,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.controllers.CartsController : Merge carts reques  (×4)
  11:00:27.061 [carts] 2024-11-23 11:00:27.060 INFO [carts,0dfb18af5ba50ca6,6093f0e2255ea06a,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  11:00:27.070 [carts] 2024-11-23 11:00:27.070 INFO [carts,0dfb18af5ba50ca6,6093f0e2255ea06a,false] 7 --- [-nio-80-exec-16] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
All services, 30 seconds either side (sampled):
  11:00:00.384 [catalogue] ts=2024-11-23T11:00:00Z caller=logging.go:85 method=Health result=2 took=26.664µs  (×40)
  11:00:11.544 [front-end] Posting Customer: {"username":"RupAdllGjrdNv","password":"zJBnIlEK","email":"RupAdllGjrdNv@gmail.com","firstName":"RupAdllGjrdNv","lastName":"RupAdllGjrdNv"}
  11:00:11.565 [carts] 2024-11-23 11:00:11.564 INFO [carts,5a2e21a486490bc1,97896900cee9f8fe,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.CartsController : Merge carts reques  (×17)
  11:00:12.740 [front-end] Posting Customer: {"username":"hYeBtEGlGq","password":"fSKDYUx","email":"hYeBtEGlGq@gmail.com","firstName":"hYeBtEGlGq","lastName":"hYeBtEGlGq"}
  11:00:14.745 [front-end] Posting Customer: {"username":"XNHqPsYlIlUw","password":"brpClEgE","email":"XNHqPsYlIlUw@gmail.com","firstName":"XNHqPsYlIlUw","lastName":"XNHqPsYlIlUw"}
  11:00:16.620 [front-end] POST /addresses 200 - ms - -  (×18)
  11:00:16.717 [front-end] User cart deleted with status: 202  (×17)
  11:00:16.737 [front-end] POST to carts: http://carts/carts/6741b5bba437380001df548b/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×8)
  11:00:16.816 [user] ts=2024-11-23T11:00:16.816230287Z caller=middlewares.go:46 method=Register username=ZYyOEosw email=ZYyOEosw@gmail.com took=2.034356ms
  11:00:19.981 [front-end] POST to carts: http://carts/carts/6741b5bda437380001df548d/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}  (×9)
  11:00:20.710 [front-end] Posting Customer: {"username":"eciSh","password":"ncDSTD","email":"eciSh@gmail.com","firstName":"eciSh","lastName":"eciSh"}
  11:00:21.686 [front-end] Posting Customer: {"username":"AtPqbXfAZp","password":"EpoZfUN","email":"AtPqbXfAZp@gmail.com","firstName":"AtPqbXfAZp","lastName":"AtPqbXfAZp"}
  11:00:23.865 [catalogue] ts=2024-11-23T11:00:23Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=4.81605m
  11:00:24.738 [front-end] Posting Customer: {"username":"HOLUtFoSuMcUtKu","password":"taAJbEDhs","email":"HOLUtFoSuMcUtKu@gmail.com","firstName":"HOLUtFoSuMcUtKu","lastName":"HOLUtFoSuMc
  11:00:26.495 [orders-db] {"t":{"$date":"2024-11-23T11:00:26.495+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235962
  11:00:27.232 [user] ts=2024-11-23T11:00:27.232650455Z caller=middlewares.go:46 method=Register username=ZloLZze email=ZloLZze@gmail.com took=3.095882ms
  11:00:28.716 [user] ts=2024-11-23T11:00:28.715850808Z caller=middlewares.go:46 method=Register username=LomuEmw email=LomuEmw@gmail.com took=2.094766ms
  11:00:29.613 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  11:00:31.625 [front-end] Posting Customer: {"username":"rbqXF","password":"pcPTGVfA","email":"rbqXF@gmail.com","firstName":"rbqXF","lastName":"rbqXF"}
  11:00:32.066 [front-end] GET Request to: http://user/customers/6741b5bda437380001df548d/addresses  (×4)
  11:00:32.083 [front-end] Received response: "{\"firstName\":\"XNHqPsYlIlUw\",\"lastName\":\"XNHqPsYlIlUw\",\"username\":\"XNHqPsYlIlUw\",\"id\":\"6741b5bea437380001df548f\",\"_links\":{
  11:00:32.150 [orders] 2024-11-23 11:00:32.150 INFO [orders,5a6a0af7afe1a8a3,d3020c3723661a9c,false] 7 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Received payment re
  11:00:32.160 [queue-master] 2024-11-23 11:00:32.160 INFO 7 --- [ool-6-thread-23] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×6)
  11:00:32.165 [front-end] Order response: undefined
  11:00:32.178 [front-end] npm timing command:run-script Completed in 44217ms
  11:00:32.180 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!

## p0655
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-11T05:35:47.508Z
```
{"service":"dbservice2","message":"2021-08-11 05:35:47,508 | ERROR | 0.0.0.2 | 172.17.0.2 | dbservice2 | 88bed53fe71b7671 | (pymysql.err.ProgrammingError) (1146, \"Table 'cloudwise_micross.system_metric_datas' doesn't exist\")[SQL: select service_names, system_data_time, system_cpu_utilization, system_memory_usage,system_disk_usage, disk_io_read_count, disk_io_write_count,system_network, network_io_read_count, network_io_write_count …"}
```
Same service, the 2 minutes before (oldest first):
  05:35:42.990 [dbservice2] INFO query = select passwards from username_table where user_name='hBdYEDwt'  (×5)
  05:35:43.067 [dbservice2] INFO e9be4260-fa22-11eb-a88b-0242ac110003-hBdYEDwt-ji?=FL!1P:b> token generate success token=MTYyODYzMTM0My4wNjY2NjY6ZTliZTQyNjAtZmEyMi0xMWViLWE4OGItMDI0MmFjMTE
  05:35:43.768 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  05:35:43.768 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  05:35:43.900 [dbservice2] INFO ea490f08-fa22-11eb-9274-0242ac110003-dneSsIED-8P7mNRZk<p&e token generate success token=MTYyODYzMTM0My44OTk4ODY2OmVhNDkwZjA4LWZhMjItMTFlYi05Mjc0LTAyNDJhYzE
  05:35:44.318 [dbservice2] INFO ea85f9d6-fa22-11eb-bdec-0242ac110004-HxQpIWMr-prs7#j4K0Dz1 token generate success token=MTYyODYzMTM0NC4zMTgwNzQ1OmVhODVmOWQ2LWZhMjItMTFlYi1iZGVjLTAyNDJhYzE
  05:35:46.326 [dbservice2] INFO ebc17cf8-fa22-11eb-8625-0242ac110004-isocSGgr-!p.z:Xl7gqf5 token generate success token=MTYyODYzMTM0Ni4zMjYyNDg6ZWJjMTdjZjgtZmEyMi0xMWViLTg2MjUtMDI0MmFjMTE
  05:35:47.206 [dbservice2] INFO ec3f8bfc-fa22-11eb-b651-0242ac110003-xjYUMcml-^4(_{v<kmK}e token generate success token=MTYyODYzMTM0Ny4yMDU1OTplYzNmOGJmYy1mYTIyLTExZWItYjY1MS0wMjQyYWMxMTA
All services, 30 seconds either side (sampled):
  05:35:17.527 [webservice2] INFO complete information: {'uuid': 'daea20c4-fa22-11eb-86de-0242ac110004', 'user_id': 'iAefFjPB'}  (×41)
  05:35:17.694 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'daea20c4-fa22-11eb-86de-0242ac110004', 'value': 'iAefFjPB'}  (×40)
  05:35:17.841 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×41)
  05:35:17.921 [webservice1] INFO uuid: db36d25c-fa22-11eb-8acf-0242ac110003 write redis successfully  (×40)
  05:35:18.029 [redisservice2] INFO service accept, status_code: 200  (×40)
  05:35:18.109 [dbservice1] INFO daea20c4-fa22-11eb-86de-0242ac110004-iAefFjPB-pr!%)P}hszWy token generate success token=MTYyODYzMTMxOC4xMDg3NDEzOmRhZWEyMGM0LWZhMjItMTFlYi04NmRlLTAyNDJhYzE
  05:35:18.318 [redisservice1] INFO redis读取信息成功, status_code: 200  (×49)
  05:35:18.728 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×39)
  05:35:19.818 [dbservice1] INFO dbef27bc-fa22-11eb-985f-0242ac110003-sUWAVXFt-U.o}Q=LtOC%y token generate success token=MTYyODYzMTMxOS44MTc5NTI0OmRiZWYyN2JjLWZhMjItMTFlYi05ODVmLTAyNDJhYzE
  05:35:21.403 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×41)
  05:35:23.818 [mobservice2] INFO info de8f75c6-fa22-11eb-b68b-0242ac110004:gQaRFlxY write success
  05:35:25.903 [dbservice2] INFO df8c17b8-fa22-11eb-ba3f-0242ac110004-ZlqeuHzO-2EB)FPsdU30T token generate success token=MTYyODYzMTMyNS45MDI5MDk4OmRmOGMxN2I4LWZhMjItMTFlYi1iYTNmLTAyNDJhYzE
  05:35:27.573 [dbservice2] INFO e08af2ec-fa22-11eb-950b-0242ac110003-DqvNnYcw-eUr7.Ox_/5Yd token generate success token=MTYyODYzMTMyNy41NzM0MDQzOmUwOGFmMmVjLWZhMjItMTFlYi05NTBiLTAyNDJhYzE
  05:35:30.033 [dbservice1] INFO e1f5899e-fa22-11eb-ac29-0242ac110004-JVwBQHua-/A_5xQRM{X.J token generate success token=MTYyODYzMTMzMC4wMzI2OTU4OmUxZjU4OTllLWZhMjItMTFlYi1hYzI5LTAyNDJhYzE
  05:35:32.491 [mobservice1] INFO info e3b93f0a-fa22-11eb-8b65-0242ac110003:SpJzmrVL write success
  05:35:34.697 [mobservice1] INFO info e50c8fba-fa22-11eb-beab-0242ac110003:rsGCqSOE write success
  05:35:36.938 [dbservice2] INFO e6045c68-fa22-11eb-8494-0242ac110004-NOmfIvPM-6W3hHD^pXQO< token generate success token=MTYyODYzMTMzNi45Mzc4MjYyOmU2MDQ1YzY4LWZhMjItMTFlYi04NDk0LTAyNDJhYzE
  05:35:39.153 [mobservice2] INFO info e7b06b88-fa22-11eb-96b0-0242ac110004:dtzesiga write success
  05:35:41.475 [dbservice2] INFO e8ccb328-fa22-11eb-b061-0242ac110003-RhZNdLGi-5hPyJFcg^U*Z token generate success token=MTYyODYzMTM0MS40NzUxMTE6ZThjY2IzMjgtZmEyMi0xMWViLWIwNjEtMDI0MmFjMTE
  05:35:43.953 [mobservice1] INFO info ea85f9d6-fa22-11eb-bdec-0242ac110004:HxQpIWMr write success
  05:35:46.326 [dbservice2] INFO ebc17cf8-fa22-11eb-8625-0242ac110004-isocSGgr-!p.z:Xl7gqf5 token generate success token=MTYyODYzMTM0Ni4zMjYyNDg6ZWJjMTdjZjgtZmEyMi0xMWViLTg2MjUtMDI0MmFjMTE
  05:35:49.621 [mobservice1] INFO info ede1a648-fa22-11eb-aac1-0242ac110004:UDVbonul write success
  05:35:52.086 [mobservice2] INFO info ef66be90-fa22-11eb-8749-0242ac110004:rwdmTblM write success
  05:35:58.121 [mobservice2] INFO info f2ffb7f0-fa22-11eb-83c5-0242ac110004:GTqJKEWv write success
  05:36:03.638 [mobservice2] INFO info f63d3082-fa22-11eb-ab35-0242ac110004:dzcaqmiU write success
  05:36:05.636 [dbservice1] INFO f7460bb6-fa22-11eb-a3e2-0242ac110003-DtNVdFIW-^*x0{Xp?zMmG token generate success token=MTYyODYzMTM2NS42MzU4MDE4OmY3NDYwYmI2LWZhMjItMTFlYi1hM2UyLTAyNDJhYzE
  05:36:08.178 [dbservice2] INFO f8cd84c8-fa22-11eb-9dec-0242ac110004-FXAevOmb-vIR32bWN1z{l token generate success token=MTYyODYzMTM2OC4xNzc1NTIyOmY4Y2Q4NGM4LWZhMjItMTFlYi05ZGVjLTAyNDJhYzE
  05:36:11.389 [mobservice2] INFO info fad5c69a-fa22-11eb-86fa-0242ac110004:xgMQOjrh write success
  05:36:13.580 [dbservice2] INFO fc08f212-fa22-11eb-9483-0242ac110003-hpcKRNdx-E5o4m%SA(zhR token generate success token=MTYyODYzMTM3My41Nzk3MDkzOmZjMDhmMjEyLWZhMjItMTFlYi05NDgzLTAyNDJhYzE
  05:36:16.209 [dbservice1] INFO fd835f24-fa22-11eb-b040-0242ac110004-IlvgFiyE-c.4uo}8aEr6G token generate success token=MTYyODYzMTM3Ni4yMDg2NjM3OmZkODM1ZjI0LWZhMjItMTFlYi1iMDQwLTAyNDJhYzE

## p0532
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T11:03:53.496Z
```
{"timestamp":1732359833496382200,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 11:03:53.496  INFO [carts,f3ce51e969a9d6c8,ec6a77284d5e1390,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.ItemsController   : Did not find item. Creating item for user: 6741b693a437380001df54d0, Item{id='6741b699f074bf0007005880', itemId='808a2de1-1aaa-4c25-a9b9-6612e8f29a38', quantity=1, unitPrice=17.32}"}
```
Same service, the 2 minutes before (oldest first):
  11:03:47.302 [carts] 2024-11-23 11:03:47.301 INFO [carts,5a0a5bec5562a998,10d7f3b5bd52a0a9,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×3)
  11:03:48.058 [carts] 2024-11-23 11:03:48.058 INFO [carts,0e2f905582406748,4840e505d9e8df9a,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.CartsController : Merge carts reques  (×4)
All services, 30 seconds either side (sampled):
  11:03:24.383 [catalogue] ts=2024-11-23T11:03:24Z caller=logging.go:85 method=Health result=2 took=27.327µs  (×40)
  11:03:25.848 [user] ts=2024-11-23T11:03:25.848608517Z caller=middlewares.go:157 method=Health result=2 took=2.191376ms  (×40)
  11:03:47.282 [front-end] Posting Customer: {"username":"efjgmmJtKv","password":"RMUFsiyY","email":"efjgmmJtKv@gmail.com","firstName":"efjgmmJtKv","lastName":"efjgmmJtKv"}
  11:03:47.302 [carts] 2024-11-23 11:03:47.301 INFO [carts,5a0a5bec5562a998,10d7f3b5bd52a0a9,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×15)
  11:03:48.042 [front-end] Posting Customer: {"username":"NzdAqPAXT","password":"WSOhs","email":"NzdAqPAXT@gmail.com","firstName":"NzdAqPAXT","lastName":"NzdAqPAXT"}
  11:03:51.097 [user] ts=2024-11-23T11:03:51.097470932Z caller=middlewares.go:46 method=Register username=izuCR email=izuCR@gmail.com took=2.202784ms
  11:03:53.347 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b693a437380001df54d0"}  (×21)
  11:03:53.375 [front-end] POST /cards 200 - ms - -  (×21)
  11:03:53.463 [catalogue] ts=2024-11-23T11:03:53Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=5.433436  (×20)
  11:03:53.778 [front-end] Posting Customer: {"username":"geeABJ","password":"gLAddSYTi","email":"geeABJ@gmail.com","firstName":"geeABJ","lastName":"geeABJ"}
  11:03:55.836 [front-end] Posting Customer: {"username":"hTENweUVmuIzV","password":"Dvygpi","email":"hTENweUVmuIzV@gmail.com","firstName":"hTENweUVmuIzV","lastName":"hTENweUVmuIzV"}
  11:03:56.382 [carts] 2024-11-23 11:03:56.381 INFO [carts,8ec7ce6c89d752ee,d87e8f54055f3ce3,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.ItemsController : Did not find item.  (×12)
  11:03:56.543 [front-end] Posting Customer: {"username":"YWOBdjLIWnSTg","password":"jTWvGWdK","email":"YWOBdjLIWnSTg@gmail.com","firstName":"YWOBdjLIWnSTg","lastName":"YWOBdjLIWnSTg"}
  11:03:57.772 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×3)
  11:03:59.669 [front-end] Posting Customer: {"username":"imhZTN","password":"PxvCtnJ","email":"imhZTN@gmail.com","firstName":"imhZTN","lastName":"imhZTN"}
  11:04:00.291 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×2)
  11:04:01.454 [user] ts=2024-11-23T11:04:01.454479736Z caller=middlewares.go:46 method=Register username=zDIHdeVWu email=zDIHdeVWu@gmail.com took=2.48915ms
  11:04:03.984 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  11:04:06.542 [user] ts=2024-11-23T11:04:06.541921827Z caller=middlewares.go:75 method=GetUsers id=6741b693a437380001df54d0 result=1 took=1.972827ms  (×4)
  11:04:06.562 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b699a437380001df54d8\",\"_links\":{\"
  11:04:06.577 [user] ts=2024-11-23T11:04:06.577774678Z caller=middlewares.go:134 method=GetCards id=6741b699a437380001df54d8 result=1 took=1.80299ms
  11:04:06.606 [queue-master] Received shipment task: 6741b693a437380001df54d0
  11:04:06.609 [front-end] Order response: {"statusCode":201,"headers":{"x-application-context":"orders:80","content-length":"0","date":"Sat, 23 Nov 2024 11:04:06 GMT","x-envoy-upstream-s
  11:04:06.643 [front-end] npm timing command:run-script Completed in 43497ms
  11:04:06.644 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!

## p0505
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:17:37.713Z
```
{"timestamp":1732353457713061400,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:17:37.712831797Z caller=middlewares.go:75 method=GetUsers id=67419d9ca437380001df0e6e result=1 took=3.407062ms"}
```
Same service, the 2 minutes before (oldest first):
  09:17:34.849 [user] ts=2024-11-23T09:17:34.849872219Z caller=middlewares.go:157 method=Health result=2 took=2.311693ms
  09:17:35.657 [user] ts=2024-11-23T09:17:35.657390624Z caller=middlewares.go:75 method=GetUsers id=67419d98a437380001df0e65 result=1 took=3.449766ms  (×12)
  09:17:35.828 [user] ts=2024-11-23T09:17:35.828089302Z caller=middlewares.go:46 method=Register username=ZblZyuKozOpfQ email=ZblZyuKozOpfQ@gmail.com took=2.67773ms
  09:17:36.324 [user] ts=2024-11-23T09:17:36.324673126Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419da7a437380001df0e9b took=4.616889ms  (×3)
  09:17:36.341 [user] ts=2024-11-23T09:17:36.34101182Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419da7a437380001df0e9b took=4.676248ms  (×3)
All services, 30 seconds either side (sampled):
  09:17:07.821 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67419d8ea437380001df0e4c"}  (×59)
  09:17:07.900 [front-end] Attempting to delete cart for user: 67419d8ea437380001df0e4c  (×59)
  09:17:07.969 [carts] 2024-11-23 09:17:07.969 INFO [carts,96507b9aee419043,1d3de51b49ca6299,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.ItemsController : Did not find item.  (×28)
  09:17:08.399 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67419  (×60)
  09:17:08.408 [orders] Caused by: java.lang.IllegalArgumentException: Conflicting setter definitions for property "items": works.weave.socks.orders.entities.CustomerOrder#setItems(1 p  (×60)
  09:17:08.703 [front-end] GET /catalogue 200 - ms - -  (×58)
  09:17:10.417 [front-end] Posting Customer: {"username":"qbjaFahgnGmPlw","password":"JJWrWRzI","email":"qbjaFahgnGmPlw@gmail.com","firstName":"qbjaFahgnGmPlw","lastName":"qbjaFahgnGmPlw"
  09:17:10.449 [front-end] set cookie67419d96a437380001df0e5f  (×56)
  09:17:11.253 [front-end] Posting Customer: {"username":"ekctSeuSbMAv","password":"kNwAKp","email":"ekctSeuSbMAv@gmail.com","firstName":"ekctSeuSbMAv","lastName":"ekctSeuSbMAv"}
  09:17:13.710 [front-end] Posting Customer: {"username":"mFkmHMV","password":"ILIHzLeyig","email":"mFkmHMV@gmail.com","firstName":"mFkmHMV","lastName":"mFkmHMV"}
  09:17:16.217 [front-end] Received response: "{\"firstName\":\"GObjabUkigiJqXO\",\"lastName\":\"GObjabUkigiJqXO\",\"username\":\"GObjabUkigiJqXO\",\"id\":\"67419d87a437380001df0e31\",\"_
  09:17:17.292 [front-end] Posting Customer: {"username":"pgYZJxBbFt","password":"dFnTjoV","email":"pgYZJxBbFt@gmail.com","firstName":"pgYZJxBbFt","lastName":"pgYZJxBbFt"}
  09:17:19.010 [front-end] Posting Customer: {"username":"TthAoQUobqAKTKs","password":"aXpup","email":"TthAoQUobqAKTKs@gmail.com","firstName":"TthAoQUobqAKTKs","lastName":"TthAoQUobqAKTKs
  09:17:21.216 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×8)
  09:17:23.765 [front-end] Posting Customer: {"username":"usdmXoOKgV","password":"QHyZhivNk","email":"usdmXoOKgV@gmail.com","firstName":"usdmXoOKgV","lastName":"usdmXoOKgV"}
  09:17:24.833 [orders-db] {"t":{"$date":"2024-11-23T09:17:24.832+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235344
  09:17:27.230 [front-end] Posting Customer: {"username":"ybsJzeXpxUAOl","password":"MxuotRcV","email":"ybsJzeXpxUAOl@gmail.com","firstName":"ybsJzeXpxUAOl","lastName":"ybsJzeXpxUAOl"}
  09:17:31.776 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×4)
  09:17:34.635 [front-end] Received response: "{\"firstName\":\"qbjaFahgnGmPlw\",\"lastName\":\"qbjaFahgnGmPlw\",\"username\":\"qbjaFahgnGmPlw\",\"id\":\"67419d96a437380001df0e5f\",\"_lin
  09:17:38.951 [front-end] Posting Customer: {"username":"UEqxaG","password":"DKiPVdn","email":"UEqxaG@gmail.com","firstName":"UEqxaG","lastName":"UEqxaG"}
  09:17:40.578 [front-end] Posting Customer: {"username":"chHzaqLJ","password":"roRWIu","email":"chHzaqLJ@gmail.com","firstName":"chHzaqLJ","lastName":"chHzaqLJ"}
  09:17:41.754 [front-end] Posting Customer: {"username":"BzBImPJABrLnIZb","password":"xgJXv","email":"BzBImPJABrLnIZb@gmail.com","firstName":"BzBImPJABrLnIZb","lastName":"BzBImPJABrLnIZb
  09:17:44.780 [front-end] Received response: "{\"firstName\":\"TfFkXhzUnOjXCM\",\"lastName\":\"TfFkXhzUnOjXCM\",\"username\":\"TfFkXhzUnOjXCM\",\"id\":\"67419da8a437380001df0e9e\",\"_lin
  09:17:47.339 [front-end] Posting Customer: {"username":"ZwRfehSWt","password":"irDSqwmO","email":"ZwRfehSWt@gmail.com","firstName":"ZwRfehSWt","lastName":"ZwRfehSWt"}
  09:17:49.489 [front-end] Received response: "{\"firstName\":\"ybsJzeXpxUAOl\",\"lastName\":\"ybsJzeXpxUAOl\",\"username\":\"ybsJzeXpxUAOl\",\"id\":\"67419da7a437380001df0e9b\",\"_links\
  09:17:54.912 [user] ts=2024-11-23T09:17:54.911873694Z caller=middlewares.go:46 method=Register username=XiQkcs email=XiQkcs@gmail.com took=2.1889ms
  09:17:58.799 [user] ts=2024-11-23T09:17:58.799225726Z caller=middlewares.go:46 method=Register username=RHIjulzP email=RHIjulzP@gmail.com took=2.244147ms
  09:18:03.082 [front-end] Received response: "{\"firstName\":\"daTTGwlpTcqoJUN\",\"lastName\":\"daTTGwlpTcqoJUN\",\"username\":\"daTTGwlpTcqoJUN\",\"id\":\"67419db3a437380001df0eb9\",\"_
  09:18:05.956 [front-end] Posting Customer: {"username":"BWSaAbtLhJwzC","password":"iGFQfiFg","email":"BWSaAbtLhJwzC@gmail.com","firstName":"BWSaAbtLhJwzC","lastName":"BWSaAbtLhJwzC"}

## p0763
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T06:36:45.265Z
```
{"timestamp":1732257405265235500,"container_name":"front-end","pod_name":"front-end-f77549869-mxq2p","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"firstName\\\":\\\"oomfx\\\",\\\"lastName\\\":\\\"oomfx\\\",\\\"username\\\":\\\"oomfx\\\",\\\"id\\\":\\\"6740266d768f35000114f2d9\\\",\\\"_links\\\":{\\\"addresses\\\":{\\\"href\\\":\\\"http://user/customers/6740266d768f35000114f2d9/addresses\\\"},\\\"cards\\\":{\\\"href\\\":\\\"http://user/customers/6740266d768f35000114f2d9/cards\\\"},\\\"customer\\\":{\\\"href\\\":\\\"http://user/customers/6740266d768f35000114f2d9\\\"},\\\"self\\\":{\\\"href\\\":\\\"h…"}
```
Same service, the 2 minutes before (oldest first):
  06:36:44.841 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  06:36:44.841 [front-end] POST to carts: http://carts/carts/67402675768f35000114f2ef/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  06:36:44.886 [front-end] POST /cart 500 50.708 ms - 64
  06:36:44.975 [front-end] Posting Customer: {"username":"zZRLhMCROTv","password":"GuIpIp","email":"zZRLhMCROTv@gmail.com","firstName":"zZRLhMCROTv","lastName":"zZRLhMCROTv"}
  06:36:44.982 [front-end] { id: '6740267c768f35000114f30f' }  (×2)
  06:36:44.982 [front-end] 6740267c768f35000114f30f  (×2)
  06:36:44.982 [front-end] Merging carts for customer id: 6740267c768f35000114f30f and session id: 67IhgzL89EJDSLG0XVkcqc1KwQMitQij  (×2)
  06:36:44.997 [front-end] Carts merged.  (×2)
  06:36:44.997 [front-end] set cookie6740267c768f35000114f30f  (×2)
  06:36:44.998 [front-end] Sent cookies.  (×2)
  06:36:45.000 [front-end] POST /register 200 22.279 ms - 33  (×2)
  06:36:45.060 [front-end] Posting Customer: {"username":"DlPqQkEdpY","password":"ZbUYnPrbS","email":"DlPqQkEdpY@gmail.com","firstName":"DlPqQkEdpY","lastName":"DlPqQkEdpY"}
  06:36:45.254 [front-end] Request received with body: {}
All services, 30 seconds either side (sampled):
  06:36:15.587 [carts] 2024-11-22 06:36:15.587 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  06:36:15.739 [front-end] GET /catalogue 200 - ms - -  (×61)
  06:36:16.435 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67402657768f35000114f29d"}  (×58)
  06:36:16.777 [front-end] Received response: "{\"firstName\":\"mhUkcwGi\",\"lastName\":\"mhUkcwGi\",\"username\":\"mhUkcwGi\",\"id\":\"67402648768f35000114f268\",\"_links\":{\"addresses\
  06:36:16.824 [front-end] POST /orders 500 - ms - -  (×60)
  06:36:20.488 [front-end] Posting Customer: {"username":"vjgkYNxqGjRVEE","password":"sPmsXtb","email":"vjgkYNxqGjRVEE@gmail.com","firstName":"vjgkYNxqGjRVEE","lastName":"vjgkYNxqGjRVEE"}
  06:36:23.315 [front-end] Posting Customer: {"username":"XEaFlyeMwpQvWl","password":"dvoMVJt","email":"XEaFlyeMwpQvWl@gmail.com","firstName":"XEaFlyeMwpQvWl","lastName":"XEaFlyeMwpQvWl"}
  06:36:26.708 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×12)
  06:36:31.711 [front-end] Posting Customer: {"username":"XeXhSPvQ","password":"FiKQIAR","email":"XeXhSPvQ@gmail.com","firstName":"XeXhSPvQ","lastName":"XeXhSPvQ"}
  06:36:33.687 [carts] 2024-11-22 06:36:33.686 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[HEAD],produces=[application/hal+json ||
  06:36:33.694 [carts] 2024-11-22 06:36:33.694 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[GE
  06:36:33.983 [carts] 2024-11-22 06:36:33.983 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http.
  06:36:37.670 [user] ts=2024-11-22T06:36:37.670190487Z caller=middlewares.go:46 method=Register username=uUopaQr email=uUopaQr@gmail.com took=2.497622ms
  06:36:37.991 [carts] 2024-11-22 06:36:37.986 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  06:36:40.796 [front-end] Posting Customer: {"username":"FWfmnVb","password":"dqiRIJv","email":"FWfmnVb@gmail.com","firstName":"FWfmnVb","lastName":"FWfmnVb"}
  06:36:43.043 [user] ts=2024-11-22T06:36:43.043793467Z caller=middlewares.go:46 method=Register username=ZNnPKJVw email=ZNnPKJVw@gmail.com took=2.369625ms
  06:36:45.458 [front-end] Posting Customer: {"username":"muLEbyzOwVRKHWs","password":"EZVuOhz","email":"muLEbyzOwVRKHWs@gmail.com","firstName":"muLEbyzOwVRKHWs","lastName":"muLEbyzOwVRKH
  06:36:48.587 [carts] 2024-11-22 06:36:48.587 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  06:36:51.876 [front-end] Posting Customer: {"username":"caUFPGgZE","password":"qgxUI","email":"caUFPGgZE@gmail.com","firstName":"caUFPGgZE","lastName":"caUFPGgZE"}
  06:36:53.651 [orders] java.util.concurrent.TimeoutException: null at java.util.concurrent.FutureTask.get(FutureTask.java:205) ~[na:1.8.0_131] at works.weave.socks.orders.controllers.  (×3)
  06:36:55.010 [queue-master] 2024-11-22 06:36:55.010 ERROR 7 --- [pool-6-thread-2] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×9)
  06:36:55.402 [front-end] Order response: {"statusCode":201,"body":{"id":"67402687531af4000701df48","customerId":"6740266e768f35000114f2da","customer":{"id":null,"firstName":"zzhAJquKxRC
  06:36:57.288 [carts] 2024-11-22 06:36:57.288 INFO [carts,940a8725a23205b5,79203674de0e7119,false] 7 --- [-nio-80-exec-17] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×19)
  06:36:58.900 [queue-master] 2024-11-22 06:36:58.900 ERROR 7 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×15)
  06:37:04.200 [front-end] Order response: {"id":"67402690531af4000701df4f","customerId":"67402678768f35000114f2fa","customer":{"id":null,"firstName":"CQKHgug","lastName":"CQKHgug","usern
  06:37:07.217 [front-end] Posting Customer: {"username":"jiOofoLGkosftD","password":"YxqsfCcLeF","email":"jiOofoLGkosftD@gmail.com","firstName":"jiOofoLGkosftD","lastName":"jiOofoLGkosft
  06:37:10.170 [front-end] Order response: {"statusCode":201,"body":{"id":"67402696531af4000701df54","customerId":"67402683768f35000114f32a","customer":{"id":null,"firstName":"caUFPGgZE",
  06:37:12.495 [user] ts=2024-11-22T06:37:12.495709661Z caller=middlewares.go:46 method=Register username=CZKslXPR email=CZKslXPR@gmail.com took=1.776996ms
  06:37:14.509 [front-end] Order response: {"statusCode":201,"body":{"id":"6740269a531af4000701df58","customerId":"67402680768f35000114f31c","customer":{"id":null,"firstName":"cNlztKPZjRv

## p0257
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:11.658Z
```
{"timestamp":1732242491658275800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"_embedded\\\":{\\\"address\\\":[{\\\"street\\\":\\\"123\\\",\\\"number\\\":\\\"123\\\",\\\"country\\\":\\\"123\\\",\\\"city\\\":\\\"123\\\",\\\"postcode\\\":\\\"123\\\",\\\"id\\\":\\\"673fec31b0df5c00019af959\\\",\\\"_links\\\":{\\\"address\\\":{\\\"href\\\":\\\"http://user/addresses/673fec31b0df5c00019af959\\\"},\\\"self\\\":{\\\"href\\\":\\\"http://user/addresses/673fec31b0df5c00019af959\\\"}}}]}}\\n\""}
```
Same service, the 2 minutes before (oldest first):
  02:28:11.355 [front-end] Attempting to add to cart: {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","quantity":1}  (×2)
  02:28:11.364 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  02:28:11.364 [front-end] POST to carts: http://carts/carts/673fec32b0df5c00019af95c/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}
  02:28:11.397 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec35b0df5c00019af969"}
  02:28:11.406 [front-end] POST /addresses 200 - ms - -
  02:28:11.408 [front-end] POST /cart 500 51.010 ms - 64  (×2)
  02:28:11.456 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec35b0df5c00019af969"}
  02:28:11.466 [front-end] POST /cards 200 - ms - -
  02:28:11.516 [front-end] Attempting to delete cart for user: 673fec35b0df5c00019af969
  02:28:11.561 [front-end] User cart deleted with status: 503
  02:28:11.565 [front-end] DELETE /cart 503 - ms - -
  02:28:11.579 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
  02:28:11.579 [front-end] POST to carts: http://carts/carts/673fec35b0df5c00019af969/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}
  02:28:11.642 [front-end] Request received with body: {}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:11.650 [front-end] GET Request to: http://user/customers/673fec2ab0df5c00019af942/addresses  (×2)
  02:28:11.657 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec31b0df5c00019af95a\",\"_links\":{\"
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×38)
  02:28:03.122 [front-end] GET /catalogue 200 - ms - -  (×43)
  02:28:03.196 [front-end] Received response: "{\"firstName\":\"FbddLnzSA\",\"lastName\":\"FbddLnzSA\",\"username\":\"FbddLnzSA\",\"id\":\"673fec21b0df5c00019af922\",\"_links\":{\"address
  02:28:03.245 [orders] 2024-11-22 02:28:03.244 ERROR [orders,,,] 6 --- [p-nio-80-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×16)
  02:28:03.391 [user] ts=2024-11-22T02:28:03.390808559Z caller=middlewares.go:46 method=Register username=kMzzAppFcYY email=kMzzAppFcYY@gmail.com took=958.317µs  (×5)
  02:28:03.523 [user] ts=2024-11-22T02:28:03.52331003Z caller=middlewares.go:46 method=Register username=sgQXbZQ email=sgQXbZQ@gmail.com took=1.065166ms
  02:28:05.055 [user] ts=2024-11-22T02:28:05.055011754Z caller=middlewares.go:104 method=GetAddresses id=673fec25b0df5c00019af92f result=1 took=781.934µs  (×18)
  02:28:06.796 [front-end] Posting Customer: {"username":"oyShDJ","password":"sWqvpeFZPy","email":"oyShDJ@gmail.com","firstName":"oyShDJ","lastName":"oyShDJ"}
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.451 [carts] 2024-11-22 02:28:10.451 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.377 [front-end] Received response: "{\"firstName\":\"vtFUiCYPGkr\",\"lastName\":\"vtFUiCYPGkr\",\"username\":\"vtFUiCYPGkr\",\"id\":\"673fec2bb0df5c00019af944\",\"_links\":{\"a
  02:28:19.135 [carts] 2024-11-22 02:28:18.940 INFO [carts,cb305558d352107b,fbb223eea295e77c,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×15)
  02:28:21.967 [front-end] Posting Customer: {"username":"PDQejFz","password":"UItpfuss","email":"PDQejFz@gmail.com","firstName":"PDQejFz","lastName":"PDQejFz"}
  02:28:23.046 [orders] 2024-11-22 02:28:23.045 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×8)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.870 [front-end] Received response: "{\"firstName\":\"sgQXbZQ\",\"lastName\":\"sgQXbZQ\",\"username\":\"sgQXbZQ\",\"id\":\"673fec33b0df5c00019af963\",\"_links\":{\"addresses\":{
  02:28:25.536 [carts] 2024-11-22 02:28:25.536 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.ItemsController : Did not find item.  (×12)
  02:28:26.351 [queue-master] Received shipment task: 673fec2db0df5c00019af953  (×18)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39cf","customerId":"673fec36b0df5c00019af96c","customer":{"id":null,"firstName":"oyShDJ","lastName":"oyShDJ","usernam
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.065 [front-end] Order response: {"id":"673fec4ad94b9000069b39d4","customerId":"673fec33b0df5c00019af963","customer":{"id":null,"firstName":"sgQXbZQ","lastName":"sgQXbZQ","usern
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket
  02:28:33.840 [front-end] Posting Customer: {"username":"MywYMGzyoIdhsgg","password":"SiEqM","email":"MywYMGzyoIdhsgg@gmail.com","firstName":"MywYMGzyoIdhsgg","lastName":"MywYMGzyoIdhsgg
  02:28:38.668 [front-end] Received response: "{\"firstName\":\"PDQejFz\",\"lastName\":\"PDQejFz\",\"username\":\"PDQejFz\",\"id\":\"673fec45b0df5c00019af990\",\"_links\":{\"addresses\":{
  02:28:40.321 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR",

## p0236
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T08:00:02.670Z
```
{"timestamp":1731916802670421000,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  08:00:00.904 [currencyservice] conversion request successful  (×14)
  08:00:01.587 [currencyservice] Getting supported currencies...  (×6)
All services, 30 seconds either side (sampled):
  07:59:32.868 [frontend] request started  (×317)
  07:59:32.876 [cartservice] GetCartAsync called with userId=adf41e5f-12f6-4c40-88a0-a1bcf421e416  (×259)
  07:59:32.912 [frontend] ENV_PLATFORM is: aws  (×34)
  07:59:32.920 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', 'LS4PSXUNUM', '1YMWWN1N4O', 'L9ECAV7KIM', '2ZYFJ3GM2N']  (×219)
  07:59:33.494 [frontend] adding to cart  (×35)
  07:59:33.529 [shippingservice] [GetQuote] received request  (×87)
  07:59:34.592 [frontend] placing order  (×12)
  07:59:34.619 [paymentservice] Transaction processed: visa ending 9143 Amount: USD258.320000000  (×2)
  07:59:34.623 [shippingservice] [ShipOrder] completed request  (×12)
  07:59:34.634 [emailservice] A request to send order confirmation email to brandykim@example.net has been received.
  07:59:35.802 [frontend] setting currency  (×23)
  07:59:36.829 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"89880","nanos":965944737},"credit_card":{"credit_card_number":"406234496515  (×7)
  07:59:36.843 [checkoutservice] failed to send order confirmation to "lmahoney@example.net": rpc error: code = Internal desc = Failed to serialize response!
  07:59:38.030 [emailservice] A request to send order confirmation email to rebecca69@example.com has been received.
  07:59:47.076 [emailservice] A request to send order confirmation email to dianajimenez@example.com has been received.
  07:59:49.190 [checkoutservice] failed to send order confirmation to "nancy46@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:59:56.472 [emailservice] A request to send order confirmation email to mannshelby@example.org has been received.
  07:59:59.875 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"357","nanos":350917299},"credit_card":{"credit_card_number":"48628447560980
  07:59:59.890 [checkoutservice] failed to send order confirmation to "elizabethcrawford@example.org": rpc error: code = Internal desc = Failed to serialize response!
  08:00:09.556 [checkoutservice] [PlaceOrder] user_id="adf41e5f-12f6-4c40-88a0-a1bcf421e416" user_currency="GBP"  (×2)
  08:00:09.593 [emailservice] A request to send order confirmation email to estradaelizabeth@example.net has been received.
  08:00:20.119 [emailservice] A request to send order confirmation email to taramoon@example.com has been received.
  08:00:32.271 [checkoutservice] failed to send order confirmation to "mgarrett@example.org": rpc error: code = Internal desc = Failed to serialize response!

## p0458
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-23T08:06:40.816Z
```
{"timestamp":1732349200816012000,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-zmfhr","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:40.815  INFO 7 --- [a-jaxrs-async-0] o.apache.http.impl.execchain.RetryExec   : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught when processing request to {}->unix://localhost:80: No such file or directory"}
```
Same service, the 2 minutes before (oldest first):
  08:05:27.725 [queue-master] 2024-11-23 08:05:27.725 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[application/jso
  08:05:27.725 [queue-master] 2024-11-23 08:05:27.725 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/prometheus || /prometheus.json],methods=[GET],produces=[text/plain;
  08:05:27.726 [queue-master] 2024-11-23 08:05:27.726 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[application/json]}" o
  08:05:27.726 [queue-master] 2024-11-23 08:05:27.726 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[application/json]}" o
  08:05:30.199 [queue-master] 2024-11-23 08:05:30.199 INFO 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:05:30.401 [queue-master] 2024-11-23 08:05:30.401 INFO 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'connectionFactory' has been autodetected for JMX exposure
  08:05:30.406 [queue-master] 2024-11-23 08:05:30.405 INFO 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'connectionFactory': registering with JMX server as MBean [o
  08:05:30.718 [queue-master] 2024-11-23 08:05:30.718 INFO 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase -2147482648
  08:05:30.803 [queue-master] 2024-11-23 08:05:30.718 INFO 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0  (×2)
  08:05:32.624 [queue-master] 2024-11-23 08:05:32.623 INFO 7 --- [enerContainer-1] o.s.a.r.c.CachingConnectionFactory : Created new connection: SimpleConnection@53c83726 [delegate=amqp://gue
  08:05:32.625 [queue-master] 2024-11-23 08:05:32.625 INFO 7 --- [enerContainer-1] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-durable, auto-delete, or exclusive Queue (shipping-  (×2)
  08:05:33.423 [queue-master] 2024-11-23 08:05:33.417 INFO 7 --- [ main] s.a.ScheduledAnnotationBeanPostProcessor : No TaskScheduler/ScheduledExecutorService bean found for scheduled process
  08:05:34.107 [queue-master] 2024-11-23 08:05:34.106 INFO 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:05:34.299 [queue-master] 2024-11-23 08:05:34.299 INFO 7 --- [ main] w.w.s.q.QueueMasterApplication : Started QueueMasterApplication in 66.192 seconds (JVM running for 70.627)
  08:05:43.228 [queue-master] 2024-11-23 08:05:43.228 INFO 7 --- [p-nio-80-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  08:05:43.228 [queue-master] 2024-11-23 08:05:43.228 INFO 7 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  08:05:43.320 [queue-master] 2024-11-23 08:05:43.319 INFO 7 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization completed in 91 ms
  08:06:35.505 [queue-master] Received shipment task: 67418cf2a437380001deec94
All services, 30 seconds either side (sampled):
  08:06:10.849 [user] ts=2024-11-23T08:06:10.849352289Z caller=middlewares.go:157 method=Health result=2 took=2.529897ms  (×40)
  08:06:12.370 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418  (×61)
  08:06:12.814 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418cefa437380001deec8f"}  (×57)
  08:06:13.095 [front-end] POST /cart 500 79.484 ms - 64  (×14)
  08:06:14.400 [shipping] 2024-11-23 08:06:14.400 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX ser
  08:06:15.800 [carts] 2024-11-23 08:06:15.800 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[HEAD],produces=[applicatio
  08:06:15.811 [carts] 2024-11-23 08:06:15.811 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces=
  08:06:16.434 [front-end] Posting Customer: {"username":"GXUtAA","password":"OZQmnTELUP","email":"GXUtAA@gmail.com","firstName":"GXUtAA","lastName":"GXUtAA"}
  08:06:19.002 [carts] 2024-11-23 08:06:19.002 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  08:06:19.108 [carts] 2024-11-23 08:06:19.108 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/
  08:06:23.082 [carts-db] {"t":{"$date":"2024-11-23T08:06:23.081+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173234918
  08:06:25.334 [front-end] Received response: "{\"firstName\":\"JAEXlZGcwnm\",\"lastName\":\"JAEXlZGcwnm\",\"username\":\"JAEXlZGcwnm\",\"id\":\"67418cefa437380001deec8d\",\"_links\":{\"a
  08:06:27.201 [carts] 2024-11-23 08:06:27.200 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 119.694 seconds (JVM running for 124.0
  08:06:30.330 [front-end] Posting Customer: {"username":"pFbuHLdxmNq","password":"LQDNwOWSPu","email":"pFbuHLdxmNq@gmail.com","firstName":"pFbuHLdxmNq","lastName":"pFbuHLdxmNq"}
  08:06:32.257 [front-end] Received response: "{\"firstName\":\"zFhFddnpfqKhWz\",\"lastName\":\"zFhFddnpfqKhWz\",\"username\":\"zFhFddnpfqKhWz\",\"id\":\"67418cf1a437380001deec93\",\"_lin
  08:06:34.206 [carts-db] {"t":{"$date":"2024-11-23T08:06:34.206+00:00"},"s":"I", "c":"STORAGE", "id":20320, "ctx":"conn18","msg":"createCollection","attr":{"namespace":"data.item","uuid  (×4)
  08:06:35.457 [front-end] Posting Customer: {"username":"KarxuPo","password":"sUyEQyb","email":"KarxuPo@gmail.com","firstName":"KarxuPo","lastName":"KarxuPo"}
  08:06:36.202 [front-end] Order response: {"id":"67418d0b3f77060008864e3c","customerId":"67418cf3a437380001deec98","customer":{"id":null,"firstName":"rxOPSacxRgokAg","lastName":"rxOPSacx
  08:06:40.816 [queue-master] 2024-11-23 08:06:40.816 INFO 7 --- [a-jaxrs-async-0] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×2)
  08:06:41.833 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d113f77060008864e43","customerId":"67418cf5a437380001deec9b","customer":{"id":null,"firstName":"teNYQYg","l
  08:06:43.917 [queue-master] 2024-11-23 08:06:43.917 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×84)
  08:06:47.815 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d173f77060008864e49","customerId":"67418cfba437380001deecae","customer":{"id":null,"firstName":"HsVUYJlBshm
  08:06:48.895 [front-end] Order response: {"id":"67418d183f77060008864e4d","customerId":"67418cfea437380001deecb6","customer":{"id":null,"firstName":"uIDJZeefxELrfcp","lastName":"uIDJZee
  08:06:52.688 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d1c3f77060008864e52","customerId":"67418d05a437380001deecd0","customer":{"id":null,"firstName":"cuFLCUGugoz
  08:06:56.454 [front-end] Received response: "{\"firstName\":\"EDkxTMyJmiJ\",\"lastName\":\"EDkxTMyJmiJ\",\"username\":\"EDkxTMyJmiJ\",\"id\":\"67418d06a437380001deecd9\",\"_links\":{\"a
  08:06:58.994 [front-end] Order response: {"timestamp":1732349218983,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×4)
  08:07:01.230 [front-end] Order response: {"id":"67418d253f77060008864e5b","customerId":"67418d12a437380001deecff","customer":{"id":null,"firstName":"gSjFQJm","lastName":"gSjFQJm","usern
  08:07:03.852 [front-end] Posting Customer: {"username":"DgQhwohJs","password":"UNHrVnM","email":"DgQhwohJs@gmail.com","firstName":"DgQhwohJs","lastName":"DgQhwohJs"}
  08:07:10.047 [front-end] Posting Customer: {"username":"CYjYjHDRHetSPH","password":"dXOJhrJHMH","email":"CYjYjHDRHetSPH@gmail.com","firstName":"CYjYjHDRHetSPH","lastName":"CYjYjHDRHetSP

## p0162
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T06:24:57.455Z
```
{"timestamp":1731911097455661300,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-svrwm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b"}
```
Same service, the 2 minutes before (oldest first):
  06:24:52.683 [cartservice] GetCartAsync called with userId=736a09b5-665e-4823-8520-b8602b0bdbff  (×18)
  06:24:53.073 [cartservice] AddItemAsync called with userId=0ae6d9b6-4e7f-4d38-a0eb-042389dcac30, productId=9SIQT8TOJO, quantity=2  (×2)
All services, 30 seconds either side (sampled):
  06:24:27.687 [frontend] request started  (×301)
  06:24:27.692 [currencyservice] Getting supported currencies...  (×251)
  06:24:27.703 [currencyservice] conversion request successful  (×713)
  06:24:27.724 [adservice] received ad request (context_words=[clothing, tops])  (×17)
  06:24:27.866 [adservice] received ad request (context_words=[accessories])  (×29)
  06:24:27.879 [frontend] adding to cart  (×25)
  06:24:27.891 [frontend] view user cart  (×57)
  06:24:27.913 [shippingservice] [GetQuote] completed request  (×65)
  06:24:29.132 [adservice] received ad request (context_words=[decor, home])  (×23)
  06:24:29.718 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM']  (×3)
  06:24:30.655 [frontend] ENV_PLATFORM is: aws  (×39)
  06:24:35.282 [frontend] setting currency  (×24)
  06:24:35.904 [checkoutservice] [PlaceOrder] user_id="736a09b5-665e-4823-8520-b8602b0bdbff" user_currency="CAD"  (×2)
  06:24:35.929 [paymentservice] Transaction processed: visa ending 4366 Amount: CAD2246.544799645  (×2)
  06:24:35.934 [shippingservice] [ShipOrder] received request  (×8)
  06:24:35.937 [cartservice] EmptyCartAsync called with userId=736a09b5-665e-4823-8520-b8602b0bdbff  (×8)
  06:24:35.944 [checkoutservice] order confirmation email sent to "james71@example.org"
  06:24:38.664 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="GBP"  (×3)
  06:24:38.697 [paymentservice] Transaction processed: visa ending 6714 Amount: GBP250.814908438  (×3)
  06:24:38.712 [checkoutservice] order confirmation email sent to "carl20@example.com"
  06:24:49.871 [checkoutservice] order confirmation email sent to "andrew63@example.com"
  06:24:58.364 [emailservice] A request to send order confirmation email to lori60@example.net has been received.
  06:25:05.916 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', 'LS4PSXUNUM', '2ZYFJ3GM2N', '1YMWWN1N4O']
  06:25:06.019 [checkoutservice] order confirmation email sent to "oadams@example.net"
  06:25:16.072 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"48235","nanos":492260473},"credit_card":{"credit_card_number":"491975061165
  06:25:16.085 [emailservice] A request to send order confirmation email to samantha90@example.com has been received.
  06:25:17.873 [recommendationservice] [Recv ListRecommendations] product_ids=[]
  06:25:19.050 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"1023","nanos":790000000},"credit_card":{"credit_card_number":"4403898043899  (×2)
  06:25:19.064 [emailservice] A request to send order confirmation email to rebekah66@example.com has been received.
  06:25:27.071 [emailservice] A request to send order confirmation email to ycook@example.org has been received.

## p0474
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:14:39.169Z
```
{"timestamp":1732349679169023000,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Order: {\"customer\":\"http://user/customers/67418ed6a437380001def23e\",\"address\":\"http://user/addresses/67418ee0a437380001def25f\",\"card\":\"http://user/cards/67418ee0a437380001def261\",\"items\":\"http://carts/carts/67418ed6a437380001def23e/items\"}"}
```
Same service, the 2 minutes before (oldest first):
  08:14:38.954 [front-end] GET Request to: http://user/customers/67418edca437380001def251/addresses  (×4)
  08:14:38.963 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418  (×2)
  08:14:38.963 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418ee2a437380001def26b\",\"_links\":{\"  (×2)
  08:14:38.963 [front-end] [ undefined, undefined ]  (×2)
  08:14:38.963 [front-end] Posting Order: {"customer":"http://user/customers/67418edca437380001def251","address":"http://user/addresses/67418ee2a437380001def26a","card":"http://user/cards
  08:14:38.992 [front-end] Order response: {"statusCode":201,"body":{"id":"67418eee3f77060008864ff1","customerId":"67418edca437380001def251","customer":{"id":null,"firstName":"DYVdBLexbV"
  08:14:38.992 [front-end] Order response: {"id":"67418eee3f77060008864ff1","customerId":"67418edca437380001def251","customer":{"id":null,"firstName":"DYVdBLexbV","lastName":"DYVdBLexbV",
  08:14:38.996 [front-end] POST /orders 201 - ms - -
  08:14:39.151 [front-end] Request received with body: {}
  08:14:39.155 [front-end] Posting Customer: {"username":"ZLzRIFfBtMXSJdI","password":"XtEUTkH","email":"ZLzRIFfBtMXSJdI@gmail.com","firstName":"ZLzRIFfBtMXSJdI","lastName":"ZLzRIFfBtMXSJ
  08:14:39.159 [front-end] { id: '67418eefa437380001def28c' }
  08:14:39.159 [front-end] 67418eefa437380001def28c
  08:14:39.159 [front-end] Merging carts for customer id: 67418eefa437380001def28c and session id: 1P2MIl8q99EYHVV17TXxeSZT4XTmIAbc
  08:14:39.160 [front-end] Received response: "{\"firstName\":\"hJqPI\",\"lastName\":\"hJqPI\",\"username\":\"hJqPI\",\"id\":\"67418ed6a437380001def23e\",\"_links\":{\"addresses\":{\"href
All services, 30 seconds either side (sampled):
  08:14:09.203 [front-end] Posting Customer: {"username":"CPjEaKTsIzjy","password":"QsYJIvLDHO","email":"CPjEaKTsIzjy@gmail.com","firstName":"CPjEaKTsIzjy","lastName":"CPjEaKTsIzjy"}
  08:14:09.251 [user] ts=2024-11-23T08:14:09.25088665Z caller=middlewares.go:75 method=GetUsers id=67418ebea437380001def1fd result=1 took=2.981285ms  (×228)
  08:14:09.283 [orders] 2024-11-23 08:14:09.283 INFO [orders,c70c70fb812c6427,2b8a49939b019232,false] 8 --- [p-nio-80-exec-1] w.w.s.o.controllers.OrdersController : Received payment re  (×51)
  08:14:09.368 [front-end] Attempting to delete cart for user: 67418ecca437380001def21f  (×60)
  08:14:09.399 [front-end] POST to carts: http://carts/carts/67418ecca437380001def21f/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×30)
  08:14:09.762 [user] ts=2024-11-23T08:14:09.761733394Z caller=middlewares.go:46 method=Register username=fNsMA email=fNsMA@gmail.com took=2.603381ms
  08:14:11.159 [front-end] Order response: {"statusCode":201,"body":{"id":"67418ed33f77060008864fde","customerId":"67418ec3a437380001def20a","customer":{"id":null,"firstName":"tLynT","las
  08:14:12.733 [catalogue] ts=2024-11-23T08:14:12Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=4.00459m  (×4)
  08:14:15.256 [carts] 2024-11-23 08:14:15.256 INFO [carts,621648fd5ac7b94d,c818f6b5cc3c544a,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.ItemsController : Did not find item.  (×22)
  08:14:19.187 [front-end] Order response: {"id":"67418edb3f77060008864fe0","customerId":"67418ec9a437380001def219","customer":{"id":null,"firstName":"JXBDqcmNz","lastName":"JXBDqcmNz","u
  08:14:21.445 [front-end] Order response: {"statusCode":201,"body":{"id":"67418edd3f77060008864fe2","customerId":"67418ec6a437380001def212","customer":{"id":null,"firstName":"cobvVRyST",
  08:14:24.040 [front-end] Order response: {"statusCode":201,"body":{"id":"67418ee03f77060008864fe3","customerId":"67418ecfa437380001def224","customer":{"id":null,"firstName":"DDWcsKeJ","
  08:14:25.140 [session-db] 1:M 23 Nov 2024 08:14:25.140 * Background saving terminated with success
  08:14:29.395 [front-end] Order response: {"id":"67418ee53f77060008864fe6","customerId":"67418ecea437380001def220","customer":{"id":null,"firstName":"Nkvkz","lastName":"Nkvkz","username"
  08:14:32.250 [front-end] Order response: {"id":"67418ee83f77060008864fe8","customerId":"67418ed0a437380001def227","customer":{"id":null,"firstName":"hPcZoGR","lastName":"hPcZoGR","usern
  08:14:34.500 [front-end] Order response: {"id":"67418eea3f77060008864feb","customerId":"67418ed1a437380001def22c","customer":{"id":null,"firstName":"CPjEaKTsIzjy","lastName":"CPjEaKTsIz
  08:14:37.206 [front-end] Received response: "{\"firstName\":\"EDtKtIK\",\"lastName\":\"EDtKtIK\",\"username\":\"EDtKtIK\",\"id\":\"67418ed3a437380001def230\",\"_links\":{\"addresses\":{
  08:14:38.954 [front-end] Received response: "{\"firstName\":\"DYVdBLexbV\",\"lastName\":\"DYVdBLexbV\",\"username\":\"DYVdBLexbV\",\"id\":\"67418edca437380001def251\",\"_links\":{\"addr
  08:14:40.611 [front-end] Posting Customer: {"username":"xSCuGrFVVY","password":"ZvZaZHATBH","email":"xSCuGrFVVY@gmail.com","firstName":"xSCuGrFVVY","lastName":"xSCuGrFVVY"}
  08:14:43.623 [front-end] Order response: {"id":"67418ef33f77060008864ff6","customerId":"67418ee4a437380001def271","customer":{"id":null,"firstName":"pkXJPtnkMtdS","lastName":"pkXJPtnkMt
  08:14:45.929 [front-end] Order response: {"id":"67418ef53f77060008864ff9","customerId":"67418edba437380001def24c","customer":{"id":null,"firstName":"DdxjD","lastName":"DdxjD","username"
  08:14:49.903 [front-end] Received response: "{\"firstName\":\"LkFycXNuxs\",\"lastName\":\"LkFycXNuxs\",\"username\":\"LkFycXNuxs\",\"id\":\"67418edea437380001def25b\",\"_links\":{\"addr
  08:14:53.152 [front-end] Received response: "{\"firstName\":\"YeDArPNezEwt\",\"lastName\":\"YeDArPNezEwt\",\"username\":\"YeDArPNezEwt\",\"id\":\"67418ee0a437380001def265\",\"_links\":{
  08:14:53.359 [front-end] Order response: {"statusCode":201,"body":{"id":"67418efd3f77060008864fff","customerId":"67418ee5a437380001def272","customer":{"id":null,"firstName":"hjFZIGfA","
  08:14:55.096 [front-end] Order response: {"statusCode":201,"body":{"id":"67418eff3f77060008865001","customerId":"67418ee8a437380001def27c","customer":{"id":null,"firstName":"JhemhNebpf"
  08:14:57.065 [front-end] Order response: {"id":"67418f013f77060008865004","customerId":"67418eeea437380001def28b","customer":{"id":null,"firstName":"lNQoOhnbOqUQ","lastName":"lNQoOhnbOq
  08:14:59.247 [front-end] Received response: "{\"firstName\":\"XxeVZJdDYm\",\"lastName\":\"XxeVZJdDYm\",\"username\":\"XxeVZJdDYm\",\"id\":\"67418ef4a437380001def29a\",\"_links\":{\"addr
  08:15:00.682 [front-end] Posting Customer: {"username":"aTlufYtKJyT","password":"LNxAZyA","email":"aTlufYtKJyT@gmail.com","firstName":"aTlufYtKJyT","lastName":"aTlufYtKJyT"}
  08:15:03.851 [front-end] Order response: {"id":"67418f073f7706000886500c","customerId":"67418ef0a437380001def290","customer":{"id":null,"firstName":"xSCuGrFVVY","lastName":"xSCuGrFVVY",
  08:15:08.484 [front-end] Order response: {"id":"67418f0c3f7706000886500e","customerId":"67418ef7a437380001def2a5","customer":{"id":null,"firstName":"CYdah","lastName":"CYdah","username"

## p0715
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-14T07:54:57.504Z
```
{"service":"webservice2","message":"2021-08-14 07:54:57,504 | INFO | 0.0.0.3 | 172.17.0.4 | webservice2 | a4f7982b651d5ae6 | request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'dd1bdb64-fc91-11eb-8d96-0242ac110004', 'value': '', 'ex': 10}"}
```
Same service, the 2 minutes before (oldest first):
  07:54:52.921 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×4)
  07:54:52.988 [webservice2] INFO complete information: {'uuid': 'da503100-fc91-11eb-b21b-0242ac110004', 'user_id': 'PYaoLpfS'}  (×3)
  07:54:53.005 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×3)
  07:54:55.623 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  07:54:55.624 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×3)
  07:54:55.624 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'dbfd182e-fc91-11eb-8e43-0242ac110004', 'value': '', 'ex': 10}  (×2)
  07:54:55.713 [webservice2] INFO uuid: dbfd182e-fc91-11eb-8e43-0242ac110004 write redis successfully  (×2)
All services, 30 seconds either side (sampled):
  07:54:27.525 [mobservice2] INFO info caf1a22a-fc91-11eb-a9de-0242ac110003:whQCkgBs write success
  07:54:27.645 [webservice1] INFO uuid: cb4613be-fc91-11eb-a749-0242ac110003 write redis successfully  (×44)
  07:54:27.749 [webservice1] INFO complete information: {'uuid': 'cb4613be-fc91-11eb-a749-0242ac110003', 'user_id': 'ZQXfBztT'}  (×44)
  07:54:27.806 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'cb4613be-fc91-11eb-a749-0242ac110003'}  (×41)
  07:54:28.188 [dbservice2] INFO query = select passwards from username_table where user_name='ZQXfBztT'  (×44)
  07:54:28.541 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×51)
  07:54:29.478 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'cc365522-fc91-11eb-b412-0242ac110003', 'value': 'pQdlTEwc'}  (×53)
  07:54:29.667 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×43)
  07:54:30.892 [dbservice1] INFO ccb8b800-fc91-11eb-b617-0242ac110004-elIAhJnr-WB-Y8x)=Q&J9 token generate success token=MTYyODg5ODg3MC44OTE4OTg6Y2NiOGI4MDAtZmM5MS0xMWViLWI2MTctMDI0MmFjMTE
  07:54:33.645 [dbservice1] INFO ce70f23e-fc91-11eb-8822-0242ac110003-LPlrKejU-L/x6%5@H{.!- token generate success token=MTYyODg5ODg3My42NDUyNTQxOmNlNzBmMjNlLWZjOTEtMTFlYi04ODIyLTAyNDJhYzE
  07:54:36.329 [mobservice2] INFO info d0377f7a-fc91-11eb-b52d-0242ac110004:PDUHwGKg write success
  07:54:38.685 [mobservice1] INFO info d1a19378-fc91-11eb-b100-0242ac110004:KvpoNGOC write success
  07:54:41.038 [mobservice2] INFO info d30e954e-fc91-11eb-ab43-0242ac110003:dDmGvhol write success
  07:54:43.357 [mobservice1] INFO info d479406e-fc91-11eb-9402-0242ac110003:ZYtcmNli write success
  07:54:45.636 [mobservice1] INFO info d5d51b68-fc91-11eb-b589-0242ac110003:LXQegUZS write success
  07:54:48.046 [mobservice2] INFO info d73db852-fc91-11eb-88e7-0242ac110003:bTcUudlx write success
  07:54:50.716 [dbservice2] INFO d88fee64-fc91-11eb-ae64-0242ac110003-SgtQlrMk-1<ViNJ$gM^?l token generate success token=MTYyODg5ODg5MC43MTU1ODc2OmQ4OGZlZTY0LWZjOTEtMTFlYi1hZTY0LTAyNDJhYzE
  07:54:53.509 [dbservice2] INFO da445efc-fc91-11eb-8009-0242ac110004-ceZjduVy-g<kbF6cIC/=o token generate success token=MTYyODg5ODg5My41MDkwNTAxOmRhNDQ1ZWZjLWZjOTEtMTFlYi04MDA5LTAyNDJhYzE
  07:54:55.988 [mobservice1] INFO info dbfd182e-fc91-11eb-8e43-0242ac110004:EGieKLYv write success
  07:54:58.849 [mobservice1] INFO info dda2016c-fc91-11eb-9502-0242ac110004:lvCfjILw write success
  07:55:01.646 [mobservice2] INFO info df565a94-fc91-11eb-ab96-0242ac110004:JeRfoygk write success
  07:55:04.563 [mobservice1] INFO info e1197ae6-fc91-11eb-a7fc-0242ac110003:kmPegpXw write success
  07:55:07.591 [dbservice2] INFO e2b57a8a-fc91-11eb-9ec6-0242ac110003-JTPZbGUX-owRC0.<$@!D) token generate success token=MTYyODg5ODkwNy41OTEzNDplMmI1N2E4YS1mYzkxLTExZWItOWVjNi0wMjQyYWMxMTA
  07:55:10.747 [dbservice1] INFO e48eadea-fc91-11eb-983d-0242ac110003-tVZirvSy-RdOP!c4y.62_ token generate success token=MTYyODg5ODkxMC43NDcwMzc0OmU0OGVhZGVhLWZjOTEtMTFlYi05ODNkLTAyNDJhYzE
  07:55:13.325 [dbservice1] INFO e60bd580-fc91-11eb-97f5-0242ac110004-OvMizYlS-}giQ0AvEld(L token generate success token=MTYyODg5ODkxMy4zMjU0NDg1OmU2MGJkNTgwLWZjOTEtMTFlYi05N2Y1LTAyNDJhYzE
  07:55:16.135 [dbservice2] INFO e7c77b54-fc91-11eb-8667-0242ac110003-UFfHkLJX-@+Fs&*Co(Pu- token generate success token=MTYyODg5ODkxNi4xMzQ1OTU0OmU3Yzc3YjU0LWZjOTEtMTFlYi04NjY3LTAyNDJhYzE
  07:55:19.014 [dbservice1] INFO e973243a-fc91-11eb-88a8-0242ac110004-qfINGhoa-rp/<7NyhULi4 token generate success token=MTYyODg5ODkxOS4wMTM2OTk6ZTk3MzI0M2EtZmM5MS0xMWViLTg4YTgtMDI0MmFjMTE  (×2)
  07:55:22.810 [mobservice2] INFO info ebf4aae4-fc91-11eb-b700-0242ac110003:bAyVlxfw write success
  07:55:25.234 [mobservice2] INFO info ed6ca8ea-fc91-11eb-aead-0242ac110004:CMzFsYZh write success

## p0414
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:59:48.805Z
```
{"timestamp":1732247988805734000,"container_name":"front-end","pod_name":"front-end-ccbbfbf7f-szg8d","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"GET /catalogue 200 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  03:59:47.989 [front-end] Request received with body: {}
  03:59:47.997 [front-end] Received response: "{\"firstName\":\"vbXHKfEn\",\"lastName\":\"vbXHKfEn\",\"username\":\"vbXHKfEn\",\"id\":\"674001a4b0df5c00019b3ae3\",\"_links\":{\"addresses\
  03:59:47.997 [front-end] GET Request to: http://user/customers/674001a4b0df5c00019b3ae3/addresses  (×2)
  03:59:48.006 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"674001abb0df5c00019b3afb\",\"_links\":{\"
  03:59:48.006 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67400
  03:59:48.006 [front-end] [ undefined, undefined ]
  03:59:48.006 [front-end] Posting Order: {"customer":"http://user/customers/674001a4b0df5c00019b3ae3","address":"http://user/addresses/674001abb0df5c00019b3afa","card":"http://user/cards
  03:59:48.043 [front-end] Order response: {"statusCode":201,"body":{"id":"674001b4d94b9000069b4a9e","customerId":"674001a4b0df5c00019b3ae3","customer":{"id":null,"firstName":"vbXHKfEn","
  03:59:48.043 [front-end] Order response: {"id":"674001b4d94b9000069b4a9e","customerId":"674001a4b0df5c00019b3ae3","customer":{"id":null,"firstName":"vbXHKfEn","lastName":"vbXHKfEn","use
  03:59:48.083 [front-end] POST /orders 201 - ms - -
  03:59:48.130 [front-end] Posting Customer: {"username":"SVkbOLqUFyuYJx","password":"yEbhKYutH","email":"SVkbOLqUFyuYJx@gmail.com","firstName":"SVkbOLqUFyuYJx","lastName":"SVkbOLqUFyuYJx
  03:59:48.136 [front-end] { id: '674001b4b0df5c00019b3b1b' }
  03:59:48.136 [front-end] 674001b4b0df5c00019b3b1b
  03:59:48.136 [front-end] Merging carts for customer id: 674001b4b0df5c00019b3b1b and session id: bgeb0PO4P8vkSP2YJCF_bZryGN8vZi7s
  03:59:48.159 [front-end] Carts merged.
  03:59:48.159 [front-end] set cookie674001b4b0df5c00019b3b1b
  03:59:48.159 [front-end] Sent cookies.
  03:59:48.160 [front-end] POST /register 200 29.756 ms - 33
  03:59:48.769 [front-end] GET /catalogue 200 - ms - -
All services, 30 seconds either side (sampled):
  03:59:18.898 [catalogue] ts=2024-11-22T03:59:18Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=3.973343ms  (×64)
  03:59:19.009 [orders] 2024-11-22 03:59:19.009 INFO [orders,f027dc0dd2b92b9a,a260718262b8d277,false] 6 --- [p-nio-80-exec-4] w.w.s.o.controllers.OrdersController : Sending payment req  (×41)
  03:59:19.196 [front-end] Carts merged.  (×61)
  03:59:19.246 [queue-master] 2024-11-22 03:59:19.246 INFO 6 --- [ool-6-thread-28] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×46)
  03:59:19.705 [payment] ts=2024-11-22T03:59:19Z caller=logging.go:29 method=Authorise result=true took=775ns  (×46)
  03:59:20.095 [front-end] DELETE /cart 202 - ms - -  (×56)
  03:59:20.332 [payment] ts=2024-11-22T03:59:20Z caller=logging.go:29 method=Authorise result=true took=1.123µs  (×8)
  03:59:22.998 [front-end] Order response: {"id":"6740019ad94b9000069b4a86","customerId":"67400182b0df5c00019b3a6f","customer":{"id":null,"firstName":"kUEJskgPJddl","lastName":"kUEJskgPJd
  03:59:25.236 [front-end] Order response: {"id":"6740019dd94b9000069b4a89","customerId":"6740018bb0df5c00019b3a90","customer":{"id":null,"firstName":"bpojczUeN","lastName":"bpojczUeN","u
  03:59:26.697 [front-end] Received response: "{\"firstName\":\"XKNFApPwjrdxbW\",\"lastName\":\"XKNFApPwjrdxbW\",\"username\":\"XKNFApPwjrdxbW\",\"id\":\"6740018cb0df5c00019b3a92\",\"_lin
  03:59:28.569 [front-end] Order response: {"id":"674001a0d94b9000069b4a8f","customerId":"67400187b0df5c00019b3a7e","customer":{"id":null,"firstName":"uPggUnQ","lastName":"uPggUnQ","usern
  03:59:30.266 [front-end] Order response: {"statusCode":201,"body":{"id":"674001a2d94b9000069b4a91","customerId":"6740018eb0df5c00019b3aa0","customer":{"id":null,"firstName":"YuoCJVzwN",
  03:59:33.870 [front-end] Posting Customer: {"username":"NGUNpVsSLoO","password":"omNdhR","email":"NGUNpVsSLoO@gmail.com","firstName":"NGUNpVsSLoO","lastName":"NGUNpVsSLoO"}
  03:59:37.470 [front-end] Order response: {"statusCode":201,"body":{"id":"674001a9d94b9000069b4a95","customerId":"67400197b0df5c00019b3ac0","customer":{"id":null,"firstName":"pJYADOpahdf
  03:59:38.336 [front-end] Order response: {"id":"674001aad94b9000069b4a98","customerId":"6740019ab0df5c00019b3aca","customer":{"id":null,"firstName":"BlShGA","lastName":"BlShGA","usernam
  03:59:39.457 [queue-master] 2024-11-22 03:59:39.456 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×27)
  03:59:42.742 [user] ts=2024-11-22T03:59:42.742753603Z caller=middlewares.go:46 method=Register username=NqPqN email=NqPqN@gmail.com took=1.356225ms
  03:59:47.314 [front-end] Order response: {"statusCode":201,"body":{"id":"674001b3d94b9000069b4a9d","customerId":"674001a1b0df5c00019b3adb","customer":{"id":null,"firstName":"LUyqlIvHO",
  03:59:49.996 [front-end] Order response: {"statusCode":201,"body":{"id":"674001b5d94b9000069b4aa0","customerId":"6740019db0df5c00019b3ad3","customer":{"id":null,"firstName":"OdfZQKJyF",
  03:59:54.162 [front-end] Order response: {"statusCode":201,"body":{"id":"674001bad94b9000069b4aa2","customerId":"674001a5b0df5c00019b3ae4","customer":{"id":null,"firstName":"dXiPATGXH",
  03:59:56.164 [front-end] Order response: {"statusCode":201,"body":{"id":"674001bcd94b9000069b4aa5","customerId":"674001a9b0df5c00019b3af1","customer":{"id":null,"firstName":"cdiwQUs","l
  03:59:57.392 [front-end] Posting Customer: {"username":"fmBlDqzcjPXs","password":"xbwIydSvP","email":"fmBlDqzcjPXs@gmail.com","firstName":"fmBlDqzcjPXs","lastName":"fmBlDqzcjPXs"}
  04:00:01.735 [front-end] Posting Customer: {"username":"waKrxCZTPjAQk","password":"HFqVvuWsL","email":"waKrxCZTPjAQk@gmail.com","firstName":"waKrxCZTPjAQk","lastName":"waKrxCZTPjAQk"}
  04:00:04.604 [front-end] Posting Customer: {"username":"AUElEGHPZI","password":"gpTmAB","email":"AUElEGHPZI@gmail.com","firstName":"AUElEGHPZI","lastName":"AUElEGHPZI"}
  04:00:06.566 [front-end] Received response: "{\"firstName\":\"NyUgn\",\"lastName\":\"NyUgn\",\"username\":\"NyUgn\",\"id\":\"674001b7b0df5c00019b3b25\",\"_links\":{\"addresses\":{\"href
  04:00:07.749 [user] ts=2024-11-22T04:00:07.745600327Z caller=middlewares.go:46 method=Register username=wbngOX email=wbngOX@gmail.com took=1.144399ms
  04:00:13.707 [front-end] Posting Customer: {"username":"gpreFPTldfdhn","password":"CZiJjj","email":"gpreFPTldfdhn@gmail.com","firstName":"gpreFPTldfdhn","lastName":"gpreFPTldfdhn"}
  04:00:15.149 [front-end] Posting Customer: {"username":"DHAouUECcjh","password":"uljdJep","email":"DHAouUECcjh@gmail.com","firstName":"DHAouUECcjh","lastName":"DHAouUECcjh"}
  04:00:17.866 [front-end] Posting Customer: {"username":"KaYKgP","password":"lDADOf","email":"KaYKgP@gmail.com","firstName":"KaYKgP","lastName":"KaYKgP"}
