## p0783
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service payment, 2024-11-24T13:44:24.857Z
```
{"timestamp":1732455864857422000,"container_name":"payment","pod_name":"payment-78bf948dc4-fxv9x","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-24T13:44:24Z caller=logging.go:29 method=Authorise result=false took=5.502µs"}
```
Same service, the 2 minutes before (oldest first):
  13:44:10.738 [payment] ts=2024-11-24T13:44:10Z caller=logging.go:29 method=Authorise result=true took=707ns  (×9)
  13:44:13.039 [payment] ts=2024-11-24T13:44:13Z caller=logging.go:40 method=Health result=1 took=5.595µs  (×8)
  13:44:13.244 [payment] ts=2024-11-24T13:44:13Z caller=logging.go:29 method=Authorise result=true took=1.181µs  (×2)
  13:44:17.864 [payment] ts=2024-11-24T13:44:17Z caller=logging.go:29 method=Authorise result=false took=5.657µs
All services, 30 seconds either side (sampled):
  13:43:55.009 [front-end] Posting Customer: {"username":"bmZgCJWzTSCseXx","password":"RPOnxdhpv","email":"bmZgCJWzTSCseXx@gmail.com","firstName":"bmZgCJWzTSCseXx","lastName":"bmZgCJWzTSC
  13:43:55.050 [front-end] GET /catalogue 200 - ms - -  (×59)
  13:43:55.224 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67432  (×60)
  13:43:55.250 [shipping] Adding shipment to queue...  (×53)
  13:43:55.278 [carts] 2024-11-24 13:43:55.277 INFO [carts,e6c445d7e113d9b4,1f767d45e54e83bc,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.controllers.ItemsController : Did not find item.  (×40)
  13:43:55.916 [orders] 2024-11-24 13:43:55.915 INFO [orders,fca1b15d23ed4a63,6e5b7ea83cb95771,false] 7 --- [p-nio-80-exec-2] w.w.s.o.controllers.OrdersController : Received payment re  (×45)
  13:43:57.963 [front-end] Received response: "{\"firstName\":\"FscbswrMi\",\"lastName\":\"FscbswrMi\",\"username\":\"FscbswrMi\",\"id\":\"67432d8df6d875000162061f\",\"_links\":{\"address
  13:44:00.075 [front-end] Received response: "{\"firstName\":\"voZAjzQbwxx\",\"lastName\":\"voZAjzQbwxx\",\"username\":\"voZAjzQbwxx\",\"id\":\"67432d92f6d875000162062d\",\"_links\":{\"a
  13:44:02.147 [front-end] Order response: {"id":"67432da2c4380300078a49a9","customerId":"67432d8ef6d8750001620625","customer":{"id":null,"firstName":"oPLiAGKNlVdYA","lastName":"oPLiAGKNl
  13:44:03.765 [queue-master] 2024-11-24 13:44:03.765 ERROR 7 --- [pool-6-thread-2] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×9)
  13:44:05.294 [front-end] Received response: "{\"firstName\":\"EuTjoz\",\"lastName\":\"EuTjoz\",\"username\":\"EuTjoz\",\"id\":\"67432d97f6d875000162063c\",\"_links\":{\"addresses\":{\"h
  13:44:07.525 [user] ts=2024-11-24T13:44:07.525535758Z caller=middlewares.go:46 method=Register username=jimOXULBw email=jimOXULBw@gmail.com took=1.794445ms
  13:44:09.538 [front-end] Order response: {"id":"67432da9c4380300078a49b3","customerId":"67432d94f6d8750001620634","customer":{"id":null,"firstName":"xnwJWG","lastName":"xnwJWG","usernam
  13:44:11.148 [user] ts=2024-11-24T13:44:11.147905313Z caller=middlewares.go:46 method=Register username=xuBmYTBRh email=xuBmYTBRh@gmail.com took=2.034475ms
  13:44:13.257 [front-end] Order response: {"statusCode":201,"body":{"id":"67432dadc4380300078a49b9","customerId":"67432d9bf6d8750001620646","customer":{"id":null,"firstName":"bmZgCJWzTSC
  13:44:17.059 [front-end] Posting Customer: {"username":"QJcmDDccjPBklKc","password":"Djqxap","email":"QJcmDDccjPBklKc@gmail.com","firstName":"QJcmDDccjPBklKc","lastName":"QJcmDDccjPBklK
  13:44:21.992 [front-end] Received response: "{\"firstName\":\"sVAFwkKPFH\",\"lastName\":\"sVAFwkKPFH\",\"username\":\"sVAFwkKPFH\",\"id\":\"67432d9ef6d875000162065d\",\"_links\":{\"addr
  13:44:22.782 [front-end] Order response: {"id":"67432db6c4380300078a49bf","customerId":"67432da3f6d8750001620669","customer":{"id":null,"firstName":"fzmtXvultKAzW","lastName":"fzmtXvult
  13:44:29.366 [front-end] Posting Customer: {"username":"IzSgX","password":"KHLVTeVp","email":"IzSgX@gmail.com","firstName":"IzSgX","lastName":"IzSgX"}
  13:44:32.582 [front-end] Order response: {"id":"67432dc0c4380300078a49c4","customerId":"67432dadf6d8750001620680","customer":{"id":null,"firstName":"pAhYLwzaPNwMQ","lastName":"pAhYLwzaP
  13:44:34.998 [front-end] Received response: "{\"firstName\":\"dcazMJhNaHMDhN\",\"lastName\":\"dcazMJhNaHMDhN\",\"username\":\"dcazMJhNaHMDhN\",\"id\":\"67432db0f6d8750001620689\",\"_lin
  13:44:36.410 [front-end] Posting Customer: {"username":"sJYobZOTxjEclja","password":"OKVLR","email":"sJYobZOTxjEclja@gmail.com","firstName":"sJYobZOTxjEclja","lastName":"sJYobZOTxjEclja
  13:44:38.731 [front-end] Order response: {"statusCode":201,"body":{"id":"67432dc6c4380300078a49cd","customerId":"67432db5f6d875000162069d","customer":{"id":null,"firstName":"bBxUoRFNHZp
  13:44:39.488 [front-end] Received response: "{\"firstName\":\"vKeqjLcHflbSm\",\"lastName\":\"vKeqjLcHflbSm\",\"username\":\"vKeqjLcHflbSm\",\"id\":\"67432db7f6d87500016206aa\",\"_links\
  13:44:43.343 [front-end] Order response: {"statusCode":201,"body":{"id":"67432dcbc4380300078a49d2","customerId":"67432db6f6d87500016206a1","customer":{"id":null,"firstName":"UPpAcuiDEgz
  13:44:47.705 [front-end] Posting Customer: {"username":"rGDTXEMY","password":"egXBpcn","email":"rGDTXEMY@gmail.com","firstName":"rGDTXEMY","lastName":"rGDTXEMY"}
  13:44:50.603 [front-end] Order response: {"statusCode":201,"body":{"id":"67432dd2c4380300078a49d3","customerId":"67432dbdf6d87500016206b7","customer":{"id":null,"firstName":"IzSgX","las
  13:44:52.704 [front-end] Order response: {"statusCode":201,"body":{"id":"67432dd4c4380300078a49d5","customerId":"67432dbaf6d87500016206af","customer":{"id":null,"firstName":"ZpZtfLtSzSv

## p0245
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:04.955Z
```
{"timestamp":1732242484955127000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Card: {\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"userID\":\"673fec2db0df5c00019af952\"}"}
```
Same service, the 2 minutes before (oldest first):
  02:28:03.392 [front-end] 673fec33b0df5c00019af962  (×3)
  02:28:03.392 [front-end] Merging carts for customer id: 673fec33b0df5c00019af962 and session id: D-ltML2PKwiyNToE8YIFfZBS5CSXH2nW  (×3)
  02:28:03.410 [front-end] Carts merged.  (×2)
  02:28:03.410 [front-end] set cookie673fec33b0df5c00019af962  (×2)
  02:28:03.411 [front-end] Sent cookies.  (×2)
  02:28:03.413 [front-end] POST /register 200 24.797 ms - 33  (×2)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:03.525 [front-end] { id: '673fec33b0df5c00019af963' }  (×2)
  02:28:04.929 [front-end] Posting Customer: {"username":"JGQXvUjPbFrtK","password":"HtglbTyNG","email":"JGQXvUjPbFrtK@gmail.com","firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPbFrtK"}
  02:28:04.939 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af952"}
  02:28:04.949 [front-end] POST /addresses 200 - ms - -
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×32)
  02:28:03.118 [catalogue] ts=2024-11-22T02:28:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.040202ms  (×36)
  02:28:03.190 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af953/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×18)
  02:28:03.211 [user] ts=2024-11-22T02:28:03.211690554Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=1.207621ms  (×36)
  02:28:03.252 [front-end] POST /orders 500 - ms - -  (×30)
  02:28:03.410 [front-end] Carts merged.  (×31)
  02:28:04.929 [front-end] Posting Customer: {"username":"JGQXvUjPbFrtK","password":"HtglbTyNG","email":"JGQXvUjPbFrtK@gmail.com","firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPbFrtK"}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:06.800 [user] ts=2024-11-22T02:28:06.800234478Z caller=middlewares.go:46 method=Register username=oyShDJ email=oyShDJ@gmail.com took=993.111µs
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.197 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×4)
  02:28:16.205 [front-end] Received response: "{\"firstName\":\"WiHheQzgSpJzgy\",\"lastName\":\"WiHheQzgSpJzgy\",\"username\":\"WiHheQzgSpJzgy\",\"id\":\"673fec2db0df5c00019af952\",\"_lin
  02:28:17.879 [user] ts=2024-11-22T02:28:17.879034554Z caller=middlewares.go:46 method=Register username=QGHrdp email=QGHrdp@gmail.com took=1.008054ms
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:21.971 [user] ts=2024-11-22T02:28:21.971606392Z caller=middlewares.go:46 method=Register username=PDQejFz email=PDQejFz@gmail.com took=1.195014ms
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=1.213µs  (×4)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.819 [front-end] Received response: "{\"firstName\":\"KoWsmDtUqsE\",\"lastName\":\"KoWsmDtUqsE\",\"username\":\"KoWsmDtUqsE\",\"id\":\"673fec2cb0df5c00019af949\",\"_links\":{\"a
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:25.786 [shipping] 2024-11-22 02:28:25.786 INFO [shipping,fb98be28dae5ea9a,b566bc7933720160,false] 7 --- [p-nio-80-exec-6] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.957 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","l
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFr
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:27.463 [orders-db] {"t":{"$date":"2024-11-22T02:28:27.462+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: java.lang.RuntimeException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock) at com.google.commo
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×12)

## p0548
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-ui-dashboard, 2024-12-07T18:20:36.117Z
```
{"timestamp":1733595636117108700,"container_name":"ts-ui-dashboard","pod_name":"ts-ui-dashboard-667c5cdd98-x99xl","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"127.0.0.1 - - [08/Dec/2024:02:20:36 +0800] \"GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1\" 200 202 \"-\" \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36\""}
```
Same service, the 2 minutes before (oldest first):
  18:20:23.412 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:20:23 +0800] "POST /api/v1/orderOtherService/orderOther/refresh HTTP/1.1" 200 9126 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_
  18:20:23.461 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:20:23 +0800] "PUT /api/v1/consignservice/consigns HTTP/1.1" 200 400 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebK
  18:20:26.094 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:20:26 +0800] "POST /api/v1/users/login HTTP/1.1" 200 353 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×6)
  18:20:26.381 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:20:26 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×5)
  18:20:28.312 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:20:28 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 343 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW
  18:20:30.401 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:20:30 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×6)
All services, 30 seconds either side (sampled):
  18:20:06.253 [ts-auth-service] 2024-12-07 18:20:06.253 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×24)
  18:20:06.337 [ts-travel-service] 2024-12-07 18:20:06.337 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×16)
  18:20:07.026 [ts-admin-basic-info-service] 2024-12-07 18:20:07.026 INFO 1 --- [io-18767-exec-1] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×11)
  18:20:08.987 [ts-consign-service] 2024-12-07 18:20:08.987 INFO 1 --- [io-16111-exec-6] consign.service.ConsignServiceImpl : The handle date is 2024-12-07  (×3)
  18:20:13.180 [ts-travel2-service] 2024-12-07 18:20:13.180 INFO 1 --- [io-16346-exec-9] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×13)
  18:20:13.300 [ts-price-service] 2024-12-07 18:20:13.300 INFO 1 --- [io-16579-exec-9] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×23)
  18:20:13.392 [ts-seat-service] 2024-12-07 18:20:13.391 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×39)
  18:20:13.444 [ts-travel2-service] 2024-12-07 18:20:13.444 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×26)
  18:20:13.533 [ts-seat-service] 2024-12-07 18:20:13.533 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×3)
  18:20:17.629 [ts-order-other-service] 2024-12-07 18:20:17.629 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×2)
  18:20:18.703 [ts-inside-payment-service] 2024-12-07 18:20:18.703 INFO 1 --- [io-18673-exec-2] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.
  18:20:19.790 [ts-basic-service] 2024-12-07 18:20:19.789 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×2)
  18:20:19.883 [ts-travel-service] 2024-12-07 18:20:19.882 INFO 1 --- [io-12346-exec-5] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234  (×6)
  18:20:19.989 [ts-travel2-service] 2024-12-07 18:20:19.989 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×2)
  18:20:20.161 [ts-order-service] 2024-12-07 18:20:20.161 INFO 1 --- [io-12031-exec-3] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×5)
  18:20:20.785 [ts-travel-service] 2024-12-07 18:20:20.784 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×3)
  18:20:22.036 [ts-travel-service] 2024-12-07 18:20:22.036 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×4)
  18:20:27.379 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-07T18:20:27.379+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359562
  18:20:30.105 [ts-admin-travel-service] 2024-12-07 18:20:30.104 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]
  18:20:33.597 [ts-auth-service] 2024-12-07 18:20:33.597 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
  18:20:44.695 [ts-food-service] 2024-12-07 18:20:44.695 INFO 1 --- [io-18856-exec-5] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×4)
  18:20:55.634 [ts-order-service] 2024-12-07 18:20:55.633 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160, 
  18:20:55.906 [ts-preserve-service] 2024-12-07 18:20:55.905 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Other Service][Check Security] Checking....
  18:20:55.961 [ts-security-service] 2024-12-07 18:20:55.961 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service] Max In One Hour: 2147483647 Max Not Use: 21474836
  18:20:55.977 [ts-preserve-service] 2024-12-07 18:20:55.977 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] TripId: D1345
  18:20:56.360 [ts-preserve-service] 2024-12-07 18:20:56.359 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Station Name]  (×2)
  18:20:56.578 [ts-order-service] 2024-12-07 18:20:56.578 INFO 1 --- [io-12031-exec-7] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at 
  18:20:56.609 [ts-preserve-service] 2024-12-07 18:20:56.608 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Service][Add food Order] Creating....

## p0792
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T20:43:56.203Z
```
{"timestamp":1732394636203848700,"container_name":"front-end","pod_name":"front-end-f77549869-gbrgw","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"npm ERR! A complete log of this run can be found in:"}
```
Same service, the 2 minutes before (oldest first):
  20:43:56.197 [front-end] npm notice Changelog: <https://github.com/npm/cli/releases/tag/v10.9.1>
  20:43:56.197 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!
  20:43:56.197 [front-end] npm notice 
  20:43:56.199 [front-end] npm verb stack Error: command failed
  20:43:56.199 [front-end] npm verb stack at ChildProcess.<anonymous> (/usr/local/lib/node_modules/npm/node_modules/@npmcli/promise-spawn/lib/index.js:63:27)
  20:43:56.199 [front-end] npm verb stack at ChildProcess.emit (node:events:513:28)
  20:43:56.199 [front-end] npm verb stack at maybeClose (node:internal/child_process:1100:16)
  20:43:56.199 [front-end] npm verb stack at Process.ChildProcess._handle.onexit (node:internal/child_process:304:5)
  20:43:56.199 [front-end] npm verb pkgid microservices-demo-front-end@0.0.1
  20:43:56.199 [front-end] npm verb cwd /usr/src/app
  20:43:56.199 [front-end] npm verb Linux 5.10.227-219.884.amzn2.x86_64
  20:43:56.199 [front-end] npm verb node v16.20.2
  20:43:56.200 [front-end] npm verb npm v8.19.4
  20:43:56.200 [front-end] npm ERR! path /usr/src/app
  20:43:56.201 [front-end] npm ERR! command failed
  20:43:56.201 [front-end] npm ERR! signal SIGTERM
  20:43:56.201 [front-end] npm ERR! command sh -c -- node server.js
  20:43:56.202 [front-end] npm verb exit 1
  20:43:56.202 [front-end] npm timing npm Completed in 820297ms
  20:43:56.203 [front-end] npm verb code 1 
All services, 30 seconds either side (sampled):
  20:43:26.602 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67423e6848485600016b4dee"}  (×61)
  20:43:26.650 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67423e5c48485600016b4dc6\",\"_links\":{\"  (×55)
  20:43:26.678 [queue-master] 2024-11-23 20:43:26.678 INFO 7 --- [ool-6-thread-24] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×81)
  20:43:26.717 [catalogue] ts=2024-11-23T20:43:26Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=5.324115  (×51)
  20:43:27.083 [carts] 2024-11-23 20:43:27.082 INFO [carts,251acdcde5635ecb,d8b937904898ac8d,false] 6 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×32)
  20:43:27.931 [catalogue] ts=2024-11-23T20:43:27Z caller=logging.go:85 method=Health result=2 took=25.188µs  (×40)
  20:43:28.997 [front-end] Order response: {"id":"67423e704ca85a00070c6232","customerId":"67423e5c48485600016b4dc7","customer":{"id":null,"firstName":"jsCNkxwYYyef","lastName":"jsCNkxwYYy
  20:43:34.096 [user] ts=2024-11-23T20:43:34.096106916Z caller=middlewares.go:46 method=Register username=bILYhc email=bILYhc@gmail.com took=5.749588ms
  20:43:36.848 [front-end] Received response: "{\"firstName\":\"HGkBwdf\",\"lastName\":\"HGkBwdf\",\"username\":\"HGkBwdf\",\"id\":\"67423e6548485600016b4de2\",\"_links\":{\"addresses\":{
  20:43:38.614 [front-end] npm info using npm@8.19.4  (×2)
  20:43:38.615 [front-end] npm timing config:load:user Completed in 1ms  (×2)
  20:43:38.615 [front-end] npm timing npm:load:setTitle Completed in 0ms  (×2)
  20:43:38.804 [front-end] > microservices-demo-front-end@0.0.1 start  (×2)
  20:43:40.614 [front-end] Using the redis based session manager  (×2)
  20:43:41.302 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e7d4ca85a00070c623a","customerId":"67423e6548485600016b4de5","customer":{"id":null,"firstName":"NYxxCuBu","
  20:43:42.588 [front-end] Posting Customer: {"username":"iFbDWBYwKgB","password":"xYyfS","email":"iFbDWBYwKgB@gmail.com","firstName":"iFbDWBYwKgB","lastName":"iFbDWBYwKgB"}
  20:43:43.625 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e7f4ca85a00070c623f","customerId":"67423e6848485600016b4ded","customer":{"id":null,"firstName":"mwCsrQqSuLK
  20:43:45.076 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e814ca85a00070c6242","customerId":"67423e6b48485600016b4dfd","customer":{"id":null,"firstName":"HnfwP","las
  20:43:46.190 [front-end] Order response: {"id":"67423e824ca85a00070c6244","customerId":"67423e6c48485600016b4e01","customer":{"id":null,"firstName":"oevYNrzlhVs","lastName":"oevYNrzlhVs
  20:43:50.745 [front-end] Received response: "{\"firstName\":\"OeRiOYxQG\",\"lastName\":\"OeRiOYxQG\",\"username\":\"OeRiOYxQG\",\"id\":\"67423e6f48485600016b4e0a\",\"_links\":{\"address
  20:43:52.635 [queue-master] 2024-11-23 20:43:52.635 INFO 7 --- [pool-6-thread-3] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×3)
  20:43:55.586 [front-end] Received response: "{\"firstName\":\"KlUZKgugvMgw\",\"lastName\":\"KlUZKgugvMgw\",\"username\":\"KlUZKgugvMgw\",\"id\":\"67423e7748485600016b4e28\",\"_links\":{
  20:43:56.199 [front-end] npm verb stack at ChildProcess.emit (node:events:513:28)
  20:43:56.201 [front-end] npm ERR! command sh -c -- node server.js
  20:44:00.614 [carts-db] {"t":{"$date":"2024-11-23T20:44:00.614+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173239464
  20:44:05.506 [front-end] Posting Customer: {"username":"LrzknHXn","password":"pkvqFBu","email":"LrzknHXn@gmail.com","firstName":"LrzknHXn","lastName":"LrzknHXn"}
  20:44:09.020 [front-end] Posting Order: {"customer":"http://user/customers/67423e8348485600016b4e4a","address":null,"card":null,"items":"http://carts/carts/67423e8348485600016b4e4a/item  (×3)
  20:44:13.628 [user] ts=2024-11-23T20:44:13.628246773Z caller=middlewares.go:46 method=Register username=IHVhJbg email=IHVhJbg@gmail.com took=4.491254ms
  20:44:18.402 [front-end] Posting Customer: {"username":"ZHkxe","password":"yRiRZs","email":"ZHkxe@gmail.com","firstName":"ZHkxe","lastName":"ZHkxe"}
  20:44:22.070 [front-end] Received response: "{\"firstName\":\"jwdqjMXXKLuVVy\",\"lastName\":\"jwdqjMXXKLuVVy\",\"username\":\"jwdqjMXXKLuVVy\",\"id\":\"67423e9148485600016b4e62\",\"_lin

## p0288
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:36:01.715Z
```
{"timestamp":1732242961715887000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Sent cookies."}
```
Same service, the 2 minutes before (oldest first):
  02:36:01.333 [front-end] set cookie673fee11b0df5c00019aff07  (×2)
  02:36:01.333 [front-end] Sent cookies.
  02:36:01.336 [front-end] POST /register 200 28.697 ms - 33
  02:36:01.571 [front-end] Request received with body: {}
  02:36:01.578 [front-end] Received response: "{\"firstName\":\"YDdAYWUVusVlhtV\",\"lastName\":\"YDdAYWUVusVlhtV\",\"username\":\"YDdAYWUVusVlhtV\",\"id\":\"673fedfdb0df5c00019afecb\",\"_
  02:36:01.578 [front-end] GET Request to: http://user/customers/673fedfdb0df5c00019afecb/addresses  (×2)
  02:36:01.586 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:36:01.586 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fee04b0df5c00019afee3\",\"_links\":{\"
  02:36:01.586 [front-end] [ undefined, undefined ]
  02:36:01.586 [front-end] Posting Order: {"customer":"http://user/customers/673fedfdb0df5c00019afecb","address":"http://user/addresses/673fee04b0df5c00019afee2","card":"http://user/cards
  02:36:01.619 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee11d94b9000069b3b78","customerId":"673fedfdb0df5c00019afecb","customer":{"id":null,"firstName":"YDdAYWUVusV
  02:36:01.619 [front-end] Order response: {"id":"673fee11d94b9000069b3b78","customerId":"673fedfdb0df5c00019afecb","customer":{"id":null,"firstName":"YDdAYWUVusVlhtV","lastName":"YDdAYWU
  02:36:01.621 [front-end] POST /orders 201 - ms - -
  02:36:01.688 [front-end] Posting Customer: {"username":"JBWrRuxbFG","password":"xAfxJroLT","email":"JBWrRuxbFG@gmail.com","firstName":"JBWrRuxbFG","lastName":"JBWrRuxbFG"}
  02:36:01.694 [front-end] { id: '673fee11b0df5c00019aff08' }
  02:36:01.694 [front-end] 673fee11b0df5c00019aff08
  02:36:01.694 [front-end] Merging carts for customer id: 673fee11b0df5c00019aff08 and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_
  02:36:01.715 [front-end] Carts merged.
All services, 30 seconds either side (sampled):
  02:35:31.834 [front-end] Posting Customer: {"username":"nxbqVBBGTlw","password":"TIBBft","email":"nxbqVBBGTlw@gmail.com","firstName":"nxbqVBBGTlw","lastName":"nxbqVBBGTlw"}
  02:35:32.513 [user] ts=2024-11-22T02:35:32.513572069Z caller=middlewares.go:75 method=GetUsers id=673fedddb0df5c00019afe63 result=1 took=1.040729ms  (×51)
  02:35:32.552 [orders] 2024-11-22 02:35:32.552 INFO [orders,1efe35a1fdad19a2,12b131c2bbf46494,false] 6 --- [p-nio-80-exec-4] w.w.s.o.controllers.OrdersController : Received payment re  (×37)
  02:35:32.958 [payment] ts=2024-11-22T02:35:32Z caller=logging.go:29 method=Authorise result=true took=796ns  (×29)
  02:35:33.251 [carts] 2024-11-22 02:35:33.251 INFO [carts,961d89ec7dd6effa,044e3c0369c8a8d3,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.controllers.CartsController : Merge carts reques  (×27)
  02:35:33.457 [catalogue] ts=2024-11-22T02:35:33Z caller=logging.go:62 method=Get id=3395a43e-2d88-40de-b95f-e00e1502085b sock=3395a43e-2d88-40de-b95f-e00e1502085b err=null took=4.174218  (×56)
  02:35:34.352 [catalogue] ts=2024-11-22T02:35:34Z caller=logging.go:85 method=Health result=2 took=26.791µs  (×40)
  02:35:36.405 [front-end] Order response: {"statusCode":201,"body":{"id":"673fedf8d94b9000069b3b61","customerId":"673fede3b0df5c00019afe74","customer":{"id":null,"firstName":"gnjPFWHQ","
  02:35:39.411 [front-end] Received response: "{\"firstName\":\"saRyHeIupdtu\",\"lastName\":\"saRyHeIupdtu\",\"username\":\"saRyHeIupdtu\",\"id\":\"673fede9b0df5c00019afe8c\",\"_links\":{
  02:35:40.748 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×8)
  02:35:43.033 [carts] 2024-11-22 02:35:43.033 INFO [carts,943543ee8e2bdca3,1e48aa6951d4e20a,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.ItemsController : Did not find item.  (×27)
  02:35:45.018 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×8)
  02:35:47.406 [user] ts=2024-11-22T02:35:47.406155393Z caller=middlewares.go:46 method=Register username=VphfbhxJ email=VphfbhxJ@gmail.com took=1.004448ms
  02:35:49.576 [front-end] Order response: {"id":"673fee05d94b9000069b3b6f","customerId":"673fedefb0df5c00019afe9d","customer":{"id":null,"firstName":"BJFiR","lastName":"BJFiR","username"
  02:35:52.238 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×8)
  02:35:56.551 [front-end] Posting Customer: {"username":"jIUbakcZezTGhkj","password":"ewRbwj","email":"jIUbakcZezTGhkj@gmail.com","firstName":"jIUbakcZezTGhkj","lastName":"jIUbakcZezTGhk
  02:35:59.240 [front-end] Received response: "{\"firstName\":\"tbBanYWlqACR\",\"lastName\":\"tbBanYWlqACR\",\"username\":\"tbBanYWlqACR\",\"id\":\"673fedfab0df5c00019afec4\",\"_links\":{
  02:36:01.619 [front-end] Order response: {"id":"673fee11d94b9000069b3b78","customerId":"673fedfdb0df5c00019afecb","customer":{"id":null,"firstName":"YDdAYWUVusVlhtV","lastName":"YDdAYWU
  02:36:02.479 [front-end] Order response: {"id":"673fee12d94b9000069b3b7b","customerId":"673fedf5b0df5c00019afeb5","customer":{"id":null,"firstName":"JnWwKCaFOB","lastName":"JnWwKCaFOB",
  02:36:05.815 [front-end] Received response: "{\"firstName\":\"aTeoa\",\"lastName\":\"aTeoa\",\"username\":\"aTeoa\",\"id\":\"673fee06b0df5c00019afee5\",\"_links\":{\"addresses\":{\"href
  02:36:08.086 [front-end] Received response: "{\"firstName\":\"dTjFLLTecLu\",\"lastName\":\"dTjFLLTecLu\",\"username\":\"dTjFLLTecLu\",\"id\":\"673fee08b0df5c00019afeeb\",\"_links\":{\"a
  02:36:09.876 [front-end] Order response: {"id":"673fee19d94b9000069b3b84","customerId":"673fee02b0df5c00019afed9","customer":{"id":null,"firstName":"sxrgNEkG","lastName":"sxrgNEkG","use
  02:36:12.860 [front-end] Order response: {"id":"673fee1cd94b9000069b3b87","customerId":"673fee0db0df5c00019afefc","customer":{"id":null,"firstName":"YrUAWHZ","lastName":"YrUAWHZ","usern
  02:36:18.301 [front-end] Posting Customer: {"username":"rRAAicI","password":"bESAaUwf","email":"rRAAicI@gmail.com","firstName":"rRAAicI","lastName":"rRAAicI"}
  02:36:20.298 [front-end] Posting Customer: {"username":"IJSMYJkEmzTpk","password":"lVXXPfCYF","email":"IJSMYJkEmzTpk@gmail.com","firstName":"IJSMYJkEmzTpk","lastName":"IJSMYJkEmzTpk"}
  02:36:21.790 [user] ts=2024-11-22T02:36:21.790586768Z caller=middlewares.go:46 method=Register username=cUeWQ email=cUeWQ@gmail.com took=976.437µs
  02:36:25.315 [front-end] Posting Customer: {"username":"DwAEkhQZhxpmE","password":"GHselL","email":"DwAEkhQZhxpmE@gmail.com","firstName":"DwAEkhQZhxpmE","lastName":"DwAEkhQZhxpmE"}
  02:36:26.529 [front-end] Posting Customer: {"username":"MKoyaxvRzlV","password":"yiHMMoKO","email":"MKoyaxvRzlV@gmail.com","firstName":"MKoyaxvRzlV","lastName":"MKoyaxvRzlV"}
  02:36:30.059 [front-end] Posting Customer: {"username":"MZqHKhjuFh","password":"KKMsbqIu","email":"MZqHKhjuFh@gmail.com","firstName":"MZqHKhjuFh","lastName":"MZqHKhjuFh"}

## p0229
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T07:52:32.569Z
```
{"timestamp":1731916352569687300,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Getting supported currencies..."}
```
Same service, the 2 minutes before (oldest first):
  07:52:30.640 [currencyservice] conversion request successful  (×16)
  07:52:31.425 [currencyservice] Getting supported currencies...  (×4)
All services, 30 seconds either side (sampled):
  07:52:02.627 [frontend] request started  (×331)
  07:52:02.636 [cartservice] GetCartAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4  (×276)
  07:52:02.659 [adservice] received ad request (context_words=[accessories])  (×38)
  07:52:02.807 [frontend] home  (×25)
  07:52:03.245 [adservice] received ad request (context_words=[footwear])  (×17)
  07:52:03.826 [adservice] received ad request (context_words=[kitchen])  (×55)
  07:52:03.843 [frontend] view user cart  (×70)
  07:52:03.887 [frontend] placing order  (×16)
  07:52:03.911 [paymentservice] Transaction processed: visa ending 3558 Amount: EUR700.433436536  (×2)
  07:52:03.915 [shippingservice] [ShipOrder] completed request  (×16)
  07:52:03.939 [emailservice] A request to send order confirmation email to roachjames@example.net has been received.
  07:52:05.431 [checkoutservice] [PlaceOrder] user_id="736a09b5-665e-4823-8520-b8602b0bdbff" user_currency="CAD"  (×5)
  07:52:05.468 [emailservice] A request to send order confirmation email to ccraig@example.com has been received.
  07:52:12.120 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"53","nanos":940000000},"credit_card":{"credit_card_number":"488826840967575  (×4)
  07:52:12.135 [checkoutservice] failed to send order confirmation to "whooper@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:52:16.643 [checkoutservice] failed to send order confirmation to "cardenasjennifer@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:52:17.897 [paymentservice] Transaction processed: visa ending 3861 Amount: JPY74792.350287706  (×2)
  07:52:18.607 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '66VCHSJNUP']  (×2)
  07:52:24.904 [emailservice] A request to send order confirmation email to maryanthony@example.net has been received.
  07:52:26.986 [checkoutservice] failed to send order confirmation to "julie62@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:52:33.589 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N']  (×2)
  07:52:44.412 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"2195","nanos":411040286},"credit_card":{"credit_card_number":"4425090184044  (×3)
  07:52:44.425 [checkoutservice] failed to send order confirmation to "shawnsimon@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:52:46.628 [emailservice] A request to send order confirmation email to richardsgregory@example.org has been received.
  07:52:47.712 [checkoutservice] failed to send order confirmation to "osbornchristopher@example.org": rpc error: code = Internal desc = Failed to serialize response!
  07:52:57.007 [emailservice] A request to send order confirmation email to aprilrodriguez@example.org has been received.
  07:53:01.767 [checkoutservice] failed to send order confirmation to "gilbertsamantha@example.org": rpc error: code = Internal desc = Failed to serialize response!

## p0604
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T20:04:24.122Z
```
{"timestamp":1733601864122179300,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-f7tv2","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 20:04:24.121  INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl       : [Travel Other Service][Get Route By Id] Success."}
```
Same service, the 2 minutes before (oldest first):
  20:04:21.528 [ts-travel2-service] 2024-12-07 20:04:21.528 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：9fc9c261-3263-4bfa-82f8-bb4  (×10)
  20:04:21.537 [ts-travel2-service] 2024-12-07 20:04:21.537 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×9)
  20:04:24.081 [ts-travel2-service] 2024-12-07 20:04:24.081 INFO 1 --- [io-16346-exec-6] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
All services, 30 seconds either side (sampled):
  20:03:54.178 [ts-travel2-service] 2024-12-07 20:03:54.178 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×109)
  20:03:54.314 [ts-travel2-service] 2024-12-07 20:03:54.313 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6  (×2)
  20:03:58.473 [ts-auth-service] 2024-12-07 20:03:58.473 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×16)
  20:03:58.598 [ts-basic-service] 2024-12-07 20:03:58.598 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×23)
  20:03:58.631 [ts-order-other-service] 2024-12-07 20:03:58.631 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×11)
  20:03:58.733 [ts-travel-service] 2024-12-07 20:03:58.733 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×88)
  20:03:58.858 [ts-seat-service] 2024-12-07 20:03:58.858 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×20)
  20:03:58.943 [ts-order-service] 2024-12-07 20:03:58.943 INFO 1 --- [io-12031-exec-2] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×21)
  20:03:59.416 [ts-travel-service] 2024-12-07 20:03:59.416 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：aefcef3f-3f42-46e8-afd7-6cb2a  (×3)
  20:03:59.513 [ts-basic-service] 2024-12-07 20:03:59.513 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×6)
  20:03:59.800 [ts-seat-service] 2024-12-07 20:03:59.800 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×2)
  20:04:00.025 [ts-food-map-service] 2024-12-07 20:04:00.025 INFO 1 --- [io-18855-exec-8] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×6)
  20:04:00.142 [ts-security-service] 2024-12-07 20:04:00.142 INFO 1 --- [io-11188-exec-9] security.service.SecurityServiceImpl : [Security Service][Get Order Num Info]  (×3)
  20:04:00.191 [ts-preserve-service] 2024-12-07 20:04:00.191 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Contacts Id: d14da0ec-da93-46c3-842d-23f  (×2)
  20:04:00.867 [ts-preserve-service] 2024-12-07 20:04:00.867 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : TripResponse:TripResponse(tripId=D1345, startingStation=Shang Hai, t  (×2)
  20:04:01.168 [ts-seat-service] 2024-12-07 20:04:01.168 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService distributeSeat 1] The result of getTrainTypeResult is Response(  (×3)
  20:04:01.198 [ts-preserve-service] 2024-12-07 20:04:01.198 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service][Add Assurance For Order]  (×2)
  20:04:01.277 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:04:01 +0800] "POST /api/v1/preserveservice/preserve HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWeb  (×2)
  20:04:09.656 [ts-basic-service] 2024-12-07 20:04:09.656 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×2)
  20:04:15.389 [ts-basic-service] 2024-12-07 20:04:15.384 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×9)
  20:04:25.220 [ts-price-service] 2024-12-07 20:04:25.220 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: 0b23bd3e-876a-4af3-b92  (×2)
  20:04:26.826 [ts-consign-service] 2024-12-07 20:04:26.825 INFO 1 --- [io-16111-exec-3] consign.service.ConsignServiceImpl : The target date is 2024-12-07 20:04:26
  20:04:30.254 [ts-auth-service] 2024-12-07 20:04:30.254 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  20:04:31.538 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-07T20:04:31.538+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360187
  20:04:42.397 [ts-travel2-service] 2024-12-07 20:04:42.397 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  20:04:44.395 [ts-contacts-service] 2024-12-07 20:04:44.395 INFO 1 --- [o-12347-exec-10] contacts.controller.ContactsController : [Contacts Service][Find Contacts By Account Id: 4d2a46c7-71cb-4cf1
  20:04:44.502 [ts-preserve-other-service] 2024-12-07 20:04:44.501 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Step 2] Complete
  20:04:45.031 [ts-preserve-other-service] 2024-12-07 20:04:45.031 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order] Order Travel Date: Sat Dec 07 00:00:00
  20:04:45.122 [ts-preserve-other-service] 2024-12-07 20:04:45.122 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order Complete

## p0101
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:05:53.978Z
```
{"timestamp":1731906353978362600,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  05:05:53.486 [frontend] request complete  (×6)
  05:05:53.488 [frontend] request started  (×6)
  05:05:53.488 [frontend] view user cart
  05:05:53.617 [frontend] serving product page
  05:05:53.833 [frontend] setting currency  (×2)
  05:05:53.836 [frontend] home  (×2)
  05:05:53.886 [frontend] ENV_PLATFORM is: aws  (×2)
All services, 30 seconds either side (sampled):
  05:05:28.413 [frontend] request started  (×279)
  05:05:28.422 [cartservice] GetCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×228)
  05:05:28.449 [adservice] received ad request (context_words=[accessories])  (×18)
  05:05:28.458 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=1YMWWN1N4O, quantity=7  (×28)
  05:05:28.497 [shippingservice] [GetQuote] completed request  (×63)
  05:05:28.996 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="USD"  (×7)
  05:05:29.017 [checkoutservice] payment went through (transaction_id: e43c7587-0e24-4a72-8d85-16a465855b2a)  (×10)
  05:05:29.021 [cartservice] EmptyCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×10)
  05:05:29.030 [frontend] order placed  (×10)
  05:05:31.741 [adservice] received ad request (context_words=[decor, home])  (×11)
  05:05:32.748 [frontend] ENV_PLATFORM is: aws  (×40)
  05:05:33.869 [adservice] received ad request (context_words=[footwear])  (×19)
  05:05:33.972 [paymentservice] Transaction processed: visa ending 2652 Amount: CAD426.701933656
  05:05:38.673 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×4)
  05:05:46.056 [emailservice] A request to send order confirmation email to fcontreras@example.com has been received.
  05:05:51.642 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13  (×2)
  05:05:51.663 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  05:05:52.043 [redis] 1:M 18 Nov 2024 05:05:52.043 * Background saving started by pid 47
  05:05:52.145 [redis] 1:M 18 Nov 2024 05:05:52.144 * Background saving terminated with success
  05:05:52.522 [paymentservice] Transaction processed: visa ending 2457 Amount: EUR565.165855819
  05:06:04.238 [emailservice] A request to send order confirmation email to michaelacosta@example.net has been received.
  05:06:07.915 [checkoutservice] order confirmation email sent to "cwilson@example.com"
  05:06:12.430 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="JPY"
  05:06:12.471 [emailservice] A request to send order confirmation email to leenathaniel@example.org has been received.
  05:06:22.120 [checkoutservice] order confirmation email sent to "langreginald@example.org"

## p0540
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T18:17:26.358Z
```
{"timestamp":1733595446358104000,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-kwkx6","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:17:26.357  INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl       : [Travel Other Service][Get Route By Id] Success."}
```
Same service, the 2 minutes before (oldest first):
  18:17:25.770 [ts-travel2-service] 2024-12-07 18:17:25.770 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×2)
  18:17:25.774 [ts-travel2-service] 2024-12-07 18:17:25.774 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.
  18:17:25.925 [ts-travel2-service] 2024-12-07 18:17:25.925 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  18:17:25.940 [ts-travel2-service] 2024-12-07 18:17:25.940 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  18:17:26.088 [ts-travel2-service] 2024-12-07 18:17:26.088 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  18:17:26.104 [ts-travel2-service] 2024-12-07 18:17:26.104 INFO 1 --- [io-16346-exec-4] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×2)
  18:17:26.106 [ts-travel2-service] 2024-12-07 18:17:26.106 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×2)
  18:17:26.113 [ts-travel2-service] 2024-12-07 18:17:26.113 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×2)
  18:17:26.114 [ts-travel2-service] 2024-12-07 18:17:26.113 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  18:17:26.162 [ts-travel2-service] 2024-12-07 18:17:26.162 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  18:17:26.337 [ts-travel2-service] 2024-12-07 18:17:26.337 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6
  18:17:26.347 [ts-travel2-service] 2024-12-07 18:17:26.347 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×2)
All services, 30 seconds either side (sampled):
  18:16:56.386 [ts-travel2-service] 2024-12-07 18:16:56.386 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×22)
  18:17:01.366 [ts-auth-service] 2024-12-07 18:17:01.365 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×21)
  18:17:01.492 [ts-basic-service] 2024-12-07 18:17:01.492 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×7)
  18:17:01.527 [ts-travel2-service] 2024-12-07 18:17:01.526 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×3)
  18:17:01.724 [ts-seat-service] 2024-12-07 18:17:01.723 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×27)
  18:17:01.915 [ts-travel2-service] 2024-12-07 18:17:01.914 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6  (×3)
  18:17:02.102 [ts-travel-service] 2024-12-07 18:17:02.101 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×18)
  18:17:04.258 [ts-travel2-service] 2024-12-07 18:17:04.258 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×22)
  18:17:08.183 [ts-order-other-service] 2024-12-07 18:17:08.183 INFO 1 --- [io-12032-exec-1] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×13)
  18:17:08.654 [ts-order-service] 2024-12-07 18:17:08.653 INFO 1 --- [io-12031-exec-2] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×9)
  18:17:08.870 [ts-travel-service] 2024-12-07 18:17:08.870 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×20)
  18:17:09.436 [ts-travel-service] 2024-12-07 18:17:09.436 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan  (×2)
  18:17:10.046 [ts-order-service] 2024-12-07 18:17:10.045 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×2)
  18:17:12.573 [ts-inside-payment-service] 2024-12-07 18:17:12.573 INFO 1 --- [o-18673-exec-10] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.
  18:17:24.377 [ts-travel-service] 2024-12-07 18:17:24.377 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=nanjing)  (×7)
  18:17:24.480 [ts-basic-service] 2024-12-07 18:17:24.480 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : route.getDistances().size : 5  (×4)
  18:17:27.353 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-07T18:17:27.353+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359544
  18:17:29.763 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:17:29.763+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359544
  18:17:30.927 [ts-basic-service] 2024-12-07 18:17:30.927 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69
  18:17:31.478 [ts-auth-service] 2024-12-07 18:17:31.478 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×2)
  18:17:37.585 [ts-travel-service] 2024-12-07 18:17:37.585 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×2)
  18:17:39.495 [ts-preserve-other-service] 2024-12-07 18:17:39.495 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security
  18:17:39.931 [ts-security-service] 2024-12-07 18:17:39.931 INFO 1 --- [io-11188-exec-2] security.service.SecurityServiceImpl : [Security Service][Get Security Config Info]
  18:17:40.078 [ts-preserve-other-service] 2024-12-07 18:17:40.077 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Check tickets num
  18:17:41.214 [ts-preserve-other-service] 2024-12-07 18:17:41.214 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order] Order Travel Date: Sat Dec 07 00:00:00
  18:17:41.496 [ts-order-other-service] 2024-12-07 18:17:41.495 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Verify Login] Success
  18:17:41.704 [ts-food-service] 2024-12-07 18:17:41.703 INFO 1 --- [io-18856-exec-2] foodsearch.service.FoodServiceImpl : [Food-Service][AddFoodOrder] Success.
  18:17:42.129 [ts-train-mongo] {"t":{"$date":"2024-12-07T18:17:42.129+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359546

## p0496
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:11:27.295Z
```
{"timestamp":1732353087295734500,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:11:27.295672182Z caller=middlewares.go:75 method=GetUsers id=67419c26a437380001df09de result=1 took=2.178252ms"}
```
Same service, the 2 minutes before (oldest first):
  09:11:24.184 [user] ts=2024-11-23T09:11:24.18447981Z caller=middlewares.go:46 method=Register username=ClSgJsj email=ClSgJsj@gmail.com took=2.071069ms
  09:11:25.399 [user] ts=2024-11-23T09:11:25.399341963Z caller=middlewares.go:46 method=Register username=NgoFsrlxTCHsua email=NgoFsrlxTCHsua@gmail.com took=3.298461ms  (×2)
  09:11:25.479 [user] ts=2024-11-23T09:11:25.478948937Z caller=middlewares.go:46 method=Register username=BsGODrB email=BsGODrB@gmail.com took=2.188923ms
  09:11:25.555 [user] ts=2024-11-23T09:11:25.554975341Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419c38a437380001df0a11 took=4.180309ms  (×3)
  09:11:25.612 [user] ts=2024-11-23T09:11:25.612480336Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419c38a437380001df0a11 took=3.777953ms  (×3)
  09:11:25.848 [user] ts=2024-11-23T09:11:25.848372308Z caller=middlewares.go:157 method=Health result=2 took=1.97177ms  (×2)
  09:11:26.169 [user] ts=2024-11-23T09:11:26.169719898Z caller=middlewares.go:46 method=Register username=XmZvdQ email=XmZvdQ@gmail.com took=3.244499ms
  09:11:26.847 [user] ts=2024-11-23T09:11:26.847703405Z caller=middlewares.go:75 method=GetUsers id=67419c2fa437380001df09fc result=1 took=2.711266ms  (×7)
All services, 30 seconds either side (sampled):
  09:10:57.322 [front-end] Request received with body: {}  (×66)
  09:10:57.384 [catalogue] ts=2024-11-23T09:10:57Z caller=logging.go:85 method=Health result=2 took=25.297µs  (×40)
  09:10:57.443 [front-end] Order response: {"cause":{"cause":{"cause":null,"message":"Conflicting setter definitions for property \"items\": works.weave.socks.orders.entities.CustomerOrde  (×66)
  09:10:57.559 [front-end] POST /cards 200 - ms - -  (×61)
  09:10:57.668 [carts] 2024-11-23 09:10:57.668 INFO [carts,dffd384fc58e8ded,4c13d3102122ee8c,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.ItemsController : Did not find item.  (×37)
  09:11:00.730 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×6)
  09:11:01.747 [front-end] { id: '67419c25a437380001df09dd' }  (×60)
  09:11:02.050 [front-end] Received response: "{\"firstName\":\"dUBjPbhnBmbJj\",\"lastName\":\"dUBjPbhnBmbJj\",\"username\":\"dUBjPbhnBmbJj\",\"id\":\"67419c0ca437380001df0989\",\"_links\
  09:11:02.380 [front-end] Received response: "{\"firstName\":\"lDqcFuILkDUID\",\"lastName\":\"lDqcFuILkDUID\",\"username\":\"lDqcFuILkDUID\",\"id\":\"67419c13a437380001df099f\",\"_links\
  09:11:04.717 [front-end] Posting Customer: {"username":"oRrNigKgvxGvvj","password":"eGuvYjCl","email":"oRrNigKgvxGvvj@gmail.com","firstName":"oRrNigKgvxGvvj","lastName":"oRrNigKgvxGvvj"
  09:11:08.850 [front-end] Posting Customer: {"username":"ueWVNHl","password":"ImuKVfxucD","email":"ueWVNHl@gmail.com","firstName":"ueWVNHl","lastName":"ueWVNHl"}
  09:11:10.716 [front-end] Received response: "{\"firstName\":\"DtafjpcrYwz\",\"lastName\":\"DtafjpcrYwz\",\"username\":\"DtafjpcrYwz\",\"id\":\"67419c19a437380001df09ba\",\"_links\":{\"a
  09:11:13.438 [user] ts=2024-11-23T09:11:13.437922216Z caller=middlewares.go:46 method=Register username=RhtDugB email=RhtDugB@gmail.com took=2.907273ms
  09:11:17.543 [front-end] Posting Customer: {"username":"ChywMOlVcmclv","password":"DdtJqY","email":"ChywMOlVcmclv@gmail.com","firstName":"ChywMOlVcmclv","lastName":"ChywMOlVcmclv"}
  09:11:18.627 [front-end] Posting Customer: {"username":"VmwhtNKUFOvdtJJ","password":"hqESV","email":"VmwhtNKUFOvdtJJ@gmail.com","firstName":"VmwhtNKUFOvdtJJ","lastName":"VmwhtNKUFOvdtJJ
  09:11:21.220 [front-end] Posting Customer: {"username":"JVtYXBYH","password":"GldKbwho","email":"JVtYXBYH@gmail.com","firstName":"JVtYXBYH","lastName":"JVtYXBYH"}
  09:11:24.768 [orders-db] {"t":{"$date":"2024-11-23T09:11:24.767+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235308
  09:11:26.962 [front-end] Received response: "{\"firstName\":\"MPQrOASbvZdCuVb\",\"lastName\":\"MPQrOASbvZdCuVb\",\"username\":\"MPQrOASbvZdCuVb\",\"id\":\"67419c2ba437380001df09ec\",\"_
  09:11:29.752 [user] ts=2024-11-23T09:11:29.75282996Z caller=middlewares.go:46 method=Register username=JMbeJLQj email=JMbeJLQj@gmail.com took=1.718776ms
  09:11:32.091 [session-db] 32:C 23 Nov 2024 09:11:32.091 * DB saved on disk
  09:11:33.486 [front-end] Posting Customer: {"username":"CNJmLe","password":"zQxKQlC","email":"CNJmLe@gmail.com","firstName":"CNJmLe","lastName":"CNJmLe"}
  09:11:36.125 [front-end] Received response: "{\"firstName\":\"OAJwm\",\"lastName\":\"OAJwm\",\"username\":\"OAJwm\",\"id\":\"67419c35a437380001df0a08\",\"_links\":{\"addresses\":{\"href
  09:11:39.940 [front-end] Received response: "{\"firstName\":\"iWNfZUlVvs\",\"lastName\":\"iWNfZUlVvs\",\"username\":\"iWNfZUlVvs\",\"id\":\"67419c3aa437380001df0a19\",\"_links\":{\"addr
  09:11:45.257 [user] ts=2024-11-23T09:11:45.256991259Z caller=middlewares.go:46 method=Register username=MRcMjY email=MRcMjY@gmail.com took=1.912169ms
  09:11:46.220 [user] ts=2024-11-23T09:11:46.220696536Z caller=middlewares.go:46 method=Register username=bcQxHV email=bcQxHV@gmail.com took=2.628897ms
  09:11:50.500 [front-end] Posting Customer: {"username":"HjlyVM","password":"pQWlBTVz","email":"HjlyVM@gmail.com","firstName":"HjlyVM","lastName":"HjlyVM"}
  09:11:52.460 [front-end] Posting Customer: {"username":"yJpVOLcSOWvp","password":"SzixjkbVlO","email":"yJpVOLcSOWvp@gmail.com","firstName":"yJpVOLcSOWvp","lastName":"yJpVOLcSOWvp"}
  09:11:56.556 [front-end] Posting Customer: {"username":"gKlWWGvMeKuZ","password":"iTIHPxfQv","email":"gKlWWGvMeKuZ@gmail.com","firstName":"gKlWWGvMeKuZ","lastName":"gKlWWGvMeKuZ"}

## p0800
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-08T08:40:43.502Z
```
{"timestamp":1733647243502609700,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-f2x5m","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-08 08:40:43.502  INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl  : [Basic Information Service][Query For Station Id] Station Id: Shang Hai"}
```
Same service, the 2 minutes before (oldest first):
  08:40:39.587 [ts-basic-service] 2024-12-08 08:40:39.586 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan
  08:40:39.596 [ts-basic-service] 2024-12-08 08:40:39.596 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×5)
  08:40:42.988 [ts-basic-service] 2024-12-08 08:40:42.988 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×3)
  08:40:43.032 [ts-basic-service] 2024-12-08 08:40:43.031 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×2)
  08:40:43.038 [ts-basic-service] 2024-12-08 08:40:43.038 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe
  08:40:43.045 [ts-basic-service] 2024-12-08 08:40:43.044 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69
  08:40:43.052 [ts-basic-service] 2024-12-08 08:40:43.052 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  08:40:43.052 [ts-basic-service] 2024-12-08 08:40:43.052 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4
  08:40:43.062 [ts-basic-service] 2024-12-08 08:40:43.062 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  08:40:43.069 [ts-basic-service] 2024-12-08 08:40:43.069 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
  08:40:43.069 [ts-basic-service] 2024-12-08 08:40:43.069 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1
  08:40:43.069 [ts-basic-service] 2024-12-08 08:40:43.069 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : route.getDistances().size : 2
  08:40:43.175 [ts-basic-service] 2024-12-08 08:40:43.175 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su 
All services, 30 seconds either side (sampled):
  08:40:13.503 [ts-order-other-service] 2024-12-08 08:40:13.503 INFO 1 --- [io-12032-exec-1] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×23)
  08:40:13.541 [ts-route-service] 2024-12-08 08:40:13.540 INFO 1 --- [io-11178-exec-4] route.controller.RouteController : Route id: 9fc9c261-3263-4bfa-82f8-bb44e06b2f52  (×113)
  08:40:15.382 [ts-travel2-service] 2024-12-08 08:40:15.382 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×3)
  08:40:15.438 [ts-price-service] 2024-12-08 08:40:15.437 INFO 1 --- [io-16579-exec-7] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×14)
  08:40:15.456 [ts-order-other-service] 2024-12-08 08:40:15.456 INFO 1 --- [io-12032-exec-2] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×11)
  08:40:15.531 [ts-seat-service] 2024-12-08 08:40:15.531 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×22)
  08:40:17.964 [ts-admin-basic-info-service] 2024-12-08 08:40:17.964 INFO 1 --- [io-18767-exec-8] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×6)
  08:40:26.018 [ts-basic-service] 2024-12-08 08:40:26.018 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×3)
  08:40:28.694 [ts-seat-service] 2024-12-08 08:40:28.694 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×2)
  08:40:29.532 [ts-order-service] 2024-12-08 08:40:29.531 ERROR 1 --- [io-12031-exec-7] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  08:40:31.593 [ts-auth-service] 2024-12-08 08:40:31.592 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [org.springframework.beans.fact  (×2)
  08:40:33.665 [ts-travel-service] 2024-12-08 08:40:33.664 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×2)
  08:40:33.725 [ts-order-service] 2024-12-08 08:40:33.725 INFO 1 --- [io-12031-exec-8] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:00:00   (×3)
  08:40:33.841 [ts-travel-service] 2024-12-08 08:40:33.840 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  08:40:35.263 [ts-price-service] 2024-12-08 08:40:35.263 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: 0b23bd3e-876a-4af3-b92
  08:40:39.484 [ts-auth-service] 2024-12-08 08:40:39.483 INFO 1 --- [ost-startStop-1] .s.DelegatingFilterProxyRegistrationBean : Mapping filter: 'springSecurityFilterChain' to: [/*]  (×2)
  08:40:42.512 [ts-admin-basic-info-service] 2024-12-08 08:40:42.511 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×2)
  08:40:43.529 [ts-travel-service] 2024-12-08 08:40:43.529 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  08:40:43.818 [ts-travel-service] 2024-12-08 08:40:43.817 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×2)
  08:40:51.079 [ts-auth-service] 2024-12-08 08:40:51.078 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users],methods=[GET]}" onto public org.springframework.h
  08:40:53.389 [ts-auth-service] 2024-12-08 08:40:53.389 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  08:40:53.393 [ts-auth-service] 2024-12-08 08:40:53.393 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  08:40:56.588 [ts-auth-service] 2024-12-08 08:40:56.587 INFO 1 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 'taskScheduler'
  08:41:02.799 [ts-auth-service] 2024-12-08 08:41:02.799 INFO 1 --- [io-12340-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  08:41:04.917 [ts-travel2-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×5)
  08:41:09.152 [ts-order-mongo] {"t":{"$date":"2024-12-08T08:41:09.152+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364726
  08:41:09.963 [ts-notification-mongo] {"t":{"$date":"2024-12-08T08:41:09.963+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364726
  08:41:11.222 [ts-assurance-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  08:41:13.068 [ts-consign-mongo] {"t":{"$date":"2024-12-08T08:41:13.068+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364727

## p0427
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service catalogue, 2024-11-23T08:05:16.759Z
```
{"timestamp":1732349116759951000,"container_name":"catalogue","pod_name":"catalogue-b98c66547-vcsvp","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T08:05:16Z caller=logging.go:62 method=Get id=a0a4f044-b040-410d-8ead-4de0446aec7e sock=a0a4f044-b040-410d-8ead-4de0446aec7e err=null took=5.039044ms"}
```
Same service, the 2 minutes before (oldest first):
  08:05:16.175 [catalogue] ts=2024-11-23T08:05:16Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=6.318276
All services, 30 seconds either side (sampled):
  08:05:16.044 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418cb4a437380001deebd3"}  (×35)
  08:05:16.175 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×6)
  08:05:16.938 [front-end] [ undefined, undefined ]  (×33)
  08:05:17.298 [front-end] set cookie67418cbda437380001deebef  (×34)
  08:05:17.806 [carts] 2024-11-23 08:05:17.806 INFO [carts,,,] 7 --- [ main] o.apache.catalina.core.StandardService : Starting service Tomcat
  08:05:19.108 [shipping] 2024-11-23 08:05:19.104 INFO [shipping,,,] 7 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  08:05:20.220 [queue-master] 2024-11-23 08:05:20.219 INFO 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<java.lang.Str
  08:05:21.110 [queue-master] 2024-11-23 08:05:21.029 INFO 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionHandler  (×2)
  08:05:23.533 [front-end] Posting Customer: {"username":"jPegiNos","password":"VaqlvxCpGB","email":"jPegiNos@gmail.com","firstName":"jPegiNos","lastName":"jPegiNos"}
  08:05:26.322 [queue-master] 2024-11-23 08:05:26.317 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.embedded.Ann
  08:05:26.603 [queue-master] 2024-11-23 08:05:26.602 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[GET],produces=[application/hal+json |
  08:05:26.610 [queue-master] 2024-11-23 08:05:26.610 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[DELETE],produces=[applicat
  08:05:26.619 [queue-master] 2024-11-23 08:05:26.619 INFO 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[OPTIONS]}" onto public org.springframework.http.
  08:05:27.714 [queue-master] 2024-11-23 08:05:27.714 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/json]}" onto
  08:05:27.912 [carts] 2024-11-23 08:05:27.912 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  08:05:28.832 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×5)
  08:05:30.718 [queue-master] 2024-11-23 08:05:30.718 INFO 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase -2147482648
  08:05:31.631 [carts-db] {"t":{"$date":"2024-11-23T08:05:31.631+00:00"},"s":"W", "c":"COMMAND", "id":5578800, "ctx":"conn1","msg":"Deprecated operation requested. The client driver may 
  08:05:32.625 [queue-master] 2024-11-23 08:05:32.625 INFO 7 --- [enerContainer-1] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-durable, auto-delete, or exclusive Queue (shipping-  (×2)
  08:05:34.299 [queue-master] 2024-11-23 08:05:34.299 INFO 7 --- [ main] w.w.s.q.QueueMasterApplication : Started QueueMasterApplication in 66.192 seconds (JVM running for 70.627)
  08:05:36.422 [user] ts=2024-11-23T08:05:36.42219905Z caller=middlewares.go:46 method=Register username=HppTvuW email=HppTvuW@gmail.com took=2.855564ms
  08:05:38.884 [orders] 2024-11-23 08:05:38.883 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.
  08:05:39.189 [orders] 2024-11-23 08:05:39.189 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/hal
  08:05:39.195 [orders] 2024-11-23 08:05:39.195 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces
  08:05:39.286 [orders] 2024-11-23 08:05:39.285 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http
  08:05:41.189 [orders] 2024-11-23 08:05:41.189 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application
  08:05:41.194 [orders] 2024-11-23 08:05:41.193 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public ja
  08:05:43.561 [front-end] Posting Customer: {"username":"lRmvkfemO","password":"TCyWuru","email":"lRmvkfemO@gmail.com","firstName":"lRmvkfemO","lastName":"lRmvkfemO"}
  08:05:44.792 [orders] 2024-11-23 08:05:44.791 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server a  (×2)
  08:05:46.592 [orders] 2024-11-23 08:05:46.592 INFO [orders,,,] 8 --- [ main] w.weave.socks.orders.OrderApplication : Started OrderApplication in 80.202 seconds (JVM running for 83.09

## p0406
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:51:55.234Z
```
{"timestamp":1732247515234961000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST to carts: http://carts/carts/673fffd1b0df5c00019b3556/items body: {\"itemId\":\"d3588630-ad8e-49df-bbd7-3167f7efb246\",\"unitPrice\":10.99}"}
```
Same service, the 2 minutes before (oldest first):
  03:51:54.541 [front-end] POST to carts: http://carts/carts/673fffd3b0df5c00019b3561/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}
  03:51:54.584 [front-end] POST /cart 201 - ms - -
  03:51:54.690 [front-end] Posting Customer: {"username":"pbxJb","password":"sECyNh","email":"pbxJb@gmail.com","firstName":"pbxJb","lastName":"pbxJb"}
  03:51:54.697 [front-end] { id: '673fffdab0df5c00019b357a' }
  03:51:54.697 [front-end] 673fffdab0df5c00019b357a
  03:51:54.697 [front-end] Merging carts for customer id: 673fffdab0df5c00019b357a and session id: 2HyOafr7wMs7gJBLSK8DZq-7PaDKiLQB
  03:51:54.720 [front-end] Carts merged.
  03:51:54.720 [front-end] set cookie673fffdab0df5c00019b357a
  03:51:54.720 [front-end] Sent cookies.
  03:51:54.722 [front-end] POST /register 200 30.209 ms - 33
  03:51:55.132 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fffd1b0df5c00019b3556"}  (×2)
  03:51:55.141 [front-end] POST /addresses 200 - ms - -
  03:51:55.146 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fffd1b0df5c00019b3556"}
  03:51:55.155 [front-end] POST /cards 200 - ms - -
  03:51:55.200 [front-end] Attempting to delete cart for user: 673fffd1b0df5c00019b3556
  03:51:55.217 [front-end] User cart deleted with status: 202
  03:51:55.220 [front-end] DELETE /cart 202 - ms - -
  03:51:55.227 [front-end] Attempting to add to cart: {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","quantity":1}
  03:51:55.234 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata
All services, 30 seconds either side (sampled):
  03:51:25.328 [catalogue] ts=2024-11-22T03:51:25Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.515758ms  (×61)
  03:51:25.925 [front-end] Posting Order: {"customer":"http://user/customers/673fffa5b0df5c00019b34e4","address":"http://user/addresses/673fffafb0df5c00019b3503","card":"http://user/cards  (×55)
  03:51:25.952 [queue-master] 2024-11-22 03:51:25.952 ERROR 6 --- [ool-6-thread-27] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×39)
  03:51:26.001 [front-end] set cookie673fffbdb0df5c00019b351f  (×60)
  03:51:26.871 [front-end] Received response: "{\"firstName\":\"NgOOipukSXwHYWa\",\"lastName\":\"NgOOipukSXwHYWa\",\"username\":\"NgOOipukSXwHYWa\",\"id\":\"673fffabb0df5c00019b34f3\",\"_
  03:51:29.150 [front-end] POST /addresses 200 - ms - -  (×59)
  03:51:29.270 [carts] 2024-11-22 03:51:29.270 INFO [carts,19b570490cc371ad,538b7e6c8c55399c,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.ItemsController : Did not find item.  (×44)
  03:51:30.818 [user] ts=2024-11-22T03:51:30.818296119Z caller=middlewares.go:46 method=Register username=rMZGBqiV email=rMZGBqiV@gmail.com took=1.039215ms
  03:51:31.663 [front-end] Posting Customer: {"username":"Jngmwl","password":"tRChum","email":"Jngmwl@gmail.com","firstName":"Jngmwl","lastName":"Jngmwl"}
  03:51:34.722 [front-end] Received response: "{\"firstName\":\"teJbhdRMAGkdPgQ\",\"lastName\":\"teJbhdRMAGkdPgQ\",\"username\":\"teJbhdRMAGkdPgQ\",\"id\":\"673fffb3b0df5c00019b350d\",\"_
  03:51:38.252 [front-end] Posting Customer: {"username":"LmtiO","password":"KXGeiDQy","email":"LmtiO@gmail.com","firstName":"LmtiO","lastName":"LmtiO"}
  03:51:41.075 [user] ts=2024-11-22T03:51:41.074830734Z caller=middlewares.go:46 method=Register username=raeyPw email=raeyPw@gmail.com took=1.106021ms
  03:51:43.224 [front-end] Received response: "{\"firstName\":\"snWvbH\",\"lastName\":\"snWvbH\",\"username\":\"snWvbH\",\"id\":\"673fffbdb0df5c00019b351f\",\"_links\":{\"addresses\":{\"h
  03:51:44.516 [front-end] Received response: "{\"firstName\":\"tbSKTtpX\",\"lastName\":\"tbSKTtpX\",\"username\":\"tbSKTtpX\",\"id\":\"673fffbbb0df5c00019b351e\",\"_links\":{\"addresses\
  03:51:47.077 [front-end] Posting Customer: {"username":"AlnIBOhtxUsiETy","password":"vthNK","email":"AlnIBOhtxUsiETy@gmail.com","firstName":"AlnIBOhtxUsiETy","lastName":"AlnIBOhtxUsiETy
  03:51:48.830 [front-end] Order response: {"id":"673fffd4d94b9000069b4900","customerId":"673fffc7b0df5c00019b3534","customer":{"id":null,"firstName":"jMzqwsSaOtry","lastName":"jMzqwsSaOt
  03:51:50.874 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffd6d94b9000069b4903","customerId":"673fffc8b0df5c00019b3538","customer":{"id":null,"firstName":"EMcqmnvR","
  03:51:53.351 [front-end] Order response: {"id":"673fffd9d94b9000069b4905","customerId":"673fffc3b0df5c00019b3527","customer":{"id":null,"firstName":"uiIIWurGxFKR","lastName":"uiIIWurGxF
  03:51:56.479 [front-end] Order response: {"id":"673fffdcd94b9000069b4908","customerId":"673fffc5b0df5c00019b3530","customer":{"id":null,"firstName":"aEiWEHqkzTfPW","lastName":"aEiWEHqkz
  03:52:00.711 [front-end] Posting Customer: {"username":"swbUzaAeiKD","password":"wNXUvLTMXr","email":"swbUzaAeiKD@gmail.com","firstName":"swbUzaAeiKD","lastName":"swbUzaAeiKD"}
  03:52:03.074 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffe3d94b9000069b490b","customerId":"673fffc9b0df5c00019b3539","customer":{"id":null,"firstName":"CHTEOZMWpi"
  03:52:05.362 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffe5d94b9000069b490e","customerId":"673fffd0b0df5c00019b3555","customer":{"id":null,"firstName":"pWtzE","las
  03:52:06.641 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffe6d94b9000069b4911","customerId":"673fffd3b0df5c00019b3561","customer":{"id":null,"firstName":"uoyWgBozCjH
  03:52:08.433 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffe8d94b9000069b4914","customerId":"673fffd1b0df5c00019b3557","customer":{"id":null,"firstName":"fsicNLo","l
  03:52:10.469 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffead94b9000069b4916","customerId":"673fffd3b0df5c00019b3560","customer":{"id":null,"firstName":"qCSpJwqlONF
  03:52:11.686 [front-end] Received response: "{\"firstName\":\"ZnlQTMe\",\"lastName\":\"ZnlQTMe\",\"username\":\"ZnlQTMe\",\"id\":\"673fffd8b0df5c00019b3573\",\"_links\":{\"addresses\":{
  03:52:16.097 [front-end] Posting Customer: {"username":"npdKI","password":"LqBfgQx","email":"npdKI@gmail.com","firstName":"npdKI","lastName":"npdKI"}
  03:52:18.602 [front-end] Posting Customer: {"username":"mxAxwc","password":"Vzyzp","email":"mxAxwc@gmail.com","firstName":"mxAxwc","lastName":"mxAxwc"}
  03:52:19.308 [user] ts=2024-11-22T03:52:19.307958096Z caller=middlewares.go:46 method=Register username=GHAfufHk email=GHAfufHk@gmail.com took=1.030792ms
  03:52:23.964 [front-end] Received response: "{\"firstName\":\"swbUzaAeiKD\",\"lastName\":\"swbUzaAeiKD\",\"username\":\"swbUzaAeiKD\",\"id\":\"673fffe0b0df5c00019b3591\",\"_links\":{\"a

## p0443
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T08:06:05.306Z
```
{"timestamp":1732349165306098700,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:05.305  INFO [carts,,,] 7 --- [           main] o.s.w.s.handler.SimpleUrlHandlerMapping  : Mapped URL path [/**] onto handler of type [class org.springframework.web.servlet.resource.ResourceHttpRequestHandler]"}
```
Same service, the 2 minutes before (oldest first):
  08:05:27.911 [carts] 2024-11-23 08:05:27.911 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'metricsServlet' to [/metrics]
  08:05:27.912 [carts] 2024-11-23 08:05:27.912 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  08:05:30.210 [carts] 2024-11-23 08:05:30.209 INFO [carts,,,] 7 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[carts-db:27017], mode=SINGLE, requiredC
  08:05:31.799 [carts] 2024-11-23 08:05:31.799 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:1}] to
  08:05:31.806 [carts] 2024-11-23 08:05:31.806 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  08:05:45.411 [carts] 2024-11-23 08:05:45.411 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  08:06:00.413 [carts] 2024-11-23 08:06:00.413 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  08:06:00.500 [carts] 2024-11-23 08:06:00.500 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[DE
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[GET],produces=
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}/merge],methods=[GET]}" onto publi
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[GET],produces=[applicat
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.spring
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  08:06:03.410 [carts] 2024-11-23 08:06:03.409 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  08:06:03.602 [carts] 2024-11-23 08:06:03.600 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.ac
  08:06:05.306 [carts] 2024-11-23 08:06:05.304 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.sp
All services, 30 seconds either side (sampled):
  08:05:35.373 [front-end] Request received with body: {}  (×63)
  08:05:35.510 [front-end] set cookie67418ccfa437380001deec29  (×66)
  08:05:35.883 [front-end] Received response: "{\"firstName\":\"yxWEkBiarOEcFPl\",\"lastName\":\"yxWEkBiarOEcFPl\",\"username\":\"yxWEkBiarOEcFPl\",\"id\":\"67418cb6a437380001deebd8\",\"_
  08:05:37.554 [front-end] Posting Customer: {"username":"QTNxlk","password":"qwbekCU","email":"QTNxlk@gmail.com","firstName":"QTNxlk","lastName":"QTNxlk"}
  08:05:39.188 [orders] 2024-11-23 08:05:39.188 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[OPTIONS],produces=[application
  08:05:39.196 [orders] 2024-11-23 08:05:39.196 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[OPTIONS],produces=[appl
  08:05:40.562 [front-end] Posting Customer: {"username":"eqACgmjO","password":"JpDGtXlzCs","email":"eqACgmjO@gmail.com","firstName":"eqACgmjO","lastName":"eqACgmjO"}
  08:05:41.194 [orders] 2024-11-23 08:05:41.193 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public ja
  08:05:44.588 [orders] 2024-11-23 08:05:44.587 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:05:46.357 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×8)
  08:05:49.486 [orders] 2024-11-23 08:05:49.394 ERROR [orders,,,] 8 --- [p-nio-80-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×39)
  08:05:51.461 [front-end] Posting Customer: {"username":"JfkloKMY","password":"BAlPTCaswY","email":"JfkloKMY@gmail.com","firstName":"JfkloKMY","lastName":"JfkloKMY"}
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/jso
  08:05:56.815 [front-end] Received response: "{\"firstName\":\"WoyOvB\",\"lastName\":\"WoyOvB\",\"username\":\"WoyOvB\",\"id\":\"67418ccfa437380001deec29\",\"_links\":{\"addresses\":{\"h
  08:05:59.718 [user] ts=2024-11-23T08:05:59.718194949Z caller=middlewares.go:46 method=Register username=RKNDdSk email=RKNDdSk@gmail.com took=3.379621ms
  08:06:02.425 [front-end] Posting Customer: {"username":"vZvbgNwwdo","password":"cAEgTMr","email":"vZvbgNwwdo@gmail.com","firstName":"vZvbgNwwdo","lastName":"vZvbgNwwdo"}
  08:06:06.916 [carts] 2024-11-23 08:06:06.915 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class or
  08:06:07.007 [shipping] 2024-11-23 08:06:07.007 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT
  08:06:07.614 [user] ts=2024-11-23T08:06:07.614423361Z caller=middlewares.go:46 method=Register username=ucodWkVEg email=ucodWkVEg@gmail.com took=3.000643ms
  08:06:13.834 [front-end] Received response: "{\"firstName\":\"bzxtLtBzUaRfo\",\"lastName\":\"bzxtLtBzUaRfo\",\"username\":\"bzxtLtBzUaRfo\",\"id\":\"67418ce5a437380001deec6f\",\"_links\
  08:06:15.701 [carts] 2024-11-23 08:06:15.701 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[application/hal+json || 
  08:06:15.809 [carts] 2024-11-23 08:06:15.809 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applicat
  08:06:16.439 [user] ts=2024-11-23T08:06:16.439397099Z caller=middlewares.go:46 method=Register username=GXUtAA email=GXUtAA@gmail.com took=2.399304ms
  08:06:19.009 [carts] 2024-11-23 08:06:19.009 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  08:06:21.669 [front-end] Posting Customer: {"username":"suxeYRw","password":"WiFMBG","email":"suxeYRw@gmail.com","firstName":"suxeYRw","lastName":"suxeYRw"}
  08:06:24.503 [carts] 2024-11-23 08:06:24.503 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as MB
  08:06:27.104 [carts] 2024-11-23 08:06:27.103 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:06:30.456 [front-end] Received response: "{\"firstName\":\"SPVlWNNsjeesK\",\"lastName\":\"SPVlWNNsjeesK\",\"username\":\"SPVlWNNsjeesK\",\"id\":\"67418cf2a437380001deec94\",\"_links\
  08:06:32.729 [orders] 2024-11-23 08:06:32.728 INFO [orders,fbcebf8ef5e82428,6d050ec4f8a03a61,false] 8 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Sending payment req  (×4)
  08:06:34.501 [shipping] Adding shipment to queue...  (×5)

## p0495
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:11:17.893Z
```
{"timestamp":1732353077893667600,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:11:17.893592797Z caller=middlewares.go:75 method=GetUsers id=67419c19a437380001df09bb result=1 took=1.856282ms"}
```
Same service, the 2 minutes before (oldest first):
  09:11:15.485 [user] ts=2024-11-23T09:11:15.485565587Z caller=middlewares.go:46 method=Register username=RiejTq email=RiejTq@gmail.com took=2.273975ms
  09:11:15.485 [user] ts=2024-11-23T09:11:15.485593521Z caller=middlewares.go:75 method=GetUsers id=67419c21a437380001df09d2 result=1 took=2.317717ms  (×10)
  09:11:16.763 [user] ts=2024-11-23T09:11:16.763222312Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419c2ba437380001df09ed took=4.518068ms  (×2)
  09:11:16.778 [user] ts=2024-11-23T09:11:16.778366409Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419c2ba437380001df09ed took=3.09568ms  (×2)
  09:11:16.849 [user] ts=2024-11-23T09:11:16.848958492Z caller=middlewares.go:157 method=Health result=2 took=1.716182ms  (×2)
  09:11:17.551 [user] ts=2024-11-23T09:11:17.550934293Z caller=middlewares.go:46 method=Register username=ChywMOlVcmclv email=ChywMOlVcmclv@gmail.com took=2.33096ms
  09:11:17.567 [user] ts=2024-11-23T09:11:17.567601457Z caller=middlewares.go:46 method=Register username=KnDvyMhUL email=KnDvyMhUL@gmail.com took=1.875129ms
  09:11:17.867 [user] ts=2024-11-23T09:11:17.867087963Z caller=middlewares.go:46 method=Register username=OAJwm email=OAJwm@gmail.com took=2.254256ms
All services, 30 seconds either side (sampled):
  09:10:48.131 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67419c12a437380001df099c"}  (×61)
  09:10:48.229 [front-end] DELETE /cart 202 - ms - -  (×61)
  09:10:48.384 [catalogue] ts=2024-11-23T09:10:48Z caller=logging.go:85 method=Health result=2 took=24.499µs  (×40)
  09:10:48.430 [user] ts=2024-11-23T09:10:48.429760958Z caller=middlewares.go:75 method=GetUsers id=67419c02a437380001df096c result=1 took=2.033264ms  (×197)
  09:10:48.447 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67419  (×66)
  09:10:48.461 [front-end] Order response: {"cause":{"cause":{"cause":null,"message":"Conflicting setter definitions for property \"items\": works.weave.socks.orders.entities.CustomerOrde  (×66)
  09:10:49.259 [front-end] Posting Customer: {"username":"GSOQJLbPb","password":"tfEMUV","email":"GSOQJLbPb@gmail.com","firstName":"GSOQJLbPb","lastName":"GSOQJLbPb"}
  09:10:50.151 [front-end] POST to carts: http://carts/carts/67419c11a437380001df099b/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}  (×29)
  09:10:54.295 [front-end] Posting Customer: {"username":"faGZSB","password":"jtHKmPe","email":"faGZSB@gmail.com","firstName":"faGZSB","lastName":"faGZSB"}
  09:10:56.230 [front-end] Posting Customer: {"username":"rebXy","password":"VyJMCk","email":"rebXy@gmail.com","firstName":"rebXy","lastName":"rebXy"}
  09:10:57.247 [front-end] Posting Customer: {"username":"ZtITZPSAjyw","password":"BydYgdg","email":"ZtITZPSAjyw@gmail.com","firstName":"ZtITZPSAjyw","lastName":"ZtITZPSAjyw"}
  09:11:01.745 [user] ts=2024-11-23T09:11:01.745267473Z caller=middlewares.go:46 method=Register username=xLzIv email=xLzIv@gmail.com took=2.837988ms
  09:11:03.163 [front-end] Received response: "{\"firstName\":\"JYeGFIZGQfU\",\"lastName\":\"JYeGFIZGQfU\",\"username\":\"JYeGFIZGQfU\",\"id\":\"67419c0fa437380001df0992\",\"_links\":{\"a
  09:11:05.310 [front-end] Received response: "{\"firstName\":\"yoLmMqejhSZCZ\",\"lastName\":\"yoLmMqejhSZCZ\",\"username\":\"yoLmMqejhSZCZ\",\"id\":\"67419c12a437380001df099c\",\"_links\
  09:11:09.218 [front-end] Received response: "{\"firstName\":\"JuJgbb\",\"lastName\":\"JuJgbb\",\"username\":\"JuJgbb\",\"id\":\"67419c11a437380001df099b\",\"_links\":{\"addresses\":{\"h
  09:11:11.794 [front-end] Received response: "{\"firstName\":\"azYlZxwirpCRy\",\"lastName\":\"azYlZxwirpCRy\",\"username\":\"azYlZxwirpCRy\",\"id\":\"67419c1aa437380001df09be\",\"_links\
  09:11:15.485 [user] ts=2024-11-23T09:11:15.485565587Z caller=middlewares.go:46 method=Register username=RiejTq email=RiejTq@gmail.com took=2.273975ms
  09:11:17.867 [user] ts=2024-11-23T09:11:17.867087963Z caller=middlewares.go:46 method=Register username=OAJwm email=OAJwm@gmail.com took=2.254256ms
  09:11:20.504 [front-end] Posting Customer: {"username":"GXtsuwtMC","password":"iBcpBPHO","email":"GXtsuwtMC@gmail.com","firstName":"GXtsuwtMC","lastName":"GXtsuwtMC"}
  09:11:22.673 [front-end] Posting Customer: {"username":"iWNfZUlVvs","password":"itbVqaGh","email":"iWNfZUlVvs@gmail.com","firstName":"iWNfZUlVvs","lastName":"iWNfZUlVvs"}
  09:11:26.162 [front-end] Posting Customer: {"username":"XmZvdQ","password":"FNlmwcFfUV","email":"XmZvdQ@gmail.com","firstName":"XmZvdQ","lastName":"XmZvdQ"}
  09:11:27.641 [user] ts=2024-11-23T09:11:27.641127492Z caller=middlewares.go:46 method=Register username=tbYEfOv email=tbYEfOv@gmail.com took=2.985002ms
  09:11:30.986 [front-end] Received response: "{\"firstName\":\"oRrNigKgvxGvvj\",\"lastName\":\"oRrNigKgvxGvvj\",\"username\":\"oRrNigKgvxGvvj\",\"id\":\"67419c28a437380001df09e8\",\"_lin
  09:11:32.701 [front-end] Posting Customer: {"username":"tsToi","password":"MBbkiKgmcY","email":"tsToi@gmail.com","firstName":"tsToi","lastName":"tsToi"}
  09:11:35.272 [front-end] Posting Customer: {"username":"ESqYs","password":"sLOIT","email":"ESqYs@gmail.com","firstName":"ESqYs","lastName":"ESqYs"}
  09:11:38.883 [front-end] Received response: "{\"firstName\":\"VmwhtNKUFOvdtJJ\",\"lastName\":\"VmwhtNKUFOvdtJJ\",\"username\":\"VmwhtNKUFOvdtJJ\",\"id\":\"67419c36a437380001df0a0c\",\"_
  09:11:42.909 [front-end] Posting Customer: {"username":"UGKypaKxJraOJEY","password":"FSqkbOtbae","email":"UGKypaKxJraOJEY@gmail.com","firstName":"UGKypaKxJraOJEY","lastName":"UGKypaKxJr
  09:11:46.143 [front-end] Posting Customer: {"username":"iCzyVxna","password":"BLecOkjd","email":"iCzyVxna@gmail.com","firstName":"iCzyVxna","lastName":"iCzyVxna"}

## p0031
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T07:52:33.503Z
```
{"service":"logservice1","message":"2021-08-13 07:52:33,503 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | 20428a0ac941019c | request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '5c99ba3e-fbc8-11eb-a732-0242ac110004'}"}
```
Same service, the 2 minutes before (oldest first):
  07:52:31.007 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×3)
  07:52:31.008 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  07:52:31.008 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '5b057bf4-fbc8-11eb-baad-0242ac110003', 'user_id': 'DomOhFAT'}  (×4)
  07:52:31.087 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389
  07:52:31.087 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service
  07:52:31.853 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  07:52:31.853 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  07:52:31.854 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '5ba239e4-fbc8-11eb-a540-0242ac110003'}  (×2)
All services, 30 seconds either side (sampled):
  07:52:03.521 [webservice1] INFO complete information: {'uuid': '4ae4e8ae-fbc8-11eb-ad33-0242ac110003', 'user_id': 'qHGVUSPX'}  (×41)
  07:52:03.688 [mobservice2] INFO info 4ae4e8ae-fbc8-11eb-ad33-0242ac110003:qHGVUSPX write success
  07:52:03.834 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '4ae4e8ae-fbc8-11eb-ad33-0242ac110003', 'user_id': 'qHGVUSPX'}  (×84)
  07:52:04.021 [dbservice1] INFO 4ae4e8ae-fbc8-11eb-ad33-0242ac110003-qHGVUSPX-2X6L_bVf5*I< token generate success token=MTYyODgxMjMyNC4wMjEwODk6NGFlNGU4YWUtZmJjOC0xMWViLWFkMzMtMDI0MmFjMTE
  07:52:04.396 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '4b83fd22-fbc8-11eb-8332-0242ac110004', 'value': '', 'ex': 10}  (×43)
  07:52:04.620 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×48)
  07:52:04.925 [dbservice1] INFO 4b6169f6-fbc8-11eb-8488-0242ac110003-NpSktBQI-ZNc-73/n1Rbm token generate success token=MTYyODgxMjMyNC45MjUyNzI1OjRiNjE2OWY2LWZiYzgtMTFlYi04NDg4LTAyNDJhYzE
  07:52:05.409 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '4bec4fee-fbc8-11eb-8139-0242ac110004', 'value': 'zAFcSJGh'}  (×43)
  07:52:07.580 [mobservice1] INFO info 4d2e9a1a-fbc8-11eb-b7e6-0242ac110004:jhHLeyoN write success
  07:52:10.204 [dbservice1] INFO 4e87a29e-fbc8-11eb-95af-0242ac110003-avTqnNxg-L$C9/.km:^B% token generate success token=MTYyODgxMjMzMC4yMDQ2MDk2OjRlODdhMjllLWZiYzgtMTFlYi05NWFmLTAyNDJhYzE
  07:52:12.917 [dbservice2] ERROR password in database of {user} is null, the user is not registered  (×2)
  07:52:16.027 [mobservice2] INFO info 5237633e-fbc8-11eb-a090-0242ac110004:PVFHnXol write success
  07:52:18.406 [mobservice2] INFO info 53aa57e4-fbc8-11eb-a0ae-0242ac110003:kuaemYbD write success
  07:52:20.910 [mobservice1] INFO info 5525caae-fbc8-11eb-a9f3-0242ac110004:ZlqeuHzO write success
  07:52:23.399 [mobservice1] INFO info 56a37638-fbc8-11eb-aac3-0242ac110003:uiZfvcTY write success
  07:52:25.410 [dbservice1] INFO 578de2c2-fbc8-11eb-9661-0242ac110003-jIBRSGcQ-)ERfPKel{cTt token generate success token=MTYyODgxMjM0NS40MDk5NTM4OjU3OGRlMmMyLWZiYzgtMTFlYi05NjYxLTAyNDJhYzE
  07:52:28.267 [dbservice1] INFO 59546310-fbc8-11eb-a3d9-0242ac110004-iuYCeOZW-p{tZFI_a$DRk token generate success token=MTYyODgxMjM0OC4yNjcwNDcyOjU5NTQ2MzEwLWZiYzgtMTFlYi1hM2Q5LTAyNDJhYzE
  07:52:30.839 [mobservice2] INFO info 5b055552-fbc8-11eb-989e-0242ac110003:FgWeZKzi write success
  07:52:33.680 [mobservice1] INFO info 5cc4501e-fbc8-11eb-b840-0242ac110004:xjYUMcml write success
  07:52:36.344 [dbservice2] INFO 5e21c1ee-fbc8-11eb-b2f6-0242ac110004-JZinoGDa-nw4#7?JZCUe) token generate success token=MTYyODgxMjM1Ni4zNDQwNTg6NWUyMWMxZWUtZmJjOC0xMWViLWIyZjYtMDI0MmFjMTE
  07:52:38.645 [dbservice1] INFO 5f94e790-fbc8-11eb-aa34-0242ac110003-gQaRFlxY-VQO3BbxX>G!4 token generate success token=MTYyODgxMjM1OC42NDQ5OTc2OjVmOTRlNzkwLWZiYzgtMTFlYi1hYTM0LTAyNDJhYzE
  07:52:45.385 [dbservice2] INFO 638be4d4-fbc8-11eb-ba98-0242ac110003-yeMqQbFt-RxWUf5S1}=a4 token generate success token=MTYyODgxMjM2NS4zODUyMDgxOjYzOGJlNGQ0LWZiYzgtMTFlYi1iYTk4LTAyNDJhYzE
  07:52:49.729 [dbservice2] INFO 6627b830-fbc8-11eb-a0d5-0242ac110004-GrKgOByV-n@*{TE_p^JR3 token generate success token=MTYyODgxMjM2OS43MjkzODY4OjY2MjdiODMwLWZiYzgtMTFlYi1hMGQ1LTAyNDJhYzE
  07:52:51.968 [dbservice1] INFO 678253f2-fbc8-11eb-86fc-0242ac110003-ArxCmQcb-p-n+Fy1&AjMv token generate success token=MTYyODgxMjM3MS45NjgzMzgzOjY3ODI1M2YyLWZiYzgtMTFlYi04NmZjLTAyNDJhYzE
  07:52:54.777 [mobservice1] INFO info 695d8480-fbc8-11eb-bd06-0242ac110004:ydgXkaYo write success
  07:52:57.516 [dbservice1] INFO 6ac75cc4-fbc8-11eb-b96e-0242ac110004-yaVPzdET--.P$:@2DE53H token generate success token=MTYyODgxMjM3Ny41MTU3MTMyOjZhYzc1Y2M0LWZiYzgtMTFlYi1iOTZlLTAyNDJhYzE
  07:53:00.105 [dbservice1] INFO 6c4b5028-fbc8-11eb-ba7e-0242ac110003-nlMAOLaH-.+x$_%GPZ*lV token generate success token=MTYyODgxMjM4MC4xMDU2MDA4OjZjNGI1MDI4LWZiYzgtMTFlYi1iYTdlLTAyNDJhYzE
  07:53:03.211 [mobservice2] INFO info 6e5f1548-fbc8-11eb-9db9-0242ac110004:kPDTFpxO write success

## p0360
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:32:58.589Z
```
{"timestamp":1732246378589187300,"container_name":"carts","pod_name":"carts-6cdcbc6cd7-bswq8","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:32:58.588  WARN [carts,,,] 7 --- [           main] o.s.c.a.ConfigurationClassPostProcessor  : Cannot enhance @Configuration bean definition 'refreshScope' since its singleton instance has been created too early. The typical cause is a non-static @Bean method with a BeanDefinitionRegistryPostProcessor return type: Consider declaring such methods as 'static'."}
```
Same service, the 2 minutes before (oldest first):
  03:32:13.305 [carts] 2024-11-22 03:32:13.305 INFO [carts,2d207c97655d7c25,59a4a3cc78fdb5ea,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.controllers.CartsController : Merge carts reques
  03:32:14.823 [carts] 2024-11-22 03:32:14.822 INFO [carts,8886b64395938738,9ed9764a3d0dcda6,false] 7 --- [-nio-80-exec-14] w.w.s.cart.controllers.CartsController : Merge carts reques  (×2)
  03:32:14.876 [carts] 2024-11-22 03:32:14.876 INFO [carts,1332f463061a327c,c8b73cec3e8ab83c,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  03:32:14.883 [carts] 2024-11-22 03:32:14.882 INFO [carts,1332f463061a327c,c8b73cec3e8ab83c,false] 7 --- [-nio-80-exec-16] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
  03:32:14.951 [carts] 2024-11-22 03:32:14.951 INFO [carts,95d16265d13a4858,9354869b6112f5a9,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  03:32:14.957 [carts] 2024-11-22 03:32:14.957 INFO [carts,95d16265d13a4858,9354869b6112f5a9,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
  03:32:27.890 [carts] 2024-11-22 03:32:27.884 INFO [bootstrap,,,] 7 --- [ main] s.c.a.AnnotationConfigApplicationContext : Refreshing org.springframework.context.annotation.Annotatio
  03:32:29.797 [carts] 2024-11-22 03:32:29.796 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Exception in monitor thread while connecting to server carts-db:270
  03:32:29.797 [carts] com.mongodb.MongoSocketOpenException: Exception opening socket at com.mongodb.connection.SocketStream.open(SocketStream.java:63) ~[mongodb-driver-core-3.2.2.jar
  03:32:29.797 [carts] Caused by: java.net.ConnectException: Connection refused (Connection refused) at java.net.PlainSocketImpl.socketConnect(Native Method) ~[na:1.8.0_131] at java.n
  03:32:32.889 [carts] 2024-11-22 03:32:32.888 INFO [bootstrap,,,] 7 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'configurationPropertiesRebinderAutoConfiguration' of 
  03:32:37.188 [carts] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  03:32:37.491 [carts] 2024-11-22 03:32:37.488 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : No active profile set, falling back to default profiles: default
  03:32:37.685 [carts] 2024-11-22 03:32:37.684 INFO [carts,,,] 7 --- [ main] ationConfigEmbeddedWebApplicationContext : Refreshing org.springframework.boot.context.embedded.Annotation
  03:32:55.283 [carts] 2024-11-22 03:32:55.283 INFO [carts,,,] 7 --- [ main] o.s.b.f.s.DefaultListableBeanFactory : Overriding bean definition for bean 'managementServletContext' with
All services, 30 seconds either side (sampled):
  03:32:28.610 [orders-db] {"t":{"$date":"2024-11-22T03:32:28.610+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224634
  03:32:28.665 [catalogue] ts=2024-11-22T03:32:28Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.20752ms  (×62)
  03:32:28.900 [user] ts=2024-11-22T03:32:28.900513726Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffb45b0df5c00019b2766 took=1.577124ms  (×63)
  03:32:29.797 [carts] Caused by: java.net.ConnectException: Connection refused (Connection refused) at java.net.PlainSocketImpl.socketConnect(Native Method) ~[na:1.8.0_131] at java.n
  03:32:29.916 [front-end] Received response: "{\"firstName\":\"ARIDSCyniM\",\"lastName\":\"ARIDSCyniM\",\"username\":\"ARIDSCyniM\",\"id\":\"673ffb34b0df5c00019b272d\",\"_links\":{\"addr
  03:32:29.954 [front-end] Carts merged.  (×64)
  03:32:29.983 [front-end] POST /orders 500 - ms - -  (×68)
  03:32:30.775 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×7)
  03:32:32.508 [front-end] Received response: "{\"firstName\":\"COmsLlalv\",\"lastName\":\"COmsLlalv\",\"username\":\"COmsLlalv\",\"id\":\"673ffb3db0df5c00019b2743\",\"_links\":{\"address
  03:32:33.375 [front-end] Posting Customer: {"username":"GeVdXwZX","password":"aJteqPG","email":"GeVdXwZX@gmail.com","firstName":"GeVdXwZX","lastName":"GeVdXwZX"}
  03:32:36.745 [user] ts=2024-11-22T03:32:36.744945974Z caller=middlewares.go:46 method=Register username=WTovxKCPxNKG email=WTovxKCPxNKG@gmail.com took=855.662µs  (×14)
  03:32:38.105 [front-end] Received response: "{\"firstName\":\"FoXqP\",\"lastName\":\"FoXqP\",\"username\":\"FoXqP\",\"id\":\"673ffb45b0df5c00019b2766\",\"_links\":{\"addresses\":{\"href
  03:32:41.105 [front-end] Received response: "{\"firstName\":\"IqpCHhO\",\"lastName\":\"IqpCHhO\",\"username\":\"IqpCHhO\",\"id\":\"673ffb40b0df5c00019b274e\",\"_links\":{\"addresses\":{
  03:32:44.611 [front-end] Received response: "{\"firstName\":\"bviIQkm\",\"lastName\":\"bviIQkm\",\"username\":\"bviIQkm\",\"id\":\"673ffb44b0df5c00019b275d\",\"_links\":{\"addresses\":{
  03:32:47.092 [front-end] Posting Customer: {"username":"gOZqAceenBYmfnc","password":"OFjZNPcG","email":"gOZqAceenBYmfnc@gmail.com","firstName":"gOZqAceenBYmfnc","lastName":"gOZqAceenBYm
  03:32:50.945 [user] ts=2024-11-22T03:32:50.945058061Z caller=middlewares.go:46 method=Register username=uSjiI email=uSjiI@gmail.com took=1.095737ms
  03:32:53.951 [front-end] Received response: "{\"firstName\":\"nQKDExtexdScJCC\",\"lastName\":\"nQKDExtexdScJCC\",\"username\":\"nQKDExtexdScJCC\",\"id\":\"673ffb4eb0df5c00019b278b\",\"_
  03:32:55.939 [front-end] Posting Customer: {"username":"QLTgoU","password":"MDtuAiSOfP","email":"QLTgoU@gmail.com","firstName":"QLTgoU","lastName":"QLTgoU"}
  03:32:59.951 [front-end] Posting Customer: {"username":"IZQLswcbNlBugg","password":"okTuunyWQ","email":"IZQLswcbNlBugg@gmail.com","firstName":"IZQLswcbNlBugg","lastName":"IZQLswcbNlBugg
  03:33:02.658 [front-end] Posting Customer: {"username":"sOiDDuAX","password":"sFETe","email":"sOiDDuAX@gmail.com","firstName":"sOiDDuAX","lastName":"sOiDDuAX"}
  03:33:06.459 [front-end] Received response: "{\"firstName\":\"DioarsaRSQhfH\",\"lastName\":\"DioarsaRSQhfH\",\"username\":\"DioarsaRSQhfH\",\"id\":\"673ffb62b0df5c00019b27bc\",\"_links\
  03:33:08.645 [user] ts=2024-11-22T03:33:08.645775179Z caller=middlewares.go:46 method=Register username=UTvMVv email=UTvMVv@gmail.com took=2.065559ms
  03:33:09.850 [front-end] Posting Customer: {"username":"BoWPizktVpTxaQo","password":"oPwBGCZwM","email":"BoWPizktVpTxaQo@gmail.com","firstName":"BoWPizktVpTxaQo","lastName":"BoWPizktVpT
  03:33:13.899 [front-end] Received response: "{\"firstName\":\"XpdrCDxWrENA\",\"lastName\":\"XpdrCDxWrENA\",\"username\":\"XpdrCDxWrENA\",\"id\":\"673ffb69b0df5c00019b27d4\",\"_links\":{
  03:33:16.487 [front-end] Posting Customer: {"username":"kjDdiqomYZg","password":"VvlAKWcN","email":"kjDdiqomYZg@gmail.com","firstName":"kjDdiqomYZg","lastName":"kjDdiqomYZg"}
  03:33:17.763 [front-end] Posting Customer: {"username":"aNdFIdrRbHC","password":"WxDXjaQU","email":"aNdFIdrRbHC@gmail.com","firstName":"aNdFIdrRbHC","lastName":"aNdFIdrRbHC"}
  03:33:21.639 [front-end] Posting Customer: {"username":"ftZTeNByBhYRIUO","password":"pzSAwLK","email":"ftZTeNByBhYRIUO@gmail.com","firstName":"ftZTeNByBhYRIUO","lastName":"ftZTeNByBhYRI
  03:33:23.066 [front-end] Posting Customer: {"username":"lWsTVWyIgVeaA","password":"AzJINokuh","email":"lWsTVWyIgVeaA@gmail.com","firstName":"lWsTVWyIgVeaA","lastName":"lWsTVWyIgVeaA"}
  03:33:25.242 [front-end] Received response: "{\"firstName\":\"Kfdpgakz\",\"lastName\":\"Kfdpgakz\",\"username\":\"Kfdpgakz\",\"id\":\"673ffb6bb0df5c00019b27dc\",\"_links\":{\"addresses\
  03:33:28.027 [front-end] Posting Customer: {"username":"SUWHgtC","password":"aXWkZtMHmk","email":"SUWHgtC@gmail.com","firstName":"SUWHgtC","lastName":"SUWHgtC"}

## p0447
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:06:07.528Z
```
{"timestamp":1732349167528131800,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"statusCode\":500,\"body\":{\"timestamp\":1732349167524,\"status\":500,\"error\":\"Internal Server Error\",\"exception\":\"java.lang.IllegalStateException\",\"message\":\"Unable to create order due to unspecified IO error.\",\"path\":\"/orders\"},\"headers\":{\"x-application-context\":\"orders:80\",\"content-type\":\"application/json;charset=UTF-8\",\"date\":\"Sat, 23 Nov 2024 08:06:07 GMT\",\"x-envoy-upstream-service…"}
```
Same service, the 2 minutes before (oldest first):
  08:06:06.597 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata
  08:06:06.597 [front-end] POST to carts: http://carts/carts/67418ce7a437380001deec7b/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}
  08:06:06.672 [front-end] POST /cart 500 80.467 ms - 64
  08:06:07.050 [front-end] Posting Customer: {"username":"JAEXlZGcwnm","password":"slZRIUj","email":"JAEXlZGcwnm@gmail.com","firstName":"JAEXlZGcwnm","lastName":"JAEXlZGcwnm"}
  08:06:07.056 [front-end] { id: '67418cefa437380001deec8d' }
  08:06:07.056 [front-end] 67418cefa437380001deec8d
  08:06:07.056 [front-end] Merging carts for customer id: 67418cefa437380001deec8d and session id: 4tf8FP9k3SyuWvFgmP0f4_uQyne26SN6
  08:06:07.065 [front-end] Carts merged.
  08:06:07.065 [front-end] set cookie67418cefa437380001deec8d
  08:06:07.066 [front-end] Sent cookies.
  08:06:07.068 [front-end] POST /register 200 16.429 ms - 33
  08:06:07.445 [front-end] GET /catalogue 200 - ms - -
  08:06:07.469 [front-end] Request received with body: {}
  08:06:07.479 [front-end] Received response: "{\"firstName\":\"zFrpP\",\"lastName\":\"zFrpP\",\"username\":\"zFrpP\",\"id\":\"67418cd8a437380001deec43\",\"_links\":{\"addresses\":{\"href
  08:06:07.479 [front-end] GET Request to: http://user/customers/67418cd8a437380001deec43/addresses  (×2)
  08:06:07.487 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418
  08:06:07.488 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418cdfa437380001deec5b\",\"_links\":{\"
  08:06:07.488 [front-end] [ undefined, undefined ]
  08:06:07.488 [front-end] Posting Order: {"customer":"http://user/customers/67418cd8a437380001deec43","address":"http://user/addresses/67418cdfa437380001deec5a","card":"http://user/cards
All services, 30 seconds either side (sampled):
  08:05:37.554 [front-end] Posting Customer: {"username":"QTNxlk","password":"qwbekCU","email":"QTNxlk@gmail.com","firstName":"QTNxlk","lastName":"QTNxlk"}
  08:05:37.895 [front-end] [ undefined, undefined ]  (×61)
  08:05:38.767 [front-end] DELETE /cart 503 - ms - -  (×58)
  08:05:39.189 [orders] 2024-11-23 08:05:39.189 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[DELETE],produces=[applica
  08:05:39.229 [front-end] Posting Customer: {"username":"yeVOXGwCs","password":"WeOmHJe","email":"yeVOXGwCs@gmail.com","firstName":"yeVOXGwCs","lastName":"yeVOXGwCs"}
  08:05:41.188 [orders] 2024-11-23 08:05:41.188 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public 
  08:05:41.942 [front-end] Received response: "{\"firstName\":\"rsVXS\",\"lastName\":\"rsVXS\",\"username\":\"rsVXS\",\"id\":\"67418cc0a437380001deebfb\",\"_links\":{\"addresses\":{\"href
  08:05:44.792 [orders] 2024-11-23 08:05:44.791 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server a  (×2)
  08:05:47.587 [orders] 2024-11-23 08:05:47.587 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization starte
  08:05:49.821 [user] ts=2024-11-23T08:05:49.820987108Z caller=middlewares.go:134 method=GetCards id=67418cd0a437380001deec32 result=1 took=2.170638ms  (×49)
  08:05:54.265 [front-end] Posting Customer: {"username":"imiXj","password":"mbjOThU","email":"imiXj@gmail.com","firstName":"imiXj","lastName":"imiXj"}
  08:05:55.028 [user] ts=2024-11-23T08:05:55.027714889Z caller=middlewares.go:46 method=Register username=brTpfrzj email=brTpfrzj@gmail.com took=2.180901ms
  08:05:59.408 [front-end] Posting Customer: {"username":"VWRTM","password":"jtBtF","email":"VWRTM@gmail.com","firstName":"VWRTM","lastName":"VWRTM"}
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  08:06:05.306 [carts] 2024-11-23 08:06:05.306 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/browser/**] onto handler of type [class org.sp
  08:06:07.004 [shipping] 2024-11-23 08:06:07.004 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[HEAD],produces=[application/
  08:06:07.103 [shipping] 2024-11-23 08:06:07.103 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applic  (×2)
  08:06:12.629 [front-end] Received response: "{\"firstName\":\"WUyAw\",\"lastName\":\"WUyAw\",\"username\":\"WUyAw\",\"id\":\"67418cdea437380001deec56\",\"_links\":{\"addresses\":{\"href
  08:06:15.599 [carts] 2024-11-23 08:06:15.408 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.e
  08:06:15.806 [carts] 2024-11-23 08:06:15.806 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT ||
  08:06:16.434 [front-end] Posting Customer: {"username":"GXUtAA","password":"OZQmnTELUP","email":"GXUtAA@gmail.com","firstName":"GXUtAA","lastName":"GXUtAA"}
  08:06:19.009 [carts] 2024-11-23 08:06:19.009 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  08:06:21.669 [front-end] Posting Customer: {"username":"suxeYRw","password":"WiFMBG","email":"suxeYRw@gmail.com","firstName":"suxeYRw","lastName":"suxeYRw"}
  08:06:24.580 [front-end] Received response: "{\"firstName\":\"djVRqry\",\"lastName\":\"djVRqry\",\"username\":\"djVRqry\",\"id\":\"67418cf2a437380001deec95\",\"_links\":{\"addresses\":{
  08:06:27.406 [front-end] Posting Customer: {"username":"bUcof","password":"MTgADaDKGN","email":"bUcof@gmail.com","firstName":"bUcof","lastName":"bUcof"}
  08:06:30.705 [carts] 2024-11-23 08:06:30.705 INFO [carts,993241630eccab18,e1237bff67df759e,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×8)
  08:06:32.828 [shipping] 2024-11-23 08:06:32.827 INFO [shipping,,,] 7 --- [p-nio-80-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  08:06:35.216 [rabbitmq] connection <0.573.0> (127.0.0.6:57579 -> 192.168.93.151:5672): user 'guest' authenticated and granted access to vhost '/'
  08:06:36.202 [front-end] Order response: {"id":"67418d0b3f77060008864e3c","customerId":"67418cf3a437380001deec98","customer":{"id":null,"firstName":"rxOPSacxRgokAg","lastName":"rxOPSacx

## p0173
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service emailservice, 2024-11-18T06:34:49.143Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731911689143792600,"container_name":"emailservice","pod_name":"emailservice-6b6bbffbcb-mcxbf","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"AttributeError: '_Server' object has no attribute 'Check'"}
```
Same service, the 2 minutes before (oldest first):
  06:33:18.251 [emailservice] A request to send order confirmation email to danielleduke@example.com has been received.
  06:33:19.723 [emailservice] A request to send order confirmation email to zsmith@example.org has been received.
  06:33:25.782 [emailservice] A request to send order confirmation email to xgray@example.com has been received.
  06:33:35.218 [emailservice] A request to send order confirmation email to bryananna@example.net has been received.
  06:33:42.967 [emailservice] A request to send order confirmation email to beth47@example.com has been received.
  06:33:44.113 [emailservice] A request to send order confirmation email to phillipsteresa@example.net has been received.
  06:33:47.668 [emailservice] A request to send order confirmation email to zjones@example.net has been received.
  06:33:54.417 [emailservice] A request to send order confirmation email to robinsonandrew@example.org has been received.
  06:34:10.529 [emailservice] A request to send order confirmation email to hansonjoshua@example.com has been received.
  06:34:17.680 [emailservice] A request to send order confirmation email to bwells@example.net has been received.
  06:34:17.778 [emailservice] A request to send order confirmation email to julieperkins@example.com has been received.
  06:34:18.474 [emailservice] A request to send order confirmation email to david72@example.com has been received.
  06:34:23.200 [emailservice] A request to send order confirmation email to chris07@example.com has been received.
  06:34:30.287 [emailservice] A request to send order confirmation email to deborah28@example.com has been received.
  06:34:35.872 [emailservice] A request to send order confirmation email to martinezsara@example.net has been received.
  06:34:39.059 [emailservice] A request to send order confirmation email to pthompson@example.org has been received.
  06:34:41.371 [emailservice] A request to send order confirmation email to krivas@example.net has been received.
  06:34:49.047 [emailservice] starting the email service in dummy mode.
  06:34:49.047 [emailservice] Profiler disabled.
  06:34:49.143 [emailservice] Traceback (most recent call last): File "/email_server/email_server.py", line 199, in <module> start(dummy_mode = True) File "/email_server/email_server.py", li
All services, 30 seconds either side (sampled):
  06:34:19.417 [frontend] request started  (×286)
  06:34:19.426 [cartservice] GetCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×239)
  06:34:19.452 [adservice] received ad request (context_words=[accessories])  (×35)
  06:34:20.169 [adservice] received ad request (context_words=[decor, home])  (×15)
  06:34:21.034 [frontend] view user cart  (×57)
  06:34:21.059 [shippingservice] [GetQuote] completed request  (×65)
  06:34:22.403 [frontend] ENV_PLATFORM is: aws  (×32)
  06:34:23.159 [frontend] placing order  (×8)
  06:34:23.185 [paymentservice] Transaction processed: visa ending 5958 Amount: TRY1229.219976114  (×2)
  06:34:23.190 [shippingservice] [ShipOrder] completed request  (×8)
  06:34:23.201 [checkoutservice] order confirmation email sent to "chris07@example.com"
  06:34:26.195 [frontend] setting currency  (×24)
  06:34:30.275 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"62","nanos":853795666},"credit_card":{"credit_card_number":"491516361298030  (×2)
  06:34:30.288 [checkoutservice] order confirmation email sent to "deborah28@example.com"
  06:34:35.873 [checkoutservice] order confirmation email sent to "martinezsara@example.net"
  06:34:39.047 [paymentservice] Transaction processed: visa ending 0931 Amount: EUR209.526758077
  06:34:41.331 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="JPY"  (×3)
  06:34:41.371 [emailservice] A request to send order confirmation email to krivas@example.net has been received.
  06:34:49.047 [emailservice] Profiler disabled.  (×3)
  06:34:49.784 [checkoutservice] failed to send order confirmation to "jeffrey34@example.net": rpc error: code = Unavailable desc = no healthy upstream
  06:35:07.237 [checkoutservice] failed to send order confirmation to "adamsmichael@example.net": rpc error: code = Unavailable desc = no healthy upstream

## p0764
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T06:39:03.949Z
```
{"timestamp":1732257543949697300,"container_name":"front-end","pod_name":"front-end-f77549869-mxq2p","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Card: {\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"userID\":\"67402701768f35000114f49e\"}"}
```
Same service, the 2 minutes before (oldest first):
  06:39:03.871 [front-end] Attempting to delete cart for user: 674026ff768f35000114f498
  06:39:03.890 [front-end] User cart deleted with status: 202
  06:39:03.893 [front-end] DELETE /cart 202 - ms - -
  06:39:03.901 [front-end] Attempting to add to cart: {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  06:39:03.909 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca
  06:39:03.909 [front-end] POST to carts: http://carts/carts/674026ff768f35000114f498/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}
  06:39:03.914 [front-end] Request received with body: {}
  06:39:03.925 [front-end] Received response: "{\"firstName\":\"bZIgiCBnYGiktV\",\"lastName\":\"bZIgiCBnYGiktV\",\"username\":\"bZIgiCBnYGiktV\",\"id\":\"674026f3768f35000114f475\",\"_lin
  06:39:03.925 [front-end] GET Request to: http://user/customers/674026f3768f35000114f475/addresses  (×2)
  06:39:03.930 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67402701768f35000114f49d"}  (×2)
  06:39:03.935 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67402
  06:39:03.935 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"674026fc768f35000114f48f\",\"_links\":{\"
  06:39:03.935 [front-end] [ undefined, undefined ]
  06:39:03.935 [front-end] Posting Order: {"customer":"http://user/customers/674026f3768f35000114f475","address":"http://user/addresses/674026fc768f35000114f48e","card":"http://user/cards
  06:39:03.940 [front-end] POST /addresses 200 - ms - -  (×2)
  06:39:03.946 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67402701768f35000114f49d"}
  06:39:03.947 [front-end] POST /cart 201 - ms - -
All services, 30 seconds either side (sampled):
  06:38:33.999 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"674026e1768f35000114f445"}  (×65)
  06:38:34.120 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×7)
  06:38:34.155 [payment] ts=2024-11-22T06:38:34Z caller=logging.go:29 method=Authorise result=true took=687ns  (×57)
  06:38:34.565 [front-end] Order response: {"statusCode":201,"body":{"id":"674026ea531af4000701df9f","customerId":"674026d0768f35000114f404","customer":{"id":null,"firstName":"YtuayBIWA",
  06:38:35.483 [front-end] Order response: {"statusCode":201,"body":{"id":"674026eb531af4000701dfa2","customerId":"674026dc768f35000114f42f","customer":{"id":null,"firstName":"EvyAoJsBgeV
  06:38:36.329 [front-end] Received response: "{\"firstName\":\"DcJcAClakyypxp\",\"lastName\":\"DcJcAClakyypxp\",\"username\":\"DcJcAClakyypxp\",\"id\":\"674026d7768f35000114f419\",\"_lin
  06:38:36.670 [user] ts=2024-11-22T06:38:36.670559861Z caller=middlewares.go:157 method=Health result=2 took=1.794988ms  (×40)
  06:38:38.173 [front-end] Posting Customer: {"username":"aoyhHYyHb","password":"JgxjBpUfB","email":"aoyhHYyHb@gmail.com","firstName":"aoyhHYyHb","lastName":"aoyhHYyHb"}
  06:38:40.680 [carts] 2024-11-22 06:38:40.679 INFO [carts,86a45e9a98cf672a,5785d70e0fd88b15,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.controllers.CartsController : Merge carts reques  (×24)
  06:38:42.451 [user] ts=2024-11-22T06:38:42.451704742Z caller=middlewares.go:46 method=Register username=GRRWz email=GRRWz@gmail.com took=2.220407ms
  06:38:45.191 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×5)
  06:38:46.770 [front-end] Received response: "{\"firstName\":\"kdwWcmaILM\",\"lastName\":\"kdwWcmaILM\",\"username\":\"kdwWcmaILM\",\"id\":\"674026e6768f35000114f454\",\"_links\":{\"addr
  06:38:48.649 [front-end] Order response: {"id":"674026f8531af4000701dfb3","customerId":"674026e2768f35000114f447","customer":{"id":null,"firstName":"tYdXFTsFd","lastName":"tYdXFTsFd","u
  06:38:52.957 [front-end] Posting Customer: {"username":"MLXRBPkbjxtg","password":"qLAXVFmWff","email":"MLXRBPkbjxtg@gmail.com","firstName":"MLXRBPkbjxtg","lastName":"MLXRBPkbjxtg"}
  06:38:56.381 [front-end] Order response: {"id":"67402700531af4000701dfb7","customerId":"674026e9768f35000114f45b","customer":{"id":null,"firstName":"MfdattwSKpbn","lastName":"MfdattwSKp
  06:38:59.784 [front-end] Order response: {"id":"67402703531af4000701dfb9","customerId":"674026f2768f35000114f471","customer":{"id":null,"firstName":"GRRWz","lastName":"GRRWz","username"
  06:39:03.163 [front-end] Order response: {"statusCode":201,"body":{"id":"67402707531af4000701dfbb","customerId":"674026f5768f35000114f479","customer":{"id":null,"firstName":"bdbPoQDFUTJ
  06:39:04.967 [front-end] Order response: {"statusCode":201,"body":{"id":"67402708531af4000701dfbe","customerId":"674026f0768f35000114f46d","customer":{"id":null,"firstName":"PDUygixgUcK
  06:39:08.206 [front-end] Received response: "{\"firstName\":\"NztpjFiEs\",\"lastName\":\"NztpjFiEs\",\"username\":\"NztpjFiEs\",\"id\":\"674026f3768f35000114f476\",\"_links\":{\"address
  06:39:11.203 [front-end] Order response: {"id":"6740270f531af4000701dfc4","customerId":"674026fb768f35000114f48c","customer":{"id":null,"firstName":"ZVcAOEFR","lastName":"ZVcAOEFR","use
  06:39:14.071 [user] ts=2024-11-22T06:39:14.070809858Z caller=middlewares.go:46 method=Register username=ycrihIb email=ycrihIb@gmail.com took=4.007782ms
  06:39:16.120 [front-end] Received response: "{\"firstName\":\"sLEYwOHf\",\"lastName\":\"sLEYwOHf\",\"username\":\"sLEYwOHf\",\"id\":\"67402701768f35000114f49d\",\"_links\":{\"addresses\
  06:39:18.090 [front-end] Received response: "{\"firstName\":\"vCDmprLMPmmbRm\",\"lastName\":\"vCDmprLMPmmbRm\",\"username\":\"vCDmprLMPmmbRm\",\"id\":\"674026fc768f35000114f490\",\"_lin
  06:39:19.757 [front-end] Order response: {"id":"67402717531af4000701dfcd","customerId":"67402702768f35000114f4a3","customer":{"id":null,"firstName":"Fmvrks","lastName":"Fmvrks","usernam
  06:39:22.828 [front-end] Received response: "{\"firstName\":\"vzDrEiCCAfGKc\",\"lastName\":\"vzDrEiCCAfGKc\",\"username\":\"vzDrEiCCAfGKc\",\"id\":\"67402703768f35000114f4a6\",\"_links\
  06:39:26.367 [front-end] Received response: "{\"firstName\":\"MVCEt\",\"lastName\":\"MVCEt\",\"username\":\"MVCEt\",\"id\":\"67402706768f35000114f4b1\",\"_links\":{\"addresses\":{\"href
  06:39:27.917 [front-end] Order response: {"statusCode":201,"body":{"id":"6740271f531af4000701dfd7","customerId":"67402706768f35000114f4b2","customer":{"id":null,"firstName":"TsSnW","las
  06:39:30.385 [front-end] Order response: {"id":"67402722531af4000701dfd9","customerId":"67402712768f35000114f4d9","customer":{"id":null,"firstName":"ycrihIb","lastName":"ycrihIb","usern
  06:39:33.489 [front-end] Order response: {"statusCode":201,"body":{"id":"67402725531af4000701dfdc","customerId":"67402711768f35000114f4d7","customer":{"id":null,"firstName":"DwkuzALEipn

## p0198
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T06:54:41.605Z
```
{"timestamp":1731912881605923300,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  06:54:39.568 [currencyservice] Getting supported currencies...  (×9)
  06:54:39.579 [currencyservice] conversion request successful  (×11)
All services, 30 seconds either side (sampled):
  06:54:11.639 [frontend] request started  (×349)
  06:54:11.650 [cartservice] GetCartAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432  (×282)
  06:54:11.676 [adservice] received ad request (context_words=[accessories])  (×25)
  06:54:11.758 [frontend] ENV_PLATFORM is: aws  (×35)
  06:54:12.791 [frontend] adding to cart  (×43)
  06:54:12.823 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'OLJCESPC7Z']  (×4)
  06:54:12.907 [adservice] received ad request (context_words=[kitchen])  (×59)
  06:54:13.040 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"67520","nanos":297213815},"credit_card":{"credit_card_number":"409481743262  (×3)
  06:54:13.044 [shippingservice] [ShipOrder] received request  (×17)
  06:54:13.054 [emailservice] A request to send order confirmation email to devon86@example.org has been received.
  06:54:14.089 [adservice] received ad request (context_words=[decor, home])  (×17)
  06:54:14.163 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"88","nanos":265624061},"credit_card":{"credit_card_number":"427183441806829  (×3)
  06:54:14.176 [checkoutservice] order confirmation email sent to "qgriffin@example.net"
  06:54:15.875 [adservice] received ad request (context_words=[footwear])  (×14)
  06:54:16.054 [paymentservice] Transaction processed: visa ending 6565 Amount: TRY1169.354487400
  06:54:17.194 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', '2ZYFJ3GM2N', '1YMWWN1N4O', 'LS4PSXUNUM']  (×5)
  06:54:21.960 [paymentservice] Transaction processed: visa ending 4719 Amount: EUR976.329057947  (×5)
  06:54:24.380 [adservice] received ad request (context_words=[clothing, tops])  (×18)
  06:54:29.310 [paymentservice] Transaction processed: visa ending 6127 Amount: GBP1600.129457757
  06:54:31.744 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z']  (×3)
  06:54:34.096 [paymentservice] Transaction processed: visa ending 2236 Amount: USD667.130000000  (×4)
  06:54:34.293 [emailservice] A request to send order confirmation email to teresakelly@example.net has been received.
  06:54:45.159 [emailservice] A request to send order confirmation email to kimberlystrickland@example.com has been received.
  06:54:47.051 [checkoutservice] order confirmation email sent to "maureenburke@example.org"
  06:55:00.192 [emailservice] A request to send order confirmation email to phillipslouis@example.net has been received.
  06:55:00.426 [checkoutservice] order confirmation email sent to "melissa97@example.org"
  06:55:05.234 [emailservice] A request to send order confirmation email to cowandiana@example.org has been received.
  06:55:07.659 [checkoutservice] order confirmation email sent to "youngcrystal@example.com"

## p0153
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T05:43:23.822Z
```
{"timestamp":1731908603822413800,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-m2ddm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"info: Microsoft.Hosting.Lifetime[0]\n      Application is shutting down..."}
```
Same service, the 2 minutes before (oldest first):
  05:43:18.623 [cartservice] GetCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×19)
  05:43:21.177 [cartservice] AddItemAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927, productId=OLJCESPC7Z, quantity=4
All services, 30 seconds either side (sampled):
  05:42:54.362 [frontend] request started  (×309)
  05:42:54.372 [cartservice] GetCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×248)
  05:42:54.395 [adservice] received ad request (context_words=[kitchen])  (×57)
  05:42:54.404 [cartservice] AddItemAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b, productId=9SIQT8TOJO, quantity=1  (×20)
  05:42:54.437 [shippingservice] [GetQuote] received request  (×65)
  05:42:54.474 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="EUR"  (×3)
  05:42:54.517 [checkoutservice] payment went through (transaction_id: 41f69a2c-f161-4404-a07d-a3444f490be0)  (×12)
  05:42:54.521 [cartservice] EmptyCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×12)
  05:42:54.529 [frontend] order placed  (×12)
  05:42:55.314 [adservice] received ad request (context_words=[])  (×37)
  05:42:57.558 [frontend] setting currency  (×23)
  05:42:59.266 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', 'L9ECAV7KIM', '0PUK6V6EV0']
  05:43:00.036 [paymentservice] Transaction processed: visa ending 1697 Amount: TRY4782.737868224  (×4)
  05:43:00.794 [adservice] received ad request (context_words=[clothing, tops])  (×16)
  05:43:06.514 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="GBP"
  05:43:06.564 [emailservice] A request to send order confirmation email to clayruth@example.net has been received.
  05:43:09.195 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"84221","nanos":197701114},"credit_card":{"credit_card_number":"429816317399  (×2)
  05:43:09.211 [checkoutservice] order confirmation email sent to "iadams@example.com"
  05:43:10.550 [emailservice] A request to send order confirmation email to stephenjackson@example.net has been received.
  05:43:13.653 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"768","nanos":830000000},"credit_card":{"credit_card_number":"45753943286545
  05:43:13.668 [checkoutservice] order confirmation email sent to "woodariel@example.org"
  05:43:24.743 [cartservice] info: Microsoft.Hosting.Lifetime[14] Now listening on: http://[::]:7070
  05:43:24.839 [cartservice] info: Microsoft.Hosting.Lifetime[0] Content root path: /app
  05:43:28.343 [emailservice] A request to send order confirmation email to zscott@example.com has been received.
  05:43:30.493 [checkoutservice] order confirmation email sent to "rodneyreeves@example.com"
  05:43:51.764 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="CAD"
  05:43:51.800 [emailservice] A request to send order confirmation email to jmyers@example.com has been received.

## p0679
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-12T00:26:35.092Z
```
{"service":"dbservice2","message":"2021-08-12 00:26:35,092 | ERROR | 0.0.0.2 | dbservice2 | db_helper.py -> sql_ano_prob -> 93 | 3a231593158ef84f | (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)"}
```
Same service, the 2 minutes before (oldest first):
  00:26:31.104 [dbservice2] INFO query = select passwards from username_table where user_name='VpEUCejs'  (×5)
  00:26:31.181 [dbservice2] INFO e279cde6-fac0-11eb-9dec-0242ac110004-VpEUCejs-1(0N5)u2?&IX token generate success token=MTYyODY5OTE5MS4xODA3NjczOmUyNzljZGU2LWZhYzAtMTFlYi05ZGVjLTAyNDJhYzE
  00:26:31.847 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  00:26:31.847 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  00:26:31.978 [dbservice2] INFO e2eb0218-fac0-11eb-b614-0242ac110003-dsqULkKQ-zLV!t_x^6AM( token generate success token=MTYyODY5OTE5MS45NzgyNzU6ZTJlYjAyMTgtZmFjMC0xMWViLWI2MTQtMDI0MmFjMTE
  00:26:32.750 [dbservice2] INFO e3608eb6-fac0-11eb-9dd7-0242ac110004-CapPHYsG-_8-3dh}qnA>K token generate success token=MTYyODY5OTE5Mi43NTAzMTU3OmUzNjA4ZWI2LWZhYzAtMTFlYi05ZGQ3LTAyNDJhYzE
  00:26:33.791 [dbservice2] INFO e3fd34aa-fac0-11eb-a13d-0242ac110004-fQnPbvcw-04i:fu92qAH7 token generate success token=MTYyODY5OTE5My43OTE0OTk0OmUzZmQzNGFhLWZhYzAtMTFlYi1hMTNkLTAyNDJhYzE
  00:26:34.285 [dbservice2] INFO e460338e-fac0-11eb-ba63-0242ac110003-NkRbASML-pbH0md!=?Yk: token generate success token=MTYyODY5OTE5NC4yODQ3NzMzOmU0NjAzMzhlLWZhYzAtMTFlYi1iYTYzLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  00:26:05.100 [dbservice2] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  00:26:05.205 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': 'd3146c1c-fac0-11eb-8546-0242ac110003', 'user_id': 'kPDTFpxO'}  (×83)
  00:26:05.460 [dbservice2] INFO d3146c1c-fac0-11eb-8546-0242ac110003-kPDTFpxO-UE_Y6mhf=Hb1 token generate success token=MTYyODY5OTE2NS40NTk0NzI0OmQzMTQ2YzFjLWZhYzAtMTFlYi04NTQ2LTAyNDJhYzE  (×2)
  00:26:05.739 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×40)
  00:26:06.273 [redisservice1] INFO service accept, status_code: 200  (×34)
  00:26:06.600 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×42)
  00:26:07.539 [mobservice2] INFO info d48f87ac-fac0-11eb-b775-0242ac110004:DqvNnYcw write success
  00:26:08.473 [mobservice1] INFO info d51d885e-fac0-11eb-bf89-0242ac110003:bAuaLHTx write success
  00:26:08.755 [dbservice2] INFO d51d885e-fac0-11eb-bf89-0242ac110003-bAuaLHTx-R=uojVhf*a/X token generate success token=MTYyODY5OTE2OC43NTUyODQ1OmQ1MWQ4ODVlLWZhYzAtMTFlYi1iZjg5LTAyNDJhYzE
  00:26:11.389 [dbservice1] INFO d69cdb80-fac0-11eb-97f8-0242ac110003-cvwxUkHZ-GQ=maK<n.t:_ token generate success token=MTYyODY5OTE3MS4zODkwODY3OmQ2OWNkYjgwLWZhYzAtMTFlYi05N2Y4LTAyNDJhYzE
  00:26:13.683 [dbservice2] INFO d7f443b0-fac0-11eb-9130-0242ac110004-qHGVUSPX-2X6L_bVf5*I< token generate success token=MTYyODY5OTE3My42ODI2MDM2OmQ3ZjQ0M2IwLWZhYzAtMTFlYi05MTMwLTAyNDJhYzE
  00:26:16.603 [dbservice1] INFO d9afa050-fac0-11eb-96b7-0242ac110003-sJSHvCwD-V&3eDfs.hExa token generate success token=MTYyODY5OTE3Ni42MDM2MDQ2OmQ5YWZhMDUwLWZhYzAtMTFlYi05NmI3LTAyNDJhYzE
  00:26:19.438 [dbservice1] INFO db6bf9f2-fac0-11eb-9c65-0242ac110004-GZqDYHLc--PqE2macry.D token generate success token=MTYyODY5OTE3OS40Mzg0NDg0OmRiNmJmOWYyLWZhYzAtMTFlYi05YzY1LTAyNDJhYzE
  00:26:22.219 [dbservice1] INFO dd0f45ca-fac0-11eb-8913-0242ac110003-IKTgrkvl-puzDw*h+_H#V token generate success token=MTYyODY5OTE4Mi4yMTg2Mjk6ZGQwZjQ1Y2EtZmFjMC0xMWViLTg5MTMtMDI0MmFjMTE
  00:26:24.866 [mobservice1] INFO info decc7f22-fac0-11eb-9b7f-0242ac110004:dzcaqmiU write success
  00:26:27.782 [mobservice2] INFO info e0a0f972-fac0-11eb-9cac-0242ac110003:EQWxHTiy write success
  00:26:30.127 [mobservice2] INFO info e20ae0e8-fac0-11eb-a14b-0242ac110004:uiZfvcTY write success
  00:26:32.405 [mobservice2] INFO info e3608eb6-fac0-11eb-9dd7-0242ac110004:CapPHYsG write success
  00:26:34.697 [mobservice2] INFO info e4c4e734-fac0-11eb-9d61-0242ac110003:yQDVrgJw write success
  00:26:37.523 [dbservice2] INFO e63c49cc-fac0-11eb-8f74-0242ac110003-ICpXWslJ-tkrd@G6KNM5v token generate success token=MTYyODY5OTE5Ny41MjMzMjA0OmU2M2M0OWNjLWZhYzAtMTFlYi04Zjc0LTAyNDJhYzE
  00:26:39.853 [dbservice2] INFO e7a29a6e-fac0-11eb-adbb-0242ac110004-whQCkgBs-pT02U8&n*?u4 token generate success token=MTYyODY5OTE5OS44NTI5NjI3OmU3YTI5YTZlLWZhYzAtMTFlYi1hZGJiLTAyNDJhYzE
  00:26:42.216 [dbservice1] INFO e90782d4-fac0-11eb-8de7-0242ac110004-IdNORUSj-swS@j6J2Bk%t token generate success token=MTYyODY5OTIwMi4yMTYxMDk1OmU5MDc4MmQ0LWZhYzAtMTFlYi04ZGU3LTAyNDJhYzE
  00:26:52.901 [dbservice1] INFO ef5ed2ae-fac0-11eb-8498-0242ac110003-AsKCtDoY-n2BPkW(-x&s# token generate success token=MTYyODY5OTIxMi45MDE1MzQzOmVmNWVkMmFlLWZhYzAtMTFlYi04NDk4LTAyNDJhYzE
  00:26:55.645 [mobservice2] INFO info f134aaa4-fac0-11eb-b57b-0242ac110003:wpOMLejE write success
  00:26:57.870 [mobservice2] INFO info f28e6f2a-fac0-11eb-a18b-0242ac110004:vOcCSRZA write success
  00:27:00.334 [mobservice1] INFO info f403ebbe-fac0-11eb-b6bd-0242ac110004:QTpUuoqV write success
  00:27:02.789 [mobservice2] INFO info f58282c0-fac0-11eb-8470-0242ac110003:BWZgetyT write success

## p0052
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T08:17:03.503Z
```
{"service":"dbservice2","message":"2021-08-13 08:17:03,503 | INFO | 0.0.0.2 | dbservice2 | permission_operate.py -> permission_operation -> 35 | 2ff3f38c01f1f79a | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  08:16:58.519 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:16:58.519 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  08:16:58.533 [dbservice2] ERROR service refuse  (×5)
  08:16:58.534 [dbservice2] ERROR dbservice2 access redis service denied  (×5)
All services, 30 seconds either side (sampled):
  08:16:33.571 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×51)
  08:16:33.666 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×51)
  08:16:33.758 [dbservice2] ERROR dbservice2 access redis service denied  (×51)
  08:16:33.997 [webservice2] INFO complete information: {'uuid': 'b7605402-fbcb-11eb-9e90-0242ac110004', 'user_id': 'zoYxJZbF'}  (×48)
  08:16:34.088 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×52)
  08:16:34.463 [dbservice1] INFO b7605402-fbcb-11eb-9e90-0242ac110004-zoYxJZbF-qI)V<HmnWMk} token generate success token=MTYyODgxMzc5NC40NjI3MjU6Yjc2MDU0MDItZmJjYi0xMWViLTllOTAtMDI0MmFjMTE
  08:16:34.757 [webservice1] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×51)
  08:16:35.257 [redisservice1] INFO service accept, status_code: 200  (×20)
  08:16:36.937 [dbservice1] INFO b8cfb35a-fbcb-11eb-b8f0-0242ac110004-LtXTsDKV-%Zv&u()YBC-S token generate success token=MTYyODgxMzc5Ni45Mzc1MzEyOmI4Y2ZiMzVhLWZiY2ItMTFlYi1iOGYwLTAyNDJhYzE
  08:16:37.498 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×49)
  08:16:39.020 [mobservice2] INFO info ba418c0e-fbcb-11eb-9785-0242ac110003:iAefFjPB write success
  08:16:41.477 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×3)
  08:16:43.982 [dbservice1] INFO bd095b2e-fbcb-11eb-be1b-0242ac110003-lYAOPtMm-rw)X>-}nmF+E token generate success token=MTYyODgxMzgwMy45ODI0MDU0OmJkMDk1YjJlLWZiY2ItMTFlYi1iZTFiLTAyNDJhYzE
  08:16:46.761 [mobservice1] INFO info bee035da-fbcb-11eb-bf0e-0242ac110003:aEBDmkFT write success
  08:16:49.890 [mobservice2] INFO info c0b23fb6-fbcb-11eb-9caa-0242ac110004:lzeSVXuM write success
  08:16:52.893 [mobservice2] INFO info c286594e-fbcb-11eb-9591-0242ac110003:dtYZahVu write success
  08:16:55.391 [mobservice1] INFO info c4066408-fbcb-11eb-b297-0242ac110004:cHTYOdVw write success
  08:16:58.933 [mobservice2] INFO info c6218420-fbcb-11eb-abe5-0242ac110003:mFYdOIbz write success
  08:17:01.536 [dbservice1] INFO c774c882-fbcb-11eb-8408-0242ac110003-APxbpyWu-<Fk%s3dztCD} token generate success token=MTYyODgxMzgyMS41MzU2OTg6Yzc3NGM4ODItZmJjYi0xMWViLTg0MDgtMDI0MmFjMTE
  08:17:04.861 [mobservice2] INFO info c9aa2bc4-fbcb-11eb-8fa8-0242ac110003:plhmCNjI write success
  08:17:07.285 [mobservice2] INFO info cb1966c8-fbcb-11eb-a32a-0242ac110003:WYjcLizJ write success
  08:17:10.211 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  08:17:12.860 [mobservice2] INFO info ce6cb0aa-fbcb-11eb-a3cd-0242ac110003:aLCdNFuD write success
  08:17:15.603 [mobservice1] INFO info d0192744-fbcb-11eb-aaf6-0242ac110004:PzgvQsFL write success
  08:17:18.609 [mobservice1] INFO info d1dcf394-fbcb-11eb-af93-0242ac110003:RVeouDMj write success
  08:17:21.830 [dbservice1] INFO d388b124-fbcb-11eb-96fb-0242ac110004-bHrMSWsj--%0VNhY.LywK token generate success token=MTYyODgxMzg0MS44MzA1OTEyOmQzODhiMTI0LWZiY2ItMTFlYi05NmZiLTAyNDJhYzE
  08:17:24.679 [mobservice2] INFO info d57a0f64-fbcb-11eb-b93e-0242ac110003:tcZveHsK write success
  08:17:28.531 [mobservice2] INFO info d7c310ea-fbcb-11eb-9284-0242ac110003:CxaURntJ write success
  08:17:31.454 [mobservice2] INFO info d97a88e6-fbcb-11eb-b0f6-0242ac110003:RTiMKfox write success

## p0504
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service payment, 2024-11-23T09:16:48.737Z
```
{"timestamp":1732353408737132300,"container_name":"payment","pod_name":"payment-78bf948dc4-mbtwc","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:16:48Z caller=logging.go:40 method=Health result=1 took=2.036µs"}
```
Same service, the 2 minutes before (oldest first):
  09:16:18.736 [payment] ts=2024-11-23T09:16:18Z caller=logging.go:40 method=Health result=1 took=2.108µs  (×20)
All services, 30 seconds either side (sampled):
  09:16:18.748 [front-end] Request received with body: {}  (×63)
  09:16:18.782 [orders] 2024-11-23 09:16:18.781 ERROR [orders,a656c8dbd1bc8799,0f35315e34d30054,false] 7 --- [p-nio-80-exec-8] o.s.d.r.w.RepositoryRestExceptionHandler : Could not read  (×56)
  09:16:18.838 [front-end] GET /catalogue 200 - ms - -  (×62)
  09:16:19.435 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67419d5ea437380001df0db8"}  (×60)
  09:16:19.459 [user] ts=2024-11-23T09:16:19.459555675Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419d5ea437380001df0db8 took=6.245065ms  (×60)
  09:16:19.547 [front-end] POST to carts: http://carts/carts/67419d5ea437380001df0db8/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×32)
  09:16:20.016 [front-end] Received response: "{\"firstName\":\"LhjpTEtDHqr\",\"lastName\":\"LhjpTEtDHqr\",\"username\":\"LhjpTEtDHqr\",\"id\":\"67419d51a437380001df0d8f\",\"_links\":{\"a
  09:16:23.080 [front-end] Posting Customer: {"username":"ClzNbMQwsLB","password":"TgarQ","email":"ClzNbMQwsLB@gmail.com","firstName":"ClzNbMQwsLB","lastName":"ClzNbMQwsLB"}
  09:16:24.204 [carts-db] {"t":{"$date":"2024-11-23T09:16:24.203+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235338
  09:16:26.311 [front-end] Posting Customer: {"username":"KRmUtOwXR","password":"QtWlEbsTij","email":"KRmUtOwXR@gmail.com","firstName":"KRmUtOwXR","lastName":"KRmUtOwXR"}
  09:16:28.266 [front-end] Received response: "{\"firstName\":\"VkxTgKmlvQiidi\",\"lastName\":\"VkxTgKmlvQiidi\",\"username\":\"VkxTgKmlvQiidi\",\"id\":\"67419d5ba437380001df0daf\",\"_lin
  09:16:29.566 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×6)
  09:16:33.025 [session-db] 33:C 23 Nov 2024 09:16:33.025 * Fork CoW for RDB: current 0 MB, peak 0 MB, average 0 MB
  09:16:35.901 [front-end] Posting Customer: {"username":"QknWJguTGOhMi","password":"uNChQF","email":"QknWJguTGOhMi@gmail.com","firstName":"QknWJguTGOhMi","lastName":"QknWJguTGOhMi"}
  09:16:38.453 [front-end] Received response: "{\"firstName\":\"jHWew\",\"lastName\":\"jHWew\",\"username\":\"jHWew\",\"id\":\"67419d5da437380001df0db6\",\"_links\":{\"addresses\":{\"href
  09:16:40.430 [front-end] Posting Customer: {"username":"SMYbzcPsLM","password":"YILBFc","email":"SMYbzcPsLM@gmail.com","firstName":"SMYbzcPsLM","lastName":"SMYbzcPsLM"}
  09:16:44.420 [front-end] Received response: "{\"firstName\":\"jTkgd\",\"lastName\":\"jTkgd\",\"username\":\"jTkgd\",\"id\":\"67419d62a437380001df0dbf\",\"_links\":{\"addresses\":{\"href
  09:16:47.602 [front-end] Received response: "{\"firstName\":\"gKaQVzZpQim\",\"lastName\":\"gKaQVzZpQim\",\"username\":\"gKaQVzZpQim\",\"id\":\"67419d6ca437380001df0ddd\",\"_links\":{\"a
  09:16:49.726 [front-end] Received response: "{\"firstName\":\"HmZocsyP\",\"lastName\":\"HmZocsyP\",\"username\":\"HmZocsyP\",\"id\":\"67419d72a437380001df0dee\",\"_links\":{\"addresses\
  09:16:53.289 [user] ts=2024-11-23T09:16:53.289171672Z caller=middlewares.go:46 method=Register username=wyimcuiMV email=wyimcuiMV@gmail.com took=2.803668ms
  09:16:55.002 [front-end] Posting Customer: {"username":"GObjabUkigiJqXO","password":"XnTsJnHqb","email":"GObjabUkigiJqXO@gmail.com","firstName":"GObjabUkigiJqXO","lastName":"GObjabUkigi
  09:17:00.549 [front-end] Posting Customer: {"username":"IVfWMAaQK","password":"nkbNpD","email":"IVfWMAaQK@gmail.com","firstName":"IVfWMAaQK","lastName":"IVfWMAaQK"}
  09:17:02.747 [user] ts=2024-11-23T09:17:02.747197672Z caller=middlewares.go:46 method=Register username=mqaEQvrxP email=mqaEQvrxP@gmail.com took=5.803269ms
  09:17:04.742 [front-end] Received response: "{\"firstName\":\"SMYbzcPsLM\",\"lastName\":\"SMYbzcPsLM\",\"username\":\"SMYbzcPsLM\",\"id\":\"67419d78a437380001df0e04\",\"_links\":{\"addr
  09:17:10.649 [front-end] Posting Customer: {"username":"pZTAkTrJ","password":"QbXVW","email":"pZTAkTrJ@gmail.com","firstName":"pZTAkTrJ","lastName":"pZTAkTrJ"}
  09:17:13.068 [user] ts=2024-11-23T09:17:13.068141075Z caller=middlewares.go:46 method=Register username=UvcmfmOl email=UvcmfmOl@gmail.com took=3.118112ms
  09:17:16.217 [front-end] Received response: "{\"firstName\":\"GObjabUkigiJqXO\",\"lastName\":\"GObjabUkigiJqXO\",\"username\":\"GObjabUkigiJqXO\",\"id\":\"67419d87a437380001df0e31\",\"_
  09:17:17.882 [front-end] Received response: "{\"firstName\":\"dZjNcwICumdRTfX\",\"lastName\":\"dZjNcwICumdRTfX\",\"username\":\"dZjNcwICumdRTfX\",\"id\":\"67419d85a437380001df0e2d\",\"_

## p0703
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-12T21:25:18.504Z
```
{"service":"dbservice1","message":"2021-08-12 21:25:18,504 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 65f6989983da1fa6 | bc2b0bd6-fb70-11eb-a953-0242ac110004-fNPgFxnR-@1V8_GF/6A+7 token generate success token=MTYyODc3NDcxOC41MDQyMzg2OmJjMmIwYmQ2LWZiNzAtMTFlYi1hOTUzLTAyNDJhYzExMDAwNGZOUGdGeG5SQDFWOF9HRi82QSs3OjE2Mjg3NzQ3NzguNTA0MjQ5Mzo0YWMxY2NkY2FlMTMzOTk0N2UyODUyMzM5MjlmMTcxMg=="}
```
Same service, the 2 minutes before (oldest first):
  21:25:09.451 [dbservice1] INFO b6e8ae44-fb70-11eb-b144-0242ac110004-TpPSMOEF-P)x}eV<WmgRs token generate success token=MTYyODc3NDcwOS40NTE0MTM6YjZlOGFlNDQtZmI3MC0xMWViLWIxNDQtMDI0MmFjMTE
  21:25:11.182 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  21:25:11.182 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  21:25:11.243 [dbservice1] INFO query = select passwards from username_table where user_name='KPxfCQdu'  (×5)
  21:25:11.320 [dbservice1] INFO b7edae20-fb70-11eb-bff8-0242ac110003-KPxfCQdu-eqAZ:_VsH_io token generate success token=MTYyODc3NDcxMS4zMjA0Njg0OmI3ZWRhZTIwLWZiNzAtMTFlYi1iZmY4LTAyNDJhYzE
  21:25:14.102 [dbservice1] INFO b9a2cb1a-fb70-11eb-bcbc-0242ac110004-NhtsWobx->YgS8K?XxrDn token generate success token=MTYyODc3NDcxNC4xMDE3MjQ2OmI5YTJjYjFhLWZiNzAtMTFlYi1iY2JjLTAyNDJhYzE
  21:25:16.743 [dbservice1] INFO bb319b8c-fb70-11eb-90ec-0242ac110004-AGLgdhsM-ji4TE)}3I$My token generate success token=MTYyODc3NDcxNi43NDM1MjgxOmJiMzE5YjhjLWZiNzAtMTFlYi05MGVjLTAyNDJhYzE
  21:25:17.570 [dbservice1] INFO bbae618a-fb70-11eb-856a-0242ac110004-fiNWCoaq-R92=3TN.}J8v token generate success token=MTYyODc3NDcxNy41NzA0Nzk5OmJiYWU2MThhLWZiNzAtMTFlYi04NTZhLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  21:24:48.514 [dbservice2] INFO aa5542be-fb70-11eb-8ece-0242ac110004-hPlvogHR-K>5beft3ioYy token generate success token=MTYyODc3NDY4OC41MTQzNDQ1OmFhNTU0MmJlLWZiNzAtMTFlYi04ZWNlLTAyNDJhYzE
  21:24:50.373 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×38)
  21:24:50.521 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  21:24:50.667 [redisservice2] INFO redis write success  (×80)
  21:24:50.800 [webservice1] INFO complete information: {'uuid': 'ac09c094-fb70-11eb-aacb-0242ac110003', 'user_id': 'TrtKhHmF'}  (×43)
  21:24:51.016 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×36)
  21:24:51.079 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×42)
  21:24:51.194 [redisservice1] INFO service accept, status_code: 200  (×41)
  21:24:51.401 [dbservice1] INFO ac09c094-fb70-11eb-aacb-0242ac110003-TrtKhHmF-DGj3iJ>o8x-K token generate success token=MTYyODc3NDY5MS40MDA5MjQ0OmFjMDljMDk0LWZiNzAtMTFlYi1hYWNiLTAyNDJhYzE
  21:24:51.961 [redisservice2] INFO service accept, status_code: 200  (×40)
  21:24:54.083 [mobservice2] INFO info adea5d06-fb70-11eb-a487-0242ac110004:GqOpyFdr write success
  21:24:56.451 [mobservice2] INFO info af4f9dfa-fb70-11eb-9bd5-0242ac110004:AkMRXwoH write success  (×2)
  21:24:58.308 [dbservice2] INFO b047509a-fb70-11eb-a880-0242ac110004-sNQUnOaq-YXf&B76#)l(Z token generate success token=MTYyODc3NDY5OC4zMDc4NDM0OmIwNDc1MDlhLWZiNzAtMTFlYi1hODgwLTAyNDJhYzE
  21:25:00.550 [mobservice1] INFO info b1bd2ea4-fb70-11eb-82d0-0242ac110003:GYmWSxyu write success
  21:25:02.731 [dbservice2] INFO b2de6a96-fb70-11eb-9158-0242ac110003-vLPzKelQ-H:yjVplx2YI= token generate success token=MTYyODc3NDcwMi43MzEwODM6YjJkZTZhOTYtZmI3MC0xMWViLTkxNTgtMDI0MmFjMTE
  21:25:05.044 [mobservice1] INFO info b47122b8-fb70-11eb-afde-0242ac110003:zTZgRokc write success
  21:25:06.894 [mobservice1] INFO info b58bbbfe-fb70-11eb-bf21-0242ac110004:QSUqdTsv write success
  21:25:08.749 [dbservice1] INFO b6717cb6-fb70-11eb-b8ac-0242ac110003-QSUqdTsv-er_ATbj}/nc7 token generate success token=MTYyODc3NDcwOC43NDkxNjQ4OmI2NzE3Y2I2LWZiNzAtMTFlYi1iOGFjLTAyNDJhYzE
  21:25:11.431 [mobservice1] INFO info b8369338-fb70-11eb-84d7-0242ac110003:rJyVYctH write success
  21:25:14.102 [dbservice1] INFO b9a2cb1a-fb70-11eb-bcbc-0242ac110004-NhtsWobx->YgS8K?XxrDn token generate success token=MTYyODc3NDcxNC4xMDE3MjQ2OmI5YTJjYjFhLWZiNzAtMTFlYi1iY2JjLTAyNDJhYzE
  21:25:16.591 [mobservice2] INFO info bb4af06e-fb70-11eb-a89b-0242ac110003:PKIhxRvi write success
  21:25:19.372 [dbservice2] INFO bcb954e0-fb70-11eb-857c-0242ac110004-tWbvgBRJ-7w.m!4bxPMaT token generate success token=MTYyODc3NDcxOS4zNzIyNzI6YmNiOTU0ZTAtZmI3MC0xMWViLTg1N2MtMDI0MmFjMTE
  21:25:21.537 [mobservice1] INFO info be3f90fe-fb70-11eb-abe7-0242ac110004:lGNiksWZ write success
  21:25:24.333 [dbservice2] INFO bfbb86a4-fb70-11eb-b3c0-0242ac110004-GwpUdJLR-<=#>pyVh.A$d token generate success token=MTYyODc3NDcyNC4zMzMzMDIzOmJmYmI4NmE0LWZiNzAtMTFlYi1iM2MwLTAyNDJhYzE
  21:25:26.733 [dbservice2] INFO c12f5cb8-fb70-11eb-a284-0242ac110004-dtYZahVu-L-(wot&?xVCf token generate success token=MTYyODc3NDcyNi43MzI3MjEzOmMxMmY1Y2I4LWZiNzAtMTFlYi1hMjg0LTAyNDJhYzE
  21:25:29.068 [mobservice1] INFO info c2bb7a58-fb70-11eb-b2ae-0242ac110003:ImYCctrK write success
  21:25:31.409 [dbservice1] INFO c3ebcc48-fb70-11eb-991f-0242ac110003-ThPbGWEy-l)3uy8DdN:IG token generate success token=MTYyODc3NDczMS40MDg4MDY6YzNlYmNjNDgtZmI3MC0xMWViLTk5MWYtMDI0MmFjMTE
  21:25:33.851 [mobservice2] INFO info c599be06-fb70-11eb-b200-0242ac110003:vfxYGPRM write success
  21:25:36.676 [mobservice1] INFO info c742e5de-fb70-11eb-94fe-0242ac110003:McHWnbKA write success
  21:25:45.353 [dbservice1] INFO cc3ab684-fb70-11eb-ac1d-0242ac110003-FAmtCcIX-WbpwIhFy&DB@ token generate success token=MTYyODc3NDc0NS4zNTI5MzcyOmNjM2FiNjg0LWZiNzAtMTFlYi1hYzFkLTAyNDJhYzE

## p0775
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-23T19:36:06.315Z
```
{"timestamp":1732390566315303700,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-x6bhs","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-23 19:36:06.315  INFO 7 --- [ool-6-thread-11] o.apache.http.impl.execchain.RetryExec   : Retrying request to {}->unix://localhost:80"}
```
Same service, the 2 minutes before (oldest first):
  19:36:05.273 [queue-master] 2024-11-23 19:36:05.273 INFO 7 --- [pool-6-thread-9] w.weave.socks.queuemaster.DockerSpawner : Spawning new container
  19:36:05.273 [queue-master] 2024-11-23 19:36:05.273 INFO 7 --- [pool-6-thread-9] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×3)
  19:36:05.273 [queue-master] 2024-11-23 19:36:05.273 INFO 7 --- [pool-6-thread-9] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×3)
  19:36:05.274 [queue-master] 2024-11-23 19:36:05.274 ERROR 7 --- [pool-6-thread-9] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.
  19:36:05.915 [queue-master] Received shipment task: 67422e8c48485600016b1d87  (×2)
  19:36:05.915 [queue-master] 2024-11-23 19:36:05.915 INFO 7 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×2)
  19:36:05.915 [queue-master] 2024-11-23 19:36:05.915 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×4)
  19:36:05.915 [queue-master] 2024-11-23 19:36:05.915 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×3)
  19:36:05.916 [queue-master] 2024-11-23 19:36:05.916 ERROR 7 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.
All services, 30 seconds either side (sampled):
  19:35:36.932 [catalogue] ts=2024-11-23T19:35:36Z caller=logging.go:85 method=Health result=2 took=27.106µs  (×40)
  19:35:37.144 [front-end] Sent cookies.  (×60)
  19:35:37.630 [front-end] Posting Customer: {"username":"nexTIWCMp","password":"YvhsBlNtFo","email":"nexTIWCMp@gmail.com","firstName":"nexTIWCMp","lastName":"nexTIWCMp"}
  19:35:37.711 [front-end] POST /cart 201 - ms - -  (×60)
  19:35:38.849 [front-end] GET Request to: http://user/customers/67422e7948485600016b1d5a/addresses  (×108)
  19:35:38.898 [queue-master] Received shipment task: 67422e7948485600016b1d5a  (×50)
  19:35:39.776 [front-end] Posting Customer: {"username":"PRjvUGWxvE","password":"Rdmger","email":"PRjvUGWxvE@gmail.com","firstName":"PRjvUGWxvE","lastName":"PRjvUGWxvE"}
  19:35:44.899 [orders] 2024-11-23 19:35:44.898 INFO [orders,cc59615ba1529670,7fef7ab42b1f9b8f,false] 7 --- [p-nio-80-exec-4] w.w.s.o.controllers.OrdersController : Sending payment req  (×48)
  19:35:45.583 [front-end] Order response: {"id":"67422e914ca85a00070c5430","customerId":"67422e7e48485600016b1d63","customer":{"id":null,"firstName":"WxNdfLHlOyAvCm","lastName":"WxNdfLHl
  19:35:48.184 [front-end] Order response: {"statusCode":201,"body":{"id":"67422e944ca85a00070c5433","customerId":"67422e7e48485600016b1d64","customer":{"id":null,"firstName":"HfUQlIQhJJN
  19:35:51.479 [front-end] Received response: "{\"firstName\":\"IKiFvUFlr\",\"lastName\":\"IKiFvUFlr\",\"username\":\"IKiFvUFlr\",\"id\":\"67422e8948485600016b1d76\",\"_links\":{\"address
  19:35:53.372 [front-end] Received response: "{\"firstName\":\"kmHUGHcEp\",\"lastName\":\"kmHUGHcEp\",\"username\":\"kmHUGHcEp\",\"id\":\"67422e8048485600016b1d65\",\"_links\":{\"address
  19:35:56.212 [front-end] Order response: {"statusCode":201,"body":{"id":"67422e9c4ca85a00070c5438","customerId":"67422e8948485600016b1d7b","customer":{"id":null,"firstName":"kCkxUlIJXxU
  19:35:57.720 [queue-master] 2024-11-23 19:35:57.720 INFO 7 --- [pool-6-thread-3] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×27)
  19:35:59.458 [front-end] Posting Customer: {"username":"vBHifJDnlFNGyp","password":"VHZJBFp","email":"vBHifJDnlFNGyp@gmail.com","firstName":"vBHifJDnlFNGyp","lastName":"vBHifJDnlFNGyp"}
  19:36:02.389 [front-end] Posting Customer: {"username":"UicwhIUGMgxjcVY","password":"dteHIFm","email":"UicwhIUGMgxjcVY@gmail.com","firstName":"UicwhIUGMgxjcVY","lastName":"UicwhIUGMgxjc
  19:36:03.626 [front-end] Order response: {"statusCode":201,"body":{"id":"67422ea34ca85a00070c5440","customerId":"67422e8e48485600016b1d8d","customer":{"id":null,"firstName":"xThKKBHetlv
  19:36:05.225 [front-end] Received response: "{\"firstName\":\"evImseh\",\"lastName\":\"evImseh\",\"username\":\"evImseh\",\"id\":\"67422e9348485600016b1d9c\",\"_links\":{\"addresses\":{
  19:36:06.317 [front-end] Order response: {"id":"67422ea64ca85a00070c5444","customerId":"67422e9148485600016b1d96","customer":{"id":null,"firstName":"CunlrvWNijzHc","lastName":"CunlrvWNi
  19:36:09.780 [front-end] Received response: "{\"firstName\":\"DEeMbplidUb\",\"lastName\":\"DEeMbplidUb\",\"username\":\"DEeMbplidUb\",\"id\":\"67422e8d48485600016b1d88\",\"_links\":{\"a
  19:36:12.778 [front-end] Received response: "{\"firstName\":\"dnCTkOACppTL\",\"lastName\":\"dnCTkOACppTL\",\"username\":\"dnCTkOACppTL\",\"id\":\"67422e9748485600016b1daf\",\"_links\":{
  19:36:13.565 [front-end] Posting Customer: {"username":"lcWkUCFwLxf","password":"VBrImVQSmv","email":"lcWkUCFwLxf@gmail.com","firstName":"lcWkUCFwLxf","lastName":"lcWkUCFwLxf"}
  19:36:16.610 [front-end] Received response: "{\"firstName\":\"jxOAJsX\",\"lastName\":\"jxOAJsX\",\"username\":\"jxOAJsX\",\"id\":\"67422e9f48485600016b1dc9\",\"_links\":{\"addresses\":{
  19:36:17.837 [user] ts=2024-11-23T19:36:17.837185869Z caller=middlewares.go:46 method=Register username=IZcOc email=IZcOc@gmail.com took=4.571792ms
  19:36:19.686 [front-end] Order response: {"id":"67422eb34ca85a00070c5454","customerId":"67422ea248485600016b1dd1","customer":{"id":null,"firstName":"UicwhIUGMgxjcVY","lastName":"UicwhIU
  19:36:24.476 [front-end] Received response: "{\"firstName\":\"ZucDI\",\"lastName\":\"ZucDI\",\"username\":\"ZucDI\",\"id\":\"67422ea648485600016b1ddd\",\"_links\":{\"addresses\":{\"href
  19:36:26.711 [user] ts=2024-11-23T19:36:26.711859048Z caller=middlewares.go:46 method=Register username=EipWB email=EipWB@gmail.com took=5.36658ms
  19:36:29.249 [front-end] Received response: "{\"firstName\":\"zCSdybjsVr\",\"lastName\":\"zCSdybjsVr\",\"username\":\"zCSdybjsVr\",\"id\":\"67422ea848485600016b1de5\",\"_links\":{\"addr
  19:36:31.456 [user] ts=2024-11-23T19:36:31.456840188Z caller=middlewares.go:46 method=Register username=jwqCUAGUY email=jwqCUAGUY@gmail.com took=4.602022ms

## p0468
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:09:59.074Z
```
{"timestamp":1732349399074541600,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"_embedded\\\":{\\\"card\\\":[{\\\"longNum\\\":\\\"123123321\\\",\\\"expires\\\":\\\"1232\\\",\\\"ccv\\\":\\\"123\\\",\\\"id\\\":\\\"67418dcda437380001deef33\\\",\\\"_links\\\":{\\\"card\\\":{\\\"href\\\":\\\"http://user/cards/67418dcda437380001deef33\\\"},\\\"self\\\":{\\\"href\\\":\\\"http://user/cards/67418dcda437380001deef33\\\"}}}]}}\\n\""}
```
Same service, the 2 minutes before (oldest first):
  08:09:58.845 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418dc5a437380001deef1c\",\"_links\":{\"
  08:09:58.845 [front-end] [ undefined, undefined ]
  08:09:58.845 [front-end] Posting Order: {"customer":"http://user/customers/67418dbba437380001deeef4","address":"http://user/addresses/67418dc5a437380001deef1b","card":"http://user/cards
  08:09:58.875 [front-end] Order response: {"statusCode":201,"body":{"id":"67418dd63f77060008864efb","customerId":"67418dbba437380001deeef4","customer":{"id":null,"firstName":"hPpoAo","la
  08:09:58.875 [front-end] Order response: {"id":"67418dd63f77060008864efb","customerId":"67418dbba437380001deeef4","customer":{"id":null,"firstName":"hPpoAo","lastName":"hPpoAo","usernam
  08:09:58.877 [front-end] POST /orders 201 - ms - -
  08:09:58.943 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418dcfa437380001deef3a"}
  08:09:58.954 [front-end] POST /addresses 200 - ms - -
  08:09:58.962 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67418dcfa437380001deef3a"}
  08:09:58.971 [front-end] POST /cards 200 - ms - -
  08:09:59.021 [front-end] Attempting to delete cart for user: 67418dcfa437380001deef3a
  08:09:59.036 [front-end] User cart deleted with status: 202
  08:09:59.038 [front-end] DELETE /cart 202 - ms - -
  08:09:59.045 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}
  08:09:59.053 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
  08:09:59.053 [front-end] POST to carts: http://carts/carts/67418dcfa437380001deef3a/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}
  08:09:59.055 [front-end] Request received with body: {}
  08:09:59.065 [front-end] Received response: "{\"firstName\":\"nSnRMsZHmp\",\"lastName\":\"nSnRMsZHmp\",\"username\":\"nSnRMsZHmp\",\"id\":\"67418dc3a437380001deef14\",\"_links\":{\"addr
  08:09:59.065 [front-end] GET Request to: http://user/customers/67418dc3a437380001deef14/addresses  (×2)
All services, 30 seconds either side (sampled):
  08:09:29.078 [front-end] Received response: "{\"firstName\":\"GGivTGV\",\"lastName\":\"GGivTGV\",\"username\":\"GGivTGV\",\"id\":\"67418d9fa437380001deeea1\",\"_links\":{\"addresses\":{
  08:09:29.107 [orders] 2024-11-23 08:09:29.107 INFO [orders,8d55a4c8210ed253,41a41d59687b8b42,false] 8 --- [p-nio-80-exec-1] w.w.s.o.controllers.OrdersController : Received payment re  (×54)
  08:09:29.142 [front-end] GET /catalogue 200 - ms - -  (×63)
  08:09:29.803 [catalogue] ts=2024-11-23T08:09:29Z caller=logging.go:62 method=Get id=3395a43e-2d88-40de-b95f-e00e1502085b sock=3395a43e-2d88-40de-b95f-e00e1502085b err=null took=4.57368m  (×3)
  08:09:30.888 [front-end] Order response: {"id":"67418dba3f77060008864edf","customerId":"67418da0a437380001deeea7","customer":{"id":null,"firstName":"OZypdwngfo","lastName":"OZypdwngfo",
  08:09:31.159 [front-end] Merging carts for customer id: 67418dbba437380001deeef3 and session id: VDhZWP3LO2f5pVmZ9ZLtzAOQTiQwpc1F  (×57)
  08:09:31.747 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×7)
  08:09:31.894 [carts] 2024-11-23 08:09:31.894 INFO [carts,e4bd222ec8f2ffa7,2edacb459f1eeb31,false] 7 --- [-nio-80-exec-12] w.w.s.cart.controllers.CartsController : Merge carts reques  (×28)
  08:09:35.574 [front-end] Order response: {"id":"67418dbf3f77060008864ee3","customerId":"67418db1a437380001deeedc","customer":{"id":null,"firstName":"svekSMrfTMP","lastName":"svekSMrfTMP
  08:09:38.221 [front-end] Posting Customer: {"username":"lGhiI","password":"VYWEbMED","email":"lGhiI@gmail.com","firstName":"lGhiI","lastName":"lGhiI"}
  08:09:39.669 [front-end] Posting Customer: {"username":"nSnRMsZHmp","password":"DIIZcXMxuO","email":"nSnRMsZHmp@gmail.com","firstName":"nSnRMsZHmp","lastName":"nSnRMsZHmp"}
  08:09:41.826 [front-end] Order response: {"statusCode":201,"body":{"id":"67418dc53f77060008864ee7","customerId":"67418db4a437380001deeee0","customer":{"id":null,"firstName":"YjqEdt","la
  08:09:46.583 [front-end] Order response: {"id":"67418dca3f77060008864ee9","customerId":"67418dbda437380001deeefb","customer":{"id":null,"firstName":"fHRKG","lastName":"fHRKG","username"
  08:09:48.341 [front-end] Received response: "{\"firstName\":\"gRjKMahKOhsCut\",\"lastName\":\"gRjKMahKOhsCut\",\"username\":\"gRjKMahKOhsCut\",\"id\":\"67418dbca437380001deeefa\",\"_lin
  08:09:50.404 [front-end] Received response: "{\"firstName\":\"iZxmprQJBS\",\"lastName\":\"iZxmprQJBS\",\"username\":\"iZxmprQJBS\",\"id\":\"67418db4a437380001deeedf\",\"_links\":{\"addr
  08:09:52.540 [front-end] Order response: {"statusCode":201,"body":{"id":"67418dd03f77060008864ef1","customerId":"67418db8a437380001deeeee","customer":{"id":null,"firstName":"ecKrrWNwyZC
  08:09:55.525 [front-end] Posting Customer: {"username":"nnIBp","password":"tBKEsOmVDC","email":"nnIBp@gmail.com","firstName":"nnIBp","lastName":"nnIBp"}
  08:09:56.340 [front-end] Received response: "{\"firstName\":\"DFebGSNoA\",\"lastName\":\"DFebGSNoA\",\"username\":\"DFebGSNoA\",\"id\":\"67418dbba437380001deeef9\",\"_links\":{\"address
  08:09:57.592 [front-end] Order response: {"id":"67418dd53f77060008864ef9","customerId":"67418dc9a437380001deef27","customer":{"id":null,"firstName":"CKNwrDASkluiTBc","lastName":"CKNwrDA
  08:09:59.275 [front-end] Received response: "{\"firstName\":\"WLpvn\",\"lastName\":\"WLpvn\",\"username\":\"WLpvn\",\"id\":\"67418dc2a437380001deef10\",\"_links\":{\"addresses\":{\"href
  08:10:00.359 [user] ts=2024-11-23T08:10:00.359440552Z caller=middlewares.go:46 method=Register username=raOgiaeI email=raOgiaeI@gmail.com took=2.251551ms
  08:10:05.895 [front-end] Order response: {"id":"67418ddd3f77060008864f00","customerId":"67418dc8a437380001deef22","customer":{"id":null,"firstName":"WtWQlkQHf","lastName":"WtWQlkQHf","u
  08:10:09.138 [front-end] Received response: "{\"firstName\":\"ujebDhxthEnGm\",\"lastName\":\"ujebDhxthEnGm\",\"username\":\"ujebDhxthEnGm\",\"id\":\"67418dcda437380001deef31\",\"_links\
  08:10:09.840 [user] ts=2024-11-23T08:10:09.839814813Z caller=middlewares.go:46 method=Register username=LtEfnxd email=LtEfnxd@gmail.com took=2.698948ms
  08:10:12.744 [front-end] Posting Customer: {"username":"IPeOyJxAM","password":"tvdVkPzc","email":"IPeOyJxAM@gmail.com","firstName":"IPeOyJxAM","lastName":"IPeOyJxAM"}
  08:10:14.772 [front-end] Order response: {"id":"67418de63f77060008864f08","customerId":"67418dd3a437380001deef42","customer":{"id":null,"firstName":"nnIBp","lastName":"nnIBp","username"
  08:10:19.567 [front-end] Received response: "{\"firstName\":\"raOgiaeI\",\"lastName\":\"raOgiaeI\",\"username\":\"raOgiaeI\",\"id\":\"67418dd8a437380001deef53\",\"_links\":{\"addresses\
  08:10:22.543 [front-end] Received response: "{\"firstName\":\"OhhljiktzNAy\",\"lastName\":\"OhhljiktzNAy\",\"username\":\"OhhljiktzNAy\",\"id\":\"67418dd5a437380001deef49\",\"_links\":{
  08:10:24.594 [front-end] Received response: "{\"firstName\":\"fYEGqxNrAeKyuNq\",\"lastName\":\"fYEGqxNrAeKyuNq\",\"username\":\"fYEGqxNrAeKyuNq\",\"id\":\"67418ddca437380001deef5d\",\"_
  08:10:26.068 [front-end] Order response: {"id":"67418df23f77060008864f12","customerId":"67418de1a437380001deef6c","customer":{"id":null,"firstName":"LtEfnxd","lastName":"LtEfnxd","usern

## p0798
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-08T08:40:39.502Z
```
{"timestamp":1733647239502526200,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-f2x5m","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-08 08:40:39.502  INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl  : startingPlaceId : nanjingendPlaceId : shanghai"}
```
Same service, the 2 minutes before (oldest first):
  08:40:38.756 [ts-basic-service] 2024-12-08 08:40:38.755 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha
  08:40:38.759 [ts-basic-service] 2024-12-08 08:40:38.758 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai
  08:40:38.759 [ts-basic-service] 2024-12-08 08:40:38.758 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3
  08:40:38.759 [ts-basic-service] 2024-12-08 08:40:38.758 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4
  08:40:38.772 [ts-basic-service] 2024-12-08 08:40:38.772 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×5)
  08:40:38.795 [ts-basic-service] 2024-12-08 08:40:38.795 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×4)
  08:40:39.469 [ts-basic-service] 2024-12-08 08:40:39.469 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  08:40:39.473 [ts-basic-service] 2024-12-08 08:40:39.472 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
  08:40:39.475 [ts-basic-service] 2024-12-08 08:40:39.475 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa
  08:40:39.483 [ts-basic-service] 2024-12-08 08:40:39.482 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  08:40:39.489 [ts-basic-service] 2024-12-08 08:40:39.489 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  08:40:39.489 [ts-basic-service] 2024-12-08 08:40:39.489 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693
  08:40:39.496 [ts-basic-service] 2024-12-08 08:40:39.496 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
All services, 30 seconds either side (sampled):
  08:40:09.576 [ts-train-mongo] {"t":{"$date":"2024-12-08T08:40:09.576+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364720
  08:40:09.915 [ts-station-mongo] {"t":{"$date":"2024-12-08T08:40:09.915+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364720
  08:40:11.638 [ts-assurance-mongo] {"t":{"$date":"2024-12-08T08:40:11.638+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364721
  08:40:12.818 [ts-basic-service] 2024-12-08 08:40:12.818 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×63)
  08:40:12.877 [ts-price-service] 2024-12-08 08:40:12.876 INFO 1 --- [io-16579-exec-4] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: 0b23bd3e-876a-4af3-b92  (×16)
  08:40:12.924 [ts-basic-service] 2024-12-08 08:40:12.924 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×8)
  08:40:12.990 [ts-seat-service] 2024-12-08 08:40:12.990 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×32)
  08:40:13.071 [ts-seat-service] 2024-12-08 08:40:13.071 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×16)
  08:40:15.284 [ts-auth-service] 2024-12-08 08:40:15.284 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default  (×2)
  08:40:15.869 [ts-travel2-service] 2024-12-08 08:40:15.868 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×3)
  08:40:26.048 [ts-basic-service] 2024-12-08 08:40:26.047 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×3)
  08:40:28.780 [ts-seat-service] 2024-12-08 08:40:28.779 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
  08:40:30.992 [ts-auth-service] 2024-12-08 08:40:30.992 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.access.expression.method.DefaultMethodS  (×2)
  08:40:33.646 [ts-travel-service] 2024-12-08 08:40:33.646 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×2)
  08:40:33.702 [ts-basic-service] 2024-12-08 08:40:33.702 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×3)
  08:40:33.777 [ts-order-service] 2024-12-08 08:40:33.777 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024  (×2)
  08:40:33.899 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:40:33 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 339 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×4)
  08:40:37.296 [ts-auth-service] 2024-12-08 08:40:37.295 INFO 1 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext  (×2)
  08:40:42.286 [ts-auth-service] 2024-12-08 08:40:42.286 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:33}] to ts-auth-m  (×2)
  08:40:43.494 [ts-travel-service] 2024-12-08 08:40:43.493 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Travel Service] Query TripResponse
  08:40:43.601 [ts-travel-service] 2024-12-08 08:40:43.601 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat
  08:40:49.879 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:40:49 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 5017 "-" "Mozilla/5.0 (Macintosh;
  08:40:51.389 [ts-auth-service] 2024-12-08 08:40:51.388 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.springframewo
  08:40:53.392 [ts-auth-service] 2024-12-08 08:40:53.392 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/vnd.spring-
  08:40:53.582 [ts-auth-service] 2024-12-08 08:40:53.582 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.boot.actuate.autoconfigure.Manageme
  08:40:59.988 [ts-auth-service] 2024-12-08 08:40:59.987 INFO 1 --- [ main] org.mongodb.driver.connection : Opened connection [connectionId{localValue:2, serverValue:35}] to ts-auth-mongo:27017
  08:41:04.889 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:41:04 +0800] "POST /api/v1/users/login HTTP/1.1" 200 146 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×4)
  08:41:07.011 [ts-travel-service] 2024-12-08 08:41:07.011 ERROR 1 --- [io-12346-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 

## p0643
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-admin-travel-service, 2024-12-07T20:28:42.978Z
```
{"timestamp":1733603322978171400,"container_name":"ts-admin-travel-service","pod_name":"ts-admin-travel-service-5c866595d6-5cqjp","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 20:28:42.977  INFO 1 --- [io-16114-exec-4] a.service.AdminTravelServiceImpl         : [Admin Travel Service][Get All Travels]"}
```
Same service, the 2 minutes before (oldest first):
  20:28:11.674 [ts-admin-travel-service] 2024-12-07 20:28:11.674 INFO 1 --- [io-16114-exec-4] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×12)
  20:28:12.581 [ts-admin-travel-service] 2024-12-07 20:28:12.580 INFO 1 --- [io-16114-exec-5] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×5)
  20:28:20.093 [ts-admin-travel-service] 2024-12-07 20:28:20.093 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]
  20:28:20.174 [ts-admin-travel-service] 2024-12-07 20:28:20.173 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)
All services, 30 seconds either side (sampled):
  20:28:13.264 [ts-auth-service] 2024-12-07 20:28:13.263 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×11)
  20:28:13.498 [ts-travel-service] 2024-12-07 20:28:13.498 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×54)
  20:28:13.599 [ts-route-service] 2024-12-07 20:28:13.599 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×28)
  20:28:20.174 [ts-admin-travel-service] 2024-12-07 20:28:20.173 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×4)
  20:28:22.050 [ts-basic-service] 2024-12-07 20:28:22.050 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×6)
  20:28:22.080 [ts-travel2-service] 2024-12-07 20:28:22.080 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×13)
  20:28:22.130 [ts-seat-service] 2024-12-07 20:28:22.130 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×24)
  20:28:22.180 [ts-travel2-service] 2024-12-07 20:28:22.180 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×26)
  20:28:24.050 [ts-basic-service] 2024-12-07 20:28:24.050 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×6)
  20:28:24.262 [ts-seat-service] 2024-12-07 20:28:24.262 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×5)
  20:28:24.354 [ts-travel-service] 2024-12-07 20:28:24.354 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×6)
  20:28:24.423 [ts-preserve-other-service] 2024-12-07 20:28:24.423 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Check Account Security] Checking....
  20:28:24.459 [ts-security-service] 2024-12-07 20:28:24.458 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service][Get Security Config Info]
  20:28:24.494 [ts-preserve-other-service] 2024-12-07 20:28:24.494 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Step 2] Complete
  20:28:24.850 [ts-preserve-other-service] 2024-12-07 20:28:24.850 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order
  20:28:24.904 [ts-basic-service] 2024-12-07 20:28:24.904 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×10)
  20:28:24.966 [ts-seat-service] 2024-12-07 20:28:24.966 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService distributeSeat] The request seat type is economyClass and the t
  20:28:24.977 [ts-preserve-other-service] 2024-12-07 20:28:24.977 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order Complete
  20:28:25.016 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:28:25 +0800] "POST /api/v1/preserveotherservice/preserveOther HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7
  20:28:31.088 [ts-order-other-service] 2024-12-07 20:28:31.088 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×3)
  20:28:31.762 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:28:31.762+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360331
  20:28:43.125 [ts-train-mongo] {"t":{"$date":"2024-12-07T20:28:43.125+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360332
  20:28:44.570 [ts-basic-service] 2024-12-07 20:28:44.570 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270  (×6)
  20:28:44.642 [ts-order-service] 2024-12-07 20:28:44.642 INFO 1 --- [io-12031-exec-9] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×18)
  20:28:44.802 [ts-order-service] 2024-12-07 20:28:44.802 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×3)
  20:28:52.187 [ts-travel-service] 2024-12-07 20:28:52.187 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×5)
  20:28:53.452 [ts-travel2-service] 2024-12-07 20:28:53.452 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×2)
  20:29:09.047 [ts-order-other-service] 2024-12-07 20:29:09.047 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=594119

## p0512
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:40:51.671Z
```
{"timestamp":1732358451671576600,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"Carts merged."}
```
Same service, the 2 minutes before (oldest first):
  10:40:51.261 [front-end] POST /cart 201 - ms - -
  10:40:51.291 [front-end] Request received with body: {}
  10:40:51.306 [front-end] Received response: "{\"firstName\":\"dhcyDB\",\"lastName\":\"dhcyDB\",\"username\":\"dhcyDB\",\"id\":\"6741b11ca437380001df4a47\",\"_links\":{\"addresses\":{\"h
  10:40:51.306 [front-end] GET Request to: http://user/customers/6741b11ca437380001df4a47/addresses  (×2)
  10:40:51.319 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"6741b
  10:40:51.319 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b121a437380001df4a5d\",\"_links\":{\"
  10:40:51.319 [front-end] [ undefined, undefined ]
  10:40:51.319 [front-end] Posting Order: {"customer":"http://user/customers/6741b11ca437380001df4a47","address":"http://user/addresses/6741b121a437380001df4a5c","card":"http://user/cards
  10:40:51.352 [front-end] Order response: {"statusCode":503,"body":"upstream connect error or disconnect/reset before headers. retried and the latest reset reason: remote connection fail
  10:40:51.352 [front-end] Order response: "upstream connect error or disconnect/reset before headers. retried and the latest reset reason: remote connection failure, transport failure re
  10:40:51.353 [front-end] POST /orders 503 - ms - -
  10:40:51.625 [front-end] Posting Customer: {"username":"PMMsVPkCBtB","password":"SgIrFoXQv","email":"PMMsVPkCBtB@gmail.com","firstName":"PMMsVPkCBtB","lastName":"PMMsVPkCBtB"}
  10:40:51.634 [front-end] { id: '6741b133a437380001df4a8d' }  (×2)
  10:40:51.634 [front-end] 6741b133a437380001df4a8d  (×2)
  10:40:51.634 [front-end] Merging carts for customer id: 6741b133a437380001df4a8d and session id: foGo7VwQrS0UE_Fi0K-LForTyddTphsx  (×2)
  10:40:51.658 [front-end] Posting Customer: {"username":"FoMnUsWRwtr","password":"ONCxQmw","email":"FoMnUsWRwtr@gmail.com","firstName":"FoMnUsWRwtr","lastName":"FoMnUsWRwtr"}
All services, 30 seconds either side (sampled):
  10:40:51.001 [user] ts=2024-11-23T10:40:51.001253583Z caller=middlewares.go:75 method=GetUsers id=6741b123a437380001df4a67 result=1 took=2.561807ms  (×127)
  10:40:51.057 [front-end] Request received with body: {}  (×34)
  10:40:51.115 [front-end] POST /cards 200 - ms - -  (×34)
  10:40:51.243 [carts] 2024-11-23 10:40:51.243 INFO [carts,d2c2e6abee6853ca,7c11b7f04a005886,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×15)
  10:40:51.650 [carts] 2024-11-23 10:40:51.644 INFO [carts,ce28dad27a7f1e73,b550dd7d93e87a62,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×20)
  10:40:52.715 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×4)
  10:40:54.042 [carts] 2024-11-23 10:40:54.042 INFO [carts,55279b5e8192e632,8c77ccf18a9ceab9,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.ItemsController : Did not find item.  (×19)
  10:40:55.439 [front-end] Posting Customer: {"username":"RWEKCzZbyoL","password":"eCgDEu","email":"RWEKCzZbyoL@gmail.com","firstName":"RWEKCzZbyoL","lastName":"RWEKCzZbyoL"}
  10:40:57.337 [orders] 2024-11-23 10:40:57.337 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+jso
  10:40:57.345 [orders] 2024-11-23 10:40:57.345 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[applicatio
  10:40:57.435 [orders] 2024-11-23 10:40:57.435 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicat
  10:40:57.546 [orders] 2024-11-23 10:40:57.546 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http
  10:40:58.821 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  10:40:59.450 [orders] 2024-11-23 10:40:59.450 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=
  10:40:59.540 [orders] 2024-11-23 10:40:59.540 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[app
  10:41:02.850 [front-end] Posting Customer: {"username":"oljxrbkvgRPchx","password":"KICnrSMycj","email":"oljxrbkvgRPchx@gmail.com","firstName":"oljxrbkvgRPchx","lastName":"oljxrbkvgRPch
  10:41:04.149 [orders] 2024-11-23 10:41:04.149 INFO [orders,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering w
  10:41:06.939 [orders] 2024-11-23 10:41:06.843 INFO [orders,,,] 7 --- [p-nio-80-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization starte
  10:41:08.897 [front-end] Received response: "{\"firstName\":\"FoMnUsWRwtr\",\"lastName\":\"FoMnUsWRwtr\",\"username\":\"FoMnUsWRwtr\",\"id\":\"6741b133a437380001df4a8e\",\"_links\":{\"a
  10:41:09.781 [front-end] Posting Customer: {"username":"gzAwltOvrAOlwZ","password":"mvbfevmrG","email":"gzAwltOvrAOlwZ@gmail.com","firstName":"gzAwltOvrAOlwZ","lastName":"gzAwltOvrAOlwZ
  10:41:10.346 [queue-master] 2024-11-23 10:41:10.346 INFO 7 --- [ool-6-thread-24] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×18)
  10:41:10.951 [orders-db] {"t":{"$date":"2024-11-23T10:41:10.951+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:4145  (×10)
  10:41:11.658 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b14601dd390007094dcc","customerId":"6741b12ea437380001df4a7f","customer":{"id":null,"firstName":"vDSVmUfFkYR
  10:41:11.740 [front-end] Order response: {"id":"6741b14601dd390007094dcb","customerId":"6741b135a437380001df4a95","customer":{"id":null,"firstName":"oMOnLjzHZXUV","lastName":"oMOnLjzHZX
  10:41:11.746 [front-end] Order response: {"id":"6741b14601dd390007094dcd","customerId":"6741b133a437380001df4a8d","customer":{"id":null,"firstName":"PMMsVPkCBtB","lastName":"PMMsVPkCBtB
  10:41:13.508 [user] ts=2024-11-23T10:41:13.508595513Z caller=middlewares.go:46 method=Register username=AQxdn email=AQxdn@gmail.com took=2.184408ms
  10:41:15.043 [front-end] Order response: {"id":"6741b14a01dd390007094dd4","customerId":"6741b132a437380001df4a8a","customer":{"id":null,"firstName":"mfkgXqTHaTye","lastName":"mfkgXqTHaT
  10:41:17.757 [front-end] Received response: "{\"firstName\":\"RPAyWJFRkAtx\",\"lastName\":\"RPAyWJFRkAtx\",\"username\":\"RPAyWJFRkAtx\",\"id\":\"6741b138a437380001df4aa1\",\"_links\":{
  10:41:20.018 [front-end] Received response: "{\"firstName\":\"qqkRVDrhVVQ\",\"lastName\":\"qqkRVDrhVVQ\",\"username\":\"qqkRVDrhVVQ\",\"id\":\"6741b138a437380001df4aa2\",\"_links\":{\"a

## p0130
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:21:05.701Z
```
{"timestamp":1731907265701648100,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  05:21:05.073 [frontend] failed to retrieve ads  (×2)
  05:21:05.073 [frontend] request complete  (×6)
  05:21:05.146 [frontend] request started  (×5)
  05:21:05.146 [frontend] serving product page
  05:21:05.174 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14
  05:21:05.178 [frontend] adding to cart
  05:21:05.190 [frontend] view user cart  (×2)
  05:21:05.256 [frontend] placing order
  05:21:05.322 [frontend] order placed
All services, 30 seconds either side (sampled):
  05:20:36.094 [frontend] request started  (×311)
  05:20:36.103 [cartservice] GetCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121  (×252)
  05:20:36.130 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14  (×183)
  05:20:36.134 [frontend] adding to cart  (×31)
  05:20:36.172 [shippingservice] [GetQuote] received request  (×69)
  05:20:36.189 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="CAD"  (×2)
  05:20:36.212 [checkoutservice] payment went through (transaction_id: 7998f487-08b0-4a2d-b3a4-5c8d4f0c54ad)  (×8)
  05:20:36.217 [cartservice] EmptyCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121  (×8)
  05:20:36.226 [frontend] order placed  (×8)
  05:20:43.143 [frontend] setting currency  (×29)
  05:20:52.998 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"3102","nanos":711800148},"credit_card":{"credit_card_number":"4317888326303
  05:20:53.012 [checkoutservice] order confirmation email sent to "jstevens@example.org"
  05:20:55.028 [redis] 50:C 18 Nov 2024 05:20:55.027 * DB saved on disk
  05:20:56.363 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', 'OLJCESPC7Z', 'LS4PSXUNUM', 'L9ECAV7KIM']
  05:21:03.600 [checkoutservice] order confirmation email sent to "imcpherson@example.com"
  05:21:05.306 [paymentservice] Transaction processed: visa ending 6598 Amount: EUR1219.398496258  (×2)
  05:21:08.506 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="JPY"  (×3)
  05:21:08.571 [emailservice] A request to send order confirmation email to steven03@example.net has been received.
  05:21:16.961 [checkoutservice] order confirmation email sent to "michelebauer@example.com"
  05:21:25.742 [adservice] Tracing enabled but temporarily unavailable
  05:21:27.341 [adservice] Exception in thread "main" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000 at io.grpc.netty.NettyServer.start(NettyServer.java:333) at io.g
  05:21:28.553 [checkoutservice] order confirmation email sent to "lhernandez@example.com"

## p0223
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:50:01.934Z
```
{"timestamp":1731916201934068500,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  07:50:01.284 [frontend] request started  (×6)
  07:50:01.284 [frontend] setting currency  (×2)
  07:50:01.284 [frontend] request complete  (×6)
  07:50:01.287 [frontend] home  (×2)
  07:50:01.339 [frontend] ENV_PLATFORM is: aws  (×2)
  07:50:01.681 [frontend] view user cart
  07:50:01.897 [frontend] serving product page
All services, 30 seconds either side (sampled):
  07:49:31.963 [frontend] request started  (×320)
  07:49:31.971 [cartservice] GetCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×264)
  07:49:31.993 [adservice] received ad request (context_words=[accessories])  (×37)
  07:49:32.132 [frontend] home  (×30)
  07:49:32.163 [shippingservice] [GetQuote] completed request  (×73)
  07:49:32.349 [adservice] received ad request (context_words=[kitchen])  (×53)
  07:49:34.583 [adservice] received ad request (context_words=[footwear])  (×14)
  07:49:36.072 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="GBP"  (×3)
  07:49:36.098 [checkoutservice] payment went through (transaction_id: 58850fde-67a1-4e92-841d-7d0eae33f535)  (×11)
  07:49:36.102 [cartservice] EmptyCartAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4  (×11)
  07:49:36.112 [frontend] order placed  (×11)
  07:49:39.720 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="JPY"
  07:49:39.767 [emailservice] A request to send order confirmation email to david88@example.net has been received.
  07:49:47.613 [emailservice] A request to send order confirmation email to laurawarren@example.com has been received.
  07:49:55.546 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"226","nanos":30117644},"credit_card":{"credit_card_number":"491476321563867  (×2)
  07:49:55.560 [checkoutservice] order confirmation email sent to "qhinton@example.net"
  07:49:57.155 [paymentservice] Transaction processed: visa ending 7901 Amount: EUR76.19460417  (×2)
  07:50:02.587 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="TRY"  (×2)
  07:50:02.619 [emailservice] A request to send order confirmation email to taylorjames@example.org has been received.
  07:50:19.064 [checkoutservice] order confirmation email sent to "rsmith@example.com"
  07:50:29.665 [emailservice] A request to send order confirmation email to shelby84@example.net has been received.
  07:50:30.666 [checkoutservice] order confirmation email sent to "tbaker@example.org"
  07:50:31.471 [paymentservice] Transaction processed: visa ending 8186 Amount: USD213.880000000

## p0712
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-14T02:25:16.503Z
```
{"service":"redisservice1","message":"2021-08-14 02:25:16,503 | WARNING | 0.0.0.1 | redisservice1 | redis_helper.py -> get_value_from_redis -> 72 | 4e3a5f2d84b4d392 | 用户未扫描，请等待！, status_code: 300"}
```
Same service, the 2 minutes before (oldest first):
  02:25:11.381 [redisservice1] INFO redis write success  (×10)
  02:25:11.610 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×3)
  02:25:12.000 [redisservice1] INFO service accept, status_code: 200  (×5)
  02:25:13.414 [redisservice1] INFO redis读取信息成功, status_code: 200  (×2)
All services, 30 seconds either side (sampled):
  02:24:46.504 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×51)
  02:24:46.646 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×50)
  02:24:48.918 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×45)
  02:24:49.097 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×41)
  02:24:49.569 [dbservice2] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  02:24:51.566 [logservice2] ERROR uuid expired, invalid phone request
  02:24:51.811 [webservice1] INFO complete information: {'uuid': 'bfe3ca12-fc63-11eb-9e08-0242ac110003', 'user_id': 'mVtTqAor'}  (×44)
  02:24:52.152 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  02:24:52.538 [dbservice1] INFO bfe3ca12-fc63-11eb-9e08-0242ac110003-mVtTqAor-@bx5fml._>_I token generate success token=MTYyODg3OTA5Mi41MzgxMzI3OmJmZTNjYTEyLWZjNjMtMTFlYi05ZTA4LTAyNDJhYzE
  02:24:55.329 [dbservice1] INFO c1b8d9fe-fc63-11eb-8e7b-0242ac110004-tRLZzuQg-6=h^0Kp$%lJx token generate success token=MTYyODg3OTA5NS4zMjg5NDUyOmMxYjhkOWZlLWZjNjMtMTFlYi04ZTdiLTAyNDJhYzE
  02:24:58.226 [dbservice2] INFO c35bd4c8-fc63-11eb-b34d-0242ac110003-nBSDicYe-Xnmoyc%*g{)k token generate success token=MTYyODg3OTA5OC4yMjU4ODM1OmMzNWJkNGM4LWZjNjMtMTFlYi1iMzRkLTAyNDJhYzE
  02:25:00.846 [mobservice2] INFO info c52debc4-fc63-11eb-8caa-0242ac110003:TZitjmpu write success
  02:25:03.620 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  02:25:06.317 [mobservice2] INFO info c87bcd00-fc63-11eb-90ea-0242ac110004:ceZjduVy write success
  02:25:09.163 [mobservice2] INFO info ca241e14-fc63-11eb-ab39-0242ac110003:uxPlARkn write success
  02:25:12.496 [mobservice2] INFO info cc22f2c6-fc63-11eb-9d94-0242ac110003:SUYGNuEo write success
  02:25:15.261 [dbservice2] INFO cd83e88c-fc63-11eb-8ff6-0242ac110004-WVPTmDGM-P+m#ZGgNRh3= token generate success token=MTYyODg3OTExNS4yNjA5NjE4OmNkODNlODhjLWZjNjMtMTFlYi04ZmY2LTAyNDJhYzE
  02:25:17.745 [mobservice1] INFO info cf3713d4-fc63-11eb-891b-0242ac110003:jIBRSGcQ write success
  02:25:20.326 [mobservice2] INFO info d0d058cc-fc63-11eb-bc8d-0242ac110003:tBDHvTdf write success
  02:25:22.635 [mobservice2] INFO info d2357936-fc63-11eb-a836-0242ac110004:mCkaEIVe write success
  02:25:25.666 [dbservice1] INFO d3ca0e88-fc63-11eb-bfdc-0242ac110004-zZMHRjyN->TG12BRdz}ZU token generate success token=MTYyODg3OTEyNS42NjYwMTk6ZDNjYTBlODgtZmM2My0xMWViLWJmZGMtMDI0MmFjMTE
  02:25:28.032 [dbservice2] INFO d533bc56-fc63-11eb-8ce6-0242ac110003-HytkEBDf-z?M!i}>8wU$F token generate success token=MTYyODg3OTEyOC4wMzE4NjE6ZDUzM2JjNTYtZmM2My0xMWViLThjZTYtMDI0MmFjMTE
  02:25:30.455 [dbservice1] INFO d6a4efc4-fc63-11eb-b867-0242ac110004-zLGEjrhw-D*Rm7c>0WY.N token generate success token=MTYyODg3OTEzMC40NTQ3NTM6ZDZhNGVmYzQtZmM2My0xMWViLWI4NjctMDI0MmFjMTE
  02:25:33.427 [mobservice1] INFO info d89fc060-fc63-11eb-aa89-0242ac110003:LMIQcrtC write success
  02:25:35.674 [mobservice1] INFO info d9f450fc-fc63-11eb-abdf-0242ac110003:OMLuHZEe write success
  02:25:37.967 [dbservice1] INFO db223372-fc63-11eb-b164-0242ac110004-mHwMQugd-6@1g+F.Th7c& token generate success token=MTYyODg3OTEzNy45NjczMjY0OmRiMjIzMzcyLWZjNjMtMTFlYi1iMTY0LTAyNDJhYzE
  02:25:40.957 [dbservice1] INFO dcc5027c-fc63-11eb-ab7b-0242ac110003-WVPTmDGM-P+m#ZGgNRh3= token generate success token=MTYyODg3OTE0MC45NTc1ODY1OmRjYzUwMjdjLWZjNjMtMTFlYi1hYjdiLTAyNDJhYzE
  02:25:43.565 [mobservice1] INFO info de9bbe88-fc63-11eb-b0b7-0242ac110003:ohjceMiy write success
  02:25:46.427 [mobservice2] INFO info e051a6c0-fc63-11eb-aa45-0242ac110003:rtRkpsfM write success

## p0062
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-13T08:45:56.097Z
```
{"service":"redisservice1","message":"2021-08-13 08:45:56,097 | INFO | 0.0.0.1 | 172.17.0.4 | redisservice1 | 79a1ac4fb72d3540 | service refuse, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  08:45:52.800 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×5)
  08:45:52.838 [redisservice1] INFO redis write success  (×9)
  08:45:53.211 [redisservice1] INFO service accept, status_code: 200
  08:45:53.797 [redisservice1] INFO redis读取信息成功, status_code: 200  (×4)
  08:45:53.941 [redisservice1] INFO service refuse, status_code: 200
All services, 30 seconds either side (sampled):
  08:45:26.099 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×45)
  08:45:26.197 [dbservice1] INFO query = select passwards from username_table where user_name='bAyVlxfw'  (×33)
  08:45:26.415 [webservice1] INFO uuid: c008c6a8-fbcf-11eb-9528-0242ac110003 write redis successfully  (×45)
  08:45:26.579 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'c008c6a8-fbcf-11eb-9528-0242ac110003'}  (×50)
  08:45:26.834 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'c008c6a8-fbcf-11eb-9528-0242ac110003'}  (×45)
  08:45:26.925 [logservice2] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': 'c008c6a8-fbcf-11eb-9528-0242ac110003', 'user_id': 'KrEDTxFN'}  (×89)
  08:45:27.021 [webservice1] ERROR an error occurred in the downstream service  (×28)
  08:45:27.478 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'c0767036-fbcf-11eb-a2ba-0242ac110003'}  (×44)
  08:45:27.943 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  08:45:28.142 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×45)
  08:45:28.274 [mobservice2] INFO info c0fa923a-fbcf-11eb-b50f-0242ac110004:sXITPUpy write success
  08:45:33.243 [mobservice1] INFO info c3f1d476-fbcf-11eb-9487-0242ac110003:gKPfDFAT write success
  08:45:38.190 [mobservice2] INFO info c6e2da72-fbcf-11eb-a6b7-0242ac110004:bHxAGyOk write success
  08:45:41.189 [mobservice2] INFO info c8afa0b0-fbcf-11eb-a877-0242ac110004:jSevQlNq write success
  08:45:43.487 [mobservice1] INFO info ca09b388-fbcf-11eb-9c29-0242ac110004:yHBRGerA write success
  08:45:45.823 [mobservice1] INFO info cb763016-fbcf-11eb-a2dc-0242ac110003:ICpXWslJ write success
  08:45:48.975 [mobservice1] INFO info cd525ca2-fbcf-11eb-8efa-0242ac110003:COxkLyBN write success
  08:45:52.007 [mobservice1] INFO info cf06dc12-fbcf-11eb-bf1f-0242ac110003:jSevQlNq write success
  08:45:54.759 [dbservice1] INFO d0880516-fbcf-11eb-abf2-0242ac110003-NOmfIvPM-6W3hHD^pXQO< token generate success token=MTYyODgxNTU1NC43NTg2MDM4OmQwODgwNTE2LWZiY2YtMTFlYi1hYmYyLTAyNDJhYzE
  08:45:57.583 [mobservice1] INFO info d26cd6fe-fbcf-11eb-b1de-0242ac110004:PKIhxRvi write success
  08:46:00.087 [mobservice2] INFO info d3eadf80-fbcf-11eb-abf5-0242ac110004:QSUqdTsv write success
  08:46:02.734 [dbservice1] INFO d54d3ea4-fbcf-11eb-94c6-0242ac110003-dQcykLhj-Sn.w)Vyu7fB@ token generate success token=MTYyODgxNTU2Mi43MzM4MDc6ZDU0ZDNlYTQtZmJjZi0xMWViLTk0YzYtMDI0MmFjMTE
  08:46:04.618 [mobservice1] INFO info d6acbc02-fbcf-11eb-8d8d-0242ac110004:TIlYNQVq write success
  08:46:07.379 [mobservice1] INFO info d844af0c-fbcf-11eb-a4f4-0242ac110004:vPhcKXLl write success
  08:46:10.166 [dbservice1] INFO d9af9ef6-fbcf-11eb-8fce-0242ac110004-pawXhUZy-iZh{OmG>Ty._ token generate success token=MTYyODgxNTU3MC4xNjU3Nzg6ZDlhZjllZjYtZmJjZi0xMWViLThmY2UtMDI0MmFjMTE
  08:46:13.033 [mobservice2] INFO info dba2c4d6-fbcf-11eb-89b5-0242ac110003:HRlmyonZ write success  (×2)
  08:46:17.001 [mobservice1] INFO info de091fd6-fbcf-11eb-a208-0242ac110003:TZitjmpu write success
  08:46:19.944 [mobservice1] INFO info dfc6b4e6-fbcf-11eb-9c71-0242ac110003:GTqJKEWv write success
  08:46:23.156 [dbservice1] INFO e170ee6a-fbcf-11eb-8891-0242ac110004-AIKNYSvf-Ju*+9{fYn>Ti token generate success token=MTYyODgxNTU4My4xNTU5MTk6ZTE3MGVlNmEtZmJjZi0xMWViLTg4OTEtMDI0MmFjMTE
  08:46:26.060 [mobservice2] INFO info e35ce2d8-fbcf-11eb-8763-0242ac110003:vpXbgtCB write success

## p0108
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T05:09:47.383Z
```
{"timestamp":1731906587383922200,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-m2ddm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"AddItemAsync called with userId=c216dec4-2181-4773-8cc5-aa587ee59fcc, productId=L9ECAV7KIM, quantity=7"}
```
Same service, the 2 minutes before (oldest first):
  05:09:45.686 [cartservice] GetCartAsync called with userId=736a09b5-665e-4823-8520-b8602b0bdbff  (×15)
  05:09:46.242 [cartservice] AddItemAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add, productId=L9ECAV7KIM, quantity=10  (×3)
  05:09:46.390 [cartservice] EmptyCartAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add  (×2)
All services, 30 seconds either side (sampled):
  05:09:17.394 [frontend] request started  (×345)
  05:09:17.402 [cartservice] GetCartAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43  (×279)
  05:09:17.427 [adservice] received ad request (context_words=[footwear])  (×23)
  05:09:17.437 [cartservice] AddItemAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43, productId=L9ECAV7KIM, quantity=3  (×41)
  05:09:17.468 [shippingservice] [GetQuote] received request  (×93)
  05:09:17.825 [adservice] received ad request (context_words=[clothing, tops])  (×13)
  05:09:17.948 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"316","nanos":972079616},"credit_card":{"credit_card_number":"44731566095638  (×6)
  05:09:17.951 [shippingservice] [ShipOrder] received request  (×15)
  05:09:17.961 [emailservice] A request to send order confirmation email to christinaware@example.net has been received.
  05:09:18.637 [adservice] received ad request (context_words=[accessories])  (×35)
  05:09:18.724 [paymentservice] Transaction processed: visa ending 5289 Amount: JPY258141.112782864  (×4)
  05:09:19.693 [adservice] received ad request (context_words=[decor, home])  (×14)
  05:09:20.431 [emailservice] A request to send order confirmation email to garciajessica@example.com has been received.
  05:09:20.718 [frontend] ENV_PLATFORM is: aws  (×39)
  05:09:22.078 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×10)
  05:09:28.202 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"205","nanos":210123835},"credit_card":{"credit_card_number":"48097360046457  (×2)
  05:09:28.217 [checkoutservice] order confirmation email sent to "edwardslarry@example.com"
  05:09:30.671 [frontend] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
  05:09:30.692 [paymentservice] }
  05:09:31.202 [emailservice] A request to send order confirmation email to kramerkatherine@example.com has been received.
  05:09:39.812 [checkoutservice] order confirmation email sent to "janice63@example.net"
  05:09:46.382 [paymentservice] Transaction processed: visa ending 6282 Amount: EUR2592.65457790  (×3)
  05:09:46.446 [emailservice] A request to send order confirmation email to richard26@example.net has been received.
  05:09:49.026 [emailservice] A request to send order confirmation email to erin73@example.org has been received.
  05:09:52.127 [paymentservice] Transaction processed: visa ending 4346 Amount: USD673.830000000
  05:10:03.124 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '6E92ZMYYFZ']  (×2)
  05:10:08.815 [emailservice] A request to send order confirmation email to tracey70@example.net has been received.
  05:10:09.202 [checkoutservice] order confirmation email sent to "bryantshane@example.com"

## p0843
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-food-service, 2024-12-08T13:00:12.502Z
```
{"timestamp":1733662812502898400,"container_name":"ts-food-service","pod_name":"ts-food-service-669668c96d-x69rn","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-08 13:00:12.502  INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController     : [Food Service]Get the Get Food Request!"}
```
Same service, the 2 minutes before (oldest first):
  12:58:59.597 [ts-food-service] 2024-12-08 12:58:59.596 INFO 1 --- [io-18856-exec-4] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!  (×5)
  12:59:17.626 [ts-food-service] 2024-12-08 12:59:17.626 INFO 1 --- [io-18856-exec-8] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×4)
  12:59:17.626 [ts-food-service] 2024-12-08 12:59:17.626 INFO 1 --- [io-18856-exec-8] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×4)
  12:59:33.886 [ts-food-service] 2024-12-08 12:59:33.885 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  12:59:33.886 [ts-food-service] 2024-12-08 12:59:33.885 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345
  12:59:33.897 [ts-food-service] 2024-12-08 12:59:33.897 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  12:59:34.452 [ts-food-service] 2024-12-08 12:59:34.451 INFO 1 --- [io-18856-exec-1] foodsearch.controller.FoodController : [Food Service]Try to Create a FoodOrder!  (×2)
  12:59:34.456 [ts-food-service] 2024-12-08 12:59:34.456 INFO 1 --- [io-18856-exec-1] foodsearch.service.FoodServiceImpl : [Food-Service][AddFoodOrder] Success.  (×2)
All services, 30 seconds either side (sampled):
  12:59:42.862 [ts-admin-basic-info-service] 2024-12-08 12:59:42.862 INFO 1 --- [io-18767-exec-6] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×14)
  12:59:43.613 [ts-travel-service] 2024-12-08 12:59:43.613 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×54)
  12:59:43.653 [ts-basic-service] 2024-12-08 12:59:43.653 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×3)
  12:59:43.685 [ts-order-service] 2024-12-08 12:59:43.685 INFO 1 --- [io-12031-exec-7] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:00:00   (×9)
  12:59:43.743 [ts-seat-service] 2024-12-08 12:59:43.743 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×14)
  12:59:44.672 [ts-auth-service] 2024-12-08 12:59:44.671 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×22)
  12:59:48.199 [ts-travel2-service] 2024-12-08 12:59:48.199 INFO 1 --- [io-16346-exec-9] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×11)
  12:59:48.326 [ts-order-other-service] 2024-12-08 12:59:48.325 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×9)
  12:59:48.502 [ts-order-other-service] 2024-12-08 12:59:48.502 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×21)
  12:59:49.012 [ts-admin-basic-info-service] 2024-12-08 12:59:49.012 INFO 1 --- [io-18767-exec-7] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×11)
  12:59:49.968 [ts-seat-service] 2024-12-08 12:59:49.967 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×5)
  12:59:53.702 [ts-travel-service] 2024-12-08 12:59:53.702 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×3)
  12:59:54.142 [ts-basic-service] 2024-12-08 12:59:54.142 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：a3f256c1-0e  (×2)
  13:00:01.567 [ts-auth-service] 2024-12-08 13:00:01.566 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  13:00:11.433 [ts-travel-service] 2024-12-08 13:00:11.433 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×2)
  13:00:12.291 [ts-auth-mongo] {"t":{"$date":"2024-12-08T13:00:12.291+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366281
  13:00:12.914 [ts-travel2-mongo] {"t":{"$date":"2024-12-08T13:00:12.914+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366281
  13:00:16.052 [ts-consign-mongo] {"t":{"$date":"2024-12-08T13:00:16.052+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366281
  13:00:24.471 [ts-basic-service] 2024-12-08 13:00:24.471 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×2)
  13:00:29.923 [ts-consign-service] 2024-12-08 13:00:29.923 INFO 1 --- [io-16111-exec-5] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] f35b87c4-0fe5-463c-981e-  (×2)
  13:00:32.052 [ts-travel-service] 2024-12-08 13:00:32.052 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×4)
  13:00:38.966 [ts-admin-travel-service] 2024-12-08 13:00:38.966 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)
  13:00:39.677 [ts-preserve-service] 2024-12-08 13:00:39.677 INFO 1 --- [io-14568-exec-3] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security
  13:00:39.715 [ts-security-service] 2024-12-08 13:00:39.715 INFO 1 --- [io-11188-exec-3] security.service.SecurityServiceImpl : [Security Service][Get Security Config Info]
  13:00:39.740 [ts-preserve-service] 2024-12-08 13:00:39.740 INFO 1 --- [io-14568-exec-3] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] Check tickets num
  13:00:40.005 [ts-preserve-service] 2024-12-08 13:00:40.005 INFO 1 --- [io-14568-exec-3] preserve.service.PreserveServiceImpl : TripAllDetail:TripAllDetail(status=false, message=null, tripResponse
  13:00:40.114 [ts-seat-service] 2024-12-08 13:00:40.114 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService distributeSeat] The request seat type is economyClass and the t
  13:00:40.139 [ts-preserve-service] 2024-12-08 13:00:40.139 INFO 1 --- [io-14568-exec-3] preserve.service.PreserveServiceImpl : [Preserve Service][Add Assurance For Order]
  13:00:40.174 [ts-preserve-service] 2024-12-08 13:00:40.174 INFO 1 --- [io-14568-exec-3] preserve.service.PreserveServiceImpl : [Cancel Order Service][Get Order By Id]

## p0570
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-other-service, 2024-12-07T18:31:00.335Z
```
{"timestamp":1733596260335288300,"container_name":"ts-order-other-service","pod_name":"ts-order-other-service-746fccc88f-4lb46","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:00.334 ERROR 1 --- [io-12032-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalArgumentException: Invalid UUID string: ] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  18:30:53.723 [ts-order-other-service] 2024-12-07 18:30:53.723 INFO 1 --- [io-12032-exec-5] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×6)
  18:30:56.908 [ts-order-other-service] 2024-12-07 18:30:56.907 INFO 1 --- [io-12032-exec-6] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×3)
  18:30:56.912 [ts-order-other-service] 2024-12-07 18:30:56.911 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 24  (×3)
  18:30:57.100 [ts-order-other-service] 2024-12-07 18:30:57.099 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×5)
  18:30:58.183 [ts-order-other-service] 2024-12-07 18:30:58.182 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM
  18:30:58.185 [ts-order-other-service] 2024-12-07 18:30:58.185 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392
  18:31:00.320 [ts-order-other-service] 2024-12-07 18:31:00.319 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 
All services, 30 seconds either side (sampled):
  18:30:30.413 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T18:30:30.413+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359623
  18:30:32.090 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:30:32 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 500 210 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Apple
  18:30:37.744 [ts-travel2-service] 2024-12-07 18:30:37.744 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×79)
  18:30:37.803 [ts-price-service] 2024-12-07 18:30:37.802 INFO 1 --- [io-16579-exec-3] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×17)
  18:30:37.873 [ts-seat-service] 2024-12-07 18:30:37.873 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×35)
  18:30:37.925 [ts-travel2-service] 2024-12-07 18:30:37.925 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×22)
  18:30:40.449 [ts-travel2-service] 2024-12-07 18:30:40.449 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×12)
  18:30:40.593 [ts-order-other-service] 2024-12-07 18:30:40.593 INFO 1 --- [io-12032-exec-2] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×11)
  18:30:41.717 [ts-admin-basic-info-service] 2024-12-07 18:30:41.717 INFO 1 --- [io-18767-exec-3] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×7)
  18:30:42.403 [ts-food-service] 2024-12-07 18:30:42.403 INFO 1 --- [io-18856-exec-3] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×2)
  18:30:44.930 [ts-travel2-service] 2024-12-07 18:30:44.930 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×2)
  18:30:47.145 [ts-travel-service] 2024-12-07 18:30:47.145 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×17)
  18:30:47.230 [ts-order-service] 2024-12-07 18:30:47.230 INFO 1 --- [io-12031-exec-3] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×6)
  18:30:47.294 [ts-order-service] 2024-12-07 18:30:47.294 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×10)
  18:30:51.479 [ts-auth-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  18:30:54.486 [ts-auth-service] 2024-12-07 18:30:54.485 INFO 1 --- [ main] ationConfigEmbeddedWebApplicationContext : Refreshing org.springframework.boot.context.embedded.AnnotationConfigEmbed
  18:30:58.080 [ts-price-service] 2024-12-07 18:30:58.080 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×2)
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.872 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  18:31:04.698 [ts-seat-service] 2024-12-07 18:31:04.698 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  18:31:09.955 [ts-auth-service] 2024-12-07 18:31:09.954 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 12340 (http)
  18:31:11.722 [ts-seat-service] 2024-12-07 18:31:11.722 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×5)
  18:31:12.420 [ts-travel-service] 2024-12-07 18:31:12.420 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
  18:31:19.665 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:19 +0800] "POST /api/v1/users/login HTTP/1.1" 200 146 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×6)
  18:31:21.810 [ts-order-other-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  18:31:28.270 [ts-admin-travel-service] 2024-12-07 18:31:28.269 ERROR 1 --- [io-16114-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  18:31:29.947 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:31:29.947+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628

## p0069
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T09:01:10.343Z
```
{"service":"dbservice2","message":"2021-08-13 09:01:10,343 | ERROR | 0.0.0.2 | dbservice2 | db_helper.py -> sql_ano_prob -> 93 | f0fb900e4c532e8 | (pymysql.err.OperationalError) (1054, \"Unknown column 'system_data_time' in 'field list'\")[SQL: select service_name, system_data_time, system_cpu_utilization, system_memory_usage,system_disk_usage, disk_io_read_count, disk_io_write_count,system_network, network_io_read_count, network_io_…"}
```
Same service, the 2 minutes before (oldest first):
  09:01:02.135 [dbservice2] INFO query = select passwards from username_table where user_name='NWUBeIdk'  (×5)
  09:01:02.214 [dbservice2] INFO ed75d084-fbd1-11eb-86e6-0242ac110004-NWUBeIdk-FGOw@=Id6nPZ token generate success token=MTYyODgxNjQ2Mi4yMTM1NTk5OmVkNzVkMDg0LWZiZDEtMTFlYi04NmU2LTAyNDJhYzE
  09:01:02.853 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  09:01:02.853 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  09:01:02.990 [dbservice2] INFO ede8a866-fbd1-11eb-8fc7-0242ac110004-vNyVfPiM-TpEGNKCOH2L= token generate success token=MTYyODgxNjQ2Mi45ODk2MzA3OmVkZThhODY2LWZiZDEtMTFlYi04ZmM3LTAyNDJhYzE
  09:01:04.669 [dbservice2] INFO eee521a4-fbd1-11eb-8cb4-0242ac110004-rzupZVkA-Qd<YFATn8+k) token generate success token=MTYyODgxNjQ2NC42Njg1NDAyOmVlZTUyMWE0LWZiZDEtMTFlYi04Y2I0LTAyNDJhYzE
  09:01:09.561 [dbservice2] INFO f1dbc156-fbd1-11eb-a76a-0242ac110003-tcZveHsK-1gH80/=YeI}* token generate success token=MTYyODgxNjQ2OS41NjEwMzQ6ZjFkYmMxNTYtZmJkMS0xMWViLWE3NmEtMDI0MmFjMTE
  09:01:09.965 [dbservice2] INFO f2057064-fbd1-11eb-bd86-0242ac110003-HxQpIWMr-prs7#j4K0Dz1 token generate success token=MTYyODgxNjQ2OS45NjUxMzg3OmYyMDU3MDY0LWZiZDEtMTFlYi1iZDg2LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  09:00:40.373 [webservice1] INFO complete information: {'uuid': 'e0b9109a-fbd1-11eb-8366-0242ac110003', 'user_id': 'JHvRWiIh'}  (×48)
  09:00:40.585 [redisservice2] INFO redis write success  (×91)
  09:00:40.718 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': 'e0b9109a-fbd1-11eb-8366-0242ac110003', 'user_id': 'JHvRWiIh'}  (×93)
  09:00:40.860 [redisservice2] INFO service accept, status_code: 200  (×41)
  09:00:40.933 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×45)
  09:00:41.337 [mobservice1] INFO info e13afc2c-fbd1-11eb-9c87-0242ac110004:RkEDeABl write success
  09:00:41.568 [logservice2] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×44)
  09:00:42.594 [webservice1] INFO uuid: e21f4a58-fbd1-11eb-b2a2-0242ac110003 write redis successfully  (×47)
  09:00:46.751 [mobservice1] INFO info e4763ad2-fbd1-11eb-b94a-0242ac110004:Jcofhzdp write success
  09:00:48.146 [dbservice2] INFO e50cfb8e-fbd1-11eb-8330-0242ac110004-hLXtpSzb-KxJ1VOoDm#-l token generate success token=MTYyODgxNjQ0OC4xNDU2NzU3OmU1MGNmYjhlLWZiZDEtMTFlYi04MzMwLTAyNDJhYzE
  09:00:50.728 [dbservice2] INFO e68b9b82-fbd1-11eb-a978-0242ac110004-JKhDNmCb-yMn!G#EL?u18 token generate success token=MTYyODgxNjQ1MC43Mjc3MTQ1OmU2OGI5YjgyLWZiZDEtMTFlYi1hOTc4LTAyNDJhYzE
  09:00:53.302 [dbservice1] INFO e81053bc-fbd1-11eb-83cb-0242ac110003-xXiaofbu-2Yl&jd#+ApZV token generate success token=MTYyODgxNjQ1My4zMDE5MTM6ZTgxMDUzYmMtZmJkMS0xMWViLTgzY2ItMDI0MmFjMTE
  09:00:55.776 [dbservice1] INFO e9902fc8-fbd1-11eb-b950-0242ac110004-HRlmyonZ-m?/#r3VthEpK token generate success token=MTYyODgxNjQ1NS43NzU1OTc2OmU5OTAyZmM4LWZiZDEtMTFlYi1iOTUwLTAyNDJhYzE
  09:00:58.389 [dbservice2] INFO eb349e0e-fbd1-11eb-a7db-0242ac110004-tjrRfeJy-t5EnZ!FmiUq{ token generate success token=MTYyODgxNjQ1OC4zODk0NzU4OmViMzQ5ZTBlLWZiZDEtMTFlYi1hN2RiLTAyNDJhYzE
  09:01:01.092 [mobservice2] INFO info ecea6ce2-fbd1-11eb-afc8-0242ac110003:PvCnuEHJ write success
  09:01:03.880 [dbservice1] INFO ee5e9a12-fbd1-11eb-8d94-0242ac110004-LmHpecgO-{$XO7}iZEDzn token generate success token=MTYyODgxNjQ2My44ODAyNDc4OmVlNWU5YTEyLWZiZDEtMTFlYi04ZDk0LTAyNDJhYzE
  09:01:06.680 [mobservice2] INFO info f0405b40-fbd1-11eb-b4da-0242ac110004:LiESlVvW write success
  09:01:09.321 [mobservice2] INFO info f1dbc156-fbd1-11eb-a76a-0242ac110003:tcZveHsK write success  (×2)
  09:01:11.923 [webservice1] ERROR an error occurred in the downstream service  (×4)
  09:01:15.119 [mobservice2] INFO info f5482406-fbd1-11eb-8280-0242ac110003:SNyDIdeO write success
  09:01:17.628 [mobservice1] INFO info f6da4e84-fbd1-11eb-944b-0242ac110004:PtzZjByh write success
  09:01:20.114 [mobservice2] INFO info f8485fe0-fbd1-11eb-a241-0242ac110004:LVQPlZAt write success
  09:01:22.949 [dbservice2] INFO f9c12528-fbd1-11eb-97e6-0242ac110003-nRDMHcrY-vKd#<PJBsz+5 token generate success token=MTYyODgxNjQ4Mi45NDkwNDk3OmY5YzEyNTI4LWZiZDEtMTFlYi05N2U2LTAyNDJhYzE
  09:01:25.927 [mobservice2] INFO info fbc2474e-fbd1-11eb-b65d-0242ac110004:WuXJGtdQ write success
  09:01:28.613 [mobservice1] INFO info fd65df2a-fbd1-11eb-9b5f-0242ac110004:ayOIXsmT write success
  09:01:31.163 [mobservice2] INFO info fee57e14-fbd1-11eb-81aa-0242ac110004:HkuCdjLo write success
  09:01:33.650 [mobservice2] INFO info 005b606a-fbd2-11eb-b379-0242ac110004:GLwvPubR write success
  09:01:37.275 [dbservice1] INFO 0247c4ea-fbd2-11eb-bb36-0242ac110003-VwxKRfZB-6<qdQnhm*LTF token generate success token=MTYyODgxNjQ5Ny4yNzUzMjc3OjAyNDdjNGVhLWZiZDItMTFlYi1iYjM2LTAyNDJhYzE
  09:01:39.919 [dbservice2] INFO 03c0f634-fbd2-11eb-a333-0242ac110003-CMzFsYZh-4nfMZxAl(ko0 token generate success token=MTYyODgxNjQ5OS45MTk0Njc3OjAzYzBmNjM0LWZiZDItMTFlYi1hMzMzLTAyNDJhYzE

## p0408
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:54:37.693Z
```
{"timestamp":1732247677693751000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Carts merged."}
```
Same service, the 2 minutes before (oldest first):
  03:54:36.864 [front-end] POST /addresses 200 - ms - -
  03:54:36.868 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67400076b0df5c00019b375a"}
  03:54:36.873 [front-end] Carts merged.
  03:54:36.873 [front-end] set cookie6740007cb0df5c00019b376c
  03:54:36.874 [front-end] Sent cookies.
  03:54:36.876 [front-end] POST /register 200 28.822 ms - 33
  03:54:36.876 [front-end] POST /cards 200 - ms - -
  03:54:36.922 [front-end] Attempting to delete cart for user: 67400076b0df5c00019b375a
  03:54:36.945 [front-end] User cart deleted with status: 202
  03:54:36.947 [front-end] DELETE /cart 202 - ms - -
  03:54:36.954 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  03:54:36.960 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  03:54:36.960 [front-end] POST to carts: http://carts/carts/67400076b0df5c00019b375a/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  03:54:37.006 [front-end] POST /cart 201 - ms - -
  03:54:37.116 [front-end] GET /catalogue 200 - ms - -  (×2)
  03:54:37.662 [front-end] Posting Customer: {"username":"NrShdue","password":"IimREASE","email":"NrShdue@gmail.com","firstName":"NrShdue","lastName":"NrShdue"}
  03:54:37.668 [front-end] { id: '6740007db0df5c00019b376f' }
  03:54:37.668 [front-end] 6740007db0df5c00019b376f
  03:54:37.668 [front-end] Merging carts for customer id: 6740007db0df5c00019b376f and session id: 5MFRQt0dGFAbll0r_htUwq3-fdBBEO-j
All services, 30 seconds either side (sampled):
  03:54:07.843 [payment] ts=2024-11-22T03:54:07Z caller=logging.go:40 method=Health result=1 took=7.115µs  (×40)
  03:54:08.579 [user] ts=2024-11-22T03:54:08.579330759Z caller=middlewares.go:75 method=GetUsers id=6740004db0df5c00019b36d9 result=1 took=990.665µs  (×207)
  03:54:08.613 [shipping] Adding shipment to queue...  (×51)
  03:54:08.919 [front-end] Received response: "{\"firstName\":\"qTJIxpS\",\"lastName\":\"qTJIxpS\",\"username\":\"qTJIxpS\",\"id\":\"6740004fb0df5c00019b36dd\",\"_links\":{\"addresses\":{
  03:54:09.341 [front-end] DELETE /cart 202 - ms - -  (×63)
  03:54:10.200 [front-end] POST to carts: http://carts/carts/6740005ab0df5c00019b36fa/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×32)
  03:54:10.496 [payment] ts=2024-11-22T03:54:10Z caller=logging.go:29 method=Authorise result=true took=1.151µs  (×11)
  03:54:14.811 [front-end] Order response: {"id":"67400066d94b9000069b4983","customerId":"67400058b0df5c00019b36f2","customer":{"id":null,"firstName":"CaXqszB","lastName":"CaXqszB","usern
  03:54:16.459 [front-end] Order response: {"id":"67400068d94b9000069b4985","customerId":"67400053b0df5c00019b36e5","customer":{"id":null,"firstName":"fMyIm","lastName":"fMyIm","username"
  03:54:19.552 [front-end] Order response: {"id":"6740006bd94b9000069b4987","customerId":"6740005cb0df5c00019b36fd","customer":{"id":null,"firstName":"hKLtLjNPAK","lastName":"hKLtLjNPAK",
  03:54:21.460 [front-end] Order response: {"id":"6740006dd94b9000069b4989","customerId":"6740005cb0df5c00019b36fc","customer":{"id":null,"firstName":"ugBZCWPzDfko","lastName":"ugBZCWPzDf
  03:54:24.487 [front-end] Posting Customer: {"username":"klcpCTVZJwqE","password":"MJatDpKpa","email":"klcpCTVZJwqE@gmail.com","firstName":"klcpCTVZJwqE","lastName":"klcpCTVZJwqE"}
  03:54:27.824 [front-end] Posting Customer: {"username":"EPTofxIqcDs","password":"bKAyTMVGUu","email":"EPTofxIqcDs@gmail.com","firstName":"EPTofxIqcDs","lastName":"EPTofxIqcDs"}
  03:54:28.932 [front-end] Order response: {"id":"67400074d94b9000069b4991","customerId":"67400060b0df5c00019b370d","customer":{"id":null,"firstName":"RpmXTZtYTnTht","lastName":"RpmXTZtYT
  03:54:30.093 [user] ts=2024-11-22T03:54:30.093522528Z caller=middlewares.go:157 method=Health result=2 took=1.147039ms  (×3)
  03:54:32.219 [front-end] Order response: {"statusCode":201,"body":{"id":"67400078d94b9000069b4995","customerId":"67400062b0df5c00019b3718","customer":{"id":null,"firstName":"awzyUpdYyFV
  03:54:37.662 [front-end] Posting Customer: {"username":"NrShdue","password":"IimREASE","email":"NrShdue@gmail.com","firstName":"NrShdue","lastName":"NrShdue"}
  03:54:39.764 [user] ts=2024-11-22T03:54:39.76461907Z caller=middlewares.go:46 method=Register username=WmkRWR email=WmkRWR@gmail.com took=1.025263ms
  03:54:41.563 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×3)
  03:54:44.422 [front-end] Posting Customer: {"username":"JEUIxdXSQXaVo","password":"ohDyKgeT","email":"JEUIxdXSQXaVo@gmail.com","firstName":"JEUIxdXSQXaVo","lastName":"JEUIxdXSQXaVo"}
  03:54:46.205 [queue-master] 2024-11-22 03:54:46.205 ERROR 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×9)
  03:54:48.726 [front-end] Order response: {"statusCode":201,"body":{"id":"67400088d94b9000069b49a3","customerId":"67400071b0df5c00019b3741","customer":{"id":null,"firstName":"XMMMRHpRIc"
  03:54:50.629 [front-end] Received response: "{\"firstName\":\"cIcyuxIm\",\"lastName\":\"cIcyuxIm\",\"username\":\"cIcyuxIm\",\"id\":\"67400077b0df5c00019b375b\",\"_links\":{\"addresses\
  03:54:54.087 [front-end] Posting Customer: {"username":"myyqMlQoIrhIJ","password":"QKFWZ","email":"myyqMlQoIrhIJ@gmail.com","firstName":"myyqMlQoIrhIJ","lastName":"myyqMlQoIrhIJ"}
  03:54:57.495 [front-end] Posting Customer: {"username":"bWhVmmnajAZ","password":"jiVmMWe","email":"bWhVmmnajAZ@gmail.com","firstName":"bWhVmmnajAZ","lastName":"bWhVmmnajAZ"}
  03:55:00.555 [front-end] Posting Customer: {"username":"wYNgUU","password":"KqeAwkHdau","email":"wYNgUU@gmail.com","firstName":"wYNgUU","lastName":"wYNgUU"}
  03:55:01.953 [front-end] Order response: {"statusCode":201,"body":{"id":"67400095d94b9000069b49ae","customerId":"6740007eb0df5c00019b3773","customer":{"id":null,"firstName":"ffsRvdAhzVG
  03:55:06.368 [front-end] Posting Customer: {"username":"qbnymTwz","password":"jZFQouJjj","email":"qbnymTwz@gmail.com","firstName":"qbnymTwz","lastName":"qbnymTwz"}

## p0386
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:16.642Z
```
{"timestamp":1732247176642501600,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"User cart deleted with status: 503"}
```
Same service, the 2 minutes before (oldest first):
  03:46:16.227 [front-end] POST to carts: http://carts/carts/673ffe7db0df5c00019b3151/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}  (×2)
  03:46:16.296 [front-end] POST /cart 500 70.268 ms - 64  (×2)
  03:46:16.433 [front-end] GET /catalogue 200 - ms - -  (×2)
  03:46:16.436 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffe80b0df5c00019b315a"}  (×2)
  03:46:16.445 [front-end] POST /addresses 200 - ms - -  (×2)
  03:46:16.448 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffe80b0df5c00019b315a"}  (×2)
  03:46:16.459 [front-end] POST /cards 200 - ms - -  (×2)
  03:46:16.504 [front-end] Attempting to delete cart for user: 673ffe80b0df5c00019b315a  (×2)
  03:46:16.557 [front-end] User cart deleted with status: 503
  03:46:16.558 [front-end] DELETE /cart 503 - ms - -
  03:46:16.565 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}
  03:46:16.571 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×21)
  03:46:10.147 [front-end] { id: '673ffe82b0df5c00019b315b' }  (×33)
  03:46:10.189 [front-end] Sent cookies.  (×33)
  03:46:10.811 [front-end] Received response: "{\"firstName\":\"iRQgndFKRWzZ\",\"lastName\":\"iRQgndFKRWzZ\",\"username\":\"iRQgndFKRWzZ\",\"id\":\"673ffe72b0df5c00019b3133\",\"_links\":{
  03:46:10.818 [front-end] [ undefined, undefined ]  (×34)
  03:46:10.848 [orders] 2024-11-22 03:46:10.848 ERROR [orders,,,] 6 --- [-nio-80-exec-12] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×15)
  03:46:10.940 [front-end] Received response: "{\"firstName\":\"jnTZDLVwW\",\"lastName\":\"jnTZDLVwW\",\"username\":\"jnTZDLVwW\",\"id\":\"673ffe65b0df5c00019b3100\",\"_links\":{\"address
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×38)
  03:46:11.285 [front-end] User cart deleted with status: 503  (×37)
  03:46:11.304 [front-end] POST to carts: http://carts/carts/673ffe7bb0df5c00019b3147/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}  (×24)
  03:46:11.500 [catalogue] ts=2024-11-22T03:46:11Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=3.76723m  (×5)
  03:46:12.526 [front-end] Posting Customer: {"username":"YWRstkOr","password":"kgmbhcEA","email":"YWRstkOr@gmail.com","firstName":"YWRstkOr","lastName":"YWRstkOr"}
  03:46:12.669 [orders] 2024-11-22 03:46:12.668 ERROR [orders,,,] 6 --- [p-nio-80-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×19)
  03:46:14.765 [front-end] Received response: "{\"firstName\":\"KxwXfBfUZ\",\"lastName\":\"KxwXfBfUZ\",\"username\":\"KxwXfBfUZ\",\"id\":\"673ffe6fb0df5c00019b3125\",\"_links\":{\"address
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.227 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×7)
  03:46:17.277 [user] ts=2024-11-22T03:46:17.277211334Z caller=middlewares.go:46 method=Register username=ptkQMzQKHy email=ptkQMzQKHy@gmail.com took=1.044122ms  (×7)
  03:46:20.433 [front-end] Received response: "{\"firstName\":\"DHCGNkyEyawp\",\"lastName\":\"DHCGNkyEyawp\",\"username\":\"DHCGNkyEyawp\",\"id\":\"673ffe74b0df5c00019b3136\",\"_links\":{
  03:46:22.962 [user] ts=2024-11-22T03:46:22.961891483Z caller=middlewares.go:46 method=Register username=YNeGDXzX email=YNeGDXzX@gmail.com took=1.087598ms
  03:46:25.988 [front-end] Posting Customer: {"username":"jAAETa","password":"IwsrY","email":"jAAETa@gmail.com","firstName":"jAAETa","lastName":"jAAETa"}
  03:46:26.496 [front-end] Received response: "{\"firstName\":\"gXlVL\",\"lastName\":\"gXlVL\",\"username\":\"gXlVL\",\"id\":\"673ffe80b0df5c00019b3159\",\"_links\":{\"addresses\":{\"href
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.249 [carts-db] {"t":{"$date":"2024-11-22T03:46:29.248+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224718
  03:46:30.113 [front-end] Posting Customer: {"username":"saWqTMkh","password":"METDVZTIFk","email":"saWqTMkh@gmail.com","firstName":"saWqTMkh","lastName":"saWqTMkh"}
  03:46:30.678 [front-end] Received response: "{\"firstName\":\"jwQwxgI\",\"lastName\":\"jwQwxgI\",\"username\":\"jwQwxgI\",\"id\":\"673ffe80b0df5c00019b315a\",\"_links\":{\"addresses\":{
  03:46:32.838 [front-end] Posting Customer: {"username":"ZzayWIHhxNw","password":"FoukoY","email":"ZzayWIHhxNw@gmail.com","firstName":"ZzayWIHhxNw","lastName":"ZzayWIHhxNw"}
  03:46:36.897 [front-end] Posting Customer: {"username":"gOQlBf","password":"ooDdDywNEy","email":"gOQlBf@gmail.com","firstName":"gOQlBf","lastName":"gOQlBf"}
  03:46:39.288 [front-end] Received response: "{\"firstName\":\"YNeGDXzX\",\"lastName\":\"YNeGDXzX\",\"username\":\"YNeGDXzX\",\"id\":\"673ffe8eb0df5c00019b3183\",\"_links\":{\"addresses\
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:42.361 [front-end] Received response: "{\"firstName\":\"UKKtCDfOtWIPTP\",\"lastName\":\"UKKtCDfOtWIPTP\",\"username\":\"UKKtCDfOtWIPTP\",\"id\":\"673ffe90b0df5c00019b3186\",\"_lin

## p0536
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T11:04:04.508Z
```
{"timestamp":1732359844508040400,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T11:04:04.50736759Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=6741b69ca437380001df54e3 took=4.141453ms"}
```
Same service, the 2 minutes before (oldest first):
  11:04:01.216 [user] ts=2024-11-23T11:04:01.216074412Z caller=middlewares.go:46 method=Register username=KMSFxCmQzwH email=KMSFxCmQzwH@gmail.com took=2.414083ms  (×2)
  11:04:01.391 [user] ts=2024-11-23T11:04:01.391418888Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=6741b69aa437380001df54da took=3.910351ms  (×7)
  11:04:01.450 [user] ts=2024-11-23T11:04:01.449982861Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6741b69aa437380001df54da took=4.310519ms  (×7)
  11:04:01.454 [user] ts=2024-11-23T11:04:01.454479736Z caller=middlewares.go:46 method=Register username=zDIHdeVWu email=zDIHdeVWu@gmail.com took=2.48915ms
  11:04:01.849 [user] ts=2024-11-23T11:04:01.849157625Z caller=middlewares.go:157 method=Health result=2 took=2.612178ms  (×2)
  11:04:03.680 [user] ts=2024-11-23T11:04:03.680853901Z caller=middlewares.go:46 method=Register username=QGRnrhxD email=QGRnrhxD@gmail.com took=2.043084ms
All services, 30 seconds either side (sampled):
  11:03:34.849 [user] ts=2024-11-23T11:03:34.849346473Z caller=middlewares.go:157 method=Health result=2 took=2.612714ms  (×40)
  11:03:47.282 [front-end] Posting Customer: {"username":"efjgmmJtKv","password":"RMUFsiyY","email":"efjgmmJtKv@gmail.com","firstName":"efjgmmJtKv","lastName":"efjgmmJtKv"}
  11:03:47.302 [carts] 2024-11-23 11:03:47.301 INFO [carts,5a0a5bec5562a998,10d7f3b5bd52a0a9,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×15)
  11:03:48.042 [front-end] Posting Customer: {"username":"NzdAqPAXT","password":"WSOhs","email":"NzdAqPAXT@gmail.com","firstName":"NzdAqPAXT","lastName":"NzdAqPAXT"}
  11:03:51.097 [user] ts=2024-11-23T11:03:51.097470932Z caller=middlewares.go:46 method=Register username=izuCR email=izuCR@gmail.com took=2.202784ms
  11:03:53.347 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b693a437380001df54d0"}  (×21)
  11:03:53.375 [front-end] POST /cards 200 - ms - -  (×21)
  11:03:53.463 [catalogue] ts=2024-11-23T11:03:53Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=5.433436  (×20)
  11:03:53.523 [front-end] POST /cart 201 - ms - -  (×20)
  11:03:55.832 [front-end] Posting Customer: {"username":"BvVYVeMmWCoOHQZ","password":"XEqkLs","email":"BvVYVeMmWCoOHQZ@gmail.com","firstName":"BvVYVeMmWCoOHQZ","lastName":"BvVYVeMmWCoOHQ
  11:03:56.382 [carts] 2024-11-23 11:03:56.381 INFO [carts,8ec7ce6c89d752ee,d87e8f54055f3ce3,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.ItemsController : Did not find item.  (×12)
  11:03:56.543 [front-end] Posting Customer: {"username":"YWOBdjLIWnSTg","password":"jTWvGWdK","email":"YWOBdjLIWnSTg@gmail.com","firstName":"YWOBdjLIWnSTg","lastName":"YWOBdjLIWnSTg"}
  11:03:57.772 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×3)
  11:03:59.669 [front-end] Posting Customer: {"username":"imhZTN","password":"PxvCtnJ","email":"imhZTN@gmail.com","firstName":"imhZTN","lastName":"imhZTN"}
  11:04:00.291 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×2)
  11:04:01.454 [user] ts=2024-11-23T11:04:01.454479736Z caller=middlewares.go:46 method=Register username=zDIHdeVWu email=zDIHdeVWu@gmail.com took=2.48915ms
  11:04:03.984 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  11:04:06.542 [user] ts=2024-11-23T11:04:06.541921827Z caller=middlewares.go:75 method=GetUsers id=6741b693a437380001df54d0 result=1 took=1.972827ms  (×4)
  11:04:06.562 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b699a437380001df54d8\",\"_links\":{\"
  11:04:06.577 [user] ts=2024-11-23T11:04:06.577774678Z caller=middlewares.go:134 method=GetCards id=6741b699a437380001df54d8 result=1 took=1.80299ms
  11:04:06.606 [queue-master] Received shipment task: 6741b693a437380001df54d0
  11:04:06.609 [front-end] Order response: {"statusCode":201,"headers":{"x-application-context":"orders:80","content-length":"0","date":"Sat, 23 Nov 2024 11:04:06 GMT","x-envoy-upstream-s
  11:04:06.643 [front-end] npm timing command:run-script Completed in 43497ms
  11:04:06.644 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!
  11:04:27.042 [carts-db] {"t":{"$date":"2024-11-23T11:04:27.042+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235986

## p0705
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice2, 2021-08-14T00:28:57.502Z
```
{"service":"redisservice2","message":"2021-08-14 00:28:57,502 | INFO | 0.0.0.2 | 172.17.0.4 | redisservice2 | a9456d54a626629c | service accept, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  00:28:53.403 [redisservice2] INFO service accept, status_code: 200  (×3)
  00:28:53.641 [redisservice2] INFO redis write success  (×9)
  00:28:53.893 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×5)
  00:28:54.133 [redisservice2] INFO redis读取信息成功, status_code: 200  (×3)
All services, 30 seconds either side (sampled):
  00:28:27.523 [redisservice2] INFO service accept, status_code: 200  (×44)
  00:28:27.879 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×46)
  00:28:28.075 [mobservice1] INFO info 7d253f7c-fc53-11eb-a174-0242ac110003:ohjceMiy write success
  00:28:28.239 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×48)
  00:28:28.811 [mobservice1] INFO info 7d97b250-fc53-11eb-9f10-0242ac110003:JuoeTjfH write success
  00:28:29.065 [redisservice1] INFO service accept, status_code: 200  (×50)
  00:28:29.317 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×48)
  00:28:29.832 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  00:28:31.152 [mobservice2] INFO info 7f0454c2-fc53-11eb-b929-0242ac110003:mAIhCgaZ write success
  00:28:33.824 [mobservice2] INFO info 8092585c-fc53-11eb-8620-0242ac110003:KrCJbket write success
  00:28:36.364 [mobservice2] INFO info 821d835e-fc53-11eb-940c-0242ac110003:efoEbcGO write success
  00:28:38.970 [mobservice1] INFO info 83a4956e-fc53-11eb-afb8-0242ac110004:HmUeFxBl write success
  00:28:41.515 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  00:28:43.979 [mobservice2] INFO info 869a867a-fc53-11eb-a30f-0242ac110004:QPshVMni write success
  00:28:47.028 [dbservice2] INFO 883071ac-fc53-11eb-b8bf-0242ac110004-qepNbChc-fH.oSuxnyI{B token generate success token=MTYyODg3MjEyNy4wMjc4NDA5Ojg4MzA3MWFjLWZjNTMtMTFlYi1iOGJmLTAyNDJhYzE
  00:28:49.728 [mobservice2] INFO info 8a0ef58e-fc53-11eb-ba61-0242ac110004:roAFtIPD write success
  00:28:52.336 [mobservice2] INFO info 8ba4ef66-fc53-11eb-a7cb-0242ac110003:pDXcZzKl write success
  00:28:54.771 [mobservice2] INFO info 8d12e970-fc53-11eb-9c82-0242ac110003:vRBrHTWY write success
  00:28:57.309 [mobservice1] INFO info 8e9a5bca-fc53-11eb-bb20-0242ac110003:gwdEDvWp write success
  00:28:59.632 [mobservice2] INFO info 8ffc35ec-fc53-11eb-b91c-0242ac110004:lvCfjILw write success
  00:29:02.442 [dbservice2] INFO 917432b2-fc53-11eb-b85c-0242ac110004-SZKcrGIR-xPE^X0ln_KYI token generate success token=MTYyODg3MjE0Mi40NDE5MzQ6OTE3NDMyYjItZmM1My0xMWViLWI4NWMtMDI0MmFjMTE
  00:29:05.300 [mobservice2] INFO info 935c81ba-fc53-11eb-a806-0242ac110004:URvXGzml write success
  00:29:08.713 [mobservice2] INFO info 956167dc-fc53-11eb-bcfd-0242ac110004:ydgXkaYo write success
  00:29:11.932 [mobservice1] INFO info 974f1774-fc53-11eb-88da-0242ac110004:lGNiksWZ write success
  00:29:14.621 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  00:29:17.109 [dbservice1] INFO 9a2ee83e-fc53-11eb-a2ce-0242ac110003-rwdmTblM-%{XaLd<J/W+. token generate success token=MTYyODg3MjE1Ny4xMDg3MTg5OjlhMmVlODNlLWZjNTMtMTFlYi1hMmNlLTAyNDJhYzE
  00:29:19.487 [dbservice1] INFO 9b980da4-fc53-11eb-a4f0-0242ac110004-IKTgrkvl-puzDw*h+_H#V token generate success token=MTYyODg3MjE1OS40ODcwNTQ2OjliOTgwZGE0LWZjNTMtMTFlYi1hNGYwLTAyNDJhYzE
  00:29:21.970 [dbservice2] INFO 9d1e19de-fc53-11eb-9da6-0242ac110004-btlsWgLd-X^oq#)eu9Fd/ token generate success token=MTYyODg3MjE2MS45Njk1NDI6OWQxZTE5ZGUtZmM1My0xMWViLTlkYTYtMDI0MmFjMTE
  00:29:24.836 [mobservice2] INFO info 9efa7d88-fc53-11eb-b5ac-0242ac110004:lizwZLCr write success

## p0787
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:43:31.439Z
```
{"timestamp":1732351411439882200,"container_name":"front-end","pod_name":"front-end-f77549869-fh46p","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"npm ERR!     /home/myuser/.npm/_logs/2024-11-23T08_29_51_946Z-debug-0.log"}
```
Same service, the 2 minutes before (oldest first):
  08:43:31.432 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!
  08:43:31.432 [front-end] npm notice 
  08:43:31.434 [front-end] npm verb stack Error: command failed
  08:43:31.434 [front-end] npm verb stack at ChildProcess.<anonymous> (/usr/local/lib/node_modules/npm/node_modules/@npmcli/promise-spawn/lib/index.js:63:27)
  08:43:31.434 [front-end] npm verb stack at ChildProcess.emit (node:events:513:28)
  08:43:31.434 [front-end] npm verb stack at maybeClose (node:internal/child_process:1100:16)
  08:43:31.434 [front-end] npm verb stack at Process.ChildProcess._handle.onexit (node:internal/child_process:304:5)
  08:43:31.439 [front-end] npm verb pkgid microservices-demo-front-end@0.0.1
  08:43:31.439 [front-end] npm verb cwd /usr/src/app
  08:43:31.439 [front-end] npm verb Linux 5.10.227-219.884.amzn2.x86_64
  08:43:31.439 [front-end] npm verb node v16.20.2
  08:43:31.439 [front-end] npm verb npm v8.19.4
  08:43:31.439 [front-end] npm ERR! path /usr/src/app
  08:43:31.439 [front-end] npm ERR! command failed
  08:43:31.439 [front-end] npm ERR! signal SIGTERM
  08:43:31.439 [front-end] npm ERR! command sh -c -- node server.js
  08:43:31.439 [front-end] npm verb exit 1
  08:43:31.439 [front-end] npm timing npm Completed in 819492ms
  08:43:31.439 [front-end] npm verb code 1 
  08:43:31.439 [front-end] npm ERR! A complete log of this run can be found in:
All services, 30 seconds either side (sampled):
  08:43:01.574 [catalogue] ts=2024-11-23T08:43:01Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.120099ms  (×45)
  08:43:02.003 [user] ts=2024-11-23T08:43:02.003248176Z caller=middlewares.go:104 method=GetAddresses id=67419589a437380001defe29 result=1 took=2.452319ms  (×29)
  08:43:02.022 [front-end] Order response: {"statusCode":201,"body":{"id":"674195963f7706000886534b","customerId":"67419583a437380001defe16","customer":{"id":null,"firstName":"kOAxFHlONns
  08:43:02.535 [front-end] Sent cookies.  (×51)
  08:43:02.892 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}  (×55)
  08:43:03.630 [front-end] Posting Customer: {"username":"OsNYqfzZRaMW","password":"izyKK","email":"OsNYqfzZRaMW@gmail.com","firstName":"OsNYqfzZRaMW","lastName":"OsNYqfzZRaMW"}
  08:43:04.804 [front-end] Order response: {"id":"674195983f7706000886534c","customerId":"67419587a437380001defe24","customer":{"id":null,"firstName":"XcAQaDJCWNfQJ","lastName":"XcAQaDJCW
  08:43:07.065 [front-end] Order response: {"timestamp":1732351387063,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×4)
  08:43:08.747 [front-end] Posting Customer: {"username":"atjnaEuCr","password":"YeayP","email":"atjnaEuCr@gmail.com","firstName":"atjnaEuCr","lastName":"atjnaEuCr"}
  08:43:10.781 [front-end] Posting Customer: {"username":"RgzxpfsTAiQ","password":"MpdymG","email":"RgzxpfsTAiQ@gmail.com","firstName":"RgzxpfsTAiQ","lastName":"RgzxpfsTAiQ"}
  08:43:11.764 [front-end] Order response: {"id":"6741959f3f77060008865352","customerId":"6741958fa437380001defe3a","customer":{"id":null,"firstName":"tXOnd","lastName":"tXOnd","username"
  08:43:14.237 [front-end] npm timing config:load:cli Completed in 3ms  (×2)
  08:43:14.238 [front-end] npm timing npm:load:configload Completed in 103ms  (×2)
  08:43:14.246 [front-end] npm timing npm:load:logFile Completed in 7ms  (×2)
  08:43:14.578 [front-end] Received response: "{\"firstName\":\"BIRJKPIoxpSLPc\",\"lastName\":\"BIRJKPIoxpSLPc\",\"username\":\"BIRJKPIoxpSLPc\",\"id\":\"6741958ea437380001defe37\",\"_lin
  08:43:16.133 [front-end] Order response: {"id":"674195a43f77060008865355","customerId":"67419593a437380001defe44","customer":{"id":null,"firstName":"CfYLelSE","lastName":"CfYLelSE","use
  08:43:19.655 [front-end] Order response: {"id":"674195a73f77060008865357","customerId":"6741958ba437380001defe2d","customer":{"id":null,"firstName":"FuTpsQAV","lastName":"FuTpsQAV","use
  08:43:22.050 [front-end] Received response: "{\"firstName\":\"YyimhmvssZ\",\"lastName\":\"YyimhmvssZ\",\"username\":\"YyimhmvssZ\",\"id\":\"67419599a437380001defe5a\",\"_links\":{\"addr
  08:43:23.805 [front-end] Order response: {"id":"674195ab3f7706000886535c","customerId":"6741959aa437380001defe5d","customer":{"id":null,"firstName":"sQDhmFmoIZwIYDG","lastName":"sQDhmFm
  08:43:26.197 [front-end] Posting Customer: {"username":"flEFTXC","password":"etSAPItUy","email":"flEFTXC@gmail.com","firstName":"flEFTXC","lastName":"flEFTXC"}
  08:43:27.706 [front-end] Order response: {"statusCode":201,"body":{"id":"674195af3f77060008865361","customerId":"67419598a437380001defe55","customer":{"id":null,"firstName":"gOgYQtJy","
  08:43:30.102 [front-end] Order response: {"statusCode":201,"body":{"id":"674195b23f77060008865363","customerId":"6741959ca437380001defe64","customer":{"id":null,"firstName":"atjnaEuCr",
  08:43:31.434 [front-end] npm verb stack Error: command failed  (×2)
  08:43:31.439 [front-end] npm ERR! command failed  (×2)
  08:43:36.462 [front-end] Received response: "{\"firstName\":\"FBOLvYflPzcEwLv\",\"lastName\":\"FBOLvYflPzcEwLv\",\"username\":\"FBOLvYflPzcEwLv\",\"id\":\"674195a2a437380001defe79\",\"_
  08:43:40.775 [front-end] Received response: "{\"firstName\":\"xlkVGcv\",\"lastName\":\"xlkVGcv\",\"username\":\"xlkVGcv\",\"id\":\"674195a7a437380001defe84\",\"_links\":{\"addresses\":{
  08:43:45.655 [front-end] Posting Customer: {"username":"PHSmla","password":"chOsruk","email":"PHSmla@gmail.com","firstName":"PHSmla","lastName":"PHSmla"}
  08:43:48.791 [front-end] Received response: "{\"firstName\":\"BJjqqW\",\"lastName\":\"BJjqqW\",\"username\":\"BJjqqW\",\"id\":\"674195aea437380001defe9c\",\"_links\":{\"addresses\":{\"h
  08:43:57.303 [front-end] Received response: "{\"firstName\":\"bSIxNayRKIFiLC\",\"lastName\":\"bSIxNayRKIFiLC\",\"username\":\"bSIxNayRKIFiLC\",\"id\":\"674195bfa437380001defec0\",\"_lin

## p0635
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T20:22:22.504Z
```
{"timestamp":1733602942504194600,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-f7tv2","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 20:22:22.503  INFO 1 --- [io-16346-exec-5] travel2.controller.Travel2Controller     : [Get Route By Trip ID] TripId: Z1234"}
```
Same service, the 2 minutes before (oldest first):
  20:22:18.976 [ts-travel2-service] 2024-12-07 20:22:18.975 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：9fc9c261-3263-4bfa-82f8-bb4  (×5)
  20:22:18.982 [ts-travel2-service] 2024-12-07 20:22:18.982 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×5)
  20:22:22.268 [ts-travel2-service] 2024-12-07 20:22:22.268 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  20:22:22.296 [ts-travel2-service] 2024-12-07 20:22:22.296 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50
  20:22:22.304 [ts-travel2-service] 2024-12-07 20:22:22.304 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.
  20:22:22.367 [ts-travel2-service] 2024-12-07 20:22:22.366 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  20:22:22.374 [ts-travel2-service] 2024-12-07 20:22:22.373 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  20:22:22.412 [ts-travel2-service] 2024-12-07 20:22:22.412 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  20:22:22.427 [ts-travel2-service] 2024-12-07 20:22:22.427 INFO 1 --- [io-16346-exec-7] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234
  20:22:22.438 [ts-travel2-service] 2024-12-07 20:22:22.438 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  20:22:22.475 [ts-travel2-service] 2024-12-07 20:22:22.475 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int
All services, 30 seconds either side (sampled):
  20:21:52.681 [ts-admin-basic-info-service] 2024-12-07 20:21:52.681 INFO 1 --- [io-18767-exec-2] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×13)
  20:21:53.642 [ts-basic-service] 2024-12-07 20:21:53.641 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×4)
  20:21:53.683 [ts-basic-service] 2024-12-07 20:21:53.683 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×6)
  20:21:53.747 [ts-seat-service] 2024-12-07 20:21:53.747 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×36)
  20:21:53.866 [ts-travel-service] 2024-12-07 20:21:53.866 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:00:00 GMT 2013  (×28)
  20:21:53.918 [ts-basic-service] 2024-12-07 20:21:53.918 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : route.getDistances().size : 2  (×30)
  20:21:54.357 [ts-travel-service] 2024-12-07 20:21:54.357 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×29)
  20:21:54.961 [ts-basic-service] 2024-12-07 20:21:54.961 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×17)
  20:21:55.065 [ts-seat-service] 2024-12-07 20:21:55.065 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×28)
  20:21:55.158 [ts-seat-service] 2024-12-07 20:21:55.158 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat
  20:21:57.740 [ts-travel-service] 2024-12-07 20:21:57.740 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×2)
  20:21:59.789 [ts-order-other-service] 2024-12-07 20:21:59.789 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 56  (×4)
  20:22:03.590 [ts-basic-service] 2024-12-07 20:22:03.590 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieT  (×2)
  20:22:10.354 [ts-food-service] 2024-12-07 20:22:10.354 INFO 1 --- [io-18856-exec-6] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×4)
  20:22:18.877 [ts-admin-travel-service] 2024-12-07 20:22:18.877 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]
  20:22:22.616 [ts-food-map-service] 2024-12-07 20:22:22.615 INFO 1 --- [o-18855-exec-10] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]
  20:22:22.721 [ts-security-service] 2024-12-07 20:22:22.721 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....  (×2)
  20:22:22.757 [ts-preserve-other-service] 2024-12-07 20:22:22.757 INFO 1 --- [io-14569-exec-3] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Contacts By Id is] Getting....
  20:22:23.072 [ts-preserve-other-service] 2024-12-07 20:22:23.071 INFO 1 --- [io-14569-exec-3] p.service.PreserveOtherServiceImpl : TripAllDetail : TripAllDetail(status=false, message=null, tripResponse
  20:22:23.200 [ts-seat-service] 2024-12-07 20:22:23.200 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService distributeSeat] Use a new seat number! 556146929  (×2)
  20:22:23.226 [ts-food-service] 2024-12-07 20:22:23.225 INFO 1 --- [io-18856-exec-8] foodsearch.controller.FoodController : [Food Service]Try to Create a FoodOrder!  (×2)
  20:22:24.435 [ts-seat-service] 2024-12-07 20:22:24.435 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×8)
  20:22:29.240 [ts-order-service] 2024-12-07 20:22:29.240 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×2)
  20:22:31.710 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-07T20:22:31.709+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360295
  20:22:35.553 [ts-order-service] 2024-12-07 20:22:35.553 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Other Service][Get Order By Id] Order Id: 37791f41-019d-4830-a957
  20:22:43.660 [ts-preserve-service] 2024-12-07 20:22:43.660 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Other Service][Check Security] Checking....
  20:22:43.716 [ts-travel-service] 2024-12-07 20:22:43.716 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  20:22:44.041 [ts-route-service] Error occurred during initialization of VM
  20:22:44.180 [ts-order-service] 2024-12-07 20:22:44.180 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : [Order Service][Order Create] Success.
  20:22:50.981 [ts-order-other-service] 2024-12-07 20:22:50.981 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM
