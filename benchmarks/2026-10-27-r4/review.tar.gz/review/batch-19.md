## p0316
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:20:35.302Z
```
{"timestamp":1732245635302706400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"firstName\\\":\\\"tJMqzAgJI\\\",\\\"lastName\\\":\\\"tJMqzAgJI\\\",\\\"username\\\":\\\"tJMqzAgJI\\\",\\\"id\\\":\\\"673ff874b0df5c00019b1ee9\\\",\\\"_links\\\":{\\\"addresses\\\":{\\\"href\\\":\\\"http://user/customers/673ff874b0df5c00019b1ee9/addresses\\\"},\\\"cards\\\":{\\\"href\\\":\\\"http://user/customers/673ff874b0df5c00019b1ee9/cards\\\"},\\\"customer\\\":{\\\"href\\\":\\\"http://user/customers/673ff874b0df5c00019b1ee9\\\"},\\\"self\\\":{…"}
```
Same service, the 2 minutes before (oldest first):
  03:20:35.036 [front-end] GET Request to: http://user/customers/673ff873b0df5c00019b1ee7/cards
  03:20:35.042 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:20:35.042 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff87ab0df5c00019b1efb\",\"_links\":{\"
  03:20:35.042 [front-end] [ undefined, undefined ]
  03:20:35.043 [front-end] Posting Order: {"customer":"http://user/customers/673ff873b0df5c00019b1ee7","address":"http://user/addresses/673ff87ab0df5c00019b1efa","card":"http://user/cards
  03:20:35.067 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff87ab0df5c00019b1ef7"}
  03:20:35.076 [front-end] POST /addresses 200 - ms - -
  03:20:35.080 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff87ab0df5c00019b1ef7"}
  03:20:35.090 [front-end] POST /cards 200 - ms - -
  03:20:35.111 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245635108,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:20:35.111 [front-end] Order response: {"timestamp":1732245635108,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:20:35.114 [front-end] POST /orders 500 - ms - -
  03:20:35.138 [front-end] Attempting to delete cart for user: 673ff87ab0df5c00019b1ef7
  03:20:35.202 [front-end] User cart deleted with status: 503
  03:20:35.205 [front-end] DELETE /cart 503 - ms - -
  03:20:35.210 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  03:20:35.216 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  03:20:35.216 [front-end] POST to carts: http://carts/carts/673ff87ab0df5c00019b1ef7/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  03:20:35.277 [front-end] POST /cart 500 64.611 ms - 64
  03:20:35.295 [front-end] Request received with body: {}
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×34)
  03:20:06.550 [user] ts=2024-11-22T03:20:06.549939822Z caller=middlewares.go:104 method=GetAddresses id=673ff854b0df5c00019b1e7e result=1 took=839.732µs  (×30)
  03:20:06.660 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff861b0df5c00019b1e9e"}  (×64)
  03:20:06.803 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×10)
  03:20:08.182 [front-end] GET /catalogue 200 - ms - -  (×56)
  03:20:08.498 [front-end] Sent cookies.  (×62)
  03:20:09.192 [carts] 2024-11-22 03:20:09.192 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  03:20:11.559 [user] ts=2024-11-22T03:20:11.558844653Z caller=middlewares.go:46 method=Register username=xQhxkcD email=xQhxkcD@gmail.com took=1.123618ms
  03:20:14.697 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×7)
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:21.876 [front-end] Received response: "{\"firstName\":\"GSlyQdwsNkS\",\"lastName\":\"GSlyQdwsNkS\",\"username\":\"GSlyQdwsNkS\",\"id\":\"673ff862b0df5c00019b1ea1\",\"_links\":{\"a
  03:20:26.469 [front-end] Received response: "{\"firstName\":\"tbhaDXI\",\"lastName\":\"tbhaDXI\",\"username\":\"tbhaDXI\",\"id\":\"673ff865b0df5c00019b1ea5\",\"_links\":{\"addresses\":{
  03:20:30.252 [front-end] Posting Customer: {"username":"MKGIsEbVYi","password":"VhFAQhsXw","email":"MKGIsEbVYi@gmail.com","firstName":"MKGIsEbVYi","lastName":"MKGIsEbVYi"}
  03:20:32.913 [front-end] Received response: "{\"firstName\":\"xQhxkcD\",\"lastName\":\"xQhxkcD\",\"username\":\"xQhxkcD\",\"id\":\"673ff86bb0df5c00019b1ec3\",\"_links\":{\"addresses\":{
  03:20:37.986 [front-end] Posting Customer: {"username":"WwpBLC","password":"ngXKNthnRa","email":"WwpBLC@gmail.com","firstName":"WwpBLC","lastName":"WwpBLC"}
  03:20:39.907 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×6)
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  03:20:46.654 [front-end] Received response: "{\"firstName\":\"iLqTiAFoVbIq\",\"lastName\":\"iLqTiAFoVbIq\",\"username\":\"iLqTiAFoVbIq\",\"id\":\"673ff877b0df5c00019b1eec\",\"_links\":{
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springfram
  03:20:51.541 [front-end] Received response: "{\"firstName\":\"MKGIsEbVYi\",\"lastName\":\"MKGIsEbVYi\",\"username\":\"MKGIsEbVYi\",\"id\":\"673ff87eb0df5c00019b1eff\",\"_links\":{\"addr
  03:20:55.770 [user] ts=2024-11-22T03:20:55.770582148Z caller=middlewares.go:46 method=Register username=PvCLeeg email=PvCLeeg@gmail.com took=1.055848ms
  03:20:59.486 [carts] 2024-11-22 03:20:59.485 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.e
  03:20:59.690 [carts] 2024-11-22 03:20:59.689 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[DELETE],produces=[applicat
  03:20:59.788 [carts] 2024-11-22 03:20:59.788 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applicat
  03:20:59.887 [carts] 2024-11-22 03:20:59.887 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframewor
  03:21:02.589 [user] ts=2024-11-22T03:21:02.589004338Z caller=middlewares.go:46 method=Register username=UFhesIA email=UFhesIA@gmail.com took=1.127131ms
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:21:03.479 [front-end] Received response: "{\"firstName\":\"TeeRhkRKovrDpY\",\"lastName\":\"TeeRhkRKovrDpY\",\"username\":\"TeeRhkRKovrDpY\",\"id\":\"673ff88fb0df5c00019b1f25\",\"_lin

## p0799
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-other-service, 2024-12-08T08:40:42.703Z
```
{"timestamp":1733647242703282400,"container_name":"ts-order-other-service","pod_name":"ts-order-other-service-746fccc88f-k5zlt","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"java.lang.IllegalArgumentException: Invalid UUID string: \n\tat java.util.UUID.fromString(UUID.java:194) ~[na:1.8.0_402]\n\tat other.service.OrderOtherServiceImpl.queryOrders(OrderOtherServiceImpl.java:122) ~[classes!/:1.0]\n\tat other.service.OrderOtherServiceImpl.queryOrdersForRefresh(OrderOtherServiceImpl.java:182) ~[classes!/:1.0]\n\tat other.controller.OrderOtherController.queryOrdersForRefresh(Order…"}
```
Same service, the 2 minutes before (oldest first):
  08:40:33.017 [ts-order-other-service] 2024-12-08 08:40:33.016 INFO 1 --- [io-12032-exec-6] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:0  (×4)
  08:40:33.021 [ts-order-other-service] 2024-12-08 08:40:33.020 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×4)
  08:40:33.114 [ts-order-other-service] 2024-12-08 08:40:33.114 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×7)
  08:40:35.343 [ts-order-other-service] 2024-12-08 08:40:35.343 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM
  08:40:35.346 [ts-order-other-service] 2024-12-08 08:40:35.346 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=208356
  08:40:35.416 [ts-order-other-service] 2024-12-08 08:40:35.416 INFO 1 --- [io-12032-exec-9] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=208356
  08:40:42.680 [ts-order-other-service] 2024-12-08 08:40:42.679 INFO 1 --- [io-12032-exec-8] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 
  08:40:42.703 [ts-order-other-service] 2024-12-08 08:40:42.702 ERROR 1 --- [io-12032-exec-8] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
All services, 30 seconds either side (sampled):
  08:40:12.775 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:40:12 +0800] "POST /api/v1/users/login HTTP/1.1" 503 19 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel M  (×22)
  08:40:12.862 [ts-basic-service] 2024-12-08 08:40:12.862 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×4)
  08:40:12.897 [ts-order-other-service] 2024-12-08 08:40:12.896 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:0  (×12)
  08:40:12.968 [ts-order-other-service] 2024-12-08 08:40:12.968 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×26)
  08:40:13.046 [ts-travel2-service] 2024-12-08 08:40:13.045 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×18)
  08:40:13.374 [ts-admin-basic-info-service] 2024-12-08 08:40:13.374 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin 
  08:40:15.467 [ts-travel2-service] 2024-12-08 08:40:15.467 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×3)
  08:40:22.972 [ts-admin-basic-info-service] 2024-12-08 08:40:22.972 INFO 1 --- [io-18767-exec-5] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×8)
  08:40:26.054 [ts-basic-service] 2024-12-08 08:40:26.054 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3  (×3)
  08:40:28.996 [ts-auth-service] 2024-12-08 08:40:28.995 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def  (×2)
  08:40:31.184 [ts-auth-service] 2024-12-08 08:40:31.184 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.  (×2)
  08:40:33.646 [ts-travel-service] 2024-12-08 08:40:33.646 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×2)
  08:40:33.702 [ts-basic-service] 2024-12-08 08:40:33.702 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×3)
  08:40:33.777 [ts-order-service] 2024-12-08 08:40:33.777 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024  (×2)
  08:40:33.899 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:40:33 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 339 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×4)
  08:40:37.296 [ts-auth-service] 2024-12-08 08:40:37.295 INFO 1 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext  (×2)
  08:40:42.286 [ts-auth-service] 2024-12-08 08:40:42.286 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:33}] to ts-auth-m  (×2)
  08:40:43.509 [ts-travel-service] 2024-12-08 08:40:43.509 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×3)
  08:40:43.621 [ts-travel-service] 2024-12-08 08:40:43.621 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, tr  (×2)
  08:40:49.879 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:40:49 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 5017 "-" "Mozilla/5.0 (Macintosh;
  08:40:51.389 [ts-auth-service] 2024-12-08 08:40:51.388 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.springframewo
  08:40:53.392 [ts-auth-service] 2024-12-08 08:40:53.392 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/vnd.spring-
  08:40:53.582 [ts-auth-service] 2024-12-08 08:40:53.582 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.boot.actuate.autoconfigure.Manageme
  08:40:59.988 [ts-auth-service] 2024-12-08 08:40:59.987 INFO 1 --- [ main] org.mongodb.driver.connection : Opened connection [connectionId{localValue:2, serverValue:35}] to ts-auth-mongo:27017
  08:41:04.889 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:41:04 +0800] "POST /api/v1/users/login HTTP/1.1" 200 146 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×5)
  08:41:07.011 [ts-travel-service] 2024-12-08 08:41:07.011 ERROR 1 --- [io-12346-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  08:41:09.918 [ts-travel-mongo] {"t":{"$date":"2024-12-08T08:41:09.918+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364726
  08:41:11.048 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-08T08:41:11.048+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364727
  08:41:12.497 [ts-food-map-mongo] {"t":{"$date":"2024-12-08T08:41:12.497+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364727

## p0272
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:22.114Z
```
{"timestamp":1732242502114750500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"firstName\\\":\\\"bCCZHBaYc\\\",\\\"lastName\\\":\\\"bCCZHBaYc\\\",\\\"username\\\":\\\"bCCZHBaYc\\\",\\\"id\\\":\\\"673fec31b0df5c00019af95b\\\",\\\"_links\\\":{\\\"addresses\\\":{\\\"href\\\":\\\"http://user/customers/673fec31b0df5c00019af95b/addresses\\\"},\\\"cards\\\":{\\\"href\\\":\\\"http://user/customers/673fec31b0df5c00019af95b/cards\\\"},\\\"customer\\\":{\\\"href\\\":\\\"http://user/customers/673fec31b0df5c00019af95b\\\"},\\\"self\\\":{…"}
```
Same service, the 2 minutes before (oldest first):
  02:28:21.229 [front-end] Order response: {"timestamp":1732242501226,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:21.232 [front-end] POST /orders 500 - ms - -
  02:28:21.660 [front-end] Request received with body: {}  (×2)
  02:28:21.668 [front-end] Received response: "{\"firstName\":\"kMzzAppFcYY\",\"lastName\":\"kMzzAppFcYY\",\"username\":\"kMzzAppFcYY\",\"id\":\"673fec33b0df5c00019af962\",\"_links\":{\"a
  02:28:21.668 [front-end] GET Request to: http://user/customers/673fec33b0df5c00019af962/addresses  (×2)
  02:28:21.674 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:21.674 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec39b0df5c00019af973\",\"_links\":{\"
  02:28:21.674 [front-end] [ undefined, undefined ]
  02:28:21.674 [front-end] Posting Order: {"customer":"http://user/customers/673fec33b0df5c00019af962","address":"http://user/addresses/673fec39b0df5c00019af972","card":"http://user/cards
  02:28:21.727 [front-end] GET /catalogue 200 - ms - -
  02:28:21.967 [front-end] Posting Customer: {"username":"PDQejFz","password":"UItpfuss","email":"PDQejFz@gmail.com","firstName":"PDQejFz","lastName":"PDQejFz"}
  02:28:21.968 [front-end] Posting Customer: {"username":"fLxXNRuLzWhn","password":"VrHzecv","email":"fLxXNRuLzWhn@gmail.com","firstName":"fLxXNRuLzWhn","lastName":"fLxXNRuLzWhn"}
  02:28:21.973 [front-end] { id: '673fec45b0df5c00019af990' }  (×2)
  02:28:21.974 [front-end] 673fec45b0df5c00019af990  (×2)
  02:28:21.974 [front-end] Merging carts for customer id: 673fec45b0df5c00019af990 and session id: uXbKmnZAMKoU_w4Qqg1PC4Vfbn_15hFE  (×2)
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×48)
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -  (×48)
  02:28:03.203 [front-end] [ undefined, undefined ]  (×48)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×4)
  02:28:07.445 [orders] 2024-11-22 02:28:07.445 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
  02:28:10.277 [front-end] Posting Customer: {"username":"opFqwUnVow","password":"habyXFSF","email":"opFqwUnVow@gmail.com","firstName":"opFqwUnVow","lastName":"opFqwUnVow"}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.939 [carts] 2024-11-22 02:28:22.636 INFO [carts,2304f0c26b13fa34,22ff6d298cffa122,false] 7 --- [p-nio-80-exec-6] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],m  (×3)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.999 [rabbitmq] =INFO REPORT==== 22-Nov-2024::02:28:24 ===  (×2)
  02:28:25.776 [front-end] Posting Customer: {"username":"oqYeDriHaX","password":"fGIijlAHQ","email":"oqYeDriHaX@gmail.com","firstName":"oqYeDriHaX","lastName":"oqYeDriHaX"}
  02:28:26.670 [orders-db] {"t":{"$date":"2024-11-22T02:28:26.670+00:00"},"s":"I", "c":"STORAGE", "id":20279, "ctx":"conn2","msg":"Conflicted creating a collection","attr":{"namespace":"d
  02:28:26.959 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39cf","customerId":"673fec36b0df5c00019af96c","customer":{"id":null,"firstName":"oyShDJ","la
  02:28:27.046 [front-end] Order response: {"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","lastName":"uBxHmzyg","use
  02:28:30.547 [front-end] Received response: "{\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\",\"username\":\"vvgsHcY\",\"id\":\"673fec35b0df5c00019af968\",\"_links\":{\"addresses\":{
  02:28:32.249 [queue-master] org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket-factory-20
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×60)
  02:28:38.668 [front-end] Received response: "{\"firstName\":\"PDQejFz\",\"lastName\":\"PDQejFz\",\"username\":\"PDQejFz\",\"id\":\"673fec45b0df5c00019af990\",\"_links\":{\"addresses\":{
  02:28:40.372 [front-end] Received response: "{\"firstName\":\"ngvaqDyp\",\"lastName\":\"ngvaqDyp\",\"username\":\"ngvaqDyp\",\"id\":\"673fec48b0df5c00019af997\",\"_links\":{\"addresses\
  02:28:42.162 [front-end] Order response: {"timestamp":1732242522152,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×2)
  02:28:44.338 [front-end] Order response: {"id":"673fec5cd94b9000069b39e2","customerId":"673fec3ab0df5c00019af974","customer":{"id":null,"firstName":"opFqwUnVow","lastName":"opFqwUnVow",
  02:28:45.917 [front-end] Posting Customer: {"username":"TmuiGnjHXKwQyA","password":"AlXtuGS","email":"TmuiGnjHXKwQyA@gmail.com","firstName":"TmuiGnjHXKwQyA","lastName":"TmuiGnjHXKwQyA"}
  02:28:47.785 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec5fd94b9000069b39e7","customerId":"673fec41b0df5c00019af98c","customer":{"id":null,"firstName":"QGHrdp","la
  02:28:50.862 [front-end] Posting Customer: {"username":"tuMdldzXaDzdlI","password":"tqMnacPIQx","email":"tuMdldzXaDzdlI@gmail.com","firstName":"tuMdldzXaDzdlI","lastName":"tuMdldzXaDzdl

## p0145
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:36:03.427Z
```
{"timestamp":1731908163427640300,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  05:36:02.411 [frontend] view user cart  (×3)
  05:36:02.450 [frontend] request complete  (×7)
  05:36:02.535 [frontend] request started  (×6)
  05:36:02.535 [frontend] serving product page  (×3)
  05:36:02.760 [frontend] adding to cart
All services, 30 seconds either side (sampled):
  05:35:33.719 [frontend] request started  (×304)
  05:35:33.721 [currencyservice] Getting supported currencies...  (×247)
  05:35:33.736 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '1YMWWN1N4O', 'OLJCESPC7Z', '6E92ZMYYFZ', '66VCHSJNUP']  (×200)
  05:35:33.747 [shippingservice] [GetQuote] completed request  (×66)
  05:35:33.754 [frontend] request complete  (×305)
  05:35:34.126 [frontend] home  (×43)
  05:35:34.179 [adservice] received ad request (context_words=[])  (×43)
  05:35:35.306 [adservice] received ad request (context_words=[accessories])  (×27)
  05:35:35.394 [cartservice] AddItemAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55, productId=1YMWWN1N4O, quantity=7  (×33)
  05:35:35.726 [frontend] placing order  (×6)
  05:35:35.747 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"291","nanos":560251221},"credit_card":{"credit_card_number":"44533064532990  (×3)
  05:35:35.749 [checkoutservice] payment went through (transaction_id: 0f129b30-f40d-4ae4-b5b5-f6442a57b62b)  (×6)
  05:35:35.750 [shippingservice] [ShipOrder] completed request  (×6)
  05:35:35.760 [emailservice] A request to send order confirmation email to gmorton@example.net has been received.
  05:35:35.761 [frontend] order placed  (×6)
  05:35:37.142 [adservice] received ad request (context_words=[hair, beauty])  (×15)
  05:35:40.434 [adservice] received ad request (context_words=[clothing, tops])  (×18)
  05:35:40.578 [checkoutservice] order confirmation email sent to "gabrielcurtis@example.net"
  05:35:47.754 [checkoutservice] [PlaceOrder] user_id="b63bea0e-d05f-4589-be71-8fef43557432" user_currency="JPY"  (×2)
  05:35:47.781 [paymentservice] Transaction processed: visa ending 6271 Amount: JPY244726.276869397  (×2)
  05:35:47.795 [checkoutservice] order confirmation email sent to "amandajohnson@example.org"
  05:35:52.271 [checkoutservice] order confirmation email sent to "leslieschroeder@example.net"
  05:35:58.054 [redis] 1:M 18 Nov 2024 05:35:58.054 * Background saving started by pid 53
  05:35:58.060 [redis] 53:C 18 Nov 2024 05:35:58.060 * Fork CoW for RDB: current 0 MB, peak 0 MB, average 0 MB
  05:36:11.139 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', 'OLJCESPC7Z', '0PUK6V6EV0']  (×2)
  05:36:19.221 [checkoutservice] order confirmation email sent to "ogardner@example.com"
  05:36:27.022 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"587","nanos":160000000},"credit_card":{"credit_card_number":"40081295360215
  05:36:27.035 [emailservice] A request to send order confirmation email to batesryan@example.com has been received.

## p0759
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T06:35:04.091Z
```
{"timestamp":1732257304091967200,"container_name":"carts","pod_name":"carts-6cdcbc6cd7-kqnt9","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 06:35:04.091  WARN [carts,,,] 7 --- [           main] o.s.c.a.ConfigurationClassPostProcessor  : Cannot enhance @Configuration bean definition 'refreshScope' since its singleton instance has been created too early. The typical cause is a non-static @Bean method with a BeanDefinitionRegistryPostProcessor return type: Consider declaring such methods as 'static'."}
```
Same service, the 2 minutes before (oldest first):
  06:34:16.497 [carts] 2024-11-22 06:34:16.497 INFO [carts,ad4d97235cefe909,f07fc992d872b33b,false] 7 --- [p-nio-80-exec-9] w.w.s.cart.controllers.CartsController : Merge carts reques  (×3)
  06:34:16.841 [carts] 2024-11-22 06:34:16.841 INFO [carts,6b05446195a46044,b326fa00fd406de9,false] 7 --- [-nio-80-exec-19] w.w.s.cart.controllers.CartsController : Merge carts reques  (×4)
  06:34:17.645 [carts] 2024-11-22 06:34:17.645 INFO [carts,00c0f043fd5c0534,ec9ab1bee6badbaf,false] 7 --- [-nio-80-exec-17] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  06:34:17.648 [carts] 2024-11-22 06:34:17.648 INFO [carts,00c0f043fd5c0534,ec9ab1bee6badbaf,false] 7 --- [-nio-80-exec-17] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
  06:34:28.632 [carts] 2024-11-22 06:34:28.632 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Exception in monitor thread while connecting to server carts-db:270
  06:34:28.632 [carts] com.mongodb.MongoSocketOpenException: Exception opening socket at com.mongodb.connection.SocketStream.open(SocketStream.java:63) ~[mongodb-driver-core-3.2.2.jar
  06:34:28.632 [carts] Caused by: java.net.ConnectException: Connection refused (Connection refused) at java.net.PlainSocketImpl.socketConnect(Native Method) ~[na:1.8.0_131] at java.n
  06:34:31.483 [carts] 2024-11-22 06:34:31.386 INFO [bootstrap,,,] 7 --- [ main] s.c.a.AnnotationConfigApplicationContext : Refreshing org.springframework.context.annotation.Annotatio
  06:34:37.089 [carts] 2024-11-22 06:34:37.089 INFO [bootstrap,,,] 7 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'configurationPropertiesRebinderAutoConfiguration' of 
  06:34:40.993 [carts] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  06:34:41.291 [carts] 2024-11-22 06:34:41.291 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : No active profile set, falling back to default profiles: default
  06:34:41.486 [carts] 2024-11-22 06:34:41.486 INFO [carts,,,] 7 --- [ main] ationConfigEmbeddedWebApplicationContext : Refreshing org.springframework.boot.context.embedded.Annotation
  06:35:00.986 [carts] 2024-11-22 06:35:00.985 INFO [carts,,,] 7 --- [ main] o.s.b.f.s.DefaultListableBeanFactory : Overriding bean definition for bean 'managementServletContext' with
All services, 30 seconds either side (sampled):
  06:34:34.102 [front-end] User cart deleted with status: 503  (×58)
  06:34:34.624 [user] ts=2024-11-22T06:34:34.624094271Z caller=middlewares.go:75 method=GetUsers id=674025eb768f35000114f152 result=1 took=3.640696ms  (×260)
  06:34:34.650 [user] ts=2024-11-22T06:34:34.650778482Z caller=middlewares.go:104 method=GetAddresses id=674025f1768f35000114f168 result=1 took=1.979403ms  (×65)
  06:34:35.158 [user] ts=2024-11-22T06:34:35.158199694Z caller=middlewares.go:46 method=Register username=kmOTTiAmqtM email=kmOTTiAmqtM@gmail.com took=3.140953ms  (×28)
  06:34:35.532 [payment] ts=2024-11-22T06:34:35Z caller=logging.go:40 method=Health result=1 took=5.418µs  (×40)
  06:34:35.677 [catalogue] ts=2024-11-22T06:34:35Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=3.352976  (×49)
  06:34:36.347 [front-end] Posting Customer: {"username":"vLgISaAaM","password":"hwUhSOiQ","email":"vLgISaAaM@gmail.com","firstName":"vLgISaAaM","lastName":"vLgISaAaM"}
  06:34:38.426 [front-end] Posting Customer: {"username":"hViSVFUAxtoztp","password":"DqcfJXc","email":"hViSVFUAxtoztp@gmail.com","firstName":"hViSVFUAxtoztp","lastName":"hViSVFUAxtoztp"}
  06:34:40.993 [carts] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  06:34:42.029 [front-end] Received response: "{\"firstName\":\"xZPoptlMd\",\"lastName\":\"xZPoptlMd\",\"username\":\"xZPoptlMd\",\"id\":\"674025f0768f35000114f164\",\"_links\":{\"address
  06:34:43.175 [front-end] Posting Customer: {"username":"UmxVKMRgrrQ","password":"eQpjiqwpK","email":"UmxVKMRgrrQ@gmail.com","firstName":"UmxVKMRgrrQ","lastName":"UmxVKMRgrrQ"}
  06:34:44.775 [front-end] Received response: "{\"firstName\":\"CCykUIXtrHGaddn\",\"lastName\":\"CCykUIXtrHGaddn\",\"username\":\"CCykUIXtrHGaddn\",\"id\":\"674025e8768f35000114f147\",\"_
  06:34:49.516 [front-end] Posting Customer: {"username":"bLeDcg","password":"NlKJwAxWyO","email":"bLeDcg@gmail.com","firstName":"bLeDcg","lastName":"bLeDcg"}
  06:34:52.106 [front-end] Posting Customer: {"username":"vYLlfjgeyCi","password":"aOiqnRzU","email":"vYLlfjgeyCi@gmail.com","firstName":"vYLlfjgeyCi","lastName":"vYLlfjgeyCi"}
  06:34:55.436 [front-end] Posting Customer: {"username":"XQqdulgb","password":"hXcdNb","email":"XQqdulgb@gmail.com","firstName":"XQqdulgb","lastName":"XQqdulgb"}
  06:34:57.573 [user] ts=2024-11-22T06:34:57.573437929Z caller=middlewares.go:46 method=Register username=xrtJOcF email=xrtJOcF@gmail.com took=2.004871ms
  06:34:59.780 [front-end] Received response: "{\"firstName\":\"XCFZpxsWykbL\",\"lastName\":\"XCFZpxsWykbL\",\"username\":\"XCFZpxsWykbL\",\"id\":\"674025f9768f35000114f183\",\"_links\":{
  06:35:02.925 [front-end] Posting Customer: {"username":"mTdYUTEdLC","password":"wkvBnsTvC","email":"mTdYUTEdLC@gmail.com","firstName":"mTdYUTEdLC","lastName":"mTdYUTEdLC"}
  06:35:05.967 [front-end] Received response: "{\"firstName\":\"TwNji\",\"lastName\":\"TwNji\",\"username\":\"TwNji\",\"id\":\"67402602768f35000114f194\",\"_links\":{\"addresses\":{\"href
  06:35:07.432 [front-end] Received response: "{\"firstName\":\"vYLlfjgeyCi\",\"lastName\":\"vYLlfjgeyCi\",\"username\":\"vYLlfjgeyCi\",\"id\":\"6740260c768f35000114f1b1\",\"_links\":{\"a
  06:35:09.801 [front-end] Received response: "{\"firstName\":\"FfOqMYGlRxUll\",\"lastName\":\"FfOqMYGlRxUll\",\"username\":\"FfOqMYGlRxUll\",\"id\":\"67402607768f35000114f1a7\",\"_links\
  06:35:12.928 [front-end] Posting Customer: {"username":"vXcWJ","password":"UApcFP","email":"vXcWJ@gmail.com","firstName":"vXcWJ","lastName":"vXcWJ"}
  06:35:14.618 [front-end] Posting Customer: {"username":"OeWGgPkPne","password":"irRNdi","email":"OeWGgPkPne@gmail.com","firstName":"OeWGgPkPne","lastName":"OeWGgPkPne"}
  06:35:17.344 [front-end] Received response: "{\"firstName\":\"ecIDrEWSwRXVbsm\",\"lastName\":\"ecIDrEWSwRXVbsm\",\"username\":\"ecIDrEWSwRXVbsm\",\"id\":\"6740260e768f35000114f1bb\",\"_
  06:35:21.466 [user] ts=2024-11-22T06:35:21.465811767Z caller=middlewares.go:46 method=Register username=NKFnFbzD email=NKFnFbzD@gmail.com took=1.970871ms
  06:35:22.540 [front-end] Received response: "{\"firstName\":\"nHdmTwEnOwMb\",\"lastName\":\"nHdmTwEnOwMb\",\"username\":\"nHdmTwEnOwMb\",\"id\":\"67402616768f35000114f1d7\",\"_links\":{
  06:35:23.950 [user] ts=2024-11-22T06:35:23.950301088Z caller=middlewares.go:46 method=Register username=nRJqnKrwR email=nRJqnKrwR@gmail.com took=2.422263ms
  06:35:27.062 [front-end] Posting Customer: {"username":"IpGxMilyABJlqa","password":"rCvKxi","email":"IpGxMilyABJlqa@gmail.com","firstName":"IpGxMilyABJlqa","lastName":"IpGxMilyABJlqa"}
  06:35:31.804 [user] ts=2024-11-22T06:35:31.804042207Z caller=middlewares.go:46 method=Register username=xFXTyk email=xFXTyk@gmail.com took=2.362349ms

## p0613
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T20:14:31.719Z
```
{"timestamp":1733602471719319300,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-nsc8q","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:14:31.719  INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl             : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, description=Allocation Proportion Of The Direct Ticket - From Start To End)"}
```
Same service, the 2 minutes before (oldest first):
  20:14:28.353 [ts-seat-service] 2024-12-07 20:14:28.352 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×2)
  20:14:28.353 [ts-seat-service] 2024-12-07 20:14:28.352 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
  20:14:28.368 [ts-seat-service] 2024-12-07 20:14:28.368 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  20:14:28.379 [ts-seat-service] 2024-12-07 20:14:28.378 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:14:28.392 [ts-seat-service] 2024-12-07 20:14:28.392 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×2)
  20:14:28.392 [ts-seat-service] 2024-12-07 20:14:28.392 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  20:14:28.398 [ts-seat-service] 2024-12-07 20:14:28.398 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri
  20:14:31.589 [ts-seat-service] 2024-12-07 20:14:31.589 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN
  20:14:31.589 [ts-seat-service] 2024-12-07 20:14:31.589 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234
  20:14:31.604 [ts-seat-service] 2024-12-07 20:14:31.604 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes
  20:14:31.613 [ts-seat-service] 2024-12-07 20:14:31.612 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da
  20:14:31.630 [ts-seat-service] 2024-12-07 20:14:31.630 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re
  20:14:31.630 [ts-seat-service] 2024-12-07 20:14:31.630 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  20:14:31.637 [ts-seat-service] 2024-12-07 20:14:31.637 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri
  20:14:31.669 [ts-seat-service] 2024-12-07 20:14:31.669 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234
  20:14:31.684 [ts-seat-service] 2024-12-07 20:14:31.684 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes
  20:14:31.696 [ts-seat-service] 2024-12-07 20:14:31.695 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da
All services, 30 seconds either side (sampled):
  20:14:01.788 [ts-auth-service] 2024-12-07 20:14:01.788 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×3)
  20:14:02.015 [ts-travel-service] 2024-12-07 20:14:02.015 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×21)
  20:14:02.139 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:14:02 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×17)
  20:14:09.494 [ts-travel-service] 2024-12-07 20:14:09.494 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×3)
  20:14:15.421 [ts-auth-service] 2024-12-07 20:14:15.421 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×8)
  20:14:15.669 [ts-basic-service] 2024-12-07 20:14:15.669 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×9)
  20:14:15.705 [ts-travel2-service] 2024-12-07 20:14:15.705 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×10)
  20:14:15.780 [ts-order-other-service] 2024-12-07 20:14:15.780 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×19)
  20:14:15.903 [ts-travel2-service] 2024-12-07 20:14:15.903 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×10)
  20:14:17.256 [ts-inside-payment-service] 2024-12-07 20:14:17.255 INFO 1 --- [io-18673-exec-6] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.
  20:14:24.029 [ts-travel2-service] 2024-12-07 20:14:24.028 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  20:14:28.475 [ts-route-mongo] {"t":{"$date":"2024-12-07T20:14:28.475+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360246
  20:14:30.885 [ts-auth-mongo] {"t":{"$date":"2024-12-07T20:14:30.885+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360247
  20:14:31.512 [ts-basic-service] 2024-12-07 20:14:31.512 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×6)
  20:14:31.589 [ts-seat-service] 2024-12-07 20:14:31.589 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×4)
  20:14:31.635 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:14:31.635+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360247
  20:14:31.780 [ts-basic-service] 2024-12-07 20:14:31.779 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2  (×3)
  20:14:34.304 [ts-food-map-service] 2024-12-07 20:14:34.303 INFO 1 --- [o-18855-exec-10] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]
  20:14:36.157 [ts-basic-service] 2024-12-07 20:14:36.157 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×3)
  20:14:42.368 [ts-admin-basic-info-service] 2024-12-07 20:14:42.368 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×2)
  20:14:54.393 [ts-seat-service] 2024-12-07 20:14:54.393 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:14:54.574 [ts-preserve-other-service] 2024-12-07 20:14:54.574 INFO 1 --- [io-14569-exec-1] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Check Account Security] Checking....
  20:14:54.625 [ts-security-service] 2024-12-07 20:14:54.625 INFO 1 --- [io-11188-exec-4] security.service.SecurityServiceImpl : [Security Service] Max In One Hour: 2147483647 Max Not Use: 21474836
  20:14:54.643 [ts-preserve-other-service] 2024-12-07 20:14:54.643 INFO 1 --- [io-14569-exec-1] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] TripId: Z1234
  20:14:55.048 [ts-seat-service] 2024-12-07 20:14:55.048 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService] TrainNumber start with other capital
  20:14:55.102 [ts-order-other-service] 2024-12-07 20:14:55.102 INFO 1 --- [io-12032-exec-8] other.service.OrderOtherServiceImpl : [Order Other Service][Create Order] Ready Create Order
  20:14:55.145 [ts-preserve-other-service] 2024-12-07 20:14:55.145 INFO 1 --- [io-14569-exec-1] p.service.PreserveOtherServiceImpl : [Cancel Order Service][Get Order By Id]
  20:15:00.563 [ts-auth-service] 2024-12-07 20:15:00.562 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice

## p0215
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T07:41:44.648Z
```
{"timestamp":1731915704648890600,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  07:41:43.653 [currencyservice] conversion request successful  (×16)
  07:41:43.804 [currencyservice] Getting supported currencies...  (×4)
All services, 30 seconds either side (sampled):
  07:41:14.895 [frontend] request started  (×305)
  07:41:14.903 [cartservice] GetCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×249)
  07:41:14.939 [adservice] received ad request (context_words=[footwear])  (×10)
  07:41:15.385 [adservice] received ad request (context_words=[accessories])  (×31)
  07:41:15.883 [frontend] ENV_PLATFORM is: aws  (×37)
  07:41:16.999 [adservice] received ad request (context_words=[decor, home])  (×25)
  07:41:17.089 [shippingservice] [GetQuote] completed request  (×69)
  07:41:19.753 [adservice] received ad request (context_words=[clothing, tops])  (×12)
  07:41:23.032 [redis] 78:C 18 Nov 2024 07:41:23.032 * DB saved on disk
  07:41:30.267 [frontend] placing order  (×10)
  07:41:30.291 [paymentservice] Transaction processed: visa ending 6239 Amount: TRY1678.834176026  (×2)
  07:41:30.295 [shippingservice] [ShipOrder] completed request  (×10)
  07:41:30.306 [checkoutservice] order confirmation email sent to "shanehudson@example.org"
  07:41:43.889 [checkoutservice] [PlaceOrder] user_id="33421b66-55b6-413b-9ba9-3230c85c58dc" user_currency="GBP"  (×3)
  07:41:43.926 [emailservice] A request to send order confirmation email to nicoleanderson@example.com has been received.
  07:41:45.192 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"1042","nanos":326559925},"credit_card":{"credit_card_number":"4491744647902  (×2)
  07:41:45.209 [emailservice] A request to send order confirmation email to nicholasduran@example.org has been received.
  07:41:49.165 [paymentservice] Transaction processed: visa ending 4058 Amount: USD563.200000000
  07:41:59.364 [checkoutservice] [PlaceOrder] user_id="736a09b5-665e-4823-8520-b8602b0bdbff" user_currency="JPY"
  07:41:59.397 [emailservice] A request to send order confirmation email to hardykelli@example.org has been received.
  07:42:02.036 [checkoutservice] order confirmation email sent to "rhonda65@example.com"
  07:42:06.159 [checkoutservice] [PlaceOrder] user_id="fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a" user_currency="EUR"
  07:42:06.196 [emailservice] A request to send order confirmation email to charles74@example.org has been received.
  07:42:07.614 [checkoutservice] order confirmation email sent to "wramos@example.com"

## p0840
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-08T12:53:21.767Z
```
{"timestamp":1733662401767901200,"container_name":"ts-auth-service","pod_name":"ts-auth-service-75dfb9459b-rwqjk","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:53:21.767  INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl       : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iXSwiaWQiOiI0YzdlZjM3Yy1lOGNiLTRkMjktYWFjYS02MmJkN2E4ZGE5ODUiLCJpYXQiOjE3MzM2NjI0MDEsImV4cCI6MTczMzY2NjAwMX0.xoLNjXvBcooMv-lwg6W2fd5v6kSbIa3OiRhMwsEibqgUSER TOKEN"}
```
Same service, the 2 minutes before (oldest first):
  12:53:12.369 [ts-auth-service] 2024-12-08 12:53:12.369 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×4)
  12:53:12.369 [ts-auth-service] 2024-12-08 12:53:12.369 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : 4c7ef37c-e8cb-4d29-aaca-62bd7a8da985 USER ID  (×4)
  12:53:13.080 [ts-auth-service] 2024-12-08 12:53:13.079 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  12:53:13.080 [ts-auth-service] 2024-12-08 12:53:13.079 INFO 1 --- [io-12340-exec-4] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  12:53:14.169 [ts-auth-service] 2024-12-08 12:53:14.168 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×3)
  12:53:14.169 [ts-auth-service] 2024-12-08 12:53:14.168 INFO 1 --- [io-12340-exec-8] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×3)
  12:53:16.973 [ts-auth-service] 2024-12-08 12:53:16.973 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  12:53:16.973 [ts-auth-service] 2024-12-08 12:53:16.973 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  12:53:17.176 [ts-auth-service] 2024-12-08 12:53:17.176 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI
  12:53:17.176 [ts-auth-service] 2024-12-08 12:53:17.176 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID
All services, 30 seconds either side (sampled):
  12:52:52.877 [ts-auth-service] 2024-12-08 12:52:52.877 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×12)
  12:52:53.091 [ts-route-service] 2024-12-08 12:52:53.091 INFO 1 --- [io-11178-exec-5] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×195)
  12:52:53.146 [ts-route-service] 2024-12-08 12:52:53.146 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: f3d4d4ef-693b-4456-8eed-59c0d717dd08  (×23)
  12:52:55.818 [ts-auth-service] 2024-12-08 12:52:55.817 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  12:52:56.016 [ts-travel-service] 2024-12-08 12:52:56.015 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×2)
  12:52:56.080 [ts-travel2-service] 2024-12-08 12:52:56.079 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×122)
  12:53:00.521 [ts-auth-service] 2024-12-08 12:53:00.521 INFO 1 --- [io-12340-exec-1] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×8)
  12:53:00.761 [ts-basic-service] 2024-12-08 12:53:00.760 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×3)
  12:53:00.787 [ts-basic-service] 2024-12-08 12:53:00.787 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1  (×9)
  12:53:00.851 [ts-travel2-service] 2024-12-08 12:53:00.851 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sun Dec 08 00:00:00 GMT 2024,   (×20)
  12:53:00.882 [ts-order-other-service] 2024-12-08 12:53:00.882 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=178781  (×7)
  12:53:00.969 [ts-order-other-service] 2024-12-08 12:53:00.968 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=178781
  12:53:11.746 [ts-order-mongo] {"t":{"$date":"2024-12-08T12:53:11.745+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366239
  12:53:12.375 [ts-preserve-mongo] {"t":{"$date":"2024-12-08T12:53:12.374+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366239
  12:53:13.372 [ts-basic-service] 2024-12-08 12:53:13.371 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×5)
  12:53:13.479 [ts-seat-service] 2024-12-08 12:53:13.478 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×2)
  12:53:14.038 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-08T12:53:14.038+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366239
  12:53:15.495 [ts-food-mongo] {"t":{"$date":"2024-12-08T12:53:15.494+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366239
  12:53:19.667 [ts-order-other-service] 2024-12-08 12:53:19.667 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : Stations name list is : Response(status=1, msg=Success, data=[Shang H
  12:53:23.827 [ts-travel-service] 2024-12-08 12:53:23.827 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Travel Service] Query TripResponse
  12:53:24.006 [ts-basic-service] 2024-12-08 12:53:24.006 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
  12:53:24.071 [ts-travel-service] 2024-12-08 12:53:24.071 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×4)
  12:53:24.210 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:53:24 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 339 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe
  12:53:30.451 [ts-food-map-service] 2024-12-08 12:53:30.451 INFO 1 --- [io-18855-exec-2] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×2)
  12:53:33.169 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:53:33 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 200 64716 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) App
  12:53:37.118 [ts-basic-service] 2024-12-08 12:53:37.118 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×2)
  12:53:37.155 [ts-basic-service] 2024-12-08 12:53:37.155 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing

## p0478
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:17:40.902Z
```
{"timestamp":1732349860902793700,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"npm verb stack Error: command failed"}
```
Same service, the 2 minutes before (oldest first):
  08:17:39.797 [front-end] POST to carts: http://carts/carts/67418f9ea437380001def4a4/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  08:17:39.832 [front-end] POST /cart 201 - ms - -
  08:17:40.245 [front-end] Request received with body: {}
  08:17:40.254 [front-end] Received response: "{\"firstName\":\"jJNyNCzx\",\"lastName\":\"jJNyNCzx\",\"username\":\"jJNyNCzx\",\"id\":\"67418f8ea437380001def475\",\"_links\":{\"addresses\
  08:17:40.254 [front-end] GET Request to: http://user/customers/67418f8ea437380001def475/addresses  (×2)
  08:17:40.261 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418f96a437380001def489\",\"_links\":{\"
  08:17:40.261 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418
  08:17:40.261 [front-end] [ undefined, undefined ]
  08:17:40.261 [front-end] Posting Order: {"customer":"http://user/customers/67418f8ea437380001def475","address":"http://user/addresses/67418f96a437380001def488","card":"http://user/cards
  08:17:40.283 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732349860280,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde
  08:17:40.283 [front-end] Order response: {"timestamp":1732349860280,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli
  08:17:40.285 [front-end] POST /orders 406 - ms - -
  08:17:40.900 [front-end] npm timing command:run-script Completed in 795498ms
  08:17:40.900 [front-end] npm timing command:start Completed in 795556ms
  08:17:40.900 [front-end] npm notice   (×2)
  08:17:40.900 [front-end] npm notice New major version of npm available! 8.19.4 -> 10.9.1
  08:17:40.900 [front-end] npm notice Changelog: <https://github.com/npm/cli/releases/tag/v10.9.1>
  08:17:40.900 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!
All services, 30 seconds either side (sampled):
  08:17:11.123 [front-end] Posting Customer: {"username":"QRhdA","password":"HNBUiuhCFK","email":"QRhdA@gmail.com","firstName":"QRhdA","lastName":"QRhdA"}
  08:17:11.402 [user] ts=2024-11-23T08:17:11.402696116Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418f7ea437380001def440 took=3.96969ms  (×49)
  08:17:11.497 [front-end] POST to carts: http://carts/carts/67418f7ea437380001def440/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×25)
  08:17:11.791 [front-end] Posting Order: {"customer":"http://user/customers/67418f76a437380001def427","address":"http://user/addresses/67418f7ea437380001def443","card":"http://user/cards  (×50)
  08:17:11.817 [queue-master] 2024-11-23 08:17:11.817 ERROR 7 --- [ool-6-thread-31] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×20)
  08:17:12.383 [catalogue] ts=2024-11-23T08:17:12Z caller=logging.go:85 method=Health result=2 took=25.962µs  (×40)
  08:17:13.850 [user] ts=2024-11-23T08:17:13.850301423Z caller=middlewares.go:157 method=Health result=2 took=2.694113ms  (×40)
  08:17:16.173 [front-end] Order response: {"id":"67418f8c3f77060008865085","customerId":"67418f74a437380001def422","customer":{"id":null,"firstName":"bTsDpZbGpl","lastName":"bTsDpZbGpl",
  08:17:16.995 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×11)
  08:17:18.715 [front-end] Posting Customer: {"username":"AHLEGfzWOkJSK","password":"WZnyHLi","email":"AHLEGfzWOkJSK@gmail.com","firstName":"AHLEGfzWOkJSK","lastName":"AHLEGfzWOkJSK"}
  08:17:20.207 [front-end] Received response: "{\"firstName\":\"eXwxPKpvOLhZ\",\"lastName\":\"eXwxPKpvOLhZ\",\"username\":\"eXwxPKpvOLhZ\",\"id\":\"67418f7da437380001def43e\",\"_links\":{
  08:17:22.446 [front-end] Order response: {"id":"67418f923f7706000886508d","customerId":"67418f7aa437380001def431","customer":{"id":null,"firstName":"QyeRRnQZmNfKX","lastName":"QyeRRnQZm
  08:17:24.854 [front-end] Received response: "{\"firstName\":\"hDADdujiVgp\",\"lastName\":\"hDADdujiVgp\",\"username\":\"hDADdujiVgp\",\"id\":\"67418f7ca437380001def439\",\"_links\":{\"a
  08:17:27.573 [front-end] Order response: {"id":"67418f973f77060008865091","customerId":"67418f83a437380001def457","customer":{"id":null,"firstName":"HwJeJftl","lastName":"HwJeJftl","use
  08:17:28.253 [front-end] npm timing npm:load:whichnode Completed in 0ms  (×2)
  08:17:28.253 [front-end] npm timing config:load:validate Completed in 1ms  (×2)
  08:17:28.254 [front-end] npm timing npm:load:display Completed in 8ms  (×2)
  08:17:29.112 [queue-master] 2024-11-23 08:17:29.112 INFO 7 --- [pool-6-thread-3] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×24)
  08:17:30.858 [front-end] Using the redis based session manager
  08:17:32.825 [front-end] Order response: {"id":"67418f9c3f77060008865097","customerId":"67418f83a437380001def45a","customer":{"id":null,"firstName":"pOdFHAXyWrS","lastName":"pOdFHAXyWrS
  08:17:34.861 [front-end] Posting Customer: {"username":"bwDjbwXxI","password":"KnrQLgvYFB","email":"bwDjbwXxI@gmail.com","firstName":"bwDjbwXxI","lastName":"bwDjbwXxI"}
  08:17:36.195 [front-end] Posting Customer: {"username":"LSoIyTnpnDI","password":"TJJqPCKCj","email":"LSoIyTnpnDI@gmail.com","firstName":"LSoIyTnpnDI","lastName":"LSoIyTnpnDI"}
  08:17:39.264 [front-end] Order response: {"id":"67418fa33f7706000886509b","customerId":"67418f90a437380001def47a","customer":{"id":null,"firstName":"qEFqyOJF","lastName":"qEFqyOJF","use
  08:17:40.900 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!  (×2)
  08:17:40.904 [front-end] npm ERR! command failed  (×2)
  08:17:48.008 [front-end] Posting Customer: {"username":"EPQaiJm","password":"lypRom","email":"EPQaiJm@gmail.com","firstName":"EPQaiJm","lastName":"EPQaiJm"}
  08:17:52.024 [front-end] Posting Order: {"customer":"http://user/customers/67418f9fa437380001def4a8","address":null,"card":null,"items":"http://carts/carts/67418f9fa437380001def4a8/item  (×6)
  08:17:56.736 [front-end] Posting Customer: {"username":"oYJYFgYFnZzQlq","password":"VVPjLX","email":"oYJYFgYFnZzQlq@gmail.com","firstName":"oYJYFgYFnZzQlq","lastName":"oYJYFgYFnZzQlq"}
  08:18:01.550 [front-end] Received response: "{\"firstName\":\"fhvyKaGX\",\"lastName\":\"fhvyKaGX\",\"username\":\"fhvyKaGX\",\"id\":\"67418fa3a437380001def4b7\",\"_links\":{\"addresses\
  08:18:07.314 [front-end] Received response: "{\"firstName\":\"EPQaiJm\",\"lastName\":\"EPQaiJm\",\"username\":\"EPQaiJm\",\"id\":\"67418faca437380001def4c0\",\"_links\":{\"addresses\":{

## p0580
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T18:31:19.687Z
```
{"timestamp":1733596279687995600,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-kwkx6","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"edu.fudan.common.exception.TokenException: Token is not properly constructed\n\tat edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-common-0.1.0.jar!/:0.1.0]\n\tat edu.fudan.common.security.jwt.JWTUtil.getJWTAuthentication(JWTUtil.java:36) ~[ts-common-0.1.0.jar!/:0.1.0]\n\tat edu.fudan.common.security.jwt.JWTFilter.doFilterInternal(JWTFilter.java:25) ~[ts-common-0.1.0.jar!/:0.1…"}
```
Same service, the 2 minutes before (oldest first):
  18:31:12.187 [ts-travel2-service] 2024-12-07 18:31:12.187 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  18:31:12.214 [ts-travel2-service] 2024-12-07 18:31:12.213 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024, 
  18:31:12.223 [ts-travel2-service] 2024-12-07 18:31:12.223 INFO 1 --- [io-16346-exec-8] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236
  18:31:12.225 [ts-travel2-service] 2024-12-07 18:31:12.224 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×3)
  18:31:12.229 [ts-travel2-service] 2024-12-07 18:31:12.229 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×3)
  18:31:12.230 [ts-travel2-service] 2024-12-07 18:31:12.229 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  18:31:12.264 [ts-travel2-service] 2024-12-07 18:31:12.264 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6
  18:31:12.271 [ts-travel2-service] 2024-12-07 18:31:12.270 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×2)
  18:31:19.676 [ts-travel2-service] 2024-12-07 18:31:19.676 ERROR 1 --- [io-16346-exec-2] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×2)
  18:31:19.676 [ts-travel2-service] 2024-12-07 18:31:19.676 ERROR 1 --- [o-16346-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:31:19.687 [ts-travel2-service] 2024-12-07 18:31:19.687 ERROR 1 --- [io-16346-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  18:31:19.687 [ts-travel2-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  18:31:19.687 [ts-travel2-service] 2024-12-07 18:31:19.687 ERROR 1 --- [o-16346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
All services, 30 seconds either side (sampled):
  18:30:49.754 [ts-auth-service] 2024-12-07 18:30:49.754 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricsFilter' to: [/*]  (×8)
  18:30:50.730 [ts-basic-service] 2024-12-07 18:30:50.730 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×12)
  18:30:50.773 [ts-basic-service] 2024-12-07 18:30:50.773 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×8)
  18:30:50.831 [ts-seat-service] 2024-12-07 18:30:50.831 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×17)
  18:30:50.942 [ts-seat-service] 2024-12-07 18:30:50.942 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×12)
  18:30:52.330 [ts-admin-basic-info-service] 2024-12-07 18:30:52.330 INFO 1 --- [io-18767-exec-1] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×5)
  18:30:53.648 [ts-order-other-service] 2024-12-07 18:30:53.648 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×7)
  18:30:57.104 [ts-seat-service] 2024-12-07 18:30:57.104 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  18:30:58.092 [ts-travel2-service] 2024-12-07 18:30:58.092 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  18:31:00.335 [ts-order-other-service] java.lang.IllegalArgumentException: Invalid UUID string: at java.util.UUID.fromString(UUID.java:194) ~[na:1.8.0_402] at other.service.OrderOtherServiceImpl.quer  (×3)
  18:31:01.656 [ts-auth-service] 2024-12-07 18:31:01.655 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  18:31:03.828 [ts-travel-service] 2024-12-07 18:31:03.828 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×25)
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  18:31:03.871 [ts-auth-service] 2024-12-07 18:31:03.871 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  18:31:03.909 [ts-travel-service] 2024-12-07 18:31:03.909 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×5)
  18:31:04.007 [ts-travel-service] 2024-12-07 18:31:04.006 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×10)
  18:31:05.567 [ts-auth-service] 2024-12-07 18:31:05.566 INFO 1 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in globalExceptionHandler
  18:31:08.782 [ts-auth-service] 2024-12-07 18:31:08.782 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'methodSecurityMetadataSource' of type [org.springframework.security.
  18:31:10.954 [ts-auth-service] 2024-12-07 18:31:10.953 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.907 seconds (JVM running for 71.147)
  18:31:11.909 [ts-basic-service] 2024-12-07 18:31:11.909 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f
  18:31:12.420 [ts-travel-service] 2024-12-07 18:31:12.420 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='a3f256c1-0e43-4f7d-9c21-121bf258101f', stations=[nan
  18:31:18.474 [ts-auth-service] 2024-12-07 18:31:18.474 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×9)
  18:31:19.676 [ts-travel2-service] 2024-12-07 18:31:19.676 ERROR 1 --- [io-16346-exec-2] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×9)
  18:31:27.257 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:31:27.257+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.270 [ts-admin-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×5)
  18:31:29.947 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:31:29.947+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  18:31:38.105 [ts-admin-travel-service] 2024-12-07 18:31:38.104 ERROR 1 --- [o-16114-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt

## p0107
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:09:42.462Z
```
{"timestamp":1731906582462488600,"container_name":"adservice","pod_name":"adservice-b9bcc6cc9-h4k2c","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"received ad request (context_words=[kitchen])"}
```
Same service, the 2 minutes before (oldest first):
  05:09:36.831 [adservice] received ad request (context_words=[decor, home])
  05:09:37.000 [adservice] received ad request (context_words=[accessories])  (×5)
  05:09:37.918 [adservice] received ad request (context_words=[kitchen])  (×6)
  05:09:38.211 [adservice] received ad request (context_words=[])  (×5)
  05:09:39.257 [adservice] received ad request (context_words=[clothing, tops])
  05:09:40.950 [adservice] received ad request (context_words=[hair, beauty])
  05:09:42.442 [adservice] received ad request (context_words=[footwear])
All services, 30 seconds either side (sampled):
  05:09:12.465 [adservice] received ad request (context_words=[footwear])  (×23)
  05:09:12.868 [frontend] home  (×36)
  05:09:12.882 [currencyservice] conversion request successful  (×815)
  05:09:13.359 [frontend] serving product page  (×148)
  05:09:14.036 [frontend] setting currency  (×21)
  05:09:14.671 [adservice] received ad request (context_words=[accessories])  (×35)
  05:09:14.691 [frontend] view user cart  (×76)
  05:09:14.713 [shippingservice] [GetQuote] completed request  (×92)
  05:09:17.920 [frontend] placing order  (×16)
  05:09:17.948 [paymentservice] Transaction processed: visa ending 3846 Amount: CAD316.972079616  (×5)
  05:09:17.951 [shippingservice] [ShipOrder] completed request  (×15)
  05:09:17.962 [checkoutservice] order confirmation email sent to "christinaware@example.net"
  05:09:18.724 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"258141","nanos":112782864},"credit_card":{"credit_card_number":"44867658366  (×4)
  05:09:18.740 [checkoutservice] order confirmation email sent to "dconner@example.com"
  05:09:20.431 [emailservice] A request to send order confirmation email to garciajessica@example.com has been received.
  05:09:28.202 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"205","nanos":210123835},"credit_card":{"credit_card_number":"48097360046457  (×2)
  05:09:28.217 [checkoutservice] order confirmation email sent to "edwardslarry@example.com"
  05:09:30.671 [frontend] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
  05:09:30.692 [paymentservice] }
  05:09:31.202 [emailservice] A request to send order confirmation email to kramerkatherine@example.com has been received.
  05:09:39.812 [checkoutservice] order confirmation email sent to "janice63@example.net"
  05:09:46.382 [paymentservice] Transaction processed: visa ending 6282 Amount: EUR2592.65457790  (×3)
  05:09:46.446 [emailservice] A request to send order confirmation email to richard26@example.net has been received.
  05:09:49.026 [emailservice] A request to send order confirmation email to erin73@example.org has been received.
  05:09:52.127 [paymentservice] Transaction processed: visa ending 4346 Amount: USD673.830000000
  05:10:03.124 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '6E92ZMYYFZ']  (×2)
  05:10:08.815 [emailservice] A request to send order confirmation email to tracey70@example.net has been received.
  05:10:09.202 [checkoutservice] order confirmation email sent to "bryantshane@example.com"

## p0263
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:15.906Z
```
{"timestamp":1732242495906753000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"{ id: '673fec3fb0df5c00019af987' }"}
```
Same service, the 2 minutes before (oldest first):
  02:28:14.317 [front-end] 673fec3eb0df5c00019af985  (×2)
  02:28:14.317 [front-end] Merging carts for customer id: 673fec3eb0df5c00019af985 and session id: y5_hKG3jcMa48JRLX0HxhdItvM_uuPGj  (×2)
  02:28:14.337 [front-end] Carts merged.
  02:28:14.337 [front-end] set cookie673fec3eb0df5c00019af985
  02:28:14.337 [front-end] Sent cookies.
  02:28:14.339 [front-end] POST /register 200 27.005 ms - 33
  02:28:15.632 [front-end] GET /catalogue 200 - ms - -
  02:28:15.696 [front-end] Posting Customer: {"username":"NGQZYvsdKz","password":"rioCzg","email":"NGQZYvsdKz@gmail.com","firstName":"NGQZYvsdKz","lastName":"NGQZYvsdKz"}
  02:28:15.701 [front-end] { id: '673fec3fb0df5c00019af986' }
  02:28:15.891 [front-end] Request received with body: {}
  02:28:15.896 [front-end] Received response: "{\"firstName\":\"rcABXsHV\",\"lastName\":\"rcABXsHV\",\"username\":\"rcABXsHV\",\"id\":\"673fec2ab0df5c00019af943\",\"_links\":{\"addresses\
  02:28:15.896 [front-end] GET Request to: http://user/customers/673fec2ab0df5c00019af943/addresses  (×2)
  02:28:15.903 [front-end] Posting Customer: {"username":"tWrduaLeWjJ","password":"FQckBqInY","email":"tWrduaLeWjJ@gmail.com","firstName":"tWrduaLeWjJ","lastName":"tWrduaLeWjJ"}
  02:28:15.905 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec2fb0df5c00019af958\",\"_links\":{\"
  02:28:15.905 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:15.905 [front-end] [ undefined, undefined ]
  02:28:15.905 [front-end] Posting Order: {"customer":"http://user/customers/673fec2ab0df5c00019af943","address":"http://user/addresses/673fec2fb0df5c00019af957","card":"http://user/cards
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×41)
  02:28:03.174 [front-end] User cart deleted with status: 503  (×41)
  02:28:03.202 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×42)
  02:28:03.249 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×17)
  02:28:03.410 [front-end] Carts merged.  (×39)
  02:28:04.973 [front-end] Posting Customer: {"username":"HFHBXn","password":"EOgUhihln","email":"HFHBXn@gmail.com","firstName":"HFHBXn","lastName":"HFHBXn"}
  02:28:05.351 [user] ts=2024-11-22T02:28:05.351787827Z caller=middlewares.go:46 method=Register username=vuOxCKL email=vuOxCKL@gmail.com took=4.581531ms
  02:28:08.095 [front-end] Received response: "{\"firstName\":\"RsyjMQXEZqDOIBa\",\"lastName\":\"RsyjMQXEZqDOIBa\",\"username\":\"RsyjMQXEZqDOIBa\",\"id\":\"673fec1eb0df5c00019af912\",\"_
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:15.136 [carts] 2024-11-22 02:28:15.041 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 160.989 seconds (JVM running for 167.0
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:22.317 [front-end] Received response: "{\"firstName\":\"JGQXvUjPbFrtK\",\"lastName\":\"JGQXvUjPbFrtK\",\"username\":\"JGQXvUjPbFrtK\",\"id\":\"673fec34b0df5c00019af964\",\"_links\
  02:28:23.143 [orders] 2024-11-22 02:28:23.143 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×9)
  02:28:24.588 [shipping] Adding shipment to queue...  (×24)
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:26.156 [front-end] POST /cart 201 - ms - -  (×26)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d8","customerId":"673fec2cb0df5c00019af949","customer":{"id":null,"firstName":"KoWsmDtUqsE
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:30.547 [front-end] Received response: "{\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\",\"username\":\"vvgsHcY\",\"id\":\"673fec35b0df5c00019af968\",\"_links\":{\"addresses\":{
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.645 [queue-master] 2024-11-22 02:28:32.645 INFO 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×15)
  02:28:37.005 [user] ts=2024-11-22T02:28:37.005380807Z caller=middlewares.go:46 method=Register username=XTqSaA email=XTqSaA@gmail.com took=624.562µs
  02:28:40.136 [front-end] Order response: {"id":"673fec58d94b9000069b39dc","customerId":"673fec41b0df5c00019af98b","customer":{"id":null,"firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe",
  02:28:41.723 [user] ts=2024-11-22T02:28:41.723279742Z caller=middlewares.go:46 method=Register username=yaELjpCD email=yaELjpCD@gmail.com took=1.302265ms
  02:28:43.812 [front-end] Order response: {"id":"673fec5bd94b9000069b39e0","customerId":"673fec47b0df5c00019af996","customer":{"id":null,"firstName":"bhZuEQ","lastName":"bhZuEQ","usernam
  02:28:45.163 [front-end] Received response: "{\"firstName\":\"oqYeDriHaX\",\"lastName\":\"oqYeDriHaX\",\"username\":\"oqYeDriHaX\",\"id\":\"673fec49b0df5c00019af999\",\"_links\":{\"addr

## p0059
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-13T08:39:06.674Z
```
{"service":"webservice1","message":"2021-08-13 08:39:06,674 | INFO | 0.0.0.1 | 172.17.0.3 | webservice1 | 826c193fee1f61b6 | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  08:39:03.624 [webservice1] INFO uuid: dbdf2a58-fbce-11eb-b761-0242ac110003 write redis successfully  (×3)
  08:39:03.729 [webservice1] INFO complete information: {'uuid': 'dbdf2a58-fbce-11eb-b761-0242ac110003', 'user_id': 'tvuRByVz'}  (×3)
  08:39:03.739 [webservice1] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×3)
  08:39:03.740 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
  08:39:04.183 [webservice1] ERROR an error occurred in the downstream service  (×2)
  08:39:05.124 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  08:39:05.125 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×2)
  08:39:05.125 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'dccd0976-fbce-11eb-af06-0242ac110003', 'value': '', 'ex': 10}  (×2)
All services, 30 seconds either side (sampled):
  08:38:36.683 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×49)
  08:38:36.770 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'cbbdf6fe-fbce-11eb-a94a-0242ac110004', 'value': 'zrnyoxBF'}  (×47)
  08:38:36.870 [redisservice2] INFO redis读取信息成功, status_code: 200  (×53)
  08:38:36.971 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  08:38:37.165 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×61)
  08:38:37.548 [webservice2] INFO uuid: cc4e5208-fbce-11eb-b940-0242ac110004 write redis successfully  (×49)
  08:38:38.127 [redisservice2] INFO service accept, status_code: 200  (×32)
  08:38:38.460 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×49)
  08:38:38.775 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×41)
  08:38:39.665 [redisservice1] INFO redis读取信息成功, status_code: 200  (×46)
  08:38:41.880 [mobservice1] INFO info cebd3838-fbce-11eb-b180-0242ac110003:AGLgdhsM write success
  08:38:44.477 [dbservice1] INFO d0116a92-fbce-11eb-abd8-0242ac110004-wRjEsaDr-6yOCQJ=RzT1( token generate success token=MTYyODgxNTEyNC40NzcwMTIyOmQwMTE2YTkyLWZiY2UtMTFlYi1hYmQ4LTAyNDJhYzE
  08:38:47.399 [mobservice2] INFO info d2067ea0-fbce-11eb-9800-0242ac110003:TPLgkydZ write success
  08:38:50.393 [mobservice2] INFO info d3dd2e5e-fbce-11eb-ad10-0242ac110004:lzeSVXuM write success
  08:38:53.411 [mobservice1] INFO info d59e824c-fbce-11eb-b024-0242ac110003:zHhwQRUN write success
  08:38:55.773 [mobservice2] INFO info d70c1504-fbce-11eb-bea3-0242ac110004:WitlFQzD write success
  08:38:58.572 [mobservice2] INFO info d8b413e8-fbce-11eb-8297-0242ac110003:WtfwAnYv write success
  08:39:00.896 [mobservice2] INFO info da19c476-fbce-11eb-aec4-0242ac110004:BWwoGkgb write success
  08:39:04.551 [mobservice2] INFO info dc499758-fbce-11eb-a277-0242ac110004:lkNrGYTL write success
  08:39:07.010 [mobservice2] INFO info ddb98936-fbce-11eb-b27b-0242ac110003:JuoeTjfH write success
  08:39:10.195 [mobservice1] INFO info df9e1a50-fbce-11eb-931c-0242ac110003:lmvshOqT write success
  08:39:13.322 [mobservice2] INFO info e1782cb2-fbce-11eb-9bd9-0242ac110003:hLXtpSzb write success
  08:39:16.230 [mobservice2] INFO info e3420b80-fbce-11eb-a87a-0242ac110004:kmlOKZGI write success
  08:39:19.882 [mobservice1] INFO info e571d0ca-fbce-11eb-90a2-0242ac110004:fegJlQaO write success
  08:39:23.331 [mobservice1] INFO info e76a61bc-fbce-11eb-8328-0242ac110004:SxCJORXF write success
  08:39:26.068 [dbservice1] INFO e8de9b30-fbce-11eb-aa68-0242ac110003-idmPHWUK-/6^rvD(3hS-C token generate success token=MTYyODgxNTE2Ni4wNjc5MDM1OmU4ZGU5YjMwLWZiY2UtMTFlYi1hYTY4LTAyNDJhYzE
  08:39:28.655 [dbservice1] INFO ea6672b6-fbce-11eb-8e79-0242ac110003-jhoAGDST-%RJ/0?B1fm4L token generate success token=MTYyODgxNTE2OC42NTU0Mjk2OmVhNjY3MmI2LWZiY2UtMTFlYi04ZTc5LTAyNDJhYzE
  08:39:31.334 [mobservice1] INFO info ec3e43fc-fbce-11eb-9f4c-0242ac110003:SpsReQKd write success
  08:39:34.472 [mobservice1] INFO info ee1770e0-fbce-11eb-8f75-0242ac110003:ljJOtheS write success

## p0087
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T15:30:27.504Z
```
{"service":"dbservice1","message":"2021-08-13 15:30:27,504 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | cdb7a523e44c407e | 5406bbf2-fc08-11eb-9749-0242ac110004-eJFaBQoW-bScmY_uD{wZ* token generate success token=MTYyODgzOTgyNy41MDQwNzQ4OjU0MDZiYmYyLWZjMDgtMTFlYi05NzQ5LTAyNDJhYzExMDAwNGVKRmFCUW9XYlNjbVlfdUR7d1oqOjE2Mjg4Mzk4ODcuNTA0MDg2NTpjZDZkMjQ0ZDljZDVjMWQ1Y2Y3MDJkMWE2OTU1ZjAzYw=="}
```
Same service, the 2 minutes before (oldest first):
  15:30:23.001 [dbservice1] INFO 516b5e84-fc08-11eb-ba92-0242ac110004-jrKReZbn-{Y&*CIcr/x!j token generate success token=MTYyODgzOTgyMy4wMDEyMjg6NTE2YjVlODQtZmMwOC0xMWViLWJhOTItMDI0MmFjMTE
  15:30:23.659 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  15:30:23.659 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  15:30:23.766 [dbservice1] INFO query = select passwards from username_table where user_name='VkYhsQXg'  (×5)
  15:30:23.848 [dbservice1] INFO 5206b79e-fc08-11eb-bbfe-0242ac110004-VkYhsQXg-wW@U3A6^R4)_ token generate success token=MTYyODgzOTgyMy44NDg0ODU1OjUyMDZiNzllLWZjMDgtMTFlYi1iYmZlLTAyNDJhYzE
  15:30:24.342 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  15:30:24.617 [dbservice1] INFO 52872cf8-fc08-11eb-ab1f-0242ac110004-YDlFxnqQ-iMP+NGt?ac=y token generate success token=MTYyODgzOTgyNC42MTY3MDExOjUyODcyY2Y4LWZjMDgtMTFlYi1hYjFmLTAyNDJhYzE
  15:30:25.373 [dbservice1] INFO 52fa50c0-fc08-11eb-a23b-0242ac110003-IpBPDOnW-DkL)pg*/+hK$ token generate success token=MTYyODgzOTgyNS4zNzI2MjQ5OjUyZmE1MGMwLWZjMDgtMTFlYi1hMjNiLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  15:29:57.512 [webservice1] INFO uuid: 42bdf612-fc08-11eb-b9fb-0242ac110003 write redis successfully  (×39)
  15:29:57.696 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '42bdf612-fc08-11eb-b9fb-0242ac110003'}  (×50)
  15:29:57.913 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '42bdf612-fc08-11eb-b9fb-0242ac110003'}  (×47)
  15:29:58.019 [logservice1] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '42bdf612-fc08-11eb-b9fb-0242ac110003', 'user_id': 'WHeAwPqY'}  (×82)
  15:29:58.313 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×43)
  15:29:58.649 [mobservice2] INFO info 433f10c6-fc08-11eb-9acf-0242ac110004:IvLqACZF write success
  15:29:58.805 [logservice2] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×35)
  15:29:59.666 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  15:30:00.007 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×40)
  15:30:01.101 [mobservice2] INFO info 44b64866-fc08-11eb-b35b-0242ac110004:AJYfIiku write success
  15:30:03.573 [mobservice2] INFO info 46250912-fc08-11eb-a2b1-0242ac110003:XbWNMUJl write success
  15:30:06.198 [mobservice2] INFO info 47aa48a6-fc08-11eb-8f45-0242ac110004:ycKvOJwP write success  (×2)
  15:30:09.131 [dbservice2] INFO 4903fddc-fc08-11eb-97a2-0242ac110004-xjYUMcml-^4(_{v<kmK}e token generate success token=MTYyODgzOTgwOS4xMzE0NDI6NDkwM2ZkZGMtZmMwOC0xMWViLTk3YTItMDI0MmFjMTE
  15:30:11.163 [mobservice2] INFO info 4aa6dae2-fc08-11eb-ae94-0242ac110003:HTxraybW write success
  15:30:13.249 [dbservice2] INFO 4bc77080-fc08-11eb-bc10-0242ac110003-PJMibIFO-5U{+BxgJH$VY token generate success token=MTYyODgzOTgxMy4yNDg0ODQxOjRiYzc3MDgwLWZjMDgtMTFlYi1iYzEwLTAyNDJhYzE
  15:30:15.366 [mobservice2] INFO info 4d28ce74-fc08-11eb-b1ae-0242ac110003:nzYLWZFG write success
  15:30:17.951 [mobservice1] INFO info 4eb977a2-fc08-11eb-a19a-0242ac110003:vUGVxSct write success
  15:30:20.559 [dbservice2] INFO 5016b3f8-fc08-11eb-8294-0242ac110004-YXLKvufE-RlNLZm@n6u!V token generate success token=MTYyODgzOTgyMC41NTg1MjU4OjUwMTZiM2Y4LWZjMDgtMTFlYi04Mjk0LTAyNDJhYzE
  15:30:22.421 [mobservice1] INFO info 516b5e84-fc08-11eb-ba92-0242ac110004:jrKReZbn write success
  15:30:24.617 [dbservice1] INFO 52872cf8-fc08-11eb-ab1f-0242ac110004-YDlFxnqQ-iMP+NGt?ac=y token generate success token=MTYyODgzOTgyNC42MTY3MDExOjUyODcyY2Y4LWZjMDgtMTFlYi1hYjFmLTAyNDJhYzE
  15:30:27.224 [dbservice2] INFO 53fd4482-fc08-11eb-9501-0242ac110004-NpSktBQI-ZNc-73/n1Rbm token generate success token=MTYyODgzOTgyNy4yMjM2MDU0OjUzZmQ0NDgyLWZjMDgtMTFlYi05NTAxLTAyNDJhYzE  (×3)
  15:30:29.957 [mobservice2] INFO info 55e69e60-fc08-11eb-98c9-0242ac110004:xomaJMly write success
  15:30:32.236 [dbservice2] INFO 5700267c-fc08-11eb-9d65-0242ac110004-ZnrSqIKU-6AR>9IyOXx/3 token generate success token=MTYyODgzOTgzMi4yMzU4NDUzOjU3MDAyNjdjLWZjMDgtMTFlYi05ZDY1LTAyNDJhYzE
  15:30:35.857 [mobservice2] INFO info 59677190-fc08-11eb-a910-0242ac110004:QPYaeVWt write success
  15:30:38.771 [mobservice2] INFO info 5b255d62-fc08-11eb-bb77-0242ac110004:gKPfDFAT write success
  15:30:41.005 [mobservice2] INFO info 5c7d24ba-fc08-11eb-b6c3-0242ac110004:CyQWkovZ write success
  15:30:44.477 [mobservice2] INFO info 5e8ee446-fc08-11eb-9f9c-0242ac110004:bsnOITed write success
  15:30:47.288 [mobservice1] INFO info 603d804a-fc08-11eb-8ada-0242ac110004:isocSGgr write success
  15:30:49.938 [mobservice2] INFO info 61d14d24-fc08-11eb-b831-0242ac110004:yAHjfLsg write success
  15:30:52.331 [dbservice2] INFO 63034a62-fc08-11eb-b049-0242ac110003-WQyFOAmB-#WsQM+91Ce2R token generate success token=MTYyODgzOTg1Mi4zMzA3MzIzOjYzMDM0YTYyLWZjMDgtMTFlYi1iMDQ5LTAyNDJhYzE

## p0179
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:39:37.124Z
```
{"timestamp":1731911977124724000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  06:39:36.203 [frontend] request started  (×6)
  06:39:36.203 [frontend] serving product page  (×2)
  06:39:36.207 [frontend] request complete  (×7)
  06:39:36.237 [frontend] adding to cart
  06:39:36.250 [frontend] view user cart  (×2)
  06:39:36.295 [frontend] placing order
  06:39:36.337 [frontend] order placed
All services, 30 seconds either side (sampled):
  06:39:07.126 [frontend] request complete  (×324)
  06:39:07.129 [cartservice] GetCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×268)
  06:39:07.248 [adservice] received ad request (context_words=[])  (×33)
  06:39:07.304 [frontend] setting currency  (×18)
  06:39:07.309 [currencyservice] Getting supported currencies...  (×267)
  06:39:08.058 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'LS4PSXUNUM', '6E92ZMYYFZ', 'OLJCESPC7Z', '0PUK6V6EV0']  (×227)
  06:39:08.168 [adservice] received ad request (context_words=[clothing, tops])  (×23)
  06:39:09.424 [frontend] view user cart  (×63)
  06:39:09.452 [shippingservice] [GetQuote] completed request  (×72)
  06:39:12.969 [frontend] adding to cart  (×36)
  06:39:12.998 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '66VCHSJNUP']  (×4)
  06:39:16.466 [adservice] received ad request (context_words=[accessories])  (×33)
  06:39:17.080 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="USD"
  06:39:17.101 [paymentservice] Transaction processed: visa ending 8827 Amount: USD36.440000000
  06:39:17.106 [shippingservice] [ShipOrder] received request  (×9)
  06:39:17.109 [cartservice] EmptyCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×9)
  06:39:17.114 [checkoutservice] failed to send order confirmation to "daniel87@example.net": rpc error: code = Unavailable desc = no healthy upstream
  06:39:18.031 [checkoutservice] [PlaceOrder] user_id="fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a" user_currency="CAD"  (×3)
  06:39:18.064 [paymentservice] Transaction processed: visa ending 1469 Amount: CAD2122.1415296  (×3)
  06:39:21.779 [recommendationservice] [Recv ListRecommendations] product_ids=['6E92ZMYYFZ', '9SIQT8TOJO', '66VCHSJNUP']  (×3)
  06:39:25.669 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"3446","nanos":830457302},"credit_card":{"credit_card_number":"4935368431810  (×2)
  06:39:25.681 [checkoutservice] failed to send order confirmation to "julie61@example.com": rpc error: code = Unavailable desc = no healthy upstream
  06:39:34.295 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', 'OLJCESPC7Z', '2ZYFJ3GM2N', 'LS4PSXUNUM']
  06:39:39.048 [checkoutservice] [PlaceOrder] user_id="c216dec4-2181-4773-8cc5-aa587ee59fcc" user_currency="EUR"  (×3)
  06:39:39.071 [paymentservice] Transaction processed: visa ending 8873 Amount: EUR133.20787266  (×3)
  06:39:55.762 [checkoutservice] failed to send order confirmation to "michaelford@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:40:05.433 [checkoutservice] failed to send order confirmation to "rogerstimothy@example.org": rpc error: code = Unavailable desc = no healthy upstream

## p0439
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service shipping, 2024-11-23T08:05:59.414Z
```
{"timestamp":1732349159414468600,"container_name":"shipping","pod_name":"shipping-58b65f576-rlt9r","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:05:59.414  INFO [shipping,,,] 7 --- [           main] o.s.w.s.handler.SimpleUrlHandlerMapping  : Mapped URL path [/webjars/**] onto handler of type [class org.springframework.web.servlet.resource.ResourceHttpRequestHandler]"}
```
Same service, the 2 minutes before (oldest first):
  08:05:54.899 [shipping] 2024-11-23 08:05:54.899 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produ
  08:05:54.899 [shipping] 2024-11-23 08:05:54.899 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public ja
  08:05:54.903 [shipping] 2024-11-23 08:05:54.903 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[a
  08:05:54.904 [shipping] 2024-11-23 08:05:54.904 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applica
  08:05:54.904 [shipping] 2024-11-23 08:05:54.904 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[applicati
  08:05:54.905 [shipping] 2024-11-23 08:05:54.905 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produce
  08:05:54.905 [shipping] 2024-11-23 08:05:54.905 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[a
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" on
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/jso
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto publi
  08:05:54.910 [shipping] 2024-11-23 08:05:54.910 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[applicati
  08:05:54.911 [shipping] 2024-11-23 08:05:54.911 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public 
  08:05:55.000 [shipping] 2024-11-23 08:05:55.000 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/js
  08:05:55.002 [shipping] 2024-11-23 08:05:55.002 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application
  08:05:55.008 [shipping] 2024-11-23 08:05:55.007 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applica
  08:05:55.102 [shipping] 2024-11-23 08:05:55.102 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object or
  08:05:55.103 [shipping] 2024-11-23 08:05:55.102 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map
  08:05:55.103 [shipping] 2024-11-23 08:05:55.103 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto publi
  08:05:57.198 [shipping] 2024-11-23 08:05:57.110 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.cont
  08:05:57.302 [shipping] 2024-11-23 08:05:57.301 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot
All services, 30 seconds either side (sampled):
  08:05:29.548 [front-end] Posting Customer: {"username":"yYxwhLWv","password":"VCHzKzip","email":"yYxwhLWv@gmail.com","firstName":"yYxwhLWv","lastName":"yYxwhLWv"}
  08:05:29.748 [front-end] DELETE /cart 503 - ms - -  (×56)
  08:05:30.358 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418cbea437380001deebf6\",\"_links\":{\"  (×65)
  08:05:31.295 [orders] 2024-11-23 08:05:31.292 INFO [orders,,,] 8 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.a
  08:05:32.625 [queue-master] 2024-11-23 08:05:32.625 INFO 7 --- [enerContainer-1] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-durable, auto-delete, or exclusive Queue (shipping-  (×2)
  08:05:35.430 [front-end] Posting Customer: {"username":"WoyOvB","password":"JoDhaHoLcH","email":"WoyOvB@gmail.com","firstName":"WoyOvB","lastName":"WoyOvB"}
  08:05:37.921 [front-end] Received response: "{\"firstName\":\"rOyHDnmKWE\",\"lastName\":\"rOyHDnmKWE\",\"username\":\"rOyHDnmKWE\",\"id\":\"67418cbda437380001deebf3\",\"_links\":{\"addr
  08:05:39.190 [orders] 2024-11-23 08:05:39.190 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[HEAD],produces=[applicati
  08:05:39.285 [orders] 2024-11-23 08:05:39.285 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applicat  (×2)
  08:05:41.190 [orders] 2024-11-23 08:05:41.190 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<j
  08:05:43.228 [queue-master] 2024-11-23 08:05:43.228 INFO 7 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  08:05:44.886 [orders] 2024-11-23 08:05:44.886 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as M
  08:05:49.010 [shipping] 2024-11-23 08:05:49.010 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/shipping],methods=[GET]}" onto public java.lang.S
  08:05:50.657 [user] ts=2024-11-23T08:05:50.656968664Z caller=middlewares.go:46 method=Register username=suOMyE email=suOMyE@gmail.com took=1.976885ms
  08:05:54.904 [shipping] 2024-11-23 08:05:54.904 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applica
  08:05:55.483 [front-end] Received response: "{\"firstName\":\"eevJWmvw\",\"lastName\":\"eevJWmvw\",\"username\":\"eevJWmvw\",\"id\":\"67418cd0a437380001deec2c\",\"_links\":{\"addresses\
  08:05:59.414 [shipping] 2024-11-23 08:05:59.414 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
  08:06:05.306 [carts] 2024-11-23 08:06:05.306 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/**] onto handler of type [class org.s
  08:06:07.004 [shipping] 2024-11-23 08:06:07.004 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/h
  08:06:07.103 [shipping] 2024-11-23 08:06:07.103 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applic  (×2)
  08:06:12.607 [front-end] Received response: "{\"firstName\":\"ngatc\",\"lastName\":\"ngatc\",\"username\":\"ngatc\",\"id\":\"67418cdfa437380001deec5c\",\"_links\":{\"addresses\":{\"href
  08:06:14.712 [shipping] 2024-11-23 08:06:14.711 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering
  08:06:15.805 [carts] 2024-11-23 08:06:15.804 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[GE
  08:06:15.968 [front-end] Posting Customer: {"username":"ADJLNqHnQSjIpaY","password":"BVKQdfwKCt","email":"ADJLNqHnQSjIpaY@gmail.com","firstName":"ADJLNqHnQSjIpaY","lastName":"ADJLNqHnQS
  08:06:19.002 [carts] 2024-11-23 08:06:19.002 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  08:06:19.279 [user] ts=2024-11-23T08:06:19.279512453Z caller=middlewares.go:46 method=Register username=ctDNRPS email=ctDNRPS@gmail.com took=2.189149ms
  08:06:24.199 [carts] 2024-11-23 08:06:24.199 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposur  (×2)
  08:06:26.651 [user] ts=2024-11-23T08:06:26.651741419Z caller=middlewares.go:46 method=Register username=spaWHNsfk email=spaWHNsfk@gmail.com took=2.544731ms

## p0565
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T18:30:26.903Z
```
{"timestamp":1733596226903498800,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-ndkkb","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 18:30:26.902  INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl             : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Response(status=1, msg=Success query Train by trip id, data=TrainType(id=ZhiDa, economyClass=2147483647, confortClass=2147483647, averageSpeed=120))"}
```
Same service, the 2 minutes before (oldest first):
  18:30:25.482 [ts-seat-service] 2024-12-07 18:30:25.481 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  18:30:25.492 [ts-seat-service] 2024-12-07 18:30:25.492 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×2)
  18:30:25.521 [ts-seat-service] 2024-12-07 18:30:25.520 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN
  18:30:25.521 [ts-seat-service] 2024-12-07 18:30:25.520 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
  18:30:25.531 [ts-seat-service] 2024-12-07 18:30:25.530 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  18:30:25.540 [ts-seat-service] 2024-12-07 18:30:25.539 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  18:30:25.554 [ts-seat-service] 2024-12-07 18:30:25.553 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re
  18:30:25.554 [ts-seat-service] 2024-12-07 18:30:25.553 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
  18:30:25.563 [ts-seat-service] 2024-12-07 18:30:25.563 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri
  18:30:26.794 [ts-seat-service] 2024-12-07 18:30:26.794 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×2)
  18:30:26.794 [ts-seat-service] 2024-12-07 18:30:26.794 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×2)
  18:30:26.806 [ts-seat-service] 2024-12-07 18:30:26.805 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×2)
  18:30:26.814 [ts-seat-service] 2024-12-07 18:30:26.813 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×2)
  18:30:26.827 [ts-seat-service] 2024-12-07 18:30:26.826 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re
All services, 30 seconds either side (sampled):
  18:29:57.088 [ts-auth-service] 2024-12-07 18:29:57.088 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×3)
  18:29:57.299 [ts-route-service] 2024-12-07 18:29:57.298 INFO 1 --- [io-11178-exec-7] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×174)
  18:29:57.363 [ts-travel-service] 2024-12-07 18:29:57.363 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×11)
  18:30:00.182 [ts-travel2-service] 2024-12-07 18:30:00.182 INFO 1 --- [io-16346-exec-1] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×14)
  18:30:00.275 [ts-price-service] 2024-12-07 18:30:00.275 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×3)
  18:30:00.300 [ts-order-other-service] 2024-12-07 18:30:00.300 INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×13)
  18:30:00.379 [ts-seat-service] 2024-12-07 18:30:00.379 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×3)
  18:30:00.471 [ts-seat-service] 2024-12-07 18:30:00.470 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×27)
  18:30:02.384 [ts-travel2-service] 2024-12-07 18:30:02.384 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×2)
  18:30:02.473 [ts-price-service] 2024-12-07 18:30:02.473 INFO 1 --- [io-16579-exec-1] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×20)
  18:30:02.534 [ts-food-service] 2024-12-07 18:30:02.534 INFO 1 --- [io-18856-exec-6] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×3)
  18:30:02.705 [ts-travel2-service] 2024-12-07 18:30:02.704 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×4)
  18:30:09.441 [ts-order-other-service] 2024-12-07 18:30:09.441 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou
  18:30:10.967 [ts-auth-service] 2024-12-07 18:30:10.967 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  18:30:14.656 [ts-travel-service] 2024-12-07 18:30:14.656 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×17)
  18:30:14.774 [ts-seat-service] 2024-12-07 18:30:14.774 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×11)
  18:30:14.979 [ts-basic-service] 2024-12-07 18:30:14.979 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2  (×2)
  18:30:15.874 [ts-auth-service] 2024-12-07 18:30:15.874 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : stopped _org.springframework.integration.errorLogger
  18:30:17.150 [ts-seat-service] 2024-12-07 18:30:17.150 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes
  18:30:26.260 [ts-auth-service] 2024-12-07 18:30:26.158 INFO 1 --- [ main] auth.AuthApplication : Starting AuthApplication v1.0 on ts-auth-service-54976f76bc-h7r6c with PID 1 (/app/ts-auth-ser  (×2)
  18:30:29.606 [ts-food-service] 2024-12-07 18:30:29.605 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  18:30:30.413 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T18:30:30.413+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359623
  18:30:31.978 [ts-order-service] java.lang.IllegalArgumentException: Invalid UUID string: at java.util.UUID.fromString(UUID.java:194) ~[na:1.8.0_402] at order.service.OrderServiceImpl.queryOrde
  18:30:41.360 [ts-auth-service] 2024-12-07 18:30:41.359 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.access.expression.method.DefaultMethodS
  18:30:42.223 [ts-train-mongo] {"t":{"$date":"2024-12-07T18:30:42.223+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359624
  18:30:47.194 [ts-basic-service] 2024-12-07 18:30:47.194 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69
  18:30:47.673 [ts-auth-service] 2024-12-07 18:30:47.671 INFO 1 --- [ost-startStop-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring embedded WebApplicationContext
  18:30:52.554 [ts-auth-service] 2024-12-07 18:30:52.553 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:20}] to ts-auth-m

## p0271
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:17.880Z
```
{"timestamp":1732242497880939800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Merging carts for customer id: 673fec41b0df5c00019af98c and session id: sJ5Vhf4A1CfEEunLMTP74DmBK3I7V4T_"}
```
Same service, the 2 minutes before (oldest first):
  02:28:17.028 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec38b0df5c00019af971"}
  02:28:17.035 [front-end] POST /cards 200 - ms - -
  02:28:17.084 [front-end] Attempting to delete cart for user: 673fec38b0df5c00019af971
  02:28:17.339 [front-end] GET /catalogue 200 - ms - -  (×2)
  02:28:17.369 [front-end] Request received with body: {}
  02:28:17.377 [front-end] Received response: "{\"firstName\":\"vtFUiCYPGkr\",\"lastName\":\"vtFUiCYPGkr\",\"username\":\"vtFUiCYPGkr\",\"id\":\"673fec2bb0df5c00019af944\",\"_links\":{\"a
  02:28:17.377 [front-end] GET Request to: http://user/customers/673fec2bb0df5c00019af944/addresses  (×2)
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec33b0df5c00019af961\",\"_links\":{\"
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:17.383 [front-end] [ undefined, undefined ]
  02:28:17.383 [front-end] Posting Order: {"customer":"http://user/customers/673fec2bb0df5c00019af944","address":"http://user/addresses/673fec33b0df5c00019af960","card":"http://user/cards
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:17.558 [front-end] { id: '673fec41b0df5c00019af98b' }  (×2)
  02:28:17.558 [front-end] 673fec41b0df5c00019af98b  (×2)
  02:28:17.558 [front-end] Merging carts for customer id: 673fec41b0df5c00019af98b and session id: DJgh-aP7GXWW3SFEl2AnBT8Zgj4ojU2q
  02:28:17.875 [front-end] Posting Customer: {"username":"QGHrdp","password":"lxLAJGrqCj","email":"QGHrdp@gmail.com","firstName":"QGHrdp","lastName":"QGHrdp"}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×44)
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -  (×44)
  02:28:03.203 [front-end] [ undefined, undefined ]  (×45)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×3)
  02:28:07.445 [orders] 2024-11-22 02:28:07.445 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
  02:28:10.277 [front-end] Posting Customer: {"username":"opFqwUnVow","password":"habyXFSF","email":"opFqwUnVow@gmail.com","firstName":"opFqwUnVow","lastName":"opFqwUnVow"}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
  02:28:23.301 [front-end] Received response: "{\"firstName\":\"HFHBXn\",\"lastName\":\"HFHBXn\",\"username\":\"HFHBXn\",\"id\":\"673fec34b0df5c00019af967\",\"_links\":{\"addresses\":{\"h
  02:28:24.999 [rabbitmq] 
  02:28:25.743 [carts] 2024-11-22 02:28:25.743 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×13)
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39d0","customerId":"673fec31b0df5c00019af95b","customer":{"id":null,"firstName":"bCCZHBaYc","lastName":"bCCZHBaYc","u
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×51)
  02:28:37.548 [user] ts=2024-11-22T02:28:37.548591Z caller=middlewares.go:46 method=Register username=OeZpiPZUn email=OeZpiPZUn@gmail.com took=1.009704ms
  02:28:40.321 [front-end] Order response: {"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR","lastName":"nbZCdAQyR","u
  02:28:42.162 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732242522152,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde
  02:28:44.338 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec5cd94b9000069b39e2","customerId":"673fec3ab0df5c00019af974","customer":{"id":null,"firstName":"opFqwUnVow"
  02:28:45.405 [front-end] Posting Customer: {"username":"crSMtAKNWrXaJJx","password":"TlwWXSanSW","email":"crSMtAKNWrXaJJx@gmail.com","firstName":"crSMtAKNWrXaJJx","lastName":"crSMtAKNWr
  02:28:47.575 [front-end] Received response: "{\"firstName\":\"QGHrdp\",\"lastName\":\"QGHrdp\",\"username\":\"QGHrdp\",\"id\":\"673fec41b0df5c00019af98c\",\"_links\":{\"addresses\":{\"h

## p0714
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-14T06:52:16.500Z
```
{"service":"mobservice2","message":"2021-08-14 06:52:16,500 | INFO | 0.0.0.4 | 172.17.0.2 | mobservice2 | 3aa3a092c98a599d | info 1b28aca6-fc89-11eb-b655-0242ac110004:hqSejVNL write success"}
```
Same service, the 2 minutes before (oldest first):
  06:52:09.336 [mobservice2] INFO info 16dbce3a-fc89-11eb-9cf2-0242ac110003:bhmAUvxt write success
  06:52:12.546 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  06:52:12.547 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  06:52:12.547 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '18ddbd10-fc89-11eb-b6e8-0242ac110004'}  (×4)
  06:52:12.600 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '18ddbd10-fc89-11eb-b6e8-0242ac110004', 'value': 'yeMqQbFt'}  (×4)
  06:52:12.680 [mobservice2] INFO info 18ddbd10-fc89-11eb-b6e8-0242ac110004:yeMqQbFt write success
  06:52:13.363 [mobservice2] INFO info 194ff204-fc89-11eb-8f5b-0242ac110003:PFOBQRXk write success
  06:52:14.133 [mobservice2] INFO info 19bf009a-fc89-11eb-90b9-0242ac110004:SZKcrGIR write success
All services, 30 seconds either side (sampled):
  06:51:46.508 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×47)
  06:51:46.649 [redisservice1] INFO redis write success  (×91)
  06:51:46.766 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '0967a3a0-fc89-11eb-93c5-0242ac110003', 'user_id': 'ropVRsqh'}  (×92)
  06:51:46.951 [dbservice2] INFO 0967a3a0-fc89-11eb-93c5-0242ac110003-ropVRsqh-hActS-H+f9_x token generate success token=MTYyODg5NTEwNi45NTA2MTgzOjA5NjdhM2EwLWZjODktMTFlYi05M2M1LTAyNDJhYzE  (×5)
  06:51:47.393 [mobservice1] INFO info 09d15aa2-fc89-11eb-ab87-0242ac110004:PKIhxRvi write success
  06:51:47.709 [redisservice1] INFO service accept, status_code: 200  (×49)
  06:51:48.255 [mobservice2] INFO info 0a540bbe-fc89-11eb-958d-0242ac110004:GkqNMDBg write success
  06:51:49.103 [redisservice2] INFO redis读取信息成功, status_code: 200  (×51)
  06:51:50.740 [mobservice2] INFO info 0bcba13c-fc89-11eb-b126-0242ac110003:vUsGrNAF write success
  06:51:53.277 [mobservice1] INFO info 0d4ab71e-fc89-11eb-9e53-0242ac110003:eJuaFIik write success
  06:51:55.879 [mobservice2] INFO info 0eda152a-fc89-11eb-9d64-0242ac110004:ZnrSqIKU write success
  06:51:58.369 [mobservice1] INFO info 105c606a-fc89-11eb-a488-0242ac110003:BYtUlIXT write success
  06:52:01.020 [dbservice1] ERROR password in database of {user} is null, the user is not registered  (×2)
  06:52:03.984 [dbservice1] INFO 13641b22-fc89-11eb-ae57-0242ac110004-SYUdXTMn-#?+cKu8b!U&_ token generate success token=MTYyODg5NTEyMy45ODQ0MDU1OjEzNjQxYjIyLWZjODktMTFlYi1hZTU3LTAyNDJhYzE
  06:52:06.512 [mobservice2] INFO info 1532a270-fc89-11eb-a828-0242ac110004:DomOhFAT write success
  06:52:09.502 [mobservice1] INFO info 16fa0aee-fc89-11eb-92ca-0242ac110004:vPQwWmBE write success
  06:52:12.199 [mobservice1] INFO info 189944c8-fc89-11eb-bcf0-0242ac110004:vpXbgtCB write success
  06:52:14.499 [dbservice1] INFO 19bf009a-fc89-11eb-90b9-0242ac110004-SZKcrGIR-xPE^X0ln_KYI token generate success token=MTYyODg5NTEzNC40OTkwMTM3OjE5YmYwMDlhLWZjODktMTFlYi05MGI5LTAyNDJhYzE
  06:52:17.199 [mobservice1] INFO info 1b9cf570-fc89-11eb-b4a8-0242ac110004:iBnyvbLP write success
  06:52:19.624 [mobservice1] INFO info 1d0ac2b6-fc89-11eb-ae3d-0242ac110003:BVmEhIvD write success
  06:52:22.126 [mobservice1] INFO info 1e76cbfe-fc89-11eb-87f9-0242ac110003:wRdieUHE write success
  06:52:24.700 [mobservice2] INFO info 2006f458-fc89-11eb-a645-0242ac110003:BlNycPMr write success
  06:52:27.140 [mobservice2] INFO info 217cd8ca-fc89-11eb-91e8-0242ac110003:RTiMKfox write success
  06:52:29.961 [dbservice1] INFO 22efabe2-fc89-11eb-8558-0242ac110004-tAuqKoTw-yCN:@jA43dVi token generate success token=MTYyODg5NTE0OS45NjE0MTk6MjJlZmFiZTItZmM4OS0xMWViLTg1NTgtMDI0MmFjMTE
  06:52:32.478 [dbservice2] INFO 24734f00-fc89-11eb-b327-0242ac110004-lvCfjILw-D1@9U_jQh_$a token generate success token=MTYyODg5NTE1Mi40Nzc3MDg6MjQ3MzRmMDAtZmM4OS0xMWViLWIzMjctMDI0MmFjMTE
  06:52:35.225 [dbservice1] INFO 26179834-fc89-11eb-a5a8-0242ac110003-aCdZXfNn-HVB*h$/mtRAv token generate success token=MTYyODg5NTE1NS4yMjUwMDg3OjI2MTc5ODM0LWZjODktMTFlYi1hNWE4LTAyNDJhYzE
  06:52:38.185 [dbservice1] INFO 27c81d70-fc89-11eb-8e14-0242ac110004-fjEOpuqm-<9>^jfG#2%K@ token generate success token=MTYyODg5NTE1OC4xODQ5MjE3OjI3YzgxZDcwLWZjODktMTFlYi04ZTE0LTAyNDJhYzE
  06:52:41.105 [mobservice1] INFO info 29d00628-fc89-11eb-9dd7-0242ac110003:dFRVcSCY write success
  06:52:44.118 [dbservice2] INFO 2b453596-fc89-11eb-bdc6-0242ac110004-RIklYufT-gZ(@VjR5X^<E token generate success token=MTYyODg5NTE2NC4xMTgzNDQ1OjJiNDUzNTk2LWZjODktMTFlYi1iZGM2LTAyNDJhYzE

## p0815
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-10T13:14:51.504Z
```
{"timestamp":1733836491504760600,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-vpgpt","node_name":"ip-192-168-51-182.ap-southeast-2.compute.internal","message":"2024-12-10 13:14:51.504  INFO 1 --- [           main] o.s.i.config.IntegrationRegistrar        : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. Therefore, a default DefaultHeaderChannelRegistry will be created."}
```
Same service, the 2 minutes before (oldest first):
  13:14:21.610 [ts-auth-service] 2024-12-10 13:14:21.610 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI
  13:14:21.610 [ts-auth-service] 2024-12-10 13:14:21.610 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID
  13:14:27.042 [ts-auth-service] 2024-12-10 13:14:27.042 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  13:14:27.042 [ts-auth-service] 2024-12-10 13:14:27.042 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  13:14:27.197 [ts-auth-service] 2024-12-10 13:14:27.196 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI
  13:14:27.197 [ts-auth-service] 2024-12-10 13:14:27.196 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID
  13:14:29.458 [ts-auth-service] 2024-12-10 13:14:29.456 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  13:14:29.458 [ts-auth-service] 2024-12-10 13:14:29.458 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  13:14:29.460 [ts-auth-service] 2024-12-10 13:14:29.460 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  13:14:29.463 [ts-auth-service] 2024-12-10 13:14:29.462 INFO 1 --- [ Thread-5] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 0 subscriber(s).
  13:14:29.463 [ts-auth-service] 2024-12-10 13:14:29.463 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : stopped _org.springframework.integration.errorLogger
  13:14:29.467 [ts-auth-service] 2024-12-10 13:14:29.466 INFO 1 --- [ Thread-5] o.s.s.c.ThreadPoolTaskScheduler : Shutting down ExecutorService 'taskScheduler'
  13:14:29.467 [ts-auth-service] 2024-12-10 13:14:29.466 INFO 1 --- [ Thread-5] o.s.j.e.a.AnnotationMBeanExporter : Unregistering JMX-exposed beans on shutdown
  13:14:29.469 [ts-auth-service] 2024-12-10 13:14:29.469 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:17}] to ts-auth-mongo:2  (×2)
  13:14:32.769 [ts-auth-service] [otel.javaagent 2024-12-10 13:14:32:767 +0000] [main] INFO io.opentelemetry.javaagent.tooling.VersionLogger - opentelemetry-javaagent - version: 2.0.0
  13:14:38.899 [ts-auth-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  13:14:41.800 [ts-auth-service] 2024-12-10 13:14:41.702 INFO 1 --- [ main] auth.AuthApplication : Starting AuthApplication v1.0 on ts-auth-service-54976f76bc-vpgpt with PID 1 (/app/ts-auth-ser
  13:14:41.800 [ts-auth-service] 2024-12-10 13:14:41.800 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default
  13:14:42.508 [ts-auth-service] 2024-12-10 13:14:42.508 INFO 1 --- [ main] ationConfigEmbeddedWebApplicationContext : Refreshing org.springframework.boot.context.embedded.AnnotationConfigEmbed
All services, 30 seconds either side (sampled):
  13:14:21.610 [ts-auth-service] 2024-12-10 13:14:21.610 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI
  13:14:21.674 [ts-travel2-service] 2024-12-10 13:14:21.674 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×23)
  13:14:22.724 [ts-order-service] 2024-12-10 13:14:22.724 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 3
  13:14:22.769 [ts-consign-service] 2024-12-10 13:14:22.768 INFO 1 --- [io-16111-exec-3] consign.service.ConsignServiceImpl : The handle date is 2024-12-10
  13:14:23.357 [ts-admin-basic-info-service] 2024-12-10 13:14:23.356 INFO 1 --- [io-18767-exec-3] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×12)
  13:14:26.852 [ts-travel-service] 2024-12-10 13:14:26.851 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×6)
  13:14:26.887 [ts-travel-service] 2024-12-10 13:14:26.886 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×2)
  13:14:27.042 [ts-auth-service] 2024-12-10 13:14:27.042 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  13:14:29.460 [ts-auth-service] 2024-12-10 13:14:29.460 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  13:14:29.472 [ts-auth-mongo] {"t":{"$date":"2024-12-10T13:14:29.470+00:00"},"s":"I", "c":"NETWORK", "id":22944, "ctx":"conn17","msg":"Connection ended","attr":{"remote":"127.0.0.6:54073","u  (×3)
  13:14:34.184 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:14:34 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 403 148 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)  (×2)
  13:14:41.800 [ts-auth-service] 2024-12-10 13:14:41.702 INFO 1 --- [ main] auth.AuthApplication : Starting AuthApplication v1.0 on ts-auth-service-54976f76bc-vpgpt with PID 1 (/app/ts-auth-ser  (×2)
  13:14:44.934 [ts-food-service] 2024-12-10 13:14:44.934 INFO 1 --- [io-18856-exec-7] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!  (×4)
  13:14:56.501 [ts-auth-service] 2024-12-10 13:14:56.501 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.configuration.ObjectP  (×2)
  13:14:57.205 [ts-auth-service] 2024-12-10 13:14:57.204 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'integrationGlobalProperties' of type [java.util.Properties] is not e  (×2)
  13:15:00.745 [ts-admin-basic-info-service] 2024-12-10 13:15:00.745 INFO 1 --- [o-18767-exec-10] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult] 
  13:15:03.957 [ts-travel-service] 2024-12-10 13:15:03.956 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=nanjing)
  13:15:07.037 [ts-travel-service] 2024-12-10 13:15:07.036 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  13:15:07.408 [ts-auth-service] 2024-12-10 13:15:07.407 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:19}] to ts-auth-m
  13:15:11.866 [ts-station-mongo] {"t":{"$date":"2024-12-10T13:15:11.866+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:12.527 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-10T13:15:12.527+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:13.215 [ts-travel2-mongo] {"t":{"$date":"2024-12-10T13:15:13.214+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:13.591 [ts-order-other-service] java.lang.IllegalArgumentException: Invalid UUID string: at java.util.UUID.fromString(UUID.java:194) ~[na:1.8.0_402] at other.service.OrderOtherServiceImpl.quer
  13:15:14.945 [ts-travel-mongo] {"t":{"$date":"2024-12-10T13:15:14.944+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383651
  13:15:16.114 [ts-auth-service] 2024-12-10 13:15:16.114 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/hello],methods=[GET]}" onto public java.lang.Objec
  13:15:16.501 [ts-auth-service] 2024-12-10 13:15:16.500 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.springframewo
  13:15:18.503 [ts-auth-service] 2024-12-10 13:15:18.503 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces=[applicati
  13:15:18.505 [ts-auth-service] 2024-12-10 13:15:18.505 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/vnd.spring-bo
  13:15:18.509 [ts-auth-service] 2024-12-10 13:15:18.508 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/vnd.spring-

## p0196
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T06:53:50.960Z
```
{"timestamp":1731912830960878800,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  06:53:50.270 [currencyservice] conversion request successful  (×16)
  06:53:50.304 [currencyservice] Getting supported currencies...  (×4)
All services, 30 seconds either side (sampled):
  06:53:21.617 [frontend] request started  (×320)
  06:53:21.621 [frontend] home  (×41)
  06:53:21.636 [currencyservice] conversion request successful  (×817)
  06:53:22.363 [frontend] serving product page  (×140)
  06:53:22.402 [frontend] adding to cart  (×35)
  06:53:22.436 [shippingservice] [GetQuote] received request  (×81)
  06:53:22.950 [adservice] received ad request (context_words=[clothing, tops])  (×14)
  06:53:24.857 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', '2ZYFJ3GM2N', 'OLJCESPC7Z']  (×4)
  06:53:26.915 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"466","nanos":800750106},"credit_card":{"credit_card_number":"40765339215883  (×3)
  06:53:26.919 [shippingservice] [ShipOrder] received request  (×12)
  06:53:26.929 [emailservice] A request to send order confirmation email to john17@example.com has been received.
  06:53:30.132 [emailservice] A request to send order confirmation email to annponce@example.com has been received.
  06:53:39.081 [adservice] received ad request (context_words=[footwear])  (×11)
  06:53:43.533 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"57937","nanos":153473087},"credit_card":{"credit_card_number":"436240858876  (×3)
  06:53:43.546 [checkoutservice] order confirmation email sent to "danacampos@example.net"
  06:53:53.000 [paymentservice] Transaction processed: visa ending 3265 Amount: USD1309.660000000  (×2)
  06:54:06.635 [emailservice] A request to send order confirmation email to stricklandmelissa@example.net has been received.
  06:54:06.912 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"394","nanos":745687759},"credit_card":{"credit_card_number":"49237152726698
  06:54:06.927 [checkoutservice] order confirmation email sent to "bbenjamin@example.net"
  06:54:07.125 [paymentservice] Transaction processed: visa ending 0066 Amount: TRY7986.327080097  (×2)
  06:54:08.707 [emailservice] A request to send order confirmation email to jreed@example.net has been received.
  06:54:13.055 [checkoutservice] order confirmation email sent to "devon86@example.org"
  06:54:14.163 [paymentservice] Transaction processed: visa ending 8298 Amount: CAD88.265624061
  06:54:14.275 [emailservice] A request to send order confirmation email to ellisonann@example.org has been received.
  06:54:16.073 [checkoutservice] order confirmation email sent to "clarkgabriel@example.org"

## p0697
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-12T13:38:24.502Z
```
{"service":"mobservice1","message":"2021-08-12 13:38:24,502 | INFO | 0.0.0.1 | 172.17.0.5 | mobservice1 | 86b63574e697aa47 | info 82c1e14e-fb2f-11eb-89c5-0242ac110003:xXiaofbu write success"}
```
Same service, the 2 minutes before (oldest first):
  13:38:21.986 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  13:38:21.987 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  13:38:21.987 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '815cb82e-fb2f-11eb-b474-0242ac110003'}  (×4)
  13:38:22.055 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '815cb82e-fb2f-11eb-b474-0242ac110003', 'value': 'hsWGAMiu'}  (×4)
  13:38:22.112 [mobservice1] INFO info 815cb82e-fb2f-11eb-b474-0242ac110003:hsWGAMiu write success
  13:38:22.859 [mobservice1] INFO info 81d15bac-fb2f-11eb-ba1b-0242ac110004:nlMAOLaH write success
  13:38:23.609 [mobservice1] INFO info 824505c0-fb2f-11eb-8643-0242ac110004:LeQUvMXs write success
All services, 30 seconds either side (sampled):
  13:37:54.530 [dbservice1] INFO 70a4d17e-fb2f-11eb-b931-0242ac110003-LVQPlZAt-zO)=3pt-rFm6 token generate success token=MTYyODc0NjY3NC41MzA0MTk6NzBhNGQxN2UtZmIyZi0xMWViLWI5MzEtMDI0MmFjMTE
  13:37:54.807 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×38)
  13:37:54.950 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×45)
  13:37:55.078 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '713815e2-fb2f-11eb-97b4-0242ac110004', 'user_id': 'xwrmCNQd'}  (×73)
  13:37:55.197 [redisservice2] INFO service accept, status_code: 200  (×37)
  13:37:55.782 [webservice1] INFO complete information: {'uuid': '71cd5094-fb2f-11eb-ab8d-0242ac110003', 'user_id': 'DtNVdFIW'}  (×36)
  13:37:55.929 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '71cd5094-fb2f-11eb-ab8d-0242ac110003', 'value': 'DtNVdFIW'}  (×42)
  13:37:56.274 [dbservice2] INFO 71cd5094-fb2f-11eb-ab8d-0242ac110003-DtNVdFIW-^*x0{Xp?zMmG token generate success token=MTYyODc0NjY3Ni4yNzM2NzM1OjcxY2Q1MDk0LWZiMmYtMTFlYi1hYjhkLTAyNDJhYzE
  13:37:56.590 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×31)
  13:37:58.192 [mobservice1] INFO info 732057d4-fb2f-11eb-91c0-0242ac110004:GmfKwAOM write success
  13:37:59.796 [mobservice2] INFO info 7415bb02-fb2f-11eb-ad5b-0242ac110003:DtNVdFIW write success
  13:38:02.162 [mobservice2] INFO info 757e18f4-fb2f-11eb-a785-0242ac110004:EJMXPwRO write success
  13:38:04.513 [mobservice2] INFO info 76e2c618-fb2f-11eb-8074-0242ac110004:TmVsgowE write success
  13:38:06.510 [dbservice2] INFO 77e54e82-fb2f-11eb-8060-0242ac110003-rtRkpsfM-ul#Hy_*g:KTb token generate success token=MTYyODc0NjY4Ni41MDk4Mjc5Ojc3ZTU0ZTgyLWZiMmYtMTFlYi04MDYwLTAyNDJhYzE
  13:38:08.679 [mobservice2] INFO info 7966300a-fb2f-11eb-bd5d-0242ac110003:IAqgbwQB write success
  13:38:11.143 [dbservice2] INFO 7a770b90-fb2f-11eb-9c31-0242ac110003-CZFJjyRk-1QN4a<C{jpM> token generate success token=MTYyODc0NjY5MS4xNDI3NTQ2OjdhNzcwYjkwLWZiMmYtMTFlYi05YzMxLTAyNDJhYzE
  13:38:13.610 [mobservice2] INFO info 7c5b7de2-fb2f-11eb-a8c0-0242ac110003:jInFtBJp write success
  13:38:15.683 [dbservice2] INFO 7d6ad30e-fb2f-11eb-a0cf-0242ac110003-ldRtFqHz-bh}86eDVi=P+ token generate success token=MTYyODc0NjY5NS42ODMwNzQ1OjdkNmFkMzBlLWZiMmYtMTFlYi1hMGNmLTAyNDJhYzE
  13:38:18.100 [mobservice1] INFO info 7ef6e1a4-fb2f-11eb-94c7-0242ac110004:YDlFxnqQ write success
  13:38:19.909 [dbservice1] INFO 7fe17f2a-fb2f-11eb-b6ef-0242ac110004-QDmAuJjk-EsJd)P:SQx?. token generate success token=MTYyODc0NjY5OS45MDkxOTMzOjdmZTE3ZjJhLWZiMmYtMTFlYi1iNmVmLTAyNDJhYzE
  13:38:22.383 [dbservice1] INFO 8149fc02-fb2f-11eb-b1dd-0242ac110003-JUvKDVWZ-a+*q{iPRE@-> token generate success token=MTYyODc0NjcwMi4zODI5NzQxOjgxNDlmYzAyLWZiMmYtMTFlYi1iMWRkLTAyNDJhYzE
  13:38:25.341 [dbservice2] INFO 830f4d44-fb2f-11eb-8ad8-0242ac110004-TdjVXoHa-%Gy+D.NQ!s7p token generate success token=MTYyODc0NjcwNS4zNDA3OTQ6ODMwZjRkNDQtZmIyZi0xMWViLThhZDgtMDI0MmFjMTE
  13:38:27.276 [webservice1] ERROR an error occurred in the downstream service  (×2)
  13:38:29.581 [dbservice1] INFO 859f15ee-fb2f-11eb-8d0a-0242ac110003-saJCEzRp-rVa(<KJAO=cm token generate success token=MTYyODc0NjcwOS41ODEyNTU3Ojg1OWYxNWVlLWZiMmYtMTFlYi04ZDBhLTAyNDJhYzE
  13:38:39.441 [dbservice1] INFO 8b84d480-fb2f-11eb-80d6-0242ac110004-cHTYOdVw-CeU5:@)Q{VmT token generate success token=MTYyODc0NjcxOS40NDEzOTMxOjhiODRkNDgwLWZiMmYtMTFlYi04MGQ2LTAyNDJhYzE
  13:38:42.007 [mobservice1] INFO info 8d2e1256-fb2f-11eb-aa31-0242ac110004:zwDGqUsI write success  (×2)
  13:38:44.161 [mobservice2] INFO info 8e8792e4-fb2f-11eb-9803-0242ac110003:SgtQlrMk write success
  13:38:46.085 [dbservice1] INFO 8f7a8eea-fb2f-11eb-850a-0242ac110004-aILTSXwD-f&zLjS!6@gY{ token generate success token=MTYyODc0NjcyNi4wODUxNjc6OGY3YThlZWEtZmIyZi0xMWViLTg1MGEtMDI0MmFjMTE
  13:38:50.412 [mobservice1] INFO info 9243dff0-fb2f-11eb-8d61-0242ac110004:MBoWvOAG write success

## p0493
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:10:19.184Z
```
{"timestamp":1732353019184818700,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:10:19.184753329Z caller=middlewares.go:75 method=GetUsers id=67419be8a437380001df091e result=1 took=2.581936ms"}
```
Same service, the 2 minutes before (oldest first):
  09:10:17.485 [user] ts=2024-11-23T09:10:17.485308212Z caller=middlewares.go:75 method=GetUsers id=67419be9a437380001df091f result=1 took=1.978302ms  (×13)
  09:10:17.487 [user] ts=2024-11-23T09:10:17.487811111Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419bf0a437380001df0939 took=4.392077ms  (×3)
  09:10:17.500 [user] ts=2024-11-23T09:10:17.500663892Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419bf0a437380001df0939 took=3.01786ms  (×3)
  09:10:18.316 [user] ts=2024-11-23T09:10:18.31626175Z caller=middlewares.go:46 method=Register username=tnhegd email=tnhegd@gmail.com took=2.935326ms
All services, 30 seconds either side (sampled):
  09:09:49.408 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67419bd3a437380001df08d0"}  (×67)
  09:09:49.490 [front-end] Merging carts for customer id: 67419bdda437380001df08f8 and session id: N08C7P0XM4-9xJB_ClfMrVTybVJy3y1C  (×63)
  09:09:49.520 [front-end] POST to carts: http://carts/carts/67419bd3a437380001df08d0/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}  (×39)
  09:09:50.212 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  09:09:51.383 [front-end] Received response: "{\"firstName\":\"eugseB\",\"lastName\":\"eugseB\",\"username\":\"eugseB\",\"id\":\"67419bcaa437380001df08b8\",\"_links\":{\"addresses\":{\"h
  09:09:51.749 [front-end] Posting Customer: {"username":"GKNVHMVzLWh","password":"NRFQoVnGum","email":"GKNVHMVzLWh@gmail.com","firstName":"GKNVHMVzLWh","lastName":"GKNVHMVzLWh"}
  09:09:54.957 [front-end] Received response: "{\"firstName\":\"GymesZbwO\",\"lastName\":\"GymesZbwO\",\"username\":\"GymesZbwO\",\"id\":\"67419bd3a437380001df08d3\",\"_links\":{\"address
  09:09:58.256 [front-end] Posting Customer: {"username":"YqMCFNGABTJ","password":"EnCFzkTh","email":"YqMCFNGABTJ@gmail.com","firstName":"YqMCFNGABTJ","lastName":"YqMCFNGABTJ"}
  09:10:02.943 [front-end] Received response: "{\"firstName\":\"nGmrimYJTN\",\"lastName\":\"nGmrimYJTN\",\"username\":\"nGmrimYJTN\",\"id\":\"67419bd5a437380001df08d9\",\"_links\":{\"addr
  09:10:07.452 [front-end] Received response: "{\"firstName\":\"tbWtqjkm\",\"lastName\":\"tbWtqjkm\",\"username\":\"tbWtqjkm\",\"id\":\"67419bd8a437380001df08e2\",\"_links\":{\"addresses\
  09:10:10.559 [user] ts=2024-11-23T09:10:10.559839342Z caller=middlewares.go:46 method=Register username=jkDbbJbH email=jkDbbJbH@gmail.com took=2.303456ms
  09:10:13.206 [front-end] Received response: "{\"firstName\":\"wZawFqWVlWDE\",\"lastName\":\"wZawFqWVlWDE\",\"username\":\"wZawFqWVlWDE\",\"id\":\"67419bdea437380001df08fc\",\"_links\":{
  09:10:15.745 [orders] 2024-11-23 09:10:15.744 INFO [orders,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionH  (×2)
  09:10:18.309 [front-end] Posting Customer: {"username":"tnhegd","password":"KphLiOEO","email":"tnhegd@gmail.com","firstName":"tnhegd","lastName":"tnhegd"}
  09:10:22.806 [front-end] Received response: "{\"firstName\":\"dxxkolh\",\"lastName\":\"dxxkolh\",\"username\":\"dxxkolh\",\"id\":\"67419be6a437380001df0916\",\"_links\":{\"addresses\":{
  09:10:23.049 [orders] 2024-11-23 09:10:23.049 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[GET],produces=[applicatio
  09:10:23.138 [orders] 2024-11-23 09:10:23.138 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[GET],produces=  (×2)
  09:10:23.236 [orders] 2024-11-23 09:10:23.236 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http
  09:10:24.806 [front-end] Posting Customer: {"username":"KPsrv","password":"SAEDuY","email":"KPsrv@gmail.com","firstName":"KPsrv","lastName":"KPsrv"}
  09:10:25.441 [orders] 2024-11-23 09:10:25.440 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java
  09:10:26.185 [front-end] Posting Customer: {"username":"XhmTeQuHZAmulqG","password":"NvpDL","email":"XhmTeQuHZAmulqG@gmail.com","firstName":"XhmTeQuHZAmulqG","lastName":"XhmTeQuHZAmulqG
  09:10:29.641 [orders] 2024-11-23 09:10:29.640 INFO [orders,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  09:10:31.845 [orders] 2024-11-23 09:10:31.844 INFO [orders,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  09:10:33.574 [front-end] Received response: "{\"firstName\":\"aqJlxrRC\",\"lastName\":\"aqJlxrRC\",\"username\":\"aqJlxrRC\",\"id\":\"67419bf4a437380001df0947\",\"_links\":{\"addresses\
  09:10:35.169 [front-end] Posting Customer: {"username":"MWkDmiEWUqrxCG","password":"BcRowsBRC","email":"MWkDmiEWUqrxCG@gmail.com","firstName":"MWkDmiEWUqrxCG","lastName":"MWkDmiEWUqrxCG
  09:10:38.002 [front-end] Posting Customer: {"username":"HZDjz","password":"xYncrX","email":"HZDjz@gmail.com","firstName":"HZDjz","lastName":"HZDjz"}
  09:10:43.118 [front-end] Posting Customer: {"username":"lDqcFuILkDUID","password":"fFlRDw","email":"lDqcFuILkDUID@gmail.com","firstName":"lDqcFuILkDUID","lastName":"lDqcFuILkDUID"}
  09:10:47.146 [front-end] Posting Customer: {"username":"eWNXEbRdyzoGLtj","password":"rktfs","email":"eWNXEbRdyzoGLtj@gmail.com","firstName":"eWNXEbRdyzoGLtj","lastName":"eWNXEbRdyzoGLtj

## p0353
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:30:09.950Z
```
{"timestamp":1732246209950652700,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:30:09.950403885Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffabab0df5c00019b25c7 took=1.490453ms"}
```
Same service, the 2 minutes before (oldest first):
  03:30:06.094 [user] ts=2024-11-22T03:30:06.09399781Z caller=middlewares.go:157 method=Health result=2 took=855.642µs  (×3)
  03:30:06.130 [user] ts=2024-11-22T03:30:06.13020294Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffab9b0df5c00019b25c1 took=1.660587ms  (×4)
  03:30:06.144 [user] ts=2024-11-22T03:30:06.143997884Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffab9b0df5c00019b25c1 took=1.750665ms  (×3)
  03:30:06.525 [user] ts=2024-11-22T03:30:06.525056554Z caller=middlewares.go:46 method=Register username=qVMKTSreYx email=qVMKTSreYx@gmail.com took=1.032895ms  (×2)
  03:30:06.687 [user] ts=2024-11-22T03:30:06.687297699Z caller=middlewares.go:46 method=Register username=lQpQQM email=lQpQQM@gmail.com took=1.064047ms
  03:30:09.166 [user] ts=2024-11-22T03:30:09.166661791Z caller=middlewares.go:75 method=GetUsers id=673ffaacb0df5c00019b2599 result=1 took=1.058844ms
  03:30:09.174 [user] ts=2024-11-22T03:30:09.173935858Z caller=middlewares.go:75 method=GetUsers id=673ffaacb0df5c00019b2599 result=1 took=708.557µs  (×3)
  03:30:09.183 [user] ts=2024-11-22T03:30:09.183413557Z caller=middlewares.go:134 method=GetCards id=673ffab6b0df5c00019b25b6 result=1 took=699.628µs
  03:30:09.184 [user] ts=2024-11-22T03:30:09.183915828Z caller=middlewares.go:104 method=GetAddresses id=673ffab5b0df5c00019b25b5 result=1 took=1.318913ms
  03:30:09.939 [user] ts=2024-11-22T03:30:09.939523692Z caller=middlewares.go:46 method=Register username=IjRUX email=IjRUX@gmail.com took=843.228µs
All services, 30 seconds either side (sampled):
  03:29:40.352 [catalogue] ts=2024-11-22T03:29:40Z caller=logging.go:85 method=Health result=2 took=26.297µs  (×40)
  03:29:40.631 [orders] 2024-11-22 03:29:40.630 INFO [orders,338315806e179e3f,6e5e5c1b5973b5f7,false] 6 --- [-nio-80-exec-13] w.w.s.o.controllers.OrdersController : Sending payment req  (×25)
  03:29:40.771 [catalogue] ts=2024-11-22T03:29:40Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.709958ms  (×61)
  03:29:41.265 [front-end] POST /register 200 30.674 ms - 33  (×56)
  03:29:42.189 [front-end] DELETE /cart 202 - ms - -  (×60)
  03:29:42.505 [front-end] Order response: {"id":"673ffaa6d94b9000069b4552","customerId":"673ffa92b0df5c00019b254e","customer":{"id":null,"firstName":"frOnpeyPbJZeLr","lastName":"frOnpeyP
  03:29:42.966 [queue-master] 2024-11-22 03:29:42.966 ERROR 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×12)
  03:29:45.792 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×12)
  03:29:47.760 [front-end] Order response: {"id":"673ffaabd94b9000069b4559","customerId":"673ffa97b0df5c00019b2561","customer":{"id":null,"firstName":"WJekORw","lastName":"WJekORw","usern
  03:29:50.018 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×2)
  03:29:52.160 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffab0d94b9000069b455d","customerId":"673ffa96b0df5c00019b255d","customer":{"id":null,"firstName":"nSpeH","las
  03:29:54.972 [front-end] Received response: "{\"firstName\":\"tMfgKNvMyV\",\"lastName\":\"tMfgKNvMyV\",\"username\":\"tMfgKNvMyV\",\"id\":\"673ffa98b0df5c00019b2566\",\"_links\":{\"addr
  03:29:56.607 [front-end] Received response: "{\"firstName\":\"SRWPzgtU\",\"lastName\":\"SRWPzgtU\",\"username\":\"SRWPzgtU\",\"id\":\"673ffaa0b0df5c00019b257d\",\"_links\":{\"addresses\
  03:30:00.016 [front-end] Posting Customer: {"username":"opLpRnirj","password":"lRwsvvA","email":"opLpRnirj@gmail.com","firstName":"opLpRnirj","lastName":"opLpRnirj"}
  03:30:02.536 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffabad94b9000069b4565","customerId":"673ffaa6b0df5c00019b258e","customer":{"id":null,"firstName":"YJBTBSeeLu"
  03:30:05.118 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffabdd94b9000069b4567","customerId":"673ffaa5b0df5c00019b258b","customer":{"id":null,"firstName":"iGotNtqHsOq
  03:30:10.073 [front-end] Received response: "{\"firstName\":\"YDmtNkeDJGvx\",\"lastName\":\"YDmtNkeDJGvx\",\"username\":\"YDmtNkeDJGvx\",\"id\":\"673ffaaeb0df5c00019b25a2\",\"_links\":{
  03:30:11.150 [front-end] Order response: {"id":"673ffac3d94b9000069b456b","customerId":"673ffab0b0df5c00019b25a7","customer":{"id":null,"firstName":"yqNFrdpxwpSWWY","lastName":"yqNFrdpx
  03:30:13.149 [front-end] Order response: {"id":"673ffac5d94b9000069b456d","customerId":"673ffaafb0df5c00019b25a5","customer":{"id":null,"firstName":"LByowplYzsJ","lastName":"LByowplYzsJ
  03:30:14.908 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffac6d94b9000069b4571","customerId":"673ffab6b0df5c00019b25b7","customer":{"id":null,"firstName":"CbHxzavqmqq
  03:30:17.001 [front-end] Posting Customer: {"username":"RwMntR","password":"iweziEY","email":"RwMntR@gmail.com","firstName":"RwMntR","lastName":"RwMntR"}
  03:30:20.281 [front-end] Posting Customer: {"username":"uvguTpG","password":"kCwdAMrC","email":"uvguTpG@gmail.com","firstName":"uvguTpG","lastName":"uvguTpG"}
  03:30:23.766 [user] ts=2024-11-22T03:30:23.76590728Z caller=middlewares.go:46 method=Register username=lpQTY email=lpQTY@gmail.com took=1.114463ms
  03:30:25.140 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffad1d94b9000069b457b","customerId":"673ffabab0df5c00019b25c7","customer":{"id":null,"firstName":"pWByQVWBr",
  03:30:27.249 [front-end] Posting Customer: {"username":"zerVqSVAKj","password":"pKarfVycEw","email":"zerVqSVAKj@gmail.com","firstName":"zerVqSVAKj","lastName":"zerVqSVAKj"}
  03:30:29.577 [front-end] Received response: "{\"firstName\":\"eLdSSuvnp\",\"lastName\":\"eLdSSuvnp\",\"username\":\"eLdSSuvnp\",\"id\":\"673ffac4b0df5c00019b25e7\",\"_links\":{\"address
  03:30:31.913 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffad7d94b9000069b4582","customerId":"673ffac4b0df5c00019b25e8","customer":{"id":null,"firstName":"ufsONeYZqMB
  03:30:36.520 [front-end] Order response: {"id":"673ffadcd94b9000069b4585","customerId":"673ffaccb0df5c00019b25fe","customer":{"id":null,"firstName":"uvguTpG","lastName":"uvguTpG","usern

## p0210
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:11:14.346Z
```
{"timestamp":1731913874346754800,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"adding to cart"}
```
Same service, the 2 minutes before (oldest first):
  07:11:12.098 [frontend] request complete  (×7)
  07:11:12.938 [frontend] request started  (×7)
  07:11:12.938 [frontend] serving product page  (×4)
  07:11:12.979 [frontend] adding to cart
  07:11:12.993 [frontend] view user cart
All services, 30 seconds either side (sampled):
  07:10:44.476 [frontend] request started  (×352)
  07:10:44.484 [cartservice] GetCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×285)
  07:10:44.506 [adservice] received ad request (context_words=[clothing, tops])  (×22)
  07:10:44.933 [frontend] setting currency  (×25)
  07:10:44.990 [adservice] received ad request (context_words=[])  (×37)
  07:10:45.468 [shippingservice] [GetQuote] completed request  (×93)
  07:10:47.696 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '9SIQT8TOJO', '66VCHSJNUP', 'LS4PSXUNUM']  (×8)
  07:10:48.676 [adservice] received ad request (context_words=[accessories])  (×27)
  07:10:48.751 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"65","nanos":530133568},"credit_card":{"credit_card_number":"476779680926615  (×4)
  07:10:48.755 [shippingservice] [ShipOrder] received request  (×11)
  07:10:48.762 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 14  (×13)
  07:10:48.980 [checkoutservice] [PlaceOrder] user_id="5e004f2d-a61a-45b2-840d-6bfd47a2be43" user_currency="TRY"  (×2)
  07:10:49.016 [checkoutservice] failed to send order confirmation to "michael81@example.org": rpc error: code = Unavailable desc = no healthy upstream
  07:10:49.986 [paymentservice] Transaction processed: visa ending 0430 Amount: EUR131.729323311  (×4)
  07:10:57.117 [checkoutservice] failed to send order confirmation to "davisbryan@example.com": rpc error: code = Unavailable desc = no healthy upstream
  07:11:07.319 [checkoutservice] failed to send order confirmation to "hernandezmarc@example.net": rpc error: code = Unavailable desc = no healthy upstream
  07:11:09.475 [paymentservice] Transaction processed: visa ending 3563 Amount: USD1828.470000000  (×2)
  07:11:17.076 [redis] 1:M 18 Nov 2024 07:11:17.075 * 100 changes in 300 seconds. Saving...
  07:11:17.082 [redis] 72:C 18 Nov 2024 07:11:17.082 * Fork CoW for RDB: current 0 MB, peak 0 MB, average 0 MB
  07:11:22.430 [frontend] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
  07:11:22.459 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  07:11:38.285 [checkoutservice] failed to send order confirmation to "williamsanna@example.net": rpc error: code = Unavailable desc = no healthy upstream

## p0535
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T11:04:00.324Z
```
{"timestamp":1732359840324467000,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 11:04:00.324  INFO [carts,2a0f27fdb8511bf5,2246015d32a16464,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.ItemsController   : Did not find item. Creating item for user: 6741b699a437380001df54d6, Item{id='6741b6a0f074bf00070058a6', itemId='d3588630-ad8e-49df-bbd7-3167f7efb246', quantity=1, unitPrice=10.99}"}
```
Same service, the 2 minutes before (oldest first):
  11:03:56.390 [carts] 2024-11-23 11:03:56.390 INFO [carts,8ec7ce6c89d752ee,d87e8f54055f3ce3,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)
  11:03:56.415 [carts] 2024-11-23 11:03:56.414 INFO [carts,ac82f09b91cafc17,5f9ee7d4bde9d145,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×6)
  11:03:56.438 [carts] 2024-11-23 11:03:56.438 INFO [carts,84f2ee6e86affc00,2aedf37ace384622,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.CartsController : Merge carts reques  (×5)
  11:03:57.802 [carts] 2024-11-23 11:03:57.801 INFO [carts,6f58ec3f0024c067,0723f874258c26ad,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.ItemsController : Did not find item.
  11:03:57.811 [carts] 2024-11-23 11:03:57.811 INFO [carts,6f58ec3f0024c067,0723f874258c26ad,false] 7 --- [-nio-80-exec-11] w.w.s.cart.cart.CartContentsResource : Adding for user: Car
  11:03:58.100 [carts] 2024-11-23 11:03:58.100 INFO [carts,74d552efa4b5dac9,00efb27ef936559b,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.ItemsController : Did not find item.  (×3)
All services, 30 seconds either side (sampled):
  11:03:30.383 [catalogue] ts=2024-11-23T11:03:30Z caller=logging.go:85 method=Health result=2 took=35.977µs  (×40)
  11:03:47.282 [front-end] Posting Customer: {"username":"efjgmmJtKv","password":"RMUFsiyY","email":"efjgmmJtKv@gmail.com","firstName":"efjgmmJtKv","lastName":"efjgmmJtKv"}
  11:03:47.302 [carts] 2024-11-23 11:03:47.301 INFO [carts,5a0a5bec5562a998,10d7f3b5bd52a0a9,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×15)
  11:03:48.042 [front-end] Posting Customer: {"username":"NzdAqPAXT","password":"WSOhs","email":"NzdAqPAXT@gmail.com","firstName":"NzdAqPAXT","lastName":"NzdAqPAXT"}
  11:03:51.097 [user] ts=2024-11-23T11:03:51.097470932Z caller=middlewares.go:46 method=Register username=izuCR email=izuCR@gmail.com took=2.202784ms
  11:03:53.347 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b693a437380001df54d0"}  (×21)
  11:03:53.375 [front-end] POST /cards 200 - ms - -  (×21)
  11:03:53.463 [catalogue] ts=2024-11-23T11:03:53Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=5.433436  (×20)
  11:03:53.523 [front-end] POST /cart 201 - ms - -  (×20)
  11:03:55.832 [front-end] Posting Customer: {"username":"BvVYVeMmWCoOHQZ","password":"XEqkLs","email":"BvVYVeMmWCoOHQZ@gmail.com","firstName":"BvVYVeMmWCoOHQZ","lastName":"BvVYVeMmWCoOHQ
  11:03:56.382 [carts] 2024-11-23 11:03:56.381 INFO [carts,8ec7ce6c89d752ee,d87e8f54055f3ce3,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.ItemsController : Did not find item.  (×12)
  11:03:56.543 [front-end] Posting Customer: {"username":"YWOBdjLIWnSTg","password":"jTWvGWdK","email":"YWOBdjLIWnSTg@gmail.com","firstName":"YWOBdjLIWnSTg","lastName":"YWOBdjLIWnSTg"}
  11:03:57.772 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×3)
  11:03:59.669 [front-end] Posting Customer: {"username":"imhZTN","password":"PxvCtnJ","email":"imhZTN@gmail.com","firstName":"imhZTN","lastName":"imhZTN"}
  11:04:00.291 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×2)
  11:04:01.454 [user] ts=2024-11-23T11:04:01.454479736Z caller=middlewares.go:46 method=Register username=zDIHdeVWu email=zDIHdeVWu@gmail.com took=2.48915ms
  11:04:03.984 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  11:04:06.542 [user] ts=2024-11-23T11:04:06.541921827Z caller=middlewares.go:75 method=GetUsers id=6741b693a437380001df54d0 result=1 took=1.972827ms  (×4)
  11:04:06.562 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b699a437380001df54d8\",\"_links\":{\"
  11:04:06.577 [user] ts=2024-11-23T11:04:06.577774678Z caller=middlewares.go:134 method=GetCards id=6741b699a437380001df54d8 result=1 took=1.80299ms
  11:04:06.606 [queue-master] Received shipment task: 6741b693a437380001df54d0
  11:04:06.609 [front-end] Order response: {"statusCode":201,"headers":{"x-application-context":"orders:80","content-length":"0","date":"Sat, 23 Nov 2024 11:04:06 GMT","x-envoy-upstream-s
  11:04:06.643 [front-end] npm timing command:run-script Completed in 43497ms
  11:04:06.644 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!
  11:04:27.042 [carts-db] {"t":{"$date":"2024-11-23T11:04:27.042+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235986

## p0014
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-13T06:15:10.208Z
```
{"service":"mobservice1","message":"2021-08-13 06:15:10,208 | INFO | 0.0.0.1 | 172.17.0.5 | mobservice1 | 42c8aad037736c1f | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  06:15:07.465 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  06:15:07.466 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  06:15:07.466 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'c038d4de-fbba-11eb-89aa-0242ac110004'}  (×4)
  06:15:07.517 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'c038d4de-fbba-11eb-89aa-0242ac110004', 'value': 'hpcKRNdx'}  (×4)
  06:15:07.561 [mobservice1] INFO info c038d4de-fbba-11eb-89aa-0242ac110004:hpcKRNdx write success
  06:15:07.933 [mobservice1] INFO info c0627776-fbba-11eb-9c34-0242ac110003:ORjBsXZy write success
  06:15:08.693 [mobservice1] INFO info c0e2f7e8-fbba-11eb-9932-0242ac110004:vtpXmFKe write success
  06:15:09.528 [mobservice1] INFO info c15ea956-fbba-11eb-8cf2-0242ac110003:ulnvrqij write success
All services, 30 seconds either side (sampled):
  06:14:40.310 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  06:14:40.480 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×44)
  06:14:40.682 [mobservice2] INFO info b02b4b80-fbba-11eb-a407-0242ac110003:YXLKvufE write success
  06:14:40.850 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': 'b02b4b80-fbba-11eb-a407-0242ac110003', 'user_id': 'YXLKvufE'}  (×82)
  06:14:41.067 [dbservice1] INFO query = select passwards from username_table where user_name='YXLKvufE'  (×44)
  06:14:41.470 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×39)
  06:14:41.811 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'b0b509ba-fbba-11eb-b1d5-0242ac110003'}  (×38)
  06:14:42.061 [dbservice2] INFO query = select passwards from username_table where user_name='QPYaeVWt'  (×37)
  06:14:42.555 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'b154e7a0-fbba-11eb-a74a-0242ac110004', 'value': 'pyWndFNv'}  (×41)
  06:14:44.508 [dbservice2] INFO b23fa3da-fbba-11eb-8db6-0242ac110003-BfHEtDzA-.rCI2#*OfptJ token generate success token=MTYyODgwNjQ4NC41MDgxNDY4OmIyM2ZhM2RhLWZiYmEtMTFlYi04ZGI2LTAyNDJhYzE
  06:14:46.609 [mobservice2] INFO info b3aec76e-fbba-11eb-885a-0242ac110003:QYryCKLk write success
  06:14:48.459 [dbservice1] INFO b4a3cb1a-fbba-11eb-b55c-0242ac110004-RcoJYnsh-sPdxZat-)M%I token generate success token=MTYyODgwNjQ4OC40NTkwMzA0OmI0YTNjYjFhLWZiYmEtMTFlYi1iNTVjLTAyNDJhYzE
  06:14:50.840 [dbservice1] INFO b5dfb4e4-fbba-11eb-b772-0242ac110004-GYQsHOyA-RB?=8F>L}UWG token generate success token=MTYyODgwNjQ5MC44MzkzMDEzOmI1ZGZiNGU0LWZiYmEtMTFlYi1iNzcyLTAyNDJhYzE
  06:14:53.182 [dbservice2] INFO b7682bde-fbba-11eb-8e63-0242ac110003-DLQYKJTg-?vaXQ#PZAoRN token generate success token=MTYyODgwNjQ5My4xODIxNzQyOmI3NjgyYmRlLWZiYmEtMTFlYi04ZTYzLTAyNDJhYzE
  06:14:55.220 [mobservice2] INFO info b8d6c4b2-fbba-11eb-b448-0242ac110004:YqjgnfMZ write success
  06:14:57.125 [dbservice1] INFO b9c67da4-fbba-11eb-bca5-0242ac110004-pyWndFNv-k$0)mK!%.@XT token generate success token=MTYyODgwNjQ5Ny4xMjU1NDc6YjljNjdkYTQtZmJiYS0xMWViLWJjYTUtMDI0MmFjMTE
  06:14:59.336 [dbservice1] INFO bb0a0f8c-fbba-11eb-9292-0242ac110004-OiYedVug-CgNB*r/q!wic token generate success token=MTYyODgwNjQ5OS4zMzYyMDgzOmJiMGEwZjhjLWZiYmEtMTFlYi05MjkyLTAyNDJhYzE
  06:15:01.808 [dbservice1] INFO bc8f1be0-fbba-11eb-a3aa-0242ac110003-EVWjdQPL-x0W*{QkD3ZT2 token generate success token=MTYyODgwNjUwMS44MDc4Mjc1OmJjOGYxYmUwLWZiYmEtMTFlYi1hM2FhLTAyNDJhYzE
  06:15:04.895 [dbservice2] INFO be6cf73e-fbba-11eb-a614-0242ac110004-IKAZGYCc-njNx6uZ3V<P_ token generate success token=MTYyODgwNjUwNC44OTQ3MjA2OmJlNmNmNzNlLWZiYmEtMTFlYi1hNjE0LTAyNDJhYzE
  06:15:07.052 [mobservice1] INFO info bfe8a068-fbba-11eb-bec3-0242ac110003:mwbCGSva write success
  06:15:09.528 [mobservice1] INFO info c15ea956-fbba-11eb-8cf2-0242ac110003:ulnvrqij write success
  06:15:12.193 [mobservice2] INFO info c2f00d6e-fbba-11eb-8bfa-0242ac110004:GYgLnikZ write success
  06:15:14.218 [dbservice1] INFO c3f23f16-fbba-11eb-96cb-0242ac110003-gstLzvnZ-lhfi/n1P7ZQ: token generate success token=MTYyODgwNjUxNC4yMTg1MTU5OmMzZjIzZjE2LWZiYmEtMTFlYi05NmNiLTAyNDJhYzE
  06:15:21.621 [mobservice2] INFO info c89128f2-fbba-11eb-b21f-0242ac110003:rAmXuCJg write success
  06:15:26.623 [dbservice1] INFO cb516066-fbba-11eb-abaa-0242ac110004-bHrMSWsj--%0VNhY.LywK token generate success token=MTYyODgwNjUyNi42MjI4MTE6Y2I1MTYwNjYtZmJiYS0xMWViLWFiYWEtMDI0MmFjMTE
  06:15:28.740 [mobservice1] INFO info ccd5bf7c-fbba-11eb-b043-0242ac110003:iDcvUpmS write success
  06:15:31.045 [mobservice1] INFO info ce33ee34-fbba-11eb-9b55-0242ac110004:IhzyCpmU write success
  06:15:33.284 [dbservice2] INFO cf476954-fbba-11eb-a77f-0242ac110004-QKmUlJOs-VtH(T*{y+/P@ token generate success token=MTYyODgwNjUzMy4yNzc0NjA2OmNmNDc2OTU0LWZiYmEtMTFlYi1hNzdmLTAyNDJhYzE
  06:15:35.832 [dbservice1] INFO d0cfb790-fbba-11eb-a748-0242ac110004-laVNGIPf-{Z8wE?(U^nzJ token generate success token=MTYyODgwNjUzNS44MzE3NTkyOmQwY2ZiNzkwLWZiYmEtMTFlYi1hNzQ4LTAyNDJhYzE
  06:15:38.195 [dbservice2] INFO d24431f0-fbba-11eb-a447-0242ac110003-PYaoLpfS-bW9F%P+AUv_Q token generate success token=MTYyODgwNjUzOC4xOTQ4MjAyOmQyNDQzMWYwLWZiYmEtMTFlYi1hNDQ3LTAyNDJhYzE

## p0467
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:09:30.858Z
```
{"timestamp":1732349370858221800,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"[ undefined, undefined ]"}
```
Same service, the 2 minutes before (oldest first):
  08:09:29.124 [front-end] POST /orders 201 - ms - -
  08:09:29.142 [front-end] GET /catalogue 200 - ms - -  (×2)
  08:09:29.701 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418dafa437380001deeed7"}
  08:09:29.711 [front-end] POST /addresses 200 - ms - -
  08:09:29.717 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67418dafa437380001deeed7"}
  08:09:29.728 [front-end] POST /cards 200 - ms - -
  08:09:29.774 [front-end] Attempting to delete cart for user: 67418dafa437380001deeed7
  08:09:29.788 [front-end] User cart deleted with status: 202
  08:09:29.790 [front-end] DELETE /cart 202 - ms - -
  08:09:29.797 [front-end] Attempting to add to cart: {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","quantity":1}
  08:09:29.804 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/
  08:09:29.804 [front-end] POST to carts: http://carts/carts/67418dafa437380001deeed7/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}
  08:09:29.839 [front-end] POST /cart 201 - ms - -
  08:09:30.837 [front-end] Request received with body: {}
  08:09:30.848 [front-end] Received response: "{\"firstName\":\"OZypdwngfo\",\"lastName\":\"OZypdwngfo\",\"username\":\"OZypdwngfo\",\"id\":\"67418da0a437380001deeea7\",\"_links\":{\"addr
  08:09:30.848 [front-end] GET Request to: http://user/customers/67418da0a437380001deeea7/addresses  (×2)
  08:09:30.858 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418
  08:09:30.858 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418daaa437380001deeec4\",\"_links\":{\"
All services, 30 seconds either side (sampled):
  08:09:01.716 [front-end] Request received with body: {}  (×67)
  08:09:01.760 [shipping] Adding shipment to queue...  (×62)
  08:09:02.409 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418d99a437380001deee92"}  (×62)
  08:09:02.519 [catalogue] ts=2024-11-23T08:09:02Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.928201  (×57)
  08:09:02.940 [carts] 2024-11-23 08:09:02.939 INFO [carts,8ae3da787092af8c,08a7ed1d44798dda,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.CartsController : Merge carts reques  (×32)
  08:09:03.560 [user] ts=2024-11-23T08:09:03.560604862Z caller=middlewares.go:46 method=Register username=OhaHddoInhscx email=OhaHddoInhscx@gmail.com took=1.886509ms  (×31)
  08:09:04.609 [front-end] Posting Customer: {"username":"OZypdwngfo","password":"qAcSdguMQp","email":"OZypdwngfo@gmail.com","firstName":"OZypdwngfo","lastName":"OZypdwngfo"}
  08:09:05.784 [front-end] Order response: {"id":"67418da13f77060008864ec8","customerId":"67418d8ba437380001deee65","customer":{"id":null,"firstName":"NFZvBQYjJMLA","lastName":"NFZvBQYjJM
  08:09:07.742 [front-end] Posting Customer: {"username":"FCjqhZGnA","password":"lHXMak","email":"FCjqhZGnA@gmail.com","firstName":"FCjqhZGnA","lastName":"FCjqhZGnA"}
  08:09:10.576 [front-end] Received response: "{\"firstName\":\"HAqEaMq\",\"lastName\":\"HAqEaMq\",\"username\":\"HAqEaMq\",\"id\":\"67418d99a437380001deee92\",\"_links\":{\"addresses\":{
  08:09:13.132 [front-end] Order response: {"id":"67418da93f77060008864ed0","customerId":"67418d91a437380001deee7b","customer":{"id":null,"firstName":"jAzlfC","lastName":"jAzlfC","usernam
  08:09:17.442 [queue-master] 2024-11-23 08:09:17.441 INFO 7 --- [pool-6-thread-3] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×27)
  08:09:19.716 [payment] ts=2024-11-23T08:09:19Z caller=logging.go:29 method=Authorise result=false took=7.407µs  (×5)
  08:09:22.700 [front-end] Order response: {"id":"67418db23f77060008864ed5","customerId":"67418da1a437380001deeea8","customer":{"id":null,"firstName":"ASMnZx","lastName":"ASMnZx","usernam
  08:09:23.406 [front-end] Order response: {"id":"67418db33f77060008864ed9","customerId":"67418da2a437380001deeeab","customer":{"id":null,"firstName":"oQylUZky","lastName":"oQylUZky","use
  08:09:25.853 [front-end] Posting Customer: {"username":"NADTKWdTwURTgp","password":"qJKDGcE","email":"NADTKWdTwURTgp@gmail.com","firstName":"NADTKWdTwURTgp","lastName":"NADTKWdTwURTgp"}
  08:09:28.305 [front-end] Posting Customer: {"username":"ecKrrWNwyZCE","password":"ruCPLOSlgL","email":"ecKrrWNwyZCE@gmail.com","firstName":"ecKrrWNwyZCE","lastName":"ecKrrWNwyZCE"}
  08:09:30.941 [front-end] Received response: "{\"firstName\":\"FCjqhZGnA\",\"lastName\":\"FCjqhZGnA\",\"username\":\"FCjqhZGnA\",\"id\":\"67418da3a437380001deeeb2\",\"_links\":{\"address
  08:09:33.097 [front-end] Posting Customer: {"username":"fHRKG","password":"OIOtH","email":"fHRKG@gmail.com","firstName":"fHRKG","lastName":"fHRKG"}
  08:09:37.178 [front-end] Order response: {"id":"67418dc13f77060008864ee5","customerId":"67418daea437380001deeed5","customer":{"id":null,"firstName":"RpUSJxvm","lastName":"RpUSJxvm","use
  08:09:39.669 [front-end] Posting Customer: {"username":"nSnRMsZHmp","password":"DIIZcXMxuO","email":"nSnRMsZHmp@gmail.com","firstName":"nSnRMsZHmp","lastName":"nSnRMsZHmp"}
  08:09:44.908 [front-end] Order response: {"id":"67418dc83f77060008864ee8","customerId":"67418dafa437380001deeed7","customer":{"id":null,"firstName":"oHrsSIwSDZhTO","lastName":"oHrsSIwSD
  08:09:47.867 [front-end] Order response: {"statusCode":201,"body":{"id":"67418dcb3f77060008864eec","customerId":"67418db7a437380001deeeeb","customer":{"id":null,"firstName":"WVZVAM","la
  08:09:50.404 [front-end] Received response: "{\"firstName\":\"iZxmprQJBS\",\"lastName\":\"iZxmprQJBS\",\"username\":\"iZxmprQJBS\",\"id\":\"67418db4a437380001deeedf\",\"_links\":{\"addr
  08:09:52.850 [front-end] Received response: "{\"firstName\":\"XfeCFQskHTSnulA\",\"lastName\":\"XfeCFQskHTSnulA\",\"username\":\"XfeCFQskHTSnulA\",\"id\":\"67418dbea437380001deef04\",\"_
  08:09:55.987 [front-end] Received response: "{\"firstName\":\"wdxGl\",\"lastName\":\"wdxGl\",\"username\":\"wdxGl\",\"id\":\"67418dc1a437380001deef0a\",\"_links\":{\"addresses\":{\"href
  08:09:56.869 [front-end] Order response: {"id":"67418dd43f77060008864ef8","customerId":"67418dc5a437380001deef1d","customer":{"id":null,"firstName":"rhpCcq","lastName":"rhpCcq","usernam
  08:09:59.106 [front-end] Order response: {"statusCode":201,"body":{"id":"67418dd73f77060008864efc","customerId":"67418dc3a437380001deef14","customer":{"id":null,"firstName":"nSnRMsZHmp"
  08:10:00.359 [user] ts=2024-11-23T08:10:00.359440552Z caller=middlewares.go:46 method=Register username=raOgiaeI email=raOgiaeI@gmail.com took=2.251551ms

## p0651
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-11T02:47:19.504Z
```
{"service":"mobservice1","message":"2021-08-11 02:47:19,504 | INFO | 0.0.0.1 | 172.17.0.5 | mobservice1 | 859ff8ae934b21ee | now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  02:47:15.477 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  02:47:15.478 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '617bd410-fa0b-11eb-90d9-0242ac110004'}  (×4)
  02:47:15.549 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '617bd410-fa0b-11eb-90d9-0242ac110004', 'value': 'PUILkhrM'}  (×4)
  02:47:15.643 [mobservice1] INFO info 617bd410-fa0b-11eb-90d9-0242ac110004:PUILkhrM write success
  02:47:17.491 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  02:47:17.622 [mobservice1] INFO info 62ad40e4-fa0b-11eb-b4eb-0242ac110004:WRbeulvc write success
  02:47:18.097 [mobservice1] INFO info 62faecae-fa0b-11eb-b6f2-0242ac110004:ockFwOnC write success
  02:47:18.821 [mobservice1] INFO info 6366b484-fa0b-11eb-887c-0242ac110004:nBSDicYe write success
All services, 30 seconds either side (sampled):
  02:46:49.530 [dbservice2] INFO query = select passwards from username_table where user_name='yHoAlkMd'  (×36)
  02:46:49.687 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  02:46:49.921 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×40)
  02:46:50.074 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×42)
  02:46:50.169 [logservice2] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '5245cc6c-fa0b-11eb-a589-0242ac110004', 'user_id': 'bTPjsUVJ'}  (×85)
  02:46:50.774 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×52)
  02:46:51.696 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×44)
  02:46:52.043 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '53ab3fc4-fa0b-11eb-acf0-0242ac110003', 'value': '', 'ex': 10}  (×43)
  02:46:53.244 [mobservice1] INFO info 54254c4c-fa0b-11eb-b55b-0242ac110003:dFRVcSCY write success
  02:46:55.921 [mobservice1] INFO info 55c0bd2a-fa0b-11eb-b5f8-0242ac110003:osKDHrgX write success
  02:46:58.118 [dbservice2] INFO 56ebce2e-fa0b-11eb-a782-0242ac110003-JeRfoygk-7AZktBHf9zNu token generate success token=MTYyODYyMTIxOC4xMTgzMTIxOjU2ZWJjZTJlLWZhMGItMTFlYi1hNzgyLTAyNDJhYzE  (×6)
  02:47:00.992 [dbservice2] INFO 5892bdfa-fa0b-11eb-84d9-0242ac110003-lTYxuZoK-3UtL7AG$HnN5 token generate success token=MTYyODYyMTIyMC45OTIyNDM4OjU4OTJiZGZhLWZhMGItMTFlYi04NGQ5LTAyNDJhYzE
  02:47:03.441 [mobservice2] INFO info 5a40e7d0-fa0b-11eb-8921-0242ac110004:WYMpZilL write success
  02:47:05.829 [dbservice2] INFO 5b787afa-fa0b-11eb-b6c2-0242ac110004-WQyFOAmB-#WsQM+91Ce2R token generate success token=MTYyODYyMTIyNS44MjkzMTY2OjViNzg3YWZhLWZhMGItMTFlYi1iNmMyLTAyNDJhYzE
  02:47:08.634 [mobservice1] INFO info 5d62a494-fa0b-11eb-8b33-0242ac110003:GLwvPubR write success
  02:47:11.902 [mobservice2] INFO info 5f4ca70a-fa0b-11eb-870c-0242ac110004:tBueHCAS write success
  02:47:14.324 [dbservice2] INFO 60978e18-fa0b-11eb-9d9b-0242ac110004-aLCdNFuD->*a5MwtuL=pF token generate success token=MTYyODYyMTIzNC4zMjQyNTEyOjYwOTc4ZTE4LWZhMGItMTFlYi05ZDliLTAyNDJhYzE
  02:47:16.715 [dbservice1] INFO 6200d570-fa0b-11eb-84a8-0242ac110003-OzKQAVJF-y0PH2h:lM}5T token generate success token=MTYyODYyMTIzNi43MTU0NjI0OjYyMDBkNTcwLWZhMGItMTFlYi04NGE4LTAyNDJhYzE
  02:47:19.149 [dbservice1] INFO 6366b484-fa0b-11eb-887c-0242ac110004-nBSDicYe-Xnmoyc%*g{)k token generate success token=MTYyODYyMTIzOS4xNDkxNTI4OjYzNjZiNDg0LWZhMGItMTFlYi04ODdjLTAyNDJhYzE
  02:47:21.732 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat  (×2)
  02:47:24.194 [dbservice1] INFO 666b2444-fa0b-11eb-a477-0242ac110003-GLwvPubR-c9O=AoplwGk_ token generate success token=MTYyODYyMTI0NC4xOTM4OTU4OjY2NmIyNDQ0LWZhMGItMTFlYi1hNDc3LTAyNDJhYzE
  02:47:26.638 [dbservice1] INFO 67ea02b8-fa0b-11eb-96d0-0242ac110003-OVLDMHZf-2*N=10SK9_YR token generate success token=MTYyODYyMTI0Ni42MzgxNjEyOjY3ZWEwMmI4LWZhMGItMTFlYi05NmQwLTAyNDJhYzE
  02:47:29.319 [dbservice1] INFO 6988e76a-fa0b-11eb-a362-0242ac110003-JjOStLkT-_GA<:4K/vjX@ token generate success token=MTYyODYyMTI0OS4zMTkzOTAzOjY5ODhlNzZhLWZhMGItMTFlYi1hMzYyLTAyNDJhYzE
  02:47:32.222 [dbservice2] INFO 6b24c738-fa0b-11eb-83cb-0242ac110004-DBUWXtFp-Tc5tA%i1s$&9 token generate success token=MTYyODYyMTI1Mi4yMjE5NzM3OjZiMjRjNzM4LWZhMGItMTFlYi04M2NiLTAyNDJhYzE
  02:47:34.856 [mobservice1] INFO info 6cfff820-fa0b-11eb-9b51-0242ac110003:wdBFovNq write success
  02:47:37.898 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  02:47:46.481 [dbservice1] INFO 73a75e84-fa0b-11eb-8e5a-0242ac110004-tRLZzuQg-6=h^0Kp$%lJx token generate success token=MTYyODYyMTI2Ni40ODE2MzI1OjczYTc1ZTg0LWZhMGItMTFlYi04ZTVhLTAyNDJhYzE
  02:47:48.981 [mobservice2] INFO info 75601716-fa0b-11eb-b0b3-0242ac110004:VaMiodsE write success

## p0311
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:20:27.096Z
```
{"timestamp":1732245627096874200,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:20:27.09633284Z caller=middlewares.go:157 method=Health result=2 took=577.968µs"}
```
Same service, the 2 minutes before (oldest first):
  03:20:25.350 [user] ts=2024-11-22T03:20:25.350088947Z caller=middlewares.go:104 method=GetAddresses id=673ff871b0df5c00019b1ed8 result=1 took=748.046µs
  03:20:25.350 [user] ts=2024-11-22T03:20:25.350080818Z caller=middlewares.go:134 method=GetCards id=673ff871b0df5c00019b1ed9 result=1 took=795.123µs  (×2)
  03:20:25.350 [user] ts=2024-11-22T03:20:25.350197622Z caller=middlewares.go:75 method=GetUsers id=673ff86ab0df5c00019b1ec0 result=1 took=912.945µs  (×5)
  03:20:25.425 [user] ts=2024-11-22T03:20:25.425063329Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff874b0df5c00019b1ee8 took=1.678027ms  (×5)
  03:20:25.437 [user] ts=2024-11-22T03:20:25.437625317Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff874b0df5c00019b1ee8 took=1.668976ms  (×5)
  03:20:26.021 [user] ts=2024-11-22T03:20:26.02130018Z caller=middlewares.go:46 method=Register username=HLNoIPafm email=HLNoIPafm@gmail.com took=1.058226ms
  03:20:26.483 [user] ts=2024-11-22T03:20:26.483362204Z caller=middlewares.go:104 method=GetAddresses id=673ff86ab0df5c00019b1ec1 result=1 took=1.200901ms
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×31)
  03:20:06.543 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff  (×50)
  03:20:06.590 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245606587,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×50)
  03:20:06.664 [user] ts=2024-11-22T03:20:06.664037694Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff861b0df5c00019b1e9e took=1.670187ms  (×51)
  03:20:06.789 [front-end] POST to carts: http://carts/carts/673ff861b0df5c00019b1e9e/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}  (×16)
  03:20:06.949 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×3)
  03:20:08.469 [front-end] Posting Customer: {"username":"HNCLfJfsnW","password":"sSvsy","email":"HNCLfJfsnW@gmail.com","firstName":"HNCLfJfsnW","lastName":"HNCLfJfsnW"}
  03:20:08.498 [front-end] set cookie673ff868b0df5c00019b1eb9  (×49)
  03:20:09.096 [front-end] Received response: "{\"firstName\":\"IfuCg\",\"lastName\":\"IfuCg\",\"username\":\"IfuCg\",\"id\":\"673ff851b0df5c00019b1e79\",\"_links\":{\"addresses\":{\"href
  03:20:09.910 [front-end] Posting Customer: {"username":"uQhCpCJIyYL","password":"dElvDjn","email":"uQhCpCJIyYL@gmail.com","firstName":"uQhCpCJIyYL","lastName":"uQhCpCJIyYL"}
  03:20:11.559 [user] ts=2024-11-22T03:20:11.558844653Z caller=middlewares.go:46 method=Register username=xQhxkcD email=xQhxkcD@gmail.com took=1.123618ms
  03:20:14.239 [front-end] Posting Customer: {"username":"burOTnWrVFcFcR","password":"JMCDouKzn","email":"burOTnWrVFcFcR@gmail.com","firstName":"burOTnWrVFcFcR","lastName":"burOTnWrVFcFcR
  03:20:16.376 [front-end] Posting Customer: {"username":"zCHyJV","password":"DBVYLG","email":"zCHyJV@gmail.com","firstName":"zCHyJV","lastName":"zCHyJV"}
  03:20:18.305 [front-end] Received response: "{\"firstName\":\"SxecnNeiPQ\",\"lastName\":\"SxecnNeiPQ\",\"username\":\"SxecnNeiPQ\",\"id\":\"673ff861b0df5c00019b1e9f\",\"_links\":{\"addr
  03:20:20.952 [user] ts=2024-11-22T03:20:20.951976065Z caller=middlewares.go:46 method=Register username=tJMqzAgJI email=tJMqzAgJI@gmail.com took=1.117996ms
  03:20:24.692 [carts] 2024-11-22 03:20:24.692 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  03:20:28.055 [front-end] Received response: "{\"firstName\":\"ihYowTIIUzglApd\",\"lastName\":\"ihYowTIIUzglApd\",\"username\":\"ihYowTIIUzglApd\",\"id\":\"673ff86bb0df5c00019b1ec4\",\"_
  03:20:30.097 [front-end] Posting Customer: {"username":"dStkYebBky","password":"aPZcljShz","email":"dStkYebBky@gmail.com","firstName":"dStkYebBky","lastName":"dStkYebBky"}
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.372 [front-end] Received response: "{\"firstName\":\"CBhyKd\",\"lastName\":\"CBhyKd\",\"username\":\"CBhyKd\",\"id\":\"673ff869b0df5c00019b1eba\",\"_links\":{\"addresses\":{\"h
  03:20:36.743 [front-end] Received response: "{\"firstName\":\"UzagwCTnbpaXVzA\",\"lastName\":\"UzagwCTnbpaXVzA\",\"username\":\"UzagwCTnbpaXVzA\",\"id\":\"673ff86fb0df5c00019b1ed4\",\"_
  03:20:38.171 [session-db] 1:M 22 Nov 2024 03:20:38.171 * Background saving terminated with success
  03:20:41.176 [front-end] Received response: "{\"firstName\":\"dpZIGojLodgB\",\"lastName\":\"dpZIGojLodgB\",\"username\":\"dpZIGojLodgB\",\"id\":\"673ff87bb0df5c00019b1efc\",\"_links\":{
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  03:20:43.391 [carts] 2024-11-22 03:20:43.391 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:20:47.926 [front-end] Posting Customer: {"username":"XYDErsNhuY","password":"RuOOlZc","email":"XYDErsNhuY@gmail.com","firstName":"XYDErsNhuY","lastName":"XYDErsNhuY"}
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/browser/**] onto handler of type [class org.sp
  03:20:51.235 [front-end] Posting Customer: {"username":"cqPFUedoarsUCI","password":"BNbmkot","email":"cqPFUedoarsUCI@gmail.com","firstName":"cqPFUedoarsUCI","lastName":"cqPFUedoarsUCI"}
  03:20:54.518 [front-end] Posting Customer: {"username":"aZnbBrPviPwcYcC","password":"cLxGTi","email":"aZnbBrPviPwcYcC@gmail.com","firstName":"aZnbBrPviPwcYcC","lastName":"aZnbBrPviPwcYc
  03:20:56.805 [front-end] Posting Customer: {"username":"nLZjIlByeidrL","password":"SRNOEYM","email":"nLZjIlByeidrL@gmail.com","firstName":"nLZjIlByeidrL","lastName":"nLZjIlByeidrL"}

## p0043
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice2, 2021-08-13T08:02:11.039Z
```
{"service":"logservice2","message":"2021-08-13 08:02:11,039 | ERROR | 0.0.0.2 | logservice2 | login_helper.py -> login_query_methods_model -> 93 | b83abebaa031f08a | get information failed, fail code: 400"}
```
Same service, the 2 minutes before (oldest first):
  08:02:01.337 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'af0da0f4-fbc9-11eb-8351-0242ac110003'}  (×3)
  08:02:01.388 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×2)
  08:02:01.388 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×2)
  08:02:01.388 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': 'af0da0f4-fbc9-11eb-8351-0242ac110003', 'user_id': 'ZRAoufan'}  (×4)
  08:02:04.086 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  08:02:04.086 [logservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×2)
  08:02:06.900 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×2)
  08:02:06.901 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×2)
  08:02:11.039 [logservice2] ERROR uuid expired, invalid phone request
All services, 30 seconds either side (sampled):
  08:01:41.064 [redisservice2] INFO redis write success  (×89)
  08:01:41.197 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×34)
  08:01:41.279 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×34)
  08:01:41.369 [redisservice1] INFO service refuse, status_code: 200  (×22)
  08:01:41.441 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×42)
  08:01:41.519 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'a37ea792-fbc9-11eb-8204-0242ac110003', 'value': '', 'ex': 10}  (×38)
  08:01:41.702 [webservice1] INFO complete information: {'uuid': 'a37ea792-fbc9-11eb-8204-0242ac110003', 'user_id': 'tBueHCAS'}  (×38)
  08:01:42.356 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  08:01:42.565 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×46)
  08:01:42.681 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×45)
  08:01:42.805 [dbservice1] INFO a3e42040-fbc9-11eb-8998-0242ac110004-SpJzmrVL-uO+f&?:*M^mq token generate success token=MTYyODgxMjkwMi44MDUyMzU5OmEzZTQyMDQwLWZiYzktMTFlYi04OTk4LTAyNDJhYzE
  08:01:44.677 [dbservice1] INFO a4f43c9a-fbc9-11eb-8f3a-0242ac110004-lHsQhqSv-$gNJ%:rR12(V token generate success token=MTYyODgxMjkwNC42NzY4MjQzOmE0ZjQzYzlhLWZiYzktMTFlYi04ZjNhLTAyNDJhYzE
  08:01:47.268 [mobservice1] INFO info a6af6e88-fbc9-11eb-92a3-0242ac110004:lGPfCvhn write success
  08:01:49.572 [mobservice1] INFO info a81dd96c-fbc9-11eb-aecc-0242ac110004:saJCEzRp write success
  08:01:52.106 [mobservice2] INFO info a99e0708-fbc9-11eb-96ac-0242ac110003:wRjEsaDr write success
  08:01:54.362 [mobservice2] INFO info aafe8654-fbc9-11eb-9a2f-0242ac110004:VaMiodsE write success
  08:01:57.282 [mobservice2] INFO info acb66372-fbc9-11eb-9dcd-0242ac110004:lkNrGYTL write success
  08:01:59.112 [mobservice2] INFO info adcc9ac4-fbc9-11eb-9192-0242ac110003:IKTgrkvl write success
  08:02:10.890 [mobservice2] ERROR uuid:ae4829b4-fbc9-11eb-9224-0242ac110004 information has expired, mobile phone login is invalid
  08:02:12.374 [mobservice1] INFO info b5a8f274-fbc9-11eb-934b-0242ac110003:TIlYNQVq write success
  08:02:15.058 [mobservice2] INFO info b74b0e82-fbc9-11eb-a6be-0242ac110004:jnAxEKot write success
  08:02:17.719 [mobservice2] INFO info b8e86244-fbc9-11eb-b7ef-0242ac110003:HkLmPgZU write success
  08:02:20.404 [dbservice1] INFO ba4716d0-fbc9-11eb-b839-0242ac110004-ckfeNPTM-WcHR.sT#4DEu token generate success token=MTYyODgxMjk0MC40MDQwNjU4OmJhNDcxNmQwLWZiYzktMTFlYi1iODM5LTAyNDJhYzE
  08:02:22.041 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  08:02:25.991 [mobservice2] INFO info bdcc0e64-fbc9-11eb-bc99-0242ac110004:wdBFovNq write success
  08:02:27.943 [dbservice1] INFO bec23a8c-fbc9-11eb-8ece-0242ac110004-oYLfmtrx-&koh*.@3{sGE token generate success token=MTYyODgxMjk0Ny45NDI5Njg6YmVjMjNhOGMtZmJjOS0xMWViLThlY2UtMDI0MmFjMTE
  08:02:31.065 [dbservice1] INFO c09fe606-fbc9-11eb-bc15-0242ac110003-QClFzynH-qP%6L:4dAwRi token generate success token=MTYyODgxMjk1MS4wNjUwMDcyOmMwOWZlNjA2LWZiYzktMTFlYi1iYzE1LTAyNDJhYzE
  08:02:33.966 [mobservice1] INFO info c28ce234-fbc9-11eb-b842-0242ac110004:wcXjOMum write success
  08:02:35.874 [dbservice1] INFO c3801f44-fbc9-11eb-8918-0242ac110003-VxubFBRX-Qgr73J_$>S}{ token generate success token=MTYyODgxMjk1NS44NzM4MDA4OmMzODAxZjQ0LWZiYzktMTFlYi04OTE4LTAyNDJhYzE
  08:02:40.826 [mobservice2] INFO info c6ac2b4a-fbc9-11eb-9099-0242ac110004:hVyjbRgD write success

## p0594
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T20:02:12.716Z
```
{"timestamp":1733601732716408600,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-w6jt4","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:02:12.716  INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl         : Routes Response is : Response(status=1, msg=Success, data={id=92708982-77af-4318-be25-57ccb0ff69ad, stations=[nanjing, zhenjiang, wuxi, suzhou, shanghai], distances=[0, 100, 150, 200, 250], startStationId=nanjing, terminalStationId=shanghai})"}
```
Same service, the 2 minutes before (oldest first):
  20:02:12.317 [ts-travel-service] 2024-12-07 20:02:12.317 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×3)
  20:02:12.338 [ts-travel-service] 2024-12-07 20:02:12.337 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×3)
  20:02:12.342 [ts-travel-service] 2024-12-07 20:02:12.341 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×3)
  20:02:12.353 [ts-travel-service] 2024-12-07 20:02:12.353 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×2)
  20:02:12.353 [ts-travel-service] 2024-12-07 20:02:12.353 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×2)
  20:02:12.440 [ts-travel-service] 2024-12-07 20:02:12.440 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s
  20:02:12.455 [ts-travel-service] 2024-12-07 20:02:12.455 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat
  20:02:12.497 [ts-travel-service] 2024-12-07 20:02:12.497 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr  (×2)
  20:02:12.509 [ts-travel-service] 2024-12-07 20:02:12.509 INFO 1 --- [io-12346-exec-9] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234  (×2)
  20:02:12.608 [ts-travel-service] 2024-12-07 20:02:12.608 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter
All services, 30 seconds either side (sampled):
  20:01:42.734 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T20:01:42.734+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360170
  20:01:43.283 [ts-auth-service] 2024-12-07 20:01:43.282 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×21)
  20:01:43.353 [ts-travel-service] 2024-12-07 20:01:43.352 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×4)
  20:01:43.503 [ts-travel2-service] 2024-12-07 20:01:43.503 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×115)
  20:01:44.524 [ts-travel-service] 2024-12-07 20:01:44.523 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×49)
  20:01:46.093 [ts-auth-service] 2024-12-07 20:01:46.092 INFO 1 --- [io-12340-exec-9] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×11)
  20:01:46.489 [ts-basic-service] 2024-12-07 20:01:46.489 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×16)
  20:01:46.523 [ts-travel2-service] 2024-12-07 20:01:46.523 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×10)
  20:01:46.639 [ts-seat-service] 2024-12-07 20:01:46.639 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×35)
  20:01:46.698 [ts-seat-service] 2024-12-07 20:01:46.698 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×35)
  20:01:46.920 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:01:46 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 356 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×10)
  20:01:49.681 [ts-travel2-service] 2024-12-07 20:01:49.681 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  20:01:49.979 [ts-seat-service] 2024-12-07 20:01:49.978 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  20:01:55.405 [ts-order-other-service] 2024-12-07 20:01:55.404 INFO 1 --- [io-12032-exec-1] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-
  20:01:55.969 [ts-consign-service] 2024-12-07 20:01:55.969 INFO 1 --- [io-16111-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  20:01:57.684 [ts-consign-service] 2024-12-07 20:01:57.684 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] 1f1f879c-bbef-4b89-9eba-
  20:02:00.468 [ts-consign-service] 2024-12-07 20:02:00.468 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : SAVE consign result : ConsignRecord(id=c6db72a1-41a6-41ef-972c-938f481
  20:02:07.502 [ts-admin-basic-info-service] 2024-12-07 20:02:07.502 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  20:02:07.931 [ts-travel-service] 2024-12-07 20:02:07.930 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×9)
  20:02:08.027 [ts-order-service] 2024-12-07 20:02:08.027 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×17)
  20:02:08.406 [ts-basic-service] 2024-12-07 20:02:08.406 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f  (×2)
  20:02:10.072 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:02:10 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 924 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×3)
  20:02:12.978 [ts-basic-service] 2024-12-07 20:02:12.977 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×4)
  20:02:13.557 [ts-order-service] 2024-12-07 20:02:13.557 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00 
  20:02:24.182 [ts-order-service] 2024-12-07 20:02:24.181 INFO 1 --- [io-12031-exec-6] order.controller.OrderController : [Order Other Service][Get Order By Id] Order Id: 617a302e-aa6a-4413-95f7  (×2)
  20:02:28.280 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-07T20:02:28.280+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360174
  20:02:30.771 [ts-station-mongo] {"t":{"$date":"2024-12-07T20:02:30.771+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360175
  20:02:31.519 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-07T20:02:31.519+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360175
  20:02:33.593 [ts-basic-service] 2024-12-07 20:02:33.593 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：92708982-77
  20:02:34.453 [ts-order-service] 2024-12-07 20:02:34.453 INFO 1 --- [io-12031-exec-7] org.mongodb.driver.connection : Opened connection [connectionId{localValue:3, serverValue:17}] to ts-order-

## p0426
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T04:10:02.484Z
```
{"timestamp":1732248602484716500,"container_name":"front-end","pod_name":"front-end-ccbbfbf7f-szg8d","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"set cookie6740041ab0df5c00019b427a"}
```
Same service, the 2 minutes before (oldest first):
  04:10:01.890 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67400406b0df5c00019b4241\",\"_links\":{\"
  04:10:01.891 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67400
  04:10:01.891 [front-end] [ undefined, undefined ]
  04:10:01.891 [front-end] Posting Order: {"customer":"http://user/customers/674003ffb0df5c00019b4227","address":"http://user/addresses/67400406b0df5c00019b4240","card":"http://user/cards
  04:10:01.925 [front-end] Order response: {"statusCode":201,"body":{"id":"67400419d94b9000069b4cc2","customerId":"674003ffb0df5c00019b4227","customer":{"id":null,"firstName":"DfCwmDuL","
  04:10:01.925 [front-end] Order response: {"id":"67400419d94b9000069b4cc2","customerId":"674003ffb0df5c00019b4227","customer":{"id":null,"firstName":"DfCwmDuL","lastName":"DfCwmDuL","use
  04:10:01.926 [front-end] POST /orders 201 - ms - -
  04:10:02.000 [front-end] Posting Customer: {"username":"meFNFRIEjGvSI","password":"xhKzKAMr","email":"meFNFRIEjGvSI@gmail.com","firstName":"meFNFRIEjGvSI","lastName":"meFNFRIEjGvSI"}
  04:10:02.007 [front-end] { id: '6740041ab0df5c00019b4279' }  (×2)
  04:10:02.007 [front-end] 6740041ab0df5c00019b4279  (×2)
  04:10:02.007 [front-end] Merging carts for customer id: 6740041ab0df5c00019b4279 and session id: KkZrOzNoqKgxA2YV9xemsYfowSvZTYBW  (×2)
  04:10:02.034 [front-end] Carts merged.  (×2)
  04:10:02.034 [front-end] set cookie6740041ab0df5c00019b4279
  04:10:02.034 [front-end] Sent cookies.
  04:10:02.035 [front-end] POST /register 200 34.437 ms - 33
  04:10:02.426 [front-end] Posting Customer: {"username":"xpebVbCrQhNpLKd","password":"EchNWxinZD","email":"xpebVbCrQhNpLKd@gmail.com","firstName":"xpebVbCrQhNpLKd","lastName":"xpebVbCrQh
All services, 30 seconds either side (sampled):
  04:09:32.503 [carts] 2024-11-22 04:09:32.503 INFO [carts,96c79888f43f3e9f,be940d79d3f52af1,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.controllers.ItemsController : Did not find item.  (×13)
  04:09:32.640 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"674003edb0df5c00019b4200\",\"_links\":{\"  (×33)
  04:09:32.667 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732248572665,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×6)
  04:09:32.999 [front-end] 674003fcb0df5c00019b4222  (×40)
  04:09:33.059 [user] ts=2024-11-22T04:09:33.058940046Z caller=middlewares.go:46 method=Register username=fOItCGVRDiGoBr email=fOItCGVRDiGoBr@gmail.com took=963.819µs  (×9)
  04:09:33.821 [shipping] Adding shipment to queue...  (×27)
  04:09:33.992 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"674003f7b0df5c00019b4219"}  (×36)
  04:09:34.087 [front-end] DELETE /cart 202 - ms - -  (×36)
  04:09:34.843 [payment] ts=2024-11-22T04:09:34Z caller=logging.go:40 method=Health result=1 took=6.925µs  (×24)
  04:09:35.758 [front-end] POST to carts: http://carts/carts/674003f5b0df5c00019b4211/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×22)
  04:09:36.256 [user] ts=2024-11-22T04:09:36.256351015Z caller=middlewares.go:46 method=Register username=JhkaDNQ email=JhkaDNQ@gmail.com took=1.029832ms
  04:09:37.419 [front-end] Received response: "{\"firstName\":\"SgJyKu\",\"lastName\":\"SgJyKu\",\"username\":\"SgJyKu\",\"id\":\"674003f1b0df5c00019b4206\",\"_links\":{\"addresses\":{\"h
  04:09:40.181 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×6)
  04:09:42.521 [front-end] Posting Customer: {"username":"deYddbxklhc","password":"aHFoJwNnF","email":"deYddbxklhc@gmail.com","firstName":"deYddbxklhc","lastName":"deYddbxklhc"}
  04:09:43.688 [front-end] Order response: {"id":"67400407d94b9000069b4cb1","customerId":"674003f5b0df5c00019b4210","customer":{"id":null,"firstName":"FJXsIdiSnhw","lastName":"FJXsIdiSnhw
  04:09:45.287 [front-end] Received response: "{\"firstName\":\"sVTPAABTrSHIa\",\"lastName\":\"sVTPAABTrSHIa\",\"username\":\"sVTPAABTrSHIa\",\"id\":\"674003ecb0df5c00019b41fd\",\"_links\
  04:09:48.060 [user] ts=2024-11-22T04:09:48.060418558Z caller=middlewares.go:46 method=Register username=ObRvnt email=ObRvnt@gmail.com took=1.000507ms
  04:09:49.668 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×6)
  04:09:51.324 [front-end] Order response: {"id":"6740040fd94b9000069b4cb7","customerId":"674003fcb0df5c00019b4222","customer":{"id":null,"firstName":"pIrgcEToyND","lastName":"pIrgcEToyND
  04:09:54.343 [front-end] Received response: "{\"firstName\":\"RUXlbarS\",\"lastName\":\"RUXlbarS\",\"username\":\"RUXlbarS\",\"id\":\"674003fab0df5c00019b421c\",\"_links\":{\"addresses\
  04:09:55.861 [front-end] Received response: "{\"firstName\":\"CwQYY\",\"lastName\":\"CwQYY\",\"username\":\"CwQYY\",\"id\":\"674003ffb0df5c00019b4229\",\"_links\":{\"addresses\":{\"href
  04:09:57.386 [front-end] Received response: "{\"firstName\":\"fOItCGVRDiGoBr\",\"lastName\":\"fOItCGVRDiGoBr\",\"username\":\"fOItCGVRDiGoBr\",\"id\":\"674003fdb0df5c00019b4223\",\"_lin
  04:09:58.553 [front-end] Order response: {"id":"67400416d94b9000069b4cbe","customerId":"67400400b0df5c00019b422b","customer":{"id":null,"firstName":"MlNQi","lastName":"MlNQi","username"
  04:09:58.810 [queue-master] 2024-11-22 04:09:58.810 ERROR 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×7)
  04:09:59.717 [user] ts=2024-11-22T04:09:59.716879358Z caller=middlewares.go:46 method=Register username=JXtVHMuG email=JXtVHMuG@gmail.com took=1.107072ms
  04:10:01.925 [front-end] Order response: {"id":"67400419d94b9000069b4cc2","customerId":"674003ffb0df5c00019b4227","customer":{"id":null,"firstName":"DfCwmDuL","lastName":"DfCwmDuL","use
  04:10:04.401 [front-end] Order response: {"statusCode":201,"body":{"id":"6740041cd94b9000069b4cc4","customerId":"67400404b0df5c00019b4232","customer":{"id":null,"firstName":"vAAfQarfFvQ
  04:10:06.488 [front-end] Received response: "{\"firstName\":\"KTBOBoX\",\"lastName\":\"KTBOBoX\",\"username\":\"KTBOBoX\",\"id\":\"67400406b0df5c00019b423e\",\"_links\":{\"addresses\":{

## p0312
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service catalogue, 2024-11-22T03:20:31.352Z
```
{"timestamp":1732245631352795400,"container_name":"catalogue","pod_name":"catalogue-b98c66547-q2k66","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:20:31Z caller=logging.go:85 method=Health result=2 took=20.054µs"}
```
Same service, the 2 minutes before (oldest first):
  03:20:24.416 [catalogue] ts=2024-11-22T03:20:24Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.349967  (×7)
  03:20:24.554 [catalogue] ts=2024-11-22T03:20:24Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.056554ms  (×9)
  03:20:25.352 [catalogue] ts=2024-11-22T03:20:25Z caller=logging.go:85 method=Health result=2 took=27.77µs  (×4)
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×34)
  03:20:06.543 [front-end] Posting Order: {"customer":"http://user/customers/673ff84eb0df5c00019b1e6c","address":"http://user/addresses/673ff854b0df5c00019b1e7e","card":"http://user/cards  (×52)
  03:20:06.649 [user] ts=2024-11-22T03:20:06.649242768Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff861b0df5c00019b1e9e took=1.734848ms  (×57)
  03:20:06.789 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×9)
  03:20:07.186 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×10)
  03:20:08.474 [front-end] 673ff868b0df5c00019b1eb9  (×55)
  03:20:09.093 [user] ts=2024-11-22T03:20:09.093533288Z caller=middlewares.go:46 method=Register username=CBhyKd email=CBhyKd@gmail.com took=1.350871ms
  03:20:09.910 [front-end] Posting Customer: {"username":"uQhCpCJIyYL","password":"dElvDjn","email":"uQhCpCJIyYL@gmail.com","firstName":"uQhCpCJIyYL","lastName":"uQhCpCJIyYL"}
  03:20:12.002 [front-end] Received response: "{\"firstName\":\"oVuSYHHeDcohK\",\"lastName\":\"oVuSYHHeDcohK\",\"username\":\"oVuSYHHeDcohK\",\"id\":\"673ff855b0df5c00019b1e85\",\"_links\
  03:20:15.090 [front-end] Received response: "{\"firstName\":\"NNuouUNggTNDT\",\"lastName\":\"NNuouUNggTNDT\",\"username\":\"NNuouUNggTNDT\",\"id\":\"673ff859b0df5c00019b1e89\",\"_links\
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:20.995 [front-end] Received response: "{\"firstName\":\"WQulX\",\"lastName\":\"WQulX\",\"username\":\"WQulX\",\"id\":\"673ff85fb0df5c00019b1e97\",\"_links\":{\"addresses\":{\"href
  03:20:26.017 [front-end] Posting Customer: {"username":"HLNoIPafm","password":"sBlBYfK","email":"HLNoIPafm@gmail.com","firstName":"HLNoIPafm","lastName":"HLNoIPafm"}
  03:20:29.280 [front-end] Received response: "{\"firstName\":\"iyaZwEHsMf\",\"lastName\":\"iyaZwEHsMf\",\"username\":\"iyaZwEHsMf\",\"id\":\"673ff861b0df5c00019b1ea0\",\"_links\":{\"addr
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.676 [front-end] Received response: "{\"firstName\":\"BBYdunXrngQk\",\"lastName\":\"BBYdunXrngQk\",\"username\":\"BBYdunXrngQk\",\"id\":\"673ff874b0df5c00019b1ee8\",\"_links\":{
  03:20:38.070 [session-db] 1:M 22 Nov 2024 03:20:38.070 * Background saving started by pid 32
  03:20:40.151 [user] ts=2024-11-22T03:20:40.151621717Z caller=middlewares.go:46 method=Register username=dOIvn email=dOIvn@gmail.com took=1.048258ms
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:20:46.654 [front-end] Received response: "{\"firstName\":\"iLqTiAFoVbIq\",\"lastName\":\"iLqTiAFoVbIq\",\"username\":\"iLqTiAFoVbIq\",\"id\":\"673ff877b0df5c00019b1eec\",\"_links\":{
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.sp
  03:20:51.235 [front-end] Posting Customer: {"username":"cqPFUedoarsUCI","password":"BNbmkot","email":"cqPFUedoarsUCI@gmail.com","firstName":"cqPFUedoarsUCI","lastName":"cqPFUedoarsUCI"}
  03:20:54.897 [front-end] Posting Customer: {"username":"cfTPDbfduekTBf","password":"FQrLzttH","email":"cfTPDbfduekTBf@gmail.com","firstName":"cfTPDbfduekTBf","lastName":"cfTPDbfduekTBf"
  03:20:58.176 [front-end] Received response: "{\"firstName\":\"MpDJxkmv\",\"lastName\":\"MpDJxkmv\",\"username\":\"MpDJxkmv\",\"id\":\"673ff87eb0df5c00019b1f00\",\"_links\":{\"addresses\
  03:20:59.688 [carts] 2024-11-22 03:20:59.688 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[OPTIONS],produces=[applica
  03:20:59.783 [carts] 2024-11-22 03:20:59.783 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal
  03:20:59.789 [carts] 2024-11-22 03:20:59.789 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],produc
  03:21:00.716 [front-end] Posting Customer: {"username":"bDjuXlWHATfWj","password":"ynjkfXmXiY","email":"bDjuXlWHATfWj@gmail.com","firstName":"bDjuXlWHATfWj","lastName":"bDjuXlWHATfWj"}

## p0200
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T06:55:49.281Z
```
{"timestamp":1731912949281445400,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  06:55:47.472 [currencyservice] conversion request successful  (×13)
  06:55:47.550 [currencyservice] Getting supported currencies...  (×7)
All services, 30 seconds either side (sampled):
  06:55:19.281 [cartservice] GetCartAsync called with userId=fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a  (×266)
  06:55:19.307 [adservice] received ad request (context_words=[accessories])  (×37)
  06:55:19.312 [frontend] adding to cart  (×39)
  06:55:19.328 [currencyservice] Getting supported currencies...  (×265)
  06:55:19.678 [frontend] setting currency  (×20)
  06:55:19.732 [adservice] received ad request (context_words=[])  (×35)
  06:55:20.292 [adservice] received ad request (context_words=[footwear])  (×18)
  06:55:24.511 [frontend] placing order  (×16)
  06:55:24.531 [paymentservice] Transaction processed: visa ending 7309 Amount: CAD614.139258736  (×8)
  06:55:24.536 [shippingservice] [ShipOrder] completed request  (×16)
  06:55:24.546 [checkoutservice] order confirmation email sent to "markarmstrong@example.com"
  06:55:25.122 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"138","nanos":796992485},"credit_card":{"credit_card_number":"46962994521724  (×4)
  06:55:25.137 [checkoutservice] order confirmation email sent to "frederickangela@example.com"
  06:55:28.385 [emailservice] A request to send order confirmation email to acox@example.net has been received.
  06:55:42.635 [emailservice] A request to send order confirmation email to stephanie21@example.net has been received.
  06:55:45.154 [checkoutservice] order confirmation email sent to "piercejenny@example.net"
  06:55:49.304 [emailservice] A request to send order confirmation email to ryanhenderson@example.org has been received.
  06:55:51.019 [checkoutservice] order confirmation email sent to "michaelsmall@example.com"
  06:56:00.850 [emailservice] A request to send order confirmation email to teresa99@example.net has been received.
  06:56:01.715 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"6874","nanos":237589592},"credit_card":{"credit_card_number":"4104874276998
  06:56:01.731 [checkoutservice] order confirmation email sent to "kimberly89@example.org"
  06:56:05.574 [paymentservice] Transaction processed: visa ending 1942 Amount: USD286.340000000  (×3)
  06:56:06.027 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', 'L9ECAV7KIM', '0PUK6V6EV0', 'OLJCESPC7Z']
  06:56:09.578 [emailservice] A request to send order confirmation email to paul13@example.com has been received.
  06:56:14.030 [redis] 1:M 18 Nov 2024 06:56:14.030 * 100 changes in 300 seconds. Saving...
  06:56:14.036 [redis] 69:C 18 Nov 2024 06:56:14.036 * Fork CoW for RDB: current 0 MB, peak 0 MB, average 0 MB
  06:56:16.109 [checkoutservice] order confirmation email sent to "evansjessica@example.org"
