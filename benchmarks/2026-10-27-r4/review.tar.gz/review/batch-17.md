## p0008
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-13T02:00:16.500Z
```
{"service":"mobservice1","message":"2021-08-13 02:00:16,500 | INFO | 0.0.0.1 | 172.17.0.5 | mobservice1 | 9480241014609751 | info 26073400-fb97-11eb-9df8-0242ac110003:sUWAVXFt write success"}
```
Same service, the 2 minutes before (oldest first):
  02:00:11.234 [mobservice1] INFO info 22d99bd8-fb97-11eb-8e96-0242ac110004:uloJcsne write success
  02:00:14.441 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  02:00:14.441 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  02:00:14.442 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '24ddda7a-fb97-11eb-87b5-0242ac110003'}  (×4)
  02:00:14.500 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '24ddda7a-fb97-11eb-87b5-0242ac110003', 'value': 'GxrcRlDj'}  (×4)
  02:00:14.555 [mobservice1] INFO info 24ddda7a-fb97-11eb-87b5-0242ac110003:GxrcRlDj write success
  02:00:15.326 [mobservice1] INFO info 2555855c-fb97-11eb-8ff8-0242ac110004:whQCkgBs write success
  02:00:16.049 [mobservice1] INFO info 25c2c838-fb97-11eb-a826-0242ac110003:wpOMLejE write success
All services, 30 seconds either side (sampled):
  01:59:46.545 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×46)
  01:59:46.826 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  01:59:46.985 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '14600a92-fb97-11eb-89d3-0242ac110003'}  (×52)
  01:59:47.133 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×37)
  01:59:47.847 [mobservice1] INFO info 14eaf256-fb97-11eb-9edd-0242ac110003:HCzNJuWb write success
  01:59:48.588 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  01:59:49.136 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '15eb2e50-fb97-11eb-bfc0-0242ac110004', 'value': '', 'ex': 10}  (×41)
  01:59:49.588 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '15eb2e50-fb97-11eb-bfc0-0242ac110004'}  (×34)
  01:59:50.933 [dbservice1] INFO 1673b950-fb97-11eb-8199-0242ac110003-TebkoQLO-YN(rC/LgHR*? token generate success token=MTYyODc5MTE5MC45MzMxOTk2OjE2NzNiOTUwLWZiOTctMTFlYi04MTk5LTAyNDJhYzE
  01:59:53.418 [dbservice1] INFO 1807d22e-fb97-11eb-891e-0242ac110004-pYNZrqyR-3KgMrh!TWn59 token generate success token=MTYyODc5MTE5My40MTc4Nzc6MTgwN2QyMmUtZmI5Ny0xMWViLTg5MWUtMDI0MmFjMTE
  01:59:55.735 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  01:59:58.237 [dbservice2] INFO 1ae1d422-fb97-11eb-baf8-0242ac110004-iBxJIdNQ-&20pUS%?J1T. token generate success token=MTYyODc5MTE5OC4yMzY3Nzg3OjFhZTFkNDIyLWZiOTctMTFlYi1iYWY4LTAyNDJhYzE
  02:00:00.768 [dbservice1] INFO 1c72724c-fb97-11eb-9f58-0242ac110003-AkMRXwoH-{X3w%&jNaR_s token generate success token=MTYyODc5MTIwMC43Njg1MTY1OjFjNzI3MjRjLWZiOTctMTFlYi05ZjU4LTAyNDJhYzE
  02:00:03.289 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×2)
  02:00:05.828 [dbservice1] INFO 1f6e2fe0-fb97-11eb-9c51-0242ac110004-GtoYwjTK-f!Aq7{}_JxO# token generate success token=MTYyODc5MTIwNS44Mjg2MDg6MWY2ZTJmZTAtZmI5Ny0xMWViLTljNTEtMDI0MmFjMTE
  02:00:08.729 [mobservice1] INFO info 2169d632-fb97-11eb-8b21-0242ac110003:NptDIkKG write success
  02:00:11.234 [mobservice1] INFO info 22d99bd8-fb97-11eb-8e96-0242ac110004:uloJcsne write success
  02:00:14.089 [dbservice2] INFO 244d6a44-fb97-11eb-aa89-0242ac110004-jIBRSGcQ-)ERfPKel{cTt token generate success token=MTYyODc5MTIxNC4wODg0NTIzOjI0NGQ2YTQ0LWZiOTctMTFlYi1hYTg5LTAyNDJhYzE
  02:00:16.902 [mobservice1] INFO info 263f0d08-fb97-11eb-b437-0242ac110003:AFDxXgnQ write success
  02:00:19.922 [dbservice1] INFO 27bc7af8-fb97-11eb-a440-0242ac110003-TrtKhHmF-DGj3iJ>o8x-K token generate success token=MTYyODc5MTIxOS45MjI0OTk0OjI3YmM3YWY4LWZiOTctMTFlYi1hNDQwLTAyNDJhYzE
  02:00:22.703 [mobservice1] INFO info 29b0bd88-fb97-11eb-8ce6-0242ac110004:TdjVXoHa write success
  02:00:25.361 [mobservice2] INFO info 2b3813ea-fb97-11eb-a59c-0242ac110003:EYeCRGvF write success
  02:00:32.505 [dbservice2] INFO 2f4e8b8a-fb97-11eb-a5fb-0242ac110004-WdLJXtHG-UZY)^Efxi>LV token generate success token=MTYyODc5MTIzMi41MDUyMTg1OjJmNGU4YjhhLWZiOTctMTFlYi1hNWZiLTAyNDJhYzE
  02:00:35.018 [dbservice1] INFO 30d4f214-fb97-11eb-bafe-0242ac110003-slEUKmfJ-<53oCLnjJMdv token generate success token=MTYyODc5MTIzNS4wMTgzNTE2OjMwZDRmMjE0LWZiOTctMTFlYi1iYWZlLTAyNDJhYzE
  02:00:37.592 [dbservice1] INFO 325f1934-fb97-11eb-9d1f-0242ac110004-guYIhUdp-G-Z5>I<YCLtF token generate success token=MTYyODc5MTIzNy41OTE3NjAyOjMyNWYxOTM0LWZiOTctMTFlYi05ZDFmLTAyNDJhYzE
  02:00:40.504 [mobservice2] INFO info 34523186-fb97-11eb-9640-0242ac110004:btlsWgLd write success
  02:00:44.459 [dbservice1] INFO 36780b48-fb97-11eb-a1fb-0242ac110003-PJMibIFO-5U{+BxgJH$VY token generate success token=MTYyODc5MTI0NC40NTg4NjY6MzY3ODBiNDgtZmI5Ny0xMWViLWExZmItMDI0MmFjMTE

## p0596
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T20:02:49.778Z
```
{"timestamp":1733601769778691000,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-nsc8q","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:02:49.778  INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl             : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainNumber='G1237', startStation='suzhou', destStation='shanghai', seatType=2}"}
```
Same service, the 2 minutes before (oldest first):
  20:02:48.851 [ts-seat-service] 2024-12-07 20:02:48.850 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×2)
  20:02:48.872 [ts-seat-service] 2024-12-07 20:02:48.872 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×2)
  20:02:48.885 [ts-seat-service] 2024-12-07 20:02:48.884 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×2)
  20:02:48.903 [ts-seat-service] 2024-12-07 20:02:48.903 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×2)
  20:02:48.903 [ts-seat-service] 2024-12-07 20:02:48.903 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
  20:02:48.914 [ts-seat-service] 2024-12-07 20:02:48.913 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×2)
  20:02:49.155 [ts-seat-service] 2024-12-07 20:02:49.154 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN
  20:02:49.270 [ts-seat-service] 2024-12-07 20:02:49.270 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  20:02:49.326 [ts-seat-service] 2024-12-07 20:02:49.326 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN
  20:02:49.326 [ts-seat-service] 2024-12-07 20:02:49.326 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1236
  20:02:49.367 [ts-seat-service] 2024-12-07 20:02:49.366 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes
  20:02:49.380 [ts-seat-service] 2024-12-07 20:02:49.380 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da
  20:02:49.467 [ts-seat-service] 2024-12-07 20:02:49.466 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re
  20:02:49.467 [ts-seat-service] 2024-12-07 20:02:49.467 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
  20:02:49.474 [ts-seat-service] 2024-12-07 20:02:49.474 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri
All services, 30 seconds either side (sampled):
  20:02:20.247 [ts-auth-service] 2024-12-07 20:02:20.247 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×14)
  20:02:20.537 [ts-travel2-service] 2024-12-07 20:02:20.537 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×130)
  20:02:20.604 [ts-basic-service] 2024-12-07 20:02:20.604 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×69)
  20:02:20.787 [ts-seat-service] 2024-12-07 20:02:20.787 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×26)
  20:02:20.917 [ts-seat-service] 2024-12-07 20:02:20.917 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×47)
  20:02:23.063 [ts-admin-basic-info-service] 2024-12-07 20:02:23.062 INFO 1 --- [io-18767-exec-6] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×7)
  20:02:24.195 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:02:24 +0800] "POST /api/v1/inside_pay_service/inside_payment HTTP/1.1" 200 83 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)  (×2)
  20:02:24.568 [ts-travel-service] 2024-12-07 20:02:24.568 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×18)
  20:02:26.228 [ts-food-service] 2024-12-07 20:02:26.228 INFO 1 --- [io-18856-exec-2] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!  (×5)
  20:02:26.423 [ts-seat-service] 2024-12-07 20:02:26.423 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  20:02:28.778 [ts-admin-basic-info-service] 2024-12-07 20:02:28.777 INFO 1 --- [io-18767-exec-7] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×8)
  20:02:30.107 [ts-basic-service] 2024-12-07 20:02:30.107 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×3)
  20:02:31.461 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T20:02:31.460+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360175
  20:02:33.491 [ts-travel-service] 2024-12-07 20:02:33.490 INFO 1 --- [io-12346-exec-9] travel.controller.TravelController : [Travel Service] Query TripResponse  (×5)
  20:02:33.650 [ts-travel-service] 2024-12-07 20:02:33.649 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×12)
  20:02:33.846 [ts-order-service] 2024-12-07 20:02:33.845 INFO 1 --- [io-12031-exec-2] order.service.OrderServiceImpl : Left ticket info is empty  (×15)
  20:02:34.053 [ts-travel-service] 2024-12-07 20:02:34.053 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='aefcef3f-3f42-46e8-afd7-6cb2a928bd3d', stations=[nan  (×8)
  20:02:37.693 [ts-travel-service] 2024-12-07 20:02:37.693 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×2)
  20:02:48.486 [ts-travel-service] 2024-12-07 20:02:48.486 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×23)
  20:02:49.597 [ts-basic-service] 2024-12-07 20:02:49.597 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：084837bb-53  (×2)
  20:02:53.676 [ts-travel2-service] 2024-12-07 20:02:53.676 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  20:03:11.498 [ts-travel-service] 2024-12-07 20:03:11.497 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×6)
  20:03:11.988 [ts-preserve-service] 2024-12-07 20:03:11.987 INFO 1 --- [io-14568-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  20:03:13.915 [ts-order-service] 2024-12-07 20:03:13.914 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Other Service][Security Info Get] 4d2a46c7-71cb-4cf1-b5bb-b68406d
  20:03:13.992 [ts-preserve-service] 2024-12-07 20:03:13.992 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Getting....
  20:03:14.617 [ts-travel-service] 2024-12-07 20:03:14.617 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×2)
  20:03:15.603 [ts-seat-service] 2024-12-07 20:03:15.603 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Left ticket info is : Response(status=1, msg=Success, data=LeftTicketInfo{so
  20:03:15.755 [ts-order-service] 2024-12-07 20:03:15.754 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 22.5
  20:03:16.471 [ts-food-service] 2024-12-07 20:03:16.470 INFO 1 --- [io-18856-exec-3] foodsearch.controller.FoodController : [Food Service]Try to Create a FoodOrder!
  20:03:18.449 [ts-consign-service] 2024-12-07 20:03:18.449 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : The handle date is 2024-12-07

## p0680
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-12T00:27:40.228Z
```
{"service":"dbservice2","message":"2021-08-12 00:27:40,228 | ERROR | 0.0.0.2 | dbservice2 | db_helper.py -> db_login_methods -> 63 | {trace_id} | password in database of {user} is null, the user is not registered"}
```
Same service, the 2 minutes before (oldest first):
  00:27:35.788 [dbservice2] INFO 08eac232-fac1-11eb-9b61-0242ac110003-XHisUhbp-1G?q:#9jgp.H token generate success token=MTYyODY5OTI1NS43ODc2OTY0OjA4ZWFjMjMyLWZhYzEtMTFlYi05YjYxLTAyNDJhYzE
  00:27:36.121 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  00:27:36.122 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  00:27:36.159 [dbservice2] INFO query = select passwards from username_table where user_name='JpfzoQkd'  (×5)
  00:27:36.235 [dbservice2] INFO 0938e1ce-fac1-11eb-b040-0242ac110003-JpfzoQkd-38aNP%sO6n9F token generate success token=MTYyODY5OTI1Ni4yMzU0Mzk4OjA5MzhlMWNlLWZhYzEtMTFlYi1iMDQwLTAyNDJhYzE
  00:27:38.583 [dbservice2] INFO 0a839c04-fac1-11eb-aedb-0242ac110004-lebfEIwL-N(UKYsd1kEm4 token generate success token=MTYyODY5OTI1OC41ODI3OTE2OjBhODM5YzA0LWZhYzEtMTFlYi1hZWRiLTAyNDJhYzE
  00:27:39.175 [dbservice2] INFO 0ae4baa2-fac1-11eb-b843-0242ac110003-DrMCTOXU-F$jze2^tHY/U token generate success token=MTYyODY5OTI1OS4xNzQ0ODkzOjBhZTRiYWEyLWZhYzEtMTFlYi1iODQzLTAyNDJhYzE
  00:27:39.482 [dbservice2] INFO 0b1840b6-fac1-11eb-b999-0242ac110003-aSkwezTX-Doutvs-I7}05 token generate success token=MTYyODY5OTI1OS40ODE2MDcyOjBiMTg0MGI2LWZhYzEtMTFlYi1iOTk5LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  00:27:10.243 [redisservice2] INFO redis write success  (×91)
  00:27:10.380 [webservice1] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×44)
  00:27:10.625 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  00:27:10.717 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×38)
  00:27:11.120 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×42)
  00:27:11.557 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×53)
  00:27:12.352 [redisservice1] INFO redis write success  (×83)
  00:27:12.671 [dbservice1] INFO fb33ccf6-fac0-11eb-93ed-0242ac110003-jyYHLuNM-QFl9cP:1u_Wb token generate success token=MTYyODY5OTIzMi42NzA5NDY6ZmIzM2NjZjYtZmFjMC0xMWViLTkzZWQtMDI0MmFjMTE
  00:27:14.429 [dbservice1] INFO fc34882a-fac0-11eb-9897-0242ac110004-fiPpWOMj-C!d)Sy_AULRK token generate success token=MTYyODY5OTIzNC40Mjk0NTI3OmZjMzQ4ODJhLWZhYzAtMTFlYi05ODk3LTAyNDJhYzE
  00:27:16.843 [dbservice2] INFO fdb8f2a8-fac0-11eb-a52f-0242ac110003-lzeSVXuM-3QZKph4Cw{GU token generate success token=MTYyODY5OTIzNi44NDMyNzE1OmZkYjhmMmE4LWZhYzAtMTFlYi1hNTJmLTAyNDJhYzE
  00:27:19.595 [mobservice1] INFO info ff7ede4a-fac0-11eb-9563-0242ac110004:sOldejxN write success
  00:27:21.825 [dbservice1] INFO 00a60da2-fac1-11eb-9210-0242ac110003-SbjCGNIe-I{}FNyGTP5E7 token generate success token=MTYyODY5OTI0MS44MjQ5ODg2OjAwYTYwZGEyLWZhYzEtMTFlYi05MjEwLTAyNDJhYzE
  00:27:24.478 [dbservice2] INFO 022927d6-fac1-11eb-bdf1-0242ac110003-dMOcrJWb-_!QcK%2x(ubj token generate success token=MTYyODY5OTI0NC40Nzc3NTU1OjAyMjkyN2Q2LWZhYzEtMTFlYi1iZGYxLTAyNDJhYzE
  00:27:27.183 [mobservice2] INFO info 04043b54-fac1-11eb-a602-0242ac110004:cUsPLdAz write success
  00:27:29.733 [mobservice2] INFO info 05935ff4-fac1-11eb-93bf-0242ac110003:ucEdiNGD write success
  00:27:31.640 [webservice1] ERROR an error occurred in the downstream service  (×3)
  00:27:34.153 [dbservice2] INFO 080119f2-fac1-11eb-9f67-0242ac110003-rJHuqoXG-(HeVo%G8a5v/ token generate success token=MTYyODY5OTI1NC4xNTMzMzk2OjA4MDExOWYyLWZhYzEtMTFlYi05ZjY3LTAyNDJhYzE
  00:27:36.638 [dbservice1] INFO 09719c76-fac1-11eb-8f08-0242ac110003-RVeouDMj-(Nah*B8-w4n1 token generate success token=MTYyODY5OTI1Ni42MzgyOTY6MDk3MTljNzYtZmFjMS0xMWViLThmMDgtMDI0MmFjMTE
  00:27:39.482 [dbservice2] INFO 0b1840b6-fac1-11eb-b999-0242ac110003-aSkwezTX-Doutvs-I7}05 token generate success token=MTYyODY5OTI1OS40ODE2MDcyOjBiMTg0MGI2LWZhYzEtMTFlYi1iOTk5LTAyNDJhYzE
  00:27:47.254 [mobservice2] INFO info 10076e9e-fac1-11eb-b7a8-0242ac110003:Qygqzmel write success
  00:27:50.571 [dbservice1] INFO 11b81dec-fac1-11eb-a38b-0242ac110004-BGuclMXH-PvgWp{a0S2?r token generate success token=MTYyODY5OTI3MC41NzA5Mjg2OjExYjgxZGVjLWZhYzEtMTFlYi1hMzhiLTAyNDJhYzE
  00:27:53.272 [mobservice2] INFO info 139afb02-fac1-11eb-87fb-0242ac110003:MGClVmwF write success
  00:27:55.893 [dbservice2] INFO 14edd5b0-fac1-11eb-99e8-0242ac110004-qQwhHKIv-SpFaT<ZzU!o? token generate success token=MTYyODY5OTI3NS44OTI2MTY3OjE0ZWRkNWIwLWZhYzEtMTFlYi05OWU4LTAyNDJhYzE
  00:27:58.528 [dbservice2] INFO 16626a32-fac1-11eb-9a19-0242ac110004-lTpNeXrC-EN$Va^B<?Aqi token generate success token=MTYyODY5OTI3OC41Mjc5NzQxOjE2NjI2YTMyLWZhYzEtMTFlYi05YTE5LTAyNDJhYzE
  00:28:01.727 [mobservice1] INFO info 189cc784-fac1-11eb-8632-0242ac110003:lebfEIwL write success
  00:28:04.646 [mobservice1] INFO info 1a44587c-fac1-11eb-a422-0242ac110004:LNDShPui write success
  00:28:07.543 [mobservice1] INFO info 1c0ff102-fac1-11eb-bd00-0242ac110004:QlZMgGXD write success
  00:28:10.100 [mobservice2] INFO info 1da17c16-fac1-11eb-b649-0242ac110003:zfawCciR write success

## p0086
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-13T15:19:35.503Z
```
{"service":"redisservice1","message":"2021-08-13 15:19:35,503 | INFO | 0.0.0.1 | 172.17.0.4 | redisservice1 | 7569659584250154 | service accept, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  15:19:31.578 [redisservice1] INFO redis write success  (×9)
  15:19:31.820 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×6)
  15:19:32.250 [redisservice1] INFO service accept, status_code: 200  (×3)
  15:19:32.445 [redisservice1] INFO redis读取信息成功, status_code: 200  (×2)
All services, 30 seconds either side (sampled):
  15:19:05.585 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×44)
  15:19:05.824 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  15:19:05.935 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×47)
  15:19:06.045 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  15:19:06.488 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  15:19:06.719 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×40)
  15:19:07.230 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×47)
  15:19:07.453 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'bf2b9e04-fc06-11eb-80c0-0242ac110003'}  (×46)
  15:19:09.091 [mobservice2] INFO info c008b5f0-fc06-11eb-acfa-0242ac110003:JazlhZoG write success
  15:19:11.877 [dbservice1] INFO c17fc496-fc06-11eb-9954-0242ac110003-lvCfjILw-D1@9U_jQh_$a token generate success token=MTYyODgzOTE1MS44NzcyNzQzOmMxN2ZjNDk2LWZjMDYtMTFlYi05OTU0LTAyNDJhYzE
  15:19:14.289 [dbservice1] INFO c2fec5a6-fc06-11eb-b25b-0242ac110004-ZlqeuHzO-2EB)FPsdU30T token generate success token=MTYyODgzOTE1NC4yODk1MTM6YzJmZWM1YTYtZmMwNi0xMWViLWIyNWItMDI0MmFjMTE
  15:19:17.399 [dbservice2] INFO c4d57c26-fc06-11eb-912e-0242ac110004-tLUwrBsD-<GsI}l.R:O(! token generate success token=MTYyODgzOTE1Ny4zOTkwMTU6YzRkNTdjMjYtZmMwNi0xMWViLTkxMmUtMDI0MmFjMTE
  15:19:20.205 [dbservice1] INFO c64ff3ec-fc06-11eb-9dd1-0242ac110004-dQvowFzG-=2gZ&G>mSN_{ token generate success token=MTYyODgzOTE2MC4yMDU1Nzc6YzY0ZmYzZWMtZmMwNi0xMWViLTlkZDEtMDI0MmFjMTE
  15:19:22.528 [dbservice2] INFO c7e7f2a4-fc06-11eb-9c5b-0242ac110003-dtzesiga-13Y0M?caE!yK token generate success token=MTYyODgzOTE2Mi41Mjc4OTA0OmM3ZTdmMmE0LWZjMDYtMTFlYi05YzViLTAyNDJhYzE
  15:19:25.363 [dbservice1] INFO c9548378-fc06-11eb-84e6-0242ac110003-xXiaofbu-2Yl&jd#+ApZV token generate success token=MTYyODgzOTE2NS4zNjMxMzk2OmM5NTQ4Mzc4LWZjMDYtMTFlYi04NGU2LTAyNDJhYzE
  15:19:28.612 [dbservice2] INFO cb68db28-fc06-11eb-9706-0242ac110004-vUsGrNAF-saSGFzg5!M2_ token generate success token=MTYyODgzOTE2OC42MTIxODE6Y2I2OGRiMjgtZmMwNi0xMWViLTk3MDYtMDI0MmFjMTE
  15:19:31.436 [dbservice1] INFO cd2327de-fc06-11eb-ab3f-0242ac110003-XHisUhbp-1G?q:#9jgp.H token generate success token=MTYyODgzOTE3MS40MzYyMjE2OmNkMjMyN2RlLWZjMDYtMTFlYi1hYjNmLTAyNDJhYzE
  15:19:35.011 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  15:19:37.967 [mobservice1] INFO info d13dfa42-fc06-11eb-99ce-0242ac110003:ICpXWslJ write success
  15:19:41.250 [dbservice1] INFO d2b27330-fc06-11eb-9dc4-0242ac110003-saJCEzRp-rVa(<KJAO=cm token generate success token=MTYyODgzOTE4MS4yNDk2MzMzOmQyYjI3MzMwLWZjMDYtMTFlYi05ZGM0LTAyNDJhYzE
  15:19:44.027 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  15:19:46.895 [mobservice1] INFO info d6a3d70e-fc06-11eb-89f9-0242ac110004:GwpUdJLR write success
  15:19:49.720 [dbservice1] INFO d818b802-fc06-11eb-8632-0242ac110003-kOerFKnJ-$Y(ZQN69hFpt token generate success token=MTYyODgzOTE4OS43MjA0NzQ6ZDgxOGI4MDItZmMwNi0xMWViLTg2MzItMDI0MmFjMTE
  15:19:52.157 [dbservice1] INFO d9827480-fc06-11eb-bff6-0242ac110004-SbjCGNIe-I{}FNyGTP5E7 token generate success token=MTYyODgzOTE5Mi4xNTY5OTA1OmQ5ODI3NDgwLWZjMDYtMTFlYi1iZmY2LTAyNDJhYzE
  15:19:55.450 [mobservice1] INFO info dba62928-fc06-11eb-8768-0242ac110003:lAeMCLWx write success
  15:19:58.675 [dbservice2] INFO dd699f4c-fc06-11eb-bf24-0242ac110003-OMLuHZEe-zUGYQa}urZJ/ token generate success token=MTYyODgzOTE5OC42NzQ5ODc2OmRkNjk5ZjRjLWZjMDYtMTFlYi1iZjI0LTAyNDJhYzE
  15:20:01.614 [dbservice1] INFO df16b334-fc06-11eb-9b7b-0242ac110004-GBzXyJft-#5tr9S.2Z_EP token generate success token=MTYyODgzOTIwMS42MTM2NjA4OmRmMTZiMzM0LWZjMDYtMTFlYi05YjdiLTAyNDJhYzE

## p0436
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-23T08:05:49.794Z
```
{"timestamp":1732349149794820400,"container_name":"orders","pod_name":"orders-7fff6698cb-rlq5k","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-23 08:05:49.794  INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping   : Mapped \"{[/ || ],methods=[OPTIONS],produces=[application/hal+json || application/json || application/*+json;charset=UTF-8]}\" onto public org.springframework.http.HttpEntity<?> org.springframework.data.rest.webmvc.RepositoryController.optionsForRepositori…"}
```
Same service, the 2 minutes before (oldest first):
  08:05:44.792 [orders] 2024-11-23 08:05:44.791 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server a  (×2)
  08:05:44.886 [orders] 2024-11-23 08:05:44.886 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as M
  08:05:44.894 [orders] 2024-11-23 08:05:44.894 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering w
  08:05:45.989 [orders] 2024-11-23 08:05:45.989 INFO [orders,,,] 8 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  08:05:46.587 [orders] 2024-11-23 08:05:46.586 INFO [orders,,,] 8 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:05:46.592 [orders] 2024-11-23 08:05:46.592 INFO [orders,,,] 8 --- [ main] w.weave.socks.orders.OrderApplication : Started OrderApplication in 80.202 seconds (JVM running for 83.09
  08:05:47.587 [orders] 2024-11-23 08:05:47.587 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  08:05:47.587 [orders] 2024-11-23 08:05:47.587 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization starte
  08:05:47.988 [orders] 2024-11-23 08:05:47.988 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comple
  08:05:49.486 [orders] 2024-11-23 08:05:49.394 ERROR [orders,,,] 8 --- [p-nio-80-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×4)
  08:05:49.486 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×4)
  08:05:49.793 [orders] 2024-11-23 08:05:49.793 INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/orders
  08:05:49.794 [orders] 2024-11-23 08:05:49.794 INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],
All services, 30 seconds either side (sampled):
  08:05:19.849 [user] ts=2024-11-23T08:05:19.849067994Z caller=middlewares.go:157 method=Health result=2 took=2.600764ms  (×40)
  08:05:20.649 [user] ts=2024-11-23T08:05:20.648962527Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67418cb7a437380001deebdf took=3.416226ms  (×60)
  08:05:21.523 [front-end] Posting Customer: {"username":"ZITzoSR","password":"XDZnPmN","email":"ZITzoSR@gmail.com","firstName":"ZITzoSR","lastName":"ZITzoSR"}
  08:05:23.062 [carts-db] {"t":{"$date":"2024-11-23T08:05:23.062+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173234912
  08:05:26.508 [queue-master] 2024-11-23 08:05:26.508 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal+json || ap
  08:05:26.611 [queue-master] 2024-11-23 08:05:26.611 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[application/hal+json
  08:05:27.710 [queue-master] 2024-11-23 08:05:27.710 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}" onto publ
  08:05:28.615 [shipping] 2024-11-23 08:05:28.614 INFO [shipping,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricFilter' to: [/*]  (×6)
  08:05:30.803 [queue-master] 2024-11-23 08:05:30.718 INFO 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0  (×2)
  08:05:32.625 [queue-master] 2024-11-23 08:05:32.625 INFO 7 --- [enerContainer-1] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-durable, auto-delete, or exclusive Queue (shipping-  (×2)
  08:05:36.341 [front-end] Received response: "{\"firstName\":\"LhLfQXTZGiFC\",\"lastName\":\"LhLfQXTZGiFC\",\"username\":\"LhLfQXTZGiFC\",\"id\":\"67418cb4a437380001deebd3\",\"_links\":{
  08:05:39.184 [orders] 2024-11-23 08:05:39.184 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[application/hal+json ||
  08:05:39.196 [orders] 2024-11-23 08:05:39.196 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applica
  08:05:41.188 [orders] 2024-11-23 08:05:41.188 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applicati
  08:05:43.084 [orders] 2024-11-23 08:05:43.084 INFO [orders,,,] 8 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  08:05:44.886 [orders] 2024-11-23 08:05:44.886 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as M
  08:05:49.107 [shipping] 2024-11-23 08:05:49.106 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.spr
  08:05:51.256 [user] ts=2024-11-23T08:05:51.256028158Z caller=middlewares.go:46 method=Register username=ngatc email=ngatc@gmail.com took=2.196043ms
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto publi
  08:05:57.302 [shipping] 2024-11-23 08:05:57.301 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot
  08:06:00.413 [carts] 2024-11-23 08:06:00.413 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  08:06:04.890 [front-end] Received response: "{\"firstName\":\"lRmvkfemO\",\"lastName\":\"lRmvkfemO\",\"username\":\"lRmvkfemO\",\"id\":\"67418cd7a437380001deec42\",\"_links\":{\"address
  08:06:07.003 [shipping] 2024-11-23 08:06:07.003 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[applic
  08:06:07.103 [shipping] 2024-11-23 08:06:07.103 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[text/html]}" onto publ
  08:06:12.607 [front-end] Received response: "{\"firstName\":\"ngatc\",\"lastName\":\"ngatc\",\"username\":\"ngatc\",\"id\":\"67418cdfa437380001deec5c\",\"_links\":{\"addresses\":{\"href
  08:06:15.599 [carts] 2024-11-23 08:06:15.408 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.e
  08:06:15.806 [carts] 2024-11-23 08:06:15.806 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[DE
  08:06:16.710 [front-end] Received response: "{\"firstName\":\"vwAuXUnZkT\",\"lastName\":\"vwAuXUnZkT\",\"username\":\"vwAuXUnZkT\",\"id\":\"67418ce1a437380001deec61\",\"_links\":{\"addr
  08:06:19.102 [carts] 2024-11-23 08:06:19.102 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto 

## p0328
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:21:08.985Z
```
{"timestamp":1732245668985413400,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:21:08.985  INFO [carts,,,] 7 --- [           main] o.s.j.e.a.AnnotationMBeanExporter        : Bean with name 'configurationPropertiesRebinder' has been autodetected for JMX exposure"}
```
Same service, the 2 minutes before (oldest first):
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applicatio
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public jav
  03:21:03.084 [carts] 2024-11-22 03:21:03.083 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/
  03:21:03.084 [carts] 2024-11-22 03:21:03.084 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  03:21:03.086 [carts] 2024-11-22 03:21:03.085 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applicatio
  03:21:03.086 [carts] 2024-11-22 03:21:03.086 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.s
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto 
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public j
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  03:21:03.184 [carts] 2024-11-22 03:21:03.183 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces
  03:21:03.285 [carts] 2024-11-22 03:21:03.285 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/
  03:21:06.490 [carts] 2024-11-22 03:21:06.489 INFO [carts,,,] 7 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  03:21:08.790 [carts] 2024-11-22 03:21:08.790 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
All services, 30 seconds either side (sampled):
  03:20:39.075 [front-end] Posting Customer: {"username":"ELXzX","password":"iajeZG","email":"ELXzX@gmail.com","firstName":"ELXzX","lastName":"ELXzX"}
  03:20:39.646 [user] ts=2024-11-22T03:20:39.646147266Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff87fb0df5c00019b1f03 took=1.919577ms  (×57)
  03:20:39.906 [catalogue] ts=2024-11-22T03:20:39Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=4.413476  (×48)
  03:20:41.184 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff  (×54)
  03:20:42.525 [front-end] Posting Customer: {"username":"jVIVRgJfOAq","password":"zWZXxq","email":"jVIVRgJfOAq@gmail.com","firstName":"jVIVRgJfOAq","lastName":"jVIVRgJfOAq"}
  03:20:43.389 [carts] 2024-11-22 03:20:43.388 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[GET],produces=[applicat
  03:20:48.920 [front-end] Posting Customer: {"username":"DnjBelnPao","password":"eQMYAKREBx","email":"DnjBelnPao@gmail.com","firstName":"DnjBelnPao","lastName":"DnjBelnPao"}
  03:20:51.502 [front-end] Received response: "{\"firstName\":\"znIVGAMLgnSste\",\"lastName\":\"znIVGAMLgnSste\",\"username\":\"znIVGAMLgnSste\",\"id\":\"673ff880b0df5c00019b1f04\",\"_lin
  03:20:55.766 [front-end] Posting Customer: {"username":"PvCLeeg","password":"pTqmeIPqX","email":"PvCLeeg@gmail.com","firstName":"PvCLeeg","lastName":"PvCLeeg"}
  03:20:59.661 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×6)
  03:20:59.783 [carts] 2024-11-22 03:20:59.783 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal
  03:20:59.886 [carts] 2024-11-22 03:20:59.885 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applicati  (×2)
  03:21:02.589 [user] ts=2024-11-22T03:21:02.589004338Z caller=middlewares.go:46 method=Register username=UFhesIA email=UFhesIA@gmail.com took=1.127131ms
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  03:21:04.514 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×2)
  03:21:08.987 [carts] 2024-11-22 03:21:08.987 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  03:21:11.490 [user] ts=2024-11-22T03:21:11.48978732Z caller=middlewares.go:46 method=Register username=onbFNMM email=onbFNMM@gmail.com took=993.598µs
  03:21:14.059 [front-end] Received response: "{\"firstName\":\"bDjuXlWHATfWj\",\"lastName\":\"bDjuXlWHATfWj\",\"username\":\"bDjuXlWHATfWj\",\"id\":\"673ff89cb0df5c00019b1f51\",\"_links\
  03:21:16.220 [front-end] Posting Customer: {"username":"XSDCLJKgyLoxe","password":"WVMgfuZdos","email":"XSDCLJKgyLoxe@gmail.com","firstName":"XSDCLJKgyLoxe","lastName":"XSDCLJKgyLoxe"}
  03:21:18.596 [orders] 2024-11-22 03:21:18.596 INFO [orders,40393c2387463fc4,20a8cb1f4ece78de,false] 6 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Sending payment req  (×17)
  03:21:18.619 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8aed94b9000069b438c","customerId":"673ff89cb0df5c00019b1f51","customer":{"id":null,"firstName":"bDjuXlWHATf
  03:21:19.233 [front-end] Received response: "{\"firstName\":\"cfTPDbfduekTBf\",\"lastName\":\"cfTPDbfduekTBf\",\"username\":\"cfTPDbfduekTBf\",\"id\":\"673ff896b0df5c00019b1f3c\",\"_lin
  03:21:19.905 [front-end] Order response: {"id":"673ff8afd94b9000069b4393","customerId":"673ff89eb0df5c00019b1f54","customer":{"id":null,"firstName":"gKGbBfBuFal","lastName":"gKGbBfBuFal
  03:21:20.783 [carts] 2024-11-22 03:21:20.783 INFO [carts,c68cb8218e3d30a3,e9e627c1a2386c43,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×11)
  03:21:23.285 [front-end] Posting Customer: {"username":"BHMHa","password":"KrLeziWwdr","email":"BHMHa@gmail.com","firstName":"BHMHa","lastName":"BHMHa"}
  03:21:28.217 [front-end] Received response: "{\"firstName\":\"MszyyqkjNcAvcB\",\"lastName\":\"MszyyqkjNcAvcB\",\"username\":\"MszyyqkjNcAvcB\",\"id\":\"673ff8a4b0df5c00019b1f73\",\"_lin
  03:21:32.503 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8bcd94b9000069b439e","customerId":"673ff8a0b0df5c00019b1f63","customer":{"id":null,"firstName":"vpxxpRNxF",
  03:21:34.413 [front-end] Order response: {"id":"673ff8bed94b9000069b43a0","customerId":"673ff8a6b0df5c00019b1f7f","customer":{"id":null,"firstName":"BXlkiHWqBVYl","lastName":"BXlkiHWqBV
  03:21:36.305 [front-end] Order response: {"id":"673ff8c0d94b9000069b43a2","customerId":"673ff8a7b0df5c00019b1f82","customer":{"id":null,"firstName":"onbFNMM","lastName":"onbFNMM","usern

## p0457
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:06:39.131Z
```
{"timestamp":1732349199131959000,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST to carts: http://carts/carts/67418d05a437380001deecd0/items body: {\"itemId\":\"d3588630-ad8e-49df-bbd7-3167f7efb246\",\"unitPrice\":10.99}"}
```
Same service, the 2 minutes before (oldest first):
  08:06:38.842 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67418d04a437380001deeccb"}  (×3)
  08:06:38.851 [front-end] POST /cards 200 - ms - -  (×3)
  08:06:38.915 [front-end] Attempting to delete cart for user: 67418d04a437380001deeccb  (×3)
  08:06:38.916 [front-end] POST /cart 201 - ms - -  (×3)
  08:06:38.919 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418d05a437380001deecd0"}  (×2)
  08:06:38.929 [front-end] POST /addresses 200 - ms - -  (×2)
  08:06:39.112 [front-end] User cart deleted with status: 202
  08:06:39.115 [front-end] DELETE /cart 202 - ms - -
  08:06:39.122 [front-end] Attempting to add to cart: {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","quantity":1}
  08:06:39.131 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata
All services, 30 seconds either side (sampled):
  08:06:09.381 [catalogue] ts=2024-11-23T08:06:09Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=6.848443ms  (×57)
  08:06:09.915 [user] ts=2024-11-23T08:06:09.914786538Z caller=middlewares.go:46 method=Register username=zFhFddnpfqKhWz email=zFhFddnpfqKhWz@gmail.com took=3.206593ms  (×34)
  08:06:10.849 [user] ts=2024-11-23T08:06:10.849352289Z caller=middlewares.go:157 method=Health result=2 took=2.529897ms  (×40)
  08:06:12.434 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732349172431,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×20)
  08:06:14.307 [shipping] 2024-11-23 08:06:14.306 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetec
  08:06:15.708 [carts] 2024-11-23 08:06:15.707 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[HEAD],produces=[application/hal
  08:06:15.809 [carts] 2024-11-23 08:06:15.809 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applicat
  08:06:16.123 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×9)
  08:06:18.950 [front-end] Posting Customer: {"username":"VWOjt","password":"GauRaxKYK","email":"VWOjt@gmail.com","firstName":"VWOjt","lastName":"VWOjt"}
  08:06:19.103 [carts] 2024-11-23 08:06:19.103 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  08:06:21.939 [front-end] Received response: "{\"firstName\":\"ucodWkVEg\",\"lastName\":\"ucodWkVEg\",\"username\":\"ucodWkVEg\",\"id\":\"67418cefa437380001deec8e\",\"_links\":{\"address
  08:06:24.399 [carts] 2024-11-23 08:06:24.399 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server as  (×2)
  08:06:26.765 [user] ts=2024-11-23T08:06:26.764751659Z caller=middlewares.go:46 method=Register username=KGcCpZnH email=KGcCpZnH@gmail.com took=1.964046ms
  08:06:29.799 [carts] 2024-11-23 08:06:29.702 INFO [carts,6207abd6ec238d07,52ab6267122a3f12,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×19)
  08:06:31.811 [carts-db] {"t":{"$date":"2024-11-23T08:06:31.811+00:00"},"s":"I", "c":"STORAGE", "id":20279, "ctx":"conn12","msg":"Conflicted creating a collection","attr":{"namespace":"  (×13)
  08:06:32.845 [catalogue] ts=2024-11-23T08:06:32Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=5.7778ms
  08:06:34.918 [rabbitmq] accepting AMQP connection <0.573.0> (127.0.0.6:57579 -> 192.168.93.151:5672) 
  08:06:36.034 [orders-db] {"t":{"$date":"2024-11-23T08:06:36.034+00:00"},"s":"I", "c":"STORAGE", "id":20279, "ctx":"conn2","msg":"Conflicted creating a collection","attr":{"namespace":"d  (×4)
  08:06:39.631 [user] ts=2024-11-23T08:06:39.631802497Z caller=middlewares.go:46 method=Register username=ErFfEEVmz email=ErFfEEVmz@gmail.com took=2.266647ms
  08:06:41.163 [front-end] Received response: "{\"firstName\":\"OkxajUZjGhkcaQY\",\"lastName\":\"OkxajUZjGhkcaQY\",\"username\":\"OkxajUZjGhkcaQY\",\"id\":\"67418cf8a437380001deeca8\",\"_
  08:06:43.402 [front-end] Posting Customer: {"username":"yZznqGCEisk","password":"vzBqH","email":"yZznqGCEisk@gmail.com","firstName":"yZznqGCEisk","lastName":"yZznqGCEisk"}
  08:06:47.538 [front-end] Received response: "{\"firstName\":\"KGcCpZnH\",\"lastName\":\"KGcCpZnH\",\"username\":\"KGcCpZnH\",\"id\":\"67418d02a437380001deecc4\",\"_links\":{\"addresses\
  08:06:48.789 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d183f77060008864e4c","customerId":"67418d04a437380001deeccb","customer":{"id":null,"firstName":"cBGHfcdiqX"
  08:06:52.042 [front-end] Received response: "{\"firstName\":\"dRUZXQgdp\",\"lastName\":\"dRUZXQgdp\",\"username\":\"dRUZXQgdp\",\"id\":\"67418d06a437380001deecd5\",\"_links\":{\"address
  08:06:53.837 [front-end] Received response: "{\"firstName\":\"KarxuPo\",\"lastName\":\"KarxuPo\",\"username\":\"KarxuPo\",\"id\":\"67418d0ba437380001deecdf\",\"_links\":{\"addresses\":{
  08:06:57.583 [front-end] Posting Customer: {"username":"bUbXreoCTy","password":"FxhUHwcB","email":"bUbXreoCTy@gmail.com","firstName":"bUbXreoCTy","lastName":"bUbXreoCTy"}
  08:07:01.048 [front-end] Posting Customer: {"username":"oryNHzZvN","password":"uroXPSza","email":"oryNHzZvN@gmail.com","firstName":"oryNHzZvN","lastName":"oryNHzZvN"}
  08:07:03.453 [front-end] Posting Customer: {"username":"hHThr","password":"AXeArh","email":"hHThr@gmail.com","firstName":"hHThr","lastName":"hHThr"}
  08:07:06.367 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d2a3f77060008864e60","customerId":"67418d14a437380001deed04","customer":{"id":null,"firstName":"hnpzllValfp

## p0524
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:42:30.228Z
```
{"timestamp":1732358550228249900,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"Merging carts for customer id: 6741b196a437380001df4bad and session id: 1P2MIl8q99EYHVV17TXxeSZT4XTmIAbc"}
```
Same service, the 2 minutes before (oldest first):
  10:42:29.496 [front-end] DELETE /cart 202 - ms - -
  10:42:29.501 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  10:42:29.512 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  10:42:29.512 [front-end] POST to carts: http://carts/carts/6741b18fa437380001df4b9a/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  10:42:29.568 [front-end] POST /cart 201 - ms - -
  10:42:29.814 [front-end] GET /catalogue 200 - ms - -
  10:42:29.825 [front-end] Request received with body: {}
  10:42:29.841 [front-end] Received response: "{\"firstName\":\"OqLsYhRjpY\",\"lastName\":\"OqLsYhRjpY\",\"username\":\"OqLsYhRjpY\",\"id\":\"6741b184a437380001df4b83\",\"_links\":{\"addr
  10:42:29.841 [front-end] GET Request to: http://user/customers/6741b184a437380001df4b83/addresses  (×2)
  10:42:29.854 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b18ea437380001df4b97\",\"_links\":{\"
  10:42:29.854 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"6741b
  10:42:29.854 [front-end] [ undefined, undefined ]
  10:42:29.854 [front-end] Posting Order: {"customer":"http://user/customers/6741b184a437380001df4b83","address":"http://user/addresses/6741b18ea437380001df4b96","card":"http://user/cards
  10:42:29.895 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19501dd390007094e10","customerId":"6741b184a437380001df4b83","customer":{"id":null,"firstName":"OqLsYhRjpY"
  10:42:29.895 [front-end] Order response: {"id":"6741b19501dd390007094e10","customerId":"6741b184a437380001df4b83","customer":{"id":null,"firstName":"OqLsYhRjpY","lastName":"OqLsYhRjpY",
  10:42:29.897 [front-end] POST /orders 201 - ms - -
  10:42:30.218 [front-end] Posting Customer: {"username":"DMOcLvEBWyzQX","password":"jplcbxKLK","email":"DMOcLvEBWyzQX@gmail.com","firstName":"DMOcLvEBWyzQX","lastName":"DMOcLvEBWyzQX"}
  10:42:30.228 [front-end] { id: '6741b196a437380001df4bad' }
  10:42:30.228 [front-end] 6741b196a437380001df4bad
All services, 30 seconds either side (sampled):
  10:42:00.245 [front-end] Request received with body: {}  (×60)
  10:42:00.337 [payment] ts=2024-11-23T10:42:00Z caller=logging.go:29 method=Authorise result=true took=910ns  (×44)
  10:42:00.383 [catalogue] ts=2024-11-23T10:42:00Z caller=logging.go:85 method=Health result=2 took=27.373µs  (×40)
  10:42:01.409 [user] ts=2024-11-23T10:42:01.408921714Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6741b172a437380001df4b56 took=5.298613ms  (×60)
  10:42:01.559 [front-end] POST /cart 201 - ms - -  (×60)
  10:42:02.065 [front-end] set cookie6741b17aa437380001df4b6a  (×60)
  10:42:03.037 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×8)
  10:42:05.001 [front-end] Received response: "{\"firstName\":\"sjfrIBFtnOMwhK\",\"lastName\":\"sjfrIBFtnOMwhK\",\"username\":\"sjfrIBFtnOMwhK\",\"id\":\"6741b16aa437380001df4b3a\",\"_lin
  10:42:06.045 [front-end] Order response: {"id":"6741b17e01dd390007094dfd","customerId":"6741b164a437380001df4b21","customer":{"id":null,"firstName":"NebxYZs","lastName":"NebxYZs","usern
  10:42:07.839 [front-end] Received response: "{\"firstName\":\"wEgEgz\",\"lastName\":\"wEgEgz\",\"username\":\"wEgEgz\",\"id\":\"6741b16da437380001df4b44\",\"_links\":{\"addresses\":{\"h
  10:42:12.194 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×7)
  10:42:15.584 [front-end] Received response: "{\"firstName\":\"dAtNeIAV\",\"lastName\":\"dAtNeIAV\",\"username\":\"dAtNeIAV\",\"id\":\"6741b172a437380001df4b56\",\"_links\":{\"addresses\
  10:42:17.639 [front-end] Order response: {"id":"6741b18901dd390007094e06","customerId":"6741b173a437380001df4b5a","customer":{"id":null,"firstName":"BCltxDPpCsSCJD","lastName":"BCltxDPp
  10:42:19.953 [user] ts=2024-11-23T10:42:19.95376244Z caller=middlewares.go:46 method=Register username=RIAVrKz email=RIAVrKz@gmail.com took=2.264977ms
  10:42:24.572 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19001dd390007094e0b","customerId":"6741b177a437380001df4b65","customer":{"id":null,"firstName":"SCxrEnxcK",
  10:42:26.121 [orders-db] {"t":{"$date":"2024-11-23T10:42:26.121+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235854
  10:42:27.177 [user] ts=2024-11-23T10:42:27.177095529Z caller=middlewares.go:46 method=Register username=xRRVgZEW email=xRRVgZEW@gmail.com took=3.019561ms
  10:42:29.895 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19501dd390007094e10","customerId":"6741b184a437380001df4b83","customer":{"id":null,"firstName":"OqLsYhRjpY"
  10:42:34.217 [front-end] Received response: "{\"firstName\":\"hvmhlTDxhWfD\",\"lastName\":\"hvmhlTDxhWfD\",\"username\":\"hvmhlTDxhWfD\",\"id\":\"6741b184a437380001df4b84\",\"_links\":{
  10:42:34.942 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19a01dd390007094e14","customerId":"6741b186a437380001df4b87","customer":{"id":null,"firstName":"OePlWpOYf",
  10:42:38.441 [front-end] Posting Customer: {"username":"qxMKJWILAB","password":"nPYAMbLTCN","email":"qxMKJWILAB@gmail.com","firstName":"qxMKJWILAB","lastName":"qxMKJWILAB"}
  10:42:40.192 [front-end] Order response: {"id":"6741b1a001dd390007094e17","customerId":"6741b186a437380001df4b88","customer":{"id":null,"firstName":"CydfEIYWaRvI","lastName":"CydfEIYWaR
  10:42:43.085 [front-end] Posting Customer: {"username":"UILHEiEVVssclad","password":"ZqCUxOuP","email":"UILHEiEVVssclad@gmail.com","firstName":"UILHEiEVVssclad","lastName":"UILHEiEVVssc
  10:42:45.526 [front-end] Order response: {"id":"6741b1a501dd390007094e1c","customerId":"6741b196a437380001df4bad","customer":{"id":null,"firstName":"DMOcLvEBWyzQX","lastName":"DMOcLvEBW
  10:42:47.181 [front-end] Posting Customer: {"username":"EuaRkWCg","password":"mitRj","email":"EuaRkWCg@gmail.com","firstName":"EuaRkWCg","lastName":"EuaRkWCg"}
  10:42:50.396 [user] ts=2024-11-23T10:42:50.396503272Z caller=middlewares.go:46 method=Register username=XlKDXhFKw email=XlKDXhFKw@gmail.com took=3.001343ms
  10:42:52.614 [front-end] Received response: "{\"firstName\":\"cIodMrxYWMDLnTf\",\"lastName\":\"cIodMrxYWMDLnTf\",\"username\":\"cIodMrxYWMDLnTf\",\"id\":\"6741b198a437380001df4bb4\",\"_
  10:42:54.479 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b1ae01dd390007094e24","customerId":"6741b193a437380001df4ba2","customer":{"id":null,"firstName":"xRRVgZEW","
  10:42:55.766 [front-end] Received response: "{\"firstName\":\"YrFTjPuE\",\"lastName\":\"YrFTjPuE\",\"username\":\"YrFTjPuE\",\"id\":\"6741b197a437380001df4bb1\",\"_links\":{\"addresses\
  10:42:58.786 [front-end] Received response: "{\"firstName\":\"qxMKJWILAB\",\"lastName\":\"qxMKJWILAB\",\"username\":\"qxMKJWILAB\",\"id\":\"6741b19ea437380001df4bcc\",\"_links\":{\"addr

## p0732
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-22T12:14:03.268Z
```
{"timestamp":1732277643268476700,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-mptqm","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=d01583c7-1498-45eb-a9a8-e4d2cc36d456"}
```
Same service, the 2 minutes before (oldest first):
  12:14:00.303 [cartservice] GetCartAsync called with userId=eaf79d1b-31f0-4e8e-91c1-cb7afff81318  (×16)
  12:14:00.510 [cartservice] AddItemAsync called with userId=d87ed3ba-3337-4fbc-9a07-fd380ae5008e, productId=66VCHSJNUP, quantity=8  (×4)
All services, 30 seconds either side (sampled):
  12:13:33.559 [frontend] request started  (×335)
  12:13:33.567 [cartservice] GetCartAsync called with userId=f6baa338-17b8-4a60-9256-45e6b42573c9  (×267)
  12:13:33.597 [adservice] received ad request (context_words=[decor, home])  (×16)
  12:13:34.422 [frontend] setting currency  (×23)
  12:13:34.475 [adservice] received ad request (context_words=[])  (×31)
  12:13:35.384 [adservice] received ad request (context_words=[clothing, tops])  (×18)
  12:13:37.887 [shippingservice] [GetQuote] completed request  (×88)
  12:13:41.207 [cartservice] AddItemAsync called with userId=bddb57b9-704f-4c9d-b76e-8ea50234481c, productId=66VCHSJNUP, quantity=5  (×44)
  12:13:41.280 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"11621","nanos":420610630},"credit_card":{"credit_card_number":"419788244300  (×4)
  12:13:41.286 [shippingservice] [ShipOrder] received request  (×14)
  12:13:41.293 [emailservice] A request to send order confirmation email to wukerri@example.com has been received.
  12:13:43.571 [checkoutservice] [PlaceOrder] user_id="d01583c7-1498-45eb-a9a8-e4d2cc36d456" user_currency="CAD"  (×3)
  12:13:43.612 [emailservice] A request to send order confirmation email to burnschristopher@example.org has been received.
  12:13:48.579 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"727","nanos":562475003},"credit_card":{"credit_card_number":"47413402317969
  12:13:48.592 [checkoutservice] order confirmation email sent to "bayala@example.com"
  12:13:57.135 [emailservice] A request to send order confirmation email to johnhampton@example.net has been received.
  12:13:58.440 [checkoutservice] order confirmation email sent to "patricia97@example.com"
  12:14:03.359 [paymentservice] Transaction processed: visa ending 6737 Amount: USD1355.210000000
  12:14:08.539 [emailservice] A request to send order confirmation email to anthonywoodard@example.com has been received.
  12:14:11.015 [redis] 1:M 22 Nov 2024 12:14:11.015 * Background saving started by pid 32
  12:14:11.115 [redis] 1:M 22 Nov 2024 12:14:11.115 * Background saving terminated with success
  12:14:11.374 [paymentservice] Transaction processed: visa ending 4795 Amount: TRY9907.928002684  (×3)
  12:14:12.130 [recommendationservice] [Recv ListRecommendations] product_ids=['9SIQT8TOJO', '2ZYFJ3GM2N']  (×3)
  12:14:18.177 [emailservice] A request to send order confirmation email to aguilardavid@example.com has been received.
  12:14:20.589 [checkoutservice] order confirmation email sent to "john21@example.net"
  12:14:24.265 [paymentservice] Transaction processed: visa ending 6915 Amount: EUR1173.524988957  (×2)
  12:14:24.978 [emailservice] A request to send order confirmation email to yhunt@example.com has been received.
  12:14:33.080 [checkoutservice] order confirmation email sent to "jessica10@example.com"

## p0739
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service shippingservice, 2024-11-22T12:29:13.636Z
```
{"timestamp":1732278553636947500,"container_name":"shippingservice","pod_name":"shippingservice-547ddf469c-hx47t","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"[GetQuote] received request"}
```
Same service, the 2 minutes before (oldest first):
  12:29:05.071 [shippingservice] [GetQuote] received request  (×9)
  12:29:05.071 [shippingservice] [GetQuote] completed request  (×9)
  12:29:12.426 [shippingservice] [ShipOrder] received request
  12:29:12.426 [shippingservice] [ShipOrder] completed request
All services, 30 seconds either side (sampled):
  12:28:43.822 [frontend] request started  (×296)
  12:28:43.830 [cartservice] GetCartAsync called with userId=28cd5e72-c08c-44c7-8f37-d6de6cba1e4f  (×241)
  12:28:43.855 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 4  (×178)
  12:28:44.584 [frontend] setting currency  (×31)
  12:28:47.396 [adservice] AdService starting.
  12:28:47.488 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.
  12:28:47.857 [shippingservice] [GetQuote] received request  (×62)
  12:28:49.086 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base
  12:28:51.568 [frontend] placing order  (×7)
  12:28:51.589 [paymentservice] Transaction processed: visa ending 2517 Amount: GBP27.346140644  (×2)
  12:28:51.593 [shippingservice] [ShipOrder] completed request  (×7)
  12:28:51.602 [checkoutservice] order confirmation email sent to "susan75@example.net"
  12:28:51.933 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"201","nanos":400000000},"credit_card":{"credit_card_number":"41480911863018  (×2)
  12:28:51.947 [checkoutservice] order confirmation email sent to "athomas@example.org"
  12:28:56.388 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"1661","nanos":822625392},"credit_card":{"credit_card_number":"4521648349221
  12:28:56.403 [checkoutservice] order confirmation email sent to "nnicholson@example.com"
  12:29:12.435 [emailservice] A request to send order confirmation email to lorimills@example.net has been received.
  12:29:14.064 [redis] 1:M 22 Nov 2024 12:29:14.064 * Background saving started by pid 35
  12:29:14.165 [redis] 1:M 22 Nov 2024 12:29:14.165 * Background saving terminated with success
  12:29:32.033 [paymentservice] Transaction processed: visa ending 0034 Amount: EUR644.767801861  (×2)
  12:29:32.048 [emailservice] A request to send order confirmation email to jason64@example.com has been received.

## p0351
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:27:40.055Z
```
{"timestamp":1732246060055189500,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:27:40.054  INFO [carts,86f53ffe131f085d,89aecd27148e860c,false] 7 --- [p-nio-80-exec-6] w.w.s.cart.cart.CartContentsResource     : Adding for user: Cart{id='673ffa2c3b1758000727f591', customerId='673ffa23b0df5c00019b23f6', items=[]}, Item{id='673ffa2c3b1758000727f592', itemId='03fef6ac-1896-4ce8-bd69-b798f85c6e0b', quantity=1, unitPrice=99.99}"}
```
Same service, the 2 minutes before (oldest first):
  03:27:31.018 [carts] 2024-11-22 03:27:31.018 INFO [carts,04d20f9bbd9f0219,b216bb04e66fea37,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.controllers.CartsController : Merge carts reques  (×2)
  03:27:31.858 [carts] 2024-11-22 03:27:31.858 INFO [carts,67555bc979234e7f,48519bb3a83647cd,false] 7 --- [-nio-80-exec-10] w.w.s.cart.controllers.CartsController : Merge carts reques  (×5)
  03:27:32.073 [carts] 2024-11-22 03:27:32.073 INFO [carts,0dc448629426a102,bd7d0b0ac28afb4c,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.ItemsController : Did not find item.  (×3)
  03:27:32.080 [carts] 2024-11-22 03:27:32.080 INFO [carts,0dc448629426a102,bd7d0b0ac28afb4c,false] 7 --- [-nio-80-exec-13] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×3)
  03:27:32.122 [carts] 2024-11-22 03:27:32.121 INFO [carts,42a6dac396258350,63e190bb19247cca,false] 7 --- [p-nio-80-exec-6] w.w.s.cart.controllers.ItemsController : Did not find item.  (×4)
  03:27:32.129 [carts] 2024-11-22 03:27:32.129 INFO [carts,42a6dac396258350,63e190bb19247cca,false] 7 --- [p-nio-80-exec-6] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×3)
All services, 30 seconds either side (sampled):
  03:27:10.166 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffa07b0df5c00019b239e"}  (×60)
  03:27:10.201 [front-end] [ undefined, undefined ]  (×65)
  03:27:10.233 [queue-master] 2024-11-22 03:27:10.233 ERROR 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×45)
  03:27:10.303 [carts] 2024-11-22 03:27:10.303 INFO [carts,32c7ec19f4e490f2,42f9e0cca820db57,false] 7 --- [-nio-80-exec-21] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×35)
  03:27:10.593 [front-end] POST /register 200 30.479 ms - 33  (×65)
  03:27:10.875 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×4)
  03:27:12.178 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×14)
  03:27:13.096 [carts] 2024-11-22 03:27:13.096 INFO [carts,4a97cc2ef77bdead,84c7db765af655c3,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×24)
  03:27:15.846 [front-end] Order response: {"id":"673ffa13d94b9000069b44cc","customerId":"673ff9fdb0df5c00019b2385","customer":{"id":null,"firstName":"iIXcHccHLS","lastName":"iIXcHccHLS",
  03:27:17.698 [front-end] Order response: {"id":"673ffa15d94b9000069b44ce","customerId":"673ff9fbb0df5c00019b237f","customer":{"id":null,"firstName":"kBTWAyi","lastName":"kBTWAyi","usern
  03:27:19.434 [front-end] Received response: "{\"firstName\":\"jLOLG\",\"lastName\":\"jLOLG\",\"username\":\"jLOLG\",\"id\":\"673ff9ffb0df5c00019b2387\",\"_links\":{\"addresses\":{\"href
  03:27:21.676 [front-end] Order response: {"id":"673ffa19d94b9000069b44d3","customerId":"673ffa05b0df5c00019b239a","customer":{"id":null,"firstName":"jLwainknX","lastName":"jLwainknX","u
  03:27:22.709 [front-end] Order response: {"id":"673ffa1ad94b9000069b44d6","customerId":"673ffa05b0df5c00019b239b","customer":{"id":null,"firstName":"advkZLgCiNjnvhN","lastName":"advkZLg
  03:27:25.193 [front-end] Received response: "{\"firstName\":\"fewqCFN\",\"lastName\":\"fewqCFN\",\"username\":\"fewqCFN\",\"id\":\"673ffa02b0df5c00019b2393\",\"_links\":{\"addresses\":{
  03:27:29.181 [front-end] Received response: "{\"firstName\":\"IzKSkuLwhEWL\",\"lastName\":\"IzKSkuLwhEWL\",\"username\":\"IzKSkuLwhEWL\",\"id\":\"673ffa10b0df5c00019b23c5\",\"_links\":{
  03:27:31.525 [front-end] Received response: "{\"firstName\":\"RPpMC\",\"lastName\":\"RPpMC\",\"username\":\"RPpMC\",\"id\":\"673ffa11b0df5c00019b23c8\",\"_links\":{\"addresses\":{\"href
  03:27:35.025 [front-end] Received response: "{\"firstName\":\"rhWZtvHgaUJbj\",\"lastName\":\"rhWZtvHgaUJbj\",\"username\":\"rhWZtvHgaUJbj\",\"id\":\"673ffa14b0df5c00019b23d3\",\"_links\
  03:27:37.794 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa29d94b9000069b44e5","customerId":"673ffa14b0df5c00019b23d2","customer":{"id":null,"firstName":"HIBdGX","la
  03:27:42.349 [front-end] Posting Customer: {"username":"BgPsShb","password":"EYxJFTy","email":"BgPsShb@gmail.com","firstName":"BgPsShb","lastName":"BgPsShb"}
  03:27:44.214 [front-end] Received response: "{\"firstName\":\"FKoQSpBfiUGvM\",\"lastName\":\"FKoQSpBfiUGvM\",\"username\":\"FKoQSpBfiUGvM\",\"id\":\"673ffa23b0df5c00019b23f4\",\"_links\
  03:27:47.670 [user] ts=2024-11-22T03:27:47.6707239Z caller=middlewares.go:46 method=Register username=ApclDJ email=ApclDJ@gmail.com took=1.019801ms
  03:27:51.148 [front-end] Order response: {"id":"673ffa37d94b9000069b44eb","customerId":"673ffa19b0df5c00019b23e3","customer":{"id":null,"firstName":"caoGbdq","lastName":"caoGbdq","usern
  03:27:53.088 [front-end] Received response: "{\"firstName\":\"GmTAJlOavNW\",\"lastName\":\"GmTAJlOavNW\",\"username\":\"GmTAJlOavNW\",\"id\":\"673ffa23b0df5c00019b23f6\",\"_links\":{\"a
  03:27:56.411 [front-end] Received response: "{\"firstName\":\"LtpKzywsGwH\",\"lastName\":\"LtpKzywsGwH\",\"username\":\"LtpKzywsGwH\",\"id\":\"673ffa2eb0df5c00019b240f\",\"_links\":{\"a
  03:27:59.221 [user] ts=2024-11-22T03:27:59.221100888Z caller=middlewares.go:46 method=Register username=ukNKXe email=ukNKXe@gmail.com took=967.928µs
  03:28:02.901 [front-end] Order response: {"id":"673ffa42d94b9000069b44f2","customerId":"673ffa33b0df5c00019b2420","customer":{"id":null,"firstName":"nGgyosGmNAESXFp","lastName":"nGgyosG
  03:28:04.669 [front-end] Received response: "{\"firstName\":\"pqUxjmVVuxN\",\"lastName\":\"pqUxjmVVuxN\",\"username\":\"pqUxjmVVuxN\",\"id\":\"673ffa34b0df5c00019b2424\",\"_links\":{\"a
  03:28:05.586 [front-end] Order response: {"id":"673ffa45d94b9000069b44f9","customerId":"673ffa2eb0df5c00019b2412","customer":{"id":null,"firstName":"LRCjsc","lastName":"LRCjsc","usernam
  03:28:07.605 [user] ts=2024-11-22T03:28:07.605070811Z caller=middlewares.go:46 method=Register username=kYzgkvZ email=kYzgkvZ@gmail.com took=1.098694ms

## p0720
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-14T15:16:58.504Z
```
{"service":"dbservice1","message":"2021-08-14 15:16:58,504 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 106ab5c85134ddfe | 9c78479e-fccf-11eb-ac7c-0242ac110004-hHIokWie-DyHUpusE)bOX token generate success token=MTYyODkyNTQxOC41MDM4OTcyOjljNzg0NzllLWZjY2YtMTFlYi1hYzdjLTAyNDJhYzExMDAwNGhISW9rV2llRHlIVXB1c0UpYk9YOjE2Mjg5MjU0NzguNTAzOTA4MjpiY2JkNTkxOTFhN2EwOTIzNTY2MDkwMjY0YmY0NzQzOA=="}
```
Same service, the 2 minutes before (oldest first):
  15:16:53.850 [dbservice1] INFO 99a68b0c-fccf-11eb-9a89-0242ac110003-IvLqACZF-MoJiK)-U4Bs& token generate success token=MTYyODkyNTQxMy44NTAwODkzOjk5YTY4YjBjLWZjY2YtMTFlYi05YTg5LTAyNDJhYzE
  15:16:54.331 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  15:16:54.331 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  15:16:54.363 [dbservice1] INFO query = select passwards from username_table where user_name='fVwtyQDn'  (×5)
  15:16:54.444 [dbservice1] INFO 9a06c792-fccf-11eb-88cd-0242ac110003-fVwtyQDn-m0:RzXgt4@vn token generate success token=MTYyODkyNTQxNC40NDQwNjk0OjlhMDZjNzkyLWZjY2YtMTFlYi04OGNkLTAyNDJhYzE
  15:16:56.063 [dbservice1] INFO 9af92abe-fccf-11eb-a025-0242ac110003-PtzZjByh-wNej}mCt+)JY token generate success token=MTYyODkyNTQxNi4wNjMwMDk3OjlhZjkyYWJlLWZjY2YtMTFlYi1hMDI1LTAyNDJhYzE
  15:16:56.784 [dbservice1] INFO 9b5fb0f4-fccf-11eb-b9b6-0242ac110004-QzCIyEtF-!pHZI}Si_Uby token generate success token=MTYyODkyNTQxNi43ODQzNjU6OWI1ZmIwZjQtZmNjZi0xMWViLWI5YjYtMDI0MmFjMTE
  15:16:57.690 [dbservice1] INFO 9bf9504c-fccf-11eb-9c09-0242ac110004-rydacQUo-bx?J>OSr6).& token generate success token=MTYyODkyNTQxNy42OTAwMDk2OjliZjk1MDRjLWZjY2YtMTFlYi05YzA5LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  15:16:28.521 [redisservice2] INFO service accept, status_code: 200  (×55)
  15:16:28.894 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×48)
  15:16:29.132 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×46)
  15:16:29.321 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×49)
  15:16:29.795 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  15:16:30.271 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '8c076ae8-fccf-11eb-8668-0242ac110004', 'value': '', 'ex': 10}  (×46)
  15:16:30.474 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×45)
  15:16:30.852 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×47)
  15:16:32.514 [mobservice1] INFO info 8d21e142-fccf-11eb-9b24-0242ac110003:WYjcLizJ write success
  15:16:35.379 [mobservice2] INFO info 8ee5b9f4-fccf-11eb-8579-0242ac110004:xUAQKIOl write success
  15:16:37.564 [mobservice1] INFO info 9032fbf0-fccf-11eb-82f9-0242ac110004:vYsiTgru write success
  15:16:40.194 [mobservice1] INFO info 91c22ca2-fccf-11eb-9ae9-0242ac110003:wkgeEpUD write success
  15:16:43.047 [dbservice2] INFO 933daf2a-fccf-11eb-99de-0242ac110004-GiuNzrvJ-YnTciU0WR&3p token generate success token=MTYyODkyNTQwMy4wNDcwNjM6OTMzZGFmMmEtZmNjZi0xMWViLTk5ZGUtMDI0MmFjMTE
  15:16:45.627 [dbservice2] INFO 94c9df80-fccf-11eb-bae5-0242ac110003-GxrcRlDj-Lw{tNT75j/%g token generate success token=MTYyODkyNTQwNS42MjcwMDk2Ojk0YzlkZjgwLWZjY2YtMTFlYi1iYWU1LTAyNDJhYzE
  15:16:48.014 [webservice1] ERROR an error occurred in the downstream service
  15:16:50.645 [mobservice1] INFO info 97f94ea2-fccf-11eb-8357-0242ac110003:LcsBuYDh write success
  15:16:53.467 [mobservice1] INFO info 99a68b0c-fccf-11eb-9a89-0242ac110003:IvLqACZF write success  (×2)
  15:16:56.063 [dbservice1] INFO 9af92abe-fccf-11eb-a025-0242ac110003-PtzZjByh-wNej}mCt+)JY token generate success token=MTYyODkyNTQxNi4wNjMwMDk3OjlhZjkyYWJlLWZjY2YtMTFlYi1hMDI1LTAyNDJhYzE
  15:16:58.895 [mobservice2] INFO info 9ced9918-fccf-11eb-a4c6-0242ac110003:oiBjxrzQ write success
  15:17:01.392 [dbservice2] INFO 9e319cca-fccf-11eb-8d6f-0242ac110003-dQcykLhj-Sn.w)Vyu7fB@ token generate success token=MTYyODkyNTQyMS4zOTIxNDYzOjllMzE5Y2NhLWZjY2YtMTFlYi04ZDZmLTAyNDJhYzE
  15:17:03.837 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  15:17:07.208 [dbservice1] INFO a1a6b3c2-fccf-11eb-914b-0242ac110004-KrCJbket-SDY(Ra?xklfj token generate success token=MTYyODkyNTQyNy4yMDgyNzcyOmExYTZiM2MyLWZjY2YtMTFlYi05MTRiLTAyNDJhYzE
  15:17:09.844 [dbservice2] INFO a3334610-fccf-11eb-93c1-0242ac110004-DjXaKYNR-/Q*Yd=S2X37R token generate success token=MTYyODkyNTQyOS44NDQzOTgzOmEzMzM0NjEwLWZjY2YtMTFlYi05M2MxLTAyNDJhYzE
  15:17:12.368 [dbservice2] INFO a4aea4d0-fccf-11eb-978b-0242ac110003-AsKCtDoY-n2BPkW(-x&s# token generate success token=MTYyODkyNTQzMi4zNjc3MDM6YTRhZWE0ZDAtZmNjZi0xMWViLTk3OGItMDI0MmFjMTE
  15:17:15.604 [dbservice2] INFO a69eed2c-fccf-11eb-bdb6-0242ac110003-tVZirvSy-RdOP!c4y.62_ token generate success token=MTYyODkyNTQzNS42MDM1Njg4OmE2OWVlZDJjLWZjY2YtMTFlYi1iZGI2LTAyNDJhYzE
  15:17:18.506 [mobservice1] INFO info a88bcfec-fccf-11eb-9db7-0242ac110003:YTchXgsi write success
  15:17:21.153 [mobservice1] INFO info aa1af9aa-fccf-11eb-8b4b-0242ac110003:VpEUCejs write success
  15:17:24.968 [mobservice1] INFO info ac761a7c-fccf-11eb-9abf-0242ac110004:WvYxbhDu write success
  15:17:27.718 [mobservice1] INFO info ae161d5a-fccf-11eb-8f86-0242ac110003:tdfCvYKb write success

## p0424
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T04:08:27.613Z
```
{"timestamp":1732248507613761000,"container_name":"front-end","pod_name":"front-end-ccbbfbf7f-szg8d","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"Sent cookies."}
```
Same service, the 2 minutes before (oldest first):
  04:08:26.726 [front-end] User cart deleted with status: 202
  04:08:26.726 [front-end] DELETE /cart 202 - ms - -
  04:08:26.732 [front-end] Attempting to add to cart: {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","quantity":1}
  04:08:26.742 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
  04:08:26.742 [front-end] POST to carts: http://carts/carts/674003b5b0df5c00019b4152/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}
  04:08:26.784 [front-end] POST /cart 500 51.647 ms - 70
  04:08:27.536 [front-end] Request received with body: {}
  04:08:27.537 [front-end] Posting Customer: {"username":"RaZjvxZZfzdRx","password":"oTbnZ","email":"RaZjvxZZfzdRx@gmail.com","firstName":"RaZjvxZZfzdRx","lastName":"RaZjvxZZfzdRx"}
  04:08:27.586 [front-end] { id: '674003bbb0df5c00019b416c' }
  04:08:27.586 [front-end] 674003bbb0df5c00019b416c
  04:08:27.586 [front-end] Merging carts for customer id: 674003bbb0df5c00019b416c and session id: cvdzDRzkjSIWo07U7Kb7WS4COG5Sql2O
  04:08:27.587 [front-end] Received response: "{\"firstName\":\"SOJro\",\"lastName\":\"SOJro\",\"username\":\"SOJro\",\"id\":\"674003a3b0df5c00019b4110\",\"_links\":{\"addresses\":{\"href
  04:08:27.587 [front-end] GET Request to: http://user/customers/674003a3b0df5c00019b4110/addresses  (×2)
  04:08:27.599 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"674003aab0df5c00019b412c\",\"_links\":{\"
  04:08:27.600 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67400
  04:08:27.600 [front-end] [ undefined, undefined ]
  04:08:27.600 [front-end] Posting Order: {"customer":"http://user/customers/674003a3b0df5c00019b4110","address":"http://user/addresses/674003aab0df5c00019b4129","card":"http://user/cards
  04:08:27.613 [front-end] Carts merged.
  04:08:27.613 [front-end] set cookie674003bbb0df5c00019b416c
All services, 30 seconds either side (sampled):
  04:07:57.652 [front-end] Posting Customer: {"username":"LopxNimboEWl","password":"oHKgS","email":"LopxNimboEWl@gmail.com","firstName":"LopxNimboEWl","lastName":"LopxNimboEWl"}
  04:07:57.704 [front-end] GET /catalogue 200 - ms - -  (×62)
  04:07:57.912 [catalogue] ts=2024-11-22T04:07:57Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=3.505306  (×55)
  04:07:58.403 [front-end] Received response: "{\"firstName\":\"GDqspo\",\"lastName\":\"GDqspo\",\"username\":\"GDqspo\",\"id\":\"6740038eb0df5c00019b40df\",\"_links\":{\"addresses\":{\"h
  04:07:58.435 [shipping] Adding shipment to queue...  (×51)
  04:07:59.053 [user] ts=2024-11-22T04:07:59.053029158Z caller=middlewares.go:46 method=Register username=rfthehZQfMNqVlc email=rfthehZQfMNqVlc@gmail.com took=802.963µs  (×15)
  04:08:00.085 [front-end] Posting Customer: {"username":"nrvXXMLARacOg","password":"lzUSZqelcv","email":"nrvXXMLARacOg@gmail.com","firstName":"nrvXXMLARacOg","lastName":"nrvXXMLARacOg"}
  04:08:03.384 [front-end] Posting Customer: {"username":"DbigCh","password":"VIPEbntsg","email":"DbigCh@gmail.com","firstName":"DbigCh","lastName":"DbigCh"}
  04:08:04.795 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×7)
  04:08:07.389 [front-end] Order response: {"id":"674003a7d94b9000069b4c5a","customerId":"67400390b0df5c00019b40e3","customer":{"id":null,"firstName":"bPueE","lastName":"bPueE","username"
  04:08:09.464 [user] ts=2024-11-22T04:08:09.463919875Z caller=middlewares.go:46 method=Register username=RJvvrtNb email=RJvvrtNb@gmail.com took=1.074306ms
  04:08:11.741 [front-end] Posting Customer: {"username":"qFeBgqG","password":"tBOopv","email":"qFeBgqG@gmail.com","firstName":"qFeBgqG","lastName":"qFeBgqG"}
  04:08:12.606 [front-end] Posting Customer: {"username":"ZhqZKdoOwO","password":"pTAzyqwFNW","email":"ZhqZKdoOwO@gmail.com","firstName":"ZhqZKdoOwO","lastName":"ZhqZKdoOwO"}
  04:08:16.081 [front-end] Order response: {"id":"674003b0d94b9000069b4c61","customerId":"6740039ab0df5c00019b40fd","customer":{"id":null,"firstName":"YxIatKNFUDupx","lastName":"YxIatKNFU
  04:08:19.380 [front-end] Received response: "{\"firstName\":\"nrvXXMLARacOg\",\"lastName\":\"nrvXXMLARacOg\",\"username\":\"nrvXXMLARacOg\",\"id\":\"674003a0b0df5c00019b4108\",\"_links\
  04:08:20.941 [front-end] Order response: {"id":"674003b4d94b9000069b4c66","customerId":"6740039db0df5c00019b4101","customer":{"id":null,"firstName":"LopxNimboEWl","lastName":"LopxNimboE
  04:08:22.565 [front-end] Posting Customer: {"username":"wzCNcVJu","password":"MLIvieKuO","email":"wzCNcVJu@gmail.com","firstName":"wzCNcVJu","lastName":"wzCNcVJu"}
  04:08:26.195 [front-end] Received response: "{\"firstName\":\"UUNxQHmPqm\",\"lastName\":\"UUNxQHmPqm\",\"username\":\"UUNxQHmPqm\",\"id\":\"674003a7b0df5c00019b4124\",\"_links\":{\"addr
  04:08:28.799 [front-end] Received response: "{\"firstName\":\"TplQFHJ\",\"lastName\":\"TplQFHJ\",\"username\":\"TplQFHJ\",\"id\":\"674003a5b0df5c00019b411b\",\"_links\":{\"addresses\":{
  04:08:29.162 [front-end] Order response: {"id":"674003bdd94b9000069b4c71","customerId":"674003a7b0df5c00019b4123","customer":{"id":null,"firstName":"VqKMVwMkB","lastName":"VqKMVwMkB","u
  04:08:30.901 [front-end] Order response: {"id":"674003bed94b9000069b4c74","customerId":"674003acb0df5c00019b4133","customer":{"id":null,"firstName":"ZhqZKdoOwO","lastName":"ZhqZKdoOwO",
  04:08:34.411 [front-end] Order response: {"statusCode":201,"body":{"id":"674003c2d94b9000069b4c77","customerId":"674003aab0df5c00019b4128","customer":{"id":null,"firstName":"iZHjaAfG","
  04:08:35.537 [front-end] Order response: {"id":"674003c3d94b9000069b4c79","customerId":"674003b7b0df5c00019b415e","customer":{"id":null,"firstName":"SrtERViTouai","lastName":"SrtERViTou
  04:08:37.081 [front-end] Order response: {"statusCode":201,"body":{"id":"674003c5d94b9000069b4c7c","customerId":"674003b3b0df5c00019b414e","customer":{"id":null,"firstName":"bCoxKZeqTWn
  04:08:43.816 [front-end] Received response: "{\"firstName\":\"wzCNcVJu\",\"lastName\":\"wzCNcVJu\",\"username\":\"wzCNcVJu\",\"id\":\"674003b6b0df5c00019b4157\",\"_links\":{\"addresses\
  04:08:46.778 [front-end] Posting Customer: {"username":"DACGLayPjBUrh","password":"PdnkTAbQr","email":"DACGLayPjBUrh@gmail.com","firstName":"DACGLayPjBUrh","lastName":"DACGLayPjBUrh"}
  04:08:50.348 [front-end] Order response: {"id":"674003d2d94b9000069b4c81","customerId":"674003b9b0df5c00019b4166","customer":{"id":null,"firstName":"dQsmmMbxq","lastName":"dQsmmMbxq","u
  04:08:51.673 [front-end] Received response: "{\"firstName\":\"JiQocuIHaDKr\",\"lastName\":\"JiQocuIHaDKr\",\"username\":\"JiQocuIHaDKr\",\"id\":\"674003c0b0df5c00019b4175\",\"_links\":{
  04:08:53.210 [user] ts=2024-11-22T04:08:53.210143765Z caller=middlewares.go:46 method=Register username=YZWnZm email=YZWnZm@gmail.com took=1.025496ms
  04:08:57.158 [front-end] Posting Customer: {"username":"POSQalWGW","password":"ZHvlYZ","email":"POSQalWGW@gmail.com","firstName":"POSQalWGW","lastName":"POSQalWGW"}

## p0452
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-23T08:06:19.587Z
```
{"timestamp":1732349179587097000,"container_name":"orders","pod_name":"orders-7fff6698cb-rlq5k","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:19.586 ERROR [orders,,,] 8 --- [p-nio-80-exec-6] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalStateException: Unable to create order due to unspecified IO error.] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  08:06:12.431 [orders] 2024-11-23 08:06:12.430 ERROR [orders,,,] 8 --- [p-nio-80-exec-6] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×9)
  08:06:12.431 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×10)
  08:06:13.958 [orders] 2024-11-23 08:06:13.958 ERROR [orders,,,] 8 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
All services, 30 seconds either side (sampled):
  08:05:49.793 [orders] 2024-11-23 08:05:49.793 INFO [orders,3bd25edf52d54df8,3bd25edf52d54df8,false] 8 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/orders
  08:05:50.341 [front-end] Merging carts for customer id: 67418cdea437380001deec56 and session id: dM_Q6epNQzXJhVbSGZDBgoO58-oMCsdj  (×62)
  08:05:50.760 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}  (×62)
  08:05:51.293 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×39)
  08:05:54.899 [shipping] 2024-11-23 08:05:54.899 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public ja
  08:05:55.070 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×7)
  08:05:58.133 [front-end] Received response: "{\"firstName\":\"uOuKqLBUeqm\",\"lastName\":\"uOuKqLBUeqm\",\"username\":\"uOuKqLBUeqm\",\"id\":\"67418cd1a437380001deec35\",\"_links\":{\"a
  08:06:00.402 [shipping] 2024-11-23 08:06:00.402 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class
  08:06:04.195 [front-end] Received response: "{\"firstName\":\"MQTmuf\",\"lastName\":\"MQTmuf\",\"username\":\"MQTmuf\",\"id\":\"67418cd8a437380001deec46\",\"_links\":{\"addresses\":{\"h
  08:06:07.000 [shipping] 2024-11-23 08:06:06.999 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+j
  08:06:07.007 [shipping] 2024-11-23 08:06:07.007 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT
  08:06:07.603 [front-end] Posting Customer: {"username":"ucodWkVEg","password":"qgiOJg","email":"ucodWkVEg@gmail.com","firstName":"ucodWkVEg","lastName":"ucodWkVEg"}
  08:06:13.374 [user] ts=2024-11-23T08:06:13.374609026Z caller=middlewares.go:46 method=Register username=teNYQYg email=teNYQYg@gmail.com took=2.529487ms
  08:06:15.130 [front-end] Received response: "{\"firstName\":\"RSyStLrwvSRDG\",\"lastName\":\"RSyStLrwvSRDG\",\"username\":\"RSyStLrwvSRDG\",\"id\":\"67418ce1a437380001deec62\",\"_links\
  08:06:15.805 [carts] 2024-11-23 08:06:15.804 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[GE
  08:06:15.906 [carts] 2024-11-23 08:06:15.904 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[text/html]}" onto public 
  08:06:18.955 [user] ts=2024-11-23T08:06:18.95496322Z caller=middlewares.go:46 method=Register username=VWOjt email=VWOjt@gmail.com took=2.434446ms
  08:06:19.105 [carts] 2024-11-23 08:06:19.104 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  08:06:22.980 [front-end] Received response: "{\"firstName\":\"LeJTlhMOCH\",\"lastName\":\"LeJTlhMOCH\",\"username\":\"LeJTlhMOCH\",\"id\":\"67418ce3a437380001deec69\",\"_links\":{\"addr
  08:06:25.637 [front-end] Posting Customer: {"username":"HRFgUBgyU","password":"iGVSOf","email":"HRFgUBgyU@gmail.com","firstName":"HRFgUBgyU","lastName":"HRFgUBgyU"}
  08:06:28.000 [carts] 2024-11-23 08:06:27.999 INFO [carts,,,] 7 --- [p-nio-80-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  08:06:30.705 [carts] 2024-11-23 08:06:30.705 INFO [carts,993241630eccab18,e1237bff67df759e,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×8)
  08:06:32.806 [orders] 2024-11-23 08:06:32.806 INFO [orders,fbcebf8ef5e82428,6d050ec4f8a03a61,false] 8 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Received payment re  (×16)
  08:06:34.719 [front-end] POST /cart 201 - ms - -  (×27)
  08:06:35.986 [orders-db] {"t":{"$date":"2024-11-23T08:06:35.986+00:00"},"s":"I", "c":"STORAGE", "id":20320, "ctx":"conn5","msg":"createCollection","attr":{"namespace":"data.customerOrde  (×5)
  08:06:39.627 [front-end] Posting Customer: {"username":"ErFfEEVmz","password":"xXhfhSu","email":"ErFfEEVmz@gmail.com","firstName":"ErFfEEVmz","lastName":"ErFfEEVmz"}
  08:06:41.163 [front-end] Received response: "{\"firstName\":\"OkxajUZjGhkcaQY\",\"lastName\":\"OkxajUZjGhkcaQY\",\"username\":\"OkxajUZjGhkcaQY\",\"id\":\"67418cf8a437380001deeca8\",\"_
  08:06:43.776 [front-end] Received response: "{\"firstName\":\"GXUtAA\",\"lastName\":\"GXUtAA\",\"username\":\"GXUtAA\",\"id\":\"67418cf8a437380001deeca7\",\"_links\":{\"addresses\":{\"h
  08:06:47.587 [front-end] Order response: {"id":"67418d173f77060008864e48","customerId":"67418d02a437380001deecc4","customer":{"id":null,"firstName":"KGcCpZnH","lastName":"KGcCpZnH","use
  08:06:48.895 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d183f77060008864e4d","customerId":"67418cfea437380001deecb6","customer":{"id":null,"firstName":"uIDJZeefxEL

## p0369
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:37:56.521Z
```
{"timestamp":1732246676521138000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Attempting to delete cart for user: 673ffc8db0df5c00019b2b57"}
```
Same service, the 2 minutes before (oldest first):
  03:37:56.312 [front-end] Posting Customer: {"username":"nroitNhvO","password":"gGdXV","email":"nroitNhvO@gmail.com","firstName":"nroitNhvO","lastName":"nroitNhvO"}
  03:37:56.312 [front-end] { id: '673ffc94b0df5c00019b2b66' }  (×2)
  03:37:56.312 [front-end] 673ffc94b0df5c00019b2b66  (×2)
  03:37:56.312 [front-end] Merging carts for customer id: 673ffc94b0df5c00019b2b66 and session id: D-ltML2PKwiyNToE8YIFfZBS5CSXH2nW  (×2)
  03:37:56.335 [front-end] Carts merged.  (×2)
  03:37:56.335 [front-end] set cookie673ffc94b0df5c00019b2b66  (×2)
  03:37:56.335 [front-end] Sent cookies.  (×2)
  03:37:56.337 [front-end] POST /register 200 29.292 ms - 33  (×2)
  03:37:56.430 [front-end] Posting Customer: {"username":"PoYMDSfoEEGv","password":"zvceqf","email":"PoYMDSfoEEGv@gmail.com","firstName":"PoYMDSfoEEGv","lastName":"PoYMDSfoEEGv"}
  03:37:56.453 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffc8db0df5c00019b2b57"}
  03:37:56.462 [front-end] POST /addresses 200 - ms - -
  03:37:56.467 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffc8db0df5c00019b2b57"}
  03:37:56.476 [front-end] POST /cards 200 - ms - -
All services, 30 seconds either side (sampled):
  03:37:26.565 [front-end] Attempting to delete cart for user: 673ffc6cb0df5c00019b2aef  (×57)
  03:37:26.887 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffc6fb0df5c00019b2af9"}  (×57)
  03:37:27.509 [front-end] GET Request to: http://user/customers/673ffc65b0df5c00019b2adb/addresses  (×126)
  03:37:27.544 [queue-master] Received shipment task: 673ffc65b0df5c00019b2adb  (×57)
  03:37:27.698 [front-end] Merging carts for customer id: 673ffc77b0df5c00019b2b16 and session id: fJGQ9tm9T3i765bvDhYEQkAa-KdqWGO7  (×58)
  03:37:28.515 [user] ts=2024-11-22T03:37:28.514935062Z caller=middlewares.go:104 method=GetAddresses id=673ffc69b0df5c00019b2ae4 result=1 took=1.198738ms  (×12)
  03:37:30.549 [front-end] Posting Customer: {"username":"AmbXyOJyEntbp","password":"kBTJYzHEPn","email":"AmbXyOJyEntbp@gmail.com","firstName":"AmbXyOJyEntbp","lastName":"AmbXyOJyEntbp"}
  03:37:32.056 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc7cd94b9000069b4675","customerId":"673ffc6cb0df5c00019b2af2","customer":{"id":null,"firstName":"enlrXALABSp
  03:37:33.172 [front-end] Received response: "{\"firstName\":\"MryyscIog\",\"lastName\":\"MryyscIog\",\"username\":\"MryyscIog\",\"id\":\"673ffc68b0df5c00019b2ae3\",\"_links\":{\"address
  03:37:34.357 [payment] ts=2024-11-22T03:37:34Z caller=logging.go:29 method=Authorise result=true took=1.264µs  (×18)
  03:37:36.105 [front-end] Order response: {"id":"673ffc80d94b9000069b467d","customerId":"673ffc6fb0df5c00019b2af9","customer":{"id":null,"firstName":"kKqAWGT","lastName":"kKqAWGT","usern
  03:37:39.922 [front-end] Order response: {"id":"673ffc83d94b9000069b467e","customerId":"673ffc69b0df5c00019b2ae6","customer":{"id":null,"firstName":"ruUnBiE","lastName":"ruUnBiE","usern
  03:37:40.709 [front-end] Order response: {"id":"673ffc84d94b9000069b4680","customerId":"673ffc6cb0df5c00019b2af0","customer":{"id":null,"firstName":"MZJeSb","lastName":"MZJeSb","usernam
  03:37:43.412 [front-end] Received response: "{\"firstName\":\"waNcPTeG\",\"lastName\":\"waNcPTeG\",\"username\":\"waNcPTeG\",\"id\":\"673ffc74b0df5c00019b2b0c\",\"_links\":{\"addresses\
  03:37:45.707 [front-end] Order response: {"id":"673ffc89d94b9000069b4686","customerId":"673ffc78b0df5c00019b2b18","customer":{"id":null,"firstName":"OQQQZlhzNOh","lastName":"OQQQZlhzNOh
  03:37:48.902 [front-end] Received response: "{\"firstName\":\"NDNSACOyVyxxf\",\"lastName\":\"NDNSACOyVyxxf\",\"username\":\"NDNSACOyVyxxf\",\"id\":\"673ffc77b0df5c00019b2b16\",\"_links\
  03:37:52.855 [front-end] Posting Customer: {"username":"MWgGe","password":"EQGKHN","email":"MWgGe@gmail.com","firstName":"MWgGe","lastName":"MWgGe"}
  03:37:55.597 [front-end] Posting Customer: {"username":"RlZmTOnSTDhxJ","password":"QHkmX","email":"RlZmTOnSTDhxJ@gmail.com","firstName":"RlZmTOnSTDhxJ","lastName":"RlZmTOnSTDhxJ"}
  03:37:57.310 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc95d94b9000069b4690","customerId":"673ffc81b0df5c00019b2b30","customer":{"id":null,"firstName":"aWlnoBDycQ"
  03:37:59.107 [front-end] Order response: {"id":"673ffc97d94b9000069b4693","customerId":"673ffc86b0df5c00019b2b43","customer":{"id":null,"firstName":"CxeGqyUCo","lastName":"CxeGqyUCo","u
  03:38:01.373 [front-end] Received response: "{\"firstName\":\"LzntP\",\"lastName\":\"LzntP\",\"username\":\"LzntP\",\"id\":\"673ffc84b0df5c00019b2b3a\",\"_links\":{\"addresses\":{\"href
  03:38:07.209 [front-end] Received response: "{\"firstName\":\"IdiTwgAYpCuvg\",\"lastName\":\"IdiTwgAYpCuvg\",\"username\":\"IdiTwgAYpCuvg\",\"id\":\"673ffc8db0df5c00019b2b58\",\"_links\
  03:38:09.946 [user] ts=2024-11-22T03:38:09.946572881Z caller=middlewares.go:46 method=Register username=DwAwcDO email=DwAwcDO@gmail.com took=1.069468ms
  03:38:14.423 [front-end] Received response: "{\"firstName\":\"ZHqnMzYU\",\"lastName\":\"ZHqnMzYU\",\"username\":\"ZHqnMzYU\",\"id\":\"673ffc93b0df5c00019b2b63\",\"_links\":{\"addresses\
  03:38:15.347 [front-end] Order response: {"id":"673ffca7d94b9000069b46a0","customerId":"673ffc8bb0df5c00019b2b51","customer":{"id":null,"firstName":"UXVbJmKXYvNWcY","lastName":"UXVbJmKX
  03:38:17.894 [front-end] Posting Customer: {"username":"XkjlRreAZzB","password":"bweHF","email":"XkjlRreAZzB@gmail.com","firstName":"XkjlRreAZzB","lastName":"XkjlRreAZzB"}
  03:38:21.708 [front-end] Posting Customer: {"username":"YbjgCNEg","password":"HoOnqj","email":"YbjgCNEg@gmail.com","firstName":"YbjgCNEg","lastName":"YbjgCNEg"}
  03:38:24.547 [front-end] Received response: "{\"firstName\":\"nroitNhvO\",\"lastName\":\"nroitNhvO\",\"username\":\"nroitNhvO\",\"id\":\"673ffc94b0df5c00019b2b66\",\"_links\":{\"address
  03:38:26.173 [front-end] Order response: {"id":"673ffcb2d94b9000069b46aa","customerId":"673ffca1b0df5c00019b2b92","customer":{"id":null,"firstName":"DwAwcDO","lastName":"DwAwcDO","usern

## p0569
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-07T18:30:53.503Z
```
{"timestamp":1733596253503679200,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-srqkn","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 18:30:53.503  INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl  : [Basic Information Service][Query For Station Id] Station Id: Nan Jing"}
```
Same service, the 2 minutes before (oldest first):
  18:30:50.681 [ts-basic-service] 2024-12-07 18:30:50.681 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×5)
  18:30:50.695 [ts-basic-service] 2024-12-07 18:30:50.695 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×4)
  18:30:50.730 [ts-basic-service] 2024-12-07 18:30:50.730 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  18:30:50.735 [ts-basic-service] 2024-12-07 18:30:50.735 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
  18:30:50.739 [ts-basic-service] 2024-12-07 18:30:50.739 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa
  18:30:50.749 [ts-basic-service] 2024-12-07 18:30:50.748 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  18:30:50.753 [ts-basic-service] 2024-12-07 18:30:50.753 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  18:30:50.754 [ts-basic-service] 2024-12-07 18:30:50.753 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693
  18:30:50.759 [ts-basic-service] 2024-12-07 18:30:50.759 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  18:30:50.773 [ts-basic-service] 2024-12-07 18:30:50.773 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai
  18:30:50.773 [ts-basic-service] 2024-12-07 18:30:50.773 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : indexStart : 2 __ indexEnd : 3
  18:30:50.773 [ts-basic-service] 2024-12-07 18:30:50.773 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4
  18:30:50.817 [ts-basic-service] 2024-12-07 18:30:50.817 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha
All services, 30 seconds either side (sampled):
  18:30:23.658 [ts-auth-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/  (×2)
  18:30:25.341 [ts-basic-service] 2024-12-07 18:30:25.341 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×18)
  18:30:25.377 [ts-basic-service] 2024-12-07 18:30:25.377 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1  (×21)
  18:30:25.448 [ts-seat-service] 2024-12-07 18:30:25.447 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×28)
  18:30:25.492 [ts-seat-service] 2024-12-07 18:30:25.492 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×38)
  18:30:25.554 [ts-seat-service] 2024-12-07 18:30:25.553 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×4)
  18:30:26.716 [ts-basic-service] 2024-12-07 18:30:26.716 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×8)
  18:30:27.249 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:30:27.249+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359622
  18:30:29.140 [ts-admin-basic-info-service] 2024-12-07 18:30:29.139 INFO 1 --- [io-18767-exec-9] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×9)
  18:30:29.660 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:30:29 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 3056 "-" "Mozilla/5.0 (Macintosh;  (×3)
  18:30:30.605 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-07T18:30:30.604+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359623
  18:30:36.068 [ts-auth-service] 2024-12-07 18:30:36.068 INFO 1 --- [ main] o.s.i.config.IntegrationRegistrar : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. The  (×2)
  18:30:40.512 [ts-order-other-service] 2024-12-07 18:30:40.512 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 24  (×3)
  18:30:41.368 [ts-auth-service] 2024-12-07 18:30:41.368 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.method.configuration.  (×2)
  18:30:42.396 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:30:42 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 403 148 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
  18:30:46.662 [ts-auth-service] 2024-12-07 18:30:46.661 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43  (×2)
  18:30:47.159 [ts-travel-service] 2024-12-07 18:30:47.159 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×4)
  18:30:47.236 [ts-travel-service] 2024-12-07 18:30:47.236 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×6)
  18:30:47.299 [ts-order-service] 2024-12-07 18:30:47.299 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160,   (×5)
  18:30:51.661 [ts-auth-service] 2024-12-07 18:30:51.661 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClust
  18:31:00.335 [ts-order-other-service] 2024-12-07 18:31:00.334 ERROR 1 --- [io-12032-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×4)
  18:31:01.654 [ts-auth-service] 2024-12-07 18:31:01.653 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth],methods=[POST]}" onto public org.springframework.h
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.872 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  18:31:04.652 [ts-seat-service] 2024-12-07 18:31:04.652 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×2)
  18:31:09.955 [ts-auth-service] 2024-12-07 18:31:09.954 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 12340 (http)
  18:31:11.720 [ts-order-service] 2024-12-07 18:31:11.720 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : Left ticket info is empty  (×5)
  18:31:12.245 [ts-basic-service] 2024-12-07 18:31:12.245 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2
  18:31:18.568 [ts-auth-service] 2024-12-07 18:31:18.568 INFO 1 --- [io-12340-exec-3] org.mongodb.driver.connection : Opened connection [connectionId{localValue:3, serverValue:22}] to ts-auth-m  (×2)
  18:31:20.890 [ts-travel-service] 2024-12-07 18:31:20.889 ERROR 1 --- [io-12346-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt

## p0181
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service shippingservice, 2024-11-18T06:41:38.127Z
```
{"timestamp":1731912098127159600,"container_name":"shippingservice","pod_name":"shippingservice-547ddf469c-vjbwz","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"[GetQuote] received request"}
```
Same service, the 2 minutes before (oldest first):
  06:41:30.965 [shippingservice] [GetQuote] received request  (×8)
  06:41:30.965 [shippingservice] [GetQuote] completed request  (×8)
  06:41:34.054 [shippingservice] [ShipOrder] received request  (×2)
  06:41:34.054 [shippingservice] [ShipOrder] completed request  (×2)
All services, 30 seconds either side (sampled):
  06:41:08.177 [frontend] request started  (×305)
  06:41:08.183 [cartservice] GetCartAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432  (×254)
  06:41:08.199 [shippingservice] [GetQuote] completed request  (×79)
  06:41:08.225 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '9SIQT8TOJO', '0PUK6V6EV0', '2ZYFJ3GM2N', 'OLJCESPC7Z']  (×213)
  06:41:08.306 [adservice] received ad request (context_words=[kitchen])  (×60)
  06:41:09.553 [frontend] home  (×31)
  06:41:09.794 [adservice] received ad request (context_words=[decor, home])  (×9)
  06:41:11.032 [redis] 66:C 18 Nov 2024 06:41:11.032 * DB saved on disk
  06:41:13.460 [frontend] adding to cart  (×30)
  06:41:13.528 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="EUR"  (×4)
  06:41:13.561 [paymentservice] Transaction processed: visa ending 2358 Amount: EUR860.866873073  (×4)
  06:41:13.566 [shippingservice] [ShipOrder] completed request  (×13)
  06:41:13.573 [checkoutservice] failed to send order confirmation to "andrewrodriguez@example.com": rpc error: code = Unavailable desc = no healthy upstream
  06:41:15.894 [checkoutservice] failed to send order confirmation to "emily09@example.net": rpc error: code = Unavailable desc = upstream connect error or disconnect/reset before headers. retr
  06:41:17.856 [emailservice] Traceback (most recent call last): File "/email_server/email_server.py", line 199, in <module> start(dummy_mode = True) File "/email_server/email_server.py", li
  06:41:18.402 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"151","nanos":247884121},"credit_card":{"credit_card_number":"43137936261300  (×5)
  06:41:18.946 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', 'LS4PSXUNUM', 'OLJCESPC7Z']  (×3)
  06:41:29.903 [checkoutservice] [PlaceOrder] user_id="33421b66-55b6-413b-9ba9-3230c85c58dc" user_currency="TRY"  (×3)
  06:41:29.941 [checkoutservice] failed to send order confirmation to "james02@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:41:38.119 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', '0PUK6V6EV0', '1YMWWN1N4O', 'LS4PSXUNUM']  (×4)
  06:41:52.537 [checkoutservice] failed to send order confirmation to "nmarshall@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:41:53.372 [paymentservice] Transaction processed: visa ending 9626 Amount: CAD921.744155677

## p0159
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:46:40.147Z
```
{"timestamp":1731908800147071700,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  05:46:37.769 [frontend] request complete  (×7)
  05:46:37.772 [frontend] request error
  05:46:37.903 [frontend] request started  (×6)
  05:46:37.903 [frontend] serving product page  (×3)
  05:46:38.294 [frontend] view user cart  (×2)
  05:46:40.147 [frontend] setting currency
All services, 30 seconds either side (sampled):
  05:46:10.236 [frontend] request started  (×288)
  05:46:10.243 [cartservice] GetCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×236)
  05:46:10.265 [shippingservice] [GetQuote] completed request  (×51)
  05:46:10.516 [frontend] setting currency  (×21)
  05:46:10.569 [adservice] received ad request (context_words=[])  (×27)
  05:46:10.833 [adservice] received ad request (context_words=[kitchen])  (×50)
  05:46:12.125 [frontend] span hipstershop.CartService/AddItem failed with gRPC status 9  (×31)
  05:46:12.131 [frontend] request error  (×31)
  05:46:15.904 [adservice] received ad request (context_words=[hair, beauty])  (×23)
  05:46:20.616 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"1005","nanos":162317560},"credit_card":{"credit_card_number":"4947984362639
  05:46:20.620 [shippingservice] [ShipOrder] received request  (×8)
  05:46:20.628 [emailservice] A request to send order confirmation email to erica33@example.net has been received.
  05:46:21.782 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="GBP"
  05:46:21.820 [emailservice] A request to send order confirmation email to robertkirk@example.com has been received.
  05:46:41.886 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"12","nanos":30138876},"credit_card":{"credit_card_number":"4413858399502891  (×2)
  05:46:41.900 [checkoutservice] order confirmation email sent to "bharris@example.net"
  05:46:52.461 [paymentservice] Transaction processed: visa ending 6083 Amount: TRY48.705044670
  05:46:54.215 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="USD"  (×3)
  05:46:54.243 [emailservice] A request to send order confirmation email to sheri34@example.org has been received.
  05:46:57.234 [checkoutservice] order confirmation email sent to "stevengregory@example.com"
  05:47:08.956 [emailservice] A request to send order confirmation email to johncooke@example.org has been received.

## p0218
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:47:52.533Z
```
{"timestamp":1731916072533053700,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  07:47:50.626 [frontend] request started  (×7)
  07:47:50.626 [frontend] serving product page  (×5)
  07:47:50.660 [frontend] request complete  (×6)
  07:47:51.321 [frontend] view user cart
  07:47:52.523 [frontend] adding to cart
All services, 30 seconds either side (sampled):
  07:47:22.636 [frontend] request started  (×313)
  07:47:22.640 [currencyservice] Getting supported currencies...  (×256)
  07:47:22.650 [currencyservice] conversion request successful  (×683)
  07:47:22.669 [adservice] received ad request (context_words=[kitchen])  (×52)
  07:47:22.791 [adservice] received ad request (context_words=[accessories])  (×38)
  07:47:22.798 [cartservice] AddItemAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4, productId=OLJCESPC7Z, quantity=5  (×36)
  07:47:22.829 [shippingservice] [GetQuote] received request  (×76)
  07:47:23.227 [frontend] setting currency  (×21)
  07:47:23.275 [frontend] ENV_PLATFORM is: aws  (×30)
  07:47:25.123 [adservice] received ad request (context_words=[hair, beauty])  (×16)
  07:47:25.773 [adservice] received ad request (context_words=[footwear])  (×14)
  07:47:27.424 [checkoutservice] [PlaceOrder] user_id="adf41e5f-12f6-4c40-88a0-a1bcf421e416" user_currency="JPY"
  07:47:27.454 [paymentservice] Transaction processed: visa ending 7503 Amount: JPY42551.126051150
  07:47:27.457 [shippingservice] [ShipOrder] received request  (×7)
  07:47:27.460 [cartservice] EmptyCartAsync called with userId=adf41e5f-12f6-4c40-88a0-a1bcf421e416  (×7)
  07:47:27.467 [checkoutservice] order confirmation email sent to "geraldwall@example.org"
  07:47:27.628 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', '1YMWWN1N4O', 'OLJCESPC7Z', '2ZYFJ3GM2N']  (×2)
  07:47:29.908 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="EUR"  (×2)
  07:47:29.942 [paymentservice] Transaction processed: visa ending 8296 Amount: EUR1064.219371972  (×2)
  07:47:29.955 [checkoutservice] order confirmation email sent to "cmann@example.com"
  07:47:38.794 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"120","nanos":844694381},"credit_card":{"credit_card_number":"48439645256508
  07:47:38.806 [emailservice] A request to send order confirmation email to stewartlauren@example.org has been received.
  07:47:39.400 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="CAD"  (×2)
  07:47:39.437 [paymentservice] Transaction processed: visa ending 4244 Amount: CAD2720.591150830  (×2)
  07:47:39.451 [checkoutservice] order confirmation email sent to "dwaynewilliams@example.com"
  07:48:02.538 [checkoutservice] [PlaceOrder] user_id="0727db9d-83b9-44b7-acab-68a4f8f289c0" user_currency="USD"
  07:48:02.562 [paymentservice] Transaction processed: visa ending 4114 Amount: USD1068.890000000
  07:48:02.577 [checkoutservice] order confirmation email sent to "gary93@example.net"
  07:48:05.758 [checkoutservice] order confirmation email sent to "holmeslisa@example.net"
  07:48:06.171 [checkoutservice] order confirmation email sent to "holly17@example.com"

## p0060
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-13T08:43:59.502Z
```
{"service":"mobservice2","message":"2021-08-13 08:43:59,502 | INFO | 0.0.0.4 | 172.17.0.2 | mobservice2 | a9bb702cea6f6d40 | info 8c1439ea-fbcf-11eb-8587-0242ac110003:aolWDIFH write success"}
```
Same service, the 2 minutes before (oldest first):
  08:43:50.229 [mobservice2] INFO info 86902aa6-fbcf-11eb-b9b8-0242ac110004:nxGFAjVa write success
  08:43:52.218 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  08:43:52.218 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  08:43:52.219 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '87cc9a1c-fbcf-11eb-b28a-0242ac110004'}  (×4)
  08:43:52.281 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '87cc9a1c-fbcf-11eb-b28a-0242ac110004', 'value': 'OKolGsUM'}  (×4)
  08:43:52.348 [mobservice2] INFO info 87cc9a1c-fbcf-11eb-b28a-0242ac110004:OKolGsUM write success
  08:43:55.932 [mobservice2] INFO info 89ee5826-fbcf-11eb-8e46-0242ac110003:pkIFrtAz write success
  08:43:58.062 [mobservice2] INFO info 8b37c186-fbcf-11eb-85c7-0242ac110004:SZKcrGIR write success
All services, 30 seconds either side (sampled):
  08:43:29.526 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  08:43:29.669 [mobservice1] INFO info 7a37158a-fbcf-11eb-974e-0242ac110003:GKtJXRfS write success
  08:43:29.790 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×44)
  08:43:29.859 [logservice1] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '7a37158a-fbcf-11eb-974e-0242ac110003', 'user_id': 'GKtJXRfS'}  (×89)
  08:43:30.025 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  08:43:30.499 [dbservice1] INFO 7a8dd62c-fbcf-11eb-8316-0242ac110004-yjlLtMmx-<?.ZdYVR2js- token generate success token=MTYyODgxNTQxMC40OTkzMzgyOjdhOGRkNjJjLWZiY2YtMTFlYi04MzE2LTAyNDJhYzE
  08:43:30.806 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×45)
  08:43:31.321 [webservice1] ERROR an error occurred in the downstream service  (×27)
  08:43:32.543 [mobservice1] INFO info 7bfb9846-fbcf-11eb-811a-0242ac110004:wRdieUHE write success
  08:43:32.719 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×35)
  08:43:35.247 [mobservice1] INFO info 7d983fe2-fbcf-11eb-8a18-0242ac110003:tcZveHsK write success
  08:43:37.974 [mobservice1] INFO info 7f3ac932-fbcf-11eb-b0be-0242ac110003:ifRVUwrZ write success
  08:43:40.910 [dbservice1] INFO 80c4fae8-fbcf-11eb-a1e4-0242ac110004-GrKgOByV-n@*{TE_p^JR3 token generate success token=MTYyODgxNTQyMC45MTAwNzk6ODBjNGZhZTgtZmJjZi0xMWViLWExZTQtMDI0MmFjMTE
  08:43:43.369 [dbservice1] INFO 823c5bc8-fbcf-11eb-8343-0242ac110003-pkiwOTAa-MCwpc)<4IznE token generate success token=MTYyODgxNTQyMy4zNjg3ODM6ODIzYzViYzgtZmJjZi0xMWViLTgzNDMtMDI0MmFjMTE
  08:43:45.560 [mobservice1] INFO info 83bfcdb8-fbcf-11eb-8850-0242ac110003:pSzgtGmR write success
  08:43:49.307 [mobservice1] INFO info 85ff6480-fbcf-11eb-b036-0242ac110003:DhdfCMlE write success
  08:43:55.140 [mobservice1] INFO info 897a95f8-fbcf-11eb-8dfb-0242ac110004:dzcaqmiU write success
  08:43:58.727 [mobservice1] INFO info 8b9a7bf0-fbcf-11eb-89d7-0242ac110003:zxoeJtIu write success
  08:44:02.449 [mobservice2] INFO info 8dd5bf1a-fbcf-11eb-88d4-0242ac110004:RkyaDUzj write success
  08:44:05.766 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  08:44:09.907 [mobservice1] INFO info 92461dc4-fbcf-11eb-b8d3-0242ac110004:NmlBnobg write success
  08:44:13.829 [dbservice1] INFO 946822a0-fbcf-11eb-8496-0242ac110003-zxoeJtIu--mO?#>J+iEIB token generate success token=MTYyODgxNTQ1My44MjkyNjg6OTQ2ODIyYTAtZmJjZi0xMWViLTg0OTYtMDI0MmFjMTE
  08:44:16.964 [mobservice2] INFO info 9676f440-fbcf-11eb-a399-0242ac110004:CxaURntJ write success
  08:44:19.112 [mobservice2] INFO info 97c1ef26-fbcf-11eb-a6d3-0242ac110004:VkjGfAwW write success
  08:44:22.343 [mobservice1] INFO info 99ad169e-fbcf-11eb-95f9-0242ac110004:GYgLnikZ write success
  08:44:25.368 [mobservice2] INFO info 9b74ee16-fbcf-11eb-8ec5-0242ac110003:DjXaKYNR write success
  08:44:27.231 [dbservice1] INFO 9c700a3a-fbcf-11eb-a0ed-0242ac110004-qHGVUSPX-2X6L_bVf5*I< token generate success token=MTYyODgxNTQ2Ny4yMzEzNjM4OjljNzAwYTNhLWZiY2YtMTFlYi1hMGVkLTAyNDJhYzE
  08:44:29.481 [dbservice1] INFO 9dbb3c48-fbcf-11eb-9914-0242ac110004-dIHpsMvT-UQ)#EA.:F_XL token generate success token=MTYyODgxNTQ2OS40ODE1NjUyOjlkYmIzYzQ4LWZiY2YtMTFlYi05OTE0LTAyNDJhYzE

## p0490
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:57:08.951Z
```
{"timestamp":1732352228951565800,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"_embedded\\\":{\\\"card\\\":[{\\\"longNum\\\":\\\"123123321\\\",\\\"expires\\\":\\\"1232\\\",\\\"ccv\\\":\\\"123\\\",\\\"id\\\":\\\"674198d5a437380001deff9e\\\",\\\"_links\\\":{\\\"card\\\":{\\\"href\\\":\\\"http://user/cards/674198d5a437380001deff9e\\\"},\\\"self\\\":{\\\"href\\\":\\\"http://user/cards/674198d5a437380001deff9e\\\"}}}]}}\\n\""}
```
Same service, the 2 minutes before (oldest first):
  08:57:07.239 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
  08:57:07.239 [front-end] POST to carts: http://carts/carts/674198d9a437380001deffa4/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}
  08:57:07.277 [front-end] POST /cart 201 - ms - -
  08:57:07.360 [front-end] GET /catalogue 200 - ms - -  (×4)
  08:57:07.646 [front-end] Posting Customer: {"username":"wWVXfxc","password":"MWeTANl","email":"wWVXfxc@gmail.com","firstName":"wWVXfxc","lastName":"wWVXfxc"}
  08:57:07.657 [front-end] { id: '674198e3a437380001deffb3' }
  08:57:07.657 [front-end] 674198e3a437380001deffb3
  08:57:07.657 [front-end] Merging carts for customer id: 674198e3a437380001deffb3 and session id: 01iLdm4AOsQoqXevb8nS5le3DmgwUvnx
  08:57:07.678 [front-end] Carts merged.
  08:57:07.678 [front-end] set cookie674198e3a437380001deffb3
  08:57:07.679 [front-end] Sent cookies.
  08:57:07.680 [front-end] POST /register 200 32.770 ms - 33
  08:57:08.927 [front-end] Request received with body: {}
  08:57:08.940 [front-end] Received response: "{\"firstName\":\"kJHasbuoFGY\",\"lastName\":\"kJHasbuoFGY\",\"username\":\"kJHasbuoFGY\",\"id\":\"674198cfa437380001deff8d\",\"_links\":{\"a
  08:57:08.940 [front-end] GET Request to: http://user/customers/674198cfa437380001deff8d/addresses  (×2)
  08:57:08.951 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67419
All services, 30 seconds either side (sampled):
  08:56:58.007 [catalogue] ts=2024-11-23T08:56:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.869902ms  (×46)
  08:56:58.025 [queue-master] Received shipment task: 674198bfa437380001deff45  (×34)
  08:56:59.331 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"674198d3a437380001deff98"}  (×39)
  08:56:59.474 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×39)
  08:57:00.731 [front-end] Received response: "{\"firstName\":\"nuXAdkfqQQTG\",\"lastName\":\"nuXAdkfqQQTG\",\"username\":\"nuXAdkfqQQTG\",\"id\":\"674198caa437380001deff7c\",\"_links\":{
  08:57:00.838 [front-end] Order response: {"id":"674198dc3f77060008865385","customerId":"674198caa437380001deff7c","customer":{"id":null,"firstName":"nuXAdkfqQQTG","lastName":"nuXAdkfqQQ
  08:57:01.163 [user] ts=2024-11-23T08:57:01.163824603Z caller=middlewares.go:46 method=Register username=eWMmgZPhWLI email=eWMmgZPhWLI@gmail.com took=2.820248ms  (×21)
  08:57:02.787 [front-end] Received response: "{\"firstName\":\"iEYCUjoH\",\"lastName\":\"iEYCUjoH\",\"username\":\"iEYCUjoH\",\"id\":\"674198c5a437380001deff67\",\"_links\":{\"addresses\
  08:57:03.104 [front-end] Received response: "{\"firstName\":\"ssJdfJXeVtH\",\"lastName\":\"ssJdfJXeVtH\",\"username\":\"ssJdfJXeVtH\",\"id\":\"674198cca437380001deff89\",\"_links\":{\"a
  08:57:05.233 [front-end] Received response: "{\"firstName\":\"LEiit\",\"lastName\":\"LEiit\",\"username\":\"LEiit\",\"id\":\"674198c8a437380001deff74\",\"_links\":{\"addresses\":{\"href
  08:57:06.986 [front-end] Received response: "{\"firstName\":\"vidoaLMiMZn\",\"lastName\":\"vidoaLMiMZn\",\"username\":\"vidoaLMiMZn\",\"id\":\"674198caa437380001deff7d\",\"_links\":{\"a
  08:57:08.980 [queue-master] 2024-11-23 08:57:08.980 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×81)
  08:57:09.328 [front-end] Order response: {"statusCode":201,"body":{"id":"674198e53f7706000886538d","customerId":"674198c9a437380001deff7b","customer":{"id":null,"firstName":"gwVURDHGhHv
  08:57:11.811 [user] ts=2024-11-23T08:57:11.811205446Z caller=middlewares.go:46 method=Register username=bVfUCqC email=bVfUCqC@gmail.com took=1.831284ms
  08:57:14.121 [front-end] Posting Customer: {"username":"JCYeKSjM","password":"MYIoBCiY","email":"JCYeKSjM@gmail.com","firstName":"JCYeKSjM","lastName":"JCYeKSjM"}
  08:57:17.115 [front-end] Posting Customer: {"username":"ATXpLlnRT","password":"ZyJrk","email":"ATXpLlnRT@gmail.com","firstName":"ATXpLlnRT","lastName":"ATXpLlnRT"}
  08:57:19.213 [front-end] Received response: "{\"firstName\":\"yuarl\",\"lastName\":\"yuarl\",\"username\":\"yuarl\",\"id\":\"674198d8a437380001deffa3\",\"_links\":{\"addresses\":{\"href
  08:57:21.982 [front-end] Order response: {"id":"674198f13f77060008865391","customerId":"674198e0a437380001deffae","customer":{"id":null,"firstName":"aosppOuxRWmZV","lastName":"aosppOuxR
  08:57:24.120 [front-end] Posting Customer: {"username":"zirHsnVSRGlby","password":"SPBpWAPje","email":"zirHsnVSRGlby@gmail.com","firstName":"zirHsnVSRGlby","lastName":"zirHsnVSRGlby"}
  08:57:25.637 [front-end] Order response: {"id":"674198f53f77060008865394","customerId":"674198e1a437380001deffaf","customer":{"id":null,"firstName":"vMOzyvsbIvxTHu","lastName":"vMOzyvsb
  08:57:27.390 [front-end] Order response: {"statusCode":201,"body":{"id":"674198f73f77060008865397","customerId":"674198eaa437380001deffc4","customer":{"id":null,"firstName":"JCYeKSjM","
  08:57:30.058 [front-end] Order response: {"id":"674198fa3f77060008865399","customerId":"674198e7a437380001deffbe","customer":{"id":null,"firstName":"bVfUCqC","lastName":"bVfUCqC","usern
  08:57:30.952 [front-end] Posting Customer: {"username":"YKtzb","password":"PQgwn","email":"YKtzb@gmail.com","firstName":"YKtzb","lastName":"YKtzb"}
  08:57:33.748 [front-end] Received response: "{\"firstName\":\"lKilrPhwmDT\",\"lastName\":\"lKilrPhwmDT\",\"username\":\"lKilrPhwmDT\",\"id\":\"674198eda437380001deffcd\",\"_links\":{\"a
  08:57:35.911 [front-end] Received response: "{\"firstName\":\"tIHtYdIVIc\",\"lastName\":\"tIHtYdIVIc\",\"username\":\"tIHtYdIVIc\",\"id\":\"674198eea437380001deffd7\",\"_links\":{\"addr
  08:57:36.444 [front-end] Received response: "{\"firstName\":\"AdZvMNo\",\"lastName\":\"AdZvMNo\",\"username\":\"AdZvMNo\",\"id\":\"674198f2a437380001deffe1\",\"_links\":{\"addresses\":{
  08:57:36.890 [front-end] Received response: "{\"firstName\":\"RLzoBPdIEDTXQK\",\"lastName\":\"RLzoBPdIEDTXQK\",\"username\":\"RLzoBPdIEDTXQK\",\"id\":\"674198eca437380001deffcb\",\"_lin
  08:57:37.593 [front-end] Order response: {"id":"674199013f770600088653a4","customerId":"674198eea437380001deffd0","customer":{"id":null,"firstName":"XWPQYvKaThmnJm","lastName":"XWPQYvKa

## p0261
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:15.701Z
```
{"timestamp":1732242495701613000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"673fec3fb0df5c00019af986"}
```
Same service, the 2 minutes before (oldest first):
  02:28:14.181 [front-end] User cart deleted with status: 503
  02:28:14.185 [front-end] DELETE /cart 503 - ms - -
  02:28:14.190 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  02:28:14.191 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242494188,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:14.191 [front-end] Order response: {"timestamp":1732242494188,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:14.194 [front-end] POST /orders 500 - ms - -
  02:28:14.197 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  02:28:14.197 [front-end] POST to carts: http://carts/carts/673fec34b0df5c00019af967/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  02:28:14.238 [front-end] POST /cart 500 46.629 ms - 64
  02:28:14.311 [front-end] Posting Customer: {"username":"AIwPgMB","password":"ciKTe","email":"AIwPgMB@gmail.com","firstName":"AIwPgMB","lastName":"AIwPgMB"}
  02:28:14.317 [front-end] { id: '673fec3eb0df5c00019af985' }  (×2)
  02:28:14.317 [front-end] 673fec3eb0df5c00019af985
  02:28:14.317 [front-end] Merging carts for customer id: 673fec3eb0df5c00019af985 and session id: y5_hKG3jcMa48JRLX0HxhdItvM_uuPGj
  02:28:14.337 [front-end] Carts merged.
  02:28:14.337 [front-end] set cookie673fec3eb0df5c00019af985
  02:28:14.337 [front-end] Sent cookies.
  02:28:14.339 [front-end] POST /register 200 27.005 ms - 33
  02:28:15.632 [front-end] GET /catalogue 200 - ms - -
  02:28:15.696 [front-end] Posting Customer: {"username":"NGQZYvsdKz","password":"rioCzg","email":"NGQZYvsdKz@gmail.com","firstName":"NGQZYvsdKz","lastName":"NGQZYvsdKz"}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×41)
  02:28:03.174 [front-end] User cart deleted with status: 503  (×41)
  02:28:03.202 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×42)
  02:28:03.249 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×17)
  02:28:03.410 [front-end] Carts merged.  (×39)
  02:28:04.973 [front-end] Posting Customer: {"username":"HFHBXn","password":"EOgUhihln","email":"HFHBXn@gmail.com","firstName":"HFHBXn","lastName":"HFHBXn"}
  02:28:05.351 [user] ts=2024-11-22T02:28:05.351787827Z caller=middlewares.go:46 method=Register username=vuOxCKL email=vuOxCKL@gmail.com took=4.581531ms
  02:28:08.095 [front-end] Received response: "{\"firstName\":\"RsyjMQXEZqDOIBa\",\"lastName\":\"RsyjMQXEZqDOIBa\",\"username\":\"RsyjMQXEZqDOIBa\",\"id\":\"673fec1eb0df5c00019af912\",\"_
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:15.136 [carts] 2024-11-22 02:28:15.041 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 160.989 seconds (JVM running for 167.0
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:22.317 [front-end] Received response: "{\"firstName\":\"JGQXvUjPbFrtK\",\"lastName\":\"JGQXvUjPbFrtK\",\"username\":\"JGQXvUjPbFrtK\",\"id\":\"673fec34b0df5c00019af964\",\"_links\
  02:28:23.143 [orders] 2024-11-22 02:28:23.143 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×9)
  02:28:24.588 [shipping] Adding shipment to queue...  (×24)
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:26.156 [front-end] POST /cart 201 - ms - -  (×26)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d8","customerId":"673fec2cb0df5c00019af949","customer":{"id":null,"firstName":"KoWsmDtUqsE
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:30.547 [front-end] Received response: "{\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\",\"username\":\"vvgsHcY\",\"id\":\"673fec35b0df5c00019af968\",\"_links\":{\"addresses\":{
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.645 [queue-master] 2024-11-22 02:28:32.645 INFO 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×15)
  02:28:37.005 [user] ts=2024-11-22T02:28:37.005380807Z caller=middlewares.go:46 method=Register username=XTqSaA email=XTqSaA@gmail.com took=624.562µs
  02:28:40.136 [front-end] Order response: {"id":"673fec58d94b9000069b39dc","customerId":"673fec41b0df5c00019af98b","customer":{"id":null,"firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe",
  02:28:41.723 [user] ts=2024-11-22T02:28:41.723279742Z caller=middlewares.go:46 method=Register username=yaELjpCD email=yaELjpCD@gmail.com took=1.302265ms
  02:28:43.812 [front-end] Order response: {"id":"673fec5bd94b9000069b39e0","customerId":"673fec47b0df5c00019af996","customer":{"id":null,"firstName":"bhZuEQ","lastName":"bhZuEQ","usernam
  02:28:45.163 [front-end] Received response: "{\"firstName\":\"oqYeDriHaX\",\"lastName\":\"oqYeDriHaX\",\"username\":\"oqYeDriHaX\",\"id\":\"673fec49b0df5c00019af999\",\"_links\":{\"addr

## p0002
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T00:56:33.716Z
```
{"service":"dbservice1","message":"2021-08-13 00:56:33,716 | ERROR | 0.0.0.4 | dbservice1 | db_helper.py -> db_login_methods -> 62 | {trace_id} | password in database of {user} is null, the user is not registered"}
```
Same service, the 2 minutes before (oldest first):
  00:56:29.920 [dbservice1] INFO 3cfdf9d6-fb8e-11eb-be5b-0242ac110003-sNQUnOaq-YXf&B76#)l(Z token generate success token=MTYyODc4NzM4OS45MTk4NTk6M2NmZGY5ZDYtZmI4ZS0xMWViLWJlNWItMDI0MmFjMTE
  00:56:30.714 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×6)
  00:56:30.715 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×6)
  00:56:30.738 [dbservice1] INFO query = select passwards from username_table where user_name='rydacQUo'  (×4)
  00:56:30.814 [dbservice1] INFO 3d62b592-fb8e-11eb-bee9-0242ac110004-rydacQUo-bx?J>OSr6).& token generate success token=MTYyODc4NzM5MC44MTM3MzQ4OjNkNjJiNTkyLWZiOGUtMTFlYi1iZWU5LTAyNDJhYzE
  00:56:30.826 [dbservice1] INFO 3d793f10-fb8e-11eb-9b36-0242ac110003-edQqtaui-Nyq_U<Q^_uRZ token generate success token=MTYyODc4NzM5MC44MjU3MjIyOjNkNzkzZjEwLWZiOGUtMTFlYi05YjM2LTAyNDJhYzE
  00:56:31.755 [dbservice1] INFO 3e044d76-fb8e-11eb-be05-0242ac110004-IdNORUSj-swS@j6J2Bk%t token generate success token=MTYyODc4NzM5MS43NTUyMjc6M2UwNDRkNzYtZmI4ZS0xMWViLWJlMDUtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  00:56:03.722 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  00:56:03.834 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '2ddc8418-fb8e-11eb-bf04-0242ac110004', 'value': '', 'ex': 10}  (×43)
  00:56:03.961 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×40)
  00:56:04.062 [logservice2] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '2da80d64-fb8e-11eb-960d-0242ac110004', 'user_id': 'RkEDeABl'}  (×83)
  00:56:04.492 [redisservice1] INFO service accept, status_code: 200  (×39)
  00:56:05.120 [dbservice1] INFO 2e2b525a-fb8e-11eb-90fc-0242ac110004-kdncspNK-/mUDr*ZR)9Ls token generate success token=MTYyODc4NzM2NS4xMjA1NjE0OjJlMmI1MjVhLWZiOGUtMTFlYi05MGZjLTAyNDJhYzE
  00:56:06.249 [webservice1] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×40)
  00:56:06.674 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×45)
  00:56:07.583 [dbservice2] INFO 2f8c66ca-fb8e-11eb-94df-0242ac110003-lmvshOqT-%2#uLB3dNKSs token generate success token=MTYyODc4NzM2Ny41ODMxMDY6MmY4YzY2Y2EtZmI4ZS0xMWViLTk0ZGYtMDI0MmFjMTE
  00:56:10.364 [webservice2] ERROR an error occurred in the downstream service
  00:56:12.788 [dbservice1] INFO 32c19c70-fb8e-11eb-9970-0242ac110004-VkjGfAwW-1:P5T_I!BiLK token generate success token=MTYyODc4NzM3Mi43ODgwNTozMmMxOWM3MC1mYjhlLTExZWItOTk3MC0wMjQyYWMxMTA
  00:56:15.204 [dbservice1] INFO 3441dd76-fb8e-11eb-b870-0242ac110003-igXqQZLm-oS})G7plxrgb token generate success token=MTYyODc4NzM3NS4yMDM4MzA1OjM0NDFkZDc2LWZiOGUtMTFlYi1iODcwLTAyNDJhYzE  (×2)
  00:56:18.179 [mobservice1] INFO info 363325fe-fb8e-11eb-af4b-0242ac110003:rtRkpsfM write success
  00:56:20.674 [mobservice1] INFO info 37afc37e-fb8e-11eb-9034-0242ac110003:fFkndIOY write success
  00:56:23.329 [mobservice2] INFO info 394890da-fb8e-11eb-9518-0242ac110003:FjQZnIyb write success
  00:56:25.687 [mobservice2] INFO info 3ab1757c-fb8e-11eb-b24d-0242ac110004:TZitjmpu write success
  00:56:28.007 [mobservice1] INFO info 3c0d9626-fb8e-11eb-b8db-0242ac110004:mcHMEOjb write success
  00:56:30.814 [dbservice1] INFO 3d62b592-fb8e-11eb-bee9-0242ac110004-rydacQUo-bx?J>OSr6).& token generate success token=MTYyODc4NzM5MC44MTM3MzQ4OjNkNjJiNTkyLWZiOGUtMTFlYi1iZWU5LTAyNDJhYzE
  00:56:39.059 [mobservice2] INFO info 42a6e12c-fb8e-11eb-9e68-0242ac110004:FXAevOmb write success
  00:56:42.512 [dbservice2] INFO 445b43c8-fb8e-11eb-bde9-0242ac110003-rxiVPwZL-#kN4x}e6EY-J token generate success token=MTYyODc4NzQwMi41MTE1MjE2OjQ0NWI0M2M4LWZiOGUtMTFlYi1iZGU5LTAyNDJhYzE
  00:56:44.951 [mobservice1] INFO info 4625e032-fb8e-11eb-8519-0242ac110003:GtreMfPE write success
  00:56:47.803 [mobservice2] INFO info 47d3e230-fb8e-11eb-b2fc-0242ac110004:nzYLWZFG write success
  00:56:50.304 [mobservice1] INFO info 4958222e-fb8e-11eb-bd50-0242ac110004:KrEDTxFN write success
  00:56:52.615 [mobservice1] INFO info 4abdd76c-fb8e-11eb-bbc4-0242ac110003:EJMXPwRO write success
  00:56:55.124 [mobservice2] INFO info 4c3c6ba8-fb8e-11eb-b913-0242ac110003:FKekGBJU write success
  00:56:57.672 [mobservice1] INFO info 4dbf6d22-fb8e-11eb-817c-0242ac110003:pGnBPZOX write success
  00:57:01.163 [mobservice1] INFO info 4fcd2208-fb8e-11eb-9c2b-0242ac110003:ORjBsXZy write success

## p0211
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service shippingservice, 2024-11-18T07:40:15.123Z
```
{"timestamp":1731915615123979800,"container_name":"shippingservice","pod_name":"shippingservice-547ddf469c-vjbwz","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"[GetQuote] completed request"}
```
Same service, the 2 minutes before (oldest first):
  07:40:06.960 [shippingservice] [GetQuote] completed request  (×9)
  07:40:06.987 [shippingservice] [GetQuote] received request  (×9)
  07:40:06.996 [shippingservice] [ShipOrder] received request
  07:40:06.996 [shippingservice] [ShipOrder] completed request
All services, 30 seconds either side (sampled):
  07:39:52.000 [cartservice] GetCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×249)
  07:39:52.024 [adservice] received ad request (context_words=[accessories])  (×34)
  07:39:52.029 [frontend] adding to cart  (×40)
  07:39:52.043 [currencyservice] Getting supported currencies...  (×248)
  07:39:52.283 [frontend] serving product page  (×143)
  07:39:52.973 [adservice] received ad request (context_words=[kitchen])  (×56)
  07:39:53.236 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"504","nanos":190000000},"credit_card":{"credit_card_number":"41250039999184  (×2)
  07:39:53.240 [shippingservice] [ShipOrder] received request  (×10)
  07:39:53.250 [emailservice] A request to send order confirmation email to thomas49@example.org has been received.
  07:39:54.637 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', 'L9ECAV7KIM', '66VCHSJNUP', '2ZYFJ3GM2N']  (×10)
  07:39:55.516 [adservice] received ad request (context_words=[])  (×27)
  07:39:59.923 [frontend] setting currency  (×16)
  07:40:02.310 [paymentservice] Transaction processed: visa ending 2430 Amount: EUR366.404245918  (×2)
  07:40:02.812 [emailservice] A request to send order confirmation email to calvinmoore@example.org has been received.
  07:40:03.039 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"97","nanos":410089340},"credit_card":{"credit_card_number":"442775504324461  (×2)
  07:40:03.052 [checkoutservice] order confirmation email sent to "christopherjackson@example.net"
  07:40:06.993 [paymentservice] Transaction processed: visa ending 4598 Amount: JPY13744.672269244  (×2)
  07:40:18.508 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="GBP"  (×2)
  07:40:18.568 [emailservice] A request to send order confirmation email to martin51@example.net has been received.
  07:40:24.448 [checkoutservice] order confirmation email sent to "stevenortiz@example.net"
  07:40:38.182 [emailservice] A request to send order confirmation email to uwashington@example.com has been received.
  07:40:40.769 [checkoutservice] order confirmation email sent to "barrettmichael@example.net"

## p0627
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-07T20:17:55.260Z
```
{"timestamp":1733602675260628000,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-9ll65","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:17:55.260  INFO 1 --- [           main] o.s.s.web.DefaultSecurityFilterChain     : Creating filter chain: org.springframework.security.web.util.matcher.AnyRequestMatcher@1, [org.springframework.security.web.context.request.async.WebAsyncManagerIntegrationFilter@681b42d3, org.springframework.security.web.context.SecurityContextPersistenceFilter@4738131e, org.springframework.security.w…"}
```
Same service, the 2 minutes before (oldest first):
  20:17:51.174 [ts-route-service] 2024-12-07 20:17:51.174 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  20:17:52.757 [ts-route-service] 2024-12-07 20:17:52.757 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  20:17:52.758 [ts-route-service] 2024-12-07 20:17:52.757 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics || /metrics.json],methods=[GET],produces=[application/vnd.s
  20:17:52.758 [ts-route-service] 2024-12-07 20:17:52.758 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[application/vnd.sprin
  20:17:52.759 [ts-route-service] 2024-12-07 20:17:52.759 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/vnd.spring-
  20:17:52.759 [ts-route-service] 2024-12-07 20:17:52.759 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[application/vnd.sprin
  20:17:52.760 [ts-route-service] 2024-12-07 20:17:52.760 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  20:17:52.761 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  20:17:52.761 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[POST],consumes=[application/vnd.spring-
  20:17:52.761 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  20:17:52.762 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/auditevents || /auditevents.json],methods=[GET],produces=[applicati
  20:17:52.762 [ts-route-service] 2024-12-07 20:17:52.762 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/vnd.spring-
  20:17:52.764 [ts-route-service] 2024-12-07 20:17:52.763 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[application/vnd
  20:17:52.764 [ts-route-service] 2024-12-07 20:17:52.763 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces=[applicati
  20:17:52.764 [ts-route-service] 2024-12-07 20:17:52.764 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
  20:17:52.765 [ts-route-service] 2024-12-07 20:17:52.764 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  20:17:52.765 [ts-route-service] 2024-12-07 20:17:52.765 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/vnd.spring-boot.
  20:17:52.765 [ts-route-service] 2024-12-07 20:17:52.765 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/vnd.spring-bo
  20:17:53.867 [ts-route-service] 2024-12-07 20:17:53.867 INFO 1 --- [ main] b.a.s.AuthenticationManagerConfiguration : 
  20:17:53.867 [ts-route-service] Using default security password: 9bebfd9a-81f1-4fdd-85bc-a832c9aa13e3 
All services, 30 seconds either side (sampled):
  20:17:25.266 [ts-route-service] 2024-12-07 20:17:25.265 INFO 1 --- [ main] ationConfigEmbeddedWebApplicationContext : Refreshing org.springframework.boot.context.embedded.AnnotationConfigEmbed
  20:17:25.616 [ts-travel2-service] 2024-12-07 20:17:25.616 ERROR 1 --- [io-16346-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×6)
  20:17:27.209 [ts-travel-service] 2024-12-07 20:17:27.209 ERROR 1 --- [o-12346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  20:17:28.493 [ts-config-mongo] {"t":{"$date":"2024-12-07T20:17:28.493+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360264
  20:17:29.780 [ts-auth-service] 2024-12-07 20:17:29.779 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×3)
  20:17:31.595 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T20:17:31.595+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360265
  20:17:35.723 [ts-basic-service] 2024-12-07 20:17:35.723 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×2)
  20:17:36.472 [ts-inside-payment-service] 2024-12-07 20:17:36.471 INFO 1 --- [io-18673-exec-6] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.  (×2)
  20:17:38.748 [ts-food-service] 2024-12-07 20:17:38.748 INFO 1 --- [io-18856-exec-5] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345
  20:17:41.268 [ts-route-service] 2024-12-07 20:17:41.268 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] .s.DelegatingFilterProxyRegistrationBean : Mapping filter: 'springSecurityFilterChain' to: [/*]
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.165 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{startId}/{terminalId}],methods=[GET
  20:17:51.174 [ts-route-service] 2024-12-07 20:17:51.174 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  20:17:52.762 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/auditevents || /auditevents.json],methods=[GET],produces=[applicati
  20:17:53.879 [ts-travel2-service] 2024-12-07 20:17:53.878 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  20:17:59.260 [ts-route-service] 2024-12-07 20:17:59.260 INFO 1 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 'taskScheduler'
  20:18:03.064 [ts-route-service] 2024-12-07 20:18:03.064 INFO 1 --- [ main] .d.s.w.r.o.CachingOperationNameGenerator : Generating unique operation named: valueUsingGET_1
  20:18:04.564 [ts-route-service] 2024-12-07 20:18:04.563 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: shanghai End: suzhou
  20:18:10.173 [ts-travel-service] 2024-12-07 20:18:10.173 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×8)
  20:18:11.753 [ts-basic-service] 2024-12-07 20:18:11.752 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×4)
  20:18:11.807 [ts-basic-service] 2024-12-07 20:18:11.807 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4  (×7)
  20:18:11.910 [ts-travel2-service] 2024-12-07 20:18:11.909 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  20:18:11.988 [ts-seat-service] 2024-12-07 20:18:11.988 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×7)
  20:18:15.168 [ts-price-service] 2024-12-07 20:18:15.168 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: 0b23bd3e-876a-4af3-b92
  20:18:21.301 [ts-basic-service] 2024-12-07 20:18:21.301 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×2)
  20:18:22.755 [ts-order-service] 2024-12-07 20:18:22.755 INFO 1 --- [io-12031-exec-5] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×3)
  20:18:22.880 [ts-seat-service] 2024-12-07 20:18:22.880 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×5)
  20:18:23.518 [ts-seat-service] 2024-12-07 20:18:23.518 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da

## p0373
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:40:18.014Z
```
{"timestamp":1732246818014614500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Sent cookies."}
```
Same service, the 2 minutes before (oldest first):
  03:40:17.352 [front-end] Order response: {"id":"673ffd21d94b9000069b470f","customerId":"673ffd07b0df5c00019b2ccf","customer":{"id":null,"firstName":"vCGHpFRUybWtRGK","lastName":"vCGHpFR
  03:40:17.354 [front-end] POST /orders 201 - ms - -
  03:40:17.387 [front-end] Attempting to delete cart for user: 673ffd1bb0df5c00019b2d08  (×2)
  03:40:17.406 [front-end] User cart deleted with status: 202
  03:40:17.408 [front-end] DELETE /cart 202 - ms - -
  03:40:17.414 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  03:40:17.420 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  03:40:17.420 [front-end] POST to carts: http://carts/carts/673ffd1bb0df5c00019b2d08/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  03:40:17.461 [front-end] POST /cart 201 - ms - -
  03:40:17.930 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffd1bb0df5c00019b2d0c"}
  03:40:17.940 [front-end] POST /addresses 200 - ms - -
  03:40:17.944 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffd1bb0df5c00019b2d0c"}
  03:40:17.952 [front-end] POST /cards 200 - ms - -
  03:40:17.985 [front-end] Posting Customer: {"username":"uEjMG","password":"jdieKAmf","email":"uEjMG@gmail.com","firstName":"uEjMG","lastName":"uEjMG"}
  03:40:17.991 [front-end] { id: '673ffd21b0df5c00019b2d21' }
  03:40:17.991 [front-end] 673ffd21b0df5c00019b2d21
  03:40:17.991 [front-end] Merging carts for customer id: 673ffd21b0df5c00019b2d21 and session id: 9cmQ27R1HLxSG_RW70UPuc5XB6OBP5eE
  03:40:18.014 [front-end] Carts merged.
  03:40:18.014 [front-end] set cookie673ffd21b0df5c00019b2d21
All services, 30 seconds either side (sampled):
  03:39:48.065 [front-end] Posting Customer: {"username":"mPuVOQmhX","password":"QIlSTAZ","email":"mPuVOQmhX@gmail.com","firstName":"mPuVOQmhX","lastName":"mPuVOQmhX"}
  03:39:48.825 [user] ts=2024-11-22T03:39:48.824806439Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffcfab0df5c00019b2caa took=1.662214ms  (×63)
  03:39:48.898 [front-end] Posting Order: {"customer":"http://user/customers/673ffcf1b0df5c00019b2c85","address":"http://user/addresses/673ffcf6b0df5c00019b2c98","card":"http://user/cards  (×64)
  03:39:48.928 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd04d94b9000069b46f4","customerId":"673ffcf1b0df5c00019b2c85","customer":{"id":null,"firstName":"uFHUUyeMisf
  03:39:49.005 [front-end] POST /cart 201 - ms - -  (×63)
  03:39:49.391 [orders] 2024-11-22 03:39:49.390 INFO [orders,4e4bafbecc26ee54,dca3b90d4c651e07,false] 6 --- [p-nio-80-exec-8] w.w.s.o.controllers.OrdersController : Sending payment req  (×38)
  03:39:50.454 [user] ts=2024-11-22T03:39:50.454567893Z caller=middlewares.go:46 method=Register username=jqPTxwV email=jqPTxwV@gmail.com took=923.101µs
  03:39:51.275 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd07d94b9000069b46f9","customerId":"673ffcefb0df5c00019b2c78","customer":{"id":null,"firstName":"qyVjNErSePb
  03:39:54.827 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd0ad94b9000069b46fa","customerId":"673ffcf4b0df5c00019b2c8f","customer":{"id":null,"firstName":"qvCSr","las
  03:39:55.554 [front-end] Order response: {"id":"673ffd0bd94b9000069b46fd","customerId":"673ffcf8b0df5c00019b2ca1","customer":{"id":null,"firstName":"rLwDuBKyZQy","lastName":"rLwDuBKyZQy
  03:39:57.880 [user] ts=2024-11-22T03:39:57.879948791Z caller=middlewares.go:46 method=Register username=yMWWcvvG email=yMWWcvvG@gmail.com took=1.023565ms
  03:40:01.877 [front-end] Posting Customer: {"username":"EFklGacZxjzz","password":"gNxkgRTD","email":"EFklGacZxjzz@gmail.com","firstName":"EFklGacZxjzz","lastName":"EFklGacZxjzz"}
  03:40:06.348 [front-end] Received response: "{\"firstName\":\"mPuVOQmhX\",\"lastName\":\"mPuVOQmhX\",\"username\":\"mPuVOQmhX\",\"id\":\"673ffd04b0df5c00019b2cc1\",\"_links\":{\"address
  03:40:07.888 [front-end] Posting Customer: {"username":"ATwKbWTcsCqqS","password":"uOBIpTYbZ","email":"ATwKbWTcsCqqS@gmail.com","firstName":"ATwKbWTcsCqqS","lastName":"ATwKbWTcsCqqS"}
  03:40:11.325 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd1bd94b9000069b4708","customerId":"673ffd06b0df5c00019b2cca","customer":{"id":null,"firstName":"BVqtXsnZoCH
  03:40:13.652 [front-end] Posting Customer: {"username":"QnDvKst","password":"AKdTcI","email":"QnDvKst@gmail.com","firstName":"QnDvKst","lastName":"QnDvKst"}
  03:40:15.689 [front-end] Received response: "{\"firstName\":\"mAjObwVc\",\"lastName\":\"mAjObwVc\",\"username\":\"mAjObwVc\",\"id\":\"673ffd07b0df5c00019b2cd2\",\"_links\":{\"addresses\
  03:40:17.989 [user] ts=2024-11-22T03:40:17.989239101Z caller=middlewares.go:46 method=Register username=uEjMG email=uEjMG@gmail.com took=1.026428ms
  03:40:20.258 [front-end] Order response: {"id":"673ffd24d94b9000069b4712","customerId":"673ffd11b0df5c00019b2cef","customer":{"id":null,"firstName":"eFXKRBDSOz","lastName":"eFXKRBDSOz",
  03:40:22.439 [front-end] Posting Customer: {"username":"SNIlDHpOzLhr","password":"oLgrtcKg","email":"SNIlDHpOzLhr@gmail.com","firstName":"SNIlDHpOzLhr","lastName":"SNIlDHpOzLhr"}
  03:40:24.566 [front-end] Posting Customer: {"username":"LiUKqRolHOayhli","password":"nmlMfrbCIv","email":"LiUKqRolHOayhli@gmail.com","firstName":"LiUKqRolHOayhli","lastName":"LiUKqRolHO
  03:40:26.017 [front-end] Posting Customer: {"username":"eMXUOVxDhpbzu","password":"YFzcAPU","email":"eMXUOVxDhpbzu@gmail.com","firstName":"eMXUOVxDhpbzu","lastName":"eMXUOVxDhpbzu"}
  03:40:29.128 [front-end] Posting Customer: {"username":"oHfjirgMCgcG","password":"HqxrPxrN","email":"oHfjirgMCgcG@gmail.com","firstName":"oHfjirgMCgcG","lastName":"oHfjirgMCgcG"}
  03:40:33.518 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd31d94b9000069b471d","customerId":"673ffd1bb0df5c00019b2d08","customer":{"id":null,"firstName":"ZuGaeYeAVpk
  03:40:35.855 [front-end] Received response: "{\"firstName\":\"QnDvKst\",\"lastName\":\"QnDvKst\",\"username\":\"QnDvKst\",\"id\":\"673ffd1db0df5c00019b2d13\",\"_links\":{\"addresses\":{
  03:40:38.302 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd36d94b9000069b4723","customerId":"673ffd2ab0df5c00019b2d38","customer":{"id":null,"firstName":"eMXUOVxDhpb
  03:40:40.573 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd38d94b9000069b4726","customerId":"673ffd29b0df5c00019b2d36","customer":{"id":null,"firstName":"sMpzhVgfV",
  03:40:42.299 [front-end] Received response: "{\"firstName\":\"PGPIwyszxVn\",\"lastName\":\"PGPIwyszxVn\",\"username\":\"PGPIwyszxVn\",\"id\":\"673ffd1fb0df5c00019b2d18\",\"_links\":{\"a
  03:40:43.694 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd3bd94b9000069b472b","customerId":"673ffd29b0df5c00019b2d37","customer":{"id":null,"firstName":"ZhKUJWe","l
  03:40:46.759 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd3ed94b9000069b472e","customerId":"673ffd26b0df5c00019b2d2c","customer":{"id":null,"firstName":"SNIlDHpOzLh

## p0331
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:21:10.643Z
```
{"timestamp":1732245670643420000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Address: {\"number\":\"123\",\"street\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"country\":\"123\",\"userID\":\"673ff89eb0df5c00019b1f58\"}"}
```
Same service, the 2 minutes before (oldest first):
  03:21:10.260 [front-end] DELETE /cart 503 - ms - -
  03:21:10.266 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  03:21:10.274 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  03:21:10.274 [front-end] POST to carts: http://carts/carts/673ff89db0df5c00019b1f52/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  03:21:10.326 [front-end] POST /cart 500 56.463 ms - 64
  03:21:10.475 [front-end] Request received with body: {}
  03:21:10.483 [front-end] Received response: "{\"firstName\":\"cqPFUedoarsUCI\",\"lastName\":\"cqPFUedoarsUCI\",\"username\":\"cqPFUedoarsUCI\",\"id\":\"673ff893b0df5c00019b1f2e\",\"_lin
  03:21:10.483 [front-end] GET Request to: http://user/customers/673ff893b0df5c00019b1f2e/addresses  (×2)
  03:21:10.489 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:21:10.489 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff899b0df5c00019b1f43\",\"_links\":{\"
  03:21:10.489 [front-end] [ undefined, undefined ]
  03:21:10.489 [front-end] Posting Order: {"customer":"http://user/customers/673ff893b0df5c00019b1f2e","address":"http://user/addresses/673ff899b0df5c00019b1f42","card":"http://user/cards
  03:21:10.526 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245670524,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:21:10.526 [front-end] Order response: {"timestamp":1732245670524,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:21:10.529 [front-end] POST /orders 500 - ms - -
  03:21:10.585 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff89fb0df5c00019b1f5d"}
  03:21:10.592 [front-end] POST /addresses 200 - ms - -
  03:21:10.598 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff89fb0df5c00019b1f5d"}
  03:21:10.605 [front-end] POST /cards 200 - ms - -
All services, 30 seconds either side (sampled):
  03:20:40.843 [payment] ts=2024-11-22T03:20:40Z caller=logging.go:40 method=Health result=1 took=6.863µs  (×40)
  03:20:41.044 [front-end] POST to carts: http://carts/carts/673ff87eb0df5c00019b1f00/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}  (×32)
  03:20:41.228 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×24)
  03:20:41.536 [front-end] Sent cookies.  (×58)
  03:20:43.384 [carts] 2024-11-22 03:20:43.383 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  03:20:46.355 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×8)
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springfram
  03:20:54.094 [user] ts=2024-11-22T03:20:54.094603184Z caller=middlewares.go:157 method=Health result=2 took=1.192662ms  (×6)
  03:20:56.904 [front-end] Received response: "{\"firstName\":\"pPOWMtcwKJaePCn\",\"lastName\":\"pPOWMtcwKJaePCn\",\"username\":\"pPOWMtcwKJaePCn\",\"id\":\"673ff87fb0df5c00019b1f03\",\"_
  03:20:59.688 [carts] 2024-11-22 03:20:59.688 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[OPTIONS],produces=[applica
  03:20:59.786 [carts] 2024-11-22 03:20:59.786 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT ||
  03:20:59.887 [carts] 2024-11-22 03:20:59.887 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[text/html]}" onto public 
  03:21:03.048 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×6)
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  03:21:06.274 [front-end] Received response: "{\"firstName\":\"WwpBLC\",\"lastName\":\"WwpBLC\",\"username\":\"WwpBLC\",\"id\":\"673ff885b0df5c00019b1f10\",\"_links\":{\"addresses\":{\"h
  03:21:09.238 [front-end] Posting Customer: {"username":"pMqcnDbPZ","password":"kxLei","email":"pMqcnDbPZ@gmail.com","firstName":"pMqcnDbPZ","lastName":"pMqcnDbPZ"}
  03:21:12.194 [front-end] Posting Customer: {"username":"yXmVwShR","password":"JrCRXcAWLQ","email":"yXmVwShR@gmail.com","firstName":"yXmVwShR","lastName":"yXmVwShR"}
  03:21:14.190 [carts] 2024-11-22 03:21:14.190 INFO [carts,,,] 7 --- [p-nio-80-exec-3] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization complet
  03:21:16.388 [carts] 2024-11-22 03:21:16.294 INFO [carts,4f4200e92a2346f2,c605b8bba205809d,false] 7 --- [-nio-80-exec-10] org.mongodb.driver.connection : Opened connection [connecti  (×8)
  03:21:18.602 [orders] 2024-11-22 03:21:18.602 INFO [orders,40393c2387463fc4,20a8cb1f4ece78de,false] 6 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Received payment re  (×19)
  03:21:18.708 [front-end] Order response: {"id":"673ff8aed94b9000069b438d","customerId":"673ff891b0df5c00019b1f2a","customer":{"id":null,"firstName":"asYAoymkBkzj","lastName":"asYAoymkBk
  03:21:19.450 [front-end] Received response: "{\"firstName\":\"gKGbBfBuFal\",\"lastName\":\"gKGbBfBuFal\",\"username\":\"gKGbBfBuFal\",\"id\":\"673ff89eb0df5c00019b1f54\",\"_links\":{\"a
  03:21:20.103 [front-end] Order response: {"id":"673ff8b0d94b9000069b4394","customerId":"673ff899b0df5c00019b1f44","customer":{"id":null,"firstName":"fnNnBGFeZwjz","lastName":"fnNnBGFeZw
  03:21:20.805 [front-end] Order response: {"id":"673ff8b0d94b9000069b4398","customerId":"673ff897b0df5c00019b1f3d","customer":{"id":null,"firstName":"PvCLeeg","lastName":"PvCLeeg","usern
  03:21:24.101 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b4d94b9000069b439b","customerId":"673ff89eb0df5c00019b1f57","customer":{"id":null,"firstName":"UFhesIA","l
  03:21:28.398 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732245688395,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde
  03:21:33.987 [user] ts=2024-11-22T03:21:33.987218895Z caller=middlewares.go:46 method=Register username=sYvdDM email=sYvdDM@gmail.com took=1.011607ms
  03:21:34.809 [front-end] Order response: {"id":"673ff8bed94b9000069b43a1","customerId":"673ff8abb0df5c00019b1f8e","customer":{"id":null,"firstName":"eSafJJOuc","lastName":"eSafJJOuc","u
  03:21:37.220 [front-end] Received response: "{\"firstName\":\"YOkVqshziuS\",\"lastName\":\"YOkVqshziuS\",\"username\":\"YOkVqshziuS\",\"id\":\"673ff8a2b0df5c00019b1f6f\",\"_links\":{\"a
  03:21:40.219 [front-end] Received response: "{\"firstName\":\"pMqcnDbPZ\",\"lastName\":\"pMqcnDbPZ\",\"username\":\"pMqcnDbPZ\",\"id\":\"673ff8a5b0df5c00019b1f74\",\"_links\":{\"address

## p0561
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T18:29:43.974Z
```
{"timestamp":1733596183974310100,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-894nw","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:29:43.974  INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl         : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[shanghai, suzhou], distances=[0, 50], startStationId='shanghai', terminalStationId='suzhou'}"}
```
Same service, the 2 minutes before (oldest first):
  18:29:40.658 [ts-travel-service] 2024-12-07 18:29:40.658 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  18:29:40.658 [ts-travel-service] 2024-12-07 18:29:40.658 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha
  18:29:42.692 [ts-travel-service] 2024-12-07 18:29:42.692 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×6)
  18:29:42.698 [ts-travel-service] 2024-12-07 18:29:42.698 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  18:29:42.698 [ts-travel-service] 2024-12-07 18:29:42.698 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×3)
  18:29:42.716 [ts-travel-service] 2024-12-07 18:29:42.715 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
  18:29:42.739 [ts-travel-service] 2024-12-07 18:29:42.738 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
  18:29:42.758 [ts-travel-service] 2024-12-07 18:29:42.758 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5
  18:29:42.758 [ts-travel-service] 2024-12-07 18:29:42.758 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  18:29:42.771 [ts-travel-service] 2024-12-07 18:29:42.770 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×2)
  18:29:42.771 [ts-travel-service] 2024-12-07 18:29:42.771 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha
  18:29:43.965 [ts-travel-service] 2024-12-07 18:29:43.965 INFO 1 --- [io-12346-exec-5] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
All services, 30 seconds either side (sampled):
  18:29:13.980 [ts-admin-basic-info-service] 2024-12-07 18:29:13.980 INFO 1 --- [io-18767-exec-9] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×14)
  18:29:16.062 [ts-auth-service] 2024-12-07 18:29:16.062 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×4)
  18:29:16.117 [ts-travel2-service] 2024-12-07 18:29:16.117 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×122)
  18:29:16.156 [ts-price-service] 2024-12-07 18:29:16.155 INFO 1 --- [io-16579-exec-5] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: 0b23bd3e-876a-4af3-b92  (×13)
  18:29:16.178 [ts-order-other-service] 2024-12-07 18:29:16.177 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×10)
  18:29:16.257 [ts-travel2-service] 2024-12-07 18:29:16.257 INFO 1 --- [io-16346-exec-3] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234  (×22)
  18:29:16.291 [ts-seat-service] 2024-12-07 18:29:16.291 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×13)
  18:29:18.285 [ts-admin-basic-info-service] 2024-12-07 18:29:18.285 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×3)
  18:29:21.567 [ts-consign-service] 2024-12-07 18:29:21.567 INFO 1 --- [io-16111-exec-7] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] 8dd69ea3-886d-40b6-8b7f-  (×2)
  18:29:21.897 [ts-auth-service] 2024-12-07 18:29:21.897 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×10)
  18:29:22.111 [ts-travel-service] 2024-12-07 18:29:22.111 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×45)
  18:29:22.193 [ts-travel-service] 2024-12-07 18:29:22.193 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×15)
  18:29:25.478 [ts-order-other-service] 2024-12-07 18:29:25.477 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×2)
  18:29:25.866 [ts-seat-service] 2024-12-07 18:29:25.866 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  18:29:27.024 [ts-food-service] 2024-12-07 18:29:27.024 INFO 1 --- [io-18856-exec-9] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×4)
  18:29:27.386 [ts-travel-mongo] {"t":{"$date":"2024-12-07T18:29:27.386+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359616
  18:29:27.784 [ts-travel-service] 2024-12-07 18:29:27.783 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×7)
  18:29:27.856 [ts-order-service] 2024-12-07 18:29:27.856 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×3)
  18:29:27.917 [ts-order-service] 2024-12-07 18:29:27.917 INFO 1 --- [io-12031-exec-7] order.service.OrderServiceImpl : Left ticket info is empty  (×5)
  18:29:28.189 [ts-order-service] 2024-12-07 18:29:28.189 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is empty
  18:29:29.872 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T18:29:29.872+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359616
  18:29:30.708 [ts-notification-mongo] {"t":{"$date":"2024-12-07T18:29:30.707+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359617
  18:29:33.389 [ts-seat-service] 2024-12-07 18:29:33.388 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×2)
  18:29:36.583 [ts-basic-service] 2024-12-07 18:29:36.583 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×3)
  18:29:38.437 [ts-order-service] 2024-12-07 18:29:38.437 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Query Order][Step 1] Get Orders Number of Account: 41
  18:29:40.658 [ts-travel-service] 2024-12-07 18:29:40.658 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha
  18:29:47.962 [ts-admin-travel-service] 2024-12-07 18:29:47.962 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)
  18:30:02.500 [ts-travel2-service] 2024-12-07 18:30:02.500 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  18:30:09.540 [ts-inside-payment-service] 2024-12-07 18:30:09.540 INFO 1 --- [io-18673-exec-7] i.controller.InsidePaymentController : [Inside Payment Service][Pay] Pay for: 1f1f879c-bbef-4b89-9eba-bb52c

## p0497
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service payment, 2024-11-23T09:11:33.736Z
```
{"timestamp":1732353093736815900,"container_name":"payment","pod_name":"payment-78bf948dc4-mbtwc","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:11:33Z caller=logging.go:40 method=Health result=1 took=6.841µs"}
```
Same service, the 2 minutes before (oldest first):
  09:11:03.737 [payment] ts=2024-11-23T09:11:03Z caller=logging.go:40 method=Health result=1 took=7.464µs  (×20)
All services, 30 seconds either side (sampled):
  09:11:03.737 [payment] ts=2024-11-23T09:11:03Z caller=logging.go:40 method=Health result=1 took=7.464µs  (×39)
  09:11:04.732 [carts] 2024-11-23 09:11:04.732 INFO [carts,56747577e495e84a,12f684b0e5c6feb4,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×29)
  09:11:04.928 [front-end] Received response: "{\"firstName\":\"otQQYT\",\"lastName\":\"otQQYT\",\"username\":\"otQQYT\",\"id\":\"67419c11a437380001df0998\",\"_links\":{\"addresses\":{\"h
  09:11:04.954 [orders] Caused by: com.fasterxml.jackson.databind.JsonMappingException: Conflicting setter definitions for property "items": works.weave.socks.orders.entities.CustomerO  (×62)
  09:11:05.676 [front-end] Received response: "{\"firstName\":\"YnqJcMupDE\",\"lastName\":\"YnqJcMupDE\",\"username\":\"YnqJcMupDE\",\"id\":\"67419c18a437380001df09b7\",\"_links\":{\"addr
  09:11:06.349 [front-end] User cart deleted with status: 202  (×59)
  09:11:06.394 [carts] 2024-11-23 09:11:06.393 INFO [carts,4aad5e32e78449b6,aadc0f8a53aafa36,false] 7 --- [-nio-80-exec-18] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×34)
  09:11:09.218 [front-end] Received response: "{\"firstName\":\"JuJgbb\",\"lastName\":\"JuJgbb\",\"username\":\"JuJgbb\",\"id\":\"67419c11a437380001df099b\",\"_links\":{\"addresses\":{\"h
  09:11:10.187 [carts] 2024-11-23 09:11:10.186 INFO [carts,e1b2a03e21d11def,22734928e8a88482,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.controllers.ItemsController : Did not find item.  (×25)
  09:11:12.451 [front-end] Received response: "{\"firstName\":\"rebXy\",\"lastName\":\"rebXy\",\"username\":\"rebXy\",\"id\":\"67419c20a437380001df09cd\",\"_links\":{\"addresses\":{\"href
  09:11:15.491 [front-end] Received response: "{\"firstName\":\"ZtITZPSAjyw\",\"lastName\":\"ZtITZPSAjyw\",\"username\":\"ZtITZPSAjyw\",\"id\":\"67419c21a437380001df09d2\",\"_links\":{\"a
  09:11:17.897 [front-end] Received response: "{\"firstName\":\"mryGvonx\",\"lastName\":\"mryGvonx\",\"username\":\"mryGvonx\",\"id\":\"67419c20a437380001df09cf\",\"_links\":{\"addresses\
  09:11:20.512 [user] ts=2024-11-23T09:11:20.512154662Z caller=middlewares.go:46 method=Register username=GXtsuwtMC email=GXtsuwtMC@gmail.com took=2.570799ms
  09:11:23.626 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×5)
  09:11:25.698 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  09:11:27.598 [front-end] Posting Customer: {"username":"VNuABAFIAsscswn","password":"bwUnXD","email":"VNuABAFIAsscswn@gmail.com","firstName":"VNuABAFIAsscswn","lastName":"VNuABAFIAsscsw
  09:11:30.521 [front-end] Posting Customer: {"username":"uJUSIJZmGwWu","password":"urNyY","email":"uJUSIJZmGwWu@gmail.com","firstName":"uJUSIJZmGwWu","lastName":"uJUSIJZmGwWu"}
  09:11:32.187 [session-db] 1:M 23 Nov 2024 09:11:32.187 * Background saving terminated with success
  09:11:33.707 [front-end] Posting Customer: {"username":"CpcEBxjmgyYD","password":"WYeLaXTS","email":"CpcEBxjmgyYD@gmail.com","firstName":"CpcEBxjmgyYD","lastName":"CpcEBxjmgyYD"}
  09:11:37.450 [front-end] Received response: "{\"firstName\":\"JVtYXBYH\",\"lastName\":\"JVtYXBYH\",\"username\":\"JVtYXBYH\",\"id\":\"67419c39a437380001df0a13\",\"_links\":{\"addresses\
  09:11:41.401 [front-end] Received response: "{\"firstName\":\"ClSgJsj\",\"lastName\":\"ClSgJsj\",\"username\":\"ClSgJsj\",\"id\":\"67419c3ca437380001df0a20\",\"_links\":{\"addresses\":{
  09:11:45.562 [front-end] Posting Customer: {"username":"aZFijWZP","password":"ApZKODImu","email":"aZFijWZP@gmail.com","firstName":"aZFijWZP","lastName":"aZFijWZP"}
  09:11:47.380 [front-end] Received response: "{\"firstName\":\"XmZvdQ\",\"lastName\":\"XmZvdQ\",\"username\":\"XmZvdQ\",\"id\":\"67419c3ea437380001df0a25\",\"_links\":{\"addresses\":{\"h
  09:11:50.814 [front-end] Received response: "{\"firstName\":\"VNuABAFIAsscswn\",\"lastName\":\"VNuABAFIAsscswn\",\"username\":\"VNuABAFIAsscswn\",\"id\":\"67419c3fa437380001df0a2b\",\"_
  09:11:54.070 [front-end] Received response: "{\"firstName\":\"CEoQrTAJXAByo\",\"lastName\":\"CEoQrTAJXAByo\",\"username\":\"CEoQrTAJXAByo\",\"id\":\"67419c4aa437380001df0a55\",\"_links\
  09:11:58.178 [front-end] Received response: "{\"firstName\":\"UGKypaKxJraOJEY\",\"lastName\":\"UGKypaKxJraOJEY\",\"username\":\"UGKypaKxJraOJEY\",\"id\":\"67419c4ea437380001df0a61\",\"_
  09:12:00.092 [front-end] Received response: "{\"firstName\":\"zeJrRdGTkTvZZmM\",\"lastName\":\"zeJrRdGTkTvZZmM\",\"username\":\"zeJrRdGTkTvZZmM\",\"id\":\"67419c45a437380001df0a46\",\"_

## p0794
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-08T08:39:45.503Z
```
{"timestamp":1733647185503006000,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-54fv6","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-08 08:39:45.502  INFO 1 --- [io-16346-exec-6] travel2.controller.Travel2Controller     : [Travel Service] Query TripResponse"}
```
Same service, the 2 minutes before (oldest first):
  08:39:41.671 [ts-travel2-service] 2024-12-08 08:39:41.671 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×10)
  08:39:41.676 [ts-travel2-service] 2024-12-08 08:39:41.676 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×10)
All services, 30 seconds either side (sampled):
  08:39:15.512 [ts-basic-service] 2024-12-08 08:39:15.512 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×83)
  08:39:15.543 [ts-seat-service] 2024-12-08 08:39:15.543 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×27)
  08:39:15.614 [ts-travel2-service] 2024-12-08 08:39:15.614 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×15)
  08:39:15.662 [ts-travel2-service] 2024-12-08 08:39:15.662 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×28)
  08:39:16.043 [ts-basic-service] 2024-12-08 08:39:16.043 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×23)
  08:39:16.079 [ts-basic-service] 2024-12-08 08:39:16.079 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4  (×21)
  08:39:16.369 [ts-auth-service] 2024-12-08 08:39:16.368 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : 4c7ef37c-e8cb-4d29-aaca-62bd7a8da985 USER ID  (×20)
  08:39:16.459 [ts-travel-service] 2024-12-08 08:39:16.459 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×20)
  08:39:20.580 [ts-basic-service] 2024-12-08 08:39:20.580 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×7)
  08:39:24.913 [ts-consign-service] 2024-12-08 08:39:24.912 INFO 1 --- [io-16111-exec-1] consign.service.ConsignServiceImpl : [Consign servie] [ Update consign record]
  08:39:25.575 [ts-order-other-service] 2024-12-08 08:39:25.574 INFO 1 --- [io-12032-exec-5] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 35  (×2)
  08:39:29.176 [ts-seat-service] 2024-12-08 08:39:29.175 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  08:39:34.517 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:39:34 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 5017 "-" "Mozilla/5.0 (Macintosh;  (×4)
  08:39:41.612 [ts-basic-service] 2024-12-08 08:39:41.611 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69
  08:39:41.645 [ts-order-service] 2024-12-08 08:39:41.645 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 45  (×5)
  08:39:41.840 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:39:41 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 339 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×2)
  08:39:41.966 [ts-security-service] 2024-12-08 08:39:41.966 INFO 1 --- [io-11188-exec-7] security.controller.SecurityController : [Security Service][Check Security] Check Account Id: 4d2a46c7-71cb
  08:39:42.077 [ts-preserve-service] 2024-12-08 08:39:42.076 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security Complete
  08:39:42.094 [ts-preserve-service] 2024-12-08 08:39:42.093 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting...
  08:39:42.335 [ts-seat-service] 2024-12-08 08:39:42.334 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  08:39:42.468 [ts-travel-service] 2024-12-08 08:39:42.468 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  08:39:42.509 [ts-order-service] 2024-12-08 08:39:42.509 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Service][Verify Login] Success
  08:39:42.535 [ts-preserve-service] 2024-12-08 08:39:42.535 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service][Step 6] Buy Food Success
  08:39:54.939 [ts-travel-service] 2024-12-08 08:39:54.939 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=nanjing)  (×7)
  08:39:55.219 [ts-basic-service] 2024-12-08 08:39:55.219 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: aefc
  08:40:01.266 [ts-travel2-service] 2024-12-08 08:40:01.266 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×2)
  08:40:04.160 [ts-auth-service] 2024-12-08 08:40:04.160 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  08:40:08.000 [ts-food-service] 2024-12-08 08:40:08.000 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345
  08:40:09.910 [ts-travel-mongo] {"t":{"$date":"2024-12-08T08:40:09.910+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364720
  08:40:11.855 [ts-payment-mongo] {"t":{"$date":"2024-12-08T08:40:11.855+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364721

## p0266
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:17.558Z
```
{"timestamp":1732242497558247400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"{ id: '673fec41b0df5c00019af98b' }"}
```
Same service, the 2 minutes before (oldest first):
  02:28:16.238 [front-end] 673fec40b0df5c00019af988
  02:28:16.238 [front-end] Merging carts for customer id: 673fec40b0df5c00019af988 and session id: -7CzSWzmZrMmDK5B1dmO1fprYUPKidbH
  02:28:16.536 [front-end] GET /catalogue 200 - ms - -  (×4)
  02:28:17.014 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec38b0df5c00019af971"}
  02:28:17.022 [front-end] POST /addresses 200 - ms - -
  02:28:17.028 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec38b0df5c00019af971"}
  02:28:17.035 [front-end] POST /cards 200 - ms - -
  02:28:17.084 [front-end] Attempting to delete cart for user: 673fec38b0df5c00019af971
  02:28:17.369 [front-end] Request received with body: {}
  02:28:17.377 [front-end] Received response: "{\"firstName\":\"vtFUiCYPGkr\",\"lastName\":\"vtFUiCYPGkr\",\"username\":\"vtFUiCYPGkr\",\"id\":\"673fec2bb0df5c00019af944\",\"_links\":{\"a
  02:28:17.377 [front-end] GET Request to: http://user/customers/673fec2bb0df5c00019af944/addresses  (×2)
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec33b0df5c00019af961\",\"_links\":{\"
  02:28:17.383 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:17.383 [front-end] [ undefined, undefined ]
  02:28:17.383 [front-end] Posting Order: {"customer":"http://user/customers/673fec2bb0df5c00019af944","address":"http://user/addresses/673fec33b0df5c00019af960","card":"http://user/cards
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×44)
  02:28:03.174 [front-end] User cart deleted with status: 503  (×43)
  02:28:03.202 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×43)
  02:28:03.249 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×17)
  02:28:03.410 [front-end] Carts merged.  (×44)
  02:28:04.973 [front-end] Posting Customer: {"username":"HFHBXn","password":"EOgUhihln","email":"HFHBXn@gmail.com","firstName":"HFHBXn","lastName":"HFHBXn"}
  02:28:05.351 [user] ts=2024-11-22T02:28:05.351787827Z caller=middlewares.go:46 method=Register username=vuOxCKL email=vuOxCKL@gmail.com took=4.581531ms
  02:28:08.095 [front-end] Received response: "{\"firstName\":\"RsyjMQXEZqDOIBa\",\"lastName\":\"RsyjMQXEZqDOIBa\",\"username\":\"RsyjMQXEZqDOIBa\",\"id\":\"673fec1eb0df5c00019af912\",\"_
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×6)
  02:28:15.136 [carts] 2024-11-22 02:28:15.041 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 160.989 seconds (JVM running for 167.0
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:22.317 [front-end] Received response: "{\"firstName\":\"JGQXvUjPbFrtK\",\"lastName\":\"JGQXvUjPbFrtK\",\"username\":\"JGQXvUjPbFrtK\",\"id\":\"673fec34b0df5c00019af964\",\"_links\
  02:28:23.143 [orders] 2024-11-22 02:28:23.143 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×10)
  02:28:24.588 [shipping] Adding shipment to queue...  (×25)
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:26.156 [front-end] POST /cart 201 - ms - -  (×28)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d8","customerId":"673fec2cb0df5c00019af949","customer":{"id":null,"firstName":"KoWsmDtUqsE
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:30.547 [front-end] Received response: "{\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\",\"username\":\"vvgsHcY\",\"id\":\"673fec35b0df5c00019af968\",\"_links\":{\"addresses\":{
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.645 [queue-master] 2024-11-22 02:28:32.645 INFO 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×16)
  02:28:37.005 [user] ts=2024-11-22T02:28:37.005380807Z caller=middlewares.go:46 method=Register username=XTqSaA email=XTqSaA@gmail.com took=624.562µs
  02:28:40.136 [front-end] Order response: {"id":"673fec58d94b9000069b39dc","customerId":"673fec41b0df5c00019af98b","customer":{"id":null,"firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe",
  02:28:41.723 [user] ts=2024-11-22T02:28:41.723279742Z caller=middlewares.go:46 method=Register username=yaELjpCD email=yaELjpCD@gmail.com took=1.302265ms
  02:28:43.812 [front-end] Order response: {"id":"673fec5bd94b9000069b39e0","customerId":"673fec47b0df5c00019af996","customer":{"id":null,"firstName":"bhZuEQ","lastName":"bhZuEQ","usernam
  02:28:45.163 [front-end] Received response: "{\"firstName\":\"oqYeDriHaX\",\"lastName\":\"oqYeDriHaX\",\"username\":\"oqYeDriHaX\",\"id\":\"673fec49b0df5c00019af999\",\"_links\":{\"addr
  02:28:46.749 [front-end] Posting Customer: {"username":"kSaYlXePgdj","password":"miJFSQiUAg","email":"kSaYlXePgdj@gmail.com","firstName":"kSaYlXePgdj","lastName":"kSaYlXePgdj"}

## p0325
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:21:04.514Z
```
{"timestamp":1732245664514079700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"{\"id\":\"808a2de1-1aaa-4c25-a9b9-6612e8f29a38\",\"name\":\"Crossed\",\"description\":\"A mature sock, crossed, with an air of nonchalance.\",\"imageUrl\":[\"/catalogue/images/cross_1.jpeg\",\"/catalogue/images/cross_2.jpeg\"],\"price\":17.32,\"count\":738,\"tag\":[\"blue\",\"red\",\"action\",\"formal\"]}\n"}
```
Same service, the 2 minutes before (oldest first):
  03:21:04.337 [front-end] Carts merged.  (×2)
  03:21:04.337 [front-end] set cookie673ff8a0b0df5c00019b1f5e  (×2)
  03:21:04.338 [front-end] Sent cookies.  (×2)
  03:21:04.340 [front-end] POST /register 200 46.211 ms - 33  (×2)
  03:21:04.352 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff898b0df5c00019b1f40"}
  03:21:04.361 [front-end] POST /addresses 200 - ms - -
  03:21:04.367 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff898b0df5c00019b1f40"}
  03:21:04.374 [front-end] POST /cards 200 - ms - -
  03:21:04.422 [front-end] Attempting to delete cart for user: 673ff898b0df5c00019b1f40
  03:21:04.427 [front-end] Posting Customer: {"username":"qklQL","password":"OfLCWzLJmr","email":"qklQL@gmail.com","firstName":"qklQL","lastName":"qklQL"}
  03:21:04.435 [front-end] { id: '673ff8a0b0df5c00019b1f61' }
  03:21:04.435 [front-end] 673ff8a0b0df5c00019b1f61
  03:21:04.435 [front-end] Merging carts for customer id: 673ff8a0b0df5c00019b1f61 and session id: 9cmQ27R1HLxSG_RW70UPuc5XB6OBP5eE
  03:21:04.498 [front-end] User cart deleted with status: 503
  03:21:04.501 [front-end] DELETE /cart 503 - ms - -
  03:21:04.506 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
All services, 30 seconds either side (sampled):
  03:20:34.528 [front-end] Request received with body: {}  (×56)
  03:20:34.596 [front-end] Order response: {"timestamp":1732245634593,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×33)
  03:20:35.080 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff87ab0df5c00019b1ef7"}  (×58)
  03:20:35.437 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×6)
  03:20:36.632 [front-end] POST to carts: http://carts/carts/673ff87cb0df5c00019b1efd/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}  (×26)
  03:20:39.079 [user] ts=2024-11-22T03:20:39.079141282Z caller=middlewares.go:46 method=Register username=ELXzX email=ELXzX@gmail.com took=1.044635ms
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  03:20:47.743 [front-end] Received response: "{\"firstName\":\"MoGml\",\"lastName\":\"MoGml\",\"username\":\"MoGml\",\"id\":\"673ff87cb0df5c00019b1efd\",\"_links\":{\"addresses\":{\"href
  03:20:49.389 [carts] 2024-11-22 03:20:49.389 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframewo  (×2)
  03:20:54.561 [front-end] Posting Customer: {"username":"LNstXzKIIEKneJ","password":"NZVezpyHM","email":"LNstXzKIIEKneJ@gmail.com","firstName":"LNstXzKIIEKneJ","lastName":"LNstXzKIIEKneJ
  03:20:59.100 [user] ts=2024-11-22T03:20:59.100482586Z caller=middlewares.go:46 method=Register username=mLiQP email=mLiQP@gmail.com took=1.31638ms
  03:20:59.690 [carts] 2024-11-22 03:20:59.690 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[OPTIONS],produces=[application/
  03:20:59.789 [carts] 2024-11-22 03:20:59.789 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces=
  03:21:02.411 [front-end] Received response: "{\"firstName\":\"HWsmCvxoMrNqX\",\"lastName\":\"HWsmCvxoMrNqX\",\"username\":\"HWsmCvxoMrNqX\",\"id\":\"673ff884b0df5c00019b1f0d\",\"_links\
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:21:04.427 [front-end] Posting Customer: {"username":"qklQL","password":"OfLCWzLJmr","email":"qklQL@gmail.com","firstName":"qklQL","lastName":"qklQL"}
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposur  (×2)
  03:21:10.780 [front-end] Received response: "{\"firstName\":\"MGpVgwryvJC\",\"lastName\":\"MGpVgwryvJC\",\"username\":\"MGpVgwryvJC\",\"id\":\"673ff894b0df5c00019b1f32\",\"_links\":{\"a
  03:21:13.304 [front-end] Received response: "{\"firstName\":\"XYDErsNhuY\",\"lastName\":\"XYDErsNhuY\",\"username\":\"XYDErsNhuY\",\"id\":\"673ff88fb0df5c00019b1f26\",\"_links\":{\"addr
  03:21:15.893 [carts-db] {"t":{"$date":"2024-11-22T03:21:15.892+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:5832  (×17)
  03:21:18.289 [carts] 2024-11-22 03:21:18.289 INFO [carts,fb7913950d676f18,6e117eba14b3663e,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{reposi  (×24)
  03:21:18.613 [queue-master] 2024-11-22 03:21:18.613 ERROR 6 --- [ool-6-thread-44] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×13)
  03:21:18.904 [front-end] Order response: {"id":"673ff8aed94b9000069b4390","customerId":"673ff896b0df5c00019b1f3a","customer":{"id":null,"firstName":"aZnbBrPviPwcYcC","lastName":"aZnbBrP
  03:21:19.679 [front-end] Received response: "{\"firstName\":\"qklQL\",\"lastName\":\"qklQL\",\"username\":\"qklQL\",\"id\":\"673ff8a0b0df5c00019b1f61\",\"_links\":{\"addresses\":{\"href
  03:21:20.407 [front-end] Order response: {"id":"673ff8b0d94b9000069b4396","customerId":"673ff893b0df5c00019b1f31","customer":{"id":null,"firstName":"nPklGOsvzh","lastName":"nPklGOsvzh",
  03:21:22.641 [front-end] Received response: "{\"firstName\":\"TxflHMpaWteY\",\"lastName\":\"TxflHMpaWteY\",\"username\":\"TxflHMpaWteY\",\"id\":\"673ff898b0df5c00019b1f40\",\"_links\":{
  03:21:26.847 [front-end] Received response: "{\"firstName\":\"gxEQQKdgPqad\",\"lastName\":\"gxEQQKdgPqad\",\"username\":\"gxEQQKdgPqad\",\"id\":\"673ff89fb0df5c00019b1f5d\",\"_links\":{
  03:21:32.045 [front-end] Posting Customer: {"username":"tEhusfT","password":"HAHzo","email":"tEhusfT@gmail.com","firstName":"tEhusfT","lastName":"tEhusfT"}
  03:21:34.256 [front-end] Order response: {"id":"673ff8bed94b9000069b439f","customerId":"673ff8a8b0df5c00019b1f85","customer":{"id":null,"firstName":"yXmVwShR","lastName":"yXmVwShR","use

## p0326
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:21:06.490Z
```
{"timestamp":1732245666490001400,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:21:06.489  INFO [carts,,,] 7 --- [           main] o.s.s.c.ThreadPoolTaskScheduler          : Initializing ExecutorService "}
```
Same service, the 2 minutes before (oldest first):
  03:21:00.086 [carts] 2024-11-22 03:21:00.086 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionHa
  03:21:00.086 [carts] 2024-11-22 03:21:00.086 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframewo
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applicatio
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public jav
  03:21:03.084 [carts] 2024-11-22 03:21:03.083 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/
  03:21:03.084 [carts] 2024-11-22 03:21:03.084 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  03:21:03.086 [carts] 2024-11-22 03:21:03.085 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applicatio
  03:21:03.086 [carts] 2024-11-22 03:21:03.086 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.s
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto 
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public j
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  03:21:03.184 [carts] 2024-11-22 03:21:03.183 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces
  03:21:03.285 [carts] 2024-11-22 03:21:03.285 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/
All services, 30 seconds either side (sampled):
  03:20:36.491 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff87cb0df5c00019b1efd"}  (×58)
  03:20:36.686 [front-end] Received response: "{\"firstName\":\"RnEAzWwrE\",\"lastName\":\"RnEAzWwrE\",\"username\":\"RnEAzWwrE\",\"id\":\"673ff86cb0df5c00019b1ec9\",\"_links\":{\"address
  03:20:36.736 [front-end] POST /orders 500 - ms - -  (×55)
  03:20:38.030 [front-end] Carts merged.  (×59)
  03:20:38.341 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×5)
  03:20:41.483 [front-end] Posting Customer: {"username":"URVWiLVbByzZ","password":"qXaKAmwrnF","email":"URVWiLVbByzZ@gmail.com","firstName":"URVWiLVbByzZ","lastName":"URVWiLVbByzZ"}
  03:20:43.391 [carts] 2024-11-22 03:20:43.390 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.spring
  03:20:49.001 [user] ts=2024-11-22T03:20:49.001760928Z caller=middlewares.go:46 method=Register username=asYAoymkBkzj email=asYAoymkBkzj@gmail.com took=935.752µs  (×5)
  03:20:51.970 [front-end] Posting Customer: {"username":"nPklGOsvzh","password":"YuEpn","email":"nPklGOsvzh@gmail.com","firstName":"nPklGOsvzh","lastName":"nPklGOsvzh"}
  03:20:56.805 [front-end] Posting Customer: {"username":"nLZjIlByeidrL","password":"SRNOEYM","email":"nLZjIlByeidrL@gmail.com","firstName":"nLZjIlByeidrL","lastName":"nLZjIlByeidrL"}
  03:20:59.685 [carts] 2024-11-22 03:20:59.685 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[HEAD],produces=[application/hal+json ||
  03:20:59.786 [carts] 2024-11-22 03:20:59.785 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[DELETE],produce
  03:20:59.887 [carts] 2024-11-22 03:20:59.887 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframewor
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public jav
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public j
  03:21:05.450 [front-end] Received response: "{\"firstName\":\"dOIvn\",\"lastName\":\"dOIvn\",\"username\":\"dOIvn\",\"id\":\"673ff888b0df5c00019b1f18\",\"_links\":{\"addresses\":{\"href
  03:21:09.238 [front-end] Posting Customer: {"username":"pMqcnDbPZ","password":"kxLei","email":"pMqcnDbPZ@gmail.com","firstName":"pMqcnDbPZ","lastName":"pMqcnDbPZ"}
  03:21:12.194 [front-end] Posting Customer: {"username":"yXmVwShR","password":"JrCRXcAWLQ","email":"yXmVwShR@gmail.com","firstName":"yXmVwShR","lastName":"yXmVwShR"}
  03:21:14.190 [carts] 2024-11-22 03:21:14.190 INFO [carts,,,] 7 --- [p-nio-80-exec-3] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization complet
  03:21:16.388 [carts] 2024-11-22 03:21:16.294 INFO [carts,4f4200e92a2346f2,c605b8bba205809d,false] 7 --- [-nio-80-exec-10] org.mongodb.driver.connection : Opened connection [connecti  (×8)
  03:21:18.602 [orders] 2024-11-22 03:21:18.602 INFO [orders,40393c2387463fc4,20a8cb1f4ece78de,false] 6 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Received payment re  (×16)
  03:21:18.708 [front-end] Order response: {"id":"673ff8aed94b9000069b438d","customerId":"673ff891b0df5c00019b1f2a","customer":{"id":null,"firstName":"asYAoymkBkzj","lastName":"asYAoymkBk
  03:21:19.450 [front-end] Received response: "{\"firstName\":\"gKGbBfBuFal\",\"lastName\":\"gKGbBfBuFal\",\"username\":\"gKGbBfBuFal\",\"id\":\"673ff89eb0df5c00019b1f54\",\"_links\":{\"a
  03:21:20.103 [front-end] Order response: {"id":"673ff8b0d94b9000069b4394","customerId":"673ff899b0df5c00019b1f44","customer":{"id":null,"firstName":"fnNnBGFeZwjz","lastName":"fnNnBGFeZw
  03:21:20.805 [front-end] Order response: {"id":"673ff8b0d94b9000069b4398","customerId":"673ff897b0df5c00019b1f3d","customer":{"id":null,"firstName":"PvCLeeg","lastName":"PvCLeeg","usern
  03:21:24.101 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b4d94b9000069b439b","customerId":"673ff89eb0df5c00019b1f57","customer":{"id":null,"firstName":"UFhesIA","l
  03:21:28.398 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732245688395,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde
  03:21:33.987 [user] ts=2024-11-22T03:21:33.987218895Z caller=middlewares.go:46 method=Register username=sYvdDM email=sYvdDM@gmail.com took=1.011607ms
  03:21:34.809 [front-end] Order response: {"id":"673ff8bed94b9000069b43a1","customerId":"673ff8abb0df5c00019b1f8e","customer":{"id":null,"firstName":"eSafJJOuc","lastName":"eSafJJOuc","u

## p0710
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-14T02:00:55.500Z
```
{"service":"mobservice1","message":"2021-08-14 02:00:55,500 | INFO | 0.0.0.1 | 172.17.0.5 | mobservice1 | fda259603ee2d28b | info 67b01e16-fc60-11eb-9613-0242ac110003:chfTZIqp write success"}
```
Same service, the 2 minutes before (oldest first):
  02:00:52.718 [mobservice1] INFO info 65f8000c-fc60-11eb-9d5b-0242ac110003:rJHuqoXG write success
  02:00:53.126 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  02:00:53.126 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  02:00:53.127 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '6656b034-fc60-11eb-a545-0242ac110003'}  (×4)
  02:00:53.179 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '6656b034-fc60-11eb-a545-0242ac110003', 'value': 'GalEMmnB'}  (×4)
  02:00:53.242 [mobservice1] INFO info 6656b034-fc60-11eb-a545-0242ac110003:GalEMmnB write success
  02:00:53.997 [mobservice1] INFO info 66c88b96-fc60-11eb-b44f-0242ac110003:NxPGARft write success
  02:00:55.047 [mobservice1] INFO info 676d8448-fc60-11eb-be3b-0242ac110004:ICtSnKPU write success
All services, 30 seconds either side (sampled):
  02:00:25.555 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  02:00:25.657 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×47)
  02:00:25.908 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×43)
  02:00:26.124 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  02:00:26.365 [redisservice1] INFO redis读取信息成功, status_code: 200  (×45)
  02:00:26.526 [redisservice2] INFO service accept, status_code: 200  (×48)
  02:00:26.746 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×47)
  02:00:27.029 [mobservice1] INFO info 56bd9174-fc60-11eb-8c3c-0242ac110004:bAuaLHTx write success
  02:00:29.819 [dbservice2] INFO 582f7fea-fc60-11eb-a7ac-0242ac110004-vUJXxywj-uoW{8P@>ag5V token generate success token=MTYyODg3NzYyOS44MTkzOTUzOjU4MmY3ZmVhLWZjNjAtMTFlYi1hN2FjLTAyNDJhYzE
  02:00:32.104 [dbservice2] INFO 5980dcd6-fc60-11eb-8482-0242ac110003-UDVbonul-9ximBG>/uyWw token generate success token=MTYyODg3NzYzMi4xMDM3ODQ6NTk4MGRjZDYtZmM2MC0xMWViLTg0ODItMDI0MmFjMTE
  02:00:34.620 [dbservice2] INFO 5b08e31e-fc60-11eb-ac01-0242ac110004-GqOpyFdr-IKFO1}Rm^=xD token generate success token=MTYyODg3NzYzNC42MTk2NzE4OjViMDhlMzFlLWZjNjAtMTFlYi1hYzAxLTAyNDJhYzE
  02:00:37.198 [dbservice2] INFO 5c806ec4-fc60-11eb-95f1-0242ac110003-AmhGSJRK-dWueNw!<8>i6 token generate success token=MTYyODg3NzYzNy4xOTgzNzM2OjVjODA2ZWM0LWZjNjAtMTFlYi05NWYxLTAyNDJhYzE
  02:00:39.695 [dbservice2] INFO 5e0cc62a-fc60-11eb-a4cf-0242ac110004-GYgLnikZ-DR.*AP0Lv^aF token generate success token=MTYyODg3NzYzOS42OTU0MjE6NWUwY2M2MmEtZmM2MC0xMWViLWE0Y2YtMDI0MmFjMTE
  02:00:42.077 [dbservice2] INFO 5f8d8552-fc60-11eb-88ac-0242ac110004-QNgzxusO-msv)gRlMu=0. token generate success token=MTYyODg3NzY0Mi4wNzc1NDo1ZjhkODU1Mi1mYzYwLTExZWItODhhYy0wMjQyYWMxMTA
  02:00:44.477 [dbservice1] INFO 60e41ccc-fc60-11eb-8216-0242ac110003-OMLuHZEe-zUGYQa}urZJ/ token generate success token=MTYyODg3NzY0NC40Nzc1MTI0OjYwZTQxY2NjLWZjNjAtMTFlYi04MjE2LTAyNDJhYzE
  02:00:47.031 [dbservice2] INFO 626d9f6e-fc60-11eb-9315-0242ac110004-HYsctkhi-NFMe>j?6OAvx token generate success token=MTYyODg3NzY0Ny4wMzA0ODk3OjYyNmQ5ZjZlLWZjNjAtMTFlYi05MzE1LTAyNDJhYzE
  02:00:49.744 [mobservice2] INFO info 6443b10c-fc60-11eb-b89b-0242ac110003:kWPHSeaC write success
  02:00:52.718 [mobservice1] INFO info 65f8000c-fc60-11eb-9d5b-0242ac110003:rJHuqoXG write success
  02:00:55.047 [mobservice1] INFO info 676d8448-fc60-11eb-be3b-0242ac110004:ICtSnKPU write success
  02:00:58.404 [mobservice1] INFO info 6960b982-fc60-11eb-bf9e-0242ac110004:IhzyCpmU write success
  02:01:00.987 [mobservice2] INFO info 6afb2c64-fc60-11eb-a51f-0242ac110004:SYUdXTMn write success
  02:01:03.382 [mobservice1] INFO info 6c6aa26e-fc60-11eb-b9cd-0242ac110004:WitlFQzD write success
  02:01:06.335 [dbservice1] INFO 6de2453e-fc60-11eb-89a2-0242ac110003-QYryCKLk-@51x7Dd$-e=8 token generate success token=MTYyODg3NzY2Ni4zMzQ4MDQ6NmRlMjQ1M2UtZmM2MC0xMWViLTg5YTItMDI0MmFjMTE
  02:01:08.894 [dbservice2] INFO 6f796cce-fc60-11eb-9cf0-0242ac110004-jnuiIECt-_JI:sCNEZ%ay token generate success token=MTYyODg3NzY2OC44OTQzMzI0OjZmNzk2Y2NlLWZjNjAtMTFlYi05Y2YwLTAyNDJhYzE
  02:01:11.416 [dbservice2] INFO 70fd93d6-fc60-11eb-a49a-0242ac110004-cvBGfCKh-Jf.l:ogU&-se token generate success token=MTYyODg3NzY3MS40MTYzNzA2OjcwZmQ5M2Q2LWZjNjAtMTFlYi1hNDlhLTAyNDJhYzE
  02:01:13.883 [dbservice1] INFO 726ca752-fc60-11eb-a5b3-0242ac110003-HCzNJuWb-bP$YVW7=McS1 token generate success token=MTYyODg3NzY3My44ODI5OTM6NzI2Y2E3NTItZmM2MC0xMWViLWE1YjMtMDI0MmFjMTE
  02:01:16.573 [mobservice1] INFO info 744a7b80-fc60-11eb-b610-0242ac110004:pKzgewir write success
  02:01:18.935 [mobservice2] INFO info 75b04e1e-fc60-11eb-93fc-0242ac110004:vyNKmojf write success
  02:01:22.247 [mobservice2] INFO info 77a9e806-fc60-11eb-840a-0242ac110004:vNyVfPiM write success

## p0688
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-12T06:39:37.500Z
```
{"service":"dbservice2","message":"2021-08-12 06:39:37,500 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | e03b196fe852d8f4 | 01bffb7e-faf5-11eb-9c46-0242ac110003-jFTtOqPD-V5xAt:Q*{qep token generate success token=MTYyODcyMTU3Ny40OTk3NzM3OjAxYmZmYjdlLWZhZjUtMTFlYi05YzQ2LTAyNDJhYzExMDAwM2pGVHRPcVBEVjV4QXQ6USp7cWVwOjE2Mjg3MjE2MzcuNDk5Nzg2OmZiOTllNWUwMTRlNDUzMWQ4NzdkMmFlMGQ1ZTBiZmIw"}
```
Same service, the 2 minutes before (oldest first):
  06:39:30.583 [dbservice2] INFO query = select passwards from username_table where user_name='uHrsPUfR'  (×5)
  06:39:30.661 [dbservice2] INFO fda6ad26-faf4-11eb-aefd-0242ac110004-uHrsPUfR-&IVwh=}zb.Hu token generate success token=MTYyODcyMTU3MC42NjE0NjI1OmZkYTZhZDI2LWZhZjQtMTFlYi1hZWZkLTAyNDJhYzE
  06:39:31.773 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  06:39:31.773 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  06:39:31.901 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  06:39:34.719 [dbservice2] INFO 0011311c-faf5-11eb-bf6f-0242ac110003-jyDKkYiT-TZobU^va5MEt token generate success token=MTYyODcyMTU3NC43MTkwMjc1OjAwMTEzMTFjLWZhZjUtMTFlYi1iZjZmLTAyNDJhYzE
  06:39:35.179 [dbservice2] INFO 005538e4-faf5-11eb-9a63-0242ac110003-wkgeEpUD-oq&=dQCzk7R4 token generate success token=MTYyODcyMTU3NS4xNzg3NTg0OjAwNTUzOGU0LWZhZjUtMTFlYi05YTYzLTAyNDJhYzE
  06:39:35.961 [dbservice2] INFO 00d3b390-faf5-11eb-a4b5-0242ac110004-pKxfZBio-*wUb}zXdlquF token generate success token=MTYyODcyMTU3NS45NjExOTU3OjAwZDNiMzkwLWZhZjUtMTFlYi1hNGI1LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  06:39:07.522 [redisservice1] INFO redis write success  (×69)
  06:39:07.656 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×29)
  06:39:07.753 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×30)
  06:39:07.958 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×34)
  06:39:08.218 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×35)
  06:39:08.323 [mobservice2] INFO info f08ade6e-faf4-11eb-962a-0242ac110003:WzpeuShd write success
  06:39:08.487 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×33)
  06:39:08.759 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'f104fba4-faf4-11eb-95ef-0242ac110004', 'value': '', 'ex': 10}  (×30)
  06:39:09.285 [mobservice2] INFO info f10a6bc0-faf4-11eb-bc5b-0242ac110003:XnLAQNcU write success
  06:39:09.759 [dbservice1] INFO f104fba4-faf4-11eb-95ef-0242ac110004-SBgdrmlT-HkpM0UVa+&9- token generate success token=MTYyODcyMTU0OS43NTkzMzIyOmYxMDRmYmE0LWZhZjQtMTFlYi05NWVmLTAyNDJhYzE
  06:39:10.610 [dbservice2] INFO f1a83f26-faf4-11eb-a061-0242ac110004-NChObWPp-ABNnZD}T2zO{ token generate success token=MTYyODcyMTU1MC42MDk4Nzc2OmYxYTgzZjI2LWZhZjQtMTFlYi1hMDYxLTAyNDJhYzE
  06:39:22.794 [redisservice1] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400  (×2)
  06:39:23.771 [dbservice1] INFO f9853b0e-faf4-11eb-8e34-0242ac110003-xVDzUigO-B^s:FwmVgy>_ token generate success token=MTYyODcyMTU2My43NzEyMzgzOmY5ODUzYjBlLWZhZjQtMTFlYi04ZTM0LTAyNDJhYzE
  06:39:25.885 [redisservice2] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400  (×2)
  06:39:27.862 [dbservice2] INFO fbe899c2-faf4-11eb-8ee7-0242ac110004-KcODnoiU-F<(omkXPMp#_ token generate success token=MTYyODcyMTU2Ny44NjE3NzUyOmZiZTg5OWMyLWZhZjQtMTFlYi04ZWU3LTAyNDJhYzE
  06:39:29.853 [dbservice2] INFO fd1e73ca-faf4-11eb-8a79-0242ac110004-KrCJbket-SDY(Ra?xklfj token generate success token=MTYyODcyMTU2OS44NTM0NDg0OmZkMWU3M2NhLWZhZjQtMTFlYi04YTc5LTAyNDJhYzE
  06:39:31.901 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  06:39:34.379 [dbservice1] INFO ffcd1f18-faf4-11eb-a2ba-0242ac110004-UoOtrWnu-l>x7frKnk89y token generate success token=MTYyODcyMTU3NC4zNzkwNzQ2OmZmY2QxZjE4LWZhZjQtMTFlYi1hMmJhLTAyNDJhYzE
  06:39:35.961 [dbservice2] INFO 00d3b390-faf5-11eb-a4b5-0242ac110004-pKxfZBio-*wUb}zXdlquF token generate success token=MTYyODcyMTU3NS45NjExOTU3OjAwZDNiMzkwLWZhZjUtMTFlYi1hNGI1LTAyNDJhYzE
  06:39:37.868 [mobservice1] INFO info 02288ffe-faf5-11eb-a153-0242ac110004:TKYsgkdQ write success
  06:39:40.065 [mobservice2] INFO info 0367576a-faf5-11eb-b11b-0242ac110004:rObgBwap write success
  06:39:42.432 [dbservice1] INFO 04a1c476-faf5-11eb-9bbb-0242ac110004-IToaCVWE-}<7sLbog{2vF token generate success token=MTYyODcyMTU4Mi40MzIxNTU2OjA0YTFjNDc2LWZhZjUtMTFlYi05YmJiLTAyNDJhYzE
  06:39:44.166 [dbservice2] INFO 05a0d326-faf5-11eb-af94-0242ac110003-pVIaJPSL-/6iJQ_4ro#jO token generate success token=MTYyODcyMTU4NC4xNjU2NjA2OjA1YTBkMzI2LWZhZjUtMTFlYi1hZjk0LTAyNDJhYzE
  06:39:46.168 [dbservice2] INFO 06dc8834-faf5-11eb-85d7-0242ac110003-WitlFQzD-p-/_Fb!8=}57 token generate success token=MTYyODcyMTU4Ni4xNjgwODU4OjA2ZGM4ODM0LWZhZjUtMTFlYi04NWQ3LTAyNDJhYzE
  06:39:48.284 [dbservice2] INFO 082a400a-faf5-11eb-b39f-0242ac110004-qwpdAUNi-j-s(4p$@1:Fo token generate success token=MTYyODcyMTU4OC4yODM4ODc0OjA4MmE0MDBhLWZhZjUtMTFlYi1iMzlmLTAyNDJhYzE
  06:39:54.564 [dbservice1] INFO 0be2ed32-faf5-11eb-b48f-0242ac110003-FqaTIXhn-^vCabrQL@MgF token generate success token=MTYyODcyMTU5NC41NjQ1MzU6MGJlMmVkMzItZmFmNS0xMWViLWI0OGYtMDI0MmFjMTE
  06:39:59.920 [dbservice1] ERROR password in database of {user} is null, the user is not registered  (×2)
  06:40:01.570 [dbservice2] INFO 100fc448-faf5-11eb-9647-0242ac110004-qHGVUSPX-2X6L_bVf5*I< token generate success token=MTYyODcyMTYwMS41NzAwNjY3OjEwMGZjNDQ4LWZhZjUtMTFlYi05NjQ3LTAyNDJhYzE
  06:40:03.354 [dbservice1] INFO 1102df48-faf5-11eb-8358-0242ac110003-hTjCBtGX-eJrbTQXfMu<_ token generate success token=MTYyODcyMTYwMy4zNTM2NDI3OjExMDJkZjQ4LWZhZjUtMTFlYi04MzU4LTAyNDJhYzE
  06:40:05.742 [dbservice1] INFO 12862a6e-faf5-11eb-9935-0242ac110003-NLUGYXBI-Lmw1G?kYO}b^ token generate success token=MTYyODcyMTYwNS43NDIyODU6MTI4NjJhNmUtZmFmNS0xMWViLTk5MzUtMDI0MmFjMTE

## p0208
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T07:09:20.369Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731913760369494000,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  07:09:19.854 [currencyservice] conversion request successful  (×17)
  07:09:20.239 [currencyservice] Getting supported currencies...  (×3)
All services, 30 seconds either side (sampled):
  07:08:50.877 [frontend] request started  (×315)
  07:08:50.877 [frontend] request complete  (×315)
  07:08:50.882 [currencyservice] Getting supported currencies...  (×256)
  07:08:50.893 [currencyservice] conversion request successful  (×772)
  07:08:50.926 [adservice] received ad request (context_words=[])  (×46)
  07:08:51.062 [recommendationservice] [Recv ListRecommendations] product_ids=['9SIQT8TOJO', '2ZYFJ3GM2N', '0PUK6V6EV0', '6E92ZMYYFZ', 'L9ECAV7KIM']  (×202)
  07:08:51.077 [adservice] received ad request (context_words=[hair, beauty])  (×14)
  07:08:51.084 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=2ZYFJ3GM2N, quantity=7  (×27)
  07:08:51.114 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', 'L9ECAV7KIM']  (×3)
  07:08:51.115 [shippingservice] [GetQuote] completed request  (×60)
  07:08:51.746 [adservice] received ad request (context_words=[kitchen])  (×50)
  07:08:54.960 [adservice] received ad request (context_words=[clothing, tops])  (×17)
  07:09:20.355 [frontend] placing order  (×9)
  07:09:20.384 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"88083","nanos":78284547},"credit_card":{"credit_card_number":"4031414416114  (×4)
  07:09:20.386 [checkoutservice] payment went through (transaction_id: b266173e-9ab3-4546-9b6b-c5fbde189ff1)  (×9)
  07:09:20.387 [shippingservice] [ShipOrder] completed request  (×9)
  07:09:20.394 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 14  (×9)
  07:09:20.395 [frontend] order placed  (×9)
  07:09:25.197 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"2217","nanos":169394085},"credit_card":{"credit_card_number":"4443107395714  (×3)
  07:09:25.207 [checkoutservice] failed to send order confirmation to "taylorwhitehead@example.com": rpc error: code = Unavailable desc = no healthy upstream
  07:09:29.866 [checkoutservice] failed to send order confirmation to "longanna@example.com": rpc error: code = Unavailable desc = no healthy upstream
  07:09:37.350 [checkoutservice] failed to send order confirmation to "ycollins@example.com": rpc error: code = Unavailable desc = no healthy upstream
  07:09:37.638 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"1033","nanos":343430341},"credit_card":{"credit_card_number":"4786654525320  (×2)
  07:09:37.650 [checkoutservice] failed to send order confirmation to "martinyoung@example.org": rpc error: code = Unavailable desc = no healthy upstream
  07:09:44.371 [checkoutservice] failed to send order confirmation to "ofisher@example.org": rpc error: code = Unavailable desc = no healthy upstream

## p0589
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:32:24.575Z
```
{"timestamp":1733596344575953400,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:32:24.575  INFO 1 --- [io-12340-exec-9] auth.security.UserDetailsServiceImpl     : UsernamePasswordAuthenticationToken  username :admin"}
```
Same service, the 2 minutes before (oldest first):
  18:32:13.199 [ts-auth-service] 2024-12-07 18:32:13.198 INFO 1 --- [io-12340-exec-1] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×3)
  18:32:13.374 [ts-auth-service] 2024-12-07 18:32:13.374 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×5)
  18:32:13.374 [ts-auth-service] 2024-12-07 18:32:13.374 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×5)
  18:32:15.629 [ts-auth-service] 2024-12-07 18:32:15.628 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×3)
  18:32:15.629 [ts-auth-service] 2024-12-07 18:32:15.628 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
  18:32:19.183 [ts-auth-service] 2024-12-07 18:32:19.183 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
All services, 30 seconds either side (sampled):
  18:31:54.575 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:54 +0800] "POST /api/v1/users/login HTTP/1.1" 200 146 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×27)
  18:31:54.587 [ts-travel2-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×12)
  18:31:56.579 [ts-auth-service] 2024-12-07 18:31:56.579 INFO 1 --- [io-12340-exec-4] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×12)
  18:31:56.801 [ts-admin-travel-service] 2024-12-07 18:31:56.800 ERROR 1 --- [io-16114-exec-9] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×13)
  18:31:56.804 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:56 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 500 233 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×15)
  18:31:58.511 [ts-admin-basic-info-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×30)
  18:32:04.141 [ts-auth-service] 2024-12-07 18:32:04.141 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×11)
  18:32:06.380 [ts-travel-service] 2024-12-07 18:32:06.380 ERROR 1 --- [io-12346-exec-6] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  18:32:06.389 [ts-assurance-service] 2024-12-07 18:32:06.388 ERROR 1 --- [io-18888-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  18:32:06.401 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:32:06 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 500 236 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
  18:32:08.405 [ts-admin-basic-info-service] 2024-12-07 18:32:08.405 ERROR 1 --- [o-18767-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×4)
  18:32:08.507 [ts-auth-service] 2024-12-07 18:32:08.507 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
  18:32:09.296 [ts-food-service] 2024-12-07 18:32:09.295 ERROR 1 --- [io-18856-exec-2] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×3)
  18:32:09.305 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:32:09 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 500 259 "-" "Mozilla/5.0 (Macintosh;   (×3)
  18:32:27.265 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:32:27.265+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359634
  18:32:27.501 [ts-price-mongo] {"t":{"$date":"2024-12-07T18:32:27.501+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359634
  18:32:29.848 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:32:29.848+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359634
  18:32:29.904 [ts-station-mongo] {"t":{"$date":"2024-12-07T18:32:29.903+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359634
  18:32:30.447 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T18:32:30.447+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359635
  18:32:30.636 [ts-security-mongo] {"t":{"$date":"2024-12-07T18:32:30.636+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359635
  18:32:30.959 [ts-order-mongo] {"t":{"$date":"2024-12-07T18:32:30.959+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359635
  18:32:42.227 [ts-order-other-mongo] {"t":{"$date":"2024-12-07T18:32:42.226+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359636

## p0255
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:07.871Z
```
{"timestamp":1732242487871659500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"_embedded\\\":{\\\"card\\\":[{\\\"longNum\\\":\\\"123123321\\\",\\\"expires\\\":\\\"1232\\\",\\\"ccv\\\":\\\"123\\\",\\\"id\\\":\\\"673fec2cb0df5c00019af94b\\\",\\\"_links\\\":{\\\"card\\\":{\\\"href\\\":\\\"http://user/cards/673fec2cb0df5c00019af94b\\\"},\\\"self\\\":{\\\"href\\\":\\\"http://user/cards/673fec2cb0df5c00019af94b\\\"}}}]}}\\n\""}
```
Same service, the 2 minutes before (oldest first):
  02:28:07.436 [front-end] POST /cart 500 40.001 ms - 64
  02:28:07.449 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242487446,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×2)
  02:28:07.449 [front-end] Order response: {"timestamp":1732242487446,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×2)
  02:28:07.452 [front-end] POST /orders 500 - ms - -  (×2)
  02:28:07.599 [front-end] Request received with body: {}  (×2)
  02:28:07.606 [front-end] Received response: "{\"firstName\":\"TxpsuIEan\",\"lastName\":\"TxpsuIEan\",\"username\":\"TxpsuIEan\",\"id\":\"673fec22b0df5c00019af924\",\"_links\":{\"address
  02:28:07.606 [front-end] GET Request to: http://user/customers/673fec22b0df5c00019af924/addresses  (×4)
  02:28:07.612 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×2)
  02:28:07.612 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec27b0df5c00019af936\",\"_links\":{\"
  02:28:07.612 [front-end] [ undefined, undefined ]
  02:28:07.612 [front-end] Posting Order: {"customer":"http://user/customers/673fec22b0df5c00019af924","address":"http://user/addresses/673fec27b0df5c00019af935","card":"http://user/cards
  02:28:07.864 [front-end] Received response: "{\"firstName\":\"MlWxDCPQn\",\"lastName\":\"MlWxDCPQn\",\"username\":\"MlWxDCPQn\",\"id\":\"673fec27b0df5c00019af938\",\"_links\":{\"address
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×35)
  02:28:03.122 [front-end] GET /catalogue 200 - ms - -  (×41)
  02:28:03.196 [front-end] Received response: "{\"firstName\":\"FbddLnzSA\",\"lastName\":\"FbddLnzSA\",\"username\":\"FbddLnzSA\",\"id\":\"673fec21b0df5c00019af922\",\"_links\":{\"address
  02:28:03.245 [orders] 2024-11-22 02:28:03.244 ERROR [orders,,,] 6 --- [p-nio-80-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×16)
  02:28:03.391 [user] ts=2024-11-22T02:28:03.390808559Z caller=middlewares.go:46 method=Register username=kMzzAppFcYY email=kMzzAppFcYY@gmail.com took=958.317µs  (×5)
  02:28:03.523 [user] ts=2024-11-22T02:28:03.52331003Z caller=middlewares.go:46 method=Register username=sgQXbZQ email=sgQXbZQ@gmail.com took=1.065166ms
  02:28:05.055 [user] ts=2024-11-22T02:28:05.055011754Z caller=middlewares.go:104 method=GetAddresses id=673fec25b0df5c00019af92f result=1 took=781.934µs  (×15)
  02:28:06.796 [front-end] Posting Customer: {"username":"oyShDJ","password":"sWqvpeFZPy","email":"oyShDJ@gmail.com","firstName":"oyShDJ","lastName":"oyShDJ"}
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.451 [carts] 2024-11-22 02:28:10.451 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.377 [front-end] Received response: "{\"firstName\":\"vtFUiCYPGkr\",\"lastName\":\"vtFUiCYPGkr\",\"username\":\"vtFUiCYPGkr\",\"id\":\"673fec2bb0df5c00019af944\",\"_links\":{\"a
  02:28:19.135 [carts] 2024-11-22 02:28:18.940 INFO [carts,cb305558d352107b,fbb223eea295e77c,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×13)
  02:28:21.967 [front-end] Posting Customer: {"username":"PDQejFz","password":"UItpfuss","email":"PDQejFz@gmail.com","firstName":"PDQejFz","lastName":"PDQejFz"}
  02:28:23.046 [orders] 2024-11-22 02:28:23.045 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×5)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.870 [front-end] Received response: "{\"firstName\":\"sgQXbZQ\",\"lastName\":\"sgQXbZQ\",\"username\":\"sgQXbZQ\",\"id\":\"673fec33b0df5c00019af963\",\"_links\":{\"addresses\":{
  02:28:25.536 [carts] 2024-11-22 02:28:25.536 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.ItemsController : Did not find item.  (×10)
  02:28:26.351 [queue-master] Received shipment task: 673fec2db0df5c00019af953  (×14)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39cf","customerId":"673fec36b0df5c00019af96c","customer":{"id":null,"firstName":"oyShDJ","lastName":"oyShDJ","usernam
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.065 [front-end] Order response: {"id":"673fec4ad94b9000069b39d4","customerId":"673fec33b0df5c00019af963","customer":{"id":null,"firstName":"sgQXbZQ","lastName":"sgQXbZQ","usern
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket
  02:28:33.840 [front-end] Posting Customer: {"username":"MywYMGzyoIdhsgg","password":"SiEqM","email":"MywYMGzyoIdhsgg@gmail.com","firstName":"MywYMGzyoIdhsgg","lastName":"MywYMGzyoIdhsgg

## p0719
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-14T14:17:36.500Z
```
{"service":"dbservice1","message":"2021-08-14 14:17:36,500 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 52cabda06349493 | 51466646-fcc7-11eb-abc9-0242ac110004-jdpqWsnu-=D:3M-V09)5? token generate success token=MTYyODkyMTg1Ni40OTk4Njg5OjUxNDY2NjQ2LWZjYzctMTFlYi1hYmM5LTAyNDJhYzExMDAwNGpkcHFXc251PUQ6M00tVjA5KTU_OjE2Mjg5MjE5MTYuNDk5ODc5OjA4MWMwMjY2ZDY3ZDUzZTk3ZTBiMWY2NDU1OWU3ZDE4"}
```
Same service, the 2 minutes before (oldest first):
  14:17:32.344 [dbservice1] INFO 4eaea434-fcc7-11eb-8167-0242ac110003-WuXJGtdQ-LCRs.nwO{0!? token generate success token=MTYyODkyMTg1Mi4zNDQzMzcyOjRlYWVhNDM0LWZjYzctMTFlYi04MTY3LTAyNDJhYzE
  14:17:33.090 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  14:17:33.091 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  14:17:33.143 [dbservice1] INFO query = select passwards from username_table where user_name='nzYLWZFG'  (×5)
  14:17:33.219 [dbservice1] INFO 4f57b02e-fcc7-11eb-89fa-0242ac110003-nzYLWZFG-wO^H>E+{SFKY token generate success token=MTYyODkyMTg1My4yMTk0MzY0OjRmNTdiMDJlLWZjYzctMTFlYi04OWZhLTAyNDJhYzE
  14:17:34.111 [dbservice1] INFO 4fd7fb08-fcc7-11eb-9467-0242ac110004-GxrcRlDj-Lw{tNT75j/%g token generate success token=MTYyODkyMTg1NC4xMTExMjI4OjRmZDdmYjA4LWZjYzctMTFlYi05NDY3LTAyNDJhYzE
  14:17:35.245 [dbservice1] INFO 5067ddae-fcc7-11eb-9fbc-0242ac110003-SxlGNrtW-:6aQSXm@sWb3 token generate success token=MTYyODkyMTg1NS4yNDUyMzA0OjUwNjdkZGFlLWZjYzctMTFlYi05ZmJjLTAyNDJhYzE
  14:17:36.441 [dbservice1] INFO 510c7396-fcc7-11eb-a50e-0242ac110004-igXqQZLm-oS})G7plxrgb token generate success token=MTYyODkyMTg1Ni40NDEwMjk6NTEwYzczOTYtZmNjNy0xMWViLWE1MGUtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  14:17:06.553 [dbservice2] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c  (×2)
  14:17:06.697 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  14:17:06.958 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  14:17:07.098 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×43)
  14:17:07.204 [mobservice1] INFO info 3ff01b58-fcc7-11eb-9647-0242ac110004:xgpqRfCn write success
  14:17:07.397 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×49)
  14:17:08.482 [dbservice2] INFO 4094897c-fcc7-11eb-bd10-0242ac110004-vUsGrNAF-saSGFzg5!M2_ token generate success token=MTYyODkyMTgyOC40ODIzOTUyOjQwOTQ4OTdjLWZjYzctMTFlYi1iZDEwLTAyNDJhYzE
  14:17:09.497 [webservice1] INFO uuid: 4197d2fc-fcc7-11eb-8005-0242ac110003 write redis successfully  (×45)
  14:17:10.196 [dbservice2] INFO 4197d2fc-fcc7-11eb-8005-0242ac110003-dQcykLhj-Sn.w)Vyu7fB@ token generate success token=MTYyODkyMTgzMC4xOTU4MzA2OjQxOTdkMmZjLWZjYzctMTFlYi04MDA1LTAyNDJhYzE
  14:17:12.712 [mobservice1] INFO info 43560604-fcc7-11eb-9b12-0242ac110003:LcHJSWVC write success
  14:17:15.659 [mobservice1] INFO info 4511b312-fcc7-11eb-9db3-0242ac110003:yjlLtMmx write success
  14:17:18.448 [mobservice2] INFO info 46c884ba-fcc7-11eb-8aff-0242ac110004:guYIhUdp write success
  14:17:21.148 [dbservice1] INFO 481ddf68-fcc7-11eb-a048-0242ac110004-qONAMdbK-U5b4*vyY%+>A token generate success token=MTYyODkyMTg0MS4xNDg0MzEzOjQ4MWRkZjY4LWZjYzctMTFlYi1hMDQ4LTAyNDJhYzE
  14:17:23.652 [dbservice2] INFO 49a9d85a-fcc7-11eb-b83f-0242ac110004-tAOPYVGh-x0_z<Z&/l9L+ token generate success token=MTYyODkyMTg0My42NTE1MjYyOjQ5YTlkODVhLWZjYzctMTFlYi1iODNmLTAyNDJhYzE
  14:17:27.136 [dbservice1] INFO 4bad9c68-fcc7-11eb-92da-0242ac110004-hqSejVNL-iw-__POdaN>! token generate success token=MTYyODkyMTg0Ny4xMzU2NDc1OjRiYWQ5YzY4LWZjYzctMTFlYi05MmRhLTAyNDJhYzE
  14:17:29.635 [dbservice2] INFO 4d4604fc-fcc7-11eb-9018-0242ac110004-JUvKDVWZ-a+*q{iPRE@-> token generate success token=MTYyODkyMTg0OS42MzQ5OTg6NGQ0NjA0ZmMtZmNjNy0xMWViLTkwMTgtMDI0MmFjMTE
  14:17:31.726 [mobservice2] INFO info 4eaea434-fcc7-11eb-8167-0242ac110003:WuXJGtdQ write success
  14:17:34.663 [mobservice1] INFO info 5067ddae-fcc7-11eb-9fbc-0242ac110003:SxlGNrtW write success
  14:17:38.141 [dbservice1] INFO 52489d5c-fcc7-11eb-b467-0242ac110004-cTCBbWEI-c-#1<U?VsK5w token generate success token=MTYyODkyMTg1OC4xNDA2MzcyOjUyNDg5ZDVjLWZjYzctMTFlYi1iNDY3LTAyNDJhYzE
  14:17:40.418 [dbservice2] INFO 53b19824-fcc7-11eb-ac8d-0242ac110003-CyQWkovZ-&-Rhe1{6)8Gf token generate success token=MTYyODkyMTg2MC40MTc2OTUzOjUzYjE5ODI0LWZjYzctMTFlYi1hYzhkLTAyNDJhYzE
  14:17:42.676 [dbservice2] INFO 5506e58a-fcc7-11eb-9807-0242ac110003-SZKcrGIR-xPE^X0ln_KYI token generate success token=MTYyODkyMTg2Mi42NzU3MzcxOjU1MDZlNThhLWZjYzctMTFlYi05ODA3LTAyNDJhYzE
  14:17:45.161 [dbservice2] INFO 566316c4-fcc7-11eb-b0a5-0242ac110004-rJyVYctH-ycdLHo!js4Qz token generate success token=MTYyODkyMTg2NS4xNjEzMTE0OjU2NjMxNmM0LWZjYzctMTFlYi1iMGE1LTAyNDJhYzE
  14:17:47.898 [dbservice1] INFO 581ef80c-fcc7-11eb-85a6-0242ac110003-JKhDNmCb-yMn!G#EL?u18 token generate success token=MTYyODkyMTg2Ny44OTc3ODExOjU4MWVmODBjLWZjYzctMTFlYi04NWE2LTAyNDJhYzE
  14:17:50.877 [dbservice1] INFO 59dd12e6-fcc7-11eb-9c07-0242ac110004-vfxYGPRM-*!fkZnj8N{}6 token generate success token=MTYyODkyMTg3MC44NzczMDY3OjU5ZGQxMmU2LWZjYzctMTFlYi05YzA3LTAyNDJhYzE
  14:17:53.583 [mobservice2] INFO info 5bb55790-fcc7-11eb-b33e-0242ac110004:vRBrHTWY write success
  14:17:56.398 [dbservice2] INFO 5d215098-fcc7-11eb-8fd4-0242ac110003-BrtsWueY-U<o(drDvlHsR token generate success token=MTYyODkyMTg3Ni4zOTc3OTQ6NWQyMTUwOTgtZmNjNy0xMWViLThmZDQtMDI0MmFjMTE
  14:17:59.305 [dbservice1] INFO 5edd1908-fcc7-11eb-b578-0242ac110003-jnAxEKot-^>lh?1b+3#G* token generate success token=MTYyODkyMTg3OS4zMDUwNzA5OjVlZGQxOTA4LWZjYzctMTFlYi1iNTc4LTAyNDJhYzE
  14:18:02.398 [dbservice1] INFO 6094ddf8-fcc7-11eb-8e10-0242ac110004-xgKipZPG-}vC$Ij:iYe.8 token generate success token=MTYyODkyMTg4Mi4zOTc3MDkxOjYwOTRkZGY4LWZjYzctMTFlYi04ZTEwLTAyNDJhYzE
  14:18:04.931 [mobservice1] INFO info 62780eb0-fcc7-11eb-ad51-0242ac110003:XutwzNHs write success

## p0429
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:05:36.784Z
```
{"timestamp":1732349136784930300,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST to carts: http://carts/carts/67418cc9a437380001deec1a/items body: {\"itemId\":\"zzz4f044-b040-410d-8ead-4de0446aec7e\",\"unitPrice\":12}"}
```
Same service, the 2 minutes before (oldest first):
  08:05:36.555 [front-end] Merging carts for customer id: 67418cd0a437380001deec2f and session id: txmeyA31gW5KwIa6Q2-GDCo-2cYTbBHW
  08:05:36.608 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418cc9a437380001deec1a"}  (×2)
  08:05:36.623 [front-end] GET /catalogue 200 - ms - -
  08:05:36.623 [front-end] POST /addresses 200 - ms - -  (×2)
  08:05:36.624 [front-end] Carts merged.
  08:05:36.624 [front-end] set cookie67418cd0a437380001deec2f
  08:05:36.626 [front-end] Sent cookies.
  08:05:36.627 [front-end] POST /register 200 77.269 ms - 33
  08:05:36.674 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67418cc9a437380001deec1a"}  (×2)
  08:05:36.681 [front-end] POST /cards 200 - ms - -  (×2)
  08:05:36.734 [front-end] Attempting to delete cart for user: 67418cc9a437380001deec1a  (×2)
  08:05:36.763 [front-end] User cart deleted with status: 503
  08:05:36.766 [front-end] DELETE /cart 503 - ms - -
  08:05:36.773 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  08:05:36.784 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
All services, 30 seconds either side (sampled):
  08:05:16.044 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418cb4a437380001deebd3"}  (×55)
  08:05:16.849 [user] ts=2024-11-23T08:05:16.849255197Z caller=middlewares.go:157 method=Health result=2 took=2.263814ms  (×34)
  08:05:17.265 [front-end] 67418cbda437380001deebef  (×52)
  08:05:17.815 [carts] 2024-11-23 08:05:17.815 INFO [carts,,,] 7 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.11
  08:05:19.529 [front-end] Posting Customer: {"username":"rTqPfAUyTpCsJ","password":"ZZjIx","email":"rTqPfAUyTpCsJ@gmail.com","firstName":"rTqPfAUyTpCsJ","lastName":"rTqPfAUyTpCsJ"}
  08:05:20.716 [queue-master] 2024-11-23 08:05:20.716 INFO 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/**] onto handler of type [class org.springframew
  08:05:23.723 [orders-db] {"t":{"$date":"2024-11-23T08:05:23.723+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173234912
  08:05:26.508 [queue-master] 2024-11-23 08:05:26.508 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal+json || ap
  08:05:26.610 [queue-master] 2024-11-23 08:05:26.609 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[GET],produces=[application  (×2)
  08:05:27.702 [queue-master] 2024-11-23 08:05:27.618 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/json]}" ont
  08:05:27.882 [front-end] Received response: "{\"firstName\":\"JowNHX\",\"lastName\":\"JowNHX\",\"username\":\"JowNHX\",\"id\":\"67418cafa437380001deebbf\",\"_links\":{\"addresses\":{\"h
  08:05:28.832 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×10)
  08:05:30.916 [carts-db] {"t":{"$date":"2024-11-23T08:05:30.915+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:4130
  08:05:32.618 [shipping] 2024-11-23 08:05:32.618 INFO [shipping,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-m
  08:05:35.212 [front-end] Received response: "{\"firstName\":\"SxutBgbVKLVvf\",\"lastName\":\"SxutBgbVKLVvf\",\"username\":\"SxutBgbVKLVvf\",\"id\":\"67418cb9a437380001deebea\",\"_links\
  08:05:37.558 [user] ts=2024-11-23T08:05:37.55870177Z caller=middlewares.go:46 method=Register username=QTNxlk email=QTNxlk@gmail.com took=2.268833ms
  08:05:39.189 [orders] 2024-11-23 08:05:39.189 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[applicat
  08:05:39.196 [orders] 2024-11-23 08:05:39.196 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applica
  08:05:40.568 [user] ts=2024-11-23T08:05:40.568586203Z caller=middlewares.go:46 method=Register username=eqACgmjO email=eqACgmjO@gmail.com took=3.106191ms
  08:05:41.193 [orders] 2024-11-23 08:05:41.193 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[app
  08:05:44.157 [front-end] Posting Customer: {"username":"zFrpP","password":"lvSXmE","email":"zFrpP@gmail.com","firstName":"zFrpP","lastName":"zFrpP"}
  08:05:45.411 [carts] 2024-11-23 08:05:45.411 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  08:05:49.103 [shipping] 2024-11-23 08:05:49.103 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/shipping/{id}],methods=[GET]}" onto public java.l
  08:05:50.653 [front-end] Posting Customer: {"username":"suOMyE","password":"OAliwaK","email":"suOMyE@gmail.com","firstName":"suOMyE","lastName":"suOMyE"}
  08:05:54.899 [shipping] 2024-11-23 08:05:54.899 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produ
  08:05:55.023 [front-end] Posting Customer: {"username":"brTpfrzj","password":"CqouP","email":"brTpfrzj@gmail.com","firstName":"brTpfrzj","lastName":"brTpfrzj"}
  08:05:57.540 [front-end] Posting Customer: {"username":"wgwvbFuCgu","password":"jthSvQsfs","email":"wgwvbFuCgu@gmail.com","firstName":"wgwvbFuCgu","lastName":"wgwvbFuCgu"}
  08:06:00.402 [shipping] 2024-11-23 08:06:00.402 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class
  08:06:03.602 [carts] 2024-11-23 08:06:03.600 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.ac

## p0321
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:21:01.187Z
```
{"timestamp":1732245661187685400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"{ id: '673ff89db0df5c00019b1f53' }"}
```
Same service, the 2 minutes before (oldest first):
  03:20:59.794 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  03:20:59.794 [front-end] POST to carts: http://carts/carts/673ff896b0df5c00019b1f3a/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}
  03:20:59.839 [front-end] POST /cart 500 50.436 ms - 64
  03:21:00.716 [front-end] Posting Customer: {"username":"bDjuXlWHATfWj","password":"ynjkfXmXiY","email":"bDjuXlWHATfWj@gmail.com","firstName":"bDjuXlWHATfWj","lastName":"bDjuXlWHATfWj"}
  03:21:00.722 [front-end] { id: '673ff89cb0df5c00019b1f51' }  (×2)
  03:21:00.722 [front-end] 673ff89cb0df5c00019b1f51  (×2)
  03:21:00.722 [front-end] Merging carts for customer id: 673ff89cb0df5c00019b1f51 and session id: 2ZHmuG_NvfhHugYyZRXyRtQ_1dh2_Zfi  (×2)
  03:21:00.761 [front-end] Carts merged.  (×2)
  03:21:00.761 [front-end] set cookie673ff89cb0df5c00019b1f51  (×2)
  03:21:00.761 [front-end] Sent cookies.  (×2)
  03:21:00.763 [front-end] POST /register 200 45.239 ms - 33  (×2)
  03:21:01.131 [front-end] Posting Customer: {"username":"isaznhmc","password":"PMQNcLZhlo","email":"isaznhmc@gmail.com","firstName":"isaznhmc","lastName":"isaznhmc"}
  03:21:01.182 [front-end] Posting Customer: {"username":"EFvIPXnJWRPmy","password":"UDHAmT","email":"EFvIPXnJWRPmy@gmail.com","firstName":"EFvIPXnJWRPmy","lastName":"EFvIPXnJWRPmy"}
All services, 30 seconds either side (sampled):
  03:20:31.352 [catalogue] ts=2024-11-22T03:20:31Z caller=logging.go:85 method=Health result=2 took=20.054µs  (×40)
  03:20:31.549 [front-end] User cart deleted with status: 503  (×59)
  03:20:31.844 [payment] ts=2024-11-22T03:20:31Z caller=logging.go:40 method=Health result=1 took=6.961µs  (×40)
  03:20:31.972 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×37)
  03:20:33.172 [front-end] Received response: "{\"firstName\":\"uQhCpCJIyYL\",\"lastName\":\"uQhCpCJIyYL\",\"username\":\"uQhCpCJIyYL\",\"id\":\"673ff869b0df5c00019b1ebe\",\"_links\":{\"a
  03:20:36.632 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×9)
  03:20:39.079 [user] ts=2024-11-22T03:20:39.079141282Z caller=middlewares.go:46 method=Register username=ELXzX email=ELXzX@gmail.com took=1.044635ms
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:20:47.926 [front-end] Posting Customer: {"username":"XYDErsNhuY","password":"RuOOlZc","email":"XYDErsNhuY@gmail.com","firstName":"XYDErsNhuY","lastName":"XYDErsNhuY"}
  03:20:49.809 [front-end] Posting Customer: {"username":"YwTYsSUGcmNRsJY","password":"vPzbHQOPY","email":"YwTYsSUGcmNRsJY@gmail.com","firstName":"YwTYsSUGcmNRsJY","lastName":"YwTYsSUGcmN
  03:20:54.897 [front-end] Posting Customer: {"username":"cfTPDbfduekTBf","password":"FQrLzttH","email":"cfTPDbfduekTBf@gmail.com","firstName":"cfTPDbfduekTBf","lastName":"cfTPDbfduekTBf"
  03:20:59.486 [carts] 2024-11-22 03:20:59.485 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.e
  03:20:59.690 [carts] 2024-11-22 03:20:59.690 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/hal+  (×2)
  03:20:59.885 [carts] 2024-11-22 03:20:59.885 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[OPTIONS],produces=[appli
  03:21:02.584 [front-end] Posting Customer: {"username":"sQAAadzpZlKDfq","password":"reYll","email":"sQAAadzpZlKDfq@gmail.com","firstName":"sQAAadzpZlKDfq","lastName":"sQAAadzpZlKDfq"}
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  03:21:04.514 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×2)
  03:21:08.986 [carts] 2024-11-22 03:21:08.986 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  03:21:11.486 [front-end] Posting Customer: {"username":"onbFNMM","password":"YJlvj","email":"onbFNMM@gmail.com","firstName":"onbFNMM","lastName":"onbFNMM"}
  03:21:13.884 [carts] 2024-11-22 03:21:13.884 INFO [carts,,,] 7 --- [p-nio-80-exec-3] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  03:21:15.985 [carts] 2024-11-22 03:21:15.985 INFO [carts,4f4200e92a2346f2,c605b8bba205809d,false] 7 --- [-nio-80-exec-10] w.w.s.cart.controllers.CartsController : Merge carts reques  (×8)
  03:21:18.595 [orders] 2024-11-22 03:21:18.594 INFO [orders,145906930ffa3fb8,359c2f868402564c,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×9)
  03:21:18.617 [front-end] Order response: {"id":"673ff8aed94b9000069b438b","customerId":"673ff896b0df5c00019b1f3b","customer":{"id":null,"firstName":"LNstXzKIIEKneJ","lastName":"LNstXzKI
  03:21:19.192 [carts] java.util.ConcurrentModificationException: null at java.util.HashMap$HashIterator.nextNode(HashMap.java:1437) ~[na:1.8.0_131] at java.util.HashMap$KeyIterator.n
  03:21:19.905 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8afd94b9000069b4393","customerId":"673ff89eb0df5c00019b1f54","customer":{"id":null,"firstName":"gKGbBfBuFal
  03:21:20.490 [carts] 2024-11-22 03:21:20.490 INFO [carts,c68cb8218e3d30a3,e9e627c1a2386c43,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.controllers.ItemsController : Did not find item.  (×8)
  03:21:22.904 [front-end] Order response: {"id":"673ff8b2d94b9000069b439a","customerId":"673ff898b0df5c00019b1f40","customer":{"id":null,"firstName":"TxflHMpaWteY","lastName":"TxflHMpaWt
  03:21:27.105 [front-end] Order response: {"id":"673ff8b7d94b9000069b439d","customerId":"673ff89fb0df5c00019b1f5d","customer":{"id":null,"firstName":"gxEQQKdgPqad","lastName":"gxEQQKdgPq

## p0040
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T07:58:45.503Z
```
{"service":"logservice1","message":"2021-08-13 07:58:45,503 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | 2e7f39eb2d36317 | request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '3a4dfec6-fbc9-11eb-a061-0242ac110003'}"}
```
Same service, the 2 minutes before (oldest first):
  07:58:42.794 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  07:58:42.794 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  07:58:42.795 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '38b3f69c-fbc9-11eb-9a03-0242ac110003'}  (×2)
  07:58:42.859 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×2)
  07:58:42.859 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×2)
  07:58:42.860 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '38b3f69c-fbc9-11eb-9a03-0242ac110003', 'user_id': 'GsgASzin'}  (×4)
  07:58:43.148 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×2)
  07:58:43.148 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×2)
All services, 30 seconds either side (sampled):
  07:58:15.524 [redisservice2] INFO redis读取信息成功, status_code: 200  (×33)
  07:58:15.622 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  07:58:15.902 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '28f38b96-fbc9-11eb-9b74-0242ac110004', 'value': '', 'ex': 10}  (×30)
  07:58:16.119 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×38)
  07:58:16.275 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '28f38b96-fbc9-11eb-9b74-0242ac110004'}  (×37)
  07:58:16.701 [redisservice1] INFO redis write success  (×69)
  07:58:16.867 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '2966e05a-fbc9-11eb-9a77-0242ac110003'}  (×29)
  07:58:17.118 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×29)
  07:58:17.345 [dbservice2] INFO 296504ba-fbc9-11eb-bb2a-0242ac110004-RVxXNljY-cDs.FlES+XiZ token generate success token=MTYyODgxMjY5Ny4zNDQ0NDM2OjI5NjUwNGJhLWZiYzktMTFlYi1iYjJhLTAyNDJhYzE
  07:58:19.264 [mobservice1] INFO info 2ac4da60-fbc9-11eb-aca1-0242ac110003:EJMXPwRO write success
  07:58:25.584 [dbservice1] INFO 2e566914-fbc9-11eb-96f4-0242ac110004-kWcbAndl-+K)#TtAh_eL$ token generate success token=MTYyODgxMjcwNS41ODM3ODY6MmU1NjY5MTQtZmJjOS0xMWViLTk2ZjQtMDI0MmFjMTE
  07:58:31.096 [logservice2] ERROR uuid expired, invalid phone request
  07:58:32.631 [dbservice2] INFO 3287a0ac-fbc9-11eb-991a-0242ac110004-ITinMyWu-yv/ef>@J!O?L token generate success token=MTYyODgxMjcxMi42MzEyNzE2OjMyODdhMGFjLWZiYzktMTFlYi05OTFhLTAyNDJhYzE  (×2)
  07:58:34.784 [mobservice1] INFO info 3401f9dc-fbc9-11eb-b843-0242ac110004:lGPfCvhn write success
  07:58:37.197 [dbservice1] INFO 35383c4e-fbc9-11eb-aea4-0242ac110003-mCkaEIVe-%4QxON(snAYv token generate success token=MTYyODgxMjcxNy4xOTY3NjY2OjM1MzgzYzRlLWZiYzktMTFlYi1hZWE0LTAyNDJhYzE
  07:58:39.680 [mobservice2] INFO info 36ed6000-fbc9-11eb-b87e-0242ac110004:eVrbptqN write success
  07:58:41.679 [dbservice1] INFO 37eaac24-fbc9-11eb-9255-0242ac110004-GRzjnWha-YXV0E=(>a1MP token generate success token=MTYyODgxMjcyMS42Nzk0NDIyOjM3ZWFhYzI0LWZiYzktMTFlYi05MjU1LTAyNDJhYzE
  07:58:43.766 [mobservice2] INFO info 395c4306-fbc9-11eb-92d6-0242ac110003:ZPMYDESe write success
  07:58:46.038 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  07:58:48.615 [dbservice2] INFO 3bfb679a-fbc9-11eb-91d5-0242ac110004-DhKfSuMF-Vc<a5J!Q>m{2 token generate success token=MTYyODgxMjcyOC42MTQ5NDg6M2JmYjY3OWEtZmJjOS0xMWViLTkxZDUtMDI0MmFjMTE
  07:58:59.959 [mobservice1] INFO info 42fa4df4-fbc9-11eb-899c-0242ac110004:yfLskzJE write success
  07:59:01.468 [mobservice2] INFO info 43e95688-fbc9-11eb-8ecc-0242ac110004:kHIDhMnd write success
  07:59:03.544 [dbservice1] INFO 44eb27c8-fbc9-11eb-8d5c-0242ac110003-zShwUfFn-^YekX}_z?E-@ token generate success token=MTYyODgxMjc0My41NDQyNDE6NDRlYjI3YzgtZmJjOS0xMWViLThkNWMtMDI0MmFjMTE
  07:59:06.605 [mobservice2] INFO info 46ed736e-fbc9-11eb-aa30-0242ac110004:GsgASzin write success
  07:59:09.254 [mobservice2] INFO info 488f41a2-fbc9-11eb-91df-0242ac110004:ocwNidgD write success
  07:59:11.837 [mobservice1] INFO info 4a12a96a-fbc9-11eb-9e5c-0242ac110003:rREWnpxD write success
  07:59:14.211 [mobservice2] INFO info 4b841482-fbc9-11eb-9748-0242ac110003:VpEUCejs write success

## p0412
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:57:48.183Z
```
{"timestamp":1732247868183687700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"{ id: '6740013cb0df5c00019b39ad' }"}
```
Same service, the 2 minutes before (oldest first):
  03:57:47.544 [front-end] POST /addresses 200 - ms - -
  03:57:47.550 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67400135b0df5c00019b399c"}
  03:57:47.560 [front-end] POST /cards 200 - ms - -
  03:57:47.567 [front-end] Posting Customer: {"username":"eHeVJdkwq","password":"mOQPwcle","email":"eHeVJdkwq@gmail.com","firstName":"eHeVJdkwq","lastName":"eHeVJdkwq"}
  03:57:47.572 [front-end] { id: '6740013bb0df5c00019b39ac' }
  03:57:47.572 [front-end] 6740013bb0df5c00019b39ac
  03:57:47.572 [front-end] Merging carts for customer id: 6740013bb0df5c00019b39ac and session id: nmB5ZDVT-s55QBYaKD6IyCGGAhPK9E7S
  03:57:47.594 [front-end] Carts merged.
  03:57:47.594 [front-end] set cookie6740013bb0df5c00019b39ac
  03:57:47.594 [front-end] Sent cookies.
  03:57:47.597 [front-end] POST /register 200 27.764 ms - 33
  03:57:47.606 [front-end] Attempting to delete cart for user: 67400135b0df5c00019b399c
  03:57:47.625 [front-end] User cart deleted with status: 202
  03:57:47.627 [front-end] DELETE /cart 202 - ms - -
  03:57:47.632 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  03:57:47.638 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  03:57:47.638 [front-end] POST to carts: http://carts/carts/67400135b0df5c00019b399c/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  03:57:47.678 [front-end] POST /cart 201 - ms - -
  03:57:47.938 [front-end] GET /catalogue 200 - ms - -
  03:57:48.177 [front-end] Posting Customer: {"username":"vpZYBKaZIHAIOS","password":"EHbTKzs","email":"vpZYBKaZIHAIOS@gmail.com","firstName":"vpZYBKaZIHAIOS","lastName":"vpZYBKaZIHAIOS"}
All services, 30 seconds either side (sampled):
  03:57:18.354 [front-end] Request received with body: {}  (×61)
  03:57:18.396 [payment] ts=2024-11-22T03:57:18Z caller=logging.go:29 method=Authorise result=true took=835ns  (×43)
  03:57:18.685 [orders] 2024-11-22 03:57:18.685 INFO [orders,7e55acd07c68f6ad,5bf00352b1fd494a,false] 6 --- [p-nio-80-exec-3] w.w.s.o.controllers.OrdersController : Sending payment req  (×37)
  03:57:19.685 [front-end] Merging carts for customer id: 6740011fb0df5c00019b3955 and session id: fJGQ9tm9T3i765bvDhYEQkAa-KdqWGO7  (×62)
  03:57:20.017 [front-end] POST /cards 200 - ms - -  (×60)
  03:57:20.390 [front-end] POST /cart 201 - ms - -  (×60)
  03:57:22.429 [front-end] POST to carts: http://carts/carts/67400118b0df5c00019b3941/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}  (×14)
  03:57:23.532 [user] ts=2024-11-22T03:57:23.531819943Z caller=middlewares.go:134 method=GetCards id=67400115b0df5c00019b393b result=1 took=1.019145ms  (×6)
  03:57:25.620 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×11)
  03:57:28.454 [front-end] Order response: {"id":"67400128d94b9000069b4a25","customerId":"67400114b0df5c00019b3936","customer":{"id":null,"firstName":"xskgCemBiTe","lastName":"xskgCemBiTe
  03:57:30.491 [front-end] Received response: "{\"firstName\":\"eahACWzBqwawb\",\"lastName\":\"eahACWzBqwawb\",\"username\":\"eahACWzBqwawb\",\"id\":\"67400118b0df5c00019b3941\",\"_links\
  03:57:32.575 [user] ts=2024-11-22T03:57:32.575277178Z caller=middlewares.go:46 method=Register username=RXENyGXhV email=RXENyGXhV@gmail.com took=1.066125ms
  03:57:36.810 [front-end] Order response: {"id":"67400130d94b9000069b4a2c","customerId":"67400120b0df5c00019b395a","customer":{"id":null,"firstName":"NWbjXIJxYwnn","lastName":"NWbjXIJxYw
  03:57:37.806 [front-end] Order response: {"id":"67400131d94b9000069b4a30","customerId":"6740011db0df5c00019b3954","customer":{"id":null,"firstName":"tcxDLRJCiCCkwhk","lastName":"tcxDLRJ
  03:57:40.515 [front-end] Received response: "{\"firstName\":\"BVPVLIgWiCfc\",\"lastName\":\"BVPVLIgWiCfc\",\"username\":\"BVPVLIgWiCfc\",\"id\":\"6740011bb0df5c00019b394c\",\"_links\":{
  03:57:42.318 [queue-master] 2024-11-22 03:57:42.318 INFO 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×9)
  03:57:43.995 [front-end] Received response: "{\"firstName\":\"FDKLfQUyqzsLkUp\",\"lastName\":\"FDKLfQUyqzsLkUp\",\"username\":\"FDKLfQUyqzsLkUp\",\"id\":\"6740011bb0df5c00019b394d\",\"_
  03:57:47.014 [front-end] Posting Customer: {"username":"jvGQnYS","password":"cDMibwYwt","email":"jvGQnYS@gmail.com","firstName":"jvGQnYS","lastName":"jvGQnYS"}
  03:57:50.545 [front-end] Order response: {"id":"6740013ed94b9000069b4a3c","customerId":"6740012ab0df5c00019b397f","customer":{"id":null,"firstName":"kIvFHHPwH","lastName":"kIvFHHPwH","u
  03:57:52.046 [front-end] Received response: "{\"firstName\":\"cEkyOf\",\"lastName\":\"cEkyOf\",\"username\":\"cEkyOf\",\"id\":\"6740012fb0df5c00019b398c\",\"_links\":{\"addresses\":{\"h
  03:57:53.837 [user] ts=2024-11-22T03:57:53.83700732Z caller=middlewares.go:46 method=Register username=DDLufdlFX email=DDLufdlFX@gmail.com took=1.091379ms
  03:57:58.149 [front-end] Posting Customer: {"username":"YkyyyvHObBrHr","password":"KrPBTxQOJZ","email":"YkyyyvHObBrHr@gmail.com","firstName":"YkyyyvHObBrHr","lastName":"YkyyyvHObBrHr"}
  03:58:01.216 [front-end] Received response: "{\"firstName\":\"jvGQnYS\",\"lastName\":\"jvGQnYS\",\"username\":\"jvGQnYS\",\"id\":\"6740013bb0df5c00019b39a9\",\"_links\":{\"addresses\":{
  03:58:06.660 [front-end] Received response: "{\"firstName\":\"xhwoPx\",\"lastName\":\"xhwoPx\",\"username\":\"xhwoPx\",\"id\":\"67400139b0df5c00019b39a4\",\"_links\":{\"addresses\":{\"h
  03:58:08.211 [front-end] Posting Customer: {"username":"OldnswfuTa","password":"ctLfthwGbu","email":"OldnswfuTa@gmail.com","firstName":"OldnswfuTa","lastName":"OldnswfuTa"}
  03:58:10.097 [front-end] Received response: "{\"firstName\":\"UmLwUlE\",\"lastName\":\"UmLwUlE\",\"username\":\"UmLwUlE\",\"id\":\"67400138b0df5c00019b39a3\",\"_links\":{\"addresses\":{
  03:58:12.392 [front-end] Received response: "{\"firstName\":\"bokgcsONP\",\"lastName\":\"bokgcsONP\",\"username\":\"bokgcsONP\",\"id\":\"6740013db0df5c00019b39b0\",\"_links\":{\"address
  03:58:15.273 [front-end] Received response: "{\"firstName\":\"EtbzCjsmRI\",\"lastName\":\"EtbzCjsmRI\",\"username\":\"EtbzCjsmRI\",\"id\":\"6740013fb0df5c00019b39b8\",\"_links\":{\"addr
  03:58:17.081 [front-end] Order response: {"id":"67400159d94b9000069b4a55","customerId":"67400141b0df5c00019b39bf","customer":{"id":null,"firstName":"rWUHZXNTJK","lastName":"rWUHZXNTJK",

## p0442
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T08:06:05.306Z
```
{"timestamp":1732349165306054700,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:05.304  INFO [carts,,,] 7 --- [           main] o.s.w.s.handler.SimpleUrlHandlerMapping  : Mapped URL path [/webjars/**] onto handler of type [class org.springframework.web.servlet.resource.ResourceHttpRequestHandler]"}
```
Same service, the 2 minutes before (oldest first):
  08:05:27.911 [carts] 2024-11-23 08:05:27.911 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'applicationContextIdFilter' to: [/*]
  08:05:27.911 [carts] 2024-11-23 08:05:27.911 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'metricsServlet' to [/metrics]
  08:05:27.912 [carts] 2024-11-23 08:05:27.912 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  08:05:30.210 [carts] 2024-11-23 08:05:30.209 INFO [carts,,,] 7 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[carts-db:27017], mode=SINGLE, requiredC
  08:05:31.799 [carts] 2024-11-23 08:05:31.799 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:1}] to
  08:05:31.806 [carts] 2024-11-23 08:05:31.806 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  08:05:45.411 [carts] 2024-11-23 08:05:45.411 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  08:06:00.413 [carts] 2024-11-23 08:06:00.413 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  08:06:00.500 [carts] 2024-11-23 08:06:00.500 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[DE
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[GET],produces=
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}/merge],methods=[GET]}" onto publi
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[GET],produces=[applicat
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.spring
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  08:06:03.410 [carts] 2024-11-23 08:06:03.409 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  08:06:03.602 [carts] 2024-11-23 08:06:03.600 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.ac
All services, 30 seconds either side (sampled):
  08:05:35.373 [front-end] Request received with body: {}  (×63)
  08:05:35.510 [front-end] set cookie67418ccfa437380001deec29  (×66)
  08:05:35.883 [front-end] Received response: "{\"firstName\":\"yxWEkBiarOEcFPl\",\"lastName\":\"yxWEkBiarOEcFPl\",\"username\":\"yxWEkBiarOEcFPl\",\"id\":\"67418cb6a437380001deebd8\",\"_
  08:05:37.554 [front-end] Posting Customer: {"username":"QTNxlk","password":"qwbekCU","email":"QTNxlk@gmail.com","firstName":"QTNxlk","lastName":"QTNxlk"}
  08:05:39.188 [orders] 2024-11-23 08:05:39.188 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[OPTIONS],produces=[application
  08:05:39.196 [orders] 2024-11-23 08:05:39.196 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[OPTIONS],produces=[appl
  08:05:40.562 [front-end] Posting Customer: {"username":"eqACgmjO","password":"JpDGtXlzCs","email":"eqACgmjO@gmail.com","firstName":"eqACgmjO","lastName":"eqACgmjO"}
  08:05:41.194 [orders] 2024-11-23 08:05:41.193 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public ja
  08:05:44.588 [orders] 2024-11-23 08:05:44.587 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:05:46.357 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×8)
  08:05:49.486 [orders] 2024-11-23 08:05:49.394 ERROR [orders,,,] 8 --- [p-nio-80-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×39)
  08:05:51.461 [front-end] Posting Customer: {"username":"JfkloKMY","password":"BAlPTCaswY","email":"JfkloKMY@gmail.com","firstName":"JfkloKMY","lastName":"JfkloKMY"}
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/jso
  08:05:56.815 [front-end] Received response: "{\"firstName\":\"WoyOvB\",\"lastName\":\"WoyOvB\",\"username\":\"WoyOvB\",\"id\":\"67418ccfa437380001deec29\",\"_links\":{\"addresses\":{\"h
  08:05:59.718 [user] ts=2024-11-23T08:05:59.718194949Z caller=middlewares.go:46 method=Register username=RKNDdSk email=RKNDdSk@gmail.com took=3.379621ms
  08:06:02.425 [front-end] Posting Customer: {"username":"vZvbgNwwdo","password":"cAEgTMr","email":"vZvbgNwwdo@gmail.com","firstName":"vZvbgNwwdo","lastName":"vZvbgNwwdo"}
  08:06:06.916 [carts] 2024-11-23 08:06:06.915 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class or
  08:06:07.007 [shipping] 2024-11-23 08:06:07.007 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT
  08:06:07.614 [user] ts=2024-11-23T08:06:07.614423361Z caller=middlewares.go:46 method=Register username=ucodWkVEg email=ucodWkVEg@gmail.com took=3.000643ms
  08:06:13.834 [front-end] Received response: "{\"firstName\":\"bzxtLtBzUaRfo\",\"lastName\":\"bzxtLtBzUaRfo\",\"username\":\"bzxtLtBzUaRfo\",\"id\":\"67418ce5a437380001deec6f\",\"_links\
  08:06:15.701 [carts] 2024-11-23 08:06:15.701 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[application/hal+json || 
  08:06:15.809 [carts] 2024-11-23 08:06:15.809 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[applicat
  08:06:16.439 [user] ts=2024-11-23T08:06:16.439397099Z caller=middlewares.go:46 method=Register username=GXUtAA email=GXUtAA@gmail.com took=2.399304ms
  08:06:19.009 [carts] 2024-11-23 08:06:19.009 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  08:06:21.669 [front-end] Posting Customer: {"username":"suxeYRw","password":"WiFMBG","email":"suxeYRw@gmail.com","firstName":"suxeYRw","lastName":"suxeYRw"}
  08:06:24.503 [carts] 2024-11-23 08:06:24.503 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as MB
  08:06:27.104 [carts] 2024-11-23 08:06:27.103 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:06:30.456 [front-end] Received response: "{\"firstName\":\"SPVlWNNsjeesK\",\"lastName\":\"SPVlWNNsjeesK\",\"username\":\"SPVlWNNsjeesK\",\"id\":\"67418cf2a437380001deec94\",\"_links\
  08:06:32.729 [orders] 2024-11-23 08:06:32.728 INFO [orders,fbcebf8ef5e82428,6d050ec4f8a03a61,false] 8 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Sending payment req  (×4)
  08:06:34.501 [shipping] Adding shipment to queue...  (×5)

## p0487
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-23T08:57:04.182Z, and 2 identical event(s) in the same minute
```
{"timestamp":1732352224182155000,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-zmfhr","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:57:04.181  INFO 7 --- [pool-6-thread-7] o.apache.http.impl.execchain.RetryExec   : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught when processing request to {}->unix://localhost:80: No such file or directory"}
```
Same service, the 2 minutes before (oldest first):
  08:57:00.960 [queue-master] Received shipment task: 674198c2a437380001deff4e  (×3)
  08:57:00.960 [queue-master] 2024-11-23 08:57:00.960 INFO 7 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×3)
  08:57:00.961 [queue-master] 2024-11-23 08:57:00.960 INFO 7 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×6)
  08:57:00.961 [queue-master] 2024-11-23 08:57:00.960 INFO 7 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×6)
  08:57:00.961 [queue-master] 2024-11-23 08:57:00.961 ERROR 7 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×2)
All services, 30 seconds either side (sampled):
  08:56:58.007 [catalogue] ts=2024-11-23T08:56:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.869902ms  (×39)
  08:56:58.018 [orders] 2024-11-23 08:56:58.018 INFO [orders,6baef7816fdf67ff,4dc9cbe9bd6cff45,false] 8 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Received payment re  (×28)
  08:56:58.029 [front-end] Order response: {"statusCode":201,"body":{"id":"674198da3f77060008865384","customerId":"674198bfa437380001deff45","customer":{"id":null,"firstName":"ztfESzW","l
  08:56:59.388 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674198d3a437380001deff98"}  (×34)
  08:56:59.483 [catalogue] ts=2024-11-23T08:56:59Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.990138  (×31)
  08:57:00.720 [front-end] Request received with body: {}  (×29)
  08:57:00.744 [front-end] Posting Order: {"customer":"http://user/customers/674198caa437380001deff7c","address":"http://user/addresses/674198d0a437380001deff90","card":"http://user/cards  (×29)
  08:57:01.048 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  08:57:01.165 [front-end] 674198dda437380001deffa9  (×37)
  08:57:02.787 [front-end] Received response: "{\"firstName\":\"iEYCUjoH\",\"lastName\":\"iEYCUjoH\",\"username\":\"iEYCUjoH\",\"id\":\"674198c5a437380001deff67\",\"_links\":{\"addresses\
  08:57:03.057 [front-end] Order response: {"statusCode":201,"body":{"id":"674198df3f77060008865387","customerId":"674198caa437380001deff7e","customer":{"id":null,"firstName":"qzkCXXFW","
  08:57:04.140 [front-end] Received response: "{\"firstName\":\"TlHaLWqJVqW\",\"lastName\":\"TlHaLWqJVqW\",\"username\":\"TlHaLWqJVqW\",\"id\":\"674198d0a437380001deff92\",\"_links\":{\"a
  08:57:05.392 [orders] 2024-11-23 08:57:05.392 INFO [orders,3c526066b205402a,acb1c0fc61191c83,false] 8 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×2)
  08:57:07.035 [front-end] Order response: {"statusCode":201,"body":{"id":"674198e33f7706000886538a","customerId":"674198caa437380001deff7d","customer":{"id":null,"firstName":"vidoaLMiMZn
  08:57:08.980 [queue-master] 2024-11-23 08:57:08.980 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×57)
  08:57:09.152 [front-end] Order response: {"id":"674198e53f7706000886538c","customerId":"674198d2a437380001deff95","customer":{"id":null,"firstName":"zUGYrCgol","lastName":"zUGYrCgol","u
  08:57:11.533 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×6)
  08:57:13.005 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  08:57:14.121 [front-end] Posting Customer: {"username":"JCYeKSjM","password":"MYIoBCiY","email":"JCYeKSjM@gmail.com","firstName":"JCYeKSjM","lastName":"JCYeKSjM"}
  08:57:15.678 [front-end] Order response: {"id":"674198eb3f7706000886538f","customerId":"674198cfa437380001deff8c","customer":{"id":null,"firstName":"FygEtnQmntW","lastName":"FygEtnQmntW
  08:57:18.424 [user] ts=2024-11-23T08:57:18.424838811Z caller=middlewares.go:46 method=Register username=bqLFOFtK email=bqLFOFtK@gmail.com took=2.548455ms
  08:57:19.305 [front-end] Received response: "{\"firstName\":\"aXWRmKRnN\",\"lastName\":\"aXWRmKRnN\",\"username\":\"aXWRmKRnN\",\"id\":\"674198d9a437380001deffa4\",\"_links\":{\"address
  08:57:22.096 [front-end] Posting Customer: {"username":"ErqkMC","password":"qwrMe","email":"ErqkMC@gmail.com","firstName":"ErqkMC","lastName":"ErqkMC"}
  08:57:24.110 [front-end] Order response: {"id":"674198f43f77060008865392","customerId":"674198dfa437380001deffad","customer":{"id":null,"firstName":"wqgJPHku","lastName":"wqgJPHku","use
  08:57:25.404 [front-end] Order response: {"id":"674198f53f77060008865393","customerId":"674198e2a437380001deffb0","customer":{"id":null,"firstName":"tVFCKe","lastName":"tVFCKe","usernam
  08:57:26.581 [front-end] Received response: "{\"firstName\":\"aQTVfKPpOQTV\",\"lastName\":\"aQTVfKPpOQTV\",\"username\":\"aQTVfKPpOQTV\",\"id\":\"674198e5a437380001deffb4\",\"_links\":{
  08:57:27.415 [front-end] Order response: {"statusCode":201,"body":{"id":"674198f73f77060008865398","customerId":"674198dda437380001deffa9","customer":{"id":null,"firstName":"eWMmgZPhWLI
  08:57:30.058 [front-end] Order response: {"id":"674198fa3f77060008865399","customerId":"674198e7a437380001deffbe","customer":{"id":null,"firstName":"bVfUCqC","lastName":"bVfUCqC","usern
  08:57:30.866 [front-end] Order response: {"statusCode":201,"body":{"id":"674198fa3f7706000886539b","customerId":"674198e9a437380001deffc1","customer":{"id":null,"firstName":"KHUge","las
  08:57:32.948 [front-end] Received response: "{\"firstName\":\"gaGGCw\",\"lastName\":\"gaGGCw\",\"username\":\"gaGGCw\",\"id\":\"674198e9a437380001deffc3\",\"_links\":{\"addresses\":{\"h
