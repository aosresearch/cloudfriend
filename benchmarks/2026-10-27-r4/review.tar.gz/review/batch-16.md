## p0440
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service shipping, 2024-11-23T08:05:59.808Z
```
{"timestamp":1732349159808411400,"container_name":"shipping","pod_name":"shipping-58b65f576-rlt9r","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:05:59.808  INFO [shipping,,,] 7 --- [           main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframework.boot.actuate.autoconfigure.EndpointWebMvcHypermediaManagementContextConfiguration$ActuatorEndpointLinksAdvice"}
```
Same service, the 2 minutes before (oldest first):
  08:05:54.905 [shipping] 2024-11-23 08:05:54.905 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[a
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" on
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/jso
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto publi
  08:05:54.910 [shipping] 2024-11-23 08:05:54.910 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[applicati
  08:05:54.911 [shipping] 2024-11-23 08:05:54.911 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public 
  08:05:55.000 [shipping] 2024-11-23 08:05:55.000 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/js
  08:05:55.002 [shipping] 2024-11-23 08:05:55.002 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application
  08:05:55.008 [shipping] 2024-11-23 08:05:55.007 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applica
  08:05:55.102 [shipping] 2024-11-23 08:05:55.102 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object or
  08:05:55.103 [shipping] 2024-11-23 08:05:55.102 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map
  08:05:55.103 [shipping] 2024-11-23 08:05:55.103 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto publi
  08:05:57.198 [shipping] 2024-11-23 08:05:57.110 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.cont
  08:05:57.302 [shipping] 2024-11-23 08:05:57.301 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot
  08:05:59.414 [shipping] 2024-11-23 08:05:59.414 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org
  08:05:59.414 [shipping] 2024-11-23 08:05:59.414 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springf
  08:05:59.414 [shipping] 2024-11-23 08:05:59.414 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/browser/**] onto handler of type [class org
  08:05:59.414 [shipping] 2024-11-23 08:05:59.414 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.
  08:05:59.498 [shipping] 2024-11-23 08:05:59.498 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/**] onto handler of type [class or
  08:05:59.808 [shipping] 2024-11-23 08:05:59.808 INFO [shipping,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptio
All services, 30 seconds either side (sampled):
  08:05:29.822 [front-end] POST /cart 500 64.951 ms - 64  (×56)
  08:05:30.210 [carts] 2024-11-23 08:05:30.209 INFO [carts,,,] 7 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[carts-db:27017], mode=SINGLE, requiredC
  08:05:30.742 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×5)
  08:05:31.584 [front-end] POST /register 200 35.721 ms - 33  (×58)
  08:05:32.693 [orders] 2024-11-23 08:05:32.693 INFO [orders,,,] 8 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.sp
  08:05:36.136 [front-end] Posting Customer: {"username":"eevJWmvw","password":"BjJzd","email":"eevJWmvw@gmail.com","firstName":"eevJWmvw","lastName":"eevJWmvw"}
  08:05:38.884 [orders] 2024-11-23 08:05:38.883 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.
  08:05:39.192 [orders] 2024-11-23 08:05:39.192 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[D
  08:05:39.286 [orders] 2024-11-23 08:05:39.286 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframewo
  08:05:41.192 [orders] 2024-11-23 08:05:41.191 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]
  08:05:43.566 [user] ts=2024-11-23T08:05:43.565925822Z caller=middlewares.go:46 method=Register username=lRmvkfemO email=lRmvkfemO@gmail.com took=2.334851ms
  08:05:45.411 [carts] 2024-11-23 08:05:45.411 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  08:05:49.107 [shipping] 2024-11-23 08:05:49.106 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.spr
  08:05:50.934 [front-end] Received response: "{\"firstName\":\"COYVDutH\",\"lastName\":\"COYVDutH\",\"username\":\"COYVDutH\",\"id\":\"67418cd0a437380001deec2f\",\"_links\":{\"addresses\
  08:05:54.905 [shipping] 2024-11-23 08:05:54.905 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produce
  08:05:55.766 [front-end] Received response: "{\"firstName\":\"pSeQWyL\",\"lastName\":\"pSeQWyL\",\"username\":\"pSeQWyL\",\"id\":\"67418cd0a437380001deec2e\",\"_links\":{\"addresses\":{
  08:05:59.415 [user] ts=2024-11-23T08:05:59.414942526Z caller=middlewares.go:46 method=Register username=VWRTM email=VWRTM@gmail.com took=2.20228ms
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  08:06:06.402 [carts] 2024-11-23 08:06:06.401 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframewo  (×2)
  08:06:07.005 [shipping] 2024-11-23 08:06:07.005 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[DELETE],produces=[appli
  08:06:07.105 [shipping] 2024-11-23 08:06:07.105 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.ht
  08:06:12.629 [front-end] Received response: "{\"firstName\":\"WUyAw\",\"lastName\":\"WUyAw\",\"username\":\"WUyAw\",\"id\":\"67418cdea437380001deec56\",\"_links\":{\"addresses\":{\"href
  08:06:15.130 [front-end] Received response: "{\"firstName\":\"RSyStLrwvSRDG\",\"lastName\":\"RSyStLrwvSRDG\",\"username\":\"RSyStLrwvSRDG\",\"id\":\"67418ce1a437380001deec62\",\"_links\
  08:06:15.805 [carts] 2024-11-23 08:06:15.805 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[GET],produces=[  (×2)
  08:06:16.401 [shipping] 2024-11-23 08:06:16.400 INFO [shipping,,,] 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase -2147482648
  08:06:19.007 [carts] 2024-11-23 08:06:19.007 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  08:06:19.545 [front-end] Received response: "{\"firstName\":\"OoyLttGBfsWv\",\"lastName\":\"OoyLttGBfsWv\",\"username\":\"OoyLttGBfsWv\",\"id\":\"67418ce1a437380001deec60\",\"_links\":{
  08:06:24.200 [carts] 2024-11-23 08:06:24.200 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  08:06:26.760 [front-end] Posting Customer: {"username":"KGcCpZnH","password":"FAILN","email":"KGcCpZnH@gmail.com","firstName":"KGcCpZnH","lastName":"KGcCpZnH"}
  08:06:29.800 [carts] 2024-11-23 08:06:29.798 INFO [carts,4ee08e3c3ce93187,01402718e8b4a256,false] 7 --- [-nio-80-exec-10] w.w.s.cart.controllers.CartsController : Merge carts reques

## p0587
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:50.472Z
```
{"timestamp":1733596310472259800,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:50.471  INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl       : nullUSER TOKEN"}
```
Same service, the 2 minutes before (oldest first):
  18:31:41.179 [ts-auth-service] 2024-12-07 18:31:41.178 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×4)
  18:31:41.179 [ts-auth-service] 2024-12-07 18:31:41.178 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×4)
  18:31:45.207 [ts-auth-service] 2024-12-07 18:31:45.207 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×2)
  18:31:45.207 [ts-auth-service] 2024-12-07 18:31:45.207 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
  18:31:45.547 [ts-auth-service] 2024-12-07 18:31:45.547 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  18:31:45.547 [ts-auth-service] 2024-12-07 18:31:45.547 INFO 1 --- [io-12340-exec-8] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×2)
  18:31:49.989 [ts-auth-service] 2024-12-07 18:31:49.989 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null
  18:31:49.989 [ts-auth-service] 2024-12-07 18:31:49.989 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:31:50.181 [ts-auth-service] 2024-12-07 18:31:50.180 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  18:31:50.181 [ts-auth-service] 2024-12-07 18:31:50.181 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID
All services, 30 seconds either side (sampled):
  18:31:20.890 [ts-travel-service] 2024-12-07 18:31:20.889 ERROR 1 --- [io-12346-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×4)
  18:31:20.993 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:20 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 500 227 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×4)
  18:31:21.810 [ts-order-other-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×2)
  18:31:21.872 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:21 +0800] "GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1" 200 202 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×11)
  18:31:25.386 [ts-auth-service] 2024-12-07 18:31:25.386 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×22)
  18:31:25.408 [ts-travel2-service] 2024-12-07 18:31:25.407 ERROR 1 --- [io-16346-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×13)
  18:31:25.412 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:25 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 500 228 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×15)
  18:31:27.478 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-07T18:31:27.477+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:27.588 [ts-route-mongo] {"t":{"$date":"2024-12-07T18:31:27.588+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.268 [ts-admin-travel-service] 2024-12-07 18:31:28.268 ERROR 1 --- [io-16114-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×10)
  18:31:28.271 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:28 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 500 233 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×12)
  18:31:29.436 [ts-assurance-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×3)
  18:31:29.867 [ts-food-mongo] {"t":{"$date":"2024-12-07T18:31:29.867+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:29.897 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T18:31:29.896+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:30.519 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T18:31:30.518+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:30.725 [ts-notification-mongo] {"t":{"$date":"2024-12-07T18:31:30.725+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:31.064 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×3)
  18:31:31.701 [ts-order-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  18:31:32.290 [ts-admin-basic-info-service] 2024-12-07 18:31:32.289 ERROR 1 --- [io-18767-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×20)
  18:31:38.105 [ts-admin-travel-service] 2024-12-07 18:31:38.104 ERROR 1 --- [o-16114-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×2)
  18:31:42.161 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T18:31:42.161+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359630
  18:31:42.230 [ts-train-mongo] {"t":{"$date":"2024-12-07T18:31:42.230+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359630
  18:31:45.770 [ts-travel2-service] 2024-12-07 18:31:45.770 ERROR 1 --- [o-16346-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×2)
  18:31:51.505 [ts-food-service] 2024-12-07 18:31:51.504 ERROR 1 --- [io-18856-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  18:32:08.507 [ts-auth-service] 2024-12-07 18:32:08.507 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null

## p0696
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-12T11:27:15.528Z
```
{"service":"webservice2","message":"2021-08-12 11:27:15,528 | ERROR | 0.0.0.3 | 172.17.0.4 | webservice2 | 8323924312201852 | an error occurred in the downstream service"}
```
Same service, the 2 minutes before (oldest first):
  11:27:13.873 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×3)
  11:27:13.873 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '2fc0556e-fb1d-11eb-a07c-0242ac110004', 'value': '', 'ex': 10}  (×3)
  11:27:13.931 [webservice2] INFO uuid: 2fc0556e-fb1d-11eb-a07c-0242ac110004 write redis successfully  (×3)
  11:27:14.035 [webservice2] INFO complete information: {'uuid': '2fc0556e-fb1d-11eb-a07c-0242ac110004', 'user_id': 'YXLKvufE'}  (×3)
  11:27:14.042 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×3)
  11:27:14.053 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  11:27:14.268 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
All services, 30 seconds either side (sampled):
  11:26:45.529 [redisservice1] INFO redis读取信息成功, status_code: 200  (×45)
  11:26:45.639 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×39)
  11:26:45.880 [mobservice2] ERROR uuid:18557904-fb1d-11eb-a3c5-0242ac110004 information has expired, mobile phone login is invalid
  11:26:46.085 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×40)
  11:26:46.377 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '1f30050a-fb1d-11eb-9c43-0242ac110003', 'value': 'MZHWTqUt'}  (×47)
  11:26:46.626 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×42)
  11:26:47.162 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '1fb17fc2-fb1d-11eb-837c-0242ac110003'}  (×36)
  11:26:47.974 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '20504828-fb1d-11eb-89e8-0242ac110004', 'value': '', 'ex': 10}  (×43)
  11:26:48.735 [dbservice2] INFO 20504828-fb1d-11eb-89e8-0242ac110004-MGClVmwF-=l9b/XFzu&>h token generate success token=MTYyODczODgwOC43MzU1Mjg1OjIwNTA0ODI4LWZiMWQtMTFlYi04OWU4LTAyNDJhYzE
  11:26:51.589 [dbservice1] INFO 21ddfcda-fb1d-11eb-bec0-0242ac110004-mgvTPLKy-UE!Q+o#:Kz9% token generate success token=MTYyODczODgxMS41ODkxMzM3OjIxZGRmY2RhLWZiMWQtMTFlYi1iZWMwLTAyNDJhYzE
  11:26:54.343 [mobservice1] INFO info 23e64d3e-fb1d-11eb-85a5-0242ac110003:hHIokWie write success
  11:26:57.166 [mobservice1] INFO info 258f7f0c-fb1d-11eb-ba8f-0242ac110004:OKolGsUM write success
  11:27:00.132 [mobservice1] INFO info 2750ffdc-fb1d-11eb-91f6-0242ac110004:gtLKWOSc write success
  11:27:03.236 [dbservice2] INFO 29093146-fb1d-11eb-bdbc-0242ac110004-MZHWTqUt-o=&s{Fle_%PY token generate success token=MTYyODczODgyMy4yMzYxNzgyOjI5MDkzMTQ2LWZiMWQtMTFlYi1iZGJjLTAyNDJhYzE
  11:27:06.168 [dbservice1] INFO 2aa64c78-fb1d-11eb-a2c9-0242ac110004-OSENDWPb-6)hw=<r&R9.T token generate success token=MTYyODczODgyNi4xNjc3ODU6MmFhNjRjNzgtZmIxZC0xMWViLWEyYzktMDI0MmFjMTE
  11:27:08.735 [mobservice2] INFO info 2c720e7a-fb1d-11eb-a5e7-0242ac110003:ISmxpnEs write success
  11:27:11.474 [mobservice1] INFO info 2e1df4f0-fb1d-11eb-88cd-0242ac110004:hpcKRNdx write success
  11:27:14.629 [dbservice2] INFO 2fc0556e-fb1d-11eb-a07c-0242ac110004-YXLKvufE-RlNLZm@n6u!V token generate success token=MTYyODczODgzNC42MjkxNjExOjJmYzA1NTZlLWZiMWQtMTFlYi1hMDdjLTAyNDJhYzE
  11:27:17.339 [dbservice1] INFO 3161a58a-fb1d-11eb-bec5-0242ac110003-UHcqgbTI-JH<T8XNfd/>@ token generate success token=MTYyODczODgzNy4zMzk1MTIzOjMxNjFhNThhLWZiMWQtMTFlYi1iZWM1LTAyNDJhYzE
  11:27:20.009 [dbservice2] INFO 330384d0-fb1d-11eb-8fa9-0242ac110004-DjVLApUI-+c9@_Y#Tf8ly token generate success token=MTYyODczODg0MC4wMDkwNjgzOjMzMDM4NGQwLWZiMWQtMTFlYi04ZmE5LTAyNDJhYzE
  11:27:22.919 [dbservice1] INFO 348b8a8c-fb1d-11eb-9eb8-0242ac110004-maWzwvqu-3>t0ju}R&m^p token generate success token=MTYyODczODg0Mi45MTkxNDQ0OjM0OGI4YThjLWZiMWQtMTFlYi05ZWI4LTAyNDJhYzE
  11:27:25.923 [dbservice2] INFO 365661f2-fb1d-11eb-af2b-0242ac110003-QkrTBEJI-_!2b7K&HzsM_ token generate success token=MTYyODczODg0NS45MjM1Mjk0OjM2NTY2MWYyLWZiMWQtMTFlYi1hZjJiLTAyNDJhYzE
  11:27:29.329 [dbservice1] INFO 3848fec0-fb1d-11eb-957a-0242ac110004-GOhWXRIV-:-)PYXo0ydqc token generate success token=MTYyODczODg0OS4zMjg5OTAyOjM4NDhmZWMwLWZiMWQtMTFlYi05NTdhLTAyNDJhYzE
  11:27:32.028 [dbservice2] INFO 39e60fd4-fb1d-11eb-b331-0242ac110004-wzNVdLGu->w?zB:biZ0y_ token generate success token=MTYyODczODg1Mi4wMjc4OTMzOjM5ZTYwZmQ0LWZiMWQtMTFlYi1iMzMxLTAyNDJhYzE
  11:27:34.881 [dbservice2] INFO 3bb6798e-fb1d-11eb-94ef-0242ac110003-vtpXmFKe-o%tl^Y:5g8X) token generate success token=MTYyODczODg1NC44ODA1MTkyOjNiYjY3OThlLWZiMWQtMTFlYi05NGVmLTAyNDJhYzE
  11:27:38.368 [dbservice1] INFO 3de588b2-fb1d-11eb-adab-0242ac110003-mHwMQugd-6@1g+F.Th7c& token generate success token=MTYyODczODg1OC4zNjg0NTUyOjNkZTU4OGIyLWZiMWQtMTFlYi1hZGFiLTAyNDJhYzE
  11:27:41.628 [mobservice2] INFO info 4017baec-fb1d-11eb-8538-0242ac110003:ucXDZIio write success
  11:27:44.806 [mobservice2] INFO info 41f26fc4-fb1d-11eb-8678-0242ac110003:NLUGYXBI write success

## p0685
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-12T01:10:56.500Z
```
{"service":"dbservice2","message":"2021-08-12 01:10:56,500 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | ad1508ad6959253e | 17187434-fac7-11eb-a2be-0242ac110004-SzfIWpZE-{_HV.}LO^GnA token generate success token=MTYyODcwMTg1Ni41MDAyMDI6MTcxODc0MzQtZmFjNy0xMWViLWEyYmUtMDI0MmFjMTEwMDA0U3pmSVdwWkV7X0hWLn1MT15HbkE6MTYyODcwMTkxNi41MDAyMTQ2OjVmOTQwYjVhZjUyZjM3MDY4MmM0YzBhZTNmMzVmZDli"}
```
Same service, the 2 minutes before (oldest first):
  01:10:50.857 [dbservice2] INFO query = select passwards from username_table where user_name='YKwDOXcq'  (×5)
  01:10:50.936 [dbservice2] INFO 13c8aa4c-fac7-11eb-981c-0242ac110004-YKwDOXcq-^yVRxMeUlsTA token generate success token=MTYyODcwMTg1MC45MzYyMDg3OjEzYzhhYTRjLWZhYzctMTFlYi05ODFjLTAyNDJhYzE
  01:10:51.723 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  01:10:51.723 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  01:10:51.867 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  01:10:53.867 [dbservice2] INFO 156816b2-fac7-11eb-8df7-0242ac110003-KaeOhoMc-C8w@bIBzX{A$ token generate success token=MTYyODcwMTg1My44NjcxMTM2OjE1NjgxNmIyLWZhYzctMTFlYi04ZGY3LTAyNDJhYzE
  01:10:53.923 [dbservice2] INFO 15765a10-fac7-11eb-a2a8-0242ac110004-qepNbChc-fH.oSuxnyI{B token generate success token=MTYyODcwMTg1My45MjMyMTIzOjE1NzY1YTEwLWZhYzctMTFlYi1hMmE4LTAyNDJhYzE
  01:10:54.792 [dbservice2] INFO 1607967e-fac7-11eb-b863-0242ac110004-NgkejbAm-PZS2*TO0>/RM token generate success token=MTYyODcwMTg1NC43OTE4MDA3OjE2MDc5NjdlLWZhYzctMTFlYi1iODYzLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  01:10:26.601 [redisservice2] INFO redis write success  (×80)
  01:10:26.815 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×40)
  01:10:26.984 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  01:10:27.059 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×41)
  01:10:27.117 [redisservice1] INFO redis读取信息成功, status_code: 200  (×47)
  01:10:27.279 [redisservice1] INFO service accept, status_code: 200  (×47)
  01:10:27.565 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×42)
  01:10:27.673 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×42)
  01:10:28.276 [dbservice1] INFO 062b79fa-fac7-11eb-afe3-0242ac110004-HRlmyonZ-m?/#r3VthEpK token generate success token=MTYyODcwMTgyOC4yNzYwMTk4OjA2MmI3OWZhLWZhYzctMTFlYi1hZmUzLTAyNDJhYzE
  01:10:30.513 [mobservice1] INFO info 07c4935a-fac7-11eb-8cd4-0242ac110003:yfLskzJE write success
  01:10:33.221 [mobservice2] INFO info 09786a00-fac7-11eb-9b49-0242ac110003:xhrnIDOM write success
  01:10:35.270 [dbservice2] INFO 0a7ce0de-fac7-11eb-9b80-0242ac110004-ckfeNPTM-WcHR.sT#4DEu token generate success token=MTYyODcwMTgzNS4yNjk1NTQ5OjBhN2NlMGRlLWZhYzctMTFlYi05YjgwLTAyNDJhYzE
  01:10:37.379 [mobservice2] INFO info 0be53390-fac7-11eb-87ce-0242ac110004:dDmGvhol write success
  01:10:40.217 [mobservice2] INFO info 0d922aea-fac7-11eb-87b1-0242ac110003:ydDVPRrH write success
  01:10:42.393 [dbservice1] INFO 0e90b024-fac7-11eb-9901-0242ac110003-qHGVUSPX-2X6L_bVf5*I< token generate success token=MTYyODcwMTg0Mi4zOTI4MTkyOjBlOTBiMDI0LWZhYzctMTFlYi05OTAxLTAyNDJhYzE
  01:10:44.976 [dbservice1] INFO 10402f4e-fac7-11eb-84bb-0242ac110004-aJKPGOlh-2>-vt=SWy$ca token generate success token=MTYyODcwMTg0NC45NzY0OTg0OjEwNDAyZjRlLWZhYzctMTFlYi04NGJiLTAyNDJhYzE
  01:10:47.561 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  01:10:49.220 [dbservice2] INFO 12cf184c-fac7-11eb-a687-0242ac110003-WuXJGtdQ-LCRs.nwO{0!? token generate success token=MTYyODcwMTg0OS4yMjAyODE6MTJjZjE4NGMtZmFjNy0xMWViLWE2ODctMDI0MmFjMTE
  01:10:51.560 [mobservice2] INFO info 14571f7a-fac7-11eb-b488-0242ac110004:JkrwUiSI write success
  01:10:53.923 [dbservice2] INFO 15765a10-fac7-11eb-a2a8-0242ac110004-qepNbChc-fH.oSuxnyI{B token generate success token=MTYyODcwMTg1My45MjMyMTIzOjE1NzY1YTEwLWZhYzctMTFlYi1hMmE4LTAyNDJhYzE
  01:10:56.775 [dbservice2] INFO 17476c30-fac7-11eb-b315-0242ac110003-jhoAGDST-%RJ/0?B1fm4L token generate success token=MTYyODcwMTg1Ni43NzUyMzMzOjE3NDc2YzMwLWZhYzctMTFlYi1iMzE1LTAyNDJhYzE
  01:10:59.231 [mobservice2] INFO info 18fab898-fac7-11eb-b102-0242ac110003:cHTYOdVw write success
  01:11:01.533 [dbservice2] INFO 1a1fa08a-fac7-11eb-b6d9-0242ac110003-BuorjcSM-hJxcGX+lvSa$ token generate success token=MTYyODcwMTg2MS41MzMxNDU3OjFhMWZhMDhhLWZhYzctMTFlYi1iNmQ5LTAyNDJhYzE
  01:11:05.102 [mobservice2] INFO info 1c62ccb4-fac7-11eb-83bb-0242ac110004:npqwesLI write success
  01:11:07.168 [mobservice2] INFO info 1db0b252-fac7-11eb-a723-0242ac110003:yWbZXEez write success
  01:11:09.294 [dbservice1] INFO 1eb28f2c-fac7-11eb-bb5b-0242ac110003-zrnyoxBF-Sbqp@TrH_P6c token generate success token=MTYyODcwMTg2OS4yOTM4OTg2OjFlYjI4ZjJjLWZhYzctMTFlYi1iYjViLTAyNDJhYzE
  01:11:11.723 [mobservice2] INFO info 205f38b6-fac7-11eb-b1c5-0242ac110003:glaSXZGO write success
  01:11:14.704 [mobservice2] INFO info 222141d0-fac7-11eb-aa09-0242ac110003:bJckhDFR write success
  01:11:17.249 [dbservice1] INFO 236debf6-fac7-11eb-b7f0-0242ac110003-ZYtcmNli-wfvdyXL7u$ah token generate success token=MTYyODcwMTg3Ny4yNDk0ODY0OjIzNmRlYmY2LWZhYzctMTFlYi1iN2YwLTAyNDJhYzE
  01:11:20.107 [dbservice2] INFO 2522e9b0-fac7-11eb-88bc-0242ac110004-ySjkNPYT-D^=b(51nchk< token generate success token=MTYyODcwMTg4MC4xMDcyNTE6MjUyMmU5YjAtZmFjNy0xMWViLTg4YmMtMDI0MmFjMTE

## p0779
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-24T13:34:45.948Z
```
{"timestamp":1732455285948957400,"container_name":"front-end","pod_name":"front-end-f77549869-qkdxd","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"User cart deleted with status: 503"}
```
Same service, the 2 minutes before (oldest first):
  13:34:44.179 [front-end] Sent cookies.  (×2)
  13:34:44.181 [front-end] POST /register 200 59.765 ms - 33  (×2)
  13:34:44.213 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732455284211,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  13:34:44.213 [front-end] Order response: {"timestamp":1732455284211,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  13:34:44.214 [front-end] POST /orders 500 - ms - -
  13:34:45.188 [front-end] GET /catalogue 200 - ms - -  (×2)
  13:34:45.729 [front-end] Posting Customer: {"username":"IXMyAQkuBeK","password":"yGgQbTX","email":"IXMyAQkuBeK@gmail.com","firstName":"IXMyAQkuBeK","lastName":"IXMyAQkuBeK"}
  13:34:45.734 [front-end] { id: '67432b75f6d875000161ffaf' }
  13:34:45.734 [front-end] 67432b75f6d875000161ffaf
  13:34:45.734 [front-end] Merging carts for customer id: 67432b75f6d875000161ffaf and session id: TLxtLP3zSbMiiuYPfQRRMDLAeML-drtD
  13:34:45.778 [front-end] Carts merged.
  13:34:45.778 [front-end] set cookie67432b75f6d875000161ffaf
  13:34:45.808 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67432b6ff6d875000161ff99"}
  13:34:45.817 [front-end] POST /addresses 200 - ms - -
  13:34:45.865 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67432b6ff6d875000161ff99"}
  13:34:45.874 [front-end] POST /cards 200 - ms - -
  13:34:45.921 [front-end] Attempting to delete cart for user: 67432b6ff6d875000161ff99
All services, 30 seconds either side (sampled):
  13:34:16.004 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67432b4ff6d875000161ff34"}  (×63)
  13:34:16.103 [front-end] Attempting to add to cart: {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×63)
  13:34:16.434 [carts] 2024-11-24 13:34:16.434 INFO [carts,fb4ba9c8e6dfb2fd,797077bde4808e77,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.ItemsController : Did not find item.  (×22)
  13:34:17.654 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67432  (×63)
  13:34:17.681 [queue-master] Received shipment task: 67432b42f6d875000161ff19  (×27)
  13:34:17.705 [front-end] { id: '67432b59f6d875000161ff51' }  (×64)
  13:34:18.650 [front-end] Posting Customer: {"username":"MDemFnmhXrGzUDY","password":"fxbpEJatWy","email":"MDemFnmhXrGzUDY@gmail.com","firstName":"MDemFnmhXrGzUDY","lastName":"MDemFnmhXr
  13:34:20.720 [user] ts=2024-11-24T13:34:20.720543435Z caller=middlewares.go:46 method=Register username=FEqRYTMSH email=FEqRYTMSH@gmail.com took=1.592323ms
  13:34:22.111 [front-end] Received response: "{\"firstName\":\"oaJPSVOc\",\"lastName\":\"oaJPSVOc\",\"username\":\"oaJPSVOc\",\"id\":\"67432b47f6d875000161ff20\",\"_links\":{\"addresses\
  13:34:23.013 [front-end] Order response: {"id":"67432b5fc4380300078a4804","customerId":"67432b45f6d875000161ff1c","customer":{"id":null,"firstName":"LctUiPHz","lastName":"LctUiPHz","use
  13:34:25.823 [front-end] Received response: "{\"firstName\":\"ufjHTcuTuLeodxV\",\"lastName\":\"ufjHTcuTuLeodxV\",\"username\":\"ufjHTcuTuLeodxV\",\"id\":\"67432b4bf6d875000161ff28\",\"_
  13:34:26.589 [front-end] Posting Customer: {"username":"owzxqQXxjeJLd","password":"lCNMRoX","email":"owzxqQXxjeJLd@gmail.com","firstName":"owzxqQXxjeJLd","lastName":"owzxqQXxjeJLd"}
  13:34:29.658 [front-end] Received response: "{\"firstName\":\"rYRZTQlFgJm\",\"lastName\":\"rYRZTQlFgJm\",\"username\":\"rYRZTQlFgJm\",\"id\":\"67432b53f6d875000161ff3d\",\"_links\":{\"a
  13:34:31.537 [front-end] Order response: {"statusCode":201,"body":{"id":"67432b67c4380300078a480e","customerId":"67432b55f6d875000161ff42","customer":{"id":null,"firstName":"MBZTVPjzcIV
  13:34:32.523 [front-end] Order response: {"statusCode":201,"body":{"id":"67432b68c4380300078a4811","customerId":"67432b55f6d875000161ff43","customer":{"id":null,"firstName":"ENgnxuzOFmR
  13:34:34.268 [user] ts=2024-11-24T13:34:34.268104984Z caller=middlewares.go:46 method=Register username=YhlNbHKUS email=YhlNbHKUS@gmail.com took=1.922336ms
  13:34:38.269 [front-end] Order response: {"statusCode":201,"body":{"id":"67432b6ec4380300078a4814","customerId":"67432b56f6d875000161ff49","customer":{"id":null,"firstName":"dEBMyIJuAKm
  13:34:40.120 [front-end] Order response: {"statusCode":201,"body":{"id":"67432b70c4380300078a4816","customerId":"67432b5bf6d875000161ff5c","customer":{"id":null,"firstName":"CHQPpycImUJ
  13:34:42.997 [front-end] Posting Customer: {"username":"VlZDl","password":"EYcxGDQO","email":"VlZDl@gmail.com","firstName":"VlZDl","lastName":"VlZDl"}
  13:34:44.072 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732455284070,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×34)
  13:34:46.787 [front-end] Received response: "{\"firstName\":\"owzxqQXxjeJLd\",\"lastName\":\"owzxqQXxjeJLd\",\"username\":\"owzxqQXxjeJLd\",\"id\":\"67432b62f6d875000161ff6e\",\"_links\
  13:34:49.227 [front-end] Posting Customer: {"username":"ZqUTi","password":"MufItgb","email":"ZqUTi@gmail.com","firstName":"ZqUTi","lastName":"ZqUTi"}
  13:34:51.399 [front-end] Received response: "{\"firstName\":\"fwjKtUwureQ\",\"lastName\":\"fwjKtUwureQ\",\"username\":\"fwjKtUwureQ\",\"id\":\"67432b63f6d875000161ff6f\",\"_links\":{\"a
  13:34:55.254 [front-end] Posting Customer: {"username":"FDvjJpEistkFFH","password":"PllzgvAwf","email":"FDvjJpEistkFFH@gmail.com","firstName":"FDvjJpEistkFFH","lastName":"FDvjJpEistkFFH
  13:34:59.256 [user] ts=2024-11-24T13:34:59.256086146Z caller=middlewares.go:46 method=Register username=EVRMZI email=EVRMZI@gmail.com took=1.97347ms
  13:35:02.383 [front-end] Posting Customer: {"username":"KwaCON","password":"boIMcCRX","email":"KwaCON@gmail.com","firstName":"KwaCON","lastName":"KwaCON"}
  13:35:06.684 [front-end] Posting Customer: {"username":"tXxWPCq","password":"zmsGTY","email":"tXxWPCq@gmail.com","firstName":"tXxWPCq","lastName":"tXxWPCq"}
  13:35:08.702 [user] ts=2024-11-24T13:35:08.701909101Z caller=middlewares.go:46 method=Register username=EWWLyYS email=EWWLyYS@gmail.com took=1.881826ms
  13:35:12.941 [front-end] Received response: "{\"firstName\":\"PoBVCcThKWUccy\",\"lastName\":\"PoBVCcThKWUccy\",\"username\":\"PoBVCcThKWUccy\",\"id\":\"67432b7ef6d875000161ffcb\",\"_lin
  13:35:15.039 [front-end] Received response: "{\"firstName\":\"PFJYbD\",\"lastName\":\"PFJYbD\",\"username\":\"PFJYbD\",\"id\":\"67432b85f6d875000161ffdc\",\"_links\":{\"addresses\":{\"h

## p0264
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:15.906Z
```
{"timestamp":1732242495906762500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"673fec3fb0df5c00019af987"}
```
Same service, the 2 minutes before (oldest first):
  02:28:14.317 [front-end] Merging carts for customer id: 673fec3eb0df5c00019af985 and session id: y5_hKG3jcMa48JRLX0HxhdItvM_uuPGj  (×2)
  02:28:14.337 [front-end] Carts merged.
  02:28:14.337 [front-end] set cookie673fec3eb0df5c00019af985
  02:28:14.337 [front-end] Sent cookies.
  02:28:14.339 [front-end] POST /register 200 27.005 ms - 33
  02:28:15.632 [front-end] GET /catalogue 200 - ms - -
  02:28:15.696 [front-end] Posting Customer: {"username":"NGQZYvsdKz","password":"rioCzg","email":"NGQZYvsdKz@gmail.com","firstName":"NGQZYvsdKz","lastName":"NGQZYvsdKz"}
  02:28:15.701 [front-end] { id: '673fec3fb0df5c00019af986' }  (×2)
  02:28:15.701 [front-end] 673fec3fb0df5c00019af986
  02:28:15.891 [front-end] Request received with body: {}
  02:28:15.896 [front-end] Received response: "{\"firstName\":\"rcABXsHV\",\"lastName\":\"rcABXsHV\",\"username\":\"rcABXsHV\",\"id\":\"673fec2ab0df5c00019af943\",\"_links\":{\"addresses\
  02:28:15.896 [front-end] GET Request to: http://user/customers/673fec2ab0df5c00019af943/addresses  (×2)
  02:28:15.903 [front-end] Posting Customer: {"username":"tWrduaLeWjJ","password":"FQckBqInY","email":"tWrduaLeWjJ@gmail.com","firstName":"tWrduaLeWjJ","lastName":"tWrduaLeWjJ"}
  02:28:15.905 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec2fb0df5c00019af958\",\"_links\":{\"
  02:28:15.905 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:15.905 [front-end] [ undefined, undefined ]
  02:28:15.905 [front-end] Posting Order: {"customer":"http://user/customers/673fec2ab0df5c00019af943","address":"http://user/addresses/673fec2fb0df5c00019af957","card":"http://user/cards
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×41)
  02:28:03.174 [front-end] User cart deleted with status: 503  (×41)
  02:28:03.202 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×42)
  02:28:03.249 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×17)
  02:28:03.410 [front-end] Carts merged.  (×39)
  02:28:04.973 [front-end] Posting Customer: {"username":"HFHBXn","password":"EOgUhihln","email":"HFHBXn@gmail.com","firstName":"HFHBXn","lastName":"HFHBXn"}
  02:28:05.351 [user] ts=2024-11-22T02:28:05.351787827Z caller=middlewares.go:46 method=Register username=vuOxCKL email=vuOxCKL@gmail.com took=4.581531ms
  02:28:08.095 [front-end] Received response: "{\"firstName\":\"RsyjMQXEZqDOIBa\",\"lastName\":\"RsyjMQXEZqDOIBa\",\"username\":\"RsyjMQXEZqDOIBa\",\"id\":\"673fec1eb0df5c00019af912\",\"_
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:15.136 [carts] 2024-11-22 02:28:15.041 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 160.989 seconds (JVM running for 167.0
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:22.317 [front-end] Received response: "{\"firstName\":\"JGQXvUjPbFrtK\",\"lastName\":\"JGQXvUjPbFrtK\",\"username\":\"JGQXvUjPbFrtK\",\"id\":\"673fec34b0df5c00019af964\",\"_links\
  02:28:23.143 [orders] 2024-11-22 02:28:23.143 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×9)
  02:28:24.588 [shipping] Adding shipment to queue...  (×24)
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:26.156 [front-end] POST /cart 201 - ms - -  (×26)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d8","customerId":"673fec2cb0df5c00019af949","customer":{"id":null,"firstName":"KoWsmDtUqsE
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:30.547 [front-end] Received response: "{\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\",\"username\":\"vvgsHcY\",\"id\":\"673fec35b0df5c00019af968\",\"_links\":{\"addresses\":{
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.645 [queue-master] 2024-11-22 02:28:32.645 INFO 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×15)
  02:28:37.005 [user] ts=2024-11-22T02:28:37.005380807Z caller=middlewares.go:46 method=Register username=XTqSaA email=XTqSaA@gmail.com took=624.562µs
  02:28:40.136 [front-end] Order response: {"id":"673fec58d94b9000069b39dc","customerId":"673fec41b0df5c00019af98b","customer":{"id":null,"firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe",
  02:28:41.723 [user] ts=2024-11-22T02:28:41.723279742Z caller=middlewares.go:46 method=Register username=yaELjpCD email=yaELjpCD@gmail.com took=1.302265ms
  02:28:43.812 [front-end] Order response: {"id":"673fec5bd94b9000069b39e0","customerId":"673fec47b0df5c00019af996","customer":{"id":null,"firstName":"bhZuEQ","lastName":"bhZuEQ","usernam
  02:28:45.163 [front-end] Received response: "{\"firstName\":\"oqYeDriHaX\",\"lastName\":\"oqYeDriHaX\",\"username\":\"oqYeDriHaX\",\"id\":\"673fec49b0df5c00019af999\",\"_links\":{\"addr

## p0333
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:21:13.089Z
```
{"timestamp":1732245673089501400,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:21:13.089  INFO [carts,,,] 7 --- [           main] works.weave.socks.cart.CartApplication   : Started CartApplication in 139.303 seconds (JVM running for 144.331)"}
```
Same service, the 2 minutes before (oldest first):
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public j
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  03:21:03.184 [carts] 2024-11-22 03:21:03.183 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces
  03:21:03.285 [carts] 2024-11-22 03:21:03.285 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/
  03:21:06.490 [carts] 2024-11-22 03:21:06.489 INFO [carts,,,] 7 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  03:21:08.790 [carts] 2024-11-22 03:21:08.790 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetected
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposur  (×2)
  03:21:08.986 [carts] 2024-11-22 03:21:08.986 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  03:21:08.987 [carts] 2024-11-22 03:21:08.987 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  03:21:08.990 [carts] 2024-11-22 03:21:08.990 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX server
  03:21:09.189 [carts] 2024-11-22 03:21:09.188 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server as  (×2)
  03:21:09.293 [carts] 2024-11-22 03:21:09.293 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as MB
  03:21:09.390 [carts] 2024-11-22 03:21:09.390 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering wi
  03:21:11.685 [carts] 2024-11-22 03:21:11.685 INFO [carts,,,] 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  03:21:12.988 [carts] 2024-11-22 03:21:12.988 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
All services, 30 seconds either side (sampled):
  03:20:43.352 [catalogue] ts=2024-11-22T03:20:43Z caller=logging.go:85 method=Health result=2 took=30.238µs  (×40)
  03:20:43.764 [front-end] GET /catalogue 200 - ms - -  (×57)
  03:20:46.313 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}  (×56)
  03:20:46.658 [user] ts=2024-11-22T03:20:46.658338215Z caller=middlewares.go:75 method=GetUsers id=673ff877b0df5c00019b1eec result=1 took=1.021792ms  (×54)
  03:20:47.130 [user] ts=2024-11-22T03:20:47.130654611Z caller=middlewares.go:46 method=Register username=TeeRhkRKovrDpY email=TeeRhkRKovrDpY@gmail.com took=1.065358ms  (×26)
  03:20:47.926 [front-end] Posting Customer: {"username":"XYDErsNhuY","password":"RuOOlZc","email":"XYDErsNhuY@gmail.com","firstName":"XYDErsNhuY","lastName":"XYDErsNhuY"}
  03:20:49.389 [carts] 2024-11-22 03:20:49.389 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframewo  (×2)
  03:20:54.518 [front-end] Posting Customer: {"username":"aZnbBrPviPwcYcC","password":"cLxGTi","email":"aZnbBrPviPwcYcC@gmail.com","firstName":"aZnbBrPviPwcYcC","lastName":"aZnbBrPviPwcYc
  03:20:59.096 [front-end] Posting Customer: {"username":"mLiQP","password":"QVvyQW","email":"mLiQP@gmail.com","firstName":"mLiQP","lastName":"mLiQP"}
  03:20:59.690 [carts] 2024-11-22 03:20:59.689 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[DELETE],produces=[applicat
  03:20:59.789 [carts] 2024-11-22 03:20:59.789 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],produc
  03:21:01.182 [front-end] Posting Customer: {"username":"EFvIPXnJWRPmy","password":"UDHAmT","email":"EFvIPXnJWRPmy@gmail.com","firstName":"EFvIPXnJWRPmy","lastName":"EFvIPXnJWRPmy"}
  03:21:03.086 [carts] 2024-11-22 03:21:03.086 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  03:21:03.479 [front-end] Received response: "{\"firstName\":\"TeeRhkRKovrDpY\",\"lastName\":\"TeeRhkRKovrDpY\",\"username\":\"TeeRhkRKovrDpY\",\"id\":\"673ff88fb0df5c00019b1f25\",\"_lin
  03:21:06.503 [front-end] Posting Customer: {"username":"YOkVqshziuS","password":"nmTvTMuHqo","email":"YOkVqshziuS@gmail.com","firstName":"YOkVqshziuS","lastName":"YOkVqshziuS"}
  03:21:09.390 [carts] 2024-11-22 03:21:09.390 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering wi
  03:21:12.988 [carts] 2024-11-22 03:21:12.988 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  03:21:15.774 [front-end] Posting Customer: {"username":"eSafJJOuc","password":"LrXrl","email":"eSafJJOuc@gmail.com","firstName":"eSafJJOuc","lastName":"eSafJJOuc"}
  03:21:18.113 [orders] java.util.concurrent.TimeoutException: null at java.util.concurrent.FutureTask.get(FutureTask.java:205) ~[na:1.8.0_131] at works.weave.socks.orders.controllers.  (×2)
  03:21:18.613 [queue-master] 2024-11-22 03:21:18.612 INFO 6 --- [ool-6-thread-44] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×60)
  03:21:18.854 [front-end] Received response: "{\"firstName\":\"sQAAadzpZlKDfq\",\"lastName\":\"sQAAadzpZlKDfq\",\"username\":\"sQAAadzpZlKDfq\",\"id\":\"673ff89eb0df5c00019b1f58\",\"_lin
  03:21:19.502 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8afd94b9000069b4392","customerId":"673ff89eb0df5c00019b1f58","customer":{"id":null,"firstName":"sQAAadzpZlK
  03:21:20.407 [front-end] Order response: {"id":"673ff8b0d94b9000069b4397","customerId":"673ff899b0df5c00019b1f45","customer":{"id":null,"firstName":"pNgaEfQnfRl","lastName":"pNgaEfQnfRl
  03:21:21.633 [front-end] Posting Customer: {"username":"XaQgsgBGh","password":"cPSSGplny","email":"XaQgsgBGh@gmail.com","firstName":"XaQgsgBGh","lastName":"XaQgsgBGh"}
  03:21:26.555 [front-end] Posting Customer: {"username":"ZaeWmQ","password":"ITGipAu","email":"ZaeWmQ@gmail.com","firstName":"ZaeWmQ","lastName":"ZaeWmQ"}
  03:21:29.659 [front-end] Posting Customer: {"username":"QoPcWQ","password":"kjnfWhwM","email":"QoPcWQ@gmail.com","firstName":"QoPcWQ","lastName":"QoPcWQ"}
  03:21:34.227 [user] ts=2024-11-22T03:21:34.227288332Z caller=middlewares.go:46 method=Register username=AQjSILT email=AQjSILT@gmail.com took=919.566µs
  03:21:36.103 [user] ts=2024-11-22T03:21:36.103019608Z caller=middlewares.go:46 method=Register username=viOBwi email=viOBwi@gmail.com took=1.023163ms
  03:21:38.473 [front-end] Posting Customer: {"username":"otqrpqrI","password":"iwSHv","email":"otqrpqrI@gmail.com","firstName":"otqrpqrI","lastName":"otqrpqrI"}
  03:21:41.867 [front-end] Posting Customer: {"username":"SroOVWpRGoFFmH","password":"eZNwnWTdr","email":"SroOVWpRGoFFmH@gmail.com","firstName":"SroOVWpRGoFFmH","lastName":"SroOVWpRGoFFmH

## p0358
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-22T03:32:18.539Z
```
{"timestamp":1732246338539659300,"container_name":"orders","pod_name":"orders-5fd66f9688-2x7kx","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable\n\tat org.springframework.web.client.DefaultResponseErrorHandler.handleError(DefaultResponseErrorHandler.java:94) ~[spring-web-4.3.6.RELEASE.jar!/:4.3.6.RELEASE]\n\tat org.springframework.web.client.RestTemplate.handleResponse(RestTemplate.java:700) ~[spring-web-4.3.6.RELEASE.jar!/:4.3.6.RELEASE]\n\tat org.springframework.w…"}
```
Same service, the 2 minutes before (oldest first):
  03:32:08.837 [orders] 2024-11-22 03:32:08.837 INFO [orders,09472b7a85a56c78,68a06ef095ebee99,false] 6 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Received payment re  (×7)
  03:32:09.211 [orders] 2024-11-22 03:32:09.211 INFO [orders,4849c406559a00a4,01a1f4e8903577c7,false] 6 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Sending payment req  (×6)
  03:32:10.917 [orders] 2024-11-22 03:32:10.917 INFO [orders,6c6a334f9c0af63a,a6b53424dd3c8a4c,false] 6 --- [-nio-80-exec-15] w.w.s.o.controllers.OrdersController : Sending payment req  (×3)
  03:32:10.921 [orders] 2024-11-22 03:32:10.921 INFO [orders,6c6a334f9c0af63a,a6b53424dd3c8a4c,false] 6 --- [-nio-80-exec-15] w.w.s.o.controllers.OrdersController : Received payment re  (×3)
  03:32:18.539 [orders] 2024-11-22 03:32:18.539 ERROR [orders,,,] 6 --- [p-nio-80-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
All services, 30 seconds either side (sampled):
  03:31:48.550 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffb1ab0df5c00019b26e2"}  (×61)
  03:31:48.628 [front-end] DELETE /cart 202 - ms - -  (×61)
  03:31:48.684 [front-end] POST /cart 201 - ms - -  (×24)
  03:31:49.979 [front-end] Posting Customer: {"username":"uUHegzqhy","password":"dZwxm","email":"uUHegzqhy@gmail.com","firstName":"uUHegzqhy","lastName":"uUHegzqhy"}
  03:31:51.696 [user] ts=2024-11-22T03:31:51.696588398Z caller=middlewares.go:75 method=GetUsers id=673ffb16b0df5c00019b26db result=1 took=1.004504ms  (×49)
  03:31:51.726 [queue-master] Received shipment task: 673ffb16b0df5c00019b26db  (×28)
  03:31:52.035 [payment] ts=2024-11-22T03:31:52Z caller=logging.go:29 method=Authorise result=true took=840ns  (×22)
  03:31:53.526 [carts] 2024-11-22 03:31:53.526 INFO [carts,988da20efecc68a2,6095d69bd0d88cde,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.ItemsController : Did not find item.  (×11)
  03:31:54.719 [front-end] Order response: {"id":"673ffb2ad94b9000069b45c5","customerId":"673ffb12b0df5c00019b26d1","customer":{"id":null,"firstName":"uBPmvyVkhAmg","lastName":"uBPmvyVkhA
  03:31:55.985 [front-end] Order response: {"id":"673ffb2bd94b9000069b45c8","customerId":"673ffb17b0df5c00019b26df","customer":{"id":null,"firstName":"nZOyGlhKovycg","lastName":"nZOyGlhKo
  03:31:58.300 [front-end] Order response: {"id":"673ffb2ed94b9000069b45ca","customerId":"673ffb16b0df5c00019b26d8","customer":{"id":null,"firstName":"HIZlqUqmK","lastName":"HIZlqUqmK","u
  03:32:00.676 [front-end] Order response: {"id":"673ffb30d94b9000069b45cd","customerId":"673ffb19b0df5c00019b26e1","customer":{"id":null,"firstName":"YVdsb","lastName":"YVdsb","username"
  03:32:02.705 [user] ts=2024-11-22T03:32:02.705363099Z caller=middlewares.go:75 method=GetUsers id=673ffb1ab0df5c00019b26e2 result=1 took=785µs
  03:32:05.075 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffb35d94b9000069b45d2","customerId":"673ffb27b0df5c00019b270f","customer":{"id":null,"firstName":"lxPGUfPmvGK
  03:32:09.226 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffb39d94b9000069b45d4","customerId":"673ffb25b0df5c00019b270b","customer":{"id":null,"firstName":"uUHegzqhy",
  03:32:09.825 [front-end] Posting Customer: {"username":"XCDQMLe","password":"mfXuTKITCB","email":"XCDQMLe@gmail.com","firstName":"XCDQMLe","lastName":"XCDQMLe"}
  03:32:12.953 [front-end] Received response: "{\"firstName\":\"pgVHJpb\",\"lastName\":\"pgVHJpb\",\"username\":\"pgVHJpb\",\"id\":\"673ffb29b0df5c00019b2717\",\"_links\":{\"addresses\":{
  03:32:14.813 [front-end] Posting Customer: {"username":"HvzrtkVX","password":"cNGcnneX","email":"HvzrtkVX@gmail.com","firstName":"HvzrtkVX","lastName":"HvzrtkVX"}
  03:32:16.878 [front-end] Posting Customer: {"username":"ckPnJrmieJHIUO","password":"vkVCmkNyzd","email":"ckPnJrmieJHIUO@gmail.com","firstName":"ckPnJrmieJHIUO","lastName":"ckPnJrmieJHIU
  03:32:19.052 [front-end] Posting Customer: {"username":"nXuxBetk","password":"DPBHns","email":"nXuxBetk@gmail.com","firstName":"nXuxBetk","lastName":"nXuxBetk"}
  03:32:20.791 [front-end] Posting Customer: {"username":"SBXZtYxK","password":"AwvpTaIs","email":"SBXZtYxK@gmail.com","firstName":"SBXZtYxK","lastName":"SBXZtYxK"}
  03:32:22.125 [front-end] Posting Customer: {"username":"PEHWceW","password":"eoZVw","email":"PEHWceW@gmail.com","firstName":"PEHWceW","lastName":"PEHWceW"}
  03:32:27.890 [carts] 2024-11-22 03:32:27.884 INFO [bootstrap,,,] 7 --- [ main] s.c.a.AnnotationConfigApplicationContext : Refreshing org.springframework.context.annotation.Annotatio
  03:32:29.994 [front-end] Received response: "{\"firstName\":\"CPcGZ\",\"lastName\":\"CPcGZ\",\"username\":\"CPcGZ\",\"id\":\"673ffb39b0df5c00019b273b\",\"_links\":{\"addresses\":{\"href
  03:32:33.373 [user] ts=2024-11-22T03:32:33.373389814Z caller=middlewares.go:46 method=Register username=vfmmryRC email=vfmmryRC@gmail.com took=983.86µs
  03:32:37.432 [front-end] Posting Customer: {"username":"aTjzFVnkLvnE","password":"exWiNsQGaA","email":"aTjzFVnkLvnE@gmail.com","firstName":"aTjzFVnkLvnE","lastName":"aTjzFVnkLvnE"}
  03:32:40.553 [front-end] Received response: "{\"firstName\":\"EoHXA\",\"lastName\":\"EoHXA\",\"username\":\"EoHXA\",\"id\":\"673ffb48b0df5c00019b276e\",\"_links\":{\"addresses\":{\"href
  03:32:45.515 [front-end] Received response: "{\"firstName\":\"PEHWceW\",\"lastName\":\"PEHWceW\",\"username\":\"PEHWceW\",\"id\":\"673ffb46b0df5c00019b276b\",\"_links\":{\"addresses\":{

## p0461
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:06:43.922Z
```
{"timestamp":1732349203922542800,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"id\":\"67418d133f77060008864e45\",\"customerId\":\"67418cf8a437380001deeca7\",\"customer\":{\"id\":null,\"firstName\":\"GXUtAA\",\"lastName\":\"GXUtAA\",\"username\":\"GXUtAA\",\"addresses\":[],\"cards\":[]},\"address\":{\"id\":null,\"number\":\"123\",\"street\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"country\":\"123\"},\"card\":{\"id\":null,\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\"},\"items\":[],\"shipment\":{\"id\":\"b043…"}
```
Same service, the 2 minutes before (oldest first):
  08:06:43.737 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata
  08:06:43.737 [front-end] POST to carts: http://carts/carts/67418d0ba437380001deecdf/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}
  08:06:43.765 [front-end] Request received with body: {}  (×2)
  08:06:43.776 [front-end] Received response: "{\"firstName\":\"GXUtAA\",\"lastName\":\"GXUtAA\",\"username\":\"GXUtAA\",\"id\":\"67418cf8a437380001deeca7\",\"_links\":{\"addresses\":{\"h
  08:06:43.776 [front-end] GET Request to: http://user/customers/67418cf8a437380001deeca7/addresses  (×4)
  08:06:43.783 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418  (×2)
  08:06:43.784 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418d02a437380001deecc2\",\"_links\":{\"  (×2)
  08:06:43.784 [front-end] [ undefined, undefined ]  (×2)
  08:06:43.784 [front-end] Posting Order: {"customer":"http://user/customers/67418cf8a437380001deeca7","address":"http://user/addresses/67418d02a437380001deecc1","card":"http://user/cards  (×2)
  08:06:43.811 [front-end] POST /cart 201 - ms - -
  08:06:43.836 [front-end] Received response: "{\"firstName\":\"fdgssjehHZFkqOI\",\"lastName\":\"fdgssjehHZFkqOI\",\"username\":\"fdgssjehHZFkqOI\",\"id\":\"67418d02a437380001deecbf\",\"_
  08:06:43.922 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d133f77060008864e45","customerId":"67418cf8a437380001deeca7","customer":{"id":null,"firstName":"GXUtAA","la
All services, 30 seconds either side (sampled):
  08:06:13.923 [user] ts=2024-11-23T08:06:13.923480962Z caller=middlewares.go:104 method=GetAddresses id=67418ceba437380001deec86 result=1 took=2.924364ms  (×57)
  08:06:14.075 [front-end] Posting Order: {"customer":"http://user/customers/67418cdea437380001deec59","address":"http://user/addresses/67418ce4a437380001deec6c","card":"http://user/cards  (×56)
  08:06:14.231 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×9)
  08:06:15.383 [catalogue] ts=2024-11-23T08:06:15Z caller=logging.go:85 method=Health result=2 took=27.776µs  (×40)
  08:06:15.802 [carts] 2024-11-23 08:06:15.802 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[applicati
  08:06:15.906 [carts] 2024-11-23 08:06:15.903 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[OPTIONS],produces=[appli
  08:06:15.996 [front-end] POST /register 200 25.122 ms - 33  (×60)
  08:06:16.849 [user] ts=2024-11-23T08:06:16.848778678Z caller=middlewares.go:157 method=Health result=2 took=1.686094ms  (×40)
  08:06:19.007 [carts] 2024-11-23 08:06:19.007 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  08:06:19.108 [carts] 2024-11-23 08:06:19.108 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/
  08:06:22.980 [front-end] Received response: "{\"firstName\":\"LeJTlhMOCH\",\"lastName\":\"LeJTlhMOCH\",\"username\":\"LeJTlhMOCH\",\"id\":\"67418ce3a437380001deec69\",\"_links\":{\"addr
  08:06:24.580 [front-end] Received response: "{\"firstName\":\"djVRqry\",\"lastName\":\"djVRqry\",\"username\":\"djVRqry\",\"id\":\"67418cf2a437380001deec95\",\"_links\":{\"addresses\":{
  08:06:26.904 [front-end] Posting Customer: {"username":"BPBpJa","password":"ItmzyVAteC","email":"BPBpJa@gmail.com","firstName":"BPBpJa","lastName":"BPBpJa"}
  08:06:29.799 [carts] 2024-11-23 08:06:29.702 INFO [carts,6207abd6ec238d07,52ab6267122a3f12,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×21)
  08:06:31.806 [carts-db] {"t":{"$date":"2024-11-23T08:06:31.805+00:00"},"s":"I", "c":"STORAGE", "id":20279, "ctx":"conn6","msg":"Conflicted creating a collection","attr":{"namespace":"d  (×9)
  08:06:32.829 [orders] 2024-11-23 08:06:32.829 INFO [orders,023d639e89b59062,25141f4b818ad32d,false] 8 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×4)
  08:06:34.719 [front-end] POST /cart 201 - ms - -  (×47)
  08:06:35.789 [orders] 2024-11-23 08:06:35.789 INFO [orders,fbcebf8ef5e82428,6d050ec4f8a03a61,false] 8 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×4)
  08:06:36.209 [front-end] Order response: {"id":"67418d0b3f77060008864e3d","customerId":"67418ceca437380001deec88","customer":{"id":null,"firstName":"VnaknAEtTvwY","lastName":"VnaknAEtTv
  08:06:40.900 [queue-master] Caused by: java.lang.RuntimeException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock) at com.google.commo
  08:06:42.727 [front-end] Posting Customer: {"username":"gSjFQJm","password":"OxlJt","email":"gSjFQJm@gmail.com","firstName":"gSjFQJm","lastName":"gSjFQJm"}
  08:06:43.922 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d133f77060008864e45","customerId":"67418cf8a437380001deeca7","customer":{"id":null,"firstName":"GXUtAA","la
  08:06:47.923 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d173f77060008864e4a","customerId":"67418d02a437380001deecc3","customer":{"id":null,"firstName":"spaWHNsfk",
  08:06:49.690 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d193f77060008864e4e","customerId":"67418d02a437380001deecc0","customer":{"id":null,"firstName":"QzQEpmSQXDM
  08:06:52.690 [front-end] Order response: {"id":"67418d1c3f77060008864e52","customerId":"67418d05a437380001deecd0","customer":{"id":null,"firstName":"cuFLCUGugozmeyi","lastName":"cuFLCUG
  08:06:56.454 [front-end] Received response: "{\"firstName\":\"EDkxTMyJmiJ\",\"lastName\":\"EDkxTMyJmiJ\",\"username\":\"EDkxTMyJmiJ\",\"id\":\"67418d06a437380001deecd9\",\"_links\":{\"a
  08:06:58.994 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732349218983,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×4)
  08:07:01.096 [front-end] Received response: "{\"firstName\":\"gSjFQJm\",\"lastName\":\"gSjFQJm\",\"username\":\"gSjFQJm\",\"id\":\"67418d12a437380001deecff\",\"_links\":{\"addresses\":{
  08:07:03.458 [user] ts=2024-11-23T08:07:03.458260435Z caller=middlewares.go:46 method=Register username=hHThr email=hHThr@gmail.com took=3.118032ms
  08:07:06.367 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d2a3f77060008864e60","customerId":"67418d14a437380001deed04","customer":{"id":null,"firstName":"hnpzllValfp

## p0477
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:17:34.702Z
```
{"timestamp":1732349854702232800,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"statusCode\":406,\"body\":{\"timestamp\":1732349854699,\"status\":406,\"error\":\"Not Acceptable\",\"exception\":\"works.weave.socks.orders.controllers.OrdersController$PaymentDeclinedException\",\"message\":\"Payment declined: amount exceeds 100.00\",\"path\":\"/orders\"},\"headers\":{\"x-application-context\":\"orders:80\",\"content-type\":\"application/json;charset=UTF-8\",\"date\":\"Sat, 23 Nov 2024 08:17:34 GM…"}
```
Same service, the 2 minutes before (oldest first):
  08:17:34.561 [front-end] Attempting to add to cart: {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","quantity":1}
  08:17:34.569 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
  08:17:34.569 [front-end] POST to carts: http://carts/carts/67418f99a437380001def493/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}
  08:17:34.605 [front-end] POST /cart 201 - ms - -
  08:17:34.661 [front-end] Posting Customer: {"username":"OLMIe","password":"xYIAGPHc","email":"OLMIe@gmail.com","firstName":"OLMIe","lastName":"OLMIe"}
  08:17:34.663 [front-end] Request received with body: {}
  08:17:34.665 [front-end] { id: '67418f9ea437380001def4a4' }
  08:17:34.665 [front-end] 67418f9ea437380001def4a4
  08:17:34.665 [front-end] Merging carts for customer id: 67418f9ea437380001def4a4 and session id: FX_rZ1LEV_GT55uOYRjSnVu8m32uNSPt
  08:17:34.673 [front-end] Received response: "{\"firstName\":\"aVGPN\",\"lastName\":\"aVGPN\",\"username\":\"aVGPN\",\"id\":\"67418f8ba437380001def466\",\"_links\":{\"addresses\":{\"href
  08:17:34.673 [front-end] GET Request to: http://user/customers/67418f8ba437380001def466/addresses  (×2)
  08:17:34.682 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418f92a437380001def482\",\"_links\":{\"
  08:17:34.682 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418
  08:17:34.682 [front-end] [ undefined, undefined ]
  08:17:34.682 [front-end] Posting Order: {"customer":"http://user/customers/67418f8ba437380001def466","address":"http://user/addresses/67418f92a437380001def481","card":"http://user/cards
  08:17:34.682 [front-end] Carts merged.
  08:17:34.682 [front-end] set cookie67418f9ea437380001def4a4
  08:17:34.683 [front-end] Sent cookies.
  08:17:34.684 [front-end] POST /register 200 22.135 ms - 33
All services, 30 seconds either side (sampled):
  08:17:04.849 [user] ts=2024-11-23T08:17:04.849366482Z caller=middlewares.go:157 method=Health result=2 took=2.603718ms  (×40)
  08:17:05.134 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×6)
  08:17:05.421 [front-end] set cookie67418f81a437380001def44b  (×53)
  08:17:06.546 [front-end] Posting Customer: {"username":"yLcMG","password":"qhgVHDbHbp","email":"yLcMG@gmail.com","firstName":"yLcMG","lastName":"yLcMG"}
  08:17:07.391 [front-end] GET Request to: http://user/customers/67418f73a437380001def41c/addresses  (×116)
  08:17:07.430 [queue-master] 2024-11-23 08:17:07.428 INFO 7 --- [ool-6-thread-26] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×25)
  08:17:08.149 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×7)
  08:17:10.124 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f863f7706000886507e","customerId":"67418f73a437380001def41d","customer":{"id":null,"firstName":"yOtehURT","
  08:17:11.819 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f873f77060008865080","customerId":"67418f76a437380001def427","customer":{"id":null,"firstName":"kbuYcJuflj"
  08:17:13.758 [front-end] Received response: "{\"firstName\":\"QRShkFt\",\"lastName\":\"QRShkFt\",\"username\":\"QRShkFt\",\"id\":\"67418f74a437380001def41e\",\"_links\":{\"addresses\":{
  08:17:16.384 [front-end] Order response: {"statusCode":201,"body":{"id":"67418f8c3f77060008865086","customerId":"67418f7ba437380001def438","customer":{"id":null,"firstName":"qaUknjsteJd
  08:17:18.715 [front-end] Posting Customer: {"username":"AHLEGfzWOkJSK","password":"WZnyHLi","email":"AHLEGfzWOkJSK@gmail.com","firstName":"AHLEGfzWOkJSK","lastName":"AHLEGfzWOkJSK"}
  08:17:20.485 [front-end] Posting Customer: {"username":"FNneaHiQW","password":"qfpCKXyUn","email":"FNneaHiQW@gmail.com","firstName":"FNneaHiQW","lastName":"FNneaHiQW"}
  08:17:24.395 [user] ts=2024-11-23T08:17:24.395276892Z caller=middlewares.go:46 method=Register username=AjIcqeIe email=AjIcqeIe@gmail.com took=2.286096ms
  08:17:25.047 [front-end] Posting Customer: {"username":"MQWTDFHL","password":"tYWdvWqXl","email":"MQWTDFHL@gmail.com","firstName":"MQWTDFHL","lastName":"MQWTDFHL"}
  08:17:28.101 [front-end] Order response: {"id":"67418f983f77060008865093","customerId":"67418f85a437380001def45e","customer":{"id":null,"firstName":"YtbOkEhM","lastName":"YtbOkEhM","use
  08:17:28.253 [front-end] npm timing config:load:file:/home/myuser/.npmrc Completed in 1ms  (×2)
  08:17:28.254 [front-end] npm timing npm:load:setTitle Completed in 2ms  (×2)
  08:17:29.111 [queue-master] 2024-11-23 08:17:29.111 INFO 7 --- [pool-6-thread-3] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×8)
  08:17:30.858 [front-end] Using the redis based session manager
  08:17:33.839 [front-end] Posting Customer: {"username":"DEZpKjVqb","password":"jQGQJia","email":"DEZpKjVqb@gmail.com","firstName":"DEZpKjVqb","lastName":"DEZpKjVqb"}
  08:17:35.565 [front-end] Posting Customer: {"username":"gRkXIIqnEMZ","password":"dXFfXr","email":"gRkXIIqnEMZ@gmail.com","firstName":"gRkXIIqnEMZ","lastName":"gRkXIIqnEMZ"}
  08:17:38.160 [front-end] Order response: {"id":"67418fa23f7706000886509a","customerId":"67418f87a437380001def463","customer":{"id":null,"firstName":"zUlKpfPGQF","lastName":"zUlKpfPGQF",
  08:17:40.900 [front-end] npm timing command:start Completed in 795556ms  (×2)
  08:17:40.902 [front-end] npm verb Linux 5.10.227-219.884.amzn2.x86_64  (×2)
  08:17:46.991 [front-end] Posting Customer: {"username":"cuBQEVXzGzxdSWs","password":"dMNUNsszHp","email":"cuBQEVXzGzxdSWs@gmail.com","firstName":"cuBQEVXzGzxdSWs","lastName":"cuBQEVXzGz
  08:17:52.023 [front-end] Received response: "{\"_embedded\":{\"card\":[]}}\n"  (×6)
  08:17:56.736 [front-end] Posting Customer: {"username":"oYJYFgYFnZzQlq","password":"VVPjLX","email":"oYJYFgYFnZzQlq@gmail.com","firstName":"oYJYFgYFnZzQlq","lastName":"oYJYFgYFnZzQlq"}
  08:18:01.657 [front-end] Received response: "{\"firstName\":\"gRkXIIqnEMZ\",\"lastName\":\"gRkXIIqnEMZ\",\"username\":\"gRkXIIqnEMZ\",\"id\":\"67418f9fa437380001def4a7\",\"_links\":{\"a

## p0071
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T09:02:37.444Z
```
{"service":"dbservice2","message":"2021-08-13 09:02:37,444 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | 76901b7820e534d2 | 2631c086-fbd2-11eb-9ef2-0242ac110003-NAVbZmOn-ke>7g-}&^mTA token generate success token=MTYyODgxNjU1Ny40NDQwNjk0OjI2MzFjMDg2LWZiZDItMTFlYi05ZWYyLTAyNDJhYzExMDAwM05BVmJabU9ua2U-N2ctfSZebVRBOjE2Mjg4MTY2MTcuNDQ0MDgyOjgzZjM1NWRmNDFhZmUzODJjODcwOTk0OTg4NjA1NWY2"}
```
Same service, the 2 minutes before (oldest first):
  09:02:29.152 [dbservice2] INFO query = select passwards from username_table where user_name='ocwNidgD'  (×5)
  09:02:29.230 [dbservice2] INFO 214f04a2-fbd2-11eb-aa62-0242ac110003-ocwNidgD-vr7adT}&{R=! token generate success token=MTYyODgxNjU0OS4yMzA0MTM6MjE0ZjA0YTItZmJkMi0xMWViLWFhNjItMDI0MmFjMTE
  09:02:29.863 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  09:02:29.863 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  09:02:29.996 [dbservice2] INFO 21c71744-fbd2-11eb-8233-0242ac110004-XtQAmVaq-fU}q@<msQnpj token generate success token=MTYyODgxNjU0OS45OTYzNDA4OjIxYzcxNzQ0LWZiZDItMTFlYi04MjMzLTAyNDJhYzE
  09:02:31.680 [dbservice2] INFO 22b3350c-fbd2-11eb-aca6-0242ac110003-WyKqhlJd-S5&.)N$_Qvw> token generate success token=MTYyODgxNjU1MS42Nzk3ODE3OjIyYjMzNTBjLWZiZDItMTFlYi1hY2E2LTAyNDJhYzE
  09:02:33.304 [dbservice2] INFO 23b38326-fbd2-11eb-a9af-0242ac110004-EkAYnzMd-}DiO>7wP@+#Z token generate success token=MTYyODgxNjU1My4zMDQwMTg1OjIzYjM4MzI2LWZiZDItMTFlYi1hOWFmLTAyNDJhYzE
  09:02:34.391 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
All services, 30 seconds either side (sampled):
  09:02:07.456 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×41)
  09:02:07.529 [redisservice1] INFO redis write success  (×94)
  09:02:07.690 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '14937f5e-fbd2-11eb-9e1f-0242ac110003'}  (×40)
  09:02:08.054 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×48)
  09:02:08.307 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '15175982-fbd2-11eb-8553-0242ac110004'}  (×50)
  09:02:08.502 [redisservice1] INFO redis读取信息成功, status_code: 200  (×43)
  09:02:08.855 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×44)
  09:02:09.999 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  09:02:11.361 [dbservice1] INFO 16992470-fbd2-11eb-84c3-0242ac110004-IKTgrkvl-puzDw*h+_H#V token generate success token=MTYyODgxNjUzMS4zNjA4NTE4OjE2OTkyNDcwLWZiZDItMTFlYi04NGMzLTAyNDJhYzE
  09:02:13.957 [dbservice2] ERROR password in database of {user} is null, the user is not registered
  09:02:16.822 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat  (×4)
  09:02:19.427 [dbservice2] INFO 1b622074-fbd2-11eb-bcb0-0242ac110004-mgJapjfn-_y)3.7z{26^$ token generate success token=MTYyODgxNjUzOS40MjY1NTY6MWI2MjIwNzQtZmJkMi0xMWViLWJjYjAtMDI0MmFjMTE
  09:02:22.070 [mobservice1] INFO info 1d3d92ac-fbd2-11eb-9b1e-0242ac110003:BphUxVDk write success
  09:02:24.958 [mobservice1] INFO info 1efbe846-fbd2-11eb-a664-0242ac110004:OVLDMHZf write success
  09:02:28.048 [mobservice2] INFO info 20b551fe-fbd2-11eb-8e80-0242ac110003:mFYdOIbz write success
  09:02:30.856 [dbservice1] INFO 223afa56-fbd2-11eb-b84d-0242ac110004-HRlmyonZ-m?/#r3VthEpK token generate success token=MTYyODgxNjU1MC44NTYwNDc2OjIyM2FmYTU2LWZiZDItMTFlYi1iODRkLTAyNDJhYzE
  09:02:33.304 [dbservice2] INFO 23b38326-fbd2-11eb-a9af-0242ac110004-EkAYnzMd-}DiO>7wP@+#Z token generate success token=MTYyODgxNjU1My4zMDQwMTg1OjIzYjM4MzI2LWZiZDItMTFlYi1hOWFmLTAyNDJhYzE
  09:02:35.940 [dbservice1] INFO 2545bd9e-fbd2-11eb-8e6e-0242ac110003-bHxAGyOk-FAxou7R(_OT- token generate success token=MTYyODgxNjU1NS45Mzk2NzgyOjI1NDViZDllLWZiZDItMTFlYi04ZTZlLTAyNDJhYzE
  09:02:38.837 [mobservice2] INFO info 2734c9a6-fbd2-11eb-a55f-0242ac110004:kOerFKnJ write success
  09:02:41.365 [mobservice2] INFO info 28b742f4-fbd2-11eb-8a28-0242ac110004:NptDIkKG write success
  09:02:43.560 [mobservice1] INFO info 2a0d739e-fbd2-11eb-9258-0242ac110003:ropVRsqh write success
  09:02:46.500 [dbservice2] INFO 2b9966b4-fbd2-11eb-987e-0242ac110004-Bmsjcfbe-.Df068n2zr9m token generate success token=MTYyODgxNjU2Ni41MDAxNjA1OjJiOTk2NmI0LWZiZDItMTFlYi05ODdlLTAyNDJhYzE
  09:02:48.936 [dbservice1] INFO 2cefc67a-fbd2-11eb-a760-0242ac110003-SNyDIdeO-%$BE{6JCn?Hd token generate success token=MTYyODgxNjU2OC45MzU4NTg3OjJjZWZjNjdhLWZiZDItMTFlYi1hNzYwLTAyNDJhYzE
  09:02:51.911 [mobservice2] INFO info 2f0157a8-fbd2-11eb-bb64-0242ac110003:frspTAey write success
  09:02:54.512 [dbservice2] INFO 304f75c2-fbd2-11eb-aa76-0242ac110004-OvVHWlKe-(vX2)-M{rxI! token generate success token=MTYyODgxNjU3NC41MTIyMTI4OjMwNGY3NWMyLWZiZDItMTFlYi1hYTc2LTAyNDJhYzE
  09:02:57.476 [mobservice2] INFO info 324b52ce-fbd2-11eb-b0ae-0242ac110003:pvKgfqae write success
  09:03:00.361 [dbservice1] INFO 33c932ce-fbd2-11eb-989d-0242ac110003-HwOItPMW-n7V8wc%z?O6g token generate success token=MTYyODgxNjU4MC4zNjEyMDk5OjMzYzkzMmNlLWZiZDItMTFlYi05ODlkLTAyNDJhYzE
  09:03:02.951 [dbservice2] INFO 356a6594-fbd2-11eb-9d72-0242ac110004-WRrkiQEt-6aT9E1w<+@(I token generate success token=MTYyODgxNjU4Mi45NTA1NDQ0OjM1NmE2NTk0LWZiZDItMTFlYi05ZDcyLTAyNDJhYzE
  09:03:06.247 [dbservice1] INFO 3750aecc-fbd2-11eb-abc2-0242ac110003-btlsWgLd-X^oq#)eu9Fd/ token generate success token=MTYyODgxNjU4Ni4yNDc1NDA1OjM3NTBhZWNjLWZiZDItMTFlYi1hYmMyLTAyNDJhYzE

## p0166
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T06:26:02.840Z
```
{"timestamp":1731911162840808200,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-svrwm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"GetCartAsync called with userId=736a09b5-665e-4823-8520-b8602b0bdbff"}
```
Same service, the 2 minutes before (oldest first):
  06:25:58.547 [cartservice] GetCartAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add  (×17)
  06:25:58.578 [cartservice] EmptyCartAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add  (×2)
  06:26:00.468 [cartservice] AddItemAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432, productId=2ZYFJ3GM2N, quantity=10
All services, 30 seconds either side (sampled):
  06:25:33.083 [frontend] request started  (×321)
  06:25:33.092 [cartservice] GetCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03  (×260)
  06:25:33.113 [adservice] received ad request (context_words=[decor, home])  (×16)
  06:25:33.659 [adservice] received ad request (context_words=[footwear])  (×14)
  06:25:34.576 [cartservice] AddItemAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432, productId=66VCHSJNUP, quantity=10  (×34)
  06:25:34.611 [shippingservice] [GetQuote] completed request  (×81)
  06:25:34.866 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"179","nanos":900000000},"credit_card":{"credit_card_number":"48534260914056  (×3)
  06:25:34.870 [shippingservice] [ShipOrder] received request  (×15)
  06:25:34.880 [emailservice] A request to send order confirmation email to elizabeth09@example.com has been received.
  06:25:35.255 [adservice] received ad request (context_words=[accessories])  (×31)
  06:25:36.854 [frontend] ENV_PLATFORM is: aws  (×33)
  06:25:37.846 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z']
  06:25:39.048 [paymentservice] Transaction processed: visa ending 9504 Amount: EUR3463.609022585  (×4)
  06:25:39.154 [checkoutservice] [PlaceOrder] user_id="33421b66-55b6-413b-9ba9-3230c85c58dc" user_currency="CAD"  (×4)
  06:25:39.189 [emailservice] A request to send order confirmation email to kanekimberly@example.org has been received.
  06:25:40.444 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"110829","nanos":487838165},"credit_card":{"credit_card_number":"42235373682  (×4)
  06:25:40.457 [checkoutservice] order confirmation email sent to "dennis73@example.net"
  06:25:45.683 [checkoutservice] order confirmation email sent to "browngabriela@example.com"
  06:25:58.050 [emailservice] A request to send order confirmation email to nicholasacosta@example.org has been received.
  06:25:58.585 [checkoutservice] order confirmation email sent to "dennisbryant@example.net"
  06:26:04.268 [emailservice] A request to send order confirmation email to audreycunningham@example.net has been received.
  06:26:04.360 [checkoutservice] order confirmation email sent to "dwatson@example.net"
  06:26:08.052 [redis] 63:C 18 Nov 2024 06:26:08.051 * DB saved on disk
  06:26:14.421 [emailservice] A request to send order confirmation email to lisaruiz@example.net has been received.
  06:26:17.488 [checkoutservice] order confirmation email sent to "ivan71@example.org"
  06:26:28.164 [emailservice] A request to send order confirmation email to pperry@example.net has been received.

## p0228
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:52:24.902Z
```
{"timestamp":1731916344902941200,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  07:52:23.723 [frontend] request complete  (×6)
  07:52:23.881 [frontend] request started  (×7)
  07:52:23.881 [frontend] serving product page  (×3)
  07:52:24.819 [frontend] adding to cart
  07:52:24.832 [frontend] view user cart  (×2)
  07:52:24.871 [frontend] placing order
All services, 30 seconds either side (sampled):
  07:51:54.962 [frontend] request started  (×322)
  07:51:54.971 [cartservice] GetCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121  (×268)
  07:51:54.994 [adservice] received ad request (context_words=[decor, home])  (×20)
  07:51:55.313 [frontend] ENV_PLATFORM is: aws  (×27)
  07:51:55.570 [frontend] adding to cart  (×36)
  07:51:55.604 [shippingservice] [GetQuote] received request  (×79)
  07:51:57.222 [frontend] setting currency  (×18)
  07:51:57.628 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="TRY"  (×3)
  07:51:57.660 [checkoutservice] payment went through (transaction_id: a4ef336f-bde3-4903-aecd-48a080f713d9)  (×14)
  07:51:57.664 [cartservice] EmptyCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×14)
  07:51:57.673 [frontend] order placed  (×14)
  07:52:00.654 [emailservice] listening on port: 8080
  07:52:03.888 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="EUR"  (×2)
  07:52:03.923 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 13  (×13)
  07:52:05.431 [checkoutservice] [PlaceOrder] user_id="736a09b5-665e-4823-8520-b8602b0bdbff" user_currency="CAD"  (×3)
  07:52:05.468 [emailservice] A request to send order confirmation email to ccraig@example.com has been received.
  07:52:12.120 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"53","nanos":940000000},"credit_card":{"credit_card_number":"488826840967575  (×4)
  07:52:12.135 [checkoutservice] failed to send order confirmation to "whooper@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:52:17.876 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="JPY"  (×2)
  07:52:17.912 [emailservice] A request to send order confirmation email to karenmueller@example.net has been received.
  07:52:23.705 [emailservice] A request to send order confirmation email to tammyferrell@example.org has been received.
  07:52:24.905 [checkoutservice] failed to send order confirmation to "maryanthony@example.net": rpc error: code = Internal desc = Failed to serialize response!
  07:52:30.315 [emailservice] A request to send order confirmation email to garciazachary@example.net has been received.
  07:52:37.912 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', '1YMWWN1N4O', '2ZYFJ3GM2N', '66VCHSJNUP']
  07:52:45.997 [emailservice] A request to send order confirmation email to mcbridemelanie@example.net has been received.
  07:52:46.630 [checkoutservice] failed to send order confirmation to "richardsgregory@example.org": rpc error: code = Internal desc = Failed to serialize response!

## p0517
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:42:19.955Z
```
{"timestamp":1732358539955670800,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"6741b18ba437380001df4b93"}
```
Same service, the 2 minutes before (oldest first):
  10:42:19.777 [front-end] DELETE /cart 202 - ms - -
  10:42:19.779 [front-end] GET /catalogue 200 - ms - -
  10:42:19.782 [front-end] Attempting to add to cart: {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","quantity":1}
  10:42:19.785 [front-end] Posting Customer: {"username":"mOsUajmTCOuD","password":"PclXD","email":"mOsUajmTCOuD@gmail.com","firstName":"mOsUajmTCOuD","lastName":"mOsUajmTCOuD"}
  10:42:19.791 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  10:42:19.791 [front-end] POST to carts: http://carts/carts/6741b186a437380001df4b87/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}
  10:42:19.794 [front-end] { id: '6741b18ba437380001df4b91' }  (×3)
  10:42:19.794 [front-end] 6741b18ba437380001df4b91  (×2)
  10:42:19.794 [front-end] Merging carts for customer id: 6741b18ba437380001df4b91 and session id: l3waOL3bBSR-X-OovXFRKSwKqWy2qmOC  (×2)
  10:42:19.828 [front-end] Carts merged.
  10:42:19.828 [front-end] set cookie6741b18ba437380001df4b91
  10:42:19.828 [front-end] Sent cookies.
  10:42:19.829 [front-end] POST /register 200 42.762 ms - 33
  10:42:19.845 [front-end] POST /cart 201 - ms - -
  10:42:19.936 [front-end] Posting Customer: {"username":"SlOUiiS","password":"OpdYMEsfX","email":"SlOUiiS@gmail.com","firstName":"SlOUiiS","lastName":"SlOUiiS"}
  10:42:19.947 [front-end] Posting Customer: {"username":"RIAVrKz","password":"FyNLWoFcm","email":"RIAVrKz@gmail.com","firstName":"RIAVrKz","lastName":"RIAVrKz"}
All services, 30 seconds either side (sampled):
  10:41:49.961 [catalogue] ts=2024-11-23T10:41:49Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.160667ms  (×57)
  10:41:50.066 [session-db] 50:C 23 Nov 2024 10:41:50.066 * Fork CoW for RDB: current 0 MB, peak 0 MB, average 0 MB
  10:41:50.197 [front-end] Request received with body: {}  (×57)
  10:41:50.244 [orders] 2024-11-23 10:41:50.244 INFO [orders,e18e708728efb8b9,d8f87c65d6ace17e,false] 7 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Sending payment req  (×42)
  10:41:50.268 [front-end] POST /orders 201 - ms - -  (×57)
  10:41:50.978 [front-end] Order response: {"id":"6741b16e01dd390007094deb","customerId":"6741b154a437380001df4af2","customer":{"id":null,"firstName":"MICYQy","lastName":"MICYQy","usernam
  10:41:51.225 [front-end] Order response: {"id":"6741b16f01dd390007094ded","customerId":"6741b161a437380001df4b19","customer":{"id":null,"firstName":"KPLVPuSnOQeNvh","lastName":"KPLVPuSn
  10:41:52.247 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b17001dd390007094dee","customerId":"6741b160a437380001df4b18","customer":{"id":null,"firstName":"YszLU","las
  10:41:54.852 [front-end] Received response: "{\"firstName\":\"lTyDxVi\",\"lastName\":\"lTyDxVi\",\"username\":\"lTyDxVi\",\"id\":\"6741b15fa437380001df4b14\",\"_links\":{\"addresses\":{
  10:41:55.759 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×11)
  10:41:57.157 [front-end] Order response: {"id":"6741b17501dd390007094df4","customerId":"6741b15ca437380001df4b07","customer":{"id":null,"firstName":"VkjiwmTiXIs","lastName":"VkjiwmTiXIs
  10:42:00.355 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b17801dd390007094df6","customerId":"6741b165a437380001df4b2c","customer":{"id":null,"firstName":"VHERO","las
  10:42:02.282 [front-end] Order response: {"id":"6741b17a01dd390007094df8","customerId":"6741b163a437380001df4b1e","customer":{"id":null,"firstName":"AsWOJvoKNL","lastName":"AsWOJvoKNL",
  10:42:05.001 [front-end] Received response: "{\"firstName\":\"sjfrIBFtnOMwhK\",\"lastName\":\"sjfrIBFtnOMwhK\",\"username\":\"sjfrIBFtnOMwhK\",\"id\":\"6741b16aa437380001df4b3a\",\"_lin
  10:42:06.357 [front-end] Posting Customer: {"username":"DjEHXcoqHgWxYbC","password":"dYGzfOac","email":"DjEHXcoqHgWxYbC@gmail.com","firstName":"DjEHXcoqHgWxYbC","lastName":"DjEHXcoqHgWx
  10:42:08.984 [payment] ts=2024-11-23T10:42:08Z caller=logging.go:29 method=Authorise result=false took=7.002µs  (×4)
  10:42:13.530 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b18501dd390007094e02","customerId":"6741b16fa437380001df4b4a","customer":{"id":null,"firstName":"DSAgaYnbcBN
  10:42:17.181 [front-end] Received response: "{\"firstName\":\"BBoDQLZVQIzI\",\"lastName\":\"BBoDQLZVQIzI\",\"username\":\"BBoDQLZVQIzI\",\"id\":\"6741b176a437380001df4b64\",\"_links\":{
  10:42:18.245 [front-end] Order response: {"id":"6741b18a01dd390007094e08","customerId":"6741b175a437380001df4b60","customer":{"id":null,"firstName":"vqiGwzuJlekI","lastName":"vqiGwzuJle
  10:42:23.996 [front-end] Received response: "{\"firstName\":\"jGtfmTYFLF\",\"lastName\":\"jGtfmTYFLF\",\"username\":\"jGtfmTYFLF\",\"id\":\"6741b17ba437380001df4b72\",\"_links\":{\"addr
  10:42:24.904 [user] ts=2024-11-23T10:42:24.904623485Z caller=middlewares.go:46 method=Register username=SGHrmQKj email=SGHrmQKj@gmail.com took=2.263575ms
  10:42:27.029 [front-end] Posting Customer: {"username":"drIpSVYoFYMY","password":"YGkAbaE","email":"drIpSVYoFYMY@gmail.com","firstName":"drIpSVYoFYMY","lastName":"drIpSVYoFYMY"}
  10:42:29.218 [front-end] Posting Customer: {"username":"mGHHyeKOwbUN","password":"QBuLJML","email":"mGHHyeKOwbUN@gmail.com","firstName":"mGHHyeKOwbUN","lastName":"mGHHyeKOwbUN"}
  10:42:32.458 [front-end] Received response: "{\"firstName\":\"fMqkVIscpJAub\",\"lastName\":\"fMqkVIscpJAub\",\"username\":\"fMqkVIscpJAub\",\"id\":\"6741b183a437380001df4b7f\",\"_links\
  10:42:34.942 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19a01dd390007094e14","customerId":"6741b186a437380001df4b87","customer":{"id":null,"firstName":"OePlWpOYf",
  10:42:38.441 [front-end] Posting Customer: {"username":"qxMKJWILAB","password":"nPYAMbLTCN","email":"qxMKJWILAB@gmail.com","firstName":"qxMKJWILAB","lastName":"qxMKJWILAB"}
  10:42:40.192 [front-end] Order response: {"id":"6741b1a001dd390007094e17","customerId":"6741b186a437380001df4b88","customer":{"id":null,"firstName":"CydfEIYWaRvI","lastName":"CydfEIYWaR
  10:42:43.085 [front-end] Posting Customer: {"username":"UILHEiEVVssclad","password":"ZqCUxOuP","email":"UILHEiEVVssclad@gmail.com","firstName":"UILHEiEVVssclad","lastName":"UILHEiEVVssc
  10:42:45.526 [front-end] Order response: {"id":"6741b1a501dd390007094e1c","customerId":"6741b196a437380001df4bad","customer":{"id":null,"firstName":"DMOcLvEBWyzQX","lastName":"DMOcLvEBW
  10:42:47.181 [front-end] Posting Customer: {"username":"EuaRkWCg","password":"mitRj","email":"EuaRkWCg@gmail.com","firstName":"EuaRkWCg","lastName":"EuaRkWCg"}

## p0301
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-22T03:20:06.586Z
```
{"timestamp":1732245606586941200,"container_name":"orders","pod_name":"orders-5fd66f9688-2x7kx","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-22 03:20:06.586 ERROR [orders,,,] 6 --- [p-nio-80-exec-2] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalStateException: Unable to create order due to unspecified IO error.] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  (nothing)
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×21)
  03:20:06.540 [user] ts=2024-11-22T03:20:06.540288162Z caller=middlewares.go:75 method=GetUsers id=673ff84eb0df5c00019b1e6c result=1 took=1.052177ms  (×41)
  03:20:06.550 [user] ts=2024-11-22T03:20:06.549939822Z caller=middlewares.go:104 method=GetAddresses id=673ff854b0df5c00019b1e7e result=1 took=839.732µs  (×22)
  03:20:06.591 [front-end] POST /orders 500 - ms - -  (×36)
  03:20:06.664 [user] ts=2024-11-22T03:20:06.664037694Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff861b0df5c00019b1e9e took=1.670187ms  (×36)
  03:20:06.779 [front-end] Attempting to add to cart: {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×35)
  03:20:06.803 [front-end] POST to carts: http://carts/carts/673ff860b0df5c00019b1e9b/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}  (×28)
  03:20:06.963 [orders] 2024-11-22 03:20:06.963 ERROR [orders,,,] 6 --- [p-nio-80-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×20)
  03:20:08.182 [front-end] GET /catalogue 200 - ms - -  (×30)
  03:20:08.474 [front-end] 673ff868b0df5c00019b1eb9  (×29)
  03:20:08.498 [front-end] Sent cookies.  (×29)
  03:20:09.093 [user] ts=2024-11-22T03:20:09.093546446Z caller=middlewares.go:157 method=Health result=2 took=1.105162ms
  03:20:09.192 [carts] 2024-11-22 03:20:09.192 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  03:20:09.944 [user] ts=2024-11-22T03:20:09.944714234Z caller=middlewares.go:46 method=Register username=TpbEqowkn email=TpbEqowkn@gmail.com took=1.003034ms
  03:20:11.559 [user] ts=2024-11-22T03:20:11.558844653Z caller=middlewares.go:46 method=Register username=xQhxkcD email=xQhxkcD@gmail.com took=1.123618ms
  03:20:12.464 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×4)
  03:20:14.697 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×4)
  03:20:16.381 [user] ts=2024-11-22T03:20:16.381484973Z caller=middlewares.go:46 method=Register username=zCHyJV email=zCHyJV@gmail.com took=895.452µs
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:20.321 [front-end] Received response: "{\"firstName\":\"hRqnN\",\"lastName\":\"hRqnN\",\"username\":\"hRqnN\",\"id\":\"673ff85bb0df5c00019b1e8d\",\"_links\":{\"addresses\":{\"href
  03:20:21.876 [front-end] Received response: "{\"firstName\":\"GSlyQdwsNkS\",\"lastName\":\"GSlyQdwsNkS\",\"username\":\"GSlyQdwsNkS\",\"id\":\"673ff862b0df5c00019b1ea1\",\"_links\":{\"a
  03:20:24.692 [carts] 2024-11-22 03:20:24.692 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  03:20:26.469 [front-end] Received response: "{\"firstName\":\"tbhaDXI\",\"lastName\":\"tbhaDXI\",\"username\":\"tbhaDXI\",\"id\":\"673ff865b0df5c00019b1ea5\",\"_links\":{\"addresses\":{
  03:20:28.426 [user] ts=2024-11-22T03:20:28.426008438Z caller=middlewares.go:46 method=Register username=MoGml email=MoGml@gmail.com took=1.054731ms
  03:20:30.252 [front-end] Posting Customer: {"username":"MKGIsEbVYi","password":"VhFAQhsXw","email":"MKGIsEbVYi@gmail.com","firstName":"MKGIsEbVYi","lastName":"MKGIsEbVYi"}
  03:20:32.204 [front-end] Posting Customer: {"username":"znIVGAMLgnSste","password":"zCqOHq","email":"znIVGAMLgnSste@gmail.com","firstName":"znIVGAMLgnSste","lastName":"znIVGAMLgnSste"}
  03:20:32.913 [front-end] Received response: "{\"firstName\":\"xQhxkcD\",\"lastName\":\"xQhxkcD\",\"username\":\"xQhxkcD\",\"id\":\"673ff86bb0df5c00019b1ec3\",\"_links\":{\"addresses\":{
  03:20:34.676 [front-end] Received response: "{\"firstName\":\"BBYdunXrngQk\",\"lastName\":\"BBYdunXrngQk\",\"username\":\"BBYdunXrngQk\",\"id\":\"673ff874b0df5c00019b1ee8\",\"_links\":{

## p0203
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:57:55.061Z
```
{"timestamp":1731913075061183700,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  06:57:53.555 [frontend] serving product page  (×7)
  06:57:53.587 [frontend] request complete  (×7)
  06:57:53.826 [frontend] request started  (×6)
All services, 30 seconds either side (sampled):
  06:57:26.785 [frontend] request started  (×329)
  06:57:26.789 [frontend] home  (×28)
  06:57:26.803 [currencyservice] conversion request successful  (×681)
  06:57:26.908 [frontend] serving product page  (×154)
  06:57:26.945 [frontend] adding to cart  (×42)
  06:57:26.979 [shippingservice] [GetQuote] received request  (×85)
  06:57:27.841 [adservice] received ad request (context_words=[decor, home])  (×22)
  06:57:28.992 [adservice] received ad request (context_words=[footwear])  (×16)
  06:57:35.238 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="GBP"  (×2)
  06:57:35.276 [checkoutservice] payment went through (transaction_id: 07228f6c-9211-4bbd-a53b-f20a64bf3efa)  (×13)
  06:57:35.281 [cartservice] EmptyCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×13)
  06:57:35.292 [frontend] order placed  (×13)
  06:57:40.744 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"11147","nanos":62353903},"credit_card":{"credit_card_number":"4833814864981
  06:57:40.760 [checkoutservice] order confirmation email sent to "paulamitchell@example.org"
  06:57:50.701 [paymentservice] Transaction processed: visa ending 0224 Amount: CAD575.104870416  (×2)
  06:57:51.552 [checkoutservice] [PlaceOrder] user_id="b63bea0e-d05f-4589-be71-8fef43557432" user_currency="USD"  (×4)
  06:57:51.601 [emailservice] A request to send order confirmation email to ljones@example.net has been received.
  06:57:59.414 [checkoutservice] order confirmation email sent to "john72@example.com"
  06:58:07.031 [paymentservice] Transaction processed: visa ending 5464 Amount: JPY18550.220256938
  06:58:11.550 [emailservice] A request to send order confirmation email to kevin94@example.com has been received.
  06:58:16.950 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"175","nanos":488721809},"credit_card":{"credit_card_number":"40970474614919  (×3)
  06:58:16.965 [checkoutservice] order confirmation email sent to "timothywise@example.com"
  06:58:18.327 [emailservice] A request to send order confirmation email to dennis76@example.com has been received.
  06:58:19.477 [checkoutservice] order confirmation email sent to "hebertjames@example.com"
  06:58:19.729 [emailservice] A request to send order confirmation email to smithkyle@example.net has been received.

## p0224
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:50:39.307Z
```
{"timestamp":1731916239307109000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  07:50:38.981 [frontend] serving product page  (×2)
  07:50:39.012 [frontend] request complete  (×6)
  07:50:39.015 [frontend] request started  (×6)
  07:50:39.015 [frontend] adding to cart  (×2)
  07:50:39.028 [frontend] view user cart  (×2)
  07:50:39.240 [frontend] placing order
  07:50:39.290 [frontend] order placed
All services, 30 seconds either side (sampled):
  07:50:09.476 [frontend] request started  (×313)
  07:50:09.484 [cartservice] GetCartAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43  (×259)
  07:50:09.507 [adservice] received ad request (context_words=[decor, home])  (×26)
  07:50:09.810 [frontend] setting currency  (×19)
  07:50:09.859 [adservice] received ad request (context_words=[])  (×31)
  07:50:13.241 [adservice] received ad request (context_words=[footwear])  (×14)
  07:50:13.363 [frontend] view user cart  (×65)
  07:50:13.385 [shippingservice] [GetQuote] completed request  (×77)
  07:50:19.008 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="EUR"  (×2)
  07:50:19.050 [checkoutservice] payment went through (transaction_id: 8c4728bd-7ce5-4546-b39f-21f08292ae5f)  (×12)
  07:50:19.056 [cartservice] EmptyCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×12)
  07:50:19.064 [frontend] order placed  (×12)
  07:50:25.663 [paymentservice] Transaction processed: visa ending 6785 Amount: GBP630.223598405  (×3)
  07:50:29.619 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="CAD"  (×2)
  07:50:29.665 [emailservice] A request to send order confirmation email to shelby84@example.net has been received.
  07:50:30.651 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"3452","nanos":152888149},"credit_card":{"credit_card_number":"4123855770322  (×2)
  07:50:30.666 [checkoutservice] order confirmation email sent to "tbaker@example.org"
  07:50:31.471 [paymentservice] Transaction processed: visa ending 8186 Amount: USD213.880000000  (×2)
  07:50:39.287 [emailservice] A request to send order confirmation email to omanning@example.com has been received.
  07:50:45.478 [checkoutservice] order confirmation email sent to "tracy53@example.org"
  07:50:50.527 [emailservice] A request to send order confirmation email to jenkinsandrew@example.org has been received.
  07:50:50.947 [checkoutservice] order confirmation email sent to "karen52@example.org"
  07:51:00.790 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '66VCHSJNUP', 'LS4PSXUNUM']  (×2)
  07:51:05.079 [paymentservice] Transaction processed: visa ending 5084 Amount: JPY200199.486954185

## p0157
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:45:23.520Z
```
{"timestamp":1731908723520174800,"container_name":"adservice","pod_name":"adservice-b9bcc6cc9-sdkf5","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"received ad request (context_words=[])"}
```
Same service, the 2 minutes before (oldest first):
  05:45:16.202 [adservice] received ad request (context_words=[accessories])  (×5)
  05:45:17.732 [adservice] received ad request (context_words=[])  (×3)
  05:45:18.160 [adservice] received ad request (context_words=[kitchen])  (×6)
  05:45:18.380 [adservice] received ad request (context_words=[decor, home])  (×3)
  05:45:21.940 [adservice] received ad request (context_words=[hair, beauty])
  05:45:22.125 [adservice] received ad request (context_words=[clothing, tops])  (×2)
All services, 30 seconds either side (sampled):
  05:44:53.679 [frontend] request started  (×270)
  05:44:53.688 [cartservice] GetCartAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432  (×222)
  05:44:53.712 [adservice] received ad request (context_words=[accessories])  (×41)
  05:44:53.719 [frontend] span hipstershop.CartService/AddItem failed with gRPC status 9  (×29)
  05:44:53.723 [frontend] request error  (×29)
  05:44:53.757 [shippingservice] [GetQuote] received request  (×47)
  05:44:53.765 [paymentservice] Transaction processed: visa ending 5869 Amount: GBP2061.683034049  (×4)
  05:44:53.769 [shippingservice] [ShipOrder] completed request  (×9)
  05:44:53.779 [checkoutservice] order confirmation email sent to "jacksonrenee@example.org"
  05:44:54.043 [emailservice] A request to send order confirmation email to rbarrera@example.org has been received.
  05:44:54.570 [adservice] received ad request (context_words=[clothing, tops])  (×17)
  05:45:02.503 [frontend] home  (×30)
  05:45:04.058 [adservice] received ad request (context_words=[footwear])  (×11)
  05:45:08.823 [checkoutservice] order confirmation email sent to "broberson@example.org"
  05:45:20.903 [paymentservice] Transaction processed: visa ending 1006 Amount: JPY1005.162317560  (×2)
  05:45:22.901 [emailservice] A request to send order confirmation email to millertracy@example.org has been received.
  05:45:31.061 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"12","nanos":30138876},"credit_card":{"credit_card_number":"4752765392803359
  05:45:31.076 [checkoutservice] order confirmation email sent to "bterry@example.com"
  05:45:40.816 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"798","nanos":549314470},"credit_card":{"credit_card_number":"43476196003313
  05:45:40.831 [checkoutservice] order confirmation email sent to "mccarthydavid@example.org"
  05:45:47.676 [paymentservice] Transaction processed: visa ending 4373 Amount: TRY12254.655160611
  05:45:48.096 [emailservice] A request to send order confirmation email to wardthomas@example.com has been received.

## p0666
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-11T09:11:53.504Z
```
{"service":"dbservice1","message":"2021-08-11 09:11:53,504 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 934f6fa048db071b | 1cc9a7e4-fa41-11eb-ac0c-0242ac110004-VcbkjSAZ-H}z)MI_t986B token generate success token=MTYyODY0NDMxMy41MDM3NDAzOjFjYzlhN2U0LWZhNDEtMTFlYi1hYzBjLTAyNDJhYzExMDAwNFZjYmtqU0FaSH16KU1JX3Q5ODZCOjE2Mjg2NDQzNzMuNTAzNzUyOjk5NjFjMTE2N2FhMTFkOGY4YWNkYzNhMmFhM2ExNzBl"}
```
Same service, the 2 minutes before (oldest first):
  09:11:41.806 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  09:11:42.450 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  09:11:42.450 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  09:11:42.514 [dbservice1] INFO query = select passwards from username_table where user_name='ArxCmQcb'  (×5)
  09:11:42.593 [dbservice1] INFO 164cffce-fa41-11eb-8ed2-0242ac110003-ArxCmQcb-p-n+Fy1&AjMv token generate success token=MTYyODY0NDMwMi41OTMwMTY0OjE2NGNmZmNlLWZhNDEtMTFlYi04ZWQyLTAyNDJhYzE
  09:11:44.299 [dbservice1] INFO 174a886a-fa41-11eb-a068-0242ac110004-dlznWOTR-j<7FGs8(h_fA token generate success token=MTYyODY0NDMwNC4yOTg5MDQyOjE3NGE4ODZhLWZhNDEtMTFlYi1hMDY4LTAyNDJhYzE
  09:11:45.906 [dbservice1] INFO 183f31d0-fa41-11eb-b4be-0242ac110003-OVhMJowB-tS9TykY$s?)x token generate success token=MTYyODY0NDMwNS45MDY0NTk2OjE4M2YzMWQwLWZhNDEtMTFlYi1iNGJlLTAyNDJhYzE
  09:11:50.174 [dbservice1] INFO 1acc02c0-fa41-11eb-831f-0242ac110004-xXiaofbu-2Yl&jd#+ApZV token generate success token=MTYyODY0NDMxMC4xNzM3NzU0OjFhY2MwMmMwLWZhNDEtMTFlYi04MzFmLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  09:11:23.508 [redisservice1] INFO redis write success  (×83)
  09:11:23.625 [webservice1] INFO complete information: {'uuid': '0b4d6ca8-fa41-11eb-87e0-0242ac110003', 'user_id': 'ulnvrqij'}  (×42)
  09:11:23.812 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '0b4d6ca8-fa41-11eb-87e0-0242ac110003', 'value': 'ulnvrqij'}  (×44)
  09:11:23.986 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×43)
  09:11:24.181 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  09:11:24.403 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×41)
  09:11:24.917 [redisservice1] INFO redis读取信息成功, status_code: 200  (×44)
  09:11:25.263 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '0c631282-fa41-11eb-a2a9-0242ac110004', 'value': '', 'ex': 10}  (×42)
  09:11:27.506 [mobservice2] INFO info 0d8159bc-fa41-11eb-8c17-0242ac110004:GFdYHwiu write success
  09:11:30.158 [dbservice2] INFO 0ed56f88-fa41-11eb-8472-0242ac110003-KrCJbket-SDY(Ra?xklfj token generate success token=MTYyODY0NDI5MC4xNTc1NDQ0OjBlZDU2Zjg4LWZhNDEtMTFlYi04NDcyLTAyNDJhYzE
  09:11:32.913 [dbservice1] INFO 107d418a-fa41-11eb-8a53-0242ac110003-UFfHkLJX-@+Fs&*Co(Pu- token generate success token=MTYyODY0NDI5Mi45MTMyMzQ3OjEwN2Q0MThhLWZhNDEtMTFlYi04YTUzLTAyNDJhYzE
  09:11:35.595 [dbservice1] INFO 120b7dd2-fa41-11eb-bd34-0242ac110003-NOmfIvPM-6W3hHD^pXQO< token generate success token=MTYyODY0NDI5NS41OTQ1NjU2OjEyMGI3ZGQyLWZhNDEtMTFlYi1iZDM0LTAyNDJhYzE
  09:11:38.415 [mobservice1] INFO info 14025688-fa41-11eb-9d83-0242ac110003:TEzNtqXJ write success
  09:11:41.223 [mobservice1] INFO info 15ad6ce8-fa41-11eb-809b-0242ac110003:wVcuUpbK write success
  09:11:43.433 [dbservice2] INFO 16cb9bb8-fa41-11eb-a4fc-0242ac110004-pVblEhjw-SiZo2*.WPsa% token generate success token=MTYyODY0NDMwMy40MzI2Mjg2OjE2Y2I5YmI4LWZhNDEtMTFlYi1hNGZjLTAyNDJhYzE
  09:11:45.906 [dbservice1] INFO 183f31d0-fa41-11eb-b4be-0242ac110003-OVhMJowB-tS9TykY$s?)x token generate success token=MTYyODY0NDMwNS45MDY0NTk2OjE4M2YzMWQwLWZhNDEtMTFlYi1iNGJlLTAyNDJhYzE
  09:11:53.083 [mobservice2] INFO info 1cc9a7e4-fa41-11eb-ac0c-0242ac110004:VcbkjSAZ write success
  09:11:56.701 [mobservice2] INFO info 1ee7152a-fa41-11eb-be9b-0242ac110003:dMOcrJWb write success
  09:11:59.713 [dbservice2] INFO 207940fc-fa41-11eb-832c-0242ac110003-dneSsIED-8P7mNRZk<p&e token generate success token=MTYyODY0NDMxOS43MTI5NTA3OjIwNzk0MGZjLWZhNDEtMTFlYi04MzJjLTAyNDJhYzE
  09:12:02.844 [mobservice2] INFO info 229c3254-fa41-11eb-9f11-0242ac110004:XdvDclow write success
  09:12:05.828 [dbservice1] INFO 241ce948-fa41-11eb-8a0e-0242ac110003-ztuaUykM-dE:?f1Sbn.l^ token generate success token=MTYyODY0NDMyNS44Mjg0MDU6MjQxY2U5NDgtZmE0MS0xMWViLThhMGUtMDI0MmFjMTE
  09:12:08.288 [dbservice2] INFO 259ad5f0-fa41-11eb-a3cb-0242ac110003-bJckhDFR-2Rh)TY-Lf_{s token generate success token=MTYyODY0NDMyOC4yODgxNDM5OjI1OWFkNWYwLWZhNDEtMTFlYi1hM2NiLTAyNDJhYzE
  09:12:10.643 [dbservice2] INFO 26fbc9d6-fa41-11eb-8c08-0242ac110003-tcvLYMig-0-iMCvLR/h*k token generate success token=MTYyODY0NDMzMC42NDM0Mzc5OjI2ZmJjOWQ2LWZhNDEtMTFlYi04YzA4LTAyNDJhYzE
  09:12:13.730 [mobservice1] INFO info 290869b4-fa41-11eb-a91c-0242ac110003:yHoAlkMd write success
  09:12:16.265 [mobservice2] INFO info 2a992778-fa41-11eb-991f-0242ac110004:kuaemYbD write success
  09:12:19.221 [dbservice1] INFO 2c178054-fa41-11eb-ba32-0242ac110004-aLCdNFuD->*a5MwtuL=pF token generate success token=MTYyODY0NDMzOS4yMjE0Mzk6MmMxNzgwNTQtZmE0MS0xMWViLWJhMzItMDI0MmFjMTE
  09:12:21.965 [dbservice1] INFO 2db77b08-fa41-11eb-af3a-0242ac110003-hlZNRKOv-VAn+:K$t4qsB token generate success token=MTYyODY0NDM0MS45NjUwNTM6MmRiNzdiMDgtZmE0MS0xMWViLWFmM2EtMDI0MmFjMTE

## p0029
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T07:41:21.516Z
```
{"service":"logservice1","message":"2021-08-13 07:41:21,516 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | fae6ee551eabde00 | the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389"}
```
Same service, the 2 minutes before (oldest first):
  07:41:18.123 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  07:41:18.123 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': 'ca02afc4-fbc6-11eb-8b27-0242ac110004', 'user_id': 'wyIESLrY'}  (×5)
  07:41:18.897 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  07:41:18.898 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  07:41:18.898 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'ca874306-fbc6-11eb-8785-0242ac110003'}  (×2)
  07:41:18.954 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×2)
  07:41:19.831 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×2)
  07:41:19.832 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×2)
All services, 30 seconds either side (sampled):
  07:40:51.518 [redisservice1] INFO redis write success  (×85)
  07:40:51.652 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': 'ba3ea2b4-fbc6-11eb-a4b6-0242ac110003', 'user_id': 'CkWFaQYZ'}  (×82)
  07:40:51.899 [dbservice2] INFO ba3ea2b4-fbc6-11eb-a4b6-0242ac110003-CkWFaQYZ-7JwrWYRM-C^D token generate success token=MTYyODgxMTY1MS44OTg1MjQ6YmEzZWEyYjQtZmJjNi0xMWViLWE0YjYtMDI0MmFjMTE
  07:40:52.180 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×42)
  07:40:52.692 [dbservice2] INFO babb986e-fbc6-11eb-8c03-0242ac110004-IjgwExRc-SL&dYC@_yX^8 token generate success token=MTYyODgxMTY1Mi42OTE3NDc0OmJhYmI5ODZlLWZiYzYtMTFlYi04YzAzLTAyNDJhYzE
  07:40:53.170 [mobservice2] INFO info bb3a668a-fbc6-11eb-8371-0242ac110003:QTpUuoqV write success
  07:40:53.415 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×50)
  07:40:54.210 [dbservice2] INFO bba2dc2e-fbc6-11eb-8acd-0242ac110003-DHpIOPcr--ZJF#vtu)<Ez token generate success token=MTYyODgxMTY1NC4yMTAxNTEyOmJiYTJkYzJlLWZiYzYtMTFlYi04YWNkLTAyNDJhYzE
  07:40:55.900 [mobservice1] INFO info bcd55c3e-fbc6-11eb-98b1-0242ac110004:WstfjpFZ write success
  07:40:58.457 [webservice1] ERROR an error occurred in the downstream service
  07:41:01.067 [dbservice1] INFO bfaf2390-fbc6-11eb-a004-0242ac110003-IMzHpvSY-bhtqgr.x2AfF token generate success token=MTYyODgxMTY2MS4wNjczMzA2OmJmYWYyMzkwLWZiYzYtMTFlYi1hMDA0LTAyNDJhYzE
  07:41:03.756 [dbservice1] INFO c14f837a-fbc6-11eb-939a-0242ac110004-VizMUmJR-FY?r-G0Za*AR token generate success token=MTYyODgxMTY2My43NTU2ODQxOmMxNGY4MzdhLWZiYzYtMTFlYi05MzlhLTAyNDJhYzE
  07:41:06.662 [dbservice1] INFO c2efd75c-fbc6-11eb-8858-0242ac110004-bGtJCiAM-5{+Aa/EZ2QN( token generate success token=MTYyODgxMTY2Ni42NjIyNjQ4OmMyZWZkNzVjLWZiYzYtMTFlYi04ODU4LTAyNDJhYzE
  07:41:09.156 [dbservice2] INFO c48b8dfe-fbc6-11eb-86a7-0242ac110003-rJNyXqRj-p$^%8M<usL@t token generate success token=MTYyODgxMTY2OS4xNTU4NjA0OmM0OGI4ZGZlLWZiYzYtMTFlYi04NmE3LTAyNDJhYzE
  07:41:11.831 [dbservice1] INFO c60d9bea-fbc6-11eb-a44d-0242ac110004-HXuSgZPY-Ga+n0yVZM9T* token generate success token=MTYyODgxMTY3MS44MzEwMzQ3OmM2MGQ5YmVhLWZiYzYtMTFlYi1hNDRkLTAyNDJhYzE
  07:41:14.447 [mobservice2] INFO info c7e9e400-fbc6-11eb-bccf-0242ac110004:bLKvfOjH write success
  07:41:17.093 [mobservice1] INFO info c966a6f6-fbc6-11eb-8716-0242ac110004:AIKNYSvf write success
  07:41:19.961 [dbservice1] INFO cafb09e4-fbc6-11eb-9b32-0242ac110004-GOhWXRIV-:-)PYXo0ydqc token generate success token=MTYyODgxMTY3OS45NjA5NjQ3OmNhZmIwOWU0LWZiYzYtMTFlYi05YjMyLTAyNDJhYzE
  07:41:22.994 [mobservice2] INFO info cd032140-fbc6-11eb-b984-0242ac110003:vaHXLtfK write success
  07:41:25.884 [mobservice1] INFO info ceadd698-fbc6-11eb-9908-0242ac110004:TPLgkydZ write success
  07:41:28.285 [dbservice1] INFO cffeb558-fbc6-11eb-b4bd-0242ac110003-PuHhfCZO-GImoA>p7EnU6 token generate success token=MTYyODgxMTY4OC4yODQ2NTcyOmNmZmViNTU4LWZiYzYtMTFlYi1iNGJkLTAyNDJhYzE
  07:41:31.917 [dbservice1] INFO d2112b14-fbc6-11eb-86cc-0242ac110004-CzojFELq-MU6*h.QSdBWf token generate success token=MTYyODgxMTY5MS45MTY2ODA4OmQyMTEyYjE0LWZiYzYtMTFlYi04NmNjLTAyNDJhYzE
  07:41:37.859 [dbservice1] INFO d59bc87a-fbc6-11eb-b7f8-0242ac110004-eyfiDUCK-zY5%aIh>H9gZ token generate success token=MTYyODgxMTY5Ny44NTg5NDE4OmQ1OWJjODdhLWZiYzYtMTFlYi1iN2Y4LTAyNDJhYzE
  07:41:40.708 [dbservice1] INFO d72ab71e-fbc6-11eb-9ee4-0242ac110003-DtNVdFIW-^*x0{Xp?zMmG token generate success token=MTYyODgxMTcwMC43MDc5MTQ0OmQ3MmFiNzFlLWZiYzYtMTFlYi05ZWU0LTAyNDJhYzE
  07:41:43.753 [mobservice2] INFO info d9664bce-fbc6-11eb-8eab-0242ac110003:CqkgPMzS write success
  07:41:46.551 [dbservice1] INFO dac286d6-fbc6-11eb-8722-0242ac110003-tdfCvYKb-C%R*^@5Y-oWi token generate success token=MTYyODgxMTcwNi41NTEyMDI6ZGFjMjg2ZDYtZmJjNi0xMWViLTg3MjItMDI0MmFjMTE
  07:41:49.567 [dbservice1] INFO dc7d2f1c-fbc6-11eb-81a4-0242ac110003-yWbZXEez-z1$5aONp@E#j token generate success token=MTYyODgxMTcwOS41NjY1NzEyOmRjN2QyZjFjLWZiYzYtMTFlYi04MWE0LTAyNDJhYzE

## p0057
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T08:38:33.277Z
```
{"service":"dbservice1","message":"2021-08-13 08:38:33,277 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 310aa8cdd46d67b5 | c9674e28-fbce-11eb-9660-0242ac110003-saJCEzRp-rVa(<KJAO=cm token generate success token=MTYyODgxNTExMy4yNzY4NjQ1OmM5Njc0ZTI4LWZiY2UtMTFlYi05NjYwLTAyNDJhYzExMDAwM3NhSkNFelJwclZhKDxLSkFPPWNtOjE2Mjg4MTUxNzMuMjc2ODc1NzowODI0MDc1NmQ1YWU0YjkwMWUwOTMxYWNiMWJmOTFjYw=="}
```
Same service, the 2 minutes before (oldest first):
  08:38:16.720 [dbservice1] INFO bf86a9ee-fbce-11eb-b6ea-0242ac110003-FAmtCcIX-WbpwIhFy&DB@ token generate success token=MTYyODgxNTA5Ni43MTk3NDc6YmY4NmE5ZWUtZmJjZS0xMWViLWI2ZWEtMDI0MmFjMTE
  08:38:17.489 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:38:17.489 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  08:38:17.544 [dbservice1] INFO query = select passwards from username_table where user_name='dzcaqmiU'  (×5)
  08:38:17.621 [dbservice1] INFO c0096898-fbce-11eb-b44a-0242ac110004-dzcaqmiU-y0Gd$h@MNAoL token generate success token=MTYyODgxNTA5Ny42MjA2NTg5OmMwMDk2ODk4LWZiY2UtMTFlYi1iNDRhLTAyNDJhYzE
  08:38:28.500 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  08:38:30.076 [dbservice1] INFO c779c1ae-fbce-11eb-b7a6-0242ac110004-jyYHLuNM-QFl9cP:1u_Wb token generate success token=MTYyODgxNTExMC4wNzY2MjY6Yzc3OWMxYWUtZmJjZS0xMWViLWI3YTYtMDI0MmFjMTE
  08:38:31.754 [dbservice1] INFO c85e14d0-fbce-11eb-92e9-0242ac110003-JIoWshby-YOTLdUt=xiGS token generate success token=MTYyODgxNTExMS43NTM3MjM2OmM4NWUxNGQwLWZiY2UtMTFlYi05MmU5LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  08:38:03.319 [mobservice2] INFO info b7bdf78a-fbce-11eb-b4f6-0242ac110004:WvYxbhDu write success
  08:38:03.505 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×44)
  08:38:03.561 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  08:38:03.821 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×43)
  08:38:04.073 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  08:38:04.352 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×41)
  08:38:04.523 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×41)
  08:38:04.641 [webservice1] ERROR an error occurred in the downstream service  (×24)
  08:38:04.952 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×41)
  08:38:05.151 [mobservice1] INFO info b8ce2cf8-fbce-11eb-8aaa-0242ac110004:AMGHfWVz write success
  08:38:06.013 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×41)
  08:38:07.533 [mobservice2] INFO info ba4d7200-fbce-11eb-9664-0242ac110004:ZcstOImC write success
  08:38:10.755 [mobservice2] INFO info bc305f7e-fbce-11eb-8e7d-0242ac110003:dzLawjCD write success
  08:38:13.007 [dbservice1] INFO bd47ee22-fbce-11eb-930d-0242ac110003-kmPegpXw-Dntg52T1K_h- token generate success token=MTYyODgxNTA5My4wMDcxMzI6YmQ0N2VlMjItZmJjZS0xMWViLTkzMGQtMDI0MmFjMTE  (×3)
  08:38:15.623 [mobservice2] INFO info bf17c7a4-fbce-11eb-a038-0242ac110003:NdFpoUqE write success
  08:38:19.732 [mobservice2] INFO info c18eca78-fbce-11eb-b7de-0242ac110004:npqwesLI write success
  08:38:28.898 [mobservice2] INFO info c70c485e-fbce-11eb-ba0f-0242ac110004:wcXjOMum write success
  08:38:32.267 [mobservice1] INFO info c8fa0566-fbce-11eb-8f99-0242ac110003:CyQWkovZ write success
  08:38:35.212 [mobservice2] INFO info cacbe30a-fbce-11eb-94c6-0242ac110004:rREWnpxD write success
  08:38:37.819 [mobservice1] INFO info cc4e5208-fbce-11eb-b940-0242ac110004:mTbzBuLd write success
  08:38:39.888 [dbservice1] INFO cd565876-fbce-11eb-bc0f-0242ac110003-PyWJlfep-iu/am&SCWnFx token generate success token=MTYyODgxNTExOS44ODc4MTk4OmNkNTY1ODc2LWZiY2UtMTFlYi1iYzBmLTAyNDJhYzE
  08:38:42.389 [mobservice1] INFO info cf043026-fbce-11eb-8300-0242ac110003:qQRWFANX write success  (×2)
  08:38:44.966 [mobservice1] INFO info d08fb7d0-fbce-11eb-846d-0242ac110003:nAxhWmpD write success
  08:38:47.399 [mobservice2] INFO info d2067ea0-fbce-11eb-9800-0242ac110003:TPLgkydZ write success
  08:38:49.318 [dbservice1] INFO d2f35234-fbce-11eb-93ea-0242ac110004-GiuNzrvJ-YnTciU0WR&3p token generate success token=MTYyODgxNTEyOS4zMTc2MjQ6ZDJmMzUyMzQtZmJjZS0xMWViLTkzZWEtMDI0MmFjMTE
  08:38:52.263 [dbservice1] INFO d4b660e8-fbce-11eb-8498-0242ac110003-otxdGLkJ-:i2e%}c)9Xn8 token generate success token=MTYyODgxNTEzMi4yNjMwNDg2OmQ0YjY2MGU4LWZiY2UtMTFlYi04NDk4LTAyNDJhYzE
  08:38:54.506 [dbservice1] INFO d61fdd74-fbce-11eb-9da6-0242ac110004-CPiYkQrA-O&mRE!hKAS{t token generate success token=MTYyODgxNTEzNC41MDYwMDU6ZDYxZmRkNzQtZmJjZS0xMWViLTlkYTYtMDI0MmFjMTE
  08:38:56.514 [dbservice1] INFO d73f4672-fbce-11eb-83bd-0242ac110003-dtYZahVu-L-(wot&?xVCf token generate success token=MTYyODgxNTEzNi41MTQ1MDU2OmQ3M2Y0NjcyLWZiY2UtMTFlYi04M2JkLTAyNDJhYzE
  08:38:59.322 [dbservice1] INFO d8f27f20-fbce-11eb-95ff-0242ac110004-bZJaiYAt-*S+vbf5AyB2- token generate success token=MTYyODgxNTEzOS4zMjIzMDE6ZDhmMjdmMjAtZmJjZS0xMWViLTk1ZmYtMDI0MmFjMTE
  08:39:01.903 [mobservice2] INFO info daa13b7c-fbce-11eb-905e-0242ac110004:oLiIBNFj write success

## p0583
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:40.378Z
```
{"timestamp":1733596300378899500,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:40.378  INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl       : nullUSER TOKEN"}
```
Same service, the 2 minutes before (oldest first):
  18:31:28.758 [ts-auth-service] 2024-12-07 18:31:28.758 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×4)
  18:31:28.758 [ts-auth-service] 2024-12-07 18:31:28.758 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×4)
  18:31:30.439 [ts-auth-service] 2024-12-07 18:31:30.439 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  18:31:30.439 [ts-auth-service] 2024-12-07 18:31:30.439 INFO 1 --- [io-12340-exec-9] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×2)
  18:31:31.064 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null
  18:31:31.065 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID
  18:31:37.923 [ts-auth-service] 2024-12-07 18:31:37.922 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×2)
  18:31:37.923 [ts-auth-service] 2024-12-07 18:31:37.922 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
All services, 30 seconds either side (sampled):
  18:31:10.954 [ts-auth-service] 2024-12-07 18:31:10.953 INFO 1 --- [ main] auth.AuthApplication : Started AuthApplication in 49.907 seconds (JVM running for 71.147)
  18:31:11.591 [ts-basic-service] 2024-12-07 18:31:11.591 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×2)
  18:31:11.621 [ts-basic-service] 2024-12-07 18:31:11.621 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×4)
  18:31:11.642 [ts-price-service] 2024-12-07 18:31:11.642 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]
  18:31:11.660 [ts-order-service] 2024-12-07 18:31:11.660 INFO 1 --- [io-12031-exec-6] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×3)
  18:31:11.710 [ts-seat-service] 2024-12-07 18:31:11.710 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×5)
  18:31:11.745 [ts-travel-service] 2024-12-07 18:31:11.745 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×6)
  18:31:11.918 [ts-price-service] 2024-12-07 18:31:11.917 INFO 1 --- [io-16579-exec-1] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×3)
  18:31:12.074 [ts-basic-service] 2024-12-07 18:31:12.074 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693
  18:31:12.101 [ts-order-service] 2024-12-07 18:31:12.101 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024
  18:31:12.155 [ts-travel2-service] 2024-12-07 18:31:12.155 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  18:31:12.196 [ts-seat-service] 2024-12-07 18:31:12.195 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri
  18:31:12.281 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:12 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 343 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×16)
  18:31:12.468 [ts-travel-service] 2024-12-07 18:31:12.467 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz
  18:31:13.587 [ts-auth-service] 2024-12-07 18:31:13.587 INFO 1 --- [ main] org.apache.catalina.core.StandardEngine : Starting Servlet Engine: Apache Tomcat/8.5.43
  18:31:14.585 [ts-auth-service] 2024-12-07 18:31:14.585 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 20107 ms
  18:31:18.562 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:31:18.562+00:00"},"s":"I", "c":"NETWORK", "id":51800, "ctx":"conn22","msg":"client metadata","attr":{"remote":"127.0.0.6:60935","cl  (×2)
  18:31:19.319 [ts-food-service] 2024-12-07 18:31:19.319 INFO 1 --- [io-18856-exec-5] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  18:31:19.687 [ts-travel2-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×15)
  18:31:27.257 [ts-consign-price-mongo] {"t":{"$date":"2024-12-07T18:31:27.257+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.040 [ts-auth-service] 2024-12-07 18:31:28.039 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×9)
  18:31:29.447 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:29 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 500 236 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)  (×3)
  18:31:30.431 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T18:31:30.430+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:31.064 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  18:31:31.703 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:31 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 500 229 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Apple
  18:31:42.026 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T18:31:42.026+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359630
  18:31:51.496 [ts-food-service] 2024-12-07 18:31:51.496 ERROR 1 --- [io-18856-exec-1] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×2)

## p0812
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-admin-travel-service, 2024-12-10T13:04:03.816Z
```
{"timestamp":1733835843816576500,"container_name":"ts-admin-travel-service","pod_name":"ts-admin-travel-service-5c866595d6-bscdc","node_name":"ip-192-168-51-182.ap-southeast-2.compute.internal","message":"2024-12-10 13:04:03.816  INFO 1 --- [io-16114-exec-8] a.service.AdminTravelServiceImpl         : [Admin Travel Service][Get All Travels]"}
```
Same service, the 2 minutes before (oldest first):
  13:03:24.641 [ts-admin-travel-service] 2024-12-10 13:03:24.641 INFO 1 --- [io-16114-exec-8] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×12)
  13:03:29.530 [ts-admin-travel-service] 2024-12-10 13:03:29.530 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]
  13:03:29.634 [ts-admin-travel-service] 2024-12-10 13:03:29.633 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)
  13:03:36.924 [ts-admin-travel-service] 2024-12-10 13:03:36.924 INFO 1 --- [io-16114-exec-1] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]  (×5)
All services, 30 seconds either side (sampled):
  13:03:33.837 [ts-admin-basic-info-service] 2024-12-10 13:03:33.836 INFO 1 --- [io-18767-exec-9] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×12)
  13:03:34.103 [ts-auth-service] 2024-12-10 13:03:34.102 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×4)
  13:03:34.138 [ts-basic-service] 2024-12-10 13:03:34.137 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×13)
  13:03:34.190 [ts-travel2-service] 2024-12-10 13:03:34.189 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×14)
  13:03:35.911 [ts-auth-service] 2024-12-10 13:03:35.911 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×23)
  13:03:35.996 [ts-travel2-service] 2024-12-10 13:03:35.995 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×81)
  13:03:36.214 [ts-basic-service] 2024-12-10 13:03:36.214 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×3)
  13:03:36.264 [ts-travel-service] 2024-12-10 13:03:36.264 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×17)
  13:03:36.692 [ts-auth-service] 2024-12-10 13:03:36.692 INFO 1 --- [io-12340-exec-1] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×14)
  13:03:37.002 [ts-travel-service] 2024-12-10 13:03:37.002 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×16)
  13:03:37.033 [ts-admin-travel-service] 2024-12-10 13:03:37.033 INFO 1 --- [io-16114-exec-1] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×28)
  13:03:38.252 [ts-admin-basic-info-service] 2024-12-10 13:03:38.251 INFO 1 --- [io-18767-exec-1] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×13)
  13:03:40.526 [ts-order-service] 2024-12-10 13:03:40.526 INFO 1 --- [io-12031-exec-8] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 3  (×2)
  13:03:40.619 [ts-consign-service] 2024-12-10 13:03:40.618 INFO 1 --- [io-16111-exec-3] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] 5ad7750b-a68b-49c0-a8c0-  (×2)
  13:03:40.645 [ts-consign-service] 2024-12-10 13:03:40.644 INFO 1 --- [io-16111-exec-3] consign.service.ConsignServiceImpl : SAVE consign info : ConsignRecord(id=cb0619e8-0d84-48b5-8ebc-7a1856d9f  (×2)
  13:03:53.382 [ts-admin-basic-info-service] 2024-12-10 13:03:53.381 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×2)
  13:03:54.562 [ts-order-service] 2024-12-10 13:03:54.562 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Name List is: Response(status=1, msg=Success, data=[Nan Jing, Shang Hai Ho
  13:04:00.059 [ts-travel-service] 2024-12-10 13:04:00.059 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
  13:04:00.128 [ts-travel-service] 2024-12-10 13:04:00.127 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  13:04:00.495 [ts-food-map-service] 2024-12-10 13:04:00.494 INFO 1 --- [io-18855-exec-3] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×2)
  13:04:06.052 [ts-auth-service] 2024-12-10 13:04:06.051 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  13:04:11.756 [ts-station-mongo] {"t":{"$date":"2024-12-10T13:04:11.756+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383585
  13:04:12.240 [ts-order-other-mongo] {"t":{"$date":"2024-12-10T13:04:12.239+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383585
  13:04:12.591 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-10T13:04:12.591+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383585
  13:04:13.114 [ts-travel2-mongo] {"t":{"$date":"2024-12-10T13:04:13.113+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383585
  13:04:14.807 [ts-train-mongo] {"t":{"$date":"2024-12-10T13:04:14.805+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383585
  13:04:14.842 [ts-travel-mongo] {"t":{"$date":"2024-12-10T13:04:14.841+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383585
  13:04:31.816 [ts-admin-travel-service] 2024-12-10 13:04:31.816 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]
  13:04:32.309 [ts-inside-payment-service] 2024-12-10 13:04:32.309 INFO 1 --- [io-18673-exec-4] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.

## p0019
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T06:41:35.635Z
```
{"service":"dbservice1","message":"2021-08-13 06:41:35,635 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | cee7ad503afcfd0 | 728a8968-fbbe-11eb-a4a3-0242ac110004-dtYZahVu-L-(wot&?xVCf token generate success token=MTYyODgwODA5NS42MzUzOTM0OjcyOGE4OTY4LWZiYmUtMTFlYi1hNGEzLTAyNDJhYzExMDAwNGR0WVphaFZ1TC0od290Jj94VkNmOjE2Mjg4MDgxNTUuNjM1NDA0OjQyNmJhN2YxMTg4NWM0OGQ1YjRhYTViNmM1ZmYwOTc1"}
```
Same service, the 2 minutes before (oldest first):
  06:41:30.706 [dbservice1] INFO 6f9db3ce-fbbe-11eb-be84-0242ac110003-ArxCmQcb-p-n+Fy1&AjMv token generate success token=MTYyODgwODA5MC43MDY1Mjc6NmY5ZGIzY2UtZmJiZS0xMWViLWJlODQtMDI0MmFjMTE
  06:41:31.527 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  06:41:31.527 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  06:41:31.562 [dbservice1] INFO query = select passwards from username_table where user_name='AaVSnOsU'  (×5)
  06:41:31.639 [dbservice1] INFO 702c2b86-fbbe-11eb-9c99-0242ac110004-AaVSnOsU-SjgU+V3dBavi token generate success token=MTYyODgwODA5MS42Mzg3NDU6NzAyYzJiODYtZmJiZS0xMWViLTljOTktMDI0MmFjMTE
  06:41:33.931 [dbservice1] INFO 71888196-fbbe-11eb-b989-0242ac110003-GOhWXRIV-:-)PYXo0ydqc token generate success token=MTYyODgwODA5My45MzEzOTY3OjcxODg4MTk2LWZiYmUtMTFlYi1iOTg5LTAyNDJhYzE
  06:41:34.472 [dbservice1] INFO 71d6e250-fbbe-11eb-b32b-0242ac110004-RcoJYnsh-sPdxZat-)M%I token generate success token=MTYyODgwODA5NC40NzE3NDM2OjcxZDZlMjUwLWZiYmUtMTFlYi1iMzJiLTAyNDJhYzE
  06:41:34.824 [dbservice1] INFO 7204e330-fbbe-11eb-a520-0242ac110003-JVwBQHua-/A_5xQRM{X.J token generate success token=MTYyODgwODA5NC44MjQwMDk6NzIwNGUzMzAtZmJiZS0xMWViLWE1MjAtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  06:41:05.646 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×31)
  06:41:05.724 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  06:41:05.793 [webservice1] INFO uuid: 6126315e-fbbe-11eb-8e2b-0242ac110003 write redis successfully  (×38)
  06:41:05.875 [logservice1] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '60f35608-fbbe-11eb-a033-0242ac110004', 'user_id': 'tcvLYMig'}  (×70)
  06:41:06.023 [dbservice1] INFO query = select passwards from username_table where user_name='tcvLYMig'  (×27)
  06:41:06.157 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×33)
  06:41:06.232 [webservice2] INFO uuid: 616959d4-fbbe-11eb-b6bd-0242ac110004 write redis successfully  (×34)
  06:41:06.366 [dbservice2] INFO 6126315e-fbbe-11eb-8e2b-0242ac110003-jEWmrMqA-_=}gwQ^%v8_K token generate success token=MTYyODgwODA2Ni4zNjU2MzQyOjYxMjYzMTVlLWZiYmUtMTFlYi04ZTJiLTAyNDJhYzE
  06:41:08.737 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×33)
  06:41:14.715 [dbservice2] INFO 661c81d6-fbbe-11eb-bb8c-0242ac110003-tcZveHsK-1gH80/=YeI}* token generate success token=MTYyODgwODA3NC43MTUzODI4OjY2MWM4MWQ2LWZiYmUtMTFlYi1iYjhjLTAyNDJhYzE
  06:41:18.260 [redisservice2] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400
  06:41:20.285 [mobservice2] INFO info 699766e6-fbbe-11eb-a815-0242ac110003:zWnEcpYU write success
  06:41:22.622 [mobservice1] INFO info 6afd4582-fbbe-11eb-bd8c-0242ac110003:yHoAlkMd write success
  06:41:24.123 [mobservice2] INFO info 6be69962-fbbe-11eb-b9c1-0242ac110004:RUxdhMNy write success
  06:41:26.018 [dbservice2] INFO 6cd111f4-fbbe-11eb-ab45-0242ac110004-VizMUmJR-FY?r-G0Za*AR token generate success token=MTYyODgwODA4Ni4wMTc3MTE5OjZjZDExMWY0LWZiYmUtMTFlYi1hYjQ1LTAyNDJhYzE
  06:41:28.438 [mobservice1] INFO info 6e7d7858-fbbe-11eb-bd5b-0242ac110003:efoEbcGO write success
  06:41:30.706 [dbservice1] INFO 6f9db3ce-fbbe-11eb-be84-0242ac110003-ArxCmQcb-p-n+Fy1&AjMv token generate success token=MTYyODgwODA5MC43MDY1Mjc6NmY5ZGIzY2UtZmJiZS0xMWViLWJlODQtMDI0MmFjMTE
  06:41:32.759 [mobservice2] INFO info 710aa05a-fbbe-11eb-bbc0-0242ac110004:vUsGrNAF write success
  06:41:34.824 [dbservice1] INFO 7204e330-fbbe-11eb-a520-0242ac110003-JVwBQHua-/A_5xQRM{X.J token generate success token=MTYyODgwODA5NC44MjQwMDk6NzIwNGUzMzAtZmJiZS0xMWViLWE1MjAtMDI0MmFjMTE
  06:41:42.826 [dbservice2] INFO 76d58900-fbbe-11eb-bbcb-0242ac110003-LCiNwseu-1Gx/6#-sue%D token generate success token=MTYyODgwODEwMi44MjYzOTMxOjc2ZDU4OTAwLWZiYmUtMTFlYi1iYmNiLTAyNDJhYzE
  06:41:45.303 [mobservice1] INFO info 7882bc3c-fbbe-11eb-9ebe-0242ac110003:kuaemYbD write success
  06:41:47.531 [dbservice2] INFO 799d5d0c-fbbe-11eb-a944-0242ac110003-bHrMSWsj--%0VNhY.LywK token generate success token=MTYyODgwODEwNy41MzA3NjAzOjc5OWQ1ZDBjLWZiYmUtMTFlYi1hOTQ0LTAyNDJhYzE
  06:41:49.772 [dbservice1] INFO 7b029cac-fbbe-11eb-80d3-0242ac110003-NgkejbAm-PZS2*TO0>/RM token generate success token=MTYyODgwODEwOS43NzE4NTE1OjdiMDI5Y2FjLWZiYmUtMTFlYi04MGQzLTAyNDJhYzE
  06:41:52.159 [dbservice1] INFO 7c68bcc0-fbbe-11eb-8cc3-0242ac110004-OkyWpDvC-YSR3f{z?a:H/ token generate success token=MTYyODgwODExMi4xNTg5NDk6N2M2OGJjYzAtZmJiZS0xMWViLThjYzMtMDI0MmFjMTE
  06:41:54.130 [mobservice1] INFO info 7dc67620-fbbe-11eb-8b1d-0242ac110003:acGlMCEq write success
  06:41:56.537 [mobservice2] INFO info 7f33e132-fbbe-11eb-a085-0242ac110003:ITinMyWu write success
  06:41:59.058 [mobservice1] INFO info 80a7495a-fbbe-11eb-9d83-0242ac110004:NhtsWobx write success
  06:42:01.630 [mobservice2] INFO info 823bdac4-fbbe-11eb-b89d-0242ac110004:ZYtcmNli write success

## p0098
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service checkoutservice, 2024-11-18T05:05:51.661Z
```
{"service":"checkoutservice","operation":"hipstershop.PaymentService/Charge","method":"Charge","status_code":400,"duration_us":5231,"trace_id":"bfc52b9eb6fef86dcd193fc701e0f189","message":"span hipstershop.PaymentService/Charge failed with gRPC status 400"}
```
Same service, the 2 minutes before (oldest first):
  05:05:28.996 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="USD"  (×3)
  05:05:29.017 [checkoutservice] payment went through (transaction_id: e43c7587-0e24-4a72-8d85-16a465855b2a)  (×4)
  05:05:29.029 [checkoutservice] order confirmation email sent to "williamserin@example.org"
  05:05:33.940 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="CAD"  (×2)
  05:05:33.987 [checkoutservice] order confirmation email sent to "ferrelljeffrey@example.com"
  05:05:43.963 [checkoutservice] order confirmation email sent to "samuelraymond@example.com"
  05:05:46.056 [checkoutservice] order confirmation email sent to "fcontreras@example.com"
  05:05:51.642 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
All services, 30 seconds either side (sampled):
  05:05:28.413 [frontend] request started  (×265)
  05:05:28.422 [cartservice] GetCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×218)
  05:05:28.449 [adservice] received ad request (context_words=[accessories])  (×17)
  05:05:28.458 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=1YMWWN1N4O, quantity=7  (×26)
  05:05:28.497 [shippingservice] [GetQuote] completed request  (×59)
  05:05:28.996 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="USD"  (×6)
  05:05:29.017 [checkoutservice] payment went through (transaction_id: e43c7587-0e24-4a72-8d85-16a465855b2a)  (×9)
  05:05:29.021 [cartservice] EmptyCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×9)
  05:05:29.030 [frontend] order placed  (×9)
  05:05:31.741 [adservice] received ad request (context_words=[decor, home])  (×11)
  05:05:32.748 [frontend] ENV_PLATFORM is: aws  (×39)
  05:05:33.869 [adservice] received ad request (context_words=[footwear])  (×17)
  05:05:33.972 [paymentservice] Transaction processed: visa ending 2652 Amount: CAD426.701933656
  05:05:38.673 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×4)
  05:05:46.056 [emailservice] A request to send order confirmation email to fcontreras@example.com has been received.
  05:05:51.642 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
  05:05:51.663 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  05:05:52.043 [redis] 1:M 18 Nov 2024 05:05:52.043 * Background saving started by pid 47
  05:05:52.145 [redis] 1:M 18 Nov 2024 05:05:52.144 * Background saving terminated with success
  05:05:52.522 [paymentservice] Transaction processed: visa ending 2457 Amount: EUR565.165855819
  05:06:04.238 [emailservice] A request to send order confirmation email to michaelacosta@example.net has been received.
  05:06:07.915 [checkoutservice] order confirmation email sent to "cwilson@example.com"
  05:06:12.430 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="JPY"
  05:06:12.471 [emailservice] A request to send order confirmation email to leenathaniel@example.org has been received.

## p0407
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:54:10.453Z
```
{"timestamp":1732247650453649000,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:54:10.453451527Z caller=middlewares.go:75 method=GetUsers id=6740004ab0df5c00019b36cf result=1 took=786.305µs"}
```
Same service, the 2 minutes before (oldest first):
  03:54:08.694 [user] ts=2024-11-22T03:54:08.694203926Z caller=middlewares.go:46 method=Register username=RpmXTZtYTnTht email=RpmXTZtYTnTht@gmail.com took=1.022159ms  (×3)
  03:54:08.915 [user] ts=2024-11-22T03:54:08.915277741Z caller=middlewares.go:75 method=GetUsers id=6740004fb0df5c00019b36dd result=1 took=962.765µs  (×4)
  03:54:08.930 [user] ts=2024-11-22T03:54:08.930471813Z caller=middlewares.go:134 method=GetCards id=67400058b0df5c00019b36f4 result=1 took=685.84µs
  03:54:08.930 [user] ts=2024-11-22T03:54:08.930537092Z caller=middlewares.go:104 method=GetAddresses id=67400058b0df5c00019b36f3 result=1 took=845.854µs
  03:54:09.094 [user] ts=2024-11-22T03:54:09.094104466Z caller=middlewares.go:157 method=Health result=2 took=695.765µs  (×2)
  03:54:09.257 [user] ts=2024-11-22T03:54:09.257073141Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=6740005cb0df5c00019b36fc took=1.748472ms  (×3)
  03:54:09.270 [user] ts=2024-11-22T03:54:09.270303234Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6740005cb0df5c00019b36fc took=1.509618ms  (×3)
  03:54:10.341 [user] ts=2024-11-22T03:54:10.340095955Z caller=middlewares.go:46 method=Register username=NNZhoqUiF email=NNZhoqUiF@gmail.com took=1.017633ms
  03:54:10.385 [user] ts=2024-11-22T03:54:10.384977505Z caller=middlewares.go:46 method=Register username=fhBVNntp email=fhBVNntp@gmail.com took=1.134764ms
  03:54:10.447 [user] ts=2024-11-22T03:54:10.447217431Z caller=middlewares.go:75 method=GetUsers id=6740004ab0df5c00019b36cf result=1 took=1.072712ms
All services, 30 seconds either side (sampled):
  03:53:40.454 [front-end] POST /cart 201 - ms - -  (×62)
  03:53:40.555 [front-end] POST to carts: http://carts/carts/6740003bb0df5c00019b36a4/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}  (×31)
  03:53:41.682 [front-end] Posting Customer: {"username":"IJKHRGcbmQFT","password":"pBAByeAl","email":"IJKHRGcbmQFT@gmail.com","firstName":"IJKHRGcbmQFT","lastName":"IJKHRGcbmQFT"}
  03:53:42.309 [user] ts=2024-11-22T03:53:42.309241095Z caller=middlewares.go:46 method=Register username=DrncgBLCytFgK email=DrncgBLCytFgK@gmail.com took=968.059µs  (×13)
  03:53:42.421 [orders] 2024-11-22 03:53:42.421 INFO [orders,d17cffeef5aeae6f,26a806374aec72a7,false] 6 --- [p-nio-80-exec-1] w.w.s.o.controllers.OrdersController : Sending payment req  (×36)
  03:53:43.075 [front-end] Posting Customer: {"username":"hzyBaHXqe","password":"GWJIba","email":"hzyBaHXqe@gmail.com","firstName":"hzyBaHXqe","lastName":"hzyBaHXqe"}
  03:53:44.150 [front-end] Order response: {"statusCode":201,"body":{"id":"67400048d94b9000069b4968","customerId":"6740003ab0df5c00019b36a1","customer":{"id":null,"firstName":"iDNrJsnd","
  03:53:45.426 [front-end] Received response: "{\"firstName\":\"prPXgquSEqz\",\"lastName\":\"prPXgquSEqz\",\"username\":\"prPXgquSEqz\",\"id\":\"67400033b0df5c00019b3684\",\"_links\":{\"a
  03:53:48.508 [queue-master] 2024-11-22 03:53:48.508 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×27)
  03:53:49.606 [front-end] Received response: "{\"firstName\":\"pknEeU\",\"lastName\":\"pknEeU\",\"username\":\"pknEeU\",\"id\":\"67400032b0df5c00019b3681\",\"_links\":{\"addresses\":{\"h
  03:53:52.099 [front-end] Received response: "{\"firstName\":\"CGREeuOpk\",\"lastName\":\"CGREeuOpk\",\"username\":\"CGREeuOpk\",\"id\":\"6740003eb0df5c00019b36ac\",\"_links\":{\"address
  03:53:55.168 [user] ts=2024-11-22T03:53:55.168741299Z caller=middlewares.go:46 method=Register username=fMyIm email=fMyIm@gmail.com took=1.468663ms
  03:53:57.587 [front-end] Order response: {"id":"67400055d94b9000069b4975","customerId":"67400046b0df5c00019b36c6","customer":{"id":null,"firstName":"DrncgBLCytFgK","lastName":"DrncgBLCy
  03:54:00.559 [user] ts=2024-11-22T03:54:00.559726562Z caller=middlewares.go:46 method=Register username=CaXqszB email=CaXqszB@gmail.com took=921.102µs
  03:54:02.937 [front-end] Received response: "{\"firstName\":\"IJKHRGcbmQFT\",\"lastName\":\"IJKHRGcbmQFT\",\"username\":\"IJKHRGcbmQFT\",\"id\":\"67400045b0df5c00019b36c5\",\"_links\":{
  03:54:05.492 [front-end] Received response: "{\"firstName\":\"khVTcwn\",\"lastName\":\"khVTcwn\",\"username\":\"khVTcwn\",\"id\":\"6740004db0df5c00019b36d7\",\"_links\":{\"addresses\":{
  03:54:08.583 [front-end] Received response: "{\"firstName\":\"cziYaVhfpYCY\",\"lastName\":\"cziYaVhfpYCY\",\"username\":\"cziYaVhfpYCY\",\"id\":\"6740004db0df5c00019b36d9\",\"_links\":{
  03:54:10.385 [user] ts=2024-11-22T03:54:10.384977505Z caller=middlewares.go:46 method=Register username=fhBVNntp email=fhBVNntp@gmail.com took=1.134764ms
  03:54:15.703 [front-end] Received response: "{\"firstName\":\"DnaCtRlsNlJZaL\",\"lastName\":\"DnaCtRlsNlJZaL\",\"username\":\"DnaCtRlsNlJZaL\",\"id\":\"67400059b0df5c00019b36f6\",\"_lin
  03:54:19.515 [front-end] Received response: "{\"firstName\":\"hKLtLjNPAK\",\"lastName\":\"hKLtLjNPAK\",\"username\":\"hKLtLjNPAK\",\"id\":\"6740005cb0df5c00019b36fd\",\"_links\":{\"addr
  03:54:21.420 [front-end] Received response: "{\"firstName\":\"ugBZCWPzDfko\",\"lastName\":\"ugBZCWPzDfko\",\"username\":\"ugBZCWPzDfko\",\"id\":\"6740005cb0df5c00019b36fc\",\"_links\":{
  03:54:22.953 [front-end] Posting Customer: {"username":"JoqyYlmgVC","password":"hcFEJRmsvy","email":"JoqyYlmgVC@gmail.com","firstName":"JoqyYlmgVC","lastName":"JoqyYlmgVC"}
  03:54:27.013 [front-end] Order response: {"statusCode":201,"body":{"id":"67400073d94b9000069b498e","customerId":"67400060b0df5c00019b370e","customer":{"id":null,"firstName":"xBAHIykAOVE
  03:54:28.932 [front-end] Order response: {"statusCode":201,"body":{"id":"67400074d94b9000069b4991","customerId":"67400060b0df5c00019b370d","customer":{"id":null,"firstName":"RpmXTZtYTnT
  03:54:29.907 [user] ts=2024-11-22T03:54:29.907446551Z caller=middlewares.go:46 method=Register username=tkbHTLwJ email=tkbHTLwJ@gmail.com took=1.145751ms
  03:54:32.219 [front-end] Order response: {"id":"67400078d94b9000069b4995","customerId":"67400062b0df5c00019b3718","customer":{"id":null,"firstName":"awzyUpdYyFVuYGR","lastName":"awzyUpd
  03:54:37.666 [user] ts=2024-11-22T03:54:37.666002194Z caller=middlewares.go:46 method=Register username=NrShdue email=NrShdue@gmail.com took=1.147583ms
  03:54:39.846 [front-end] Received response: "{\"firstName\":\"VvUJwvk\",\"lastName\":\"VvUJwvk\",\"username\":\"VvUJwvk\",\"id\":\"6740006eb0df5c00019b373b\",\"_links\":{\"addresses\":{

## p0411
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:57:15.008Z
```
{"timestamp":1732247835008599800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"set cookie6740011ab0df5c00019b3949"}
```
Same service, the 2 minutes before (oldest first):
  03:57:14.953 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67400115b0df5c00019b393d"}
  03:57:14.954 [front-end] Request received with body: {}
  03:57:14.960 [front-end] Received response: "{\"firstName\":\"vZHpbR\",\"lastName\":\"vZHpbR\",\"username\":\"vZHpbR\",\"id\":\"67400108b0df5c00019b391e\",\"_links\":{\"addresses\":{\"h
  03:57:14.960 [front-end] GET Request to: http://user/customers/67400108b0df5c00019b391e/addresses  (×2)
  03:57:14.962 [front-end] POST /addresses 200 - ms - -
  03:57:14.967 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6740010eb0df5c00019b392a\",\"_links\":{\"
  03:57:14.967 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67400
  03:57:14.967 [front-end] [ undefined, undefined ]
  03:57:14.967 [front-end] Posting Order: {"customer":"http://user/customers/67400108b0df5c00019b391e","address":"http://user/addresses/6740010eb0df5c00019b3929","card":"http://user/cards
  03:57:14.967 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67400115b0df5c00019b393d"}
  03:57:14.975 [front-end] POST /cards 200 - ms - -
  03:57:14.979 [front-end] Posting Customer: {"username":"CxfEMDHeEGzTHu","password":"andISP","email":"CxfEMDHeEGzTHu@gmail.com","firstName":"CxfEMDHeEGzTHu","lastName":"CxfEMDHeEGzTHu"}
  03:57:14.985 [front-end] { id: '6740011ab0df5c00019b3949' }
  03:57:14.985 [front-end] 6740011ab0df5c00019b3949
  03:57:14.985 [front-end] Merging carts for customer id: 6740011ab0df5c00019b3949 and session id: yPSJm1ktwEBX63jjm7WPnMElBrQao3Uw
  03:57:14.998 [front-end] Order response: {"statusCode":201,"body":{"id":"6740011ad94b9000069b4a1b","customerId":"67400108b0df5c00019b391e","customer":{"id":null,"firstName":"vZHpbR","la
  03:57:14.998 [front-end] Order response: {"id":"6740011ad94b9000069b4a1b","customerId":"67400108b0df5c00019b391e","customer":{"id":null,"firstName":"vZHpbR","lastName":"vZHpbR","usernam
  03:57:15.001 [front-end] POST /orders 201 - ms - -
  03:57:15.008 [front-end] Carts merged.
All services, 30 seconds either side (sampled):
  03:56:45.093 [user] ts=2024-11-22T03:56:45.093318321Z caller=middlewares.go:157 method=Health result=2 took=784.907µs  (×37)
  03:56:45.733 [orders] 2024-11-22 03:56:45.733 INFO [orders,fd2b6239219c6b41,5f0fcb9956a174f8,false] 6 --- [-nio-80-exec-14] w.w.s.o.controllers.OrdersController : Sending payment req  (×29)
  03:56:45.802 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"674000f4b0df5c00019b38d8"}  (×58)
  03:56:45.902 [catalogue] ts=2024-11-22T03:56:45Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=3.783107  (×52)
  03:56:46.205 [front-end] Carts merged.  (×55)
  03:56:46.353 [orders] 2024-11-22 03:56:46.352 INFO [orders,cd21fb462b7bc3dc,a301c313abd4c7da,false] 6 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Sending payment req  (×38)
  03:56:47.859 [user] ts=2024-11-22T03:56:47.859478184Z caller=middlewares.go:46 method=Register username=QpxCEmbl email=QpxCEmbl@gmail.com took=1.106074ms
  03:56:49.169 [front-end] Received response: "{\"firstName\":\"VdTUeUwHVywOHIZ\",\"lastName\":\"VdTUeUwHVywOHIZ\",\"username\":\"VdTUeUwHVywOHIZ\",\"id\":\"674000eeb0df5c00019b38c0\",\"_
  03:56:49.665 [front-end] Order response: {"id":"67400101d94b9000069b4a05","customerId":"674000ebb0df5c00019b38ba","customer":{"id":null,"firstName":"rEIzGqkxw","lastName":"rEIzGqkxw","u
  03:56:53.374 [front-end] Received response: "{\"firstName\":\"schoXNoviUReXwz\",\"lastName\":\"schoXNoviUReXwz\",\"username\":\"schoXNoviUReXwz\",\"id\":\"674000f7b0df5c00019b38e4\",\"_
  03:56:54.540 [front-end] Received response: "{\"firstName\":\"WlxWAYApCjQW\",\"lastName\":\"WlxWAYApCjQW\",\"username\":\"WlxWAYApCjQW\",\"id\":\"674000ebb0df5c00019b38b9\",\"_links\":{
  03:56:56.234 [front-end] Order response: {"statusCode":201,"body":{"id":"67400108d94b9000069b4a0e","customerId":"674000f1b0df5c00019b38d1","customer":{"id":null,"firstName":"yHqsLycRjlO
  03:56:57.765 [front-end] Order response: {"id":"67400109d94b9000069b4a10","customerId":"674000fbb0df5c00019b38f5","customer":{"id":null,"firstName":"rwVrepXVEMCCG","lastName":"rwVrepXVE
  03:56:59.973 [front-end] Order response: {"id":"6740010bd94b9000069b4a12","customerId":"674000fbb0df5c00019b38f6","customer":{"id":null,"firstName":"leIclT","lastName":"leIclT","usernam
  03:57:04.707 [front-end] Posting Customer: {"username":"EefqCz","password":"rkhKOjc","email":"EefqCz@gmail.com","firstName":"EefqCz","lastName":"EefqCz"}
  03:57:08.811 [front-end] Posting Customer: {"username":"GrheZMGpE","password":"hzSXD","email":"GrheZMGpE@gmail.com","firstName":"GrheZMGpE","lastName":"GrheZMGpE"}
  03:57:10.454 [front-end] Order response: {"id":"67400116d94b9000069b4a18","customerId":"674000feb0df5c00019b38fd","customer":{"id":null,"firstName":"RHKXih","lastName":"RHKXih","usernam
  03:57:14.885 [front-end] Posting Customer: {"username":"lgAFCycmFbR","password":"txqmmIhFdf","email":"lgAFCycmFbR@gmail.com","firstName":"lgAFCycmFbR","lastName":"lgAFCycmFbR"}
  03:57:15.892 [front-end] Order response: {"id":"6740011bd94b9000069b4a1d","customerId":"67400106b0df5c00019b3913","customer":{"id":null,"firstName":"iTWmgRh","lastName":"iTWmgRh","usern
  03:57:21.204 [front-end] Order response: {"statusCode":201,"body":{"id":"67400121d94b9000069b4a1f","customerId":"6740010bb0df5c00019b3924","customer":{"id":null,"firstName":"CdJFDtoNOlw
  03:57:23.965 [front-end] Received response: "{\"firstName\":\"EefqCz\",\"lastName\":\"EefqCz\",\"username\":\"EefqCz\",\"id\":\"67400110b0df5c00019b392d\",\"_links\":{\"addresses\":{\"h
  03:57:28.275 [front-end] Received response: "{\"firstName\":\"JfcfMZLy\",\"lastName\":\"JfcfMZLy\",\"username\":\"JfcfMZLy\",\"id\":\"67400113b0df5c00019b3932\",\"_links\":{\"addresses\
  03:57:30.198 [user] ts=2024-11-22T03:57:30.198735821Z caller=middlewares.go:46 method=Register username=kIvFHHPwH email=kIvFHHPwH@gmail.com took=987.14µs
  03:57:31.452 [front-end] Order response: {"id":"6740012bd94b9000069b4a2a","customerId":"67400111b0df5c00019b392e","customer":{"id":null,"firstName":"nnASJgPOuhWkUCe","lastName":"nnASJgP
  03:57:36.684 [front-end] Received response: "{\"firstName\":\"NWbjXIJxYwnn\",\"lastName\":\"NWbjXIJxYwnn\",\"username\":\"NWbjXIJxYwnn\",\"id\":\"67400120b0df5c00019b395a\",\"_links\":{
  03:57:37.763 [front-end] Received response: "{\"firstName\":\"tcxDLRJCiCCkwhk\",\"lastName\":\"tcxDLRJCiCCkwhk\",\"username\":\"tcxDLRJCiCCkwhk\",\"id\":\"6740011db0df5c00019b3954\",\"_
  03:57:39.501 [user] ts=2024-11-22T03:57:39.501385495Z caller=middlewares.go:46 method=Register username=LuuzfHedS email=LuuzfHedS@gmail.com took=1.12411ms
  03:57:42.230 [front-end] Posting Customer: {"username":"bvrKxIFRmS","password":"nzmkJfnRRE","email":"bvrKxIFRmS@gmail.com","firstName":"bvrKxIFRmS","lastName":"bvrKxIFRmS"}
  03:57:44.035 [front-end] Order response: {"id":"67400138d94b9000069b4a39","customerId":"6740011bb0df5c00019b394d","customer":{"id":null,"firstName":"FDKLfQUyqzsLkUp","lastName":"FDKLfQU

## p0549
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-07T18:21:07.479Z
```
{"timestamp":1733595667479055000,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-srqkn","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 18:21:07.478  INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl  : [Basic Information Service][Check Station Exists] Station Name: Nan Jing"}
```
Same service, the 2 minutes before (oldest first):
  18:21:04.979 [ts-basic-service] 2024-12-07 18:21:04.978 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87
  18:21:04.984 [ts-basic-service] 2024-12-07 18:21:04.984 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  18:21:04.985 [ts-basic-service] 2024-12-07 18:21:04.985 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23
  18:21:04.992 [ts-basic-service] 2024-12-07 18:21:04.991 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  18:21:04.992 [ts-basic-service] 2024-12-07 18:21:04.992 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×5)
  18:21:04.998 [ts-basic-service] 2024-12-07 18:21:04.998 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×5)
  18:21:05.005 [ts-basic-service] 2024-12-07 18:21:05.004 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing
  18:21:05.005 [ts-basic-service] 2024-12-07 18:21:05.005 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1
  18:21:05.005 [ts-basic-service] 2024-12-07 18:21:05.005 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4
  18:21:07.420 [ts-basic-service] 2024-12-07 18:21:07.419 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha
  18:21:07.439 [ts-basic-service] 2024-12-07 18:21:07.439 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su 
  18:21:07.459 [ts-basic-service] 2024-12-07 18:21:07.459 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
All services, 30 seconds either side (sampled):
  18:20:37.808 [ts-admin-basic-info-service] 2024-12-07 18:20:37.808 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin 
  18:20:42.152 [ts-train-mongo] {"t":{"$date":"2024-12-07T18:20:42.152+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359564
  18:20:43.347 [ts-route-service] 2024-12-07 18:20:43.346 INFO 1 --- [io-11178-exec-7] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×260)
  18:20:43.409 [ts-price-service] 2024-12-07 18:20:43.409 INFO 1 --- [io-16579-exec-9] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×22)
  18:20:43.507 [ts-seat-service] 2024-12-07 18:20:43.506 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×5)
  18:20:43.556 [ts-seat-service] 2024-12-07 18:20:43.555 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×4)
  18:20:43.648 [ts-seat-service] 2024-12-07 18:20:43.648 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×37)
  18:20:44.707 [ts-food-map-service] 2024-12-07 18:20:44.706 INFO 1 --- [io-18855-exec-2] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×5)
  18:20:45.020 [ts-order-other-service] 2024-12-07 18:20:45.020 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×14)
  18:20:45.457 [ts-travel-service] 2024-12-07 18:20:45.457 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×14)
  18:20:45.679 [ts-basic-service] 2024-12-07 18:20:45.679 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×4)
  18:20:49.504 [ts-food-service] 2024-12-07 18:20:49.499 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  18:20:52.167 [ts-auth-service] 2024-12-07 18:20:52.166 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×2)
  18:20:55.629 [ts-order-service] 2024-12-07 18:20:55.629 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024
  18:20:55.882 [ts-contacts-service] 2024-12-07 18:20:55.881 INFO 1 --- [io-12347-exec-7] contacts.service.ContactsServiceImpl : [Contacts-Query-Service][Query-Contacts] Result Size: 2  (×2)
  18:20:55.939 [ts-security-service] 2024-12-07 18:20:55.939 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Getting....
  18:20:55.971 [ts-contacts-service] 2024-12-07 18:20:55.971 INFO 1 --- [io-12347-exec-8] contacts.controller.ContactsController : [ContactsService][VerifyLogin] Success.  (×2)
  18:20:56.360 [ts-preserve-service] 2024-12-07 18:20:56.359 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : TripAllDetail:TripAllDetail(status=false, message=null, tripResponse
  18:20:56.506 [ts-seat-service] 2024-12-07 18:20:56.506 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService distributeSeat] The request seat type is confortClass and the t  (×2)
  18:20:56.587 [ts-preserve-service] 2024-12-07 18:20:56.587 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Service][Add Assurance For Order]
  18:20:56.630 [ts-preserve-service] 2024-12-07 18:20:56.630 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Cancel Order Service][Get Order By Id]
  18:20:58.845 [ts-consign-service] 2024-12-07 18:20:58.845 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : The handle date is 2024-12-07
  18:21:07.617 [ts-order-service] 2024-12-07 18:21:07.617 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00 
  18:21:09.548 [ts-travel-service] 2024-12-07 18:21:09.548 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×2)
  18:21:11.381 [ts-order-other-service] 2024-12-07 18:21:11.380 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Security Info Get]
  18:21:11.414 [ts-preserve-other-service] 2024-12-07 18:21:11.414 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] TripId: Z1234
  18:21:12.314 [ts-seat-service] 2024-12-07 18:21:12.313 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService] TrainNumber start with other capital
  18:21:12.374 [ts-preserve-other-service] 2024-12-07 18:21:12.374 INFO 1 --- [io-14569-exec-2] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 5] Do not need to buy assurance
  18:21:27.489 [ts-config-mongo] {"t":{"$date":"2024-12-07T18:21:27.489+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359568
  18:21:29.788 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T18:21:29.788+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359568

## p0835
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-08T12:47:49.398Z
```
{"timestamp":1733662069398493200,"container_name":"ts-route-service","pod_name":"ts-route-service-6bdc49b787-n6bd9","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"agent library failed to init: instrument"}
```
Same service, the 2 minutes before (oldest first):
  12:47:45.255 [ts-route-service] 2024-12-08 12:47:45.255 INFO 1 --- [io-11178-exec-7] route.controller.RouteController : Route id: 084837bb-53c8-4438-87c8-0321a4d09917  (×16)
  12:47:45.262 [ts-route-service] 2024-12-08 12:47:45.262 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: f3d4d4ef-693b-4456-8eed-59c0d717dd08  (×2)
  12:47:49.398 [ts-route-service] Error occurred during initialization of VM
  12:47:49.398 [ts-route-service] Error opening zip file or JAR manifest missing : /tmp/opentelemetry-javaagent.jar
All services, 30 seconds either side (sampled):
  12:47:19.958 [ts-auth-service] 2024-12-08 12:47:19.957 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×3)
  12:47:20.207 [ts-travel-service] 2024-12-08 12:47:20.206 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×39)
  12:47:20.276 [ts-travel2-service] 2024-12-08 12:47:20.276 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×108)
  12:47:21.882 [ts-auth-service] 2024-12-08 12:47:21.881 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×21)
  12:47:27.182 [ts-travel2-service] 2024-12-08 12:47:27.181 INFO 1 --- [io-16346-exec-3] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×12)
  12:47:27.283 [ts-price-service] 2024-12-08 12:47:27.283 INFO 1 --- [io-16579-exec-4] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×12)
  12:47:27.307 [ts-travel2-service] 2024-12-08 12:47:27.307 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×9)
  12:47:27.392 [ts-seat-service] 2024-12-08 12:47:27.392 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×25)
  12:47:30.524 [ts-travel-service] 2024-12-08 12:47:30.523 INFO 1 --- [io-12346-exec-6] travel.controller.TravelController : [Travel Service] Query TripResponse  (×5)
  12:47:30.652 [ts-order-service] 2024-12-08 12:47:30.651 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:00:00 
  12:47:30.737 [ts-seat-service] 2024-12-08 12:47:30.736 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×16)
  12:47:37.155 [ts-basic-service] 2024-12-08 12:47:37.155 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×4)
  12:47:40.115 [ts-travel2-service] 2024-12-08 12:47:40.114 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×3)
  12:47:41.878 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:47:41 +0800] "GET /api/v1/contactservice/contacts/account/4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f HTTP/1.1" 200 471 "-" "Mozilla/5.0 
  12:47:41.915 [ts-security-service] 2024-12-08 12:47:41.914 INFO 1 --- [io-11188-exec-2] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Getting....
  12:47:41.955 [ts-contacts-service] 2024-12-08 12:47:41.954 INFO 1 --- [io-12347-exec-2] contacts.controller.ContactsController : [ContactsService][Contacts Id Print] 10fc4588-94c4-4e14-b67c-338ec
  12:47:42.212 [ts-order-service] 2024-12-08 12:47:42.212 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=625927415, 
  12:47:42.361 [ts-seat-service] 2024-12-08 12:47:42.360 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Left ticket info is : Response(status=1, msg=Success, data=LeftTicketInfo{so
  12:47:42.398 [ts-order-service] 2024-12-08 12:47:42.398 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Order Create] Success.
  12:47:42.422 [ts-preserve-service] 2024-12-08 12:47:42.422 INFO 1 --- [o-14568-exec-10] preserve.service.PreserveServiceImpl : [Preserve Service]
  12:47:51.579 [ts-route-service] agent library failed to init: instrument  (×2)
  12:47:54.599 [ts-travel-service] 2024-12-08 12:47:54.599 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  12:48:02.376 [ts-seat-service] 2024-12-08 12:48:02.376 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat
  12:48:04.913 [ts-route-service] 2024-12-08 12:48:04.913 INFO 1 --- [ Thread-5] o.s.s.c.ThreadPoolTaskScheduler : Shutting down ExecutorService 'taskScheduler'
  12:48:09.426 [ts-admin-travel-service] 2024-12-08 12:48:09.426 ERROR 1 --- [io-16114-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  12:48:12.175 [ts-travel2-service] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×3)
  12:48:13.375 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-08T12:48:13.374+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366209
  12:48:15.910 [ts-consign-mongo] {"t":{"$date":"2024-12-08T12:48:15.910+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366209
  12:48:16.976 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:48:16 +0800] "POST /api/v1/inside_pay_service/inside_payment HTTP/1.1" 200 83 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)

## p0682
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-12T00:39:02.503Z
```
{"service":"dbservice1","message":"2021-08-12 00:39:02,503 | INFO | 0.0.0.4 | dbservice1 | permission_operate.py -> permission_operation -> 35 | 64d99349e4eea045 | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  00:38:54.205 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  00:38:54.205 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  00:38:54.259 [dbservice1] INFO query = select passwards from username_table where user_name='JTPZbGUX'  (×5)
  00:38:54.336 [dbservice1] INFO 9d3de01c-fac2-11eb-b2dd-0242ac110004-JTPZbGUX-owRC0.<$@!D) token generate success token=MTYyODY5OTkzNC4zMzY1Mjg6OWQzZGUwMWMtZmFjMi0xMWViLWIyZGQtMDI0MmFjMTE
  00:38:55.371 [dbservice1] INFO 9dfeb4f4-fac2-11eb-8a64-0242ac110004-SBgdrmlT-HkpM0UVa+&9- token generate success token=MTYyODY5OTkzNS4zNzExMjg4OjlkZmViNGY0LWZhYzItMTFlYi04YTY0LTAyNDJhYzE
  00:39:00.147 [dbservice1] INFO a0cd2d00-fac2-11eb-8215-0242ac110004-hUmNCczf-YIyG6<:Pu7x/ token generate success token=MTYyODY5OTk0MC4xNDY5MTc4OmEwY2QyZDAwLWZhYzItMTFlYi04MjE1LTAyNDJhYzE
  00:39:00.253 [dbservice1] INFO a0ed92ac-fac2-11eb-a521-0242ac110003-bGtJCiAM-5{+Aa/EZ2QN( token generate success token=MTYyODY5OTk0MC4yNTMyNTQ3OmEwZWQ5MmFjLWZhYzItMTFlYi1hNTIxLTAyNDJhYzE
  00:39:01.082 [dbservice1] INFO a16e728c-fac2-11eb-9dd2-0242ac110003-vLPzKelQ-H:yjVplx2YI= token generate success token=MTYyODY5OTk0MS4wODE2NTEyOmExNmU3MjhjLWZhYzItMTFlYi05ZGQyLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  00:38:33.149 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  00:38:33.471 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×45)
  00:38:33.595 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '912f6caa-fac2-11eb-8ce0-0242ac110004'}  (×37)
  00:38:33.798 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  00:38:35.327 [webservice1] INFO uuid: 92719a7a-fac2-11eb-818b-0242ac110003 write redis successfully  (×39)
  00:38:35.878 [dbservice2] INFO query = select passwards from username_table where user_name='RTiMKfox'  (×39)
  00:38:36.698 [mobservice2] INFO info 92f10d14-fac2-11eb-a363-0242ac110004:IMzHpvSY write success
  00:38:36.966 [dbservice2] INFO 92e7eef0-fac2-11eb-a9ac-0242ac110004-wzuckBhX-M8t1WKXj9vHT token generate success token=MTYyODY5OTkxNi45NjU3NjA1OjkyZTdlZWYwLWZhYzItMTFlYi1hOWFjLTAyNDJhYzE  (×2)
  00:38:38.662 [dbservice2] INFO 940f87ca-fac2-11eb-8f65-0242ac110004-JKhDNmCb-yMn!G#EL?u18 token generate success token=MTYyODY5OTkxOC42NjIwMDkyOjk0MGY4N2NhLWZhYzItMTFlYi04ZjY1LTAyNDJhYzE
  00:38:41.293 [dbservice1] INFO 95a8fa30-fac2-11eb-aaed-0242ac110003-BuiqHsCZ-9fT<+%?POyQv token generate success token=MTYyODY5OTkyMS4yOTI5OTc2Ojk1YThmYTMwLWZhYzItMTFlYi1hYWVkLTAyNDJhYzE
  00:38:43.619 [dbservice2] INFO 97057660-fac2-11eb-aea0-0242ac110004-wpOMLejE-clXe.MWn<NK^ token generate success token=MTYyODY5OTkyMy42MTg2NDgzOjk3MDU3NjYwLWZhYzItMTFlYi1hZWEwLTAyNDJhYzE
  00:38:46.070 [dbservice1] INFO 986e5c74-fac2-11eb-b095-0242ac110004-COxkLyBN-!+trM_O$J5qZ token generate success token=MTYyODY5OTkyNi4wNzAzMzU2Ojk4NmU1Yzc0LWZhYzItMTFlYi1iMDk1LTAyNDJhYzE
  00:38:48.480 [dbservice2] INFO 99f0c71c-fac2-11eb-ba26-0242ac110003-aolWDIFH-Z(_kMcNp^guh token generate success token=MTYyODY5OTkyOC40Nzk2NDE0Ojk5ZjBjNzFjLWZhYzItMTFlYi1iYTI2LTAyNDJhYzE
  00:38:51.010 [dbservice1] INFO 9b681c9e-fac2-11eb-8d44-0242ac110003-aejQpHvi-63rjB42m(_JT token generate success token=MTYyODY5OTkzMS4wMDk3NTE4OjliNjgxYzllLWZhYzItMTFlYi04ZDQ0LTAyNDJhYzE
  00:38:53.892 [mobservice2] INFO info 9d3de01c-fac2-11eb-b2dd-0242ac110004:JTPZbGUX write success
  00:38:57.078 [dbservice2] INFO 9f0324f2-fac2-11eb-a931-0242ac110003-npqwesLI-thUF.2@>A!&C token generate success token=MTYyODY5OTkzNy4wNzc4MjY3OjlmMDMyNGYyLWZhYzItMTFlYi1hOTMxLTAyNDJhYzE
  00:38:59.763 [mobservice1] INFO info a0cd2d00-fac2-11eb-8215-0242ac110004:hUmNCczf write success
  00:39:02.596 [mobservice2] INFO info a29208ae-fac2-11eb-9801-0242ac110003:fQnPbvcw write success
  00:39:05.456 [mobservice1] INFO info a42dfaa6-fac2-11eb-a1da-0242ac110004:tjrRfeJy write success
  00:39:08.227 [mobservice1] INFO info a5d4fc74-fac2-11eb-8f7c-0242ac110003:NOPyEIST write success
  00:39:10.581 [mobservice1] INFO info a740d0e2-fac2-11eb-9982-0242ac110004:VxubFBRX write success
  00:39:13.268 [mobservice2] INFO info a8d865c8-fac2-11eb-953c-0242ac110004:jKNlhwnV write success
  00:39:15.766 [mobservice2] INFO info aa67b844-fac2-11eb-a9a3-0242ac110003:LVQPlZAt write success
  00:39:18.415 [mobservice1] INFO info abe70a62-fac2-11eb-9cb9-0242ac110003:EufWiDjO write success
  00:39:21.095 [mobservice1] INFO info ad7c3726-fac2-11eb-b7aa-0242ac110003:wdBFovNq write success
  00:39:23.697 [mobservice2] INFO info af1797c4-fac2-11eb-bc22-0242ac110003:LcsBuYDh write success
  00:39:28.913 [dbservice2] INFO b2031486-fac2-11eb-b3af-0242ac110003-MDLxpWSd-HTPfjtRmx@ep token generate success token=MTYyODY5OTk2OC45MTMyNTYyOmIyMDMxNDg2LWZhYzItMTFlYi1iM2FmLTAyNDJhYzE

## p0450
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:06:16.392Z
```
{"timestamp":1732349176392867600,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /addresses 200 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  08:06:15.968 [front-end] Posting Customer: {"username":"ADJLNqHnQSjIpaY","password":"BVKQdfwKCt","email":"ADJLNqHnQSjIpaY@gmail.com","firstName":"ADJLNqHnQSjIpaY","lastName":"ADJLNqHnQS
  08:06:15.974 [front-end] { id: '67418cf7a437380001deeca2' }
  08:06:15.974 [front-end] 67418cf7a437380001deeca2
  08:06:15.974 [front-end] Merging carts for customer id: 67418cf7a437380001deeca2 and session id: 1P2MIl8q99EYHVV17TXxeSZT4XTmIAbc
  08:06:15.976 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67418cf1a437380001deec93"}  (×2)
  08:06:15.987 [front-end] POST /addresses 200 - ms - -
  08:06:15.992 [front-end] Carts merged.
  08:06:15.992 [front-end] set cookie67418cf7a437380001deeca2
  08:06:15.992 [front-end] Sent cookies.
  08:06:15.993 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67418cf1a437380001deec93"}
  08:06:15.996 [front-end] POST /register 200 25.122 ms - 33
  08:06:16.012 [front-end] POST /cards 200 - ms - -
  08:06:16.062 [front-end] Attempting to delete cart for user: 67418cf1a437380001deec93
  08:06:16.094 [front-end] User cart deleted with status: 503
  08:06:16.096 [front-end] DELETE /cart 503 - ms - -
  08:06:16.111 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  08:06:16.123 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  08:06:16.123 [front-end] POST to carts: http://carts/carts/67418cf1a437380001deec93/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  08:06:16.185 [front-end] POST /cart 500 71.086 ms - 64
All services, 30 seconds either side (sampled):
  08:05:46.417 [front-end] POST /cart 500 72.712 ms - 64  (×38)
  08:05:47.235 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418  (×54)
  08:05:48.384 [catalogue] ts=2024-11-23T08:05:48Z caller=logging.go:85 method=Health result=2 took=26.084µs  (×40)
  08:05:49.280 [front-end] set cookie67418cdda437380001deec55  (×62)
  08:05:50.657 [user] ts=2024-11-23T08:05:50.656968664Z caller=middlewares.go:46 method=Register username=suOMyE email=suOMyE@gmail.com took=1.976885ms
  08:05:54.434 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×14)
  08:05:55.023 [front-end] Posting Customer: {"username":"brTpfrzj","password":"CqouP","email":"brTpfrzj@gmail.com","firstName":"brTpfrzj","lastName":"brTpfrzj"}
  08:05:57.540 [front-end] Posting Customer: {"username":"wgwvbFuCgu","password":"jthSvQsfs","email":"wgwvbFuCgu@gmail.com","firstName":"wgwvbFuCgu","lastName":"wgwvbFuCgu"}
  08:06:00.402 [shipping] 2024-11-23 08:06:00.402 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class
  08:06:04.195 [front-end] Received response: "{\"firstName\":\"MQTmuf\",\"lastName\":\"MQTmuf\",\"username\":\"MQTmuf\",\"id\":\"67418cd8a437380001deec46\",\"_links\":{\"addresses\":{\"h
  08:06:07.000 [shipping] 2024-11-23 08:06:06.999 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+j
  08:06:07.007 [shipping] 2024-11-23 08:06:07.007 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT
  08:06:07.603 [front-end] Posting Customer: {"username":"ucodWkVEg","password":"qgiOJg","email":"ucodWkVEg@gmail.com","firstName":"ucodWkVEg","lastName":"ucodWkVEg"}
  08:06:13.374 [user] ts=2024-11-23T08:06:13.374609026Z caller=middlewares.go:46 method=Register username=teNYQYg email=teNYQYg@gmail.com took=2.529487ms
  08:06:15.130 [front-end] Received response: "{\"firstName\":\"RSyStLrwvSRDG\",\"lastName\":\"RSyStLrwvSRDG\",\"username\":\"RSyStLrwvSRDG\",\"id\":\"67418ce1a437380001deec62\",\"_links\
  08:06:15.805 [carts] 2024-11-23 08:06:15.804 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[GE
  08:06:15.906 [carts] 2024-11-23 08:06:15.904 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[text/html]}" onto public 
  08:06:18.955 [user] ts=2024-11-23T08:06:18.95496322Z caller=middlewares.go:46 method=Register username=VWOjt email=VWOjt@gmail.com took=2.434446ms
  08:06:19.105 [carts] 2024-11-23 08:06:19.104 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  08:06:22.980 [front-end] Received response: "{\"firstName\":\"LeJTlhMOCH\",\"lastName\":\"LeJTlhMOCH\",\"username\":\"LeJTlhMOCH\",\"id\":\"67418ce3a437380001deec69\",\"_links\":{\"addr
  08:06:25.637 [front-end] Posting Customer: {"username":"HRFgUBgyU","password":"iGVSOf","email":"HRFgUBgyU@gmail.com","firstName":"HRFgUBgyU","lastName":"HRFgUBgyU"}
  08:06:28.000 [carts] 2024-11-23 08:06:27.999 INFO [carts,,,] 7 --- [p-nio-80-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  08:06:30.705 [carts] 2024-11-23 08:06:30.705 INFO [carts,993241630eccab18,e1237bff67df759e,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×8)
  08:06:32.806 [orders] 2024-11-23 08:06:32.806 INFO [orders,fbcebf8ef5e82428,6d050ec4f8a03a61,false] 8 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Received payment re  (×10)
  08:06:34.719 [front-end] POST /cart 201 - ms - -  (×23)
  08:06:35.986 [orders-db] {"t":{"$date":"2024-11-23T08:06:35.986+00:00"},"s":"I", "c":"STORAGE", "id":20320, "ctx":"conn5","msg":"createCollection","attr":{"namespace":"data.customerOrde  (×5)
  08:06:39.627 [front-end] Posting Customer: {"username":"ErFfEEVmz","password":"xXhfhSu","email":"ErFfEEVmz@gmail.com","firstName":"ErFfEEVmz","lastName":"ErFfEEVmz"}
  08:06:41.163 [front-end] Received response: "{\"firstName\":\"OkxajUZjGhkcaQY\",\"lastName\":\"OkxajUZjGhkcaQY\",\"username\":\"OkxajUZjGhkcaQY\",\"id\":\"67418cf8a437380001deeca8\",\"_
  08:06:43.776 [front-end] Received response: "{\"firstName\":\"GXUtAA\",\"lastName\":\"GXUtAA\",\"username\":\"GXUtAA\",\"id\":\"67418cf8a437380001deeca7\",\"_links\":{\"addresses\":{\"h

## p0248
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:05.172Z
```
{"timestamp":1732242485172273200,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"_embedded\\\":{\\\"card\\\":[{\\\"longNum\\\":\\\"123123321\\\",\\\"expires\\\":\\\"1232\\\",\\\"ccv\\\":\\\"123\\\",\\\"id\\\":\\\"673fec29b0df5c00019af941\\\",\\\"_links\\\":{\\\"card\\\":{\\\"href\\\":\\\"http://user/cards/673fec29b0df5c00019af941\\\"},\\\"self\\\":{\\\"href\\\":\\\"http://user/cards/673fec29b0df5c00019af941\\\"}}}]}}\\n\""}
```
Same service, the 2 minutes before (oldest first):
  02:28:05.033 [front-end] GET Request to: http://user/customers/673fec1db0df5c00019af90f/addresses  (×4)
  02:28:05.047 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×2)
  02:28:05.047 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec25b0df5c00019af930\",\"_links\":{\"
  02:28:05.047 [front-end] [ undefined, undefined ]
  02:28:05.047 [front-end] Posting Order: {"customer":"http://user/customers/673fec1db0df5c00019af90f","address":"http://user/addresses/673fec25b0df5c00019af92f","card":"http://user/cards
  02:28:05.062 [front-end] User cart deleted with status: 503
  02:28:05.065 [front-end] DELETE /cart 503 - ms - -
  02:28:05.071 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  02:28:05.078 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af952/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  02:28:05.097 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:05.097 [front-end] Order response: {"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:05.100 [front-end] POST /orders 500 - ms - -
  02:28:05.146 [front-end] POST /cart 500 72.021 ms - 64
  02:28:05.160 [front-end] Request received with body: {}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×32)
  02:28:03.118 [catalogue] ts=2024-11-22T02:28:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.040202ms  (×36)
  02:28:03.190 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af953/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×18)
  02:28:03.211 [user] ts=2024-11-22T02:28:03.211690554Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=1.207621ms  (×36)
  02:28:03.252 [front-end] POST /orders 500 - ms - -  (×30)
  02:28:03.410 [front-end] Carts merged.  (×31)
  02:28:04.929 [front-end] Posting Customer: {"username":"JGQXvUjPbFrtK","password":"HtglbTyNG","email":"JGQXvUjPbFrtK@gmail.com","firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPbFrtK"}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:06.800 [user] ts=2024-11-22T02:28:06.800234478Z caller=middlewares.go:46 method=Register username=oyShDJ email=oyShDJ@gmail.com took=993.111µs
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.197 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×4)
  02:28:16.205 [front-end] Received response: "{\"firstName\":\"WiHheQzgSpJzgy\",\"lastName\":\"WiHheQzgSpJzgy\",\"username\":\"WiHheQzgSpJzgy\",\"id\":\"673fec2db0df5c00019af952\",\"_lin
  02:28:17.879 [user] ts=2024-11-22T02:28:17.879034554Z caller=middlewares.go:46 method=Register username=QGHrdp email=QGHrdp@gmail.com took=1.008054ms
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:21.971 [user] ts=2024-11-22T02:28:21.971606392Z caller=middlewares.go:46 method=Register username=PDQejFz email=PDQejFz@gmail.com took=1.195014ms
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=1.213µs  (×4)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.819 [front-end] Received response: "{\"firstName\":\"KoWsmDtUqsE\",\"lastName\":\"KoWsmDtUqsE\",\"username\":\"KoWsmDtUqsE\",\"id\":\"673fec2cb0df5c00019af949\",\"_links\":{\"a
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:25.786 [shipping] 2024-11-22 02:28:25.786 INFO [shipping,fb98be28dae5ea9a,b566bc7933720160,false] 7 --- [p-nio-80-exec-6] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.957 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","l
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFr
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:27.463 [orders-db] {"t":{"$date":"2024-11-22T02:28:27.462+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: java.lang.RuntimeException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock) at com.google.commo
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×12)

## p0766
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T19:24:03.519Z
```
{"timestamp":1732389843519379700,"container_name":"front-end","pod_name":"front-end-f77549869-q8jx8","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"Posting Order: {\"customer\":\"http://user/customers/67422bbe48485600016b1513\",\"address\":\"http://user/addresses/67422bc548485600016b1529\",\"card\":\"http://user/cards/67422bc548485600016b152b\",\"items\":\"http://carts/carts/67422bbe48485600016b1513/items\"}"}
```
Same service, the 2 minutes before (oldest first):
  19:24:03.421 [front-end] Sent cookies.
  19:24:03.422 [front-end] POST /register 200 33.965 ms - 33
  19:24:03.443 [front-end] Attempting to delete cart for user: 67422bc948485600016b1533
  19:24:03.462 [front-end] User cart deleted with status: 202
  19:24:03.462 [front-end] DELETE /cart 202 - ms - -
  19:24:03.469 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  19:24:03.478 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  19:24:03.478 [front-end] POST to carts: http://carts/carts/67422bc948485600016b1533/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  19:24:03.486 [front-end] Request received with body: {}  (×2)
  19:24:03.502 [front-end] Received response: "{\"firstName\":\"oyDIYDYRspeRa\",\"lastName\":\"oyDIYDYRspeRa\",\"username\":\"oyDIYDYRspeRa\",\"id\":\"67422bbe48485600016b1513\",\"_links\
  19:24:03.502 [front-end] GET Request to: http://user/customers/67422bbe48485600016b1513/addresses  (×4)
  19:24:03.503 [front-end] Received response: "{\"firstName\":\"weWFGbctd\",\"lastName\":\"weWFGbctd\",\"username\":\"weWFGbctd\",\"id\":\"67422bbe48485600016b1512\",\"_links\":{\"address
  19:24:03.518 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67422  (×2)
  19:24:03.519 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67422bc548485600016b152b\",\"_links\":{\"
  19:24:03.519 [front-end] [ undefined, undefined ]
All services, 30 seconds either side (sampled):
  19:23:33.608 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67422baf48485600016b14d7"}  (×66)
  19:23:33.730 [front-end] POST to carts: http://carts/carts/67422baf48485600016b14d7/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}  (×37)
  19:23:34.018 [front-end] set cookie67422bb548485600016b14f5  (×59)
  19:23:35.917 [front-end] Posting Customer: {"username":"LMzygzLKVk","password":"mUsxT","email":"LMzygzLKVk@gmail.com","firstName":"LMzygzLKVk","lastName":"LMzygzLKVk"}
  19:23:36.534 [front-end] Posting Order: {"customer":"http://user/customers/67422ba248485600016b14b3","address":"http://user/addresses/67422baa48485600016b14c4","card":"http://user/cards  (×63)
  19:23:36.567 [front-end] Order response: {"statusCode":201,"body":{"id":"67422bb84ca85a00070c5214","customerId":"67422ba248485600016b14b3","customer":{"id":null,"firstName":"NuCLPiMf","
  19:23:38.088 [front-end] Order response: {"id":"67422bba4ca85a00070c5216","customerId":"67422ba248485600016b14b4","customer":{"id":null,"firstName":"NEHuYbdlKF","lastName":"NEHuYbdlKF",
  19:23:39.173 [front-end] Order response: {"timestamp":1732389819172,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×6)
  19:23:41.127 [front-end] Order response: {"id":"67422bbd4ca85a00070c5219","customerId":"67422bad48485600016b14d3","customer":{"id":null,"firstName":"VNZaiU","lastName":"VNZaiU","usernam
  19:23:42.279 [front-end] Posting Customer: {"username":"oyDIYDYRspeRa","password":"vxGbt","email":"oyDIYDYRspeRa@gmail.com","firstName":"oyDIYDYRspeRa","lastName":"oyDIYDYRspeRa"}
  19:23:43.559 [front-end] Received response: "{\"firstName\":\"GcEvVqQlyWaVOVh\",\"lastName\":\"GcEvVqQlyWaVOVh\",\"username\":\"GcEvVqQlyWaVOVh\",\"id\":\"67422baa48485600016b14c6\",\"_
  19:23:46.823 [front-end] Order response: {"id":"67422bc24ca85a00070c5220","customerId":"67422baa48485600016b14c8","customer":{"id":null,"firstName":"ufBZmb","lastName":"ufBZmb","usernam
  19:23:49.179 [front-end] Order response: {"statusCode":201,"body":{"id":"67422bc54ca85a00070c5223","customerId":"67422bac48485600016b14d2","customer":{"id":null,"firstName":"VvEfNVGeNpk
  19:23:54.337 [front-end] Received response: "{\"firstName\":\"ZNCIMkzCjZNpgKT\",\"lastName\":\"ZNCIMkzCjZNpgKT\",\"username\":\"ZNCIMkzCjZNpgKT\",\"id\":\"67422bba48485600016b1501\",\"_
  19:23:55.304 [front-end] Order response: {"id":"67422bcb4ca85a00070c5229","customerId":"67422bb848485600016b14fd","customer":{"id":null,"firstName":"ceucWagTdTPsieC","lastName":"ceucWag
  19:23:56.667 [front-end] Order response: {"statusCode":201,"body":{"id":"67422bcc4ca85a00070c522d","customerId":"67422bb548485600016b14ef","customer":{"id":null,"firstName":"fTyJmqudVRL
  19:23:58.666 [front-end] Order response: {"statusCode":201,"body":{"id":"67422bce4ca85a00070c522f","customerId":"67422bb548485600016b14f0","customer":{"id":null,"firstName":"eTfpaOqGMfZ
  19:24:01.623 [user] ts=2024-11-23T19:24:01.623406785Z caller=middlewares.go:46 method=Register username=LtHAObdSf email=LtHAObdSf@gmail.com took=5.202586ms
  19:24:03.557 [front-end] Order response: {"statusCode":201,"body":{"id":"67422bd34ca85a00070c5234","customerId":"67422bbe48485600016b1512","customer":{"id":null,"firstName":"weWFGbctd",
  19:24:06.887 [front-end] Posting Customer: {"username":"lgwRR","password":"dBkCHzjaw","email":"lgwRR@gmail.com","firstName":"lgwRR","lastName":"lgwRR"}
  19:24:09.746 [front-end] Order response: {"statusCode":201,"body":{"id":"67422bd94ca85a00070c523a","customerId":"67422bca48485600016b1536","customer":{"id":null,"firstName":"cbtZfFBYkw"
  19:24:12.560 [front-end] Order response: {"id":"67422bdc4ca85a00070c523b","customerId":"67422bc448485600016b1526","customer":{"id":null,"firstName":"NlalRnk","lastName":"NlalRnk","usern
  19:24:15.679 [user] ts=2024-11-23T19:24:15.679465575Z caller=middlewares.go:46 method=Register username=bKiCFyYn email=bKiCFyYn@gmail.com took=3.858585ms
  19:24:19.633 [front-end] Received response: "{\"firstName\":\"pDRpi\",\"lastName\":\"pDRpi\",\"username\":\"pDRpi\",\"id\":\"67422bcd48485600016b153a\",\"_links\":{\"addresses\":{\"href
  19:24:21.664 [front-end] Order response: {"id":"67422be54ca85a00070c5240","customerId":"67422bd348485600016b1547","customer":{"id":null,"firstName":"xqNnRD","lastName":"xqNnRD","usernam
  19:24:24.919 [front-end] Posting Customer: {"username":"FWZMFNEttwILqcD","password":"pmMCruS","email":"FWZMFNEttwILqcD@gmail.com","firstName":"FWZMFNEttwILqcD","lastName":"FWZMFNEttwILq
  19:24:27.634 [front-end] Received response: "{\"firstName\":\"aGPiXLoMnmz\",\"lastName\":\"aGPiXLoMnmz\",\"username\":\"aGPiXLoMnmz\",\"id\":\"67422bda48485600016b1555\",\"_links\":{\"a
  19:24:29.884 [front-end] Received response: "{\"firstName\":\"KImhXgRYTYtfq\",\"lastName\":\"KImhXgRYTYtfq\",\"username\":\"KImhXgRYTYtfq\",\"id\":\"67422bd848485600016b1552\",\"_links\
  19:24:32.363 [front-end] Order response: {"id":"67422bf04ca85a00070c524c","customerId":"67422bda48485600016b1554","customer":{"id":null,"firstName":"mszplHimkBkeDkv","lastName":"mszplHi

## p0359
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:32:29.797Z
```
{"timestamp":1732246349797384400,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"Caused by: java.net.ConnectException: Connection refused (Connection refused)\n\tat java.net.PlainSocketImpl.socketConnect(Native Method) ~[na:1.8.0_131]\n\tat java.net.AbstractPlainSocketImpl.doConnect(AbstractPlainSocketImpl.java:350) ~[na:1.8.0_131]\n\tat java.net.AbstractPlainSocketImpl.connectToAddress(AbstractPlainSocketImpl.java:206) ~[na:1.8.0_131]\n\tat java.net.AbstractPlainSocketImpl.connect(Ab…"}
```
Same service, the 2 minutes before (oldest first):
  03:32:10.283 [carts] 2024-11-22 03:32:10.283 INFO [carts,5afbd3880a4d70ed,a6df63665f839431,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.controllers.ItemsController : Did not find item.  (×4)
  03:32:10.290 [carts] 2024-11-22 03:32:10.290 INFO [carts,5afbd3880a4d70ed,a6df63665f839431,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)
  03:32:12.298 [carts] 2024-11-22 03:32:12.298 INFO [carts,9a6bbc87681922fb,95af8b155c24d3ee,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×3)
  03:32:12.428 [carts] 2024-11-22 03:32:12.428 INFO [carts,6852b343af9fcf90,1bfd75319c3e2220,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.CartsController : Merge carts reques  (×2)
  03:32:14.876 [carts] 2024-11-22 03:32:14.876 INFO [carts,1332f463061a327c,c8b73cec3e8ab83c,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  03:32:14.883 [carts] 2024-11-22 03:32:14.882 INFO [carts,1332f463061a327c,c8b73cec3e8ab83c,false] 7 --- [-nio-80-exec-16] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
  03:32:27.890 [carts] 2024-11-22 03:32:27.884 INFO [bootstrap,,,] 7 --- [ main] s.c.a.AnnotationConfigApplicationContext : Refreshing org.springframework.context.annotation.Annotatio
  03:32:29.797 [carts] 2024-11-22 03:32:29.796 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Exception in monitor thread while connecting to server carts-db:270
  03:32:29.797 [carts] com.mongodb.MongoSocketOpenException: Exception opening socket at com.mongodb.connection.SocketStream.open(SocketStream.java:63) ~[mongodb-driver-core-3.2.2.jar
All services, 30 seconds either side (sampled):
  03:32:00.094 [user] ts=2024-11-22T03:32:00.09401783Z caller=middlewares.go:157 method=Health result=2 took=747.389µs  (×34)
  03:32:00.263 [user] ts=2024-11-22T03:32:00.263466581Z caller=middlewares.go:104 method=GetAddresses id=673ffb23b0df5c00019b2700 result=1 took=1.080093ms  (×19)
  03:32:00.285 [queue-master] 2024-11-22 03:32:00.285 ERROR 6 --- [ool-6-thread-21] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×17)
  03:32:00.676 [front-end] Order response: {"id":"673ffb30d94b9000069b45cd","customerId":"673ffb19b0df5c00019b26e1","customer":{"id":null,"firstName":"YVdsb","lastName":"YVdsb","username"
  03:32:01.203 [front-end] POST /register 200 29.299 ms - 33  (×62)
  03:32:02.314 [front-end] POST /cards 200 - ms - -  (×58)
  03:32:02.441 [front-end] POST /cart 201 - ms - -  (×11)
  03:32:02.742 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffb32d94b9000069b45d0","customerId":"673ffb1ab0df5c00019b26e2","customer":{"id":null,"firstName":"vNydxJ","la
  03:32:05.034 [user] ts=2024-11-22T03:32:05.034120228Z caller=middlewares.go:46 method=Register username=tChxdVCOhk email=tChxdVCOhk@gmail.com took=877.769µs  (×10)
  03:32:06.349 [carts] 2024-11-22 03:32:06.349 INFO [carts,b3a4f8250fb2983e,a4811b02e171657e,false] 7 --- [-nio-80-exec-18] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×5)
  03:32:09.226 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffb39d94b9000069b45d4","customerId":"673ffb25b0df5c00019b270b","customer":{"id":null,"firstName":"uUHegzqhy",
  03:32:09.797 [user] ts=2024-11-22T03:32:09.796898787Z caller=middlewares.go:46 method=Register username=CPcGZ email=CPcGZ@gmail.com took=1.120429ms
  03:32:12.506 [front-end] Received response: "{\"firstName\":\"PgagNLyaIBtl\",\"lastName\":\"PgagNLyaIBtl\",\"username\":\"PgagNLyaIBtl\",\"id\":\"673ffb25b0df5c00019b2708\",\"_links\":{
  03:32:13.299 [user] ts=2024-11-22T03:32:13.298866133Z caller=middlewares.go:46 method=Register username=COmsLlalv email=COmsLlalv@gmail.com took=916.076µs
  03:32:15.000 [front-end] Order response: {"id":"673ffb3ed94b9000069b45dc","customerId":"673ffb24b0df5c00019b2707","customer":{"id":null,"firstName":"aauDDkJrjXWDR","lastName":"aauDDkJrj
  03:32:17.379 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×7)
  03:32:19.055 [user] ts=2024-11-22T03:32:19.055496103Z caller=middlewares.go:46 method=Register username=nXuxBetk email=nXuxBetk@gmail.com took=1.102951ms
  03:32:20.794 [user] ts=2024-11-22T03:32:20.794538409Z caller=middlewares.go:46 method=Register username=SBXZtYxK email=SBXZtYxK@gmail.com took=980.119µs
  03:32:22.125 [front-end] Posting Customer: {"username":"PEHWceW","password":"eoZVw","email":"PEHWceW@gmail.com","firstName":"PEHWceW","lastName":"PEHWceW"}
  03:32:27.081 [front-end] Received response: "{\"firstName\":\"XCDQMLe\",\"lastName\":\"XCDQMLe\",\"username\":\"XCDQMLe\",\"id\":\"673ffb39b0df5c00019b273c\",\"_links\":{\"addresses\":{
  03:32:29.912 [user] ts=2024-11-22T03:32:29.91258946Z caller=middlewares.go:46 method=Register username=VEbrWh email=VEbrWh@gmail.com took=714.15µs
  03:32:32.681 [user] ts=2024-11-22T03:32:32.681695484Z caller=middlewares.go:46 method=Register username=eLlagV email=eLlagV@gmail.com took=973.531µs
  03:32:36.723 [front-end] Received response: "{\"firstName\":\"PjZfgF\",\"lastName\":\"PjZfgF\",\"username\":\"PjZfgF\",\"id\":\"673ffb3fb0df5c00019b2749\",\"_links\":{\"addresses\":{\"h
  03:32:39.819 [front-end] Received response: "{\"firstName\":\"VFebmgOfCZwKHC\",\"lastName\":\"VFebmgOfCZwKHC\",\"username\":\"VFebmgOfCZwKHC\",\"id\":\"673ffb39b0df5c00019b273a\",\"_lin
  03:32:43.958 [front-end] Received response: "{\"firstName\":\"vOwQpRlpy\",\"lastName\":\"vOwQpRlpy\",\"username\":\"vOwQpRlpy\",\"id\":\"673ffb44b0df5c00019b275e\",\"_links\":{\"address
  03:32:46.557 [front-end] Posting Customer: {"username":"jzNEQoEFsj","password":"hgDCY","email":"jzNEQoEFsj@gmail.com","firstName":"jzNEQoEFsj","lastName":"jzNEQoEFsj"}
  03:32:51.174 [front-end] Received response: "{\"firstName\":\"VEbrWh\",\"lastName\":\"VEbrWh\",\"username\":\"VEbrWh\",\"id\":\"673ffb4db0df5c00019b2785\",\"_links\":{\"addresses\":{\"h
  03:32:55.006 [front-end] Posting Customer: {"username":"eQvfgyzdSyQ","password":"LagJtLtiZU","email":"eQvfgyzdSyQ@gmail.com","firstName":"eQvfgyzdSyQ","lastName":"eQvfgyzdSyQ"}
  03:32:58.589 [carts] 2024-11-22 03:32:58.588 WARN [carts,,,] 7 --- [ main] o.s.c.a.ConfigurationClassPostProcessor : Cannot enhance @Configuration bean definition 'refreshScope' sin

## p0523
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:42:30.228Z
```
{"timestamp":1732358550228206600,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"{ id: '6741b196a437380001df4bad' }"}
```
Same service, the 2 minutes before (oldest first):
  10:42:29.464 [front-end] Attempting to delete cart for user: 6741b18fa437380001df4b9a
  10:42:29.495 [front-end] User cart deleted with status: 202
  10:42:29.496 [front-end] DELETE /cart 202 - ms - -
  10:42:29.501 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  10:42:29.512 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  10:42:29.512 [front-end] POST to carts: http://carts/carts/6741b18fa437380001df4b9a/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  10:42:29.568 [front-end] POST /cart 201 - ms - -
  10:42:29.814 [front-end] GET /catalogue 200 - ms - -
  10:42:29.825 [front-end] Request received with body: {}
  10:42:29.841 [front-end] Received response: "{\"firstName\":\"OqLsYhRjpY\",\"lastName\":\"OqLsYhRjpY\",\"username\":\"OqLsYhRjpY\",\"id\":\"6741b184a437380001df4b83\",\"_links\":{\"addr
  10:42:29.841 [front-end] GET Request to: http://user/customers/6741b184a437380001df4b83/addresses  (×2)
  10:42:29.854 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b18ea437380001df4b97\",\"_links\":{\"
  10:42:29.854 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"6741b
  10:42:29.854 [front-end] [ undefined, undefined ]
  10:42:29.854 [front-end] Posting Order: {"customer":"http://user/customers/6741b184a437380001df4b83","address":"http://user/addresses/6741b18ea437380001df4b96","card":"http://user/cards
  10:42:29.895 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19501dd390007094e10","customerId":"6741b184a437380001df4b83","customer":{"id":null,"firstName":"OqLsYhRjpY"
  10:42:29.895 [front-end] Order response: {"id":"6741b19501dd390007094e10","customerId":"6741b184a437380001df4b83","customer":{"id":null,"firstName":"OqLsYhRjpY","lastName":"OqLsYhRjpY",
  10:42:29.897 [front-end] POST /orders 201 - ms - -
  10:42:30.218 [front-end] Posting Customer: {"username":"DMOcLvEBWyzQX","password":"jplcbxKLK","email":"DMOcLvEBWyzQX@gmail.com","firstName":"DMOcLvEBWyzQX","lastName":"DMOcLvEBWyzQX"}
All services, 30 seconds either side (sampled):
  10:42:00.245 [front-end] Request received with body: {}  (×60)
  10:42:00.337 [payment] ts=2024-11-23T10:42:00Z caller=logging.go:29 method=Authorise result=true took=910ns  (×44)
  10:42:00.383 [catalogue] ts=2024-11-23T10:42:00Z caller=logging.go:85 method=Health result=2 took=27.373µs  (×40)
  10:42:01.409 [user] ts=2024-11-23T10:42:01.408921714Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6741b172a437380001df4b56 took=5.298613ms  (×60)
  10:42:01.559 [front-end] POST /cart 201 - ms - -  (×60)
  10:42:02.065 [front-end] set cookie6741b17aa437380001df4b6a  (×60)
  10:42:03.037 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×8)
  10:42:05.001 [front-end] Received response: "{\"firstName\":\"sjfrIBFtnOMwhK\",\"lastName\":\"sjfrIBFtnOMwhK\",\"username\":\"sjfrIBFtnOMwhK\",\"id\":\"6741b16aa437380001df4b3a\",\"_lin
  10:42:06.045 [front-end] Order response: {"id":"6741b17e01dd390007094dfd","customerId":"6741b164a437380001df4b21","customer":{"id":null,"firstName":"NebxYZs","lastName":"NebxYZs","usern
  10:42:07.839 [front-end] Received response: "{\"firstName\":\"wEgEgz\",\"lastName\":\"wEgEgz\",\"username\":\"wEgEgz\",\"id\":\"6741b16da437380001df4b44\",\"_links\":{\"addresses\":{\"h
  10:42:12.194 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×7)
  10:42:15.584 [front-end] Received response: "{\"firstName\":\"dAtNeIAV\",\"lastName\":\"dAtNeIAV\",\"username\":\"dAtNeIAV\",\"id\":\"6741b172a437380001df4b56\",\"_links\":{\"addresses\
  10:42:17.639 [front-end] Order response: {"id":"6741b18901dd390007094e06","customerId":"6741b173a437380001df4b5a","customer":{"id":null,"firstName":"BCltxDPpCsSCJD","lastName":"BCltxDPp
  10:42:19.953 [user] ts=2024-11-23T10:42:19.95376244Z caller=middlewares.go:46 method=Register username=RIAVrKz email=RIAVrKz@gmail.com took=2.264977ms
  10:42:24.572 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19001dd390007094e0b","customerId":"6741b177a437380001df4b65","customer":{"id":null,"firstName":"SCxrEnxcK",
  10:42:26.121 [orders-db] {"t":{"$date":"2024-11-23T10:42:26.121+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235854
  10:42:27.177 [user] ts=2024-11-23T10:42:27.177095529Z caller=middlewares.go:46 method=Register username=xRRVgZEW email=xRRVgZEW@gmail.com took=3.019561ms
  10:42:29.895 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19501dd390007094e10","customerId":"6741b184a437380001df4b83","customer":{"id":null,"firstName":"OqLsYhRjpY"
  10:42:34.217 [front-end] Received response: "{\"firstName\":\"hvmhlTDxhWfD\",\"lastName\":\"hvmhlTDxhWfD\",\"username\":\"hvmhlTDxhWfD\",\"id\":\"6741b184a437380001df4b84\",\"_links\":{
  10:42:34.942 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19a01dd390007094e14","customerId":"6741b186a437380001df4b87","customer":{"id":null,"firstName":"OePlWpOYf",
  10:42:38.441 [front-end] Posting Customer: {"username":"qxMKJWILAB","password":"nPYAMbLTCN","email":"qxMKJWILAB@gmail.com","firstName":"qxMKJWILAB","lastName":"qxMKJWILAB"}
  10:42:40.192 [front-end] Order response: {"id":"6741b1a001dd390007094e17","customerId":"6741b186a437380001df4b88","customer":{"id":null,"firstName":"CydfEIYWaRvI","lastName":"CydfEIYWaR
  10:42:43.085 [front-end] Posting Customer: {"username":"UILHEiEVVssclad","password":"ZqCUxOuP","email":"UILHEiEVVssclad@gmail.com","firstName":"UILHEiEVVssclad","lastName":"UILHEiEVVssc
  10:42:45.526 [front-end] Order response: {"id":"6741b1a501dd390007094e1c","customerId":"6741b196a437380001df4bad","customer":{"id":null,"firstName":"DMOcLvEBWyzQX","lastName":"DMOcLvEBW
  10:42:47.181 [front-end] Posting Customer: {"username":"EuaRkWCg","password":"mitRj","email":"EuaRkWCg@gmail.com","firstName":"EuaRkWCg","lastName":"EuaRkWCg"}
  10:42:50.396 [user] ts=2024-11-23T10:42:50.396503272Z caller=middlewares.go:46 method=Register username=XlKDXhFKw email=XlKDXhFKw@gmail.com took=3.001343ms
  10:42:52.614 [front-end] Received response: "{\"firstName\":\"cIodMrxYWMDLnTf\",\"lastName\":\"cIodMrxYWMDLnTf\",\"username\":\"cIodMrxYWMDLnTf\",\"id\":\"6741b198a437380001df4bb4\",\"_
  10:42:54.479 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b1ae01dd390007094e24","customerId":"6741b193a437380001df4ba2","customer":{"id":null,"firstName":"xRRVgZEW","
  10:42:55.766 [front-end] Received response: "{\"firstName\":\"YrFTjPuE\",\"lastName\":\"YrFTjPuE\",\"username\":\"YrFTjPuE\",\"id\":\"6741b197a437380001df4bb1\",\"_links\":{\"addresses\
  10:42:58.786 [front-end] Received response: "{\"firstName\":\"qxMKJWILAB\",\"lastName\":\"qxMKJWILAB\",\"username\":\"qxMKJWILAB\",\"id\":\"6741b19ea437380001df4bcc\",\"_links\":{\"addr

## p0678
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-11T21:00:30.503Z
```
{"service":"webservice2","message":"2021-08-11 21:00:30,503 | INFO | 0.0.0.3 | 172.17.0.4 | webservice2 | 185309186707995 | call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  21:00:28.037 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  21:00:28.656 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  21:00:28.657 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×3)
  21:00:28.657 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '1a39e706-faa4-11eb-920a-0242ac110004', 'value': '', 'ex': 10}  (×3)
  21:00:28.709 [webservice2] INFO uuid: 1a39e706-faa4-11eb-920a-0242ac110004 write redis successfully  (×3)
  21:00:28.827 [webservice2] INFO complete information: {'uuid': '1a39e706-faa4-11eb-920a-0242ac110004', 'user_id': 'nNFECVbW'}  (×3)
  21:00:28.874 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×2)
All services, 30 seconds either side (sampled):
  21:00:00.530 [mobservice2] INFO info 0932f466-faa4-11eb-9ef0-0242ac110004:xkZXUvcn write success
  21:00:00.667 [redisservice2] INFO redis读取信息成功, status_code: 200  (×43)
  21:00:00.750 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×47)
  21:00:00.778 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×45)
  21:00:00.954 [dbservice1] INFO 0943f874-faa4-11eb-8ffa-0242ac110004-jdpqWsnu-=D:3M-V09)5? token generate success token=MTYyODY4NjgwMC45NTM4ODU4OjA5NDNmODc0LWZhYTQtMTFlYi04ZmZhLTAyNDJhYzE
  21:00:01.226 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×45)
  21:00:02.622 [dbservice1] INFO 0a4817aa-faa4-11eb-a675-0242ac110003-JUlvPnIe-31q#+(J%zy_> token generate success token=MTYyODY4NjgwMi42MjI1MjE0OjBhNDgxN2FhLWZhYTQtMTFlYi1hNjc1LTAyNDJhYzE
  21:00:03.622 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  21:00:03.987 [mobservice2] INFO info 0b4df476-faa4-11eb-bc47-0242ac110004:TzNJoquC write success
  21:00:06.787 [dbservice2] INFO 0ca754f2-faa4-11eb-985c-0242ac110004-SBgdrmlT-HkpM0UVa+&9- token generate success token=MTYyODY4NjgwNi43ODcwNTE6MGNhNzU0ZjItZmFhNC0xMWViLTk4NWMtMDI0MmFjMTE
  21:00:09.651 [dbservice2] INFO 0e71f288-faa4-11eb-9285-0242ac110004-NJwFMgYh-r7602!<ni{bW token generate success token=MTYyODY4NjgwOS42NTEzMzY6MGU3MWYyODgtZmFhNC0xMWViLTkyODUtMDI0MmFjMTE
  21:00:12.148 [mobservice2] INFO info 1026cf04-faa4-11eb-91e7-0242ac110003:NxPGARft write success
  21:00:14.790 [dbservice2] INFO 11865b80-faa4-11eb-859e-0242ac110004-RcoJYnsh-sPdxZat-)M%I token generate success token=MTYyODY4NjgxNC43OTAzNDQyOjExODY1YjgwLWZhYTQtMTFlYi04NTllLTAyNDJhYzE
  21:00:17.355 [dbservice1] INFO 131fc0bc-faa4-11eb-8cd0-0242ac110004-dULDJpwo--J=t5_1H_3.l token generate success token=MTYyODY4NjgxNy4zNTUwNzM3OjEzMWZjMGJjLWZhYTQtMTFlYi04Y2QwLTAyNDJhYzE
  21:00:19.656 [dbservice1] INFO 1480c33e-faa4-11eb-a886-0242ac110003-FTkscPog-!K5SR?}hnJW> token generate success token=MTYyODY4NjgxOS42NTU4MzI4OjE0ODBjMzNlLWZhYTQtMTFlYi1hODg2LTAyNDJhYzE
  21:00:22.380 [mobservice2] INFO info 164c67a4-faa4-11eb-a501-0242ac110004:nAxhWmpD write success
  21:00:25.256 [mobservice2] INFO info 17f5b510-faa4-11eb-b9a4-0242ac110004:uanSAwbe write success
  21:00:28.224 [mobservice1] INFO info 19bf2278-faa4-11eb-87a2-0242ac110004:cNyGSbzR write success
  21:00:30.634 [mobservice2] INFO info 1b3b9618-faa4-11eb-925b-0242ac110004:nHYqImvP write success
  21:00:33.570 [mobservice2] INFO info 1cf3c296-faa4-11eb-a748-0242ac110003:jHYceNBX write success
  21:00:36.171 [mobservice2] INFO info 1e83847a-faa4-11eb-b9c5-0242ac110003:OvVHWlKe write success
  21:00:39.041 [mobservice1] INFO info 20322d62-faa4-11eb-b8fa-0242ac110004:GrKgOByV write success
  21:00:41.727 [mobservice2] INFO info 21d34908-faa4-11eb-bdd3-0242ac110004:IWVYEAts write success
  21:00:47.925 [dbservice2] INFO 2552c9e6-faa4-11eb-a924-0242ac110003-pkIFrtAz-I})K1%yO+*f7 token generate success token=MTYyODY4Njg0Ny45MjQ2NjA3OjI1NTJjOWU2LWZhYTQtMTFlYi1hOTI0LTAyNDJhYzE
  21:00:50.178 [dbservice2] INFO 26b2efa0-faa4-11eb-b026-0242ac110004-VaMiodsE-Ce_X1s0dvj)V token generate success token=MTYyODY4Njg1MC4xNzgxNDM6MjZiMmVmYTAtZmFhNC0xMWViLWIwMjYtMDI0MmFjMTE
  21:00:53.452 [mobservice2] INFO info 28c88e3a-faa4-11eb-b24c-0242ac110004:FqaTIXhn write success
  21:00:56.027 [mobservice2] INFO info 2a56e580-faa4-11eb-962c-0242ac110004:dlSUhBPw write success
  21:00:58.776 [mobservice1] INFO info 2be9afd6-faa4-11eb-be76-0242ac110003:AfSqKhsi write success

## p0485
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-23T08:57:00.960Z
```
{"timestamp":1732352220960417300,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-zmfhr","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received shipment task: 674198c2a437380001deff4e"}
```
Same service, the 2 minutes before (oldest first):
  08:56:58.025 [queue-master] Received shipment task: 674198bfa437380001deff45  (×2)
  08:56:58.025 [queue-master] 2024-11-23 08:56:58.025 INFO 7 --- [pool-6-thread-1] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×2)
  08:56:58.026 [queue-master] 2024-11-23 08:56:58.026 INFO 7 --- [pool-6-thread-1] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×6)
  08:56:58.026 [queue-master] 2024-11-23 08:56:58.026 INFO 7 --- [pool-6-thread-1] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×6)
  08:56:58.026 [queue-master] 2024-11-23 08:56:58.026 ERROR 7 --- [pool-6-thread-1] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×2)
All services, 30 seconds either side (sampled):
  08:56:58.007 [catalogue] ts=2024-11-23T08:56:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.869902ms  (×36)
  08:56:58.018 [orders] 2024-11-23 08:56:58.018 INFO [orders,6baef7816fdf67ff,4dc9cbe9bd6cff45,false] 8 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Received payment re  (×26)
  08:56:58.029 [front-end] Order response: {"statusCode":201,"body":{"id":"674198da3f77060008865384","customerId":"674198bfa437380001deff45","customer":{"id":null,"firstName":"ztfESzW","l
  08:56:59.388 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674198d3a437380001deff98"}  (×30)
  08:56:59.483 [catalogue] ts=2024-11-23T08:56:59Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.990138  (×27)
  08:57:00.720 [front-end] Request received with body: {}  (×27)
  08:57:00.744 [front-end] Posting Order: {"customer":"http://user/customers/674198caa437380001deff7c","address":"http://user/addresses/674198d0a437380001deff90","card":"http://user/cards  (×27)
  08:57:01.048 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  08:57:01.165 [front-end] 674198dda437380001deffa9  (×33)
  08:57:02.787 [front-end] Received response: "{\"firstName\":\"iEYCUjoH\",\"lastName\":\"iEYCUjoH\",\"username\":\"iEYCUjoH\",\"id\":\"674198c5a437380001deff67\",\"_links\":{\"addresses\
  08:57:03.057 [front-end] Order response: {"statusCode":201,"body":{"id":"674198df3f77060008865387","customerId":"674198caa437380001deff7e","customer":{"id":null,"firstName":"qzkCXXFW","
  08:57:04.140 [front-end] Received response: "{\"firstName\":\"TlHaLWqJVqW\",\"lastName\":\"TlHaLWqJVqW\",\"username\":\"TlHaLWqJVqW\",\"id\":\"674198d0a437380001deff92\",\"_links\":{\"a
  08:57:05.392 [orders] 2024-11-23 08:57:05.392 INFO [orders,3c526066b205402a,acb1c0fc61191c83,false] 8 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×2)
  08:57:07.035 [front-end] Order response: {"statusCode":201,"body":{"id":"674198e33f7706000886538a","customerId":"674198caa437380001deff7d","customer":{"id":null,"firstName":"vidoaLMiMZn
  08:57:08.980 [queue-master] 2024-11-23 08:57:08.980 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×51)
  08:57:09.152 [front-end] Order response: {"id":"674198e53f7706000886538c","customerId":"674198d2a437380001deff95","customer":{"id":null,"firstName":"zUGYrCgol","lastName":"zUGYrCgol","u
  08:57:11.533 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×6)
  08:57:13.005 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  08:57:14.121 [front-end] Posting Customer: {"username":"JCYeKSjM","password":"MYIoBCiY","email":"JCYeKSjM@gmail.com","firstName":"JCYeKSjM","lastName":"JCYeKSjM"}
  08:57:15.678 [front-end] Order response: {"id":"674198eb3f7706000886538f","customerId":"674198cfa437380001deff8c","customer":{"id":null,"firstName":"FygEtnQmntW","lastName":"FygEtnQmntW
  08:57:18.424 [user] ts=2024-11-23T08:57:18.424838811Z caller=middlewares.go:46 method=Register username=bqLFOFtK email=bqLFOFtK@gmail.com took=2.548455ms
  08:57:19.305 [front-end] Received response: "{\"firstName\":\"aXWRmKRnN\",\"lastName\":\"aXWRmKRnN\",\"username\":\"aXWRmKRnN\",\"id\":\"674198d9a437380001deffa4\",\"_links\":{\"address
  08:57:22.096 [front-end] Posting Customer: {"username":"ErqkMC","password":"qwrMe","email":"ErqkMC@gmail.com","firstName":"ErqkMC","lastName":"ErqkMC"}
  08:57:24.110 [front-end] Order response: {"id":"674198f43f77060008865392","customerId":"674198dfa437380001deffad","customer":{"id":null,"firstName":"wqgJPHku","lastName":"wqgJPHku","use
  08:57:25.404 [front-end] Order response: {"id":"674198f53f77060008865393","customerId":"674198e2a437380001deffb0","customer":{"id":null,"firstName":"tVFCKe","lastName":"tVFCKe","usernam
  08:57:26.581 [front-end] Received response: "{\"firstName\":\"aQTVfKPpOQTV\",\"lastName\":\"aQTVfKPpOQTV\",\"username\":\"aQTVfKPpOQTV\",\"id\":\"674198e5a437380001deffb4\",\"_links\":{
  08:57:27.415 [front-end] Order response: {"statusCode":201,"body":{"id":"674198f73f77060008865398","customerId":"674198dda437380001deffa9","customer":{"id":null,"firstName":"eWMmgZPhWLI
  08:57:30.058 [front-end] Order response: {"id":"674198fa3f77060008865399","customerId":"674198e7a437380001deffbe","customer":{"id":null,"firstName":"bVfUCqC","lastName":"bVfUCqC","usern
  08:57:30.866 [front-end] Order response: {"statusCode":201,"body":{"id":"674198fa3f7706000886539b","customerId":"674198e9a437380001deffc1","customer":{"id":null,"firstName":"KHUge","las

## p0837
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-08T12:48:05.397Z
```
{"timestamp":1733662085397828000,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-xdbjj","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"org.springframework.web.client.HttpServerErrorException: 500 Internal Server Error\n\tat org.springframework.web.client.DefaultResponseErrorHandler.handleError(DefaultResponseErrorHandler.java:111) ~[spring-web-4.3.25.RELEASE.jar!/:4.3.25.RELEASE]\n\tat org.springframework.web.client.RestTemplate.handleResponse(RestTemplate.java:709) ~[spring-web-4.3.25.RELEASE.jar!/:4.3.25.RELEASE]\n\tat org.springfram…"}
```
Same service, the 2 minutes before (oldest first):
  12:48:04.721 [ts-travel2-service] 2024-12-08 12:48:04.721 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  12:48:04.758 [ts-travel2-service] 2024-12-08 12:48:04.758 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sun Dec 08 00:00:00 GMT 2024,   (×2)
  12:48:04.765 [ts-travel2-service] 2024-12-08 12:48:04.765 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236
  12:48:04.767 [ts-travel2-service] 2024-12-08 12:48:04.766 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600
  12:48:04.775 [ts-travel2-service] 2024-12-08 12:48:04.775 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.
  12:48:04.776 [ts-travel2-service] 2024-12-08 12:48:04.776 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  12:48:04.811 [ts-travel2-service] 2024-12-08 12:48:04.811 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  12:48:04.848 [ts-travel2-service] 2024-12-08 12:48:04.847 INFO 1 --- [io-16346-exec-1] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236
  12:48:04.849 [ts-travel2-service] 2024-12-08 12:48:04.849 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600  (×3)
  12:48:04.856 [ts-travel2-service] 2024-12-08 12:48:04.856 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×2)
  12:48:04.857 [ts-travel2-service] 2024-12-08 12:48:04.857 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  12:48:04.893 [ts-travel2-service] 2024-12-08 12:48:04.893 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6
  12:48:04.901 [ts-travel2-service] 2024-12-08 12:48:04.901 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×2)
  12:48:05.397 [ts-travel2-service] 2024-12-08 12:48:05.396 ERROR 1 --- [io-16346-exec-8] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
All services, 30 seconds either side (sampled):
  12:47:36.092 [ts-admin-basic-info-service] 2024-12-08 12:47:36.092 INFO 1 --- [io-18767-exec-7] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×12)
  12:47:37.094 [ts-basic-service] 2024-12-08 12:47:37.093 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×4)
  12:47:37.162 [ts-basic-service] 2024-12-08 12:47:37.162 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×12)
  12:47:37.186 [ts-travel2-service] 2024-12-08 12:47:37.186 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×8)
  12:47:37.271 [ts-seat-service] 2024-12-08 12:47:37.271 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×15)
  12:47:37.411 [ts-travel2-service] 2024-12-08 12:47:37.411 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×8)
  12:47:39.774 [ts-auth-service] 2024-12-08 12:47:39.774 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×3)
  12:47:41.537 [ts-travel-service] 2024-12-08 12:47:41.536 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×11)
  12:47:41.581 [ts-travel-service] 2024-12-08 12:47:41.581 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×6)
  12:47:41.641 [ts-order-service] 2024-12-08 12:47:41.641 INFO 1 --- [io-12031-exec-2] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:00:00   (×3)
  12:47:41.751 [ts-travel-service] 2024-12-08 12:47:41.750 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×6)
  12:47:41.856 [ts-assurance-service] 2024-12-08 12:47:41.855 INFO 1 --- [o-18888-exec-10] a.controller.AssuranceController : [Assurances Service][Get Assurance Type]
  12:47:41.897 [ts-security-service] 2024-12-08 12:47:41.897 INFO 1 --- [io-11188-exec-2] security.controller.SecurityController : [Security Service][Check Security] Check Account Id: 4d2a46c7-71cb
  12:47:41.935 [ts-security-service] 2024-12-08 12:47:41.935 INFO 1 --- [io-11188-exec-2] security.service.SecurityServiceImpl : [Security Service] Max In One Hour: 2147483647 Max Not Use: 21474836
  12:47:41.962 [ts-preserve-service] 2024-12-08 12:47:41.962 INFO 1 --- [o-14568-exec-10] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] Check tickets num
  12:47:42.253 [ts-preserve-service] 2024-12-08 12:47:42.253 INFO 1 --- [o-14568-exec-10] preserve.service.PreserveServiceImpl : TripAllDetail:TripAllDetail(status=false, message=null, tripResponse
  12:47:42.374 [ts-seat-service] 2024-12-08 12:47:42.374 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService distributeSeat 1] The result of getTrainTypeResult is Response(
  12:47:42.398 [ts-order-service] 2024-12-08 12:47:42.398 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 50.0
  12:47:42.422 [ts-preserve-service] 2024-12-08 12:47:42.422 INFO 1 --- [o-14568-exec-10] preserve.service.PreserveServiceImpl : [Cancel Order Service][Get Order By Id]
  12:47:52.364 [ts-food-service] 2024-12-08 12:47:52.363 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  12:47:54.599 [ts-travel-service] 2024-12-08 12:47:54.599 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  12:47:56.389 [ts-basic-service] 2024-12-08 12:47:56.389 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×4)
  12:48:02.393 [ts-seat-service] 2024-12-08 12:48:02.392 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  12:48:04.918 [ts-route-service] 2024-12-08 12:48:04.917 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:52}] to ts-route-mongo:  (×4)
  12:48:10.896 [ts-route-mongo] {"t":{"$date":"2024-12-08T12:48:10.896+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366209
  12:48:12.329 [ts-preserve-mongo] {"t":{"$date":"2024-12-08T12:48:12.329+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366209
  12:48:14.000 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-08T12:48:14.000+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366209
  12:48:16.738 [ts-order-service] 2024-12-08 12:48:16.738 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 155
  12:48:20.179 [ts-food-service] 2024-12-08 12:48:20.178 ERROR 1 --- [io-18856-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 

## p0811
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-08T09:23:54.503Z
```
{"timestamp":1733649834503838000,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h4k7r","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-08 09:23:54.503  INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl       : LOGIN USER NEW:fdse_microservice __ 111111 __ null"}
```
Same service, the 2 minutes before (oldest first):
  09:23:39.329 [ts-auth-service] 2024-12-08 09:23:39.328 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×2)
  09:23:39.329 [ts-auth-service] 2024-12-08 09:23:39.329 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×2)
  09:23:39.595 [ts-auth-service] 2024-12-08 09:23:39.595 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×4)
  09:23:39.595 [ts-auth-service] 2024-12-08 09:23:39.595 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×4)
  09:23:44.396 [ts-auth-service] 2024-12-08 09:23:44.396 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×2)
  09:23:44.396 [ts-auth-service] 2024-12-08 09:23:44.396 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
  09:23:53.374 [ts-auth-service] 2024-12-08 09:23:53.374 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null
  09:23:53.375 [ts-auth-service] 2024-12-08 09:23:53.374 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  09:23:53.588 [ts-auth-service] 2024-12-08 09:23:53.588 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  09:23:53.588 [ts-auth-service] 2024-12-08 09:23:53.588 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4c7ef37c-e8cb-4d29-aaca-62bd7a8da985 USER ID
All services, 30 seconds either side (sampled):
  09:23:25.024 [ts-admin-basic-info-service] 2024-12-08 09:23:25.024 ERROR 1 --- [io-18767-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×24)
  09:23:25.027 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:23:25 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 500 238 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_  (×14)
  09:23:29.567 [ts-auth-service] 2024-12-08 09:23:29.567 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×11)
  09:23:29.781 [ts-auth-service] 2024-12-08 09:23:29.781 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×23)
  09:23:29.801 [ts-travel2-service] 2024-12-08 09:23:29.800 ERROR 1 --- [io-16346-exec-1] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×10)
  09:23:29.803 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:23:29 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 500 228 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×11)
  09:23:30.130 [ts-admin-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×15)
  09:23:33.149 [ts-admin-basic-info-service] 2024-12-08 09:23:33.149 ERROR 1 --- [o-18767-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×3)
  09:23:33.306 [ts-auth-service] 2024-12-08 09:23:33.306 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×3)
  09:23:34.503 [ts-travel2-service] 2024-12-08 09:23:34.503 ERROR 1 --- [o-16346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  09:23:35.739 [ts-order-other-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo
  09:23:39.517 [ts-order-service] 2024-12-08 09:23:39.517 ERROR 1 --- [o-12031-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  09:23:40.748 [ts-food-service] 2024-12-08 09:23:40.748 ERROR 1 --- [o-18856-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  09:23:40.752 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:17:23:40 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 500 259 "-" "Mozilla/5.0 (Macintosh;   (×6)
  09:24:09.033 [ts-route-mongo] {"t":{"$date":"2024-12-08T09:24:09.033+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364984
  09:24:10.136 [ts-auth-mongo] {"t":{"$date":"2024-12-08T09:24:10.136+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364985
  09:24:10.204 [ts-user-mongo] {"t":{"$date":"2024-12-08T09:24:10.204+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364985
  09:24:10.290 [ts-preserve-mongo] {"t":{"$date":"2024-12-08T09:24:10.289+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364985
  09:24:10.428 [ts-config-mongo] {"t":{"$date":"2024-12-08T09:24:10.427+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364985
  09:24:11.889 [ts-security-mongo] {"t":{"$date":"2024-12-08T09:24:11.889+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364985
  09:24:12.120 [ts-travel-service] 2024-12-08 09:24:12.120 ERROR 1 --- [io-12346-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  09:24:12.164 [ts-assurance-mongo] {"t":{"$date":"2024-12-08T09:24:12.164+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364985
  09:24:12.943 [ts-consign-price-mongo] {"t":{"$date":"2024-12-08T09:24:12.943+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364985
  09:24:13.529 [ts-consign-mongo] {"t":{"$date":"2024-12-08T09:24:13.529+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364985

## p0752
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service recommendationservice, 2024-11-23T14:33:33.748Z
```
{"timestamp":1732372413748452900,"container_name":"recommendationservice","pod_name":"recommendationservice-fdf57f545-kvcpw","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"[Recv ListRecommendations] product_ids=['9SIQT8TOJO', '1YMWWN1N4O', '6E92ZMYYFZ', '66VCHSJNUP', 'L9ECAV7KIM']"}
```
Same service, the 2 minutes before (oldest first):
  14:33:27.665 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '2ZYFJ3GM2N', 'L9ECAV7KIM', '66VCHSJNUP', '6E92ZMYYFZ']  (×19)
  14:33:29.318 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', 'LS4PSXUNUM', '9SIQT8TOJO', '66VCHSJNUP']
All services, 30 seconds either side (sampled):
  14:33:03.837 [frontend] request started  (×269)
  14:33:03.840 [currencyservice] Getting supported currencies...  (×229)
  14:33:03.847 [currencyservice] conversion request successful  (×539)
  14:33:03.865 [adservice] received ad request (context_words=[kitchen])  (×44)
  14:33:04.680 [adservice] received ad request (context_words=[accessories])  (×34)
  14:33:05.589 [frontend] setting currency  (×14)
  14:33:05.623 [frontend] ENV_PLATFORM is: aws  (×23)
  14:33:06.427 [adservice] received ad request (context_words=[decor, home])  (×19)
  14:33:06.464 [cartservice] AddItemAsync called with userId=fbfa9a65-8394-4a78-8c33-015a2e393081, productId=9SIQT8TOJO, quantity=1  (×26)
  14:33:06.494 [shippingservice] [GetQuote] received request  (×64)
  14:33:07.833 [adservice] received ad request (context_words=[hair, beauty])  (×16)
  14:33:08.434 [checkoutservice] [PlaceOrder] user_id="6129cf10-ed45-447d-9baf-531b5fac192e" user_currency="GBP"
  14:33:08.455 [paymentservice] Transaction processed: visa ending 3254 Amount: GBP326.777255182
  14:33:08.460 [shippingservice] [ShipOrder] received request  (×7)
  14:33:08.462 [cartservice] EmptyCartAsync called with userId=6129cf10-ed45-447d-9baf-531b5fac192e  (×7)
  14:33:08.467 [checkoutservice] failed to send order confirmation to "luke00@example.com": rpc error: code = Unavailable desc = no healthy upstream
  14:33:09.072 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', 'OLJCESPC7Z', '1YMWWN1N4O', '66VCHSJNUP']  (×5)
  14:33:09.708 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"259","nanos":982308714},"credit_card":{"credit_card_number":"43388921097109  (×2)
  14:33:09.720 [checkoutservice] failed to send order confirmation to "jessica04@example.org": rpc error: code = Unavailable desc = no healthy upstream
  14:33:26.820 [checkoutservice] [PlaceOrder] user_id="0badaee9-31d7-4840-8c50-a2fb869180b3" user_currency="USD"
  14:33:26.844 [paymentservice] Transaction processed: visa ending 1047 Amount: USD1918.710000000
  14:33:34.038 [checkoutservice] [PlaceOrder] user_id="6e17f999-1f44-47b4-93f0-534a09a0d813" user_currency="TRY"  (×2)
  14:33:34.056 [paymentservice] Transaction processed: visa ending 1641 Amount: TRY3028.164367985  (×2)
  14:33:48.910 [emailservice] starting the email service in dummy mode.
  14:33:49.009 [emailservice] Traceback (most recent call last): File "/email_server/email_server.py", line 199, in <module> start(dummy_mode = True) File "/email_server/email_server.py", li
  14:33:49.145 [checkoutservice] failed to send order confirmation to "kyleweber@example.com": rpc error: code = Unavailable desc = upstream connect error or disconnect/reset before headers. re
  14:33:50.342 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"15476","nanos":592658536},"credit_card":{"credit_card_number":"496293443852
  14:33:50.352 [checkoutservice] failed to send order confirmation to "allisonpatel@example.com": rpc error: code = Unavailable desc = no healthy upstream

## p0341
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-22T03:21:28.389Z
```
{"timestamp":1732245688389928700,"container_name":"orders","pod_name":"orders-5fd66f9688-2x7kx","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-22 03:21:28.389  INFO [orders,57733cc00e77bf8a,07b77016e61b1df8,false] 6 --- [-nio-80-exec-14] w.w.s.o.controllers.OrdersController     : Sending payment request: PaymentRequest{address=Address{id=null, number='123', street='123', city='123', country='123', postcode='123'}, card=Card{id=null, longNum='123123321', expires='1232', ccv='123'}, customer=Customer{id=null, firstName='MszyyqkjNcA…"}
```
Same service, the 2 minutes before (oldest first):
  03:21:20.087 [orders] 2024-11-22 03:21:20.087 INFO [orders,575baa71da911389,ebd81a89d14bb156,false] 6 --- [-nio-80-exec-13] w.w.s.o.controllers.OrdersController : Sending payment req  (×5)
  03:21:20.092 [orders] 2024-11-22 03:21:20.092 INFO [orders,575baa71da911389,ebd81a89d14bb156,false] 6 --- [-nio-80-exec-13] w.w.s.o.controllers.OrdersController : Received payment re  (×5)
  03:21:20.187 [orders] 2024-11-22 03:21:20.187 INFO [orders,c8c97483795e1480,987987bb9f6e0a00,false] 6 --- [p-nio-80-exec-8] w.w.s.o.controllers.OrdersController : Sending payment req  (×5)
  03:21:20.192 [orders] 2024-11-22 03:21:20.192 INFO [orders,c8c97483795e1480,987987bb9f6e0a00,false] 6 --- [p-nio-80-exec-8] w.w.s.o.controllers.OrdersController : Received payment re  (×5)
All services, 30 seconds either side (sampled):
  03:20:58.390 [front-end] POST /orders 500 - ms - -  (×64)
  03:20:59.173 [front-end] Carts merged.  (×58)
  03:20:59.489 [carts] 2024-11-22 03:20:59.489 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.actu
  03:20:59.783 [carts] 2024-11-22 03:20:59.783 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal
  03:20:59.886 [carts] 2024-11-22 03:20:59.885 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[GET],produces=[applicati  (×2)
  03:21:02.119 [front-end] Posting Customer: {"username":"gKGbBfBuFal","password":"jTPEzN","email":"gKGbBfBuFal@gmail.com","firstName":"gKGbBfBuFal","lastName":"gKGbBfBuFal"}
  03:21:02.491 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245662488,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×13)
  03:21:03.084 [carts] 2024-11-22 03:21:03.084 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  03:21:03.184 [carts] 2024-11-22 03:21:03.183 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces
  03:21:06.274 [front-end] Received response: "{\"firstName\":\"WwpBLC\",\"lastName\":\"WwpBLC\",\"username\":\"WwpBLC\",\"id\":\"673ff885b0df5c00019b1f10\",\"_links\":{\"addresses\":{\"h
  03:21:09.238 [front-end] Posting Customer: {"username":"pMqcnDbPZ","password":"kxLei","email":"pMqcnDbPZ@gmail.com","firstName":"pMqcnDbPZ","lastName":"pMqcnDbPZ"}
  03:21:12.197 [user] ts=2024-11-22T03:21:12.197239401Z caller=middlewares.go:46 method=Register username=yXmVwShR email=yXmVwShR@gmail.com took=735.735µs
  03:21:15.275 [front-end] Posting Customer: {"username":"xlSpYB","password":"qbBOBmLGvy","email":"xlSpYB@gmail.com","firstName":"xlSpYB","lastName":"xlSpYB"}
  03:21:17.489 [front-end] Received response: "{\"firstName\":\"kJMPYF\",\"lastName\":\"kJMPYF\",\"username\":\"kJMPYF\",\"id\":\"673ff896b0df5c00019b1f37\",\"_links\":{\"addresses\":{\"h
  03:21:18.612 [queue-master] Received shipment task: 673ff896b0df5c00019b1f3b  (×48)
  03:21:18.809 [front-end] Order response: {"id":"673ff8aed94b9000069b438f","customerId":"673ff89db0df5c00019b1f52","customer":{"id":null,"firstName":"isaznhmc","lastName":"isaznhmc","use
  03:21:19.502 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8afd94b9000069b4392","customerId":"673ff89eb0df5c00019b1f58","customer":{"id":null,"firstName":"sQAAadzpZlK
  03:21:20.407 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b0d94b9000069b4396","customerId":"673ff893b0df5c00019b1f31","customer":{"id":null,"firstName":"nPklGOsvzh"
  03:21:22.641 [front-end] Received response: "{\"firstName\":\"TxflHMpaWteY\",\"lastName\":\"TxflHMpaWteY\",\"username\":\"TxflHMpaWteY\",\"id\":\"673ff898b0df5c00019b1f40\",\"_links\":{
  03:21:26.847 [front-end] Received response: "{\"firstName\":\"gxEQQKdgPqad\",\"lastName\":\"gxEQQKdgPqad\",\"username\":\"gxEQQKdgPqad\",\"id\":\"673ff89fb0df5c00019b1f5d\",\"_links\":{
  03:21:32.048 [user] ts=2024-11-22T03:21:32.048729283Z caller=middlewares.go:46 method=Register username=tEhusfT email=tEhusfT@gmail.com took=1.084876ms
  03:21:34.413 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8bed94b9000069b43a0","customerId":"673ff8a6b0df5c00019b1f7f","customer":{"id":null,"firstName":"BXlkiHWqBVY
  03:21:36.305 [front-end] Order response: {"id":"673ff8c0d94b9000069b43a2","customerId":"673ff8a7b0df5c00019b1f82","customer":{"id":null,"firstName":"onbFNMM","lastName":"onbFNMM","usern
  03:21:39.862 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8c3d94b9000069b43a6","customerId":"673ff8adb0df5c00019b1f95","customer":{"id":null,"firstName":"nzRGBLrbgct
  03:21:43.358 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8c7d94b9000069b43a8","customerId":"673ff8aab0df5c00019b1f8c","customer":{"id":null,"firstName":"GaVMS","las
  03:21:45.822 [front-end] Received response: "{\"firstName\":\"xlSpYB\",\"lastName\":\"xlSpYB\",\"username\":\"xlSpYB\",\"id\":\"673ff8abb0df5c00019b1f8d\",\"_links\":{\"addresses\":{\"h
  03:21:50.503 [catalogue] ts=2024-11-22T03:21:50Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=4.2271ms
  03:21:55.069 [user] ts=2024-11-22T03:21:55.069222744Z caller=middlewares.go:46 method=Register username=UyPmLD email=UyPmLD@gmail.com took=998.258µs
  03:21:56.558 [front-end] Order response: {"id":"673ff8d4d94b9000069b43b5","customerId":"673ff8c0b0df5c00019b1fbc","customer":{"id":null,"firstName":"DXXEAuEZfGxuPq","lastName":"DXXEAuEZ
  03:21:58.062 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8d6d94b9000069b43b9","customerId":"673ff8c6b0df5c00019b1fcd","customer":{"id":null,"firstName":"xJlcQpb","l

## p0404
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:51:11.960Z
```
{"timestamp":1732247471960200700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Sent cookies."}
```
Same service, the 2 minutes before (oldest first):
  03:51:11.213 [front-end] Order response: {"id":"673fffafd94b9000069b48e0","customerId":"673fff9eb0df5c00019b34c8","customer":{"id":null,"firstName":"lFihmanjHAQGSg","lastName":"lFihmanj
  03:51:11.215 [front-end] POST /orders 201 - ms - -
  03:51:11.741 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fffa5b0df5c00019b34e4"}
  03:51:11.753 [front-end] POST /addresses 200 - ms - -
  03:51:11.756 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fffa5b0df5c00019b34e4"}
  03:51:11.760 [front-end] GET /catalogue 200 - ms - -
  03:51:11.764 [front-end] POST /cards 200 - ms - -
  03:51:11.812 [front-end] Attempting to delete cart for user: 673fffa5b0df5c00019b34e4
  03:51:11.832 [front-end] User cart deleted with status: 202
  03:51:11.833 [front-end] DELETE /cart 202 - ms - -
  03:51:11.838 [front-end] Attempting to add to cart: {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  03:51:11.847 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca
  03:51:11.847 [front-end] POST to carts: http://carts/carts/673fffa5b0df5c00019b34e4/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}
  03:51:11.895 [front-end] POST /cart 201 - ms - -
  03:51:11.930 [front-end] Posting Customer: {"username":"Xikfod","password":"dKOCFQlgf","email":"Xikfod@gmail.com","firstName":"Xikfod","lastName":"Xikfod"}
  03:51:11.936 [front-end] { id: '673fffafb0df5c00019b3505' }
  03:51:11.936 [front-end] 673fffafb0df5c00019b3505
  03:51:11.936 [front-end] Merging carts for customer id: 673fffafb0df5c00019b3505 and session id: NzfCcAkpuAGLP5LNXltHtFCQFDG9giTD
  03:51:11.959 [front-end] Carts merged.
  03:51:11.959 [front-end] set cookie673fffafb0df5c00019b3505
All services, 30 seconds either side (sampled):
  03:50:42.094 [user] ts=2024-11-22T03:50:42.094107445Z caller=middlewares.go:157 method=Health result=2 took=906.737µs  (×32)
  03:50:42.214 [catalogue] ts=2024-11-22T03:50:42Z caller=logging.go:62 method=Get id=837ab141-399e-4c1f-9abc-bace40296bac sock=837ab141-399e-4c1f-9abc-bace40296bac err=null took=3.250133  (×55)
  03:50:42.646 [front-end] GET Request to: http://user/customers/673fff7bb0df5c00019b3463/addresses  (×112)
  03:50:42.678 [queue-master] Received shipment task: 673fff7bb0df5c00019b3463  (×51)
  03:50:43.016 [carts] 2024-11-22 03:50:43.016 INFO [carts,62c89030c9fed6c9,1f150f00b56b4152,false] 7 --- [-nio-80-exec-23] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×42)
  03:50:43.197 [user] ts=2024-11-22T03:50:43.196953645Z caller=middlewares.go:75 method=GetUsers id=673fff7db0df5c00019b3465 result=1 took=1.033758ms  (×41)
  03:50:43.955 [user] ts=2024-11-22T03:50:43.955688525Z caller=middlewares.go:46 method=Register username=QVKeIC email=QVKeIC@gmail.com took=1.152142ms
  03:50:44.231 [carts] 2024-11-22 03:50:44.231 INFO [carts,9797b858b5474be1,7c5af17e7e149bf9,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.CartsController : Merge carts reques  (×23)
  03:50:46.920 [front-end] Posting Customer: {"username":"fURkXZidVbLUb","password":"DVgZIzD","email":"fURkXZidVbLUb@gmail.com","firstName":"fURkXZidVbLUb","lastName":"fURkXZidVbLUb"}
  03:50:49.616 [front-end] Received response: "{\"firstName\":\"MvjLo\",\"lastName\":\"MvjLo\",\"username\":\"MvjLo\",\"id\":\"673fff86b0df5c00019b347f\",\"_links\":{\"addresses\":{\"href
  03:50:51.137 [front-end] Posting Customer: {"username":"SXijrvPKiF","password":"yfHWVbjP","email":"SXijrvPKiF@gmail.com","firstName":"SXijrvPKiF","lastName":"SXijrvPKiF"}
  03:50:55.283 [front-end] Received response: "{\"firstName\":\"ekfWlVpTkIC\",\"lastName\":\"ekfWlVpTkIC\",\"username\":\"ekfWlVpTkIC\",\"id\":\"673fff8fb0df5c00019b348d\",\"_links\":{\"a
  03:50:58.699 [front-end] Posting Customer: {"username":"WwmtawYUvciRKBj","password":"oDvUFYZ","email":"WwmtawYUvciRKBj@gmail.com","firstName":"WwmtawYUvciRKBj","lastName":"WwmtawYUvciRK
  03:51:02.007 [front-end] Received response: "{\"firstName\":\"ZETPaDs\",\"lastName\":\"ZETPaDs\",\"username\":\"ZETPaDs\",\"id\":\"673fff8db0df5c00019b348c\",\"_links\":{\"addresses\":{
  03:51:03.205 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffa7d94b9000069b48d3","customerId":"673fff96b0df5c00019b34a4","customer":{"id":null,"firstName":"fURkXZidVbL
  03:51:03.919 [front-end] Order response: {"id":"673fffa7d94b9000069b48d5","customerId":"673fff91b0df5c00019b3493","customer":{"id":null,"firstName":"lrPzjZx","lastName":"lrPzjZx","usern
  03:51:05.412 [queue-master] 2024-11-22 03:51:05.412 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×27)
  03:51:05.816 [front-end] Order response: {"id":"673fffa9d94b9000069b48da","customerId":"673fff90b0df5c00019b3490","customer":{"id":null,"firstName":"eAUFvOMqivvrV","lastName":"eAUFvOMqi
  03:51:08.814 [front-end] Order response: {"id":"673fffacd94b9000069b48dd","customerId":"673fff91b0df5c00019b3492","customer":{"id":null,"firstName":"nhZYDjilGacQtcv","lastName":"nhZYDji
  03:51:11.213 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffafd94b9000069b48e0","customerId":"673fff9eb0df5c00019b34c8","customer":{"id":null,"firstName":"lFihmanjHAQ
  03:51:13.519 [front-end] Order response: {"id":"673fffb1d94b9000069b48e2","customerId":"673fff9ab0df5c00019b34b0","customer":{"id":null,"firstName":"YWomJxQ","lastName":"YWomJxQ","usern
  03:51:16.238 [front-end] Received response: "{\"firstName\":\"KspdjdfWQwxh\",\"lastName\":\"KspdjdfWQwxh\",\"username\":\"KspdjdfWQwxh\",\"id\":\"673fffa1b0df5c00019b34ca\",\"_links\":{
  03:51:16.822 [front-end] Order response: {"id":"673fffb4d94b9000069b48e9","customerId":"673fffa6b0df5c00019b34e5","customer":{"id":null,"firstName":"envMnATCNSGnBO","lastName":"envMnATC
  03:51:20.961 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffb8d94b9000069b48ed","customerId":"673fffa2b0df5c00019b34d5","customer":{"id":null,"firstName":"WwmtawYUvci
  03:51:23.302 [front-end] Posting Customer: {"username":"tbSKTtpX","password":"nkpftrjkf","email":"tbSKTtpX@gmail.com","firstName":"tbSKTtpX","lastName":"tbSKTtpX"}
  03:51:25.917 [front-end] Received response: "{\"firstName\":\"JlXpqKrXrNmuY\",\"lastName\":\"JlXpqKrXrNmuY\",\"username\":\"JlXpqKrXrNmuY\",\"id\":\"673fffa5b0df5c00019b34e4\",\"_links\
  03:51:27.986 [front-end] Received response: "{\"firstName\":\"zWPolVrh\",\"lastName\":\"zWPolVrh\",\"username\":\"zWPolVrh\",\"id\":\"673fffa7b0df5c00019b34e8\",\"_links\":{\"addresses\
  03:51:31.497 [front-end] Order response: {"id":"673fffc3d94b9000069b48f6","customerId":"673fffaeb0df5c00019b34fc","customer":{"id":null,"firstName":"VbMPd","lastName":"VbMPd","username"
  03:51:35.592 [front-end] Posting Customer: {"username":"jMzqwsSaOtry","password":"AoBAipmTW","email":"jMzqwsSaOtry@gmail.com","firstName":"jMzqwsSaOtry","lastName":"jMzqwsSaOtry"}
  03:51:38.721 [front-end] Received response: "{\"firstName\":\"qjETvi\",\"lastName\":\"qjETvi\",\"username\":\"qjETvi\",\"id\":\"673fffb0b0df5c00019b3506\",\"_links\":{\"addresses\":{\"h

## p0013
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T06:14:33.490Z
```
{"service":"dbservice1","message":"2021-08-13 06:14:33,490 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 2dc2c66a713f767c | query = select passwards from username_table where user_name='rJNyXqRj'"}
```
Same service, the 2 minutes before (oldest first):
  06:14:24.827 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×6)
  06:14:24.869 [dbservice1] INFO query = select passwards from username_table where user_name='cforzalb'  (×4)
  06:14:24.946 [dbservice1] INFO a6870d1c-fbba-11eb-94cb-0242ac110003-cforzalb-X-U4NfJV3_Q= token generate success token=MTYyODgwNjQ2NC45NDYzNzg1OmE2ODcwZDFjLWZiYmEtMTFlYi05NGNiLTAyNDJhYzE  (×2)
  06:14:27.658 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  06:14:28.262 [dbservice1] INFO a895bd42-fbba-11eb-94ae-0242ac110004-wVcuUpbK-W^z<aB52Vgc- token generate success token=MTYyODgwNjQ2OC4yNjIzNDc1OmE4OTViZDQyLWZiYmEtMTFlYi05NGFlLTAyNDJhYzE
  06:14:29.050 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  06:14:29.892 [dbservice1] INFO a980e1fa-fbba-11eb-9c42-0242ac110004-ZzmSOCgj--Z!lLScPi9</ token generate success token=MTYyODgwNjQ2OS44OTIwNTc0OmE5ODBlMWZhLWZiYmEtMTFlYi05YzQyLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  06:14:03.498 [webservice2] INFO complete information: {'uuid': '9a214ce0-fbba-11eb-812e-0242ac110004', 'user_id': 'xUAQKIOl'}  (×45)
  06:14:03.668 [redisservice1] INFO redis write success  (×81)
  06:14:03.805 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '9a214ce0-fbba-11eb-812e-0242ac110004', 'user_id': 'xUAQKIOl'}  (×89)
  06:14:04.018 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  06:14:04.155 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '9a9e5e56-fbba-11eb-b9a4-0242ac110003', 'value': '', 'ex': 10}  (×45)
  06:14:04.418 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×46)
  06:14:05.334 [mobservice1] INFO info 9b1edc34-fbba-11eb-9d5e-0242ac110003:bhmAUvxt write success
  06:14:05.535 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  06:14:07.247 [mobservice2] INFO info 9c378616-fbba-11eb-b608-0242ac110003:WRrkiQEt write success
  06:14:09.710 [mobservice1] INFO info 9dc06dea-fbba-11eb-92d7-0242ac110003:GrAcpCvX write success
  06:14:11.843 [mobservice2] INFO info 9f002dee-fbba-11eb-a8a6-0242ac110003:vRBrHTWY write success
  06:14:14.189 [mobservice1] INFO info a06682aa-fbba-11eb-ab65-0242ac110004:MXIwargu write success
  06:14:16.548 [mobservice1] INFO info a1ce7b16-fbba-11eb-90c3-0242ac110004:YWGLHvVN write success
  06:14:19.387 [mobservice2] INFO info a369ff68-fbba-11eb-b3ea-0242ac110003:irpbvSZq write success
  06:14:27.497 [dbservice2] INFO a80c7dc0-fbba-11eb-909a-0242ac110003-laVNGIPf-{Z8wE?(U^nzJ token generate success token=MTYyODgwNjQ2Ny40OTY1MjE3OmE4MGM3ZGMwLWZiYmEtMTFlYi05MDlhLTAyNDJhYzE
  06:14:30.282 [mobservice2] INFO info a9eeb234-fbba-11eb-b2c9-0242ac110004:IfxPKRFv write success
  06:14:32.955 [dbservice2] INFO ab5be902-fbba-11eb-a649-0242ac110004-GSgbqoFw-Y_*N-71D.6+R token generate success token=MTYyODgwNjQ3Mi45NTQ2NDY2OmFiNWJlOTAyLWZiYmEtMTFlYi1hNjQ5LTAyNDJhYzE
  06:14:35.311 [dbservice1] INFO acc38732-fbba-11eb-b587-0242ac110004-kLYBXRtg-qc#u?jieO(yH token generate success token=MTYyODgwNjQ3NS4zMTA2NjQyOmFjYzM4NzMyLWZiYmEtMTFlYi1iNTg3LTAyNDJhYzE
  06:14:37.693 [dbservice2] INFO ae2875c4-fbba-11eb-bce5-0242ac110003-mgvTPLKy-UE!Q+o#:Kz9% token generate success token=MTYyODgwNjQ3Ny42OTM0MTU5OmFlMjg3NWM0LWZiYmEtMTFlYi1iY2U1LTAyNDJhYzE
  06:14:40.114 [dbservice2] INFO afa3cbec-fbba-11eb-afbe-0242ac110004-pkiwOTAa-MCwpc)<4IznE token generate success token=MTYyODgwNjQ4MC4xMTQwNzc6YWZhM2NiZWMtZmJiYS0xMWViLWFmYmUtMDI0MmFjMTE
  06:14:43.001 [dbservice2] INFO b154e7a0-fbba-11eb-a74a-0242ac110004-pyWndFNv-k$0)mK!%.@XT token generate success token=MTYyODgwNjQ4My4wMDA1MjYyOmIxNTRlN2EwLWZiYmEtMTFlYi1hNzRhLTAyNDJhYzE  (×2)
  06:14:46.137 [dbservice1] INFO b338dbda-fbba-11eb-8902-0242ac110004-tBDHvTdf--r!uKC9qw1f: token generate success token=MTYyODgwNjQ4Ni4xMzcxODg6YjMzOGRiZGEtZmJiYS0xMWViLTg5MDItMDI0MmFjMTE
  06:14:48.459 [dbservice1] INFO b4a3cb1a-fbba-11eb-b55c-0242ac110004-RcoJYnsh-sPdxZat-)M%I token generate success token=MTYyODgwNjQ4OC40NTkwMzA0OmI0YTNjYjFhLWZiYmEtMTFlYi1iNTVjLTAyNDJhYzE
  06:14:51.320 [mobservice2] INFO info b688130a-fbba-11eb-82d4-0242ac110003:zwDGqUsI write success
  06:14:53.717 [dbservice1] INFO b7ade552-fbba-11eb-8d61-0242ac110003-NSiQolUW-T3rg/Jh_qz#l token generate success token=MTYyODgwNjQ5My43MTcwOTIzOmI3YWRlNTUyLWZiYmEtMTFlYi04ZDYxLTAyNDJhYzE
  06:14:56.326 [dbservice2] INFO b94cadf8-fbba-11eb-8e87-0242ac110004-BGRWzCUk-U%NApF&5I:E7 token generate success token=MTYyODgwNjQ5Ni4zMjYxODA3OmI5NGNhZGY4LWZiYmEtMTFlYi04ZTg3LTAyNDJhYzE
  06:14:58.922 [mobservice2] INFO info bb0a0f8c-fbba-11eb-9292-0242ac110004:OiYedVug write success
  06:15:01.432 [mobservice1] INFO info bc8f1be0-fbba-11eb-a3aa-0242ac110003:EVWjdQPL write success

## p0405
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:51:53.316Z
```
{"timestamp":1732247513316558800,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:51:53.31643212Z caller=middlewares.go:75 method=GetUsers id=673fffc3b0df5c00019b3527 result=1 took=936.093µs"}
```
Same service, the 2 minutes before (oldest first):
  03:51:51.094 [user] ts=2024-11-22T03:51:51.094189765Z caller=middlewares.go:157 method=Health result=2 took=701.699µs  (×2)
  03:51:51.106 [user] ts=2024-11-22T03:51:51.106210342Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673fffcfb0df5c00019b354f took=1.695653ms  (×4)
  03:51:51.120 [user] ts=2024-11-22T03:51:51.119973974Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673fffcfb0df5c00019b354f took=1.61274ms  (×4)
  03:51:51.387 [user] ts=2024-11-22T03:51:51.38724232Z caller=middlewares.go:46 method=Register username=kpsfQP email=kpsfQP@gmail.com took=1.130455ms
  03:51:52.106 [user] ts=2024-11-22T03:51:52.10639868Z caller=middlewares.go:75 method=GetUsers id=673fffc5b0df5c00019b3531 result=1 took=893.256µs  (×4)
  03:51:52.112 [user] ts=2024-11-22T03:51:52.112609581Z caller=middlewares.go:75 method=GetUsers id=673fffc5b0df5c00019b3531 result=1 took=1.015493ms  (×2)
  03:51:52.121 [user] ts=2024-11-22T03:51:52.121468078Z caller=middlewares.go:104 method=GetAddresses id=673fffcab0df5c00019b353e result=1 took=813.037µs
  03:51:52.121 [user] ts=2024-11-22T03:51:52.12156216Z caller=middlewares.go:134 method=GetCards id=673fffcab0df5c00019b353f result=1 took=744.287µs
  03:51:52.409 [user] ts=2024-11-22T03:51:52.408936694Z caller=middlewares.go:46 method=Register username=ZnlQTMe email=ZnlQTMe@gmail.com took=977.893µs
All services, 30 seconds either side (sampled):
  03:51:23.332 [front-end] Carts merged.  (×60)
  03:51:23.923 [front-end] [ undefined, undefined ]  (×56)
  03:51:23.951 [queue-master] 2024-11-22 03:51:23.950 INFO 6 --- [ool-6-thread-24] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×120)
  03:51:24.245 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffbcd94b9000069b48f0","customerId":"673fffa9b0df5c00019b34ee","customer":{"id":null,"firstName":"GLsre","las
  03:51:25.955 [front-end] Order response: {"id":"673fffbdd94b9000069b48f2","customerId":"673fffa5b0df5c00019b34e4","customer":{"id":null,"firstName":"JlXpqKrXrNmuY","lastName":"JlXpqKrXr
  03:51:26.907 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffbed94b9000069b48f4","customerId":"673fffabb0df5c00019b34f3","customer":{"id":null,"firstName":"NgOOipukSXw
  03:51:29.160 [user] ts=2024-11-22T03:51:29.159874763Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673fffb9b0df5c00019b351a took=1.639925ms  (×57)
  03:51:29.293 [front-end] POST /cart 201 - ms - -  (×57)
  03:51:31.063 [front-end] Posting Customer: {"username":"uiIIWurGxFKR","password":"okHvC","email":"uiIIWurGxFKR@gmail.com","firstName":"uiIIWurGxFKR","lastName":"uiIIWurGxFKR"}
  03:51:32.449 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×8)
  03:51:35.641 [front-end] Posting Customer: {"username":"ewDMfuPY","password":"FQxKjswYJ","email":"ewDMfuPY@gmail.com","firstName":"ewDMfuPY","lastName":"ewDMfuPY"}
  03:51:38.721 [front-end] Received response: "{\"firstName\":\"qjETvi\",\"lastName\":\"qjETvi\",\"username\":\"qjETvi\",\"id\":\"673fffb0b0df5c00019b3506\",\"_links\":{\"addresses\":{\"h
  03:51:41.728 [payment] ts=2024-11-22T03:51:41Z caller=logging.go:29 method=Authorise result=true took=1.049µs  (×11)
  03:51:43.262 [front-end] Order response: {"id":"673fffcfd94b9000069b48fb","customerId":"673fffbdb0df5c00019b351f","customer":{"id":null,"firstName":"snWvbH","lastName":"snWvbH","usernam
  03:51:44.554 [front-end] Order response: {"id":"673fffd0d94b9000069b48fe","customerId":"673fffbbb0df5c00019b351e","customer":{"id":null,"firstName":"tbSKTtpX","lastName":"tbSKTtpX","use
  03:51:47.390 [front-end] Posting Customer: {"username":"uoyWgBozCjHlow","password":"fITNFf","email":"uoyWgBozCjHlow@gmail.com","firstName":"uoyWgBozCjHlow","lastName":"uoyWgBozCjHlow"}
  03:51:49.525 [user] ts=2024-11-22T03:51:49.525666205Z caller=middlewares.go:46 method=Register username=bVyBQKEvd email=bVyBQKEvd@gmail.com took=1.152823ms
  03:51:51.382 [front-end] Posting Customer: {"username":"kpsfQP","password":"wtHeGtnKU","email":"kpsfQP@gmail.com","firstName":"kpsfQP","lastName":"kpsfQP"}
  03:51:54.067 [front-end] Order response: {"statusCode":201,"body":{"id":"673fffdad94b9000069b4906","customerId":"673fffc4b0df5c00019b352f","customer":{"id":null,"firstName":"qVqqa","las
  03:51:57.297 [front-end] Posting Customer: {"username":"sDLlRTLWLYx","password":"IysaOuI","email":"sDLlRTLWLYx@gmail.com","firstName":"sDLlRTLWLYx","lastName":"sDLlRTLWLYx"}
  03:52:01.551 [queue-master] 2024-11-22 03:52:01.551 INFO 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×9)
  03:52:03.084 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  03:52:06.270 [front-end] Posting Customer: {"username":"tdNnX","password":"juCsFyF","email":"tdNnX@gmail.com","firstName":"tdNnX","lastName":"tdNnX"}
  03:52:07.244 [front-end] Received response: "{\"firstName\":\"UNjKenDRxWgp\",\"lastName\":\"UNjKenDRxWgp\",\"username\":\"UNjKenDRxWgp\",\"id\":\"673fffd5b0df5c00019b356b\",\"_links\":{
  03:52:08.446 [front-end] Received response: "{\"firstName\":\"dzcnipxzGupoor\",\"lastName\":\"dzcnipxzGupoor\",\"username\":\"dzcnipxzGupoor\",\"id\":\"673fffd4b0df5c00019b3565\",\"_lin
  03:52:10.513 [front-end] Posting Customer: {"username":"hoEMJDQT","password":"loJovAq","email":"hoEMJDQT@gmail.com","firstName":"hoEMJDQT","lastName":"hoEMJDQT"}
  03:52:11.723 [front-end] Order response: {"id":"673fffebd94b9000069b4919","customerId":"673fffd8b0df5c00019b3573","customer":{"id":null,"firstName":"ZnlQTMe","lastName":"ZnlQTMe","usern
  03:52:16.591 [front-end] Received response: "{\"firstName\":\"kpsfQP\",\"lastName\":\"kpsfQP\",\"username\":\"kpsfQP\",\"id\":\"673fffd7b0df5c00019b356e\",\"_links\":{\"addresses\":{\"h
  03:52:19.068 [front-end] Received response: "{\"firstName\":\"epCfef\",\"lastName\":\"epCfef\",\"username\":\"epCfef\",\"id\":\"673fffe1b0df5c00019b3592\",\"_links\":{\"addresses\":{\"h
  03:52:21.852 [user] ts=2024-11-22T03:52:21.851941062Z caller=middlewares.go:46 method=Register username=WrORxwTBq email=WrORxwTBq@gmail.com took=913.282µs

## p0140
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:32:48.465Z
```
{"timestamp":1731907968465991400,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  05:32:47.098 [frontend] ENV_PLATFORM is: aws
  05:32:47.103 [frontend] request complete  (×7)
  05:32:47.161 [frontend] request started  (×6)
  05:32:47.161 [frontend] serving product page  (×5)
  05:32:48.306 [frontend] view user cart
All services, 30 seconds either side (sampled):
  05:32:18.801 [frontend] request started  (×302)
  05:32:18.808 [cartservice] GetCartAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43  (×252)
  05:32:18.832 [adservice] received ad request (context_words=[kitchen])  (×47)
  05:32:18.842 [cartservice] AddItemAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43, productId=9SIQT8TOJO, quantity=3  (×31)
  05:32:18.880 [shippingservice] [GetQuote] completed request  (×73)
  05:32:19.234 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="USD"  (×3)
  05:32:19.254 [checkoutservice] payment went through (transaction_id: d0dbffff-0f58-41c3-811d-5b760858da62)  (×12)
  05:32:19.259 [cartservice] EmptyCartAsync called with userId=f3509d43-91d9-45a0-a174-70f597a55fb4  (×12)
  05:32:19.265 [frontend] order placed  (×12)
  05:32:19.832 [frontend] ENV_PLATFORM is: aws  (×37)
  05:32:23.342 [adservice] received ad request (context_words=[footwear])  (×17)
  05:32:27.985 [frontend] setting currency  (×20)
  05:32:29.432 [paymentservice] Transaction processed: visa ending 1596 Amount: CAD1095.826554624  (×2)
  05:32:31.917 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="TRY"  (×2)
  05:32:31.967 [emailservice] A request to send order confirmation email to lewisbrian@example.net has been received.
  05:32:32.431 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"332","nanos":153707198},"credit_card":{"credit_card_number":"46106407054499  (×3)
  05:32:32.448 [checkoutservice] order confirmation email sent to "steven68@example.org"
  05:32:45.693 [emailservice] A request to send order confirmation email to qsullivan@example.net has been received.
  05:32:56.072 [emailservice] A request to send order confirmation email to brian95@example.com has been received.
  05:33:05.521 [checkoutservice] [PlaceOrder] user_id="0727db9d-83b9-44b7-acab-68a4f8f289c0" user_currency="JPY"
  05:33:05.563 [emailservice] A request to send order confirmation email to todd58@example.org has been received.
  05:33:11.180 [checkoutservice] order confirmation email sent to "gailthompson@example.net"
  05:33:11.772 [paymentservice] Transaction processed: visa ending 0254 Amount: EUR1162.96417522
  05:33:14.018 [emailservice] A request to send order confirmation email to cristina39@example.org has been received.
  05:33:17.829 [checkoutservice] order confirmation email sent to "blackanthony@example.net"
