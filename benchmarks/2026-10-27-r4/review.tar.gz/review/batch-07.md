## p0449
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:06:12.706Z
```
{"timestamp":1732349172706266400,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"timestamp\":1732349172700,\"status\":500,\"error\":\"Internal Server Error\",\"exception\":\"java.lang.IllegalStateException\",\"message\":\"Unable to create order due to unspecified IO error.\",\"path\":\"/orders\"}"}
```
Same service, the 2 minutes before (oldest first):
  08:06:12.434 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732349172431,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×2)
  08:06:12.434 [front-end] Order response: {"timestamp":1732349172431,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  08:06:12.436 [front-end] POST /orders 500 - ms - -
  08:06:12.591 [front-end] Request received with body: {}  (×2)
  08:06:12.607 [front-end] Received response: "{\"firstName\":\"ngatc\",\"lastName\":\"ngatc\",\"username\":\"ngatc\",\"id\":\"67418cdfa437380001deec5c\",\"_links\":{\"addresses\":{\"href
  08:06:12.607 [front-end] GET Request to: http://user/customers/67418cdfa437380001deec5c/addresses  (×4)
  08:06:12.622 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418  (×2)
  08:06:12.622 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418ce7a437380001deec77\",\"_links\":{\"  (×2)
  08:06:12.622 [front-end] [ undefined, undefined ]  (×2)
  08:06:12.622 [front-end] Posting Order: {"customer":"http://user/customers/67418cdfa437380001deec5c","address":"http://user/addresses/67418ce7a437380001deec75","card":"http://user/cards  (×2)
  08:06:12.629 [front-end] Received response: "{\"firstName\":\"WUyAw\",\"lastName\":\"WUyAw\",\"username\":\"WUyAw\",\"id\":\"67418cdea437380001deec56\",\"_links\":{\"addresses\":{\"href
All services, 30 seconds either side (sampled):
  08:05:42.737 [payment] ts=2024-11-23T08:05:42Z caller=logging.go:40 method=Health result=1 took=7.552µs  (×40)
  08:05:43.228 [queue-master] 2024-11-23 08:05:43.228 INFO 7 --- [p-nio-80-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  08:05:43.611 [front-end] set cookie67418cd7a437380001deec42  (×61)
  08:05:44.682 [front-end] POST to carts: http://carts/carts/67418ccfa437380001deec29/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}  (×35)
  08:05:45.706 [front-end] Received response: "{\"firstName\":\"TUwwDhCkvEuN\",\"lastName\":\"TUwwDhCkvEuN\",\"username\":\"TUwwDhCkvEuN\",\"id\":\"67418cc5a437380001deec07\",\"_links\":{
  08:05:49.010 [shipping] 2024-11-23 08:05:49.010 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map
  08:05:50.334 [front-end] Posting Customer: {"username":"WUyAw","password":"kHKFVbVXGj","email":"WUyAw@gmail.com","firstName":"WUyAw","lastName":"WUyAw"}
  08:05:54.269 [user] ts=2024-11-23T08:05:54.269158571Z caller=middlewares.go:46 method=Register username=imiXj email=imiXj@gmail.com took=1.773598ms
  08:05:55.023 [front-end] Posting Customer: {"username":"brTpfrzj","password":"CqouP","email":"brTpfrzj@gmail.com","firstName":"brTpfrzj","lastName":"brTpfrzj"}
  08:05:58.133 [front-end] Received response: "{\"firstName\":\"uOuKqLBUeqm\",\"lastName\":\"uOuKqLBUeqm\",\"username\":\"uOuKqLBUeqm\",\"id\":\"67418cd1a437380001deec35\",\"_links\":{\"a
  08:06:00.413 [carts] 2024-11-23 08:06:00.413 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  08:06:04.542 [front-end] Received response: "{\"firstName\":\"yeVOXGwCs\",\"lastName\":\"yeVOXGwCs\",\"username\":\"yeVOXGwCs\",\"id\":\"67418cd3a437380001deec3b\",\"_links\":{\"address
  08:06:07.000 [shipping] 2024-11-23 08:06:07.000 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[HEAD],produces=[application/hal+json
  08:06:07.008 [shipping] 2024-11-23 08:06:07.008 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[DELETE],prod
  08:06:07.614 [user] ts=2024-11-23T08:06:07.614423361Z caller=middlewares.go:46 method=Register username=ucodWkVEg email=ucodWkVEg@gmail.com took=3.000643ms
  08:06:13.586 [front-end] Received response: "{\"firstName\":\"psXVPVgRfTd\",\"lastName\":\"psXVPVgRfTd\",\"username\":\"psXVPVgRfTd\",\"id\":\"67418cdda437380001deec55\",\"_links\":{\"a
  08:06:15.603 [carts] 2024-11-23 08:06:15.603 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.actu
  08:06:15.805 [carts] 2024-11-23 08:06:15.805 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[DELETE],produce
  08:06:16.401 [shipping] 2024-11-23 08:06:16.400 INFO [shipping,,,] 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase -2147482648
  08:06:19.002 [carts] 2024-11-23 08:06:19.002 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  08:06:19.274 [front-end] Posting Customer: {"username":"ctDNRPS","password":"kZNuA","email":"ctDNRPS@gmail.com","firstName":"ctDNRPS","lastName":"ctDNRPS"}
  08:06:24.004 [carts] 2024-11-23 08:06:24.003 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:06:26.093 [front-end] Received response: "{\"firstName\":\"XJzSyDLxvp\",\"lastName\":\"XJzSyDLxvp\",\"username\":\"XJzSyDLxvp\",\"id\":\"67418cefa437380001deec90\",\"_links\":{\"addr
  08:06:28.351 [front-end] Received response: "{\"firstName\":\"VnaknAEtTvwY\",\"lastName\":\"VnaknAEtTvwY\",\"username\":\"VnaknAEtTvwY\",\"id\":\"67418ceca437380001deec88\",\"_links\":{
  08:06:31.705 [carts-db] {"t":{"$date":"2024-11-23T08:06:31.705+00:00"},"s":"I", "c":"STORAGE", "id":20320, "ctx":"conn4","msg":"createCollection","attr":{"namespace":"data.cart","uuidD  (×8)
  08:06:32.828 [shipping] 2024-11-23 08:06:32.828 INFO [shipping,,,] 7 --- [p-nio-80-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization star
  08:06:34.918 [rabbitmq] accepting AMQP connection <0.573.0> (127.0.0.6:57579 -> 192.168.93.151:5672) 
  08:06:36.198 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d0b3f77060008864e3f","customerId":"67418cf2a437380001deec94","customer":{"id":null,"firstName":"SPVlWNNsjee
  08:06:40.396 [front-end] Posting Customer: {"username":"ehjzbOPHpDjC","password":"qwbmwOfmZE","email":"ehjzbOPHpDjC@gmail.com","firstName":"ehjzbOPHpDjC","lastName":"ehjzbOPHpDjC"}
  08:06:41.695 [front-end] Received response: "{\"firstName\":\"teNYQYg\",\"lastName\":\"teNYQYg\",\"username\":\"teNYQYg\",\"id\":\"67418cf5a437380001deec9b\",\"_links\":{\"addresses\":{

## p0117
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:17:40.213Z
```
{"timestamp":1731907060213034800,"container_name":"adservice","pod_name":"adservice-b9bcc6cc9-h4k2c","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"*** server shut down"}
```
Same service, the 2 minutes before (oldest first):
  05:17:34.069 [adservice] received ad request (context_words=[decor, home])
  05:17:34.221 [adservice] received ad request (context_words=[kitchen])  (×4)
  05:17:34.919 [adservice] received ad request (context_words=[footwear])  (×2)
  05:17:34.960 [adservice] received ad request (context_words=[hair, beauty])  (×5)
  05:17:36.105 [adservice] received ad request (context_words=[accessories])  (×2)
  05:17:37.384 [adservice] received ad request (context_words=[clothing, tops])  (×3)
  05:17:38.820 [adservice] received ad request (context_words=[])  (×2)
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
All services, 30 seconds either side (sampled):
  05:17:10.253 [frontend] request started  (×280)
  05:17:10.260 [cartservice] GetCartAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432  (×238)
  05:17:10.285 [adservice] received ad request (context_words=[accessories])  (×12)
  05:17:10.324 [frontend] adding to cart  (×24)
  05:17:10.367 [shippingservice] [GetQuote] received request  (×76)
  05:17:12.011 [adservice] received ad request (context_words=[clothing, tops])  (×8)
  05:17:12.236 [frontend] ENV_PLATFORM is: aws  (×30)
  05:17:16.636 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '66VCHSJNUP']  (×4)
  05:17:16.693 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"1792","nanos":226454698},"credit_card":{"credit_card_number":"4639203387545  (×4)
  05:17:16.696 [shippingservice] [ShipOrder] received request  (×7)
  05:17:16.705 [emailservice] A request to send order confirmation email to abowman@example.com has been received.
  05:17:16.824 [emailservice] A request to send order confirmation email to barbara24@example.com has been received.
  05:17:23.425 [adservice] received ad request (context_words=[footwear])  (×6)
  05:17:24.111 [paymentservice] Transaction processed: visa ending 1703 Amount: CAD346.438559926  (×2)
  05:17:25.127 [emailservice] A request to send order confirmation email to coxchristine@example.net has been received.
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:43.747 [adservice] AdService starting.  (×2)
  05:17:43.841 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.  (×2)
  05:17:45.450 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  05:17:55.239 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="EUR"
  05:17:55.276 [emailservice] A request to send order confirmation email to alopez@example.org has been received.
  05:18:02.298 [checkoutservice] order confirmation email sent to "caseyhoward@example.com"

## p0237
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T08:00:30.858Z
```
{"timestamp":1731916830858485800,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  08:00:29.571 [frontend] request started  (×7)
  08:00:29.571 [frontend] view user cart  (×2)
  08:00:29.608 [frontend] request complete  (×6)
  08:00:30.028 [frontend] serving product page  (×4)
  08:00:30.632 [frontend] adding to cart
All services, 30 seconds either side (sampled):
  08:00:00.873 [frontend] request started  (×329)
  08:00:00.879 [cartservice] GetCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×260)
  08:00:00.900 [shippingservice] [GetQuote] completed request  (×87)
  08:00:01.583 [frontend] serving product page  (×131)
  08:00:02.365 [adservice] received ad request (context_words=[clothing, tops])  (×16)
  08:00:02.677 [adservice] received ad request (context_words=[])  (×42)
  08:00:06.317 [frontend] adding to cart  (×36)
  08:00:09.075 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="JPY"
  08:00:09.106 [checkoutservice] payment went through (transaction_id: 3dc783cd-99ba-4c6c-b13a-b978c4997452)  (×11)
  08:00:09.110 [cartservice] EmptyCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03  (×11)
  08:00:09.119 [checkoutservice] failed to send order confirmation to "snyderjohn@example.org": rpc error: code = Internal desc = Failed to serialize response!
  08:00:09.580 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"355","nanos":720361781},"credit_card":{"credit_card_number":"43882900269244  (×4)
  08:00:09.596 [checkoutservice] failed to send order confirmation to "estradaelizabeth@example.net": rpc error: code = Internal desc = Failed to serialize response!
  08:00:13.224 [recommendationservice] [Recv ListRecommendations] product_ids=['9SIQT8TOJO', 'OLJCESPC7Z', 'L9ECAV7KIM']  (×3)
  08:00:20.103 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"2811","nanos":520000000},"credit_card":{"credit_card_number":"4524971626123
  08:00:20.121 [checkoutservice] failed to send order confirmation to "taramoon@example.com": rpc error: code = Internal desc = Failed to serialize response!
  08:00:38.231 [emailservice] A request to send order confirmation email to alex38@example.org has been received.
  08:00:49.376 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"2830","nanos":481585150},"credit_card":{"credit_card_number":"4189279411431  (×2)
  08:00:49.390 [checkoutservice] failed to send order confirmation to "jeremy69@example.net": rpc error: code = Internal desc = Failed to serialize response!
  08:00:51.186 [paymentservice] Transaction processed: visa ending 4453 Amount: EUR108.739495801  (×3)
  08:00:52.200 [emailservice] A request to send order confirmation email to eblair@example.org has been received.
  08:00:54.411 [checkoutservice] failed to send order confirmation to "benderalyssa@example.org": rpc error: code = Internal desc = Failed to serialize response!
  08:00:59.020 [emailservice] A request to send order confirmation email to kerry58@example.net has been received.

## p0365
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:36:22.252Z
```
{"timestamp":1732246582252700000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"{ id: '673ffc36b0df5c00019b2a45' }"}
```
Same service, the 2 minutes before (oldest first):
  03:36:21.761 [front-end] POST /cards 200 - ms - -
  03:36:21.808 [front-end] Attempting to delete cart for user: 673ffc2db0df5c00019b2a32
  03:36:21.830 [front-end] User cart deleted with status: 202
  03:36:21.832 [front-end] DELETE /cart 202 - ms - -
  03:36:21.837 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  03:36:21.849 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  03:36:21.849 [front-end] POST to carts: http://carts/carts/673ffc2db0df5c00019b2a32/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  03:36:21.895 [front-end] POST /cart 201 - ms - -
  03:36:22.067 [front-end] Request received with body: {}
  03:36:22.073 [front-end] Received response: "{\"firstName\":\"ARCovtMT\",\"lastName\":\"ARCovtMT\",\"username\":\"ARCovtMT\",\"id\":\"673ffc1fb0df5c00019b2a08\",\"_links\":{\"addresses\
  03:36:22.073 [front-end] GET Request to: http://user/customers/673ffc1fb0df5c00019b2a08/addresses  (×2)
  03:36:22.081 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffc27b0df5c00019b2a29\",\"_links\":{\"
  03:36:22.081 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:36:22.081 [front-end] [ undefined, undefined ]
  03:36:22.081 [front-end] Posting Order: {"customer":"http://user/customers/673ffc1fb0df5c00019b2a08","address":"http://user/addresses/673ffc27b0df5c00019b2a28","card":"http://user/cards
  03:36:22.113 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc36d94b9000069b463a","customerId":"673ffc1fb0df5c00019b2a08","customer":{"id":null,"firstName":"ARCovtMT","
  03:36:22.113 [front-end] Order response: {"id":"673ffc36d94b9000069b463a","customerId":"673ffc1fb0df5c00019b2a08","customer":{"id":null,"firstName":"ARCovtMT","lastName":"ARCovtMT","use
  03:36:22.114 [front-end] POST /orders 201 - ms - -
  03:36:22.246 [front-end] Posting Customer: {"username":"jqdvFFlf","password":"JshiLcv","email":"jqdvFFlf@gmail.com","firstName":"jqdvFFlf","lastName":"jqdvFFlf"}
All services, 30 seconds either side (sampled):
  03:35:52.255 [front-end] POST /cart 201 - ms - -  (×64)
  03:35:52.432 [catalogue] ts=2024-11-22T03:35:52Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=5.199732  (×58)
  03:35:52.764 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff  (×66)
  03:35:52.795 [queue-master] 2024-11-22 03:35:52.795 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×54)
  03:35:53.874 [user] ts=2024-11-22T03:35:53.873943585Z caller=middlewares.go:46 method=Register username=uvMTxIVdMmuCLX email=uvMTxIVdMmuCLX@gmail.com took=1.059841ms  (×26)
  03:35:55.313 [front-end] Received response: "{\"firstName\":\"dbxdkCXENSQ\",\"lastName\":\"dbxdkCXENSQ\",\"username\":\"dbxdkCXENSQ\",\"id\":\"673ffc03b0df5c00019b29b2\",\"_links\":{\"a
  03:35:55.684 [carts] 2024-11-22 03:35:55.684 INFO [carts,f2ae27ee47f24e6c,e7f16daa4bade3e5,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×28)
  03:35:57.650 [user] ts=2024-11-22T03:35:57.649906616Z caller=middlewares.go:46 method=Register username=OtThRHppyMWv email=OtThRHppyMWv@gmail.com took=978.972µs  (×8)
  03:35:59.306 [front-end] Order response: {"id":"673ffc1fd94b9000069b4621","customerId":"673ffc0ab0df5c00019b29c3","customer":{"id":null,"firstName":"SoldnTuscCR","lastName":"SoldnTuscCR
  03:36:02.172 [front-end] Order response: {"id":"673ffc22d94b9000069b4623","customerId":"673ffc04b0df5c00019b29b5","customer":{"id":null,"firstName":"vZCSNEGC","lastName":"vZCSNEGC","use
  03:36:03.452 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc23d94b9000069b4625","customerId":"673ffc0cb0df5c00019b29cc","customer":{"id":null,"firstName":"VmQerZhjPmv
  03:36:04.791 [front-end] Posting Customer: {"username":"bgjkfAfrLnOixr","password":"WSrDTAAVOn","email":"bgjkfAfrLnOixr@gmail.com","firstName":"bgjkfAfrLnOixr","lastName":"bgjkfAfrLnOix
  03:36:07.348 [front-end] Received response: "{\"firstName\":\"RXYOWERvYm\",\"lastName\":\"RXYOWERvYm\",\"username\":\"RXYOWERvYm\",\"id\":\"673ffc14b0df5c00019b29e1\",\"_links\":{\"addr
  03:36:11.908 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc2bd94b9000069b462e","customerId":"673ffc1db0df5c00019b2a02","customer":{"id":null,"firstName":"OtThRHppyMW
  03:36:13.370 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc2dd94b9000069b4632","customerId":"673ffc20b0df5c00019b2a09","customer":{"id":null,"firstName":"iSGYfcrdcdF
  03:36:15.206 [front-end] Received response: "{\"firstName\":\"GaJLClHtnct\",\"lastName\":\"GaJLClHtnct\",\"username\":\"GaJLClHtnct\",\"id\":\"673ffc17b0df5c00019b29f1\",\"_links\":{\"a
  03:36:17.371 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc31d94b9000069b4637","customerId":"673ffc1eb0df5c00019b2a07","customer":{"id":null,"firstName":"qAqSarWAcMd
  03:36:20.085 [front-end] Order response: {"id":"673ffc34d94b9000069b4639","customerId":"673ffc23b0df5c00019b2a15","customer":{"id":null,"firstName":"JBwlhtWCZcx","lastName":"JBwlhtWCZcx
  03:36:22.924 [front-end] Order response: {"id":"673ffc36d94b9000069b463b","customerId":"673ffc22b0df5c00019b2a0f","customer":{"id":null,"firstName":"RZwVmAXqyw","lastName":"RZwVmAXqyw",
  03:36:28.175 [user] ts=2024-11-22T03:36:28.175702085Z caller=middlewares.go:46 method=Register username=jdyusgKH email=jdyusgKH@gmail.com took=1.118348ms
  03:36:29.995 [front-end] Order response: {"id":"673ffc3dd94b9000069b463f","customerId":"673ffc28b0df5c00019b2a2a","customer":{"id":null,"firstName":"EPLdHzYvXvFHM","lastName":"EPLdHzYvX
  03:36:32.752 [front-end] Order response: {"id":"673ffc40d94b9000069b4641","customerId":"673ffc2db0df5c00019b2a31","customer":{"id":null,"firstName":"mksMi","lastName":"mksMi","username"
  03:36:36.013 [user] ts=2024-11-22T03:36:36.013414587Z caller=middlewares.go:46 method=Register username=RdklDUW email=RdklDUW@gmail.com took=989.179µs
  03:36:38.653 [front-end] Posting Customer: {"username":"VkcTkinLLcVSBa","password":"jJGDezm","email":"VkcTkinLLcVSBa@gmail.com","firstName":"VkcTkinLLcVSBa","lastName":"VkcTkinLLcVSBa"}
  03:36:41.277 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc49d94b9000069b4648","customerId":"673ffc31b0df5c00019b2a3a","customer":{"id":null,"firstName":"ctiLBaUmBSm
  03:36:42.411 [front-end] Received response: "{\"firstName\":\"fFmtIFaBTd\",\"lastName\":\"fFmtIFaBTd\",\"username\":\"fFmtIFaBTd\",\"id\":\"673ffc39b0df5c00019b2a4e\",\"_links\":{\"addr
  03:36:44.919 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc4cd94b9000069b464e","customerId":"673ffc38b0df5c00019b2a4b","customer":{"id":null,"firstName":"tjxzlUHEHhd
  03:36:47.419 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc4fd94b9000069b4650","customerId":"673ffc3eb0df5c00019b2a66","customer":{"id":null,"firstName":"sqktCyWmQDf
  03:36:50.577 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc52d94b9000069b4654","customerId":"673ffc42b0df5c00019b2a71","customer":{"id":null,"firstName":"WoROyGlgncp
  03:36:51.959 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc53d94b9000069b4657","customerId":"673ffc3fb0df5c00019b2a6b","customer":{"id":null,"firstName":"AKQGGCgWNni

## p0231
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T07:54:08.104Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731916448104533800,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  07:54:07.337 [currencyservice] conversion request successful  (×13)
  07:54:07.401 [currencyservice] Getting supported currencies...  (×7)
All services, 30 seconds either side (sampled):
  07:53:38.499 [frontend] request started  (×331)
  07:53:38.501 [currencyservice] Getting supported currencies...  (×262)
  07:53:38.512 [currencyservice] conversion request successful  (×798)
  07:53:38.546 [adservice] received ad request (context_words=[])  (×41)
  07:53:39.058 [frontend] serving product page  (×140)
  07:53:39.090 [adservice] received ad request (context_words=[accessories])  (×34)
  07:53:39.098 [cartservice] AddItemAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58, productId=1YMWWN1N4O, quantity=8  (×42)
  07:53:39.132 [shippingservice] [GetQuote] received request  (×81)
  07:53:39.487 [adservice] received ad request (context_words=[footwear])  (×19)
  07:53:40.785 [adservice] received ad request (context_words=[kitchen])  (×43)
  07:53:41.262 [frontend] setting currency  (×27)
  07:53:44.116 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="USD"
  07:53:44.144 [paymentservice] Transaction processed: visa ending 6323 Amount: USD303.850000000
  07:53:44.147 [shippingservice] [ShipOrder] received request  (×8)
  07:53:44.150 [cartservice] EmptyCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×8)
  07:53:44.156 [emailservice] A request to send order confirmation email to jfuentes@example.org has been received.
  07:53:44.158 [frontend] order placed  (×8)
  07:53:45.760 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"5116","nanos":359297674},"credit_card":{"credit_card_number":"4948602056358
  07:53:45.772 [emailservice] A request to send order confirmation email to jamesflores@example.com has been received.
  07:53:48.898 [adservice] received ad request (context_words=[decor, home])  (×16)
  07:53:59.743 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"53879","nanos":607253734},"credit_card":{"credit_card_number":"402267578245  (×2)
  07:53:59.757 [emailservice] A request to send order confirmation email to marvinriley@example.net has been received.
  07:54:07.303 [recommendationservice] [Recv ListRecommendations] product_ids=['9SIQT8TOJO', '2ZYFJ3GM2N', 'OLJCESPC7Z', 'LS4PSXUNUM']  (×6)
  07:54:19.368 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="CAD"  (×4)
  07:54:19.449 [paymentservice] Transaction processed: visa ending 3395 Amount: CAD2908.817995574  (×4)
  07:54:19.462 [checkoutservice] failed to send order confirmation to "gcox@example.org": rpc error: code = Internal desc = Failed to serialize response!
  07:54:27.163 [checkoutservice] failed to send order confirmation to "vmiles@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:54:27.954 [checkoutservice] failed to send order confirmation to "campbellhunter@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:54:29.668 [checkoutservice] failed to send order confirmation to "danielwalker@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:54:35.499 [checkoutservice] failed to send order confirmation to "larrywells@example.com": rpc error: code = Internal desc = Failed to serialize response!

## p0250
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:05.172Z
```
{"timestamp":1732242485172316200,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Order: {\"customer\":\"http://user/customers/673fec20b0df5c00019af91e\",\"address\":\"http://user/addresses/673fec29b0df5c00019af940\",\"card\":\"http://user/cards/673fec29b0df5c00019af941\",\"items\":\"http://carts/carts/673fec20b0df5c00019af91e/items\"}"}
```
Same service, the 2 minutes before (oldest first):
  02:28:05.047 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×2)
  02:28:05.047 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec25b0df5c00019af930\",\"_links\":{\"  (×2)
  02:28:05.047 [front-end] [ undefined, undefined ]  (×2)
  02:28:05.047 [front-end] Posting Order: {"customer":"http://user/customers/673fec1db0df5c00019af90f","address":"http://user/addresses/673fec25b0df5c00019af92f","card":"http://user/cards
  02:28:05.062 [front-end] User cart deleted with status: 503
  02:28:05.065 [front-end] DELETE /cart 503 - ms - -
  02:28:05.071 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  02:28:05.078 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af952/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  02:28:05.097 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:05.097 [front-end] Order response: {"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:05.100 [front-end] POST /orders 500 - ms - -
  02:28:05.146 [front-end] POST /cart 500 72.021 ms - 64
  02:28:05.160 [front-end] Request received with body: {}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:05.166 [front-end] GET Request to: http://user/customers/673fec20b0df5c00019af91e/addresses  (×2)
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×32)
  02:28:03.118 [catalogue] ts=2024-11-22T02:28:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.040202ms  (×36)
  02:28:03.190 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af953/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×18)
  02:28:03.211 [user] ts=2024-11-22T02:28:03.211690554Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=1.207621ms  (×36)
  02:28:03.252 [front-end] POST /orders 500 - ms - -  (×30)
  02:28:03.410 [front-end] Carts merged.  (×31)
  02:28:04.929 [front-end] Posting Customer: {"username":"JGQXvUjPbFrtK","password":"HtglbTyNG","email":"JGQXvUjPbFrtK@gmail.com","firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPbFrtK"}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:06.800 [user] ts=2024-11-22T02:28:06.800234478Z caller=middlewares.go:46 method=Register username=oyShDJ email=oyShDJ@gmail.com took=993.111µs
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.197 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×4)
  02:28:16.205 [front-end] Received response: "{\"firstName\":\"WiHheQzgSpJzgy\",\"lastName\":\"WiHheQzgSpJzgy\",\"username\":\"WiHheQzgSpJzgy\",\"id\":\"673fec2db0df5c00019af952\",\"_lin
  02:28:17.879 [user] ts=2024-11-22T02:28:17.879034554Z caller=middlewares.go:46 method=Register username=QGHrdp email=QGHrdp@gmail.com took=1.008054ms
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:21.971 [user] ts=2024-11-22T02:28:21.971606392Z caller=middlewares.go:46 method=Register username=PDQejFz email=PDQejFz@gmail.com took=1.195014ms
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=1.213µs  (×4)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.819 [front-end] Received response: "{\"firstName\":\"KoWsmDtUqsE\",\"lastName\":\"KoWsmDtUqsE\",\"username\":\"KoWsmDtUqsE\",\"id\":\"673fec2cb0df5c00019af949\",\"_links\":{\"a
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:25.786 [shipping] 2024-11-22 02:28:25.786 INFO [shipping,fb98be28dae5ea9a,b566bc7933720160,false] 7 --- [p-nio-80-exec-6] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.957 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","l
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFr
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:27.463 [orders-db] {"t":{"$date":"2024-11-22T02:28:27.462+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: java.lang.RuntimeException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock) at com.google.commo
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×12)

## p0175
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:36:06.833Z
```
{"timestamp":1731911766833479400,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  06:36:05.020 [frontend] request started  (×7)
  06:36:05.020 [frontend] serving product page  (×7)
  06:36:05.058 [frontend] request complete  (×6)
All services, 30 seconds either side (sampled):
  06:35:37.163 [frontend] request started  (×339)
  06:35:37.171 [cartservice] GetCartAsync called with userId=adf41e5f-12f6-4c40-88a0-a1bcf421e416  (×273)
  06:35:37.195 [adservice] received ad request (context_words=[accessories])  (×27)
  06:35:37.385 [shippingservice] [GetQuote] received request  (×99)
  06:35:38.137 [frontend] home  (×37)
  06:35:38.345 [adservice] received ad request (context_words=[footwear])  (×19)
  06:35:38.390 [adservice] received ad request (context_words=[decor, home])  (×10)
  06:35:38.440 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"124524","nanos":964176016},"credit_card":{"credit_card_number":"43979579586  (×8)
  06:35:38.444 [shippingservice] [ShipOrder] received request  (×15)
  06:35:38.451 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 14  (×15)
  06:35:40.020 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', 'LS4PSXUNUM', '0PUK6V6EV0', '66VCHSJNUP']  (×5)
  06:35:40.186 [paymentservice] Transaction processed: visa ending 2367 Amount: TRY2486.395239285
  06:35:44.015 [checkoutservice] [PlaceOrder] user_id="0727db9d-83b9-44b7-acab-68a4f8f289c0" user_currency="EUR"  (×2)
  06:35:44.063 [checkoutservice] failed to send order confirmation to "tcurry@example.net": rpc error: code = Unavailable desc = no healthy upstream
  06:35:48.718 [checkoutservice] failed to send order confirmation to "adam68@example.net": rpc error: code = Unavailable desc = upstream connect error or disconnect/reset before headers. retri
  06:35:49.158 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"132","nanos":966426355},"credit_card":{"credit_card_number":"41921142078688  (×2)
  06:35:49.747 [emailservice] starting the email service in dummy mode.
  06:35:49.843 [emailservice] AttributeError: '_Server' object has no attribute 'Check'
  06:36:01.990 [checkoutservice] failed to send order confirmation to "susangross@example.org": rpc error: code = Unavailable desc = no healthy upstream
  06:36:10.064 [redis] 1:M 18 Nov 2024 06:36:10.064 * Background saving started by pid 65
  06:36:10.166 [redis] 1:M 18 Nov 2024 06:36:10.166 * Background saving terminated with success
  06:36:17.933 [checkoutservice] failed to send order confirmation to "johnsonjames@example.net": rpc error: code = Unavailable desc = no healthy upstream
  06:36:19.286 [paymentservice] Transaction processed: visa ending 5818 Amount: USD710.310000000  (×2)
  06:36:26.525 [checkoutservice] failed to send order confirmation to "moralesnicolas@example.com": rpc error: code = Unavailable desc = no healthy upstream

## p0782
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service shipping, 2024-11-24T13:43:42.061Z
```
{"timestamp":1732455822061891600,"container_name":"shipping","pod_name":"shipping-58b65f576-mh54k","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Adding shipment to queue..."}
```
Same service, the 2 minutes before (oldest first):
  13:43:24.210 [shipping] Adding shipment to queue...  (×20)
All services, 30 seconds either side (sampled):
  13:43:12.269 [catalogue] ts=2024-11-24T13:43:12Z caller=logging.go:85 method=Health result=2 took=27.355µs  (×40)
  13:43:12.442 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×8)
  13:43:12.481 [front-end] POST /cart 201 - ms - -  (×63)
  13:43:12.596 [orders] 2024-11-24 13:43:12.595 INFO [orders,30e1f9e2b884a0dc,abca45f73c30e297,false] 7 --- [p-nio-80-exec-4] w.w.s.o.controllers.OrdersController : Received payment re  (×51)
  13:43:13.114 [front-end] Posting Customer: {"username":"fHZwmbuk","password":"iRxdae","email":"fHZwmbuk@gmail.com","firstName":"fHZwmbuk","lastName":"fHZwmbuk"}
  13:43:14.009 [orders] 2024-11-24 13:43:14.009 INFO [orders,81d4c02c2de7af0a,48cad84e45fe6fff,false] 7 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×17)
  13:43:15.410 [front-end] Received response: "{\"firstName\":\"YikyDeyqZjAfy\",\"lastName\":\"YikyDeyqZjAfy\",\"username\":\"YikyDeyqZjAfy\",\"id\":\"67432d62f6d8750001620598\",\"_links\
  13:43:16.871 [front-end] POST to carts: http://carts/carts/67432d6bf6d87500016205b9/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}  (×31)
  13:43:17.926 [front-end] Order response: {"id":"67432d75c4380300078a4982","customerId":"67432d5ff6d8750001620591","customer":{"id":null,"firstName":"janhzQAsbgjAGCc","lastName":"janhzQA
  13:43:22.050 [front-end] Received response: "{\"firstName\":\"hyUcTKkFFxil\",\"lastName\":\"hyUcTKkFFxil\",\"username\":\"hyUcTKkFFxil\",\"id\":\"67432d61f6d8750001620597\",\"_links\":{
  13:43:24.327 [user] ts=2024-11-24T13:43:24.327467592Z caller=middlewares.go:46 method=Register username=MAVDALBj email=MAVDALBj@gmail.com took=1.908133ms
  13:43:26.667 [front-end] Order response: {"id":"67432d7ec4380300078a4988","customerId":"67432d6df6d87500016205bb","customer":{"id":null,"firstName":"KMtorhz","lastName":"KMtorhz","usern
  13:43:29.461 [user] ts=2024-11-24T13:43:29.461078931Z caller=middlewares.go:46 method=Register username=pdGbk email=pdGbk@gmail.com took=1.926798ms
  13:43:34.571 [front-end] Order response: {"statusCode":201,"body":{"id":"67432d86c4380300078a498d","customerId":"67432d78f6d87500016205d9","customer":{"id":null,"firstName":"wIsBites","
  13:43:37.568 [front-end] Order response: {"statusCode":201,"body":{"id":"67432d89c4380300078a4991","customerId":"67432d7bf6d87500016205e5","customer":{"id":null,"firstName":"ubZVnZvOz",
  13:43:38.689 [front-end] Order response: {"statusCode":201,"body":{"id":"67432d8ac4380300078a4995","customerId":"67432d70f6d87500016205c2","customer":{"id":null,"firstName":"nahdIZQlBC"
  13:43:41.761 [front-end] Posting Customer: {"username":"FscbswrMi","password":"GVOZM","email":"FscbswrMi@gmail.com","firstName":"FscbswrMi","lastName":"FscbswrMi"}
  13:43:42.515 [front-end] Posting Customer: {"username":"KTlOSZt","password":"gBBrzorqqO","email":"KTlOSZt@gmail.com","firstName":"KTlOSZt","lastName":"KTlOSZt"}
  13:43:45.820 [catalogue] ts=2024-11-24T13:43:45Z caller=logging.go:62 method=Get id=510a0d7e-8e83-4193-b483-e27e09ddc34d sock=510a0d7e-8e83-4193-b483-e27e09ddc34d err=null took=5.1066ms
  13:43:48.603 [front-end] Order response: {"statusCode":201,"body":{"id":"67432d94c4380300078a49a0","customerId":"67432d7ff6d87500016205f6","customer":{"id":null,"firstName":"ShcizUMaQMe
  13:43:51.276 [front-end] Posting Customer: {"username":"YTNurOuf","password":"DjHMFsO","email":"YTNurOuf@gmail.com","firstName":"YTNurOuf","lastName":"YTNurOuf"}
  13:43:55.256 [front-end] Order response: {"id":"67432d9bc4380300078a49a3","customerId":"67432d84f6d875000162060b","customer":{"id":null,"firstName":"IEvNpylNoYREk","lastName":"IEvNpylNo
  13:43:59.419 [front-end] Order response: {"id":"67432d9fc4380300078a49a6","customerId":"67432d87f6d8750001620615","customer":{"id":null,"firstName":"mRXdUwtlGO","lastName":"mRXdUwtlGO",
  13:44:02.108 [front-end] Received response: "{\"firstName\":\"oPLiAGKNlVdYA\",\"lastName\":\"oPLiAGKNlVdYA\",\"username\":\"oPLiAGKNlVdYA\",\"id\":\"67432d8ef6d8750001620625\",\"_links\
  13:44:03.879 [front-end] Received response: "{\"firstName\":\"YViuirLYGm\",\"lastName\":\"YViuirLYGm\",\"username\":\"YViuirLYGm\",\"id\":\"67432d8ef6d8750001620624\",\"_links\":{\"addr
  13:44:06.164 [front-end] Order response: {"statusCode":201,"body":{"id":"67432da6c4380300078a49af","customerId":"67432d98f6d8750001620642","customer":{"id":null,"firstName":"jgYpANk","l
  13:44:08.490 [front-end] Posting Customer: {"username":"aTImkGtXviPILz","password":"NzCpH","email":"aTImkGtXviPILz@gmail.com","firstName":"aTImkGtXviPILz","lastName":"aTImkGtXviPILz"}
  13:44:10.707 [front-end] Received response: "{\"firstName\":\"ZNwnTPYQXadpmYU\",\"lastName\":\"ZNwnTPYQXadpmYU\",\"username\":\"ZNwnTPYQXadpmYU\",\"id\":\"67432d96f6d8750001620639\",\"_

## p0374
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service shipping, 2024-11-22T03:40:23.178Z
```
{"timestamp":1732246823178981400,"container_name":"shipping","pod_name":"shipping-58b65f576-pwmz6","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"Adding shipment to queue..."}
```
Same service, the 2 minutes before (oldest first):
  03:40:05.518 [shipping] Adding shipment to queue...  (×20)
All services, 30 seconds either side (sampled):
  03:39:53.759 [front-end] Posting Customer: {"username":"MtNrOMrOXM","password":"OZuDW","email":"MtNrOMrOXM@gmail.com","firstName":"MtNrOMrOXM","lastName":"MtNrOMrOXM"}
  03:39:54.094 [user] ts=2024-11-22T03:39:54.093963092Z caller=middlewares.go:157 method=Health result=2 took=749.536µs  (×38)
  03:39:54.805 [user] ts=2024-11-22T03:39:54.805658067Z caller=middlewares.go:134 method=GetCards id=673ffcfcb0df5c00019b2cb2 result=1 took=804.392µs  (×50)
  03:39:54.827 [queue-master] 2024-11-22 03:39:54.827 ERROR 6 --- [ool-6-thread-23] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×49)
  03:39:55.512 [front-end] Order response: {"id":"673ffd0bd94b9000069b46fc","customerId":"673ffcf6b0df5c00019b2c96","customer":{"id":null,"firstName":"MMmvJm","lastName":"MMmvJm","usernam
  03:39:57.445 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd0dd94b9000069b46ff","customerId":"673ffcf5b0df5c00019b2c93","customer":{"id":null,"firstName":"zfvucUwUah"
  03:39:57.635 [catalogue] ts=2024-11-22T03:39:57Z caller=logging.go:62 method=Get id=837ab141-399e-4c1f-9abc-bace40296bac sock=837ab141-399e-4c1f-9abc-bace40296bac err=null took=5.777808  (×52)
  03:39:58.308 [carts] 2024-11-22 03:39:58.308 INFO [carts,11501e383527d81e,2e58853744f60b1d,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.controllers.ItemsController : Did not find item.  (×25)
  03:40:00.254 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×10)
  03:40:05.524 [front-end] Order response: {"id":"673ffd15d94b9000069b4702","customerId":"673ffd0ab0df5c00019b2cd9","customer":{"id":null,"firstName":"BdIjndiKvjyPn","lastName":"BdIjndiKv
  03:40:07.592 [user] ts=2024-11-22T03:40:07.59181125Z caller=middlewares.go:46 method=Register username=YclTA email=YclTA@gmail.com took=1.104919ms
  03:40:09.254 [front-end] Order response: {"id":"673ffd19d94b9000069b4707","customerId":"673ffd03b0df5c00019b2cc0","customer":{"id":null,"firstName":"yQSpsaJBWTF","lastName":"yQSpsaJBWTF
  03:40:11.852 [front-end] Posting Customer: {"username":"jIdsT","password":"EGZBzhUuHN","email":"jIdsT@gmail.com","firstName":"jIdsT","lastName":"jIdsT"}
  03:40:14.701 [front-end] Received response: "{\"firstName\":\"jqPTxwV\",\"lastName\":\"jqPTxwV\",\"username\":\"jqPTxwV\",\"id\":\"673ffd06b0df5c00019b2ccb\",\"_links\":{\"addresses\":{
  03:40:16.247 [front-end] Order response: {"id":"673ffd20d94b9000069b470e","customerId":"673ffd11b0df5c00019b2cf0","customer":{"id":null,"firstName":"EFklGacZxjzz","lastName":"EFklGacZxj
  03:40:19.225 [front-end] Received response: "{\"firstName\":\"lSgKzNLxQbojsEV\",\"lastName\":\"lSgKzNLxQbojsEV\",\"username\":\"lSgKzNLxQbojsEV\",\"id\":\"673ffd0ab0df5c00019b2cda\",\"_
  03:40:20.713 [front-end] Posting Customer: {"username":"aLRiojBnGBIruG","password":"wcTrpq","email":"aLRiojBnGBIruG@gmail.com","firstName":"aLRiojBnGBIruG","lastName":"aLRiojBnGBIruG"}
  03:40:23.182 [queue-master] 2024-11-22 03:40:23.182 ERROR 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×9)
  03:40:25.340 [user] ts=2024-11-22T03:40:25.340262974Z caller=middlewares.go:46 method=Register username=sMpzhVgfV email=sMpzhVgfV@gmail.com took=1.017871ms
  03:40:26.507 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd2ad94b9000069b4719","customerId":"673ffd1bb0df5c00019b2d07","customer":{"id":null,"firstName":"FFzOIKpJqGT
  03:40:31.340 [user] ts=2024-11-22T03:40:31.340166049Z caller=middlewares.go:46 method=Register username=JKcBDLiu email=JKcBDLiu@gmail.com took=1.059034ms
  03:40:34.219 [user] ts=2024-11-22T03:40:34.219185897Z caller=middlewares.go:46 method=Register username=sITZbLr email=sITZbLr@gmail.com took=1.005752ms
  03:40:36.063 [front-end] Order response: {"id":"673ffd34d94b9000069b4721","customerId":"673ffd1fb0df5c00019b2d1a","customer":{"id":null,"firstName":"RWQtQw","lastName":"RWQtQw","usernam
  03:40:38.811 [front-end] Received response: "{\"firstName\":\"wDQlrkYxpEcQ\",\"lastName\":\"wDQlrkYxpEcQ\",\"username\":\"wDQlrkYxpEcQ\",\"id\":\"673ffd23b0df5c00019b2d23\",\"_links\":{
  03:40:41.845 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd39d94b9000069b4727","customerId":"673ffd2ab0df5c00019b2d3c","customer":{"id":null,"firstName":"BVmGZaaWBXg
  03:40:42.845 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd3ad94b9000069b4729","customerId":"673ffd28b0df5c00019b2d31","customer":{"id":null,"firstName":"LiUKqRolHOa
  03:40:46.314 [front-end] Received response: "{\"firstName\":\"NUHZhd\",\"lastName\":\"NUHZhd\",\"username\":\"NUHZhd\",\"id\":\"673ffd2ab0df5c00019b2d39\",\"_links\":{\"addresses\":{\"h
  03:40:47.191 [front-end] Posting Customer: {"username":"goLVOTOYUJxzrs","password":"YFkJSZ","email":"goLVOTOYUJxzrs@gmail.com","firstName":"goLVOTOYUJxzrs","lastName":"goLVOTOYUJxzrs"}
  03:40:49.358 [front-end] Posting Customer: {"username":"jLUtWGWaIeV","password":"gwZxHMriG","email":"jLUtWGWaIeV@gmail.com","firstName":"jLUtWGWaIeV","lastName":"jLUtWGWaIeV"}

## p0529
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T11:00:23.769Z
```
{"timestamp":1732359623769278500,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T11:00:23.769148763Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6741b5bea437380001df548e took=3.975413ms"}
```
Same service, the 2 minutes before (oldest first):
  11:00:17.449 [user] ts=2024-11-23T11:00:17.449375396Z caller=middlewares.go:46 method=Register username=EnPYTBJddXxq email=EnPYTBJddXxq@gmail.com took=1.969654ms  (×3)
  11:00:19.819 [user] ts=2024-11-23T11:00:19.819553171Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=6741b5bda437380001df548d took=3.857918ms  (×5)
  11:00:19.848 [user] ts=2024-11-23T11:00:19.848245192Z caller=middlewares.go:157 method=Health result=2 took=1.946158ms  (×4)
  11:00:19.886 [user] ts=2024-11-23T11:00:19.886238131Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6741b5bda437380001df548d took=4.205884ms  (×4)
  11:00:20.452 [user] ts=2024-11-23T11:00:20.452188204Z caller=middlewares.go:46 method=Register username=FdLurxK email=FdLurxK@gmail.com took=2.471721ms
  11:00:20.719 [user] ts=2024-11-23T11:00:20.718934891Z caller=middlewares.go:46 method=Register username=eciSh email=eciSh@gmail.com took=2.708961ms
  11:00:21.861 [user] ts=2024-11-23T11:00:21.861320645Z caller=middlewares.go:46 method=Register username=VaKnbsYM email=VaKnbsYM@gmail.com took=2.904186ms
  11:00:22.451 [user] ts=2024-11-23T11:00:22.451389801Z caller=middlewares.go:46 method=Register username=RQdkCu email=RQdkCu@gmail.com took=2.404383ms
All services, 30 seconds either side (sampled):
  10:59:54.383 [catalogue] ts=2024-11-23T10:59:54Z caller=logging.go:85 method=Health result=2 took=31.088µs  (×40)
  11:00:11.544 [front-end] Posting Customer: {"username":"RupAdllGjrdNv","password":"zJBnIlEK","email":"RupAdllGjrdNv@gmail.com","firstName":"RupAdllGjrdNv","lastName":"RupAdllGjrdNv"}
  11:00:11.565 [carts] 2024-11-23 11:00:11.564 INFO [carts,5a2e21a486490bc1,97896900cee9f8fe,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.CartsController : Merge carts reques  (×17)
  11:00:12.740 [front-end] Posting Customer: {"username":"hYeBtEGlGq","password":"fSKDYUx","email":"hYeBtEGlGq@gmail.com","firstName":"hYeBtEGlGq","lastName":"hYeBtEGlGq"}
  11:00:14.745 [front-end] Posting Customer: {"username":"XNHqPsYlIlUw","password":"brpClEgE","email":"XNHqPsYlIlUw@gmail.com","firstName":"XNHqPsYlIlUw","lastName":"XNHqPsYlIlUw"}
  11:00:16.620 [front-end] POST /addresses 200 - ms - -  (×18)
  11:00:16.717 [front-end] User cart deleted with status: 202  (×17)
  11:00:16.737 [front-end] POST to carts: http://carts/carts/6741b5bba437380001df548b/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×8)
  11:00:16.816 [user] ts=2024-11-23T11:00:16.816230287Z caller=middlewares.go:46 method=Register username=ZYyOEosw email=ZYyOEosw@gmail.com took=2.034356ms
  11:00:19.981 [front-end] POST to carts: http://carts/carts/6741b5bda437380001df548d/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}  (×9)
  11:00:20.710 [front-end] Posting Customer: {"username":"eciSh","password":"ncDSTD","email":"eciSh@gmail.com","firstName":"eciSh","lastName":"eciSh"}
  11:00:21.686 [front-end] Posting Customer: {"username":"AtPqbXfAZp","password":"EpoZfUN","email":"AtPqbXfAZp@gmail.com","firstName":"AtPqbXfAZp","lastName":"AtPqbXfAZp"}
  11:00:23.865 [catalogue] ts=2024-11-23T11:00:23Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=4.81605m
  11:00:24.738 [front-end] Posting Customer: {"username":"HOLUtFoSuMcUtKu","password":"taAJbEDhs","email":"HOLUtFoSuMcUtKu@gmail.com","firstName":"HOLUtFoSuMcUtKu","lastName":"HOLUtFoSuMc
  11:00:26.495 [orders-db] {"t":{"$date":"2024-11-23T11:00:26.495+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235962
  11:00:27.232 [user] ts=2024-11-23T11:00:27.232650455Z caller=middlewares.go:46 method=Register username=ZloLZze email=ZloLZze@gmail.com took=3.095882ms
  11:00:28.716 [user] ts=2024-11-23T11:00:28.715850808Z caller=middlewares.go:46 method=Register username=LomuEmw email=LomuEmw@gmail.com took=2.094766ms
  11:00:29.613 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  11:00:31.625 [front-end] Posting Customer: {"username":"rbqXF","password":"pcPTGVfA","email":"rbqXF@gmail.com","firstName":"rbqXF","lastName":"rbqXF"}
  11:00:32.066 [front-end] GET Request to: http://user/customers/6741b5bda437380001df548d/addresses  (×4)
  11:00:32.083 [front-end] Received response: "{\"firstName\":\"XNHqPsYlIlUw\",\"lastName\":\"XNHqPsYlIlUw\",\"username\":\"XNHqPsYlIlUw\",\"id\":\"6741b5bea437380001df548f\",\"_links\":{
  11:00:32.150 [orders] 2024-11-23 11:00:32.150 INFO [orders,5a6a0af7afe1a8a3,d3020c3723661a9c,false] 7 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Received payment re
  11:00:32.160 [queue-master] 2024-11-23 11:00:32.160 INFO 7 --- [ool-6-thread-23] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×6)
  11:00:32.165 [front-end] Order response: undefined
  11:00:32.178 [front-end] npm timing command:run-script Completed in 44217ms
  11:00:32.180 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!

## p0123
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:18:18.739Z
```
{"timestamp":1731907098739793000,"container_name":"adservice","pod_name":"adservice-574c5fd7b4-tmkhn","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Tracing enabled but temporarily unavailable"}
```
Same service, the 2 minutes before (oldest first):
  05:17:39.847 [adservice] received ad request (context_words=[])
  05:17:39.858 [adservice] received ad request (context_words=[kitchen])
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:40.213 [adservice] *** server shut down
  05:17:43.747 [adservice] AdService starting.  (×3)
  05:17:43.839 [adservice] Stats enabled, but temporarily unavailable  (×3)
  05:17:43.840 [adservice] Tracing enabled but temporarily unavailable  (×2)
  05:17:43.841 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.  (×2)
  05:17:43.842 [adservice] Tracing enabled - Stackdriver exporter initialized.  (×2)
  05:17:45.449 [adservice] Exception in thread "main" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000 at io.grpc.netty.NettyServer.start(NettyServer.java:333) at io.g  (×2)
  05:17:45.450 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
All services, 30 seconds either side (sampled):
  05:17:49.359 [frontend] request started  (×291)
  05:17:49.368 [cartservice] GetCartAsync called with userId=adf41e5f-12f6-4c40-88a0-a1bcf421e416  (×245)
  05:17:49.388 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 4  (×173)
  05:17:49.497 [frontend] adding to cart  (×28)
  05:17:49.541 [shippingservice] [GetQuote] received request  (×73)
  05:17:49.561 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="CAD"
  05:17:49.589 [checkoutservice] payment went through (transaction_id: b8ee51d3-3b17-4fba-b69a-4f014013c8cc)  (×8)
  05:17:49.595 [cartservice] EmptyCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×8)
  05:17:49.604 [frontend] order placed  (×8)
  05:17:52.100 [frontend] ENV_PLATFORM is: aws  (×34)
  05:17:53.543 [adservice] AdService starting.  (×2)
  05:17:53.544 [adservice] Tracing enabled - Stackdriver exporter initialized.  (×2)
  05:17:55.239 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="EUR"  (×2)
  05:17:55.276 [emailservice] A request to send order confirmation email to alopez@example.org has been received.
  05:18:02.284 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"725","nanos":428863340},"credit_card":{"credit_card_number":"47716610325023  (×3)
  05:18:02.298 [checkoutservice] order confirmation email sent to "caseyhoward@example.com"
  05:18:22.550 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"1521","nanos":300176901},"credit_card":{"credit_card_number":"4909740041071
  05:18:22.564 [checkoutservice] order confirmation email sent to "janetbrown@example.org"
  05:18:25.981 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"106183","nanos":826626688},"credit_card":{"credit_card_number":"48642226849  (×2)
  05:18:25.994 [checkoutservice] order confirmation email sent to "bradycarla@example.net"
  05:18:26.960 [paymentservice] UnacceptedCreditCard [Error]: Sorry, we cannot process visa_electron credit cards. Only VISA or MasterCard is accepted. at charge (/usr/src/app/charge.js:74:68)
  05:18:32.594 [emailservice] A request to send order confirmation email to tashawolf@example.org has been received.
  05:18:35.671 [checkoutservice] order confirmation email sent to "daniel24@example.org"

## p0089
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice2, 2021-08-13T15:56:53.264Z
```
{"service":"redisservice2","message":"2021-08-13 15:56:53,264 | INFO | 0.0.0.2 | 172.17.0.4 | redisservice2 | a9ef87d0c98cc582 | redis读取信息成功, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  15:56:47.677 [redisservice2] INFO redis write success  (×8)
  15:56:47.949 [redisservice2] INFO service accept, status_code: 200  (×3)
  15:56:48.450 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×4)
  15:56:49.673 [redisservice2] INFO redis读取信息成功, status_code: 200  (×5)
All services, 30 seconds either side (sampled):
  15:56:23.264 [webservice2] INFO uuid: f3e5b7e2-fc0b-11eb-8b36-0242ac110004 write redis successfully  (×44)
  15:56:23.374 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×51)
  15:56:23.440 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×51)
  15:56:23.598 [dbservice2] INFO query = select passwards from username_table where user_name='NGJTlZWq'  (×44)
  15:56:24.006 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'f464750a-fc0b-11eb-b46b-0242ac110003', 'value': '', 'ex': 10}  (×43)
  15:56:25.371 [mobservice2] INFO info f4fc4baa-fc0b-11eb-afc3-0242ac110003:rxiVPwZL write success
  15:56:25.932 [dbservice2] INFO f4fc4baa-fc0b-11eb-afc3-0242ac110003-rxiVPwZL-#kN4x}e6EY-J token generate success token=MTYyODg0MTM4NS45MzE4MjQ6ZjRmYzRiYWEtZmMwYi0xMWViLWFmYzMtMDI0MmFjMTE
  15:56:26.387 [mobservice2] INFO info f5997524-fc0b-11eb-a8cc-0242ac110004:elIAhJnr write success
  15:56:27.096 [dbservice1] INFO f5a2dcd6-fc0b-11eb-b059-0242ac110003-nuXjsHUb-@8.+B_ezYn70 token generate success token=MTYyODg0MTM4Ny4wOTYxMjUxOmY1YTJkY2Q2LWZjMGItMTFlYi1iMDU5LTAyNDJhYzE
  15:56:29.818 [dbservice2] INFO f77e4284-fc0b-11eb-adcd-0242ac110003-hCIZuDLt-F^*JxWUs&YgO token generate success token=MTYyODg0MTM4OS44MTc0OTU6Zjc3ZTQyODQtZmMwYi0xMWViLWFkY2QtMDI0MmFjMTE  (×2)
  15:56:32.332 [mobservice1] INFO info f91c142c-fc0b-11eb-8968-0242ac110003:DjXaKYNR write success
  15:56:35.163 [dbservice2] INFO fa97580c-fc0b-11eb-ab8e-0242ac110003-bCtvogcT-z9vf?iYtU=2( token generate success token=MTYyODg0MTM5NS4xNjI2OTk3OmZhOTc1ODBjLWZjMGItMTFlYi1hYjhlLTAyNDJhYzE
  15:56:38.128 [mobservice2] INFO info fc8cf644-fc0b-11eb-8f86-0242ac110004:RVxXNljY write success
  15:56:40.960 [dbservice2] INFO fe15ba50-fc0b-11eb-ad63-0242ac110004-jSevQlNq-y=u7{-jE?dDK token generate success token=MTYyODg0MTQwMC45NjAxODM0OmZlMTViYTUwLWZjMGItMTFlYi1hZDYzLTAyNDJhYzE
  15:56:43.763 [dbservice2] INFO ffa6e24a-fc0b-11eb-958f-0242ac110003-oJvuskDK-ce_Fo%vzuUK< token generate success token=MTYyODg0MTQwMy43NjMwOTg1OmZmYTZlMjRhLWZjMGItMTFlYi05NThmLTAyNDJhYzE
  15:56:46.451 [dbservice1] INFO 014deecc-fc0c-11eb-97d8-0242ac110003-xMrHpLuv-.yKokf@{mjrC token generate success token=MTYyODg0MTQwNi40NTEyMTM6MDE0ZGVlY2MtZmMwYy0xMWViLTk3ZDgtMDI0MmFjMTE
  15:56:49.153 [dbservice2] INFO 02d164c2-fc0c-11eb-9860-0242ac110004-FjQZnIyb-N?AQYWzUJSXj token generate success token=MTYyODg0MTQwOS4xNTI2ODU0OjAyZDE2NGMyLWZjMGMtMTFlYi05ODYwLTAyNDJhYzE
  15:56:52.376 [dbservice1] INFO 04bb9a50-fc0c-11eb-ac83-0242ac110004-PVFHnXol-4ksJ2?fe(UZ- token generate success token=MTYyODg0MTQxMi4zNzU5NTc3OjA0YmI5YTUwLWZjMGMtMTFlYi1hYzgzLTAyNDJhYzE
  15:56:54.849 [dbservice2] INFO 0653b032-fc0c-11eb-9b66-0242ac110004-QYryCKLk-@51x7Dd$-e=8 token generate success token=MTYyODg0MTQxNC44NDg5MTMyOjA2NTNiMDMyLWZjMGMtMTFlYi05YjY2LTAyNDJhYzE
  15:56:57.306 [dbservice1] INFO 07d53796-fc0c-11eb-be0a-0242ac110003-dULDJpwo--J=t5_1H_3.l token generate success token=MTYyODg0MTQxNy4zMDU3NjU0OjA3ZDUzNzk2LWZjMGMtMTFlYi1iZTBhLTAyNDJhYzE
  15:57:00.504 [mobservice1] INFO info 09f059ca-fc0c-11eb-8a2f-0242ac110004:GRzjnWha write success
  15:57:03.308 [dbservice2] INFO 0b5cc988-fc0c-11eb-9340-0242ac110004-lkNrGYTL-S$afkB0(o_gn token generate success token=MTYyODg0MTQyMy4zMDgxMTc0OjBiNWNjOTg4LWZjMGMtMTFlYi05MzQwLTAyNDJhYzE
  15:57:05.775 [dbservice2] INFO 0cdd1808-fc0c-11eb-81af-0242ac110003-HkLmPgZU-^/Kv(%ND.k0T token generate success token=MTYyODg0MTQyNS43NzQ1ODA3OjBjZGQxODA4LWZjMGMtMTFlYi04MWFmLTAyNDJhYzE
  15:57:08.251 [dbservice1] INFO 0e567bac-fc0c-11eb-939e-0242ac110004-bTPjsUVJ-/OMn<NHZb.me token generate success token=MTYyODg0MTQyOC4yNTEwNTQzOjBlNTY3YmFjLWZjMGMtMTFlYi05MzllLTAyNDJhYzE
  15:57:10.956 [dbservice1] INFO 0ff2f5a8-fc0c-11eb-92dc-0242ac110004-CxaURntJ-FQ4_E#@RDnS. token generate success token=MTYyODg0MTQzMC45NTU5MjgzOjBmZjJmNWE4LWZjMGMtMTFlYi05MmRjLTAyNDJhYzE
  15:57:15.297 [dbservice1] INFO 129290ac-fc0c-11eb-b319-0242ac110003-UEASdwYn-lX/Z%YE&xQ5: token generate success token=MTYyODg0MTQzNS4yOTY5NTgyOjEyOTI5MGFjLWZjMGMtMTFlYi1iMzE5LTAyNDJhYzE
  15:57:18.132 [dbservice2] INFO 141a9442-fc0c-11eb-88cd-0242ac110003-FGqxBRpZ-}9s_LQ?u>hzS token generate success token=MTYyODg0MTQzOC4xMzI0MjMyOjE0MWE5NDQyLWZjMGMtMTFlYi04OGNkLTAyNDJhYzE
  15:57:21.081 [dbservice2] INFO 15b215fa-fc0c-11eb-b24a-0242ac110004-zwDGqUsI-8E$)(fg/C-MF token generate success token=MTYyODg0MTQ0MS4wODE1MTk6MTViMjE1ZmEtZmMwYy0xMWViLWIyNGEtMDI0MmFjMTE

## p0376
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:41:39.223Z
```
{"timestamp":1732246899223633200,"container_name":"carts","pod_name":"carts-6cdcbc6cd7-bswq8","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:41:39.223  INFO [carts,01deac4589851efe,a3e01a7525226122,false] 7 --- [-nio-80-exec-12] w.w.s.cart.cart.CartContentsResource     : Adding for user: Cart{id='673ffd732f1cab0007fac945', customerId='673ffd6cb0df5c00019b2e04', items=[]}, Item{id='673ffd732f1cab0007fac946', itemId='d3588630-ad8e-49df-bbd7-3167f7efb246', quantity=1, unitPrice=10.99}"}
```
Same service, the 2 minutes before (oldest first):
  03:41:33.744 [carts] 2024-11-22 03:41:33.743 INFO [carts,d32a2a8bcf89891c,ea45bfa105de23ab,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×5)
  03:41:34.122 [carts] 2024-11-22 03:41:34.122 INFO [carts,05e35ee6318b085c,3b9eaea51a0b5ef6,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.controllers.CartsController : Merge carts reques  (×4)
  03:41:34.350 [carts] 2024-11-22 03:41:34.350 INFO [carts,ca61e18c271eb079,903ec7a1fa936f35,false] 7 --- [-nio-80-exec-12] w.w.s.cart.controllers.ItemsController : Did not find item.  (×5)
  03:41:34.358 [carts] 2024-11-22 03:41:34.357 INFO [carts,ca61e18c271eb079,903ec7a1fa936f35,false] 7 --- [-nio-80-exec-12] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)
  03:41:38.796 [carts] 2024-11-22 03:41:38.796 INFO [carts,d5309688c0f8b9aa,88ac18f7d04f106d,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.controllers.ItemsController : Did not find item.
  03:41:38.804 [carts] 2024-11-22 03:41:38.804 INFO [carts,d5309688c0f8b9aa,88ac18f7d04f106d,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.cart.CartContentsResource : Adding for user: Car
All services, 30 seconds either side (sampled):
  03:41:09.262 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffd4db0df5c00019b2daa"}  (×61)
  03:41:09.418 [front-end] POST to carts: http://carts/carts/673ffd4db0df5c00019b2daa/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}  (×24)
  03:41:09.629 [front-end] Posting Order: {"customer":"http://user/customers/673ffd41b0df5c00019b2d7e","address":"http://user/addresses/673ffd46b0df5c00019b2d8e","card":"http://user/cards  (×63)
  03:41:09.657 [queue-master] 2024-11-22 03:41:09.657 ERROR 6 --- [ool-6-thread-46] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×46)
  03:41:10.438 [user] ts=2024-11-22T03:41:10.438219874Z caller=middlewares.go:104 method=GetAddresses id=673ffd45b0df5c00019b2d88 result=1 took=911.213µs  (×44)
  03:41:11.531 [front-end] Received response: "{\"firstName\":\"ySjyQlrYPeogmav\",\"lastName\":\"ySjyQlrYPeogmav\",\"username\":\"ySjyQlrYPeogmav\",\"id\":\"673ffd43b0df5c00019b2d83\",\"_
  03:41:13.404 [front-end] Merging carts for customer id: 673ffd59b0df5c00019b2dce and session id: irFyIK4QMbggxgJuip2BjfVckHvysNYh  (×58)
  03:41:13.592 [queue-master] 2024-11-22 03:41:13.592 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×33)
  03:41:16.348 [front-end] Received response: "{\"firstName\":\"sPqiURrxX\",\"lastName\":\"sPqiURrxX\",\"username\":\"sPqiURrxX\",\"id\":\"673ffd49b0df5c00019b2d9a\",\"_links\":{\"address
  03:41:17.479 [front-end] Received response: "{\"firstName\":\"ovQpp\",\"lastName\":\"ovQpp\",\"username\":\"ovQpp\",\"id\":\"673ffd4db0df5c00019b2daa\",\"_links\":{\"addresses\":{\"href
  03:41:19.278 [front-end] Posting Customer: {"username":"RWMsckgrRQQenew","password":"hXCEizriy","email":"RWMsckgrRQQenew@gmail.com","firstName":"RWMsckgrRQQenew","lastName":"RWMsckgrRQQ
  03:41:22.571 [front-end] Received response: "{\"firstName\":\"ctQSXUnuKjxCpou\",\"lastName\":\"ctQSXUnuKjxCpou\",\"username\":\"ctQSXUnuKjxCpou\",\"id\":\"673ffd4eb0df5c00019b2dac\",\"_
  03:41:23.729 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd63d94b9000069b4753","customerId":"673ffd53b0df5c00019b2dbc","customer":{"id":null,"firstName":"UINMbgLrMtl
  03:41:26.843 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd66d94b9000069b4755","customerId":"673ffd52b0df5c00019b2dbb","customer":{"id":null,"firstName":"dAwkeqSYZKz
  03:41:28.270 [front-end] Order response: {"id":"673ffd68d94b9000069b4758","customerId":"673ffd53b0df5c00019b2dbd","customer":{"id":null,"firstName":"ZAojCaSGE","lastName":"ZAojCaSGE","u
  03:41:30.991 [front-end] Received response: "{\"firstName\":\"VzxDDmBATRm\",\"lastName\":\"VzxDDmBATRm\",\"username\":\"VzxDDmBATRm\",\"id\":\"673ffd5bb0df5c00019b2dd2\",\"_links\":{\"a
  03:41:34.188 [front-end] Received response: "{\"firstName\":\"hOjQLav\",\"lastName\":\"hOjQLav\",\"username\":\"hOjQLav\",\"id\":\"673ffd5cb0df5c00019b2dd6\",\"_links\":{\"addresses\":{
  03:41:38.327 [front-end] Order response: {"id":"673ffd72d94b9000069b475d","customerId":"673ffd5ab0df5c00019b2dcf","customer":{"id":null,"firstName":"MWwbuljCiaMqwi","lastName":"MWwbuljC
  03:41:40.404 [front-end] Posting Customer: {"username":"msDyrdsbyomN","password":"gzXuLQa","email":"msDyrdsbyomN@gmail.com","firstName":"msDyrdsbyomN","lastName":"msDyrdsbyomN"}
  03:41:43.279 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd77d94b9000069b4762","customerId":"673ffd69b0df5c00019b2df5","customer":{"id":null,"firstName":"YiTmRDOlmlt
  03:41:46.245 [front-end] Received response: "{\"firstName\":\"NqeGftHRvMF\",\"lastName\":\"NqeGftHRvMF\",\"username\":\"NqeGftHRvMF\",\"id\":\"673ffd63b0df5c00019b2de7\",\"_links\":{\"a
  03:41:50.129 [front-end] Posting Customer: {"username":"xhvtH","password":"WPxPaIBjW","email":"xhvtH@gmail.com","firstName":"xhvtH","lastName":"xhvtH"}
  03:41:51.730 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd7fd94b9000069b476b","customerId":"673ffd64b0df5c00019b2dea","customer":{"id":null,"firstName":"nkRropEFNQB
  03:41:54.365 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd82d94b9000069b476e","customerId":"673ffd73b0df5c00019b2e22","customer":{"id":null,"firstName":"mHIUg","las
  03:41:55.827 [front-end] Order response: {"id":"673ffd83d94b9000069b4771","customerId":"673ffd6bb0df5c00019b2e03","customer":{"id":null,"firstName":"GaGiGUSlD","lastName":"GaGiGUSlD","u
  03:41:58.030 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffd86d94b9000069b4775","customerId":"673ffd6db0df5c00019b2e0e","customer":{"id":null,"firstName":"tnvRukEpABD
  03:42:00.165 [front-end] Order response: {"id":"673ffd88d94b9000069b4777","customerId":"673ffd72b0df5c00019b2e1f","customer":{"id":null,"firstName":"JzvgOyDkLhD","lastName":"JzvgOyDkLhD
  03:42:03.700 [front-end] Posting Customer: {"username":"VCaOgjawsIlvXr","password":"AzROo","email":"VCaOgjawsIlvXr@gmail.com","firstName":"VCaOgjawsIlvXr","lastName":"VCaOgjawsIlvXr"}
  03:42:08.984 [user] ts=2024-11-22T03:42:08.984639571Z caller=middlewares.go:46 method=Register username=oPTLuFy email=oPTLuFy@gmail.com took=1.067137ms

## p0718
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-14T14:00:28.502Z
```
{"service":"dbservice1","message":"2021-08-14 14:00:28,502 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 7e486f08701385 | ec8c352a-fcc4-11eb-b47a-0242ac110004-VcbkjSAZ-H}z)MI_t986B token generate success token=MTYyODkyMDgyOC41MDIwNTczOmVjOGMzNTJhLWZjYzQtMTFlYi1iNDdhLTAyNDJhYzExMDAwNFZjYmtqU0FaSH16KU1JX3Q5ODZCOjE2Mjg5MjA4ODguNTAyMDY4OmVlY2YwMzM5OWVmMzEwYzI4NGRiZGZjZmI2Mzc3NDEz"}
```
Same service, the 2 minutes before (oldest first):
  14:00:23.007 [dbservice1] INFO e940c96c-fcc4-11eb-a68d-0242ac110004-EVBLhgrm-9os/__E:hq47 token generate success token=MTYyODkyMDgyMy4wMDcwNjUzOmU5NDBjOTZjLWZjYzQtMTFlYi1hNjhkLTAyNDJhYzE
  14:00:23.791 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  14:00:23.791 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  14:00:23.850 [dbservice1] INFO query = select passwards from username_table where user_name='iBnyvbLP'  (×5)
  14:00:23.934 [dbservice1] INFO e9cdd258-fcc4-11eb-9104-0242ac110004-iBnyvbLP-R$>:BM4<a*@! token generate success token=MTYyODkyMDgyMy45MzQ1NTUzOmU5Y2RkMjU4LWZjYzQtMTFlYi05MTA0LTAyNDJhYzE
  14:00:25.813 [dbservice1] INFO eada11b6-fcc4-11eb-b4b5-0242ac110003-LmHpecgO-{$XO7}iZEDzn token generate success token=MTYyODkyMDgyNS44MTI3Mzc6ZWFkYTExYjYtZmNjNC0xMWViLWI0YjUtMDI0MmFjMTE
  14:00:26.689 [dbservice1] INFO eb75c37c-fcc4-11eb-bba3-0242ac110003-DLQYKJTg-?vaXQ#PZAoRN token generate success token=MTYyODkyMDgyNi42ODkxNTE6ZWI3NWMzN2MtZmNjNC0xMWViLWJiYTMtMDI0MmFjMTE
  14:00:27.648 [dbservice1] INFO ebfac86a-fcc4-11eb-a63e-0242ac110003-QghyctJY-PkMVvH8?+4Z= token generate success token=MTYyODkyMDgyNy42NDgwODk0OmViZmFjODZhLWZjYzQtMTFlYi1hNjNlLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  13:59:58.525 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×36)
  13:59:58.736 [redisservice2] INFO redis读取信息成功, status_code: 200  (×36)
  13:59:58.874 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  13:59:59.346 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'db9fbfde-fcc4-11eb-977e-0242ac110003', 'value': '', 'ex': 10}  (×35)
  14:00:04.016 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×31)
  14:00:04.252 [webservice2] ERROR an error occurred in the downstream service  (×6)
  14:00:06.780 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×32)
  14:00:06.936 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  14:00:10.848 [webservice1] ERROR an error occurred in the downstream service  (×4)
  14:00:11.766 [webservice2] INFO uuid: e2ffe5ec-fcc4-11eb-9639-0242ac110004 write redis successfully  (×37)
  14:00:12.453 [dbservice2] INFO e2ffe5ec-fcc4-11eb-9639-0242ac110004-dtYZahVu-L-(wot&?xVCf token generate success token=MTYyODkyMDgxMi40NTMyNTM3OmUyZmZlNWVjLWZjYzQtMTFlYi05NjM5LTAyNDJhYzE
  14:00:15.256 [dbservice1] ERROR password in database of {user} is null, the user is not registered  (×2)
  14:00:17.961 [dbservice1] INFO e63bd446-fcc4-11eb-99e5-0242ac110003-lEKkjfpD-^a37_&?:CJeS token generate success token=MTYyODkyMDgxNy45NjA4ODE6ZTYzYmQ0NDYtZmNjNC0xMWViLTk5ZTUtMDI0MmFjMTE
  14:00:20.780 [mobservice1] INFO info e82b720c-fcc4-11eb-ad4c-0242ac110003:IKAZGYCc write success
  14:00:23.007 [dbservice1] INFO e940c96c-fcc4-11eb-a68d-0242ac110004-EVBLhgrm-9os/__E:hq47 token generate success token=MTYyODkyMDgyMy4wMDcwNjUzOmU5NDBjOTZjLWZjYzQtMTFlYi1hNjhkLTAyNDJhYzE
  14:00:25.813 [dbservice1] INFO eada11b6-fcc4-11eb-b4b5-0242ac110003-LmHpecgO-{$XO7}iZEDzn token generate success token=MTYyODkyMDgyNS44MTI3Mzc6ZWFkYTExYjYtZmNjNC0xMWViLWI0YjUtMDI0MmFjMTE
  14:00:28.128 [mobservice2] INFO info ec8c352a-fcc4-11eb-b47a-0242ac110004:VcbkjSAZ write success
  14:00:31.215 [mobservice2] INFO info ee667202-fcc4-11eb-85b3-0242ac110004:pawXhUZy write success
  14:00:33.615 [dbservice1] INFO ef95e248-fcc4-11eb-833b-0242ac110004-XUtTqLre-dtbi.SgcZV?! token generate success token=MTYyODkyMDgzMy42MTQ4NzY1OmVmOTVlMjQ4LWZjYzQtMTFlYi04MzNiLTAyNDJhYzE
  14:00:36.073 [mobservice1] INFO info f14d434c-fcc4-11eb-a7b7-0242ac110003:SxlGNrtW write success
  14:00:38.558 [dbservice2] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c
  14:00:41.028 [mobservice2] INFO info f440f30a-fcc4-11eb-96a1-0242ac110003:tdfCvYKb write success
  14:00:43.265 [dbservice2] INFO f54e8244-fcc4-11eb-a711-0242ac110003-qQwhHKIv-SpFaT<ZzU!o? token generate success token=MTYyODkyMDg0My4yNjUyNDg6ZjU0ZTgyNDQtZmNjNC0xMWViLWE3MTEtMDI0MmFjMTE
  14:00:45.681 [mobservice1] INFO info f6fbdbdc-fcc4-11eb-9699-0242ac110004:LeQUvMXs write success
  14:00:49.077 [dbservice2] INFO f8b0d0e0-fcc4-11eb-87f0-0242ac110004-mIgaboME-%kKe74{mJnG5 token generate success token=MTYyODkyMDg0OS4wNzcxODk0OmY4YjBkMGUwLWZjYzQtMTFlYi04N2YwLTAyNDJhYzE
  14:00:51.388 [dbservice1] INFO fa3422be-fcc4-11eb-827e-0242ac110004-iZWtCSMp-M5*>4^fm-6c) token generate success token=MTYyODkyMDg1MS4zODc3OTI4OmZhMzQyMmJlLWZjYzQtMTFlYi04MjdlLTAyNDJhYzE
  14:00:54.503 [dbservice2] INFO fbd7091a-fcc4-11eb-bbcb-0242ac110004-SmLIGcYg-W<_hvc0zYusl token generate success token=MTYyODkyMDg1NC41MDI5MDc4OmZiZDcwOTFhLWZjYzQtMTFlYi1iYmNiLTAyNDJhYzE
  14:00:57.023 [mobservice2] INFO info fdc23fb0-fcc4-11eb-9de7-0242ac110003:MBoWvOAG write success

## p0362
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:34:04.502Z
```
{"timestamp":1732246444502358800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /cards 200 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  03:34:03.825 [front-end] set cookie673ffbabb0df5c00019b289d  (×3)
  03:34:03.825 [front-end] Sent cookies.  (×3)
  03:34:03.827 [front-end] POST /register 200 35.278 ms - 33  (×3)
  03:34:03.848 [front-end] Carts merged.  (×2)
  03:34:03.910 [front-end] GET /catalogue 200 - ms - -
  03:34:03.951 [front-end] Posting Customer: {"username":"SawmEZCGq","password":"ENsHLqQWq","email":"SawmEZCGq@gmail.com","firstName":"SawmEZCGq","lastName":"SawmEZCGq"}
  03:34:03.956 [front-end] { id: '673ffbabb0df5c00019b289f' }
  03:34:03.956 [front-end] 673ffbabb0df5c00019b289f
  03:34:03.956 [front-end] Merging carts for customer id: 673ffbabb0df5c00019b289f and session id: cO62M9UVCOuvJ1O5mBAsYIgXKpWqDQZY
  03:34:04.479 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffba5b0df5c00019b288e"}
  03:34:04.488 [front-end] POST /addresses 200 - ms - -
  03:34:04.494 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffba5b0df5c00019b288e"}
  03:34:04.502 [front-end] Request received with body: {}
All services, 30 seconds either side (sampled):
  03:33:34.504 [front-end] POST /cards 200 - ms - -  (×57)
  03:33:34.784 [carts] 2024-11-22 03:33:34.783 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  03:33:35.006 [user] ts=2024-11-22T03:33:35.006641702Z caller=middlewares.go:46 method=Register username=ahHiz email=ahHiz@gmail.com took=1.124176ms
  03:33:36.093 [user] ts=2024-11-22T03:33:36.093356104Z caller=middlewares.go:157 method=Health result=2 took=763.291µs  (×37)
  03:33:36.238 [front-end] Posting Order: {"customer":"http://user/customers/673ffb7cb0df5c00019b2810","address":"http://user/addresses/673ffb83b0df5c00019b2824","card":"http://user/cards  (×66)
  03:33:36.864 [front-end] Posting Customer: {"username":"vofgzmlG","password":"vOjyOvlP","email":"vofgzmlG@gmail.com","firstName":"vofgzmlG","lastName":"vofgzmlG"}
  03:33:39.240 [front-end] Received response: "{\"firstName\":\"gsgGmxLUYu\",\"lastName\":\"gsgGmxLUYu\",\"username\":\"gsgGmxLUYu\",\"id\":\"673ffb7fb0df5c00019b2818\",\"_links\":{\"addr
  03:33:41.184 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  03:33:44.367 [front-end] Received response: "{\"firstName\":\"lWsTVWyIgVeaA\",\"lastName\":\"lWsTVWyIgVeaA\",\"username\":\"lWsTVWyIgVeaA\",\"id\":\"673ffb83b0df5c00019b2827\",\"_links\
  03:33:47.787 [front-end] Posting Customer: {"username":"balNYntzTG","password":"FikFiE","email":"balNYntzTG@gmail.com","firstName":"balNYntzTG","lastName":"balNYntzTG"}
  03:33:50.387 [front-end] Posting Customer: {"username":"SszKsOMIqhDn","password":"eZFpbJ","email":"SszKsOMIqhDn@gmail.com","firstName":"SszKsOMIqhDn","lastName":"SszKsOMIqhDn"}
  03:33:55.567 [front-end] Received response: "{\"firstName\":\"YFxNtoXtzFUCvUM\",\"lastName\":\"YFxNtoXtzFUCvUM\",\"username\":\"YFxNtoXtzFUCvUM\",\"id\":\"673ffb89b0df5c00019b2840\",\"_
  03:33:59.549 [front-end] Posting Customer: {"username":"QxvylaoI","password":"yVtTVTxQvS","email":"QxvylaoI@gmail.com","firstName":"QxvylaoI","lastName":"QxvylaoI"}
  03:34:02.040 [front-end] Posting Customer: {"username":"QZykixJJv","password":"YrNGeemFWE","email":"QZykixJJv@gmail.com","firstName":"QZykixJJv","lastName":"QZykixJJv"}
  03:34:03.809 [front-end] Posting Customer: {"username":"sodZqevvhKZpzL","password":"PBeca","email":"sodZqevvhKZpzL@gmail.com","firstName":"sodZqevvhKZpzL","lastName":"sodZqevvhKZpzL"}
  03:34:08.539 [front-end] Posting Customer: {"username":"YNMGmWFqGY","password":"tpnDiAMm","email":"YNMGmWFqGY@gmail.com","firstName":"YNMGmWFqGY","lastName":"YNMGmWFqGY"}
  03:34:09.189 [carts] 2024-11-22 03:34:09.189 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
  03:34:11.989 [user] ts=2024-11-22T03:34:11.989201481Z caller=middlewares.go:46 method=Register username=IfmvArYLd email=IfmvArYLd@gmail.com took=1.002926ms
  03:34:13.622 [user] ts=2024-11-22T03:34:13.622270819Z caller=middlewares.go:46 method=Register username=Umaupu email=Umaupu@gmail.com took=1.083971ms
  03:34:16.846 [front-end] Posting Customer: {"username":"cBiHCInttKC","password":"GZczjzr","email":"cBiHCInttKC@gmail.com","firstName":"cBiHCInttKC","lastName":"cBiHCInttKC"}
  03:34:20.311 [front-end] Received response: "{\"firstName\":\"XtmVoXKnmLWjJv\",\"lastName\":\"XtmVoXKnmLWjJv\",\"username\":\"XtmVoXKnmLWjJv\",\"id\":\"673ffbaeb0df5c00019b28a9\",\"_lin
  03:34:23.122 [front-end] Posting Customer: {"username":"HxhyLLnNjF","password":"BGYEgAMCwg","email":"HxhyLLnNjF@gmail.com","firstName":"HxhyLLnNjF","lastName":"HxhyLLnNjF"}
  03:34:25.886 [carts] 2024-11-22 03:34:25.886 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+json
  03:34:25.989 [carts] 2024-11-22 03:34:25.989 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[application
  03:34:25.993 [carts] 2024-11-22 03:34:25.993 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces=
  03:34:26.191 [front-end] Received response: "{\"firstName\":\"omPPflkNjBQC\",\"lastName\":\"omPPflkNjBQC\",\"username\":\"omPPflkNjBQC\",\"id\":\"673ffbb3b0df5c00019b28c3\",\"_links\":{
  03:34:29.485 [carts] 2024-11-22 03:34:29.485 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  03:34:29.489 [carts] 2024-11-22 03:34:29.489 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  03:34:32.892 [carts] 2024-11-22 03:34:32.892 INFO [carts,,,] 7 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 

## p0506
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:19:23.393Z
```
{"timestamp":1732353563393078300,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:19:23.3929529Z caller=middlewares.go:75 method=GetUsers id=67419e05a437380001df0fa2 result=1 took=1.906977ms"}
```
Same service, the 2 minutes before (oldest first):
  09:19:21.592 [user] ts=2024-11-23T09:19:21.592665217Z caller=middlewares.go:75 method=GetUsers id=67419e06a437380001df0fa4 result=1 took=2.225822ms  (×15)
  09:19:22.464 [user] ts=2024-11-23T09:19:22.463913874Z caller=middlewares.go:46 method=Register username=KRCkNUfP email=KRCkNUfP@gmail.com took=2.785057ms
  09:19:22.499 [user] ts=2024-11-23T09:19:22.498920578Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419e10a437380001df0fcb took=4.74699ms
  09:19:22.560 [user] ts=2024-11-23T09:19:22.560315533Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419e10a437380001df0fcb took=4.626759ms
  09:19:22.853 [user] ts=2024-11-23T09:19:22.852890161Z caller=middlewares.go:157 method=Health result=2 took=5.92178ms  (×2)
All services, 30 seconds either side (sampled):
  09:18:53.407 [catalogue] ts=2024-11-23T09:18:53Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.549829ms  (×57)
  09:18:53.799 [front-end] Attempting to delete cart for user: 67419df5a437380001df0f7e  (×59)
  09:18:53.869 [carts] 2024-11-23 09:18:53.868 INFO [carts,54f5968f747a64a7,9f20dc3399274e53,false] 7 --- [-nio-80-exec-11] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×32)
  09:18:55.030 [front-end] Received response: "{\"firstName\":\"nsaNAtGwDv\",\"lastName\":\"nsaNAtGwDv\",\"username\":\"nsaNAtGwDv\",\"id\":\"67419de6a437380001df0f57\",\"_links\":{\"addr
  09:18:55.052 [orders] Caused by: com.fasterxml.jackson.databind.JsonMappingException: Conflicting setter definitions for property "items": works.weave.socks.orders.entities.CustomerO  (×58)
  09:18:55.138 [front-end] 67419dffa437380001df0f96  (×60)
  09:18:56.540 [front-end] Received response: "{\"firstName\":\"LxWEPIZNMdFk\",\"lastName\":\"LxWEPIZNMdFk\",\"username\":\"LxWEPIZNMdFk\",\"id\":\"67419deea437380001df0f67\",\"_links\":{
  09:18:58.286 [user] ts=2024-11-23T09:18:58.286575554Z caller=middlewares.go:46 method=Register username=nsKKXcdJy email=nsKKXcdJy@gmail.com took=3.019349ms
  09:19:00.135 [front-end] Posting Customer: {"username":"uQsVqnFMIcozQx","password":"XbYaoXrr","email":"uQsVqnFMIcozQx@gmail.com","firstName":"uQsVqnFMIcozQx","lastName":"uQsVqnFMIcozQx"
  09:19:01.190 [user] ts=2024-11-23T09:19:01.190025409Z caller=middlewares.go:46 method=Register username=xzaYAPZ email=xzaYAPZ@gmail.com took=2.517504ms
  09:19:03.984 [front-end] Received response: "{\"firstName\":\"xECNng\",\"lastName\":\"xECNng\",\"username\":\"xECNng\",\"id\":\"67419deea437380001df0f68\",\"_links\":{\"addresses\":{\"h
  09:19:05.841 [user] ts=2024-11-23T09:19:05.841292666Z caller=middlewares.go:46 method=Register username=qvureeHiQ email=qvureeHiQ@gmail.com took=2.03529ms
  09:19:07.634 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×8)
  09:19:09.567 [front-end] Posting Customer: {"username":"eyfZO","password":"inLujk","email":"eyfZO@gmail.com","firstName":"eyfZO","lastName":"eyfZO"}
  09:19:14.702 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×5)
  09:19:19.709 [front-end] Received response: "{\"firstName\":\"LeJzXiQab\",\"lastName\":\"LeJzXiQab\",\"username\":\"LeJzXiQab\",\"id\":\"67419e04a437380001df0fa1\",\"_links\":{\"address
  09:19:22.766 [front-end] Received response: "{\"firstName\":\"bNRMNn\",\"lastName\":\"bNRMNn\",\"username\":\"bNRMNn\",\"id\":\"67419e02a437380001df0f9c\",\"_links\":{\"addresses\":{\"h
  09:19:24.854 [orders-db] {"t":{"$date":"2024-11-23T09:19:24.854+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235356
  09:19:26.156 [front-end] Received response: "{\"firstName\":\"ugGWgr\",\"lastName\":\"ugGWgr\",\"username\":\"ugGWgr\",\"id\":\"67419e0ba437380001df0fbf\",\"_links\":{\"addresses\":{\"h
  09:19:28.056 [front-end] Received response: "{\"firstName\":\"qvureeHiQ\",\"lastName\":\"qvureeHiQ\",\"username\":\"qvureeHiQ\",\"id\":\"67419e09a437380001df0fae\",\"_links\":{\"address
  09:19:30.429 [front-end] Received response: "{\"firstName\":\"pbndm\",\"lastName\":\"pbndm\",\"username\":\"pbndm\",\"id\":\"67419e12a437380001df0fd6\",\"_links\":{\"addresses\":{\"href
  09:19:34.127 [user] ts=2024-11-23T09:19:34.127104552Z caller=middlewares.go:46 method=Register username=xpJyGBMv email=xpJyGBMv@gmail.com took=2.522756ms
  09:19:36.476 [front-end] Posting Customer: {"username":"RZhbSFcG","password":"rkYfPs","email":"RZhbSFcG@gmail.com","firstName":"RZhbSFcG","lastName":"RZhbSFcG"}
  09:19:42.124 [front-end] Received response: "{\"firstName\":\"XVfZOrXDYP\",\"lastName\":\"XVfZOrXDYP\",\"username\":\"XVfZOrXDYP\",\"id\":\"67419e13a437380001df0fdd\",\"_links\":{\"addr
  09:19:44.140 [user] ts=2024-11-23T09:19:44.140708917Z caller=middlewares.go:46 method=Register username=GmvHxVjCB email=GmvHxVjCB@gmail.com took=2.880265ms
  09:19:48.574 [front-end] Received response: "{\"firstName\":\"nIbNgK\",\"lastName\":\"nIbNgK\",\"username\":\"nIbNgK\",\"id\":\"67419e20a437380001df0ffd\",\"_links\":{\"addresses\":{\"h
  09:19:52.561 [front-end] Posting Customer: {"username":"yltfBtzq","password":"qZIgxxdUi","email":"yltfBtzq@gmail.com","firstName":"yltfBtzq","lastName":"yltfBtzq"}

## p0293
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:38:19.037Z
```
{"timestamp":1732243099037311700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Carts merged."}
```
Same service, the 2 minutes before (oldest first):
  02:38:18.081 [front-end] Merging carts for customer id: 673fee9ab0df5c00019b00b2 and session id: weSesx-wmqeE7cNzspFamZNpujBSvq1N  (×2)
  02:38:18.098 [front-end] Carts merged.
  02:38:18.098 [front-end] set cookie673fee9ab0df5c00019b00b2
  02:38:18.099 [front-end] Sent cookies.
  02:38:18.101 [front-end] POST /register 200 24.152 ms - 33
  02:38:18.859 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fee94b0df5c00019b009d"}
  02:38:18.867 [front-end] POST /addresses 200 - ms - -
  02:38:18.873 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fee94b0df5c00019b009d"}
  02:38:18.883 [front-end] POST /cards 200 - ms - -
  02:38:18.928 [front-end] Attempting to delete cart for user: 673fee94b0df5c00019b009d
  02:38:18.944 [front-end] User cart deleted with status: 202
  02:38:18.947 [front-end] DELETE /cart 202 - ms - -
  02:38:18.952 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  02:38:18.960 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  02:38:18.960 [front-end] POST to carts: http://carts/carts/673fee94b0df5c00019b009d/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  02:38:18.992 [front-end] POST /cart 201 - ms - -
  02:38:19.015 [front-end] Posting Customer: {"username":"flzgqYzlrTwM","password":"uFkPQdNdOg","email":"flzgqYzlrTwM@gmail.com","firstName":"flzgqYzlrTwM","lastName":"flzgqYzlrTwM"}
  02:38:19.020 [front-end] { id: '673fee9bb0df5c00019b00b5' }
  02:38:19.020 [front-end] 673fee9bb0df5c00019b00b5
All services, 30 seconds either side (sampled):
  02:37:49.352 [catalogue] ts=2024-11-22T02:37:49Z caller=logging.go:85 method=Health result=2 took=26.284µs  (×39)
  02:37:49.981 [front-end] Request received with body: {}  (×60)
  02:37:50.016 [orders] 2024-11-22 02:37:50.016 INFO [orders,e417264f3a623f30,70e0e5f802164b84,false] 6 --- [-nio-80-exec-15] w.w.s.o.controllers.OrdersController : Received payment re  (×25)
  02:37:50.288 [carts] 2024-11-22 02:37:50.288 INFO [carts,60755ba4b45811a1,444824b3f754b61f,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×31)
  02:37:50.375 [orders] 2024-11-22 02:37:50.375 INFO [orders,33e37c13e1647959,e29c6c32c48d7ab7,false] 6 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Sending payment req  (×35)
  02:37:50.432 [front-end] POST /cart 201 - ms - -  (×59)
  02:37:52.598 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×7)
  02:37:55.579 [front-end] Received response: "{\"firstName\":\"PZqMDkYiGi\",\"lastName\":\"PZqMDkYiGi\",\"username\":\"PZqMDkYiGi\",\"id\":\"673fee6fb0df5c00019b0036\",\"_links\":{\"addr
  02:37:56.991 [front-end] POST to carts: http://carts/carts/673fee7ab0df5c00019b005a/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}  (×24)
  02:38:00.206 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732243080204,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×6)
  02:38:02.703 [catalogue] ts=2024-11-22T02:38:02Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=4.17653m  (×5)
  02:38:06.071 [front-end] Order response: {"id":"673fee8ed94b9000069b3bf2","customerId":"673fee75b0df5c00019b004c","customer":{"id":null,"firstName":"senehdf","lastName":"senehdf","usern
  02:38:07.537 [queue-master] 2024-11-22 02:38:07.537 ERROR 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×9)
  02:38:10.648 [front-end] Received response: "{\"firstName\":\"KQXPgLCscaH\",\"lastName\":\"KQXPgLCscaH\",\"username\":\"KQXPgLCscaH\",\"id\":\"673fee7ab0df5c00019b0057\",\"_links\":{\"a
  02:38:12.786 [user] ts=2024-11-22T02:38:12.786574612Z caller=middlewares.go:46 method=Register username=gDbYYMHQ email=gDbYYMHQ@gmail.com took=997.415µs
  02:38:14.563 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee96d94b9000069b3bfc","customerId":"673fee80b0df5c00019b0066","customer":{"id":null,"firstName":"yHNGklHdnZm
  02:38:19.091 [front-end] Received response: "{\"firstName\":\"MFPenYarqDA\",\"lastName\":\"MFPenYarqDA\",\"username\":\"MFPenYarqDA\",\"id\":\"673fee88b0df5c00019b007c\",\"_links\":{\"a
  02:38:20.079 [front-end] Received response: "{\"firstName\":\"BcUALzYbrk\",\"lastName\":\"BcUALzYbrk\",\"username\":\"BcUALzYbrk\",\"id\":\"673fee83b0df5c00019b006a\",\"_links\":{\"addr
  02:38:23.853 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee9fd94b9000069b3c05","customerId":"673fee8db0df5c00019b008b","customer":{"id":null,"firstName":"BlXXP","las
  02:38:27.882 [carts-db] {"t":{"$date":"2024-11-22T02:38:27.881+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224310
  02:38:28.851 [front-end] Order response: {"id":"673feea4d94b9000069b3c0a","customerId":"673fee95b0df5c00019b00a0","customer":{"id":null,"firstName":"uEVEcke","lastName":"uEVEcke","usern
  02:38:30.693 [user] ts=2024-11-22T02:38:30.693207189Z caller=middlewares.go:46 method=Register username=CMGACdVZn email=CMGACdVZn@gmail.com took=1.040966ms
  02:38:31.579 [front-end] Received response: "{\"firstName\":\"bMyeICjUYoa\",\"lastName\":\"bMyeICjUYoa\",\"username\":\"bMyeICjUYoa\",\"id\":\"673fee90b0df5c00019b0095\",\"_links\":{\"a
  02:38:33.497 [front-end] Order response: {"id":"673feea9d94b9000069b3c0e","customerId":"673fee8fb0df5c00019b0093","customer":{"id":null,"firstName":"JXGGkzfvuakQ","lastName":"JXGGkzfvua
  02:38:38.757 [front-end] Order response: {"statusCode":201,"body":{"id":"673feeaed94b9000069b3c11","customerId":"673fee96b0df5c00019b00a4","customer":{"id":null,"firstName":"BefZqFmzQJq
  02:38:42.443 [front-end] Received response: "{\"firstName\":\"ZUEqGwFMOYjiUtY\",\"lastName\":\"ZUEqGwFMOYjiUtY\",\"username\":\"ZUEqGwFMOYjiUtY\",\"id\":\"673feea0b0df5c00019b00c7\",\"_
  02:38:44.664 [front-end] Received response: "{\"firstName\":\"zxtZkxtre\",\"lastName\":\"zxtZkxtre\",\"username\":\"zxtZkxtre\",\"id\":\"673feea5b0df5c00019b00d0\",\"_links\":{\"address
  02:38:48.048 [front-end] Order response: {"id":"673feeb8d94b9000069b3c19","customerId":"673feea5b0df5c00019b00d5","customer":{"id":null,"firstName":"LYBVAxYonZif","lastName":"LYBVAxYonZ
  02:38:48.916 [front-end] Order response: {"id":"673feeb8d94b9000069b3c1c","customerId":"673feea6b0df5c00019b00d8","customer":{"id":null,"firstName":"CMGACdVZn","lastName":"CMGACdVZn","u

## p0460
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:06:42.933Z
```
{"timestamp":1732349202933222000,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"statusCode\":201,\"body\":{\"id\":\"67418d123f77060008864e44\",\"customerId\":\"67418cfda437380001deecb5\",\"customer\":{\"id\":null,\"firstName\":\"suxeYRw\",\"lastName\":\"suxeYRw\",\"username\":\"suxeYRw\",\"addresses\":[],\"cards\":[]},\"address\":{\"id\":null,\"number\":\"123\",\"street\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"country\":\"123\"},\"card\":{\"id\":null,\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\"},\"item…"}
```
Same service, the 2 minutes before (oldest first):
  08:06:42.309 [front-end] Sent cookies.  (×2)
  08:06:42.313 [front-end] POST /register 200 166.296 ms - 33  (×2)
  08:06:42.404 [front-end] POST /cart 201 - ms - -
  08:06:42.520 [front-end] GET /catalogue 200 - ms - -
  08:06:42.727 [front-end] Posting Customer: {"username":"gSjFQJm","password":"OxlJt","email":"gSjFQJm@gmail.com","firstName":"gSjFQJm","lastName":"gSjFQJm"}
  08:06:42.732 [front-end] { id: '67418d12a437380001deecff' }
  08:06:42.732 [front-end] 67418d12a437380001deecff
  08:06:42.732 [front-end] Merging carts for customer id: 67418d12a437380001deecff and session id: h-yhvVxqQn3ateXWPcde3AzIQBsLnaV3
  08:06:42.839 [front-end] Request received with body: {}
  08:06:42.851 [front-end] Received response: "{\"firstName\":\"suxeYRw\",\"lastName\":\"suxeYRw\",\"username\":\"suxeYRw\",\"id\":\"67418cfda437380001deecb5\",\"_links\":{\"addresses\":{
  08:06:42.851 [front-end] GET Request to: http://user/customers/67418cfda437380001deecb5/addresses  (×2)
  08:06:42.860 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418d05a437380001deecd4\",\"_links\":{\"
  08:06:42.860 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418
  08:06:42.860 [front-end] [ undefined, undefined ]
  08:06:42.860 [front-end] Posting Order: {"customer":"http://user/customers/67418cfda437380001deecb5","address":"http://user/addresses/67418d05a437380001deecd3","card":"http://user/cards
  08:06:42.907 [front-end] Carts merged.
  08:06:42.907 [front-end] set cookie67418d12a437380001deecff
All services, 30 seconds either side (sampled):
  08:06:12.992 [front-end] User cart deleted with status: 503  (×60)
  08:06:13.421 [front-end] POST /register 200 47.362 ms - 33  (×61)
  08:06:13.643 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732349173638,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×17)
  08:06:14.065 [front-end] Received response: "{\"firstName\":\"suOMyE\",\"lastName\":\"suOMyE\",\"username\":\"suOMyE\",\"id\":\"67418cdea437380001deec59\",\"_links\":{\"addresses\":{\"h
  08:06:15.603 [carts] 2024-11-23 08:06:15.603 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.actu
  08:06:15.805 [carts] 2024-11-23 08:06:15.804 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[GE
  08:06:15.906 [carts] 2024-11-23 08:06:15.904 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframewor
  08:06:16.825 [front-end] Posting Customer: {"username":"OkxajUZjGhkcaQY","password":"HuzLEVid","email":"OkxajUZjGhkcaQY@gmail.com","firstName":"OkxajUZjGhkcaQY","lastName":"OkxajUZjGhkc
  08:06:19.009 [carts] 2024-11-23 08:06:19.009 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[appl
  08:06:20.059 [front-end] Received response: "{\"firstName\":\"RKNDdSk\",\"lastName\":\"RKNDdSk\",\"username\":\"RKNDdSk\",\"id\":\"67418ce7a437380001deec7c\",\"_links\":{\"addresses\":{
  08:06:24.105 [carts] 2024-11-23 08:06:24.105 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetected
  08:06:26.093 [front-end] Received response: "{\"firstName\":\"XJzSyDLxvp\",\"lastName\":\"XJzSyDLxvp\",\"username\":\"XJzSyDLxvp\",\"id\":\"67418cefa437380001deec90\",\"_links\":{\"addr
  08:06:28.206 [front-end] Posting Customer: {"username":"cBGHfcdiqX","password":"AQDeYE","email":"cBGHfcdiqX@gmail.com","firstName":"cBGHfcdiqX","lastName":"cBGHfcdiqX"}
  08:06:30.915 [front-end] Posting Customer: {"username":"EDkxTMyJmiJ","password":"mQFftS","email":"EDkxTMyJmiJ@gmail.com","firstName":"EDkxTMyJmiJ","lastName":"EDkxTMyJmiJ"}
  08:06:32.806 [orders] 2024-11-23 08:06:32.806 INFO [orders,fbcebf8ef5e82428,6d050ec4f8a03a61,false] 8 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Received payment re  (×37)
  08:06:34.499 [carts] 2024-11-23 08:06:34.499 INFO [carts,6edc4d8c38bbfc4a,aeca33d2594acd5e,false] 7 --- [-nio-80-exec-12] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×29)
  08:06:35.621 [front-end] Received response: "{\"firstName\":\"WPDZdEO\",\"lastName\":\"WPDZdEO\",\"username\":\"WPDZdEO\",\"id\":\"67418cf9a437380001deeca9\",\"_links\":{\"addresses\":{
  08:06:36.205 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d0b3f77060008864e3d","customerId":"67418ceca437380001deec88","customer":{"id":null,"firstName":"VnaknAEtTvw
  08:06:40.900 [queue-master] Caused by: java.lang.RuntimeException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock) at com.google.commo
  08:06:42.731 [user] ts=2024-11-23T08:06:42.730941626Z caller=middlewares.go:46 method=Register username=gSjFQJm email=gSjFQJm@gmail.com took=2.103432ms
  08:06:43.932 [front-end] Order response: {"id":"67418d133f77060008864e46","customerId":"67418d02a437380001deecbf","customer":{"id":null,"firstName":"fdgssjehHZFkqOI","lastName":"fdgssje
  08:06:48.331 [user] ts=2024-11-23T08:06:48.331118952Z caller=middlewares.go:46 method=Register username=BmPHiTV email=BmPHiTV@gmail.com took=3.505554ms
  08:06:49.893 [front-end] Order response: {"id":"67418d193f77060008864e4f","customerId":"67418d01a437380001deecbe","customer":{"id":null,"firstName":"HRFgUBgyU","lastName":"HRFgUBgyU","u
  08:06:53.483 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d1d3f77060008864e54","customerId":"67418d09a437380001deecda","customer":{"id":null,"firstName":"HotpHJJrtTu
  08:06:56.741 [front-end] Received response: "{\"firstName\":\"pFbuHLdxmNq\",\"lastName\":\"pFbuHLdxmNq\",\"username\":\"pFbuHLdxmNq\",\"id\":\"67418d06a437380001deecd6\",\"_links\":{\"a
  08:07:00.337 [user] ts=2024-11-23T08:07:00.337091992Z caller=middlewares.go:46 method=Register username=cbnvs email=cbnvs@gmail.com took=1.75498ms
  08:07:01.907 [front-end] Order response: {"id":"67418d253f77060008864e5d","customerId":"67418d10a437380001deecf9","customer":{"id":null,"firstName":"ehjzbOPHpDjC","lastName":"ehjzbOPHpD
  08:07:04.456 [front-end] Posting Customer: {"username":"LvArsGp","password":"rrNBGLQsC","email":"LvArsGp@gmail.com","firstName":"LvArsGp","lastName":"LvArsGp"}
  08:07:12.068 [front-end] Posting Customer: {"username":"afuxjwRgkh","password":"DMvvTuY","email":"afuxjwRgkh@gmail.com","firstName":"afuxjwRgkh","lastName":"afuxjwRgkh"}

## p0388
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service catalogue, 2024-11-22T03:46:22.352Z
```
{"timestamp":1732247182352243000,"container_name":"catalogue","pod_name":"catalogue-b98c66547-q2k66","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:46:22Z caller=logging.go:85 method=Health result=2 took=27.682µs"}
```
Same service, the 2 minutes before (oldest first):
  03:46:15.766 [catalogue] ts=2024-11-22T03:46:15Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=6.451347ms  (×8)
  03:46:16.226 [catalogue] ts=2024-11-22T03:46:16Z caller=logging.go:62 method=Get id=819e1fbf-8b7e-4f6d-811f-693534916a8b sock=819e1fbf-8b7e-4f6d-811f-693534916a8b err=null took=4.874752  (×7)
  03:46:16.352 [catalogue] ts=2024-11-22T03:46:16Z caller=logging.go:85 method=Health result=2 took=28.032µs  (×4)
  03:46:16.570 [catalogue] ts=2024-11-22T03:46:16Z caller=logging.go:62 method=Get id=837ab141-399e-4c1f-9abc-bace40296bac sock=837ab141-399e-4c1f-9abc-bace40296bac err=null took=3.87728m
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×25)
  03:46:10.147 [front-end] 673ffe82b0df5c00019b315b  (×39)
  03:46:10.351 [catalogue] ts=2024-11-22T03:46:10Z caller=logging.go:85 method=Health result=2 took=27.37µs  (×29)
  03:46:10.817 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe78b0df5c00019b3141\",\"_links\":{\"  (×41)
  03:46:10.843 [payment] ts=2024-11-22T03:46:10Z caller=logging.go:40 method=Health result=1 took=7.196µs  (×28)
  03:46:10.940 [front-end] Received response: "{\"firstName\":\"jnTZDLVwW\",\"lastName\":\"jnTZDLVwW\",\"username\":\"jnTZDLVwW\",\"id\":\"673ffe65b0df5c00019b3100\",\"_links\":{\"address
  03:46:11.161 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffe79b0df5c00019b3143"}  (×42)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×42)
  03:46:11.318 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  03:46:12.141 [user] ts=2024-11-22T03:46:12.141108416Z caller=middlewares.go:46 method=Register username=VaPxY email=VaPxY@gmail.com took=1.01883ms
  03:46:12.669 [orders] 2024-11-22 03:46:12.668 ERROR [orders,,,] 6 --- [p-nio-80-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×23)
  03:46:14.786 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  03:46:15.206 [user] ts=2024-11-22T03:46:15.206068871Z caller=middlewares.go:46 method=Register username=GIUFZZyI email=GIUFZZyI@gmail.com took=1.199135ms
  03:46:16.945 [user] ts=2024-11-22T03:46:16.945426009Z caller=middlewares.go:46 method=Register username=ANUgD email=ANUgD@gmail.com took=1.061751ms
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:22.962 [user] ts=2024-11-22T03:46:22.961891483Z caller=middlewares.go:46 method=Register username=YNeGDXzX email=YNeGDXzX@gmail.com took=1.087598ms
  03:46:25.991 [user] ts=2024-11-22T03:46:25.991686067Z caller=middlewares.go:46 method=Register username=jAAETa email=jAAETa@gmail.com took=1.020993ms
  03:46:26.921 [user] ts=2024-11-22T03:46:26.921445594Z caller=middlewares.go:46 method=Register username=SGNMlFJX email=SGNMlFJX@gmail.com took=998.659µs
  03:46:28.865 [orders-db] {"t":{"$date":"2024-11-22T03:46:28.864+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224718
  03:46:30.040 [user] ts=2024-11-22T03:46:30.040199562Z caller=middlewares.go:46 method=Register username=hCQLZMhz email=hCQLZMhz@gmail.com took=1.097772ms
  03:46:30.678 [front-end] Received response: "{\"firstName\":\"jwQwxgI\",\"lastName\":\"jwQwxgI\",\"username\":\"jwQwxgI\",\"id\":\"673ffe80b0df5c00019b315a\",\"_links\":{\"addresses\":{
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.099 [front-end] Posting Customer: {"username":"THBqBDDcBz","password":"PRiYTiQkw","email":"THBqBDDcBz@gmail.com","firstName":"THBqBDDcBz","lastName":"THBqBDDcBz"}
  03:46:40.280 [front-end] Posting Customer: {"username":"GFexg","password":"iTpJx","email":"GFexg@gmail.com","firstName":"GFexg","lastName":"GFexg"}
  03:46:42.343 [front-end] Posting Customer: {"username":"PscIdXcmCyQHmMr","password":"qvNYdZI","email":"PscIdXcmCyQHmMr@gmail.com","firstName":"PscIdXcmCyQHmMr","lastName":"PscIdXcmCyQHm
  03:46:47.377 [front-end] Received response: "{\"firstName\":\"hCQLZMhz\",\"lastName\":\"hCQLZMhz\",\"username\":\"hCQLZMhz\",\"id\":\"673ffe96b0df5c00019b3197\",\"_links\":{\"addresses\
  03:46:50.786 [front-end] Received response: "{\"firstName\":\"WrRpd\",\"lastName\":\"WrRpd\",\"username\":\"WrRpd\",\"id\":\"673ffe94b0df5c00019b3193\",\"_links\":{\"addresses\":{\"href
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon

## p0025
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T07:21:30.380Z
```
{"service":"dbservice1","message":"2021-08-13 07:21:30,380 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 59bf623c9f805f47 | 05e862d4-fbc4-11eb-9f45-0242ac110004-OzKQAVJF-y0PH2h:lM}5T token generate success token=MTYyODgxMDQ5MC4zNzc4ODM6MDVlODYyZDQtZmJjNC0xMWViLTlmNDUtMDI0MmFjMTEwMDA0T3pLUUFWSkZ5MFBIMmg6bE19NVQ6MTYyODgxMDU1MC4zNzc4OTQ5OmVjOGFmZGEwOTcwNDYwZWFlMmRmYmQyOTQ1NjVmZDk3"}
```
Same service, the 2 minutes before (oldest first):
  07:21:24.656 [dbservice1] INFO 02860ff6-fbc4-11eb-b212-0242ac110003-HSRAIxlj-CuIYqAwN&?x) token generate success token=MTYyODgxMDQ4NC42NTU4NjM6MDI4NjBmZjYtZmJjNC0xMWViLWIyMTItMDI0MmFjMTE
  07:21:25.880 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  07:21:25.880 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  07:21:25.936 [dbservice1] INFO query = select passwards from username_table where user_name='fVwtyQDn'  (×5)
  07:21:26.012 [dbservice1] INFO 033e026e-fbc4-11eb-af7a-0242ac110004-fVwtyQDn-m0:RzXgt4@vn token generate success token=MTYyODgxMDQ4Ni4wMTIyNDQ6MDMzZTAyNmUtZmJjNC0xMWViLWFmN2EtMDI0MmFjMTE
  07:21:26.794 [dbservice1] INFO 03daba46-fbc4-11eb-a092-0242ac110003-MiawoxWe-(HUjD!cPq)uv token generate success token=MTYyODgxMDQ4Ni43OTQxNDowM2RhYmE0Ni1mYmM0LTExZWItYTA5Mi0wMjQyYWMxMTA
  07:21:27.512 [dbservice1] INFO 043ae27c-fbc4-11eb-b82d-0242ac110003-gKUmCyre-YL:T*me_uhSJ token generate success token=MTYyODgxMDQ4Ny41MTIxODMyOjA0M2FlMjdjLWZiYzQtMTFlYi1iODJkLTAyNDJhYzE
  07:21:28.406 [dbservice1] INFO 04c0f4c0-fbc4-11eb-852a-0242ac110004-btlsWgLd-X^oq#)eu9Fd/ token generate success token=MTYyODgxMDQ4OC40MDYzMjQ6MDRjMGY0YzAtZmJjNC0xMWViLTg1MmEtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  07:21:00.407 [redisservice2] INFO redis读取信息成功, status_code: 200  (×44)
  07:21:00.507 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×43)
  07:21:00.857 [redisservice1] INFO redis write success  (×94)
  07:21:01.057 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×40)
  07:21:01.361 [logservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×47)
  07:21:01.542 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×47)
  07:21:01.982 [webservice1] INFO complete information: {'uuid': 'f554ad1a-fbc3-11eb-8cfe-0242ac110003', 'user_id': 'jnuiIECt'}  (×42)
  07:21:02.934 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'f5dd78b6-fbc3-11eb-bed1-0242ac110003'}  (×40)
  07:21:04.503 [dbservice1] INFO f68aae3c-fbc3-11eb-bec7-0242ac110003-WRrkiQEt-6aT9E1w<+@(I token generate success token=MTYyODgxMDQ2NC41MDI1MDMyOmY2OGFhZTNjLWZiYzMtMTFlYi1iZWM3LTAyNDJhYzE
  07:21:07.148 [mobservice1] INFO info f8324592-fbc3-11eb-b54d-0242ac110004:CfHjswnr write success
  07:21:09.783 [dbservice2] INFO f9a9d4ee-fbc3-11eb-aadd-0242ac110004-wRjEsaDr-6yOCQJ=RzT1( token generate success token=MTYyODgxMDQ2OS43ODI2Mzc4OmY5YTlkNGVlLWZiYzMtMTFlYi1hYWRkLTAyNDJhYzE
  07:21:12.184 [dbservice1] INFO fb19d432-fbc3-11eb-a965-0242ac110004-OSENDWPb-6)hw=<r&R9.T token generate success token=MTYyODgxMDQ3Mi4xODQxMzpmYjE5ZDQzMi1mYmMzLTExZWItYTk2NS0wMjQyYWMxMTA
  07:21:14.565 [dbservice2] INFO fc89199a-fbc3-11eb-836d-0242ac110003-CxaURntJ-FQ4_E#@RDnS. token generate success token=MTYyODgxMDQ3NC41NjUwNDU0OmZjODkxOTlhLWZiYzMtMTFlYi04MzZkLTAyNDJhYzE
  07:21:17.087 [dbservice2] INFO fdff37be-fbc3-11eb-bf7d-0242ac110004-lESgOeYC-FB)bO>ocNqeu token generate success token=MTYyODgxMDQ3Ny4wODY2MTU2OmZkZmYzN2JlLWZiYzMtMTFlYi1iZjdkLTAyNDJhYzE
  07:21:19.286 [mobservice2] INFO info ff8bb012-fbc3-11eb-90a3-0242ac110004:ahqTsjZo write success
  07:21:21.947 [mobservice2] INFO info 0127ee18-fbc4-11eb-990f-0242ac110003:ceZjduVy write success
  07:21:24.671 [mobservice1] INFO info 02b57a70-fbc4-11eb-928f-0242ac110003:YDlFxnqQ write success
  07:21:27.512 [dbservice1] INFO 043ae27c-fbc4-11eb-b82d-0242ac110003-gKUmCyre-YL:T*me_uhSJ token generate success token=MTYyODgxMDQ4Ny41MTIxODMyOjA0M2FlMjdjLWZiYzQtMTFlYi1iODJkLTAyNDJhYzE
  07:21:30.037 [dbservice2] INFO 05c3e8dc-fbc4-11eb-9985-0242ac110003-vYsiTgru-E1o_Qp_rKU/% token generate success token=MTYyODgxMDQ5MC4wMzY5Nzg1OjA1YzNlOGRjLWZiYzQtMTFlYi05OTg1LTAyNDJhYzE
  07:21:36.072 [dbservice2] INFO 095414ae-fbc4-11eb-9b87-0242ac110003-GiuNzrvJ-YnTciU0WR&3p token generate success token=MTYyODgxMDQ5Ni4wNzIwNDIyOjA5NTQxNGFlLWZiYzQtMTFlYi05Yjg3LTAyNDJhYzE
  07:21:39.201 [dbservice1] INFO 0b27bbd2-fbc4-11eb-b465-0242ac110004-rJNyXqRj-p$^%8M<usL@t token generate success token=MTYyODgxMDQ5OS4yMDA2MzYxOjBiMjdiYmQyLWZiYzQtMTFlYi1iNDY1LTAyNDJhYzE
  07:21:41.892 [dbservice1] INFO 0cafa186-fbc4-11eb-911a-0242ac110004-SzfIWpZE-{_HV.}LO^GnA token generate success token=MTYyODgxMDUwMS44OTE4NTE6MGNhZmExODYtZmJjNC0xMWViLTkxMWEtMDI0MmFjMTE
  07:21:44.916 [mobservice1] INFO info 0ec1ce72-fbc4-11eb-9520-0242ac110004:JkvHOUxm write success
  07:21:47.781 [dbservice1] INFO 10453450-fbc4-11eb-b082-0242ac110004-jnAxEKot-^>lh?1b+3#G* token generate success token=MTYyODgxMDUwNy43ODA4ODA1OjEwNDUzNDUwLWZiYzQtMTFlYi1iMDgyLTAyNDJhYzE
  07:21:50.303 [mobservice1] INFO info 11fc588c-fbc4-11eb-814b-0242ac110004:ciMhOCvb write success
  07:21:52.762 [dbservice1] INFO 134d26b2-fbc4-11eb-8ae6-0242ac110003-URvXGzml-*5)F@m4bJeLU token generate success token=MTYyODgxMDUxMi43NjI1MjQ2OjEzNGQyNmIyLWZiYzQtMTFlYi04YWU2LTAyNDJhYzE
  07:21:56.026 [mobservice2] INFO info 1572f0ac-fbc4-11eb-b076-0242ac110003:pSzgtGmR write success
  07:21:59.227 [mobservice1] INFO info 174dca28-fbc4-11eb-adfb-0242ac110004:wyIESLrY write success

## p0102
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T05:06:04.822Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731906364822660400,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-sd8v2","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  05:06:03.930 [currencyservice] conversion request successful  (×13)
  05:06:04.083 [currencyservice] Getting supported currencies...  (×7)
All services, 30 seconds either side (sampled):
  05:05:35.059 [frontend] request started  (×298)
  05:05:35.069 [cartservice] GetCartAsync called with userId=acc735c5-72d0-48e6-b237-46a63eac4c4d  (×246)
  05:05:35.094 [adservice] received ad request (context_words=[clothing, tops])  (×16)
  05:05:35.316 [cartservice] AddItemAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58, productId=66VCHSJNUP, quantity=4  (×27)
  05:05:35.333 [frontend] home  (×46)
  05:05:35.445 [frontend] ENV_PLATFORM is: aws  (×46)
  05:05:37.831 [adservice] received ad request (context_words=[kitchen])  (×52)
  05:05:39.880 [adservice] received ad request (context_words=[accessories])  (×20)
  05:05:43.904 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="USD"  (×8)
  05:05:43.950 [checkoutservice] payment went through (transaction_id: ea32a64b-109f-44d7-8f42-0007e17d8b26)  (×10)
  05:05:43.955 [cartservice] EmptyCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53  (×10)
  05:05:43.964 [frontend] order placed  (×10)
  05:05:51.640 [frontend] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13
  05:05:51.663 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"854","nanos":982906680},"credit_card":{"credit_card_number":"48444530783364
  05:05:51.663 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  05:05:52.043 [redis] 1:M 18 Nov 2024 05:05:52.043 * Background saving started by pid 47
  05:05:52.145 [redis] 1:M 18 Nov 2024 05:05:52.144 * Background saving terminated with success
  05:05:52.522 [paymentservice] Transaction processed: visa ending 2457 Amount: EUR565.165855819
  05:06:04.238 [emailservice] A request to send order confirmation email to michaelacosta@example.net has been received.
  05:06:07.915 [checkoutservice] order confirmation email sent to "cwilson@example.com"
  05:06:12.430 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="JPY"
  05:06:12.471 [emailservice] A request to send order confirmation email to leenathaniel@example.org has been received.
  05:06:22.119 [emailservice] A request to send order confirmation email to langreginald@example.org has been received.
  05:06:24.824 [checkoutservice] order confirmation email sent to "owright@example.net"

## p0649
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-11T01:34:51.500Z
```
{"service":"dbservice1","message":"2021-08-11 01:34:51,500 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | c3788d3f4b2cf8d6 | 43fd59fe-fa01-11eb-a6c4-0242ac110004-DjXaKYNR-/Q*Yd=S2X37R token generate success token=MTYyODYxNjg5MS40OTk5MjA2OjQzZmQ1OWZlLWZhMDEtMTFlYi1hNmM0LTAyNDJhYzExMDAwNERqWGFLWU5SL1EqWWQ9UzJYMzdSOjE2Mjg2MTY5NTEuNDk5OTMxMzo4NGNkZTE5MjNhYjMzNjM1YjUwNjhlYjI0YmU4OGRkYQ=="}
```
Same service, the 2 minutes before (oldest first):
  01:34:45.457 [dbservice1] INFO 405fc160-fa01-11eb-a9e7-0242ac110004-vUGVxSct-oE/Qs.WM!UC< token generate success token=MTYyODYxNjg4NS40NTcwNTQxOjQwNWZjMTYwLWZhMDEtMTFlYi1hOWU3LTAyNDJhYzE
  01:34:46.168 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  01:34:46.168 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  01:34:46.225 [dbservice1] INFO query = select passwards from username_table where user_name='wpOMLejE'  (×5)
  01:34:46.301 [dbservice1] INFO 40e5c940-fa01-11eb-a9fb-0242ac110003-wpOMLejE-clXe.MWn<NK^ token generate success token=MTYyODYxNjg4Ni4zMDA2ODAyOjQwZTVjOTQwLWZhMDEtMTFlYi1hOWZiLTAyNDJhYzE
  01:34:48.135 [dbservice1] INFO 41e93994-fa01-11eb-9aa3-0242ac110004-hsWGAMiu-TpvY4Uf=Ir0S token generate success token=MTYyODYxNjg4OC4xMzQ2Mjc6NDFlOTM5OTQtZmEwMS0xMWViLTlhYTMtMDI0MmFjMTE
  01:34:50.687 [dbservice1] INFO 437caf70-fa01-11eb-a804-0242ac110003-SbjCGNIe-I{}FNyGTP5E7 token generate success token=MTYyODYxNjg5MC42ODY4MTM0OjQzN2NhZjcwLWZhMDEtMTFlYi1hODA0LTAyNDJhYzE
  01:34:50.958 [dbservice1] INFO 43afff2e-fa01-11eb-9603-0242ac110003-JjOStLkT-_GA<:4K/vjX@ token generate success token=MTYyODYxNjg5MC45NTg1MTg1OjQzYWZmZjJlLWZhMDEtMTFlYi05NjAzLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  01:34:21.518 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  01:34:21.604 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '326ac064-fa01-11eb-903e-0242ac110004', 'value': 'VwxKRfZB'}  (×43)
  01:34:21.736 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '326ac064-fa01-11eb-903e-0242ac110004'}  (×39)
  01:34:21.803 [redisservice1] INFO redis读取信息成功, status_code: 200  (×36)
  01:34:21.874 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×46)
  01:34:22.170 [redisservice2] INFO redis读取信息成功, status_code: 200  (×46)
  01:34:22.525 [mobservice2] INFO info 32f17a96-fa01-11eb-b780-0242ac110003:ISmxpnEs write success
  01:34:23.607 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×43)
  01:34:23.992 [webservice2] INFO uuid: 33fa8e00-fa01-11eb-b1bb-0242ac110004 write redis successfully  (×41)
  01:34:25.313 [dbservice1] INFO 345e7924-fa01-11eb-a7e7-0242ac110003-hpcKRNdx-E5o4m%SA(zhR token generate success token=MTYyODYxNjg2NS4zMTI2NDc4OjM0NWU3OTI0LWZhMDEtMTFlYi1hN2U3LTAyNDJhYzE
  01:34:35.209 [mobservice2] INFO info 3a8353b0-fa01-11eb-982d-0242ac110003:LKtqBVoF write success
  01:34:37.058 [dbservice2] INFO 3b736166-fa01-11eb-96f6-0242ac110004-lESgOeYC-FB)bO>ocNqeu token generate success token=MTYyODYxNjg3Ny4wNTgxNTM0OjNiNzM2MTY2LWZhMDEtMTFlYi05NmY2LTAyNDJhYzE
  01:34:39.497 [dbservice2] INFO 3cd982ec-fa01-11eb-b11f-0242ac110003-GsgASzin-v47{KN&<nj-h token generate success token=MTYyODYxNjg3OS40OTcxNTczOjNjZDk4MmVjLWZhMDEtMTFlYi1iMTFmLTAyNDJhYzE
  01:34:41.677 [mobservice1] INFO info 3e585e68-fa01-11eb-b4a8-0242ac110003:xgpqRfCn write success
  01:34:43.736 [dbservice2] INFO 3f60a5c2-fa01-11eb-a8c8-0242ac110004-nuXjsHUb-@8.+B_ezYn70 token generate success token=MTYyODYxNjg4My43MzU4NzI1OjNmNjBhNWMyLWZhMDEtMTFlYi1hOGM4LTAyNDJhYzE
  01:34:45.917 [mobservice2] INFO info 40e5c940-fa01-11eb-a9fb-0242ac110003:wpOMLejE write success
  01:34:49.795 [dbservice2] INFO 42fb4f34-fa01-11eb-ba36-0242ac110003-ISXlWuVn-?S9Cz:ye75_r token generate success token=MTYyODYxNjg4OS43OTUyNzo0MmZiNGYzNC1mYTAxLTExZWItYmEzNi0wMjQyYWMxMTA
  01:34:52.292 [dbservice2] INFO 447b2da2-fa01-11eb-8aa3-0242ac110004-bLKvfOjH-dhLSRU@?#%CE token generate success token=MTYyODYxNjg5Mi4yOTIyNzc6NDQ3YjJkYTItZmEwMS0xMWViLThhYTMtMDI0MmFjMTE
  01:34:54.270 [mobservice2] INFO info 45e42680-fa01-11eb-a767-0242ac110004:XrSheKyp write success
  01:34:56.505 [dbservice2] INFO 47035fae-fa01-11eb-9802-0242ac110004-HytkEBDf-z?M!i}>8wU$F token generate success token=MTYyODYxNjg5Ni41MDU0MDc2OjQ3MDM1ZmFlLWZhMDEtMTFlYi05ODAyLTAyNDJhYzE
  01:34:59.261 [dbservice2] INFO 48ac13f0-fa01-11eb-945f-0242ac110003-mcHMEOjb-kSRgwoq.+VGj token generate success token=MTYyODYxNjg5OS4yNjEzMzc1OjQ4YWMxM2YwLWZhMDEtMTFlYi05NDVmLTAyNDJhYzE
  01:35:01.969 [mobservice2] INFO info 4a78ebae-fa01-11eb-b7c3-0242ac110004:IQZdkFax write success
  01:35:04.297 [mobservice1] INFO info 4bd2dabe-fa01-11eb-88ca-0242ac110004:FuZbUPph write success
  01:35:06.255 [dbservice1] INFO 4cccfe04-fa01-11eb-91fd-0242ac110004-rNfgkPxE-ZI78qlV2ts)U token generate success token=MTYyODYxNjkwNi4yNTQ5MjI5OjRjY2NmZTA0LWZhMDEtMTFlYi05MWZkLTAyNDJhYzE
  01:35:08.307 [mobservice2] INFO info 4e38dba0-fa01-11eb-9f7c-0242ac110004:gwdEDvWp write success
  01:35:10.842 [mobservice2] INFO info 4fb28b3e-fa01-11eb-8498-0242ac110004:sCbMprDF write success
  01:35:13.530 [dbservice2] INFO 511d3f32-fa01-11eb-b587-0242ac110004-AMFryZUz-jrK#m*:OpaoS token generate success token=MTYyODYxNjkxMy41MzA0MTk6NTExZDNmMzItZmEwMS0xMWViLWI1ODctMDI0MmFjMTE
  01:35:16.065 [mobservice2] INFO info 52dceeda-fa01-11eb-bc44-0242ac110004:vmFDrneJ write success
  01:35:19.394 [dbservice1] INFO 5499c2f2-fa01-11eb-be56-0242ac110003-eJFaBQoW-bScmY_uD{wZ* token generate success token=MTYyODYxNjkxOS4zOTQ0MzI1OjU0OTljMmYyLWZhMDEtMTFlYi1iZTU2LTAyNDJhYzE

## p0601
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T20:03:32.389Z
```
{"timestamp":1733601812389700900,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-f7tv2","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 20:03:32.389  INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl       : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50a90c90b04"}
```
Same service, the 2 minutes before (oldest first):
  20:03:31.164 [ts-travel2-service] 2024-12-07 20:03:31.164 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×2)
  20:03:31.164 [ts-travel2-service] 2024-12-07 20:03:31.164 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：9fc9c261-3263-4bfa-82f8-bb4  (×9)
  20:03:31.172 [ts-travel2-service] 2024-12-07 20:03:31.172 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×9)
All services, 30 seconds either side (sampled):
  20:03:02.391 [ts-route-service] 2024-12-07 20:03:02.391 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: a3f256c1-0e43-4f7d-9c21-121bf258101f  (×27)
  20:03:02.427 [ts-basic-service] 2024-12-07 20:03:02.427 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : route.getDistances().size : 3  (×27)
  20:03:02.556 [ts-travel-service] 2024-12-07 20:03:02.555 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1236  (×3)
  20:03:02.654 [ts-seat-service] 2024-12-07 20:03:02.654 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×24)
  20:03:02.962 [ts-travel-service] 2024-12-07 20:03:02.962 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×16)
  20:03:03.398 [ts-seat-service] 2024-12-07 20:03:03.398 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×3)
  20:03:04.472 [ts-auth-service] 2024-12-07 20:03:04.472 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×21)
  20:03:06.801 [ts-admin-basic-info-service] 2024-12-07 20:03:06.800 INFO 1 --- [io-18767-exec-2] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×8)
  20:03:09.246 [ts-auth-service] 2024-12-07 20:03:09.246 INFO 1 --- [io-12340-exec-1] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×13)
  20:03:09.603 [ts-travel2-service] 2024-12-07 20:03:09.603 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×11)
  20:03:09.780 [ts-seat-service] 2024-12-07 20:03:09.780 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×15)
  20:03:11.148 [ts-basic-service] 2024-12-07 20:03:11.148 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×7)
  20:03:11.527 [ts-food-service] 2024-12-07 20:03:11.527 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345
  20:03:12.091 [ts-preserve-service] 2024-12-07 20:03:12.091 INFO 1 --- [io-14568-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization completed in 102 m
  20:03:13.302 [ts-basic-service] 2024-12-07 20:03:13.302 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4
  20:03:13.903 [ts-security-service] 2024-12-07 20:03:13.903 INFO 1 --- [io-11188-exec-3] security.service.SecurityServiceImpl : [Security Service][Get Order Num Info]  (×2)
  20:03:13.992 [ts-preserve-service] 2024-12-07 20:03:13.992 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Find contacts  (×2)
  20:03:14.411 [ts-travel-service] 2024-12-07 20:03:14.411 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345  (×2)
  20:03:15.092 [ts-seat-service] 2024-12-07 20:03:15.092 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  20:03:15.586 [ts-seat-service] 2024-12-07 20:03:15.586 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService distributeSeat] The result of getRouteResult is Success  (×2)
  20:03:15.754 [ts-order-service] 2024-12-07 20:03:15.754 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : [Order Service][Order Create] Success.  (×2)
  20:03:16.458 [ts-preserve-service] 2024-12-07 20:03:16.458 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service][Add food Order] Creating....  (×2)
  20:03:18.071 [ts-order-service] 2024-12-07 20:03:18.071 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 69
  20:03:18.482 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:03:18 +0800] "PUT /api/v1/consignservice/consigns HTTP/1.1" 200 399 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebK
  20:03:30.508 [ts-travel2-service] 2024-12-07 20:03:30.508 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×2)
  20:03:30.785 [ts-auth-mongo] {"t":{"$date":"2024-12-07T20:03:30.784+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360181
  20:03:31.638 [ts-notification-mongo] {"t":{"$date":"2024-12-07T20:03:31.638+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360181
  20:03:42.749 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T20:03:42.749+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360182
  20:03:44.353 [ts-order-other-service] 2024-12-07 20:03:44.353 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou
  20:03:51.866 [ts-admin-travel-service] 2024-12-07 20:03:51.866 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]

## p0295
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:38:48.415Z
```
{"timestamp":1732243128415872000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Order: {\"customer\":\"http://user/customers/673feea7b0df5c00019b00db\",\"address\":\"http://user/addresses/673feeafb0df5c00019b00fa\",\"card\":\"http://user/cards/673feeafb0df5c00019b00fb\",\"items\":\"http://carts/carts/673feea7b0df5c00019b00db/items\"}"}
```
Same service, the 2 minutes before (oldest first):
  02:38:48.050 [front-end] POST /orders 201 - ms - -  (×2)
  02:38:48.343 [front-end] Request received with body: {}  (×2)
  02:38:48.344 [front-end] GET /catalogue 200 - ms - -
  02:38:48.349 [front-end] Received response: "{\"firstName\":\"NobBxH\",\"lastName\":\"NobBxH\",\"username\":\"NobBxH\",\"id\":\"673feea7b0df5c00019b00da\",\"_links\":{\"addresses\":{\"h
  02:38:48.349 [front-end] GET Request to: http://user/customers/673feea7b0df5c00019b00da/addresses  (×4)
  02:38:48.355 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×2)
  02:38:48.355 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673feeaeb0df5c00019b00f9\",\"_links\":{\"  (×2)
  02:38:48.355 [front-end] [ undefined, undefined ]  (×2)
  02:38:48.355 [front-end] Posting Order: {"customer":"http://user/customers/673feea7b0df5c00019b00da","address":"http://user/addresses/673feeaeb0df5c00019b00f8","card":"http://user/cards
  02:38:48.389 [front-end] Order response: {"statusCode":201,"body":{"id":"673feeb8d94b9000069b3c1a","customerId":"673feea7b0df5c00019b00da","customer":{"id":null,"firstName":"NobBxH","la
  02:38:48.389 [front-end] Order response: {"id":"673feeb8d94b9000069b3c1a","customerId":"673feea7b0df5c00019b00da","customer":{"id":null,"firstName":"NobBxH","lastName":"NobBxH","usernam
  02:38:48.409 [front-end] Received response: "{\"firstName\":\"QQPAMDR\",\"lastName\":\"QQPAMDR\",\"username\":\"QQPAMDR\",\"id\":\"673feea7b0df5c00019b00db\",\"_links\":{\"addresses\":{
All services, 30 seconds either side (sampled):
  02:38:18.859 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fee94b0df5c00019b009d"}  (×61)
  02:38:18.960 [front-end] POST to carts: http://carts/carts/673fee94b0df5c00019b009d/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}  (×25)
  02:38:19.037 [front-end] Sent cookies.  (×61)
  02:38:19.104 [user] ts=2024-11-22T02:38:19.104627847Z caller=middlewares.go:104 method=GetAddresses id=673fee8db0df5c00019b008d result=1 took=859.556µs  (×35)
  02:38:19.125 [user] ts=2024-11-22T02:38:19.125288399Z caller=middlewares.go:75 method=GetUsers id=673fee84b0df5c00019b0071 result=1 took=1.575783ms  (×43)
  02:38:19.568 [front-end] Received response: "{\"firstName\":\"XCYdmAXSWd\",\"lastName\":\"XCYdmAXSWd\",\"username\":\"XCYdmAXSWd\",\"id\":\"673fee86b0df5c00019b007a\",\"_links\":{\"addr
  02:38:20.561 [front-end] POST to carts: http://carts/carts/673fee92b0df5c00019b0099/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}  (×35)
  02:38:23.662 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×5)
  02:38:26.002 [front-end] Order response: {"id":"673feea1d94b9000069b3c06","customerId":"673fee90b0df5c00019b0096","customer":{"id":null,"firstName":"OTmchGTAvvrH","lastName":"OTmchGTAvv
  02:38:28.114 [front-end] Order response: {"id":"673feea4d94b9000069b3c09","customerId":"673fee93b0df5c00019b009c","customer":{"id":null,"firstName":"OvGNB","lastName":"OvGNB","username"
  02:38:29.433 [user] ts=2024-11-22T02:38:29.432931908Z caller=middlewares.go:46 method=Register username=zxtZkxtre email=zxtZkxtre@gmail.com took=958.313µs
  02:38:31.165 [front-end] Posting Customer: {"username":"QQPAMDR","password":"WQbIChvt","email":"QQPAMDR@gmail.com","firstName":"QQPAMDR","lastName":"QQPAMDR"}
  02:38:32.154 [front-end] Posting Customer: {"username":"bNsTpYYksHWYcK","password":"lBduIPdYg","email":"bNsTpYYksHWYcK@gmail.com","firstName":"bNsTpYYksHWYcK","lastName":"bNsTpYYksHWYcK
  02:38:34.905 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×2)
  02:38:39.014 [front-end] Received response: "{\"firstName\":\"gDbYYMHQ\",\"lastName\":\"gDbYYMHQ\",\"username\":\"gDbYYMHQ\",\"id\":\"673fee94b0df5c00019b009d\",\"_links\":{\"addresses\
  02:38:42.442 [front-end] Order response: {"id":"673feeb2d94b9000069b3c14","customerId":"673fee9bb0df5c00019b00b5","customer":{"id":null,"firstName":"flzgqYzlrTwM","lastName":"flzgqYzlrT
  02:38:44.050 [front-end] Received response: "{\"firstName\":\"uVapLGZrlWwgs\",\"lastName\":\"uVapLGZrlWwgs\",\"username\":\"uVapLGZrlWwgs\",\"id\":\"673fee9bb0df5c00019b00b7\",\"_links\
  02:38:48.048 [front-end] Order response: {"statusCode":201,"body":{"id":"673feeb8d94b9000069b3c19","customerId":"673feea5b0df5c00019b00d5","customer":{"id":null,"firstName":"LYBVAxYonZi
  02:38:48.916 [front-end] Order response: {"statusCode":201,"body":{"id":"673feeb8d94b9000069b3c1c","customerId":"673feea6b0df5c00019b00d8","customer":{"id":null,"firstName":"CMGACdVZn",
  02:38:51.873 [front-end] Received response: "{\"firstName\":\"yfgASniKQ\",\"lastName\":\"yfgASniKQ\",\"username\":\"yfgASniKQ\",\"id\":\"673feea4b0df5c00019b00cb\",\"_links\":{\"address
  02:38:53.940 [front-end] Order response: {"statusCode":201,"body":{"id":"673feebdd94b9000069b3c22","customerId":"673feea6b0df5c00019b00d9","customer":{"id":null,"firstName":"RCKDl","las
  02:38:57.425 [front-end] Posting Customer: {"username":"sMojXqzuOahx","password":"AuEzPUJueA","email":"sMojXqzuOahx@gmail.com","firstName":"sMojXqzuOahx","lastName":"sMojXqzuOahx"}
  02:39:00.406 [queue-master] 2024-11-22 02:39:00.406 ERROR 6 --- [pool-6-thread-4] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×9)
  02:39:03.552 [front-end] Order response: {"statusCode":201,"body":{"id":"673feec7d94b9000069b3c27","customerId":"673feeb3b0df5c00019b0106","customer":{"id":null,"firstName":"ZXnbyLGGAtM
  02:39:05.574 [front-end] Posting Customer: {"username":"PPaJbEFSSGI","password":"dWewe","email":"PPaJbEFSSGI@gmail.com","firstName":"PPaJbEFSSGI","lastName":"PPaJbEFSSGI"}
  02:39:08.957 [front-end] Received response: "{\"firstName\":\"MjKvVexducQS\",\"lastName\":\"MjKvVexducQS\",\"username\":\"MjKvVexducQS\",\"id\":\"673feeb7b0df5c00019b010d\",\"_links\":{
  02:39:13.899 [front-end] Posting Customer: {"username":"jRrQaFFegy","password":"IsKAyv","email":"jRrQaFFegy@gmail.com","firstName":"jRrQaFFegy","lastName":"jRrQaFFegy"}
  02:39:16.670 [front-end] Received response: "{\"firstName\":\"QSPotKykQ\",\"lastName\":\"QSPotKykQ\",\"username\":\"QSPotKykQ\",\"id\":\"673feebab0df5c00019b0116\",\"_links\":{\"address

## p0193
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T06:51:14.755Z
```
{"timestamp":1731912674755039500,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Getting supported currencies..."}
```
Same service, the 2 minutes before (oldest first):
  06:51:12.823 [currencyservice] Getting supported currencies...  (×6)
  06:51:12.854 [currencyservice] conversion request successful  (×14)
All services, 30 seconds either side (sampled):
  06:50:44.756 [currencyservice] conversion request successful  (×696)
  06:50:44.764 [frontend] request complete  (×329)
  06:50:45.023 [currencyservice] Getting supported currencies...  (×271)
  06:50:45.051 [adservice] received ad request (context_words=[hair, beauty])  (×24)
  06:50:45.070 [frontend] view user cart  (×74)
  06:50:45.171 [adservice] received ad request (context_words=[footwear])  (×17)
  06:50:45.666 [adservice] received ad request (context_words=[accessories])  (×32)
  06:50:49.719 [adservice] received ad request (context_words=[clothing, tops])  (×19)
  06:50:49.813 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"980","nanos":60353845},"credit_card":{"credit_card_number":"453718884467291  (×3)
  06:50:49.817 [shippingservice] [ShipOrder] received request  (×12)
  06:50:49.827 [emailservice] A request to send order confirmation email to xeverett@example.org has been received.
  06:50:51.179 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="GBP"  (×2)
  06:50:51.227 [emailservice] A request to send order confirmation email to egomez@example.com has been received.
  06:50:59.576 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="USD"  (×2)
  06:50:59.617 [emailservice] A request to send order confirmation email to matthewscharles@example.com has been received.
  06:51:04.759 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="EUR"
  06:51:04.813 [emailservice] A request to send order confirmation email to wward@example.com has been received.
  06:51:13.058 [redis] 1:M 18 Nov 2024 06:51:13.058 * Background saving started by pid 68
  06:51:13.159 [redis] 1:M 18 Nov 2024 06:51:13.159 * Background saving terminated with success
  06:51:23.111 [checkoutservice] [PlaceOrder] user_id="5e004f2d-a61a-45b2-840d-6bfd47a2be43" user_currency="JPY"  (×2)
  06:51:23.152 [emailservice] A request to send order confirmation email to lindatownsend@example.com has been received.
  06:51:26.415 [checkoutservice] order confirmation email sent to "natasha78@example.net"
  06:51:30.843 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="CAD"  (×2)
  06:51:30.886 [emailservice] A request to send order confirmation email to jeff23@example.net has been received.
  06:51:31.920 [checkoutservice] order confirmation email sent to "nicholas06@example.org"
  06:51:34.871 [checkoutservice] order confirmation email sent to "jonathanbonilla@example.net"

## p0222
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T07:49:19.564Z
```
{"timestamp":1731916159564172500,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  07:49:18.676 [currencyservice] Getting supported currencies...  (×5)
  07:49:18.686 [currencyservice] conversion request successful  (×15)
All services, 30 seconds either side (sampled):
  07:48:49.564 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', 'OLJCESPC7Z', '9SIQT8TOJO', 'LS4PSXUNUM', '66VCHSJNUP']  (×234)
  07:48:50.281 [frontend] request started  (×331)
  07:48:50.289 [cartservice] GetCartAsync called with userId=adf41e5f-12f6-4c40-88a0-a1bcf421e416  (×275)
  07:48:50.328 [adservice] received ad request (context_words=[decor, home])  (×20)
  07:48:50.491 [cartservice] AddItemAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b, productId=6E92ZMYYFZ, quantity=6  (×36)
  07:48:50.526 [shippingservice] [GetQuote] completed request  (×80)
  07:48:51.075 [frontend] placing order  (×12)
  07:48:51.121 [paymentservice] Transaction processed: visa ending 8743 Amount: USD1679.890000000  (×2)
  07:48:51.124 [shippingservice] [ShipOrder] completed request  (×12)
  07:48:51.137 [checkoutservice] order confirmation email sent to "ybrown@example.org"
  07:48:51.699 [frontend] ENV_PLATFORM is: aws  (×38)
  07:49:00.526 [checkoutservice] [PlaceOrder] user_id="fd2169a6-17e7-4d0e-9b57-1a8b67c1ae1a" user_currency="EUR"  (×7)
  07:49:00.560 [emailservice] A request to send order confirmation email to erik67@example.com has been received.
  07:49:05.969 [emailservice] A request to send order confirmation email to kimrodriguez@example.com has been received.
  07:49:07.264 [checkoutservice] order confirmation email sent to "karenli@example.org"
  07:49:16.531 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '66VCHSJNUP', '6E92ZMYYFZ', '0PUK6V6EV0']  (×3)
  07:49:18.545 [emailservice] A request to send order confirmation email to johnhill@example.com has been received.
  07:49:23.762 [checkoutservice] order confirmation email sent to "jordan06@example.org"
  07:49:36.072 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="GBP"  (×2)
  07:49:36.109 [emailservice] A request to send order confirmation email to aaron90@example.net has been received.
  07:49:39.755 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"100713","nanos":15480938},"credit_card":{"credit_card_number":"435419626916
  07:49:39.769 [checkoutservice] order confirmation email sent to "david88@example.net"

## p0723
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-14T17:50:50.502Z
```
{"service":"mobservice2","message":"2021-08-14 17:50:50,502 | INFO | 0.0.0.4 | 172.17.0.2 | mobservice2 | f6e0c6396447c973 | info 1b56b734-fce5-11eb-bb2e-0242ac110003:sjignBZH write success"}
```
Same service, the 2 minutes before (oldest first):
  17:50:47.050 [mobservice2] INFO info 1941e13a-fce5-11eb-927f-0242ac110004:MSLIBsQD write success
  17:50:48.338 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  17:50:48.338 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  17:50:48.339 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '1a1c5310-fce5-11eb-823f-0242ac110003'}  (×4)
  17:50:48.399 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '1a1c5310-fce5-11eb-823f-0242ac110003', 'value': 'pDXcZzKl'}  (×4)
  17:50:48.442 [mobservice2] INFO info 1a1c5310-fce5-11eb-823f-0242ac110003:pDXcZzKl write success
  17:50:48.779 [mobservice2] INFO info 1a50944a-fce5-11eb-a7cb-0242ac110004:TEzNtqXJ write success
  17:50:49.698 [mobservice2] INFO info 1ad96c48-fce5-11eb-ad25-0242ac110004:QvNLTxkS write success
All services, 30 seconds either side (sampled):
  17:50:20.527 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×50)
  17:50:20.901 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×56)
  17:50:20.969 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '0991036a-fce5-11eb-89a4-0242ac110004', 'user_id': 'ydDVPRrH'}  (×92)
  17:50:21.210 [dbservice2] INFO 0991036a-fce5-11eb-89a4-0242ac110004-ydDVPRrH-K>1}?T{_&NHS token generate success token=MTYyODkzNDYyMS4yMTAwNjg6MDk5MTAzNmEtZmNlNS0xMWViLTg5YTQtMDI0MmFjMTE
  17:50:21.453 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×52)
  17:50:21.975 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  17:50:22.329 [mobservice1] INFO info 0a91643a-fce5-11eb-8ca8-0242ac110003:WILFvAUY write success
  17:50:22.609 [logservice2] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×36)
  17:50:24.598 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×2)
  17:50:27.056 [dbservice2] INFO 0d1bfd28-fce5-11eb-a3a2-0242ac110004-vEGoarin-aD/}1_Q-2%xq token generate success token=MTYyODkzNDYyNy4wNTU3MTU6MGQxYmZkMjgtZmNlNS0xMWViLWEzYTItMDI0MmFjMTE
  17:50:29.482 [dbservice1] INFO 0e919f5a-fce5-11eb-adcb-0242ac110003-iBnyvbLP-R$>:BM4<a*@! token generate success token=MTYyODkzNDYyOS40ODE3Mjk1OjBlOTE5ZjVhLWZjZTUtMTFlYi1hZGNiLTAyNDJhYzE
  17:50:32.335 [dbservice1] INFO 104e2944-fce5-11eb-8ef3-0242ac110003-wgzbfODa-i2wL_t/)#Cy> token generate success token=MTYyODkzNDYzMi4zMzUwNjQ2OjEwNGUyOTQ0LWZjZTUtMTFlYi04ZWYzLTAyNDJhYzE
  17:50:34.974 [dbservice1] INFO 11d55daa-fce5-11eb-89d7-0242ac110003-rapsGDTF-+o8Wb{j4#H@n token generate success token=MTYyODkzNDYzNC45NzQyODg1OjExZDU1ZGFhLWZjZTUtMTFlYi04OWQ3LTAyNDJhYzE
  17:50:37.416 [dbservice1] INFO 13544826-fce5-11eb-8d34-0242ac110003-yNHlLvWp-eoafKh(T>NMD token generate success token=MTYyODkzNDYzNy40MTY1OTgzOjEzNTQ0ODI2LWZjZTUtMTFlYi04ZDM0LTAyNDJhYzE
  17:50:40.209 [webservice1] ERROR an error occurred in the downstream service
  17:50:42.901 [mobservice1] INFO info 16d281f2-fce5-11eb-91bf-0242ac110003:tJwGvlrd write success
  17:50:45.535 [mobservice1] INFO info 18622e0a-fce5-11eb-b007-0242ac110004:uGrcWJOt write success
  17:50:48.427 [dbservice2] INFO 19ccc17e-fce5-11eb-bf68-0242ac110004-NGJTlZWq-Ke:g$c+JP/iq token generate success token=MTYyODkzNDY0OC40MjY4MDI5OjE5Y2NjMTdlLWZjZTUtMTFlYi1iZjY4LTAyNDJhYzE
  17:50:51.424 [mobservice2] INFO info 1bd1ef12-fce5-11eb-a4c6-0242ac110003:gEUZdcKS write success
  17:50:53.984 [mobservice2] INFO info 1d646986-fce5-11eb-8f94-0242ac110003:fQnPbvcw write success
  17:50:57.095 [mobservice2] INFO info 1f45a1ca-fce5-11eb-b2b9-0242ac110004:sEtBNqcf write success
  17:50:59.620 [mobservice2] INFO info 20cbdb4a-fce5-11eb-8008-0242ac110003:AdPXowjJ write success
  17:51:01.862 [mobservice1] INFO info 2223b6ac-fce5-11eb-a6e1-0242ac110004:HXuSgZPY write success
  17:51:04.439 [mobservice2] INFO info 23a65d22-fce5-11eb-ae2f-0242ac110003:DuxqVwXb write success
  17:51:07.276 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  17:51:09.757 [dbservice1] INFO 269afcc2-fce5-11eb-921c-0242ac110004-WYjcLizJ-pZYv_kf^:i!E token generate success token=MTYyODkzNDY2OS43NTc1MDc2OjI2OWFmY2MyLWZjZTUtMTFlYi05MjFjLTAyNDJhYzE
  17:51:12.331 [dbservice2] INFO 280b92ce-fce5-11eb-bb10-0242ac110003-piekgYwo-SN2Kb8qO&%Ye token generate success token=MTYyODkzNDY3Mi4zMzExMzY6MjgwYjkyY2UtZmNlNS0xMWViLWJiMTAtMDI0MmFjMTE
  17:51:15.051 [dbservice1] INFO 29b42e06-fce5-11eb-ae8b-0242ac110003-saHAJjFe-$p8NUBRnq{X< token generate success token=MTYyODkzNDY3NS4wNTA5MjE3OjI5YjQyZTA2LWZjZTUtMTFlYi1hZThiLTAyNDJhYzE
  17:51:17.639 [mobservice1] INFO info 2b8bf27c-fce5-11eb-b7a6-0242ac110003:bCtvogcT write success
  17:51:20.439 [dbservice1] INFO 2cf23086-fce5-11eb-9028-0242ac110003-kWPHSeaC-nKV<}+zw:Zk% token generate success token=MTYyODkzNDY4MC40MzkwNjg2OjJjZjIzMDg2LWZjZTUtMTFlYi05MDI4LTAyNDJhYzE

## p0693
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-12T11:16:57.372Z
```
{"service":"webservice2","message":"2021-08-12 11:16:57,372 | ERROR | 0.0.0.3 | 172.17.0.4 | webservice2 | b29f388454ba4c1a | an error occurred in the downstream service"}
```
Same service, the 2 minutes before (oldest first):
  11:16:54.971 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×3)
  11:16:54.971 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'bedb5e76-fb1b-11eb-bbce-0242ac110004', 'value': '', 'ex': 10}  (×3)
  11:16:55.014 [webservice2] INFO uuid: bedb5e76-fb1b-11eb-bbce-0242ac110004 write redis successfully  (×3)
  11:16:55.120 [webservice2] INFO complete information: {'uuid': 'bedb5e76-fb1b-11eb-bbce-0242ac110004', 'user_id': 'vOcCSRZA'}  (×3)
  11:16:55.127 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×3)
  11:16:55.128 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
  11:16:55.887 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
All services, 30 seconds either side (sampled):
  11:16:27.430 [webservice1] INFO complete information: {'uuid': 'ae57c666-fb1b-11eb-91ba-0242ac110003', 'user_id': 'KvpoNGOC'}  (×41)
  11:16:27.589 [redisservice1] INFO redis write success  (×78)
  11:16:27.748 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×49)
  11:16:28.183 [dbservice2] INFO ae57c666-fb1b-11eb-91ba-0242ac110003-KvpoNGOC-2{r-4./W3G&K token generate success token=MTYyODczODE4OC4xODMyOTY3OmFlNTdjNjY2LWZiMWItMTFlYi05MWJhLTAyNDJhYzE
  11:16:28.564 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'aeec7950-fb1b-11eb-84f0-0242ac110003', 'value': 'eHFMUigu'}  (×41)
  11:16:28.795 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×35)
  11:16:29.248 [dbservice1] INFO aeec7950-fb1b-11eb-84f0-0242ac110003-eHFMUigu-^7vWS:ROpGca token generate success token=MTYyODczODE4OS4yNDgyMjU6YWVlYzc5NTAtZmIxYi0xMWViLTg0ZjAtMDI0MmFjMTE
  11:16:29.568 [dbservice1] INFO af47a802-fb1b-11eb-a5be-0242ac110003-PVFHnXol-4ksJ2?fe(UZ- token generate success token=MTYyODczODE4OS41NjgzNDE3OmFmNDdhODAyLWZiMWItMTFlYi1hNWJlLTAyNDJhYzE
  11:16:32.091 [dbservice1] INFO b0cb17e0-fb1b-11eb-81a0-0242ac110004-oLiIBNFj-n?OKmV7pSb}: token generate success token=MTYyODczODE5Mi4wOTExNjA4OmIwY2IxN2UwLWZiMWItMTFlYi04MWEwLTAyNDJhYzE
  11:16:35.126 [dbservice2] INFO b275a40c-fb1b-11eb-95c1-0242ac110003-YKwDOXcq-^yVRxMeUlsTA token generate success token=MTYyODczODE5NS4xMjU2MTc1OmIyNzVhNDBjLWZiMWItMTFlYi05NWMxLTAyNDJhYzE  (×2)
  11:16:37.801 [dbservice1] INFO b42c520a-fb1b-11eb-b507-0242ac110004-lEKkjfpD-^a37_&?:CJeS token generate success token=MTYyODczODE5Ny44MDA4MTQ5OmI0MmM1MjBhLWZiMWItMTFlYi1iNTA3LTAyNDJhYzE
  11:16:40.193 [dbservice1] INFO b59627f6-fb1b-11eb-9d25-0242ac110004-HfPCXKQO-ko9a.361RV:P token generate success token=MTYyODczODIwMC4xOTMyNTQ6YjU5NjI3ZjYtZmIxYi0xMWViLTlkMjUtMDI0MmFjMTE
  11:16:42.835 [dbservice2] INFO b7044032-fb1b-11eb-a2f6-0242ac110003-SYUdXTMn-#?+cKu8b!U&_ token generate success token=MTYyODczODIwMi44MzQ3OTpiNzA0NDAzMi1mYjFiLTExZWItYTJmNi0wMjQyYWMxMTA
  11:16:46.072 [mobservice2] INFO info b9562f4e-fb1b-11eb-84cc-0242ac110003:MfgEVxGn write success
  11:16:49.568 [mobservice1] INFO info bb6637ca-fb1b-11eb-a032-0242ac110004:GNqpIFum write success
  11:16:52.410 [dbservice2] INFO bca37602-fb1b-11eb-aeaa-0242ac110003-QSNmqeTf-X!?shln-IxLw token generate success token=MTYyODczODIxMi40MTA1MjA2OmJjYTM3NjAyLWZiMWItMTFlYi1hZWFhLTAyNDJhYzE
  11:16:55.353 [mobservice2] INFO info bed75eb6-fb1b-11eb-bbf8-0242ac110003:JZinoGDa write success
  11:16:57.770 [mobservice2] INFO info c0530524-fb1b-11eb-86bf-0242ac110003:chfTZIqp write success
  11:17:00.344 [dbservice1] INFO c1a2c11c-fb1b-11eb-8857-0242ac110003-NEhHktDw-V3.Dx4)O+_o7 token generate success token=MTYyODczODIyMC4zNDM4MDQ6YzFhMmMxMWMtZmIxYi0xMWViLTg4NTctMDI0MmFjMTE
  11:17:03.802 [mobservice2] INFO info c3e74236-fb1b-11eb-a35b-0242ac110003:YaLWCkue write success
  11:17:06.418 [dbservice2] INFO c53bc526-fb1b-11eb-b64e-0242ac110003-JXejhiMl-97R5_3u8cLX? token generate success token=MTYyODczODIyNi40MTc3ODM6YzUzYmM1MjYtZmIxYi0xMWViLWI2NGUtMDI0MmFjMTE
  11:17:08.989 [webservice2] ERROR an error occurred in the downstream service
  11:17:12.346 [dbservice2] INFO c8be354e-fb1b-11eb-a50f-0242ac110003-qhdLCnSU-I!Hg(Dukw}{) token generate success token=MTYyODczODIzMi4zNDU4NTg6YzhiZTM1NGUtZmIxYi0xMWViLWE1MGYtMDI0MmFjMTE
  11:17:15.584 [dbservice1] INFO cab092a2-fb1b-11eb-a3aa-0242ac110003-TzNJoquC-HD=#x)&^AZ14 token generate success token=MTYyODczODIzNS41ODM3MDU3OmNhYjA5MmEyLWZiMWItMTFlYi1hM2FhLTAyNDJhYzE
  11:17:18.641 [mobservice2] INFO info ccc02706-fb1b-11eb-83aa-0242ac110004:jliMGRSf write success
  11:17:21.442 [mobservice2] INFO info ce6aec58-fb1b-11eb-b898-0242ac110004:QlZMgGXD write success
  11:17:24.501 [mobservice1] INFO info d041277c-fb1b-11eb-ba7c-0242ac110004:kuaemYbD write success

## p0281
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T02:31:23.872Z
```
{"timestamp":1732242683872401700,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T02:31:23.872236522Z caller=middlewares.go:75 method=GetUsers id=673fece5b0df5c00019afb6c result=1 took=836.819µs"}
```
Same service, the 2 minutes before (oldest first):
  02:31:21.228 [user] ts=2024-11-22T02:31:21.227889979Z caller=middlewares.go:75 method=GetUsers id=673fece0b0df5c00019afb5e result=1 took=860.988µs  (×5)
  02:31:21.245 [user] ts=2024-11-22T02:31:21.245683692Z caller=middlewares.go:134 method=GetCards id=673feceab0df5c00019afb75 result=1 took=985.48µs
  02:31:21.246 [user] ts=2024-11-22T02:31:21.246366739Z caller=middlewares.go:104 method=GetAddresses id=673feceab0df5c00019afb74 result=1 took=1.636738ms
  02:31:21.828 [user] ts=2024-11-22T02:31:21.827935239Z caller=middlewares.go:46 method=Register username=ljBGzv email=ljBGzv@gmail.com took=1.231688ms
  02:31:21.953 [user] ts=2024-11-22T02:31:21.95372347Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673fecefb0df5c00019afb8c took=1.66115ms  (×5)
  02:31:22.009 [user] ts=2024-11-22T02:31:22.009629164Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673fecefb0df5c00019afb8c took=1.831591ms  (×5)
  02:31:23.401 [user] ts=2024-11-22T02:31:23.401654688Z caller=middlewares.go:46 method=Register username=ImmnOylM email=ImmnOylM@gmail.com took=1.020248ms
  02:31:23.807 [user] ts=2024-11-22T02:31:23.806885599Z caller=middlewares.go:46 method=Register username=AQaPpqwnYfs email=AQaPpqwnYfs@gmail.com took=960.769µs
All services, 30 seconds either side (sampled):
  02:30:53.986 [front-end] Request received with body: {}  (×62)
  02:30:54.020 [payment] ts=2024-11-22T02:30:54Z caller=logging.go:29 method=Authorise result=true took=1.157µs  (×24)
  02:30:55.111 [catalogue] ts=2024-11-22T02:30:55Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=3.455488ms  (×58)
  02:30:55.425 [front-end] Attempting to add to cart: {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","quantity":1}  (×59)
  02:30:56.035 [front-end] { id: '673fece0b0df5c00019afb5e' }  (×63)
  02:30:56.557 [front-end] Order response: {"id":"673fece0d94b9000069b3a5d","customerId":"673fecccb0df5c00019afb23","customer":{"id":null,"firstName":"QFBhfSRAmMH","lastName":"QFBhfSRAmMH
  02:30:58.788 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732242658785,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×8)
  02:30:59.463 [front-end] Order response: {"statusCode":201,"body":{"id":"673fece3d94b9000069b3a5f","customerId":"673fecccb0df5c00019afb22","customer":{"id":null,"firstName":"fQTqPlne","
  02:31:01.929 [front-end] Received response: "{\"firstName\":\"WEppnbPG\",\"lastName\":\"WEppnbPG\",\"username\":\"WEppnbPG\",\"id\":\"673feccab0df5c00019afb1d\",\"_links\":{\"addresses\
  02:31:03.012 [queue-master] 2024-11-22 02:31:03.012 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×27)
  02:31:05.578 [front-end] Order response: {"statusCode":201,"body":{"id":"673fece9d94b9000069b3a66","customerId":"673fecd4b0df5c00019afb3b","customer":{"id":null,"firstName":"fJrGXut","l
  02:31:08.539 [front-end] Posting Customer: {"username":"RPeCrYXdEFvY","password":"CppRsHyMKD","email":"RPeCrYXdEFvY@gmail.com","firstName":"RPeCrYXdEFvY","lastName":"RPeCrYXdEFvY"}
  02:31:10.571 [user] ts=2024-11-22T02:31:10.571593445Z caller=middlewares.go:46 method=Register username=xkfFQx email=xkfFQx@gmail.com took=1.146979ms
  02:31:11.890 [user] ts=2024-11-22T02:31:11.890087344Z caller=middlewares.go:46 method=Register username=HlMKMqe email=HlMKMqe@gmail.com took=1.088039ms
  02:31:15.929 [user] ts=2024-11-22T02:31:15.928411557Z caller=middlewares.go:46 method=Register username=NMpguAn email=NMpguAn@gmail.com took=850.307µs
  02:31:18.626 [front-end] Received response: "{\"firstName\":\"QEBhPhFKZZi\",\"lastName\":\"QEBhPhFKZZi\",\"username\":\"QEBhPhFKZZi\",\"id\":\"673fece3b0df5c00019afb67\",\"_links\":{\"a
  02:31:21.280 [front-end] Order response: {"statusCode":201,"body":{"id":"673fecf9d94b9000069b3a74","customerId":"673fece0b0df5c00019afb5e","customer":{"id":null,"firstName":"rELSnLBjLXm
  02:31:24.689 [front-end] Received response: "{\"firstName\":\"ruMACnU\",\"lastName\":\"ruMACnU\",\"username\":\"ruMACnU\",\"id\":\"673fece2b0df5c00019afb63\",\"_links\":{\"addresses\":{
  02:31:27.630 [front-end] Order response: {"id":"673fecffd94b9000069b3a78","customerId":"673fece6b0df5c00019afb6e","customer":{"id":null,"firstName":"NFCojZFVmvjCT","lastName":"NFCojZFVm
  02:31:29.237 [front-end] Order response: {"id":"673fed01d94b9000069b3a7b","customerId":"673fecf2b0df5c00019afb91","customer":{"id":null,"firstName":"YwnXhYq","lastName":"YwnXhYq","usern
  02:31:31.879 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed03d94b9000069b3a7e","customerId":"673fecf1b0df5c00019afb8e","customer":{"id":null,"firstName":"RRzRe","las
  02:31:35.453 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed07d94b9000069b3a80","customerId":"673fecefb0df5c00019afb8c","customer":{"id":null,"firstName":"HlMKMqe","l
  02:31:38.901 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed0ad94b9000069b3a83","customerId":"673fecf4b0df5c00019afb9a","customer":{"id":null,"firstName":"jlUCnfetLhR
  02:31:41.433 [user] ts=2024-11-22T02:31:41.432888218Z caller=middlewares.go:46 method=Register username=CFJETHpar email=CFJETHpar@gmail.com took=1.036044ms
  02:31:43.265 [front-end] Order response: {"id":"673fed0fd94b9000069b3a88","customerId":"673fecf5b0df5c00019afb9c","customer":{"id":null,"firstName":"uRSGsjmlJoruR","lastName":"uRSGsjmlJ
  02:31:46.913 [front-end] Received response: "{\"firstName\":\"izracnuSkkp\",\"lastName\":\"izracnuSkkp\",\"username\":\"izracnuSkkp\",\"id\":\"673fed03b0df5c00019afbcd\",\"_links\":{\"a
  02:31:48.165 [front-end] Received response: "{\"firstName\":\"ffIqqRGdZ\",\"lastName\":\"ffIqqRGdZ\",\"username\":\"ffIqqRGdZ\",\"id\":\"673fed01b0df5c00019afbc9\",\"_links\":{\"address
  02:31:50.356 [user] ts=2024-11-22T02:31:50.341729043Z caller=middlewares.go:46 method=Register username=fWWoGEh email=fWWoGEh@gmail.com took=1.647791ms

## p0317
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:20:47.345Z
```
{"timestamp":1732245647345169000,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:20:47.344924911Z caller=middlewares.go:75 method=GetUsers id=673ff87ab0df5c00019b1ef7 result=1 took=735.933µs"}
```
Same service, the 2 minutes before (oldest first):
  03:20:42.698 [user] ts=2024-11-22T03:20:42.698434864Z caller=middlewares.go:75 method=GetUsers id=673ff871b0df5c00019b1eda result=1 took=1.000488ms  (×5)
  03:20:42.704 [user] ts=2024-11-22T03:20:42.704694233Z caller=middlewares.go:75 method=GetUsers id=673ff871b0df5c00019b1eda result=1 took=675.443µs  (×4)
  03:20:42.714 [user] ts=2024-11-22T03:20:42.714525504Z caller=middlewares.go:134 method=GetCards id=673ff879b0df5c00019b1ef6 result=1 took=1.049162ms
  03:20:42.714 [user] ts=2024-11-22T03:20:42.71459359Z caller=middlewares.go:104 method=GetAddresses id=673ff879b0df5c00019b1ef3 result=1 took=895.254µs  (×2)
  03:20:45.094 [user] ts=2024-11-22T03:20:45.093960066Z caller=middlewares.go:157 method=Health result=2 took=793.726µs  (×2)
  03:20:46.178 [user] ts=2024-11-22T03:20:46.17847517Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff884b0df5c00019b1f0d took=1.738227ms  (×2)
  03:20:46.191 [user] ts=2024-11-22T03:20:46.190922358Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff884b0df5c00019b1f0d took=1.709823ms  (×2)
  03:20:46.669 [user] ts=2024-11-22T03:20:46.668785629Z caller=middlewares.go:134 method=GetCards id=673ff87fb0df5c00019b1f02 result=1 took=775.182µs
  03:20:47.130 [user] ts=2024-11-22T03:20:47.130654611Z caller=middlewares.go:46 method=Register username=TeeRhkRKovrDpY email=TeeRhkRKovrDpY@gmail.com took=1.065358ms
All services, 30 seconds either side (sampled):
  03:20:17.365 [front-end] Posting Customer: {"username":"JPLuxMxilULRS","password":"WnbUsNRmg","email":"JPLuxMxilULRS@gmail.com","firstName":"JPLuxMxilULRS","lastName":"JPLuxMxilULRS"}
  03:20:17.841 [front-end] POST /addresses 200 - ms - -  (×63)
  03:20:17.900 [front-end] Posting Order: {"customer":"http://user/customers/673ff861b0df5c00019b1e9e","address":"http://user/addresses/673ff866b0df5c00019b1eab","card":"http://user/cards  (×58)
  03:20:17.959 [front-end] POST /orders 500 - ms - -  (×53)
  03:20:18.562 [front-end] Received response: "{\"firstName\":\"DqUKJjZwHbm\",\"lastName\":\"DqUKJjZwHbm\",\"username\":\"DqUKJjZwHbm\",\"id\":\"673ff85cb0df5c00019b1e90\",\"_links\":{\"a
  03:20:19.778 [user] ts=2024-11-22T03:20:19.778567514Z caller=middlewares.go:46 method=Register username=fSJlclyeT email=fSJlclyeT@gmail.com took=1.162628ms
  03:20:23.543 [front-end] Received response: "{\"firstName\":\"zGGJO\",\"lastName\":\"zGGJO\",\"username\":\"zGGJO\",\"id\":\"673ff863b0df5c00019b1ea3\",\"_links\":{\"addresses\":{\"href
  03:20:28.055 [front-end] Received response: "{\"firstName\":\"ihYowTIIUzglApd\",\"lastName\":\"ihYowTIIUzglApd\",\"username\":\"ihYowTIIUzglApd\",\"id\":\"673ff86bb0df5c00019b1ec4\",\"_
  03:20:31.505 [front-end] Posting Customer: {"username":"pPOWMtcwKJaePCn","password":"KHxGo","email":"pPOWMtcwKJaePCn@gmail.com","firstName":"pPOWMtcwKJaePCn","lastName":"pPOWMtcwKJaePCn
  03:20:34.372 [front-end] Received response: "{\"firstName\":\"CBhyKd\",\"lastName\":\"CBhyKd\",\"username\":\"CBhyKd\",\"id\":\"673ff869b0df5c00019b1eba\",\"_links\":{\"addresses\":{\"h
  03:20:38.070 [session-db] 1:M 22 Nov 2024 03:20:38.070 * Background saving started by pid 32
  03:20:41.483 [front-end] Posting Customer: {"username":"URVWiLVbByzZ","password":"qXaKAmwrnF","email":"URVWiLVbByzZ@gmail.com","firstName":"URVWiLVbByzZ","lastName":"URVWiLVbByzZ"}
  03:20:43.389 [carts] 2024-11-22 03:20:43.389 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
  03:20:48.449 [front-end] Received response: "{\"firstName\":\"dStkYebBky\",\"lastName\":\"dStkYebBky\",\"username\":\"dStkYebBky\",\"id\":\"673ff87eb0df5c00019b1efe\",\"_links\":{\"addr
  03:20:50.091 [carts] 2024-11-22 03:20:50.087 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class or
  03:20:54.561 [front-end] Posting Customer: {"username":"LNstXzKIIEKneJ","password":"NZVezpyHM","email":"LNstXzKIIEKneJ@gmail.com","firstName":"LNstXzKIIEKneJ","lastName":"LNstXzKIIEKneJ
  03:20:58.331 [front-end] Received response: "{\"firstName\":\"ELXzX\",\"lastName\":\"ELXzX\",\"username\":\"ELXzX\",\"id\":\"673ff887b0df5c00019b1f13\",\"_links\":{\"addresses\":{\"href
  03:20:59.689 [carts] 2024-11-22 03:20:59.689 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[application
  03:20:59.787 [carts] 2024-11-22 03:20:59.786 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[DE
  03:20:59.887 [carts] 2024-11-22 03:20:59.887 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframewor
  03:21:02.864 [front-end] Received response: "{\"firstName\":\"jVIVRgJfOAq\",\"lastName\":\"jVIVRgJfOAq\",\"username\":\"jVIVRgJfOAq\",\"id\":\"673ff88ab0df5c00019b1f20\",\"_links\":{\"a
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  03:21:04.427 [front-end] Posting Customer: {"username":"qklQL","password":"OfLCWzLJmr","email":"qklQL@gmail.com","firstName":"qklQL","lastName":"qklQL"}
  03:21:08.790 [carts] 2024-11-22 03:21:08.790 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  03:21:09.390 [carts] 2024-11-22 03:21:09.390 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering wi
  03:21:12.422 [user] ts=2024-11-22T03:21:12.422435342Z caller=middlewares.go:75 method=GetUsers id=673ff89bb0df5c00019b1f4c result=1 took=990µs
  03:21:14.190 [carts] 2024-11-22 03:21:14.190 INFO [carts,,,] 7 --- [p-nio-80-exec-3] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization complet
  03:21:16.231 [front-end] Posting Customer: {"username":"jStfWCKVIxuZsZx","password":"iRGdzUAo","email":"jStfWCKVIxuZsZx@gmail.com","firstName":"jStfWCKVIxuZsZx","lastName":"jStfWCKVIxuZ

## p0381
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:43:39.062Z
```
{"timestamp":1732247019062399700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST to carts: http://carts/carts/673ffde0b0df5c00019b2f70/items body: {\"itemId\":\"a0a4f044-b040-410d-8ead-4de0446aec7e\",\"unitPrice\":7.99}"}
```
Same service, the 2 minutes before (oldest first):
  03:43:38.557 [front-end] Request received with body: {}
  03:43:38.564 [front-end] Received response: "{\"firstName\":\"cABwWeDaGnbbR\",\"lastName\":\"cABwWeDaGnbbR\",\"username\":\"cABwWeDaGnbbR\",\"id\":\"673ffdd9b0df5c00019b2f5c\",\"_links\
  03:43:38.564 [front-end] GET Request to: http://user/customers/673ffdd9b0df5c00019b2f5c/addresses  (×2)
  03:43:38.571 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:43:38.571 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffde2b0df5c00019b2f78\",\"_links\":{\"
  03:43:38.571 [front-end] [ undefined, undefined ]
  03:43:38.571 [front-end] Posting Order: {"customer":"http://user/customers/673ffdd9b0df5c00019b2f5c","address":"http://user/addresses/673ffde2b0df5c00019b2f77","card":"http://user/cards
  03:43:38.607 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdead94b9000069b47ce","customerId":"673ffdd9b0df5c00019b2f5c","customer":{"id":null,"firstName":"cABwWeDaGnb
  03:43:38.607 [front-end] Order response: {"id":"673ffdead94b9000069b47ce","customerId":"673ffdd9b0df5c00019b2f5c","customer":{"id":null,"firstName":"cABwWeDaGnbbR","lastName":"cABwWeDaG
  03:43:38.611 [front-end] POST /orders 201 - ms - -
  03:43:38.956 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffde0b0df5c00019b2f70"}
  03:43:38.965 [front-end] POST /addresses 200 - ms - -
  03:43:38.969 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffde0b0df5c00019b2f70"}
  03:43:38.978 [front-end] POST /cards 200 - ms - -
  03:43:39.028 [front-end] Attempting to delete cart for user: 673ffde0b0df5c00019b2f70
  03:43:39.046 [front-end] User cart deleted with status: 202
  03:43:39.048 [front-end] DELETE /cart 202 - ms - -
  03:43:39.055 [front-end] Attempting to add to cart: {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  03:43:39.062 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca
All services, 30 seconds either side (sampled):
  03:43:09.094 [user] ts=2024-11-22T03:43:09.093809373Z caller=middlewares.go:157 method=Health result=2 took=765.301µs  (×35)
  03:43:09.915 [front-end] POST /register 200 29.430 ms - 33  (×60)
  03:43:10.065 [front-end] DELETE /cart 202 - ms - -  (×61)
  03:43:10.187 [user] ts=2024-11-22T03:43:10.186812016Z caller=middlewares.go:75 method=GetUsers id=673ffdb6b0df5c00019b2eef result=1 took=695.905µs  (×186)
  03:43:10.219 [queue-master] 2024-11-22 03:43:10.219 INFO 6 --- [pool-6-thread-5] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×13)
  03:43:11.482 [front-end] Posting Customer: {"username":"MSMhLESnSjGB","password":"GVeqUaKLs","email":"MSMhLESnSjGB@gmail.com","firstName":"MSMhLESnSjGB","lastName":"MSMhLESnSjGB"}
  03:43:13.465 [front-end] Posting Customer: {"username":"HcEIw","password":"RyMrvDQK","email":"HcEIw@gmail.com","firstName":"HcEIw","lastName":"HcEIw"}
  03:43:14.142 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732246994141,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×6)
  03:43:14.681 [front-end] Received response: "{\"firstName\":\"cTcvfQeN\",\"lastName\":\"cTcvfQeN\",\"username\":\"cTcvfQeN\",\"id\":\"673ffdc3b0df5c00019b2f0b\",\"_links\":{\"addresses\
  03:43:14.876 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdd2d94b9000069b47b6","customerId":"673ffdbdb0df5c00019b2efd","customer":{"id":null,"firstName":"xdBoNAXezKd
  03:43:21.802 [front-end] Order response: {"id":"673ffdd9d94b9000069b47b7","customerId":"673ffdc5b0df5c00019b2f0f","customer":{"id":null,"firstName":"KcWcQE","lastName":"KcWcQE","usernam
  03:43:23.354 [front-end] Order response: {"id":"673ffddbd94b9000069b47b9","customerId":"673ffdc8b0df5c00019b2f14","customer":{"id":null,"firstName":"IADshk","lastName":"IADshk","usernam
  03:43:24.693 [front-end] Order response: {"id":"673ffddcd94b9000069b47bc","customerId":"673ffdc4b0df5c00019b2f0c","customer":{"id":null,"firstName":"xUsGSNBIWfx","lastName":"xUsGSNBIWfx
  03:43:26.741 [front-end] Received response: "{\"firstName\":\"FjIBgpqiWYgXCEH\",\"lastName\":\"FjIBgpqiWYgXCEH\",\"username\":\"FjIBgpqiWYgXCEH\",\"id\":\"673ffdccb0df5c00019b2f28\",\"_
  03:43:27.726 [front-end] Order response: {"id":"673ffddfd94b9000069b47c3","customerId":"673ffdcfb0df5c00019b2f2e","customer":{"id":null,"firstName":"MSMhLESnSjGB","lastName":"MSMhLESnSj
  03:43:28.904 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffde0d94b9000069b47c6","customerId":"673ffdcfb0df5c00019b2f2f","customer":{"id":null,"firstName":"JAVeVHSdMPM
  03:43:30.177 [front-end] Posting Customer: {"username":"XNuYV","password":"MxMAzVdvI","email":"XNuYV@gmail.com","firstName":"XNuYV","lastName":"XNuYV"}
  03:43:35.418 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffde7d94b9000069b47cb","customerId":"673ffdd1b0df5c00019b2f36","customer":{"id":null,"firstName":"FajVymUhIEI
  03:43:38.607 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdead94b9000069b47ce","customerId":"673ffdd9b0df5c00019b2f5c","customer":{"id":null,"firstName":"cABwWeDaGnb
  03:43:41.125 [front-end] Order response: {"id":"673ffdedd94b9000069b47cf","customerId":"673ffdd9b0df5c00019b2f5d","customer":{"id":null,"firstName":"ZInGJmtxchcA","lastName":"ZInGJmtxch
  03:43:43.983 [front-end] Posting Customer: {"username":"bQfredqAcYcOqY","password":"LLhrpklD","email":"bQfredqAcYcOqY@gmail.com","firstName":"bQfredqAcYcOqY","lastName":"bQfredqAcYcOqY"
  03:43:45.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdf1d94b9000069b47d4","customerId":"673ffddab0df5c00019b2f60","customer":{"id":null,"firstName":"iTjkmy","la
  03:43:49.058 [front-end] Received response: "{\"firstName\":\"fSOCXj\",\"lastName\":\"fSOCXj\",\"username\":\"fSOCXj\",\"id\":\"673ffddfb0df5c00019b2f6f\",\"_links\":{\"addresses\":{\"h
  03:43:55.373 [user] ts=2024-11-22T03:43:55.373734243Z caller=middlewares.go:46 method=Register username=GjuVk email=GjuVk@gmail.com took=1.000861ms
  03:43:57.949 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffdfdd94b9000069b47da","customerId":"673ffdecb0df5c00019b2f90","customer":{"id":null,"firstName":"gDswpqcpGLC
  03:43:59.918 [front-end] Order response: {"id":"673ffdffd94b9000069b47dc","customerId":"673ffde5b0df5c00019b2f7f","customer":{"id":null,"firstName":"blIFvgmiWUwjwXc","lastName":"blIFvgm
  03:44:00.997 [front-end] Received response: "{\"firstName\":\"ijQFfEAgFfuvKzE\",\"lastName\":\"ijQFfEAgFfuvKzE\",\"username\":\"ijQFfEAgFfuvKzE\",\"id\":\"673ffdebb0df5c00019b2f8e\",\"_
  03:44:03.851 [user] ts=2024-11-22T03:44:03.851313703Z caller=middlewares.go:46 method=Register username=kuiliWxuq email=kuiliWxuq@gmail.com took=8.150698ms
  03:44:04.946 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffe04d94b9000069b47e5","customerId":"673ffdeeb0df5c00019b2f94","customer":{"id":null,"firstName":"GnUPBfIh","

## p0023
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice2, 2021-08-13T06:47:50.091Z
```
{"service":"redisservice2","message":"2021-08-13 06:47:50,091 | INFO | 0.0.0.2 | 172.17.0.4 | redisservice2 | 97eb9f5753530971 | redis读取信息成功, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  06:47:42.682 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×5)
  06:47:42.727 [redisservice2] INFO redis write success  (×7)
  06:47:42.837 [redisservice2] INFO redis读取信息成功, status_code: 200  (×5)
  06:47:42.969 [redisservice2] INFO service accept, status_code: 200  (×3)
All services, 30 seconds either side (sampled):
  06:47:20.106 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×35)
  06:47:20.172 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×35)
  06:47:20.258 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×35)
  06:47:20.402 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat  (×2)
  06:47:20.696 [webservice2] INFO complete information: {'uuid': '408f8f98-fbbf-11eb-b684-0242ac110004', 'user_id': 'tWMvxnLr'}  (×44)
  06:47:20.899 [mobservice1] INFO info 408f8f98-fbbf-11eb-b684-0242ac110004:tWMvxnLr write success
  06:47:22.050 [dbservice1] INFO query = select passwards from username_table where user_name='AZDazHog'  (×42)
  06:47:22.473 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×41)
  06:47:23.764 [dbservice1] INFO 420fe520-fbbf-11eb-ad6d-0242ac110003-PNmIMWHV-^@.oySAnw2TX token generate success token=MTYyODgwODQ0My43NjQwMDI2OjQyMGZlNTIwLWZiYmYtMTFlYi1hZDZkLTAyNDJhYzE
  06:47:26.285 [dbservice1] INFO 4386174e-fbbf-11eb-9bda-0242ac110003-bhmAUvxt-bl!-9=:e3B{F token generate success token=MTYyODgwODQ0Ni4yODUwOTQ3OjQzODYxNzRlLWZiYmYtMTFlYi05YmRhLTAyNDJhYzE
  06:47:29.156 [mobservice2] INFO info 45736782-fbbf-11eb-b987-0242ac110004:cqyYsFCP write success
  06:47:31.949 [dbservice2] INFO 46f05502-fbbf-11eb-b609-0242ac110003-lvCfjILw-D1@9U_jQh_$a token generate success token=MTYyODgwODQ1MS45NDkxNTY4OjQ2ZjA1NTAyLWZiYmYtMTFlYi1iNjA5LTAyNDJhYzE
  06:47:35.123 [mobservice2] INFO info 49066ad4-fbbf-11eb-b621-0242ac110003:rJyVYctH write success
  06:47:37.871 [mobservice1] INFO info 4a9f5496-fbbf-11eb-bbbb-0242ac110003:ITinMyWu write success
  06:47:42.760 [mobservice1] INFO info 4d9ac360-fbbf-11eb-a256-0242ac110004:HwOItPMW write success
  06:47:48.660 [dbservice2] INFO 50defb72-fbbf-11eb-87ef-0242ac110004-QNgzxusO-msv)gRlMu=0. token generate success token=MTYyODgwODQ2OC42NjAwMzczOjUwZGVmYjcyLWZiYmYtMTFlYi04N2VmLTAyNDJhYzE
  06:47:51.227 [mobservice1] INFO info 5299e508-fbbf-11eb-94ef-0242ac110003:bTPjsUVJ write success
  06:47:54.179 [mobservice1] INFO info 54622af8-fbbf-11eb-8425-0242ac110003:WfxvHjKb write success
  06:47:56.883 [dbservice2] INFO 55c8d05e-fbbf-11eb-a13c-0242ac110004-iBxJIdNQ-&20pUS%?J1T. token generate success token=MTYyODgwODQ3Ni44ODMwMzY0OjU1YzhkMDVlLWZiYmYtMTFlYi1hMTNjLTAyNDJhYzE
  06:47:59.338 [dbservice1] INFO 573c7ddc-fbbf-11eb-af54-0242ac110003-cmBuyeUK-ZNQ?-Mu}LOAT token generate success token=MTYyODgwODQ3OS4zMzgyMzIzOjU3M2M3ZGRjLWZiYmYtMTFlYi1hZjU0LTAyNDJhYzE
  06:48:02.001 [dbservice1] INFO 58c99f0e-fbbf-11eb-9c33-0242ac110003-RVxXNljY-cDs.FlES+XiZ token generate success token=MTYyODgwODQ4Mi4wMDA4NTY6NThjOTlmMGUtZmJiZi0xMWViLTljMzMtMDI0MmFjMTE
  06:48:04.572 [dbservice1] INFO 5a59bd0e-fbbf-11eb-b0d0-0242ac110004-NFBuWbaS-u*8p#x?OjmgL token generate success token=MTYyODgwODQ4NC41NzE4NjM6NWE1OWJkMGUtZmJiZi0xMWViLWIwZDAtMDI0MmFjMTE
  06:48:07.094 [dbservice1] INFO 5bda42e8-fbbf-11eb-9bc4-0242ac110004-WcUSzNAM-4Tvi5PF$026m token generate success token=MTYyODgwODQ4Ny4wOTQyNDY2OjViZGE0MmU4LWZiYmYtMTFlYi05YmM0LTAyNDJhYzE
  06:48:09.485 [dbservice2] INFO 5d57eb84-fbbf-11eb-999a-0242ac110004-lcIzRtym-stnKM@HiB>bU token generate success token=MTYyODgwODQ4OS40ODUzNDIzOjVkNTdlYjg0LWZiYmYtMTFlYi05OTlhLTAyNDJhYzE
  06:48:12.329 [mobservice2] INFO info 5f39823c-fbbf-11eb-a610-0242ac110003:zrFvXilR write success
  06:48:15.094 [dbservice1] INFO 60a605c8-fbbf-11eb-b37d-0242ac110004-rJNyXqRj-p$^%8M<usL@t token generate success token=MTYyODgwODQ5NS4wOTQ0OTk4OjYwYTYwNWM4LWZiYmYtMTFlYi1iMzdkLTAyNDJhYzE
  06:48:17.804 [dbservice1] INFO 622eec0c-fbbf-11eb-8cd1-0242ac110004-AwlIqmHD-pyw@uEvW-irk token generate success token=MTYyODgwODQ5Ny44MDQ0NDUzOjYyMmVlYzBjLWZiYmYtMTFlYi04Y2QxLTAyNDJhYzE

## p0488
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T08:57:04.660Z
```
{"timestamp":1732352224660331300,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:57:04.659  INFO [carts,94ab114f05b74586,86af6374d456ff34,false] 7 --- [-nio-80-exec-17] w.w.s.cart.controllers.CartsController   : Merge carts request received for ids: 674198e0a437380001deffae and 0ovW9Se8e_uIhe_smcESNGBvXMLuSeJm"}
```
Same service, the 2 minutes before (oldest first):
  08:56:59.506 [carts] 2024-11-23 08:56:59.506 INFO [carts,d9cfb38bd61f40a7,5f4c0d10fefd923d,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  08:56:59.512 [carts] 2024-11-23 08:56:59.512 INFO [carts,d9cfb38bd61f40a7,5f4c0d10fefd923d,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
  08:57:01.066 [carts] 2024-11-23 08:57:01.066 INFO [carts,b76309bd2270af6a,d0af7f0322dd666c,false] 7 --- [-nio-80-exec-17] w.w.s.cart.controllers.ItemsController : Did not find item.
  08:57:01.072 [carts] 2024-11-23 08:57:01.072 INFO [carts,b76309bd2270af6a,d0af7f0322dd666c,false] 7 --- [-nio-80-exec-17] w.w.s.cart.cart.CartContentsResource : Adding for user: Car
  08:57:01.169 [carts] 2024-11-23 08:57:01.169 INFO [carts,5c538ec146e63634,7af536729a4b5cfd,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.controllers.CartsController : Merge carts reques  (×2)
  08:57:03.870 [carts] 2024-11-23 08:57:03.869 INFO [carts,2acacf9129723beb,60cc2df2df2f4acf,false] 7 --- [-nio-80-exec-18] w.w.s.cart.controllers.CartsController : Merge carts reques
All services, 30 seconds either side (sampled):
  08:56:58.007 [catalogue] ts=2024-11-23T08:56:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.869902ms  (×39)
  08:56:58.018 [orders] 2024-11-23 08:56:58.018 INFO [orders,6baef7816fdf67ff,4dc9cbe9bd6cff45,false] 8 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Received payment re  (×28)
  08:56:58.029 [front-end] Order response: {"statusCode":201,"body":{"id":"674198da3f77060008865384","customerId":"674198bfa437380001deff45","customer":{"id":null,"firstName":"ztfESzW","l
  08:56:59.388 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674198d3a437380001deff98"}  (×35)
  08:56:59.483 [catalogue] ts=2024-11-23T08:56:59Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.990138  (×32)
  08:57:00.720 [front-end] Request received with body: {}  (×29)
  08:57:00.744 [front-end] Posting Order: {"customer":"http://user/customers/674198caa437380001deff7c","address":"http://user/addresses/674198d0a437380001deff90","card":"http://user/cards  (×29)
  08:57:01.048 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  08:57:01.165 [front-end] 674198dda437380001deffa9  (×37)
  08:57:02.787 [front-end] Received response: "{\"firstName\":\"iEYCUjoH\",\"lastName\":\"iEYCUjoH\",\"username\":\"iEYCUjoH\",\"id\":\"674198c5a437380001deff67\",\"_links\":{\"addresses\
  08:57:03.057 [front-end] Order response: {"statusCode":201,"body":{"id":"674198df3f77060008865387","customerId":"674198caa437380001deff7e","customer":{"id":null,"firstName":"qzkCXXFW","
  08:57:04.140 [front-end] Received response: "{\"firstName\":\"TlHaLWqJVqW\",\"lastName\":\"TlHaLWqJVqW\",\"username\":\"TlHaLWqJVqW\",\"id\":\"674198d0a437380001deff92\",\"_links\":{\"a
  08:57:05.392 [orders] 2024-11-23 08:57:05.392 INFO [orders,3c526066b205402a,acb1c0fc61191c83,false] 8 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×2)
  08:57:07.035 [front-end] Order response: {"statusCode":201,"body":{"id":"674198e33f7706000886538a","customerId":"674198caa437380001deff7d","customer":{"id":null,"firstName":"vidoaLMiMZn
  08:57:08.980 [queue-master] 2024-11-23 08:57:08.980 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×57)
  08:57:09.152 [front-end] Order response: {"id":"674198e53f7706000886538c","customerId":"674198d2a437380001deff95","customer":{"id":null,"firstName":"zUGYrCgol","lastName":"zUGYrCgol","u
  08:57:11.533 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×7)
  08:57:13.005 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  08:57:14.121 [front-end] Posting Customer: {"username":"JCYeKSjM","password":"MYIoBCiY","email":"JCYeKSjM@gmail.com","firstName":"JCYeKSjM","lastName":"JCYeKSjM"}
  08:57:15.678 [front-end] Order response: {"id":"674198eb3f7706000886538f","customerId":"674198cfa437380001deff8c","customer":{"id":null,"firstName":"FygEtnQmntW","lastName":"FygEtnQmntW
  08:57:18.424 [user] ts=2024-11-23T08:57:18.424838811Z caller=middlewares.go:46 method=Register username=bqLFOFtK email=bqLFOFtK@gmail.com took=2.548455ms
  08:57:19.305 [front-end] Received response: "{\"firstName\":\"aXWRmKRnN\",\"lastName\":\"aXWRmKRnN\",\"username\":\"aXWRmKRnN\",\"id\":\"674198d9a437380001deffa4\",\"_links\":{\"address
  08:57:22.096 [front-end] Posting Customer: {"username":"ErqkMC","password":"qwrMe","email":"ErqkMC@gmail.com","firstName":"ErqkMC","lastName":"ErqkMC"}
  08:57:24.110 [front-end] Order response: {"id":"674198f43f77060008865392","customerId":"674198dfa437380001deffad","customer":{"id":null,"firstName":"wqgJPHku","lastName":"wqgJPHku","use
  08:57:25.404 [front-end] Order response: {"id":"674198f53f77060008865393","customerId":"674198e2a437380001deffb0","customer":{"id":null,"firstName":"tVFCKe","lastName":"tVFCKe","usernam
  08:57:26.581 [front-end] Received response: "{\"firstName\":\"aQTVfKPpOQTV\",\"lastName\":\"aQTVfKPpOQTV\",\"username\":\"aQTVfKPpOQTV\",\"id\":\"674198e5a437380001deffb4\",\"_links\":{
  08:57:27.415 [front-end] Order response: {"statusCode":201,"body":{"id":"674198f73f77060008865398","customerId":"674198dda437380001deffa9","customer":{"id":null,"firstName":"eWMmgZPhWLI
  08:57:30.058 [front-end] Order response: {"id":"674198fa3f77060008865399","customerId":"674198e7a437380001deffbe","customer":{"id":null,"firstName":"bVfUCqC","lastName":"bVfUCqC","usern
  08:57:30.866 [front-end] Order response: {"statusCode":201,"body":{"id":"674198fa3f7706000886539b","customerId":"674198e9a437380001deffc1","customer":{"id":null,"firstName":"KHUge","las
  08:57:32.948 [front-end] Received response: "{\"firstName\":\"gaGGCw\",\"lastName\":\"gaGGCw\",\"username\":\"gaGGCw\",\"id\":\"674198e9a437380001deffc3\",\"_links\":{\"addresses\":{\"h

## p0806
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-08T09:15:54.593Z
```
{"timestamp":1733649354593602800,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h4k7r","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-08 09:15:54.593  INFO 1 --- [           main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a default PublishSubscribeChannel will be created."}
```
Same service, the 2 minutes before (oldest first):
  09:15:31.405 [ts-auth-service] 2024-12-08 09:15:31.404 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  09:15:31.405 [ts-auth-service] 2024-12-08 09:15:31.404 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  09:15:31.618 [ts-auth-service] 2024-12-08 09:15:31.618 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX
  09:15:31.618 [ts-auth-service] 2024-12-08 09:15:31.618 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4c7ef37c-e8cb-4d29-aaca-62bd7a8da985 USER ID
  09:15:31.801 [ts-auth-service] 2024-12-08 09:15:31.799 INFO 1 --- [ Thread-5] ationConfigEmbeddedWebApplicationContext : Closing org.springframework.boot.context.embedded.AnnotationConfigEmbe
  09:15:31.805 [ts-auth-service] 2024-12-08 09:15:31.803 INFO 1 --- [ Thread-5] o.s.c.support.DefaultLifecycleProcessor : Stopping beans in phase 0
  09:15:31.805 [ts-auth-service] 2024-12-08 09:15:31.804 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : Removing {logging-channel-adapter:_org.springframework.integration.errorLogg
  09:15:31.806 [ts-auth-service] 2024-12-08 09:15:31.806 INFO 1 --- [ Thread-5] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 0 subscriber(s).
  09:15:31.806 [ts-auth-service] 2024-12-08 09:15:31.806 INFO 1 --- [ Thread-5] o.s.i.endpoint.EventDrivenConsumer : stopped _org.springframework.integration.errorLogger
  09:15:31.808 [ts-auth-service] 2024-12-08 09:15:31.808 INFO 1 --- [ Thread-5] o.s.s.c.ThreadPoolTaskScheduler : Shutting down ExecutorService 'taskScheduler'
  09:15:31.808 [ts-auth-service] 2024-12-08 09:15:31.808 INFO 1 --- [ Thread-5] o.s.j.e.a.AnnotationMBeanExporter : Unregistering JMX-exposed beans on shutdown
  09:15:31.811 [ts-auth-service] 2024-12-08 09:15:31.811 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:38}] to ts-auth-mongo:2  (×3)
  09:15:35.586 [ts-auth-service] [otel.javaagent 2024-12-08 09:15:35:585 +0000] [main] INFO io.opentelemetry.javaagent.tooling.VersionLogger - opentelemetry-javaagent - version: 2.0.0
  09:15:38.192 [ts-auth-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  09:15:40.887 [ts-auth-service] 2024-12-08 09:15:40.790 INFO 1 --- [ main] auth.AuthApplication : Starting AuthApplication v1.0 on ts-auth-service-54976f76bc-h4k7r with PID 1 (/app/ts-auth-ser
  09:15:40.887 [ts-auth-service] 2024-12-08 09:15:40.886 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default
  09:15:41.679 [ts-auth-service] 2024-12-08 09:15:41.678 INFO 1 --- [ main] ationConfigEmbeddedWebApplicationContext : Refreshing org.springframework.boot.context.embedded.AnnotationConfigEmbed
  09:15:51.091 [ts-auth-service] 2024-12-08 09:15:51.090 INFO 1 --- [ main] o.s.i.config.IntegrationRegistrar : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. The
All services, 30 seconds either side (sampled):
  09:15:25.931 [ts-travel-service] 2024-12-08 09:15:25.930 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Travel Service] Query TripResponse  (×4)
  09:15:26.009 [ts-travel-service] 2024-12-08 09:15:26.009 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×8)
  09:15:26.067 [ts-basic-service] 2024-12-08 09:15:26.067 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1  (×16)
  09:15:26.139 [ts-seat-service] 2024-12-08 09:15:26.138 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×12)
  09:15:26.268 [ts-seat-service] 2024-12-08 09:15:26.267 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×5)
  09:15:26.323 [ts-preserve-service] 2024-12-08 09:15:26.323 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security
  09:15:26.360 [ts-security-service] 2024-12-08 09:15:26.360 INFO 1 --- [io-11188-exec-7] security.service.SecurityServiceImpl : [Security Service][Get Security Config Info]
  09:15:26.383 [ts-preserve-service] 2024-12-08 09:15:26.383 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting...
  09:15:26.593 [ts-basic-service] 2024-12-08 09:15:26.593 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×2)
  09:15:26.640 [ts-order-other-service] 2024-12-08 09:15:26.640 INFO 1 --- [io-12032-exec-8] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:0  (×11)
  09:15:26.707 [ts-seat-service] 2024-12-08 09:15:26.707 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×21)
  09:15:26.810 [ts-seat-service] 2024-12-08 09:15:26.809 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService distributeSeat] The result of getRouteResult is Success
  09:15:26.843 [ts-order-service] 2024-12-08 09:15:26.843 INFO 1 --- [io-12031-exec-9] order.service.OrderServiceImpl : [Order Service][Create Order] Ready Create Order.
  09:15:29.873 [ts-food-service] 2024-12-08 09:15:29.873 INFO 1 --- [io-18856-exec-1] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×4)
  09:15:31.618 [ts-auth-service] 2024-12-08 09:15:31.618 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX
  09:15:32.590 [ts-admin-basic-info-service] 2024-12-08 09:15:32.590 INFO 1 --- [io-18767-exec-6] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×11)
  09:15:33.411 [ts-travel2-service] 2024-12-08 09:15:33.411 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×6)
  09:15:45.493 [ts-order-service] 2024-12-08 09:15:45.493 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 
  09:15:49.904 [ts-travel-service] 2024-12-08 09:15:49.904 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×6)
  09:15:51.091 [ts-auth-service] 2024-12-08 09:15:51.090 INFO 1 --- [ main] o.s.i.config.IntegrationRegistrar : No bean named 'integrationHeaderChannelRegistry' has been explicitly defined. The  (×2)
  09:15:57.381 [ts-basic-service] 2024-12-08 09:15:57.380 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×4)
  09:16:01.754 [ts-basic-service] 2024-12-08 09:16:01.754 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
  09:16:07.387 [ts-auth-service] 2024-12-08 09:16:07.387 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip
  09:16:10.202 [ts-station-mongo] {"t":{"$date":"2024-12-08T09:16:10.201+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364937
  09:16:12.867 [ts-consign-price-mongo] {"t":{"$date":"2024-12-08T09:16:12.867+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364937
  09:16:15.982 [ts-auth-service] 2024-12-08 09:16:15.982 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.springframework.w
  09:16:18.390 [ts-auth-service] 2024-12-08 09:16:18.390 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/vnd.spring-bo
  09:16:19.996 [ts-auth-service] 2024-12-08 09:16:19.995 INFO 1 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in globalExceptionHandler
  09:16:23.696 [ts-auth-service] 2024-12-08 09:16:23.695 INFO 1 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup

## p0348
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:27:10.210Z
```
{"timestamp":1732246030210798600,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:27:10.210583071Z caller=middlewares.go:104 method=GetAddresses id=673ff9fbb0df5c00019b237d result=1 took=816.215µs"}
```
Same service, the 2 minutes before (oldest first):
  03:27:07.513 [user] ts=2024-11-22T03:27:07.513390629Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffa05b0df5c00019b239b took=1.526671ms  (×7)
  03:27:07.929 [user] ts=2024-11-22T03:27:07.929342985Z caller=middlewares.go:46 method=Register username=DSnhBHKixU email=DSnhBHKixU@gmail.com took=943.142µs  (×2)
  03:27:08.101 [user] ts=2024-11-22T03:27:08.101333485Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffa04b0df5c00019b2395 took=1.796067ms  (×6)
  03:27:09.093 [user] ts=2024-11-22T03:27:09.093519179Z caller=middlewares.go:157 method=Health result=2 took=792.26µs  (×2)
  03:27:10.192 [user] ts=2024-11-22T03:27:10.19267294Z caller=middlewares.go:75 method=GetUsers id=673ff9f4b0df5c00019b2371 result=1 took=869.382µs  (×3)
All services, 30 seconds either side (sampled):
  03:26:40.352 [catalogue] ts=2024-11-22T03:26:40Z caller=logging.go:85 method=Health result=2 took=26.327µs  (×40)
  03:26:40.900 [front-end] User cart deleted with status: 202  (×55)
  03:26:41.314 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×5)
  03:26:42.093 [user] ts=2024-11-22T03:26:42.093451708Z caller=middlewares.go:157 method=Health result=2 took=758.61µs  (×32)
  03:26:42.592 [orders] 2024-11-22 03:26:42.592 INFO [orders,a06720231d1c6514,c3185274a403b375,false] 6 --- [-nio-80-exec-14] w.w.s.o.controllers.OrdersController : Sending payment req  (×25)
  03:26:42.610 [front-end] POST /orders 201 - ms - -  (×59)
  03:26:43.554 [front-end] Posting Customer: {"username":"EuVOk","password":"yluLZmv","email":"EuVOk@gmail.com","firstName":"EuVOk","lastName":"EuVOk"}
  03:26:45.995 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9f5d94b9000069b44b7","customerId":"673ff9e0b0df5c00019b232f","customer":{"id":null,"firstName":"GITcg","las
  03:26:47.629 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9f7d94b9000069b44b9","customerId":"673ff9e6b0df5c00019b2345","customer":{"id":null,"firstName":"MMzNkgQuq",
  03:26:50.297 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9fad94b9000069b44ba","customerId":"673ff9e8b0df5c00019b234c","customer":{"id":null,"firstName":"yDRpxgSzGkP
  03:26:52.606 [front-end] Received response: "{\"firstName\":\"xyjpVB\",\"lastName\":\"xyjpVB\",\"username\":\"xyjpVB\",\"id\":\"673ff9e7b0df5c00019b2348\",\"_links\":{\"addresses\":{\"h
  03:26:54.350 [queue-master] 2024-11-22 03:26:54.350 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×27)
  03:26:56.051 [front-end] Order response: {"id":"673ffa00d94b9000069b44c0","customerId":"673ff9e5b0df5c00019b2343","customer":{"id":null,"firstName":"XMMeAiwQxW","lastName":"XMMeAiwQxW",
  03:26:58.816 [front-end] Received response: "{\"firstName\":\"WTNaLS\",\"lastName\":\"WTNaLS\",\"username\":\"WTNaLS\",\"id\":\"673ff9e9b0df5c00019b234e\",\"_links\":{\"addresses\":{\"h
  03:27:01.446 [user] ts=2024-11-22T03:27:01.44667531Z caller=middlewares.go:46 method=Register username=jLwainknX email=jLwainknX@gmail.com took=944.045µs
  03:27:03.908 [front-end] Received response: "{\"firstName\":\"irITZqEwVRiZtiC\",\"lastName\":\"irITZqEwVRiZtiC\",\"username\":\"irITZqEwVRiZtiC\",\"id\":\"673ff9f1b0df5c00019b236b\",\"_
  03:27:07.926 [front-end] Posting Customer: {"username":"DSnhBHKixU","password":"LXDZT","email":"DSnhBHKixU@gmail.com","firstName":"DSnhBHKixU","lastName":"DSnhBHKixU"}
  03:27:11.440 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa0fd94b9000069b44c9","customerId":"673ff9f4b0df5c00019b2370","customer":{"id":null,"firstName":"VRnlhxWD","
  03:27:12.703 [front-end] Posting Customer: {"username":"zMGfGiXRujo","password":"HgyIAIusKw","email":"zMGfGiXRujo@gmail.com","firstName":"zMGfGiXRujo","lastName":"zMGfGiXRujo"}
  03:27:16.542 [user] ts=2024-11-22T03:27:16.542604256Z caller=middlewares.go:46 method=Register username=HIBdGX email=HIBdGX@gmail.com took=988.158µs
  03:27:17.937 [front-end] Received response: "{\"firstName\":\"iswKmiwcQNQ\",\"lastName\":\"iswKmiwcQNQ\",\"username\":\"iswKmiwcQNQ\",\"id\":\"673ffa08b0df5c00019b23a4\",\"_links\":{\"a
  03:27:19.473 [front-end] Order response: {"id":"673ffa17d94b9000069b44d1","customerId":"673ff9ffb0df5c00019b2387","customer":{"id":null,"firstName":"jLOLG","lastName":"jLOLG","username"
  03:27:22.129 [front-end] Received response: "{\"firstName\":\"DSnhBHKixU\",\"lastName\":\"DSnhBHKixU\",\"username\":\"DSnhBHKixU\",\"id\":\"673ffa0bb0df5c00019b23b0\",\"_links\":{\"addr
  03:27:23.588 [front-end] Received response: "{\"firstName\":\"wDKANSSusfHVV\",\"lastName\":\"wDKANSSusfHVV\",\"username\":\"wDKANSSusfHVV\",\"id\":\"673ffa07b0df5c00019b23a0\",\"_links\
  03:27:25.230 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa1dd94b9000069b44da","customerId":"673ffa02b0df5c00019b2393","customer":{"id":null,"firstName":"fewqCFN","l
  03:27:29.220 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa21d94b9000069b44dd","customerId":"673ffa10b0df5c00019b23c5","customer":{"id":null,"firstName":"IzKSkuLwhEW
  03:27:31.525 [front-end] Received response: "{\"firstName\":\"RPpMC\",\"lastName\":\"RPpMC\",\"username\":\"RPpMC\",\"id\":\"673ffa11b0df5c00019b23c8\",\"_links\":{\"addresses\":{\"href
  03:27:34.946 [front-end] Order response: {"id":"673ffa26d94b9000069b44e1","customerId":"673ffa10b0df5c00019b23c4","customer":{"id":null,"firstName":"zMGfGiXRujo","lastName":"zMGfGiXRujo
  03:27:37.635 [front-end] Order response: {"id":"673ffa29d94b9000069b44e4","customerId":"673ffa11b0df5c00019b23c9","customer":{"id":null,"firstName":"rmpUlzccFXpPIQ","lastName":"rmpUlzcc

## p0563
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-mongo, 2024-12-07T18:30:15.883Z
```
{"timestamp":1733596215883143700,"container_name":"ts-auth-mongo","pod_name":"ts-auth-mongo-5f4f97c69b-kbdjp","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"{\"t\":{\"$date\":\"2024-12-07T18:30:15.883+00:00\"},\"s\":\"I\",  \"c\":\"NETWORK\",  \"id\":22944,   \"ctx\":\"conn16\",\"msg\":\"Connection ended\",\"attr\":{\"remote\":\"127.0.0.6:46471\",\"uuid\":\"53c010d2-8ff5-404b-8b32-e7a3ef9c5b47\",\"connectionId\":16,\"connectionCount\":4}}"}
```
Same service, the 2 minutes before (oldest first):
  18:28:29.813 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:28:29.813+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359610  (×2)
All services, 30 seconds either side (sampled):
  18:29:45.888 [ts-basic-service] 2024-12-07 18:29:45.887 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×8)
  18:29:45.930 [ts-basic-service] 2024-12-07 18:29:45.930 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×62)
  18:29:45.993 [ts-travel2-service] 2024-12-07 18:29:45.993 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×111)
  18:29:46.031 [ts-seat-service] 2024-12-07 18:29:46.031 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×36)
  18:29:47.860 [ts-auth-service] 2024-12-07 18:29:47.860 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iX  (×9)
  18:29:47.919 [ts-travel-service] 2024-12-07 18:29:47.919 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×12)
  18:29:47.979 [ts-travel2-service] 2024-12-07 18:29:47.978 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×16)
  18:29:54.679 [ts-auth-service] 2024-12-07 18:29:54.679 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  18:30:00.246 [ts-basic-service] 2024-12-07 18:30:00.246 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  18:30:00.278 [ts-basic-service] 2024-12-07 18:30:00.278 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  18:30:00.379 [ts-seat-service] 2024-12-07 18:30:00.379 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×3)
  18:30:02.452 [ts-basic-service] 2024-12-07 18:30:02.452 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×24)
  18:30:02.486 [ts-basic-service] 2024-12-07 18:30:02.486 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai  (×11)
  18:30:02.555 [ts-travel-service] 2024-12-07 18:30:02.554 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×4)
  18:30:07.196 [ts-order-other-service] 2024-12-07 18:30:07.196 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×3)
  18:30:09.590 [ts-inside-payment-service] 2024-12-07 18:30:09.588 INFO 1 --- [io-18673-exec-7] i.service.InsidePaymentServiceImpl : Out pay result: Response(status=1, msg=Pay Success, data=null)
  18:30:14.631 [ts-basic-service] 2024-12-07 18:30:14.630 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×19)
  18:30:14.739 [ts-order-service] 2024-12-07 18:30:14.739 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×5)
  18:30:14.807 [ts-seat-service] 2024-12-07 18:30:14.807 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×11)
  18:30:15.479 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:30:15 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 916 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×2)
  18:30:15.880 [ts-auth-service] 2024-12-07 18:30:15.880 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:16}] to ts-auth-mongo:2  (×4)
  18:30:17.523 [ts-travel-service] 2024-12-07 18:30:17.523 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1237
  18:30:26.260 [ts-auth-service] 2024-12-07 18:30:26.260 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default
  18:30:29.606 [ts-food-service] 2024-12-07 18:30:29.605 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  18:30:29.940 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:30:29.940+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359622
  18:30:31.939 [ts-order-service] 2024-12-07 18:30:31.939 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 
  18:30:40.512 [ts-order-other-service] 2024-12-07 18:30:40.512 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 24
  18:30:42.020 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T18:30:42.020+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359624
  18:30:44.984 [ts-travel2-service] 2024-12-07 18:30:44.983 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success

## p0314
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:20:32.260Z
```
{"timestamp":1732245632260819700,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /register 200 54.622 ms - 33"}
```
Same service, the 2 minutes before (oldest first):
  03:20:31.593 [front-end] POST /cart 500 30.657 ms - 64
  03:20:31.742 [front-end] GET /catalogue 200 - ms - -
  03:20:31.918 [front-end] Request received with body: {}
  03:20:31.925 [front-end] Received response: "{\"firstName\":\"voTxzAg\",\"lastName\":\"voTxzAg\",\"username\":\"voTxzAg\",\"id\":\"673ff864b0df5c00019b1ea4\",\"_links\":{\"addresses\":{
  03:20:31.925 [front-end] GET Request to: http://user/customers/673ff864b0df5c00019b1ea4/addresses  (×2)
  03:20:31.931 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:20:31.931 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff86db0df5c00019b1ecf\",\"_links\":{\"
  03:20:31.931 [front-end] [ undefined, undefined ]
  03:20:31.931 [front-end] Posting Order: {"customer":"http://user/customers/673ff864b0df5c00019b1ea4","address":"http://user/addresses/673ff86db0df5c00019b1ece","card":"http://user/cards
  03:20:31.975 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245631972,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:20:31.975 [front-end] Order response: {"timestamp":1732245631972,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:20:31.977 [front-end] POST /orders 500 - ms - -
  03:20:32.204 [front-end] Posting Customer: {"username":"znIVGAMLgnSste","password":"zCqOHq","email":"znIVGAMLgnSste@gmail.com","firstName":"znIVGAMLgnSste","lastName":"znIVGAMLgnSste"}
  03:20:32.210 [front-end] { id: '673ff880b0df5c00019b1f04' }
  03:20:32.210 [front-end] 673ff880b0df5c00019b1f04
  03:20:32.210 [front-end] Merging carts for customer id: 673ff880b0df5c00019b1f04 and session id: k6e1DMJjhYMQwbKV_wavu5B5-CGT76lX
  03:20:32.258 [front-end] Carts merged.
  03:20:32.258 [front-end] set cookie673ff880b0df5c00019b1f04
  03:20:32.258 [front-end] Sent cookies.
All services, 30 seconds either side (sampled):
  03:20:06.094 [user] ts=2024-11-22T03:20:06.093913614Z caller=middlewares.go:157 method=Health result=2 took=831.401µs  (×34)
  03:20:06.543 [front-end] Posting Order: {"customer":"http://user/customers/673ff84eb0df5c00019b1e6c","address":"http://user/addresses/673ff854b0df5c00019b1e7e","card":"http://user/cards  (×52)
  03:20:06.649 [user] ts=2024-11-22T03:20:06.649242768Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff861b0df5c00019b1e9e took=1.734848ms  (×57)
  03:20:06.789 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×9)
  03:20:07.186 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×10)
  03:20:08.474 [front-end] 673ff868b0df5c00019b1eb9  (×56)
  03:20:09.093 [user] ts=2024-11-22T03:20:09.093533288Z caller=middlewares.go:46 method=Register username=CBhyKd email=CBhyKd@gmail.com took=1.350871ms
  03:20:09.910 [front-end] Posting Customer: {"username":"uQhCpCJIyYL","password":"dElvDjn","email":"uQhCpCJIyYL@gmail.com","firstName":"uQhCpCJIyYL","lastName":"uQhCpCJIyYL"}
  03:20:12.002 [front-end] Received response: "{\"firstName\":\"oVuSYHHeDcohK\",\"lastName\":\"oVuSYHHeDcohK\",\"username\":\"oVuSYHHeDcohK\",\"id\":\"673ff855b0df5c00019b1e85\",\"_links\
  03:20:15.090 [front-end] Received response: "{\"firstName\":\"NNuouUNggTNDT\",\"lastName\":\"NNuouUNggTNDT\",\"username\":\"NNuouUNggTNDT\",\"id\":\"673ff859b0df5c00019b1e89\",\"_links\
  03:20:18.022 [front-end] Received response: "{\"firstName\":\"fjKqdCY\",\"lastName\":\"fjKqdCY\",\"username\":\"fjKqdCY\",\"id\":\"673ff858b0df5c00019b1e88\",\"_links\":{\"addresses\":{
  03:20:20.995 [front-end] Received response: "{\"firstName\":\"WQulX\",\"lastName\":\"WQulX\",\"username\":\"WQulX\",\"id\":\"673ff85fb0df5c00019b1e97\",\"_links\":{\"addresses\":{\"href
  03:20:26.017 [front-end] Posting Customer: {"username":"HLNoIPafm","password":"sBlBYfK","email":"HLNoIPafm@gmail.com","firstName":"HLNoIPafm","lastName":"HLNoIPafm"}
  03:20:29.280 [front-end] Received response: "{\"firstName\":\"iyaZwEHsMf\",\"lastName\":\"iyaZwEHsMf\",\"username\":\"iyaZwEHsMf\",\"id\":\"673ff861b0df5c00019b1ea0\",\"_links\":{\"addr
  03:20:32.616 [front-end] Posting Customer: {"username":"cEqPa","password":"xBmWZZWt","email":"cEqPa@gmail.com","firstName":"cEqPa","lastName":"cEqPa"}
  03:20:34.676 [front-end] Received response: "{\"firstName\":\"BBYdunXrngQk\",\"lastName\":\"BBYdunXrngQk\",\"username\":\"BBYdunXrngQk\",\"id\":\"673ff874b0df5c00019b1ee8\",\"_links\":{
  03:20:38.070 [session-db] 1:M 22 Nov 2024 03:20:38.070 * Background saving started by pid 32
  03:20:40.151 [user] ts=2024-11-22T03:20:40.151621717Z caller=middlewares.go:46 method=Register username=dOIvn email=dOIvn@gmail.com took=1.048258ms
  03:20:43.387 [carts] 2024-11-22 03:20:43.387 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:20:46.654 [front-end] Received response: "{\"firstName\":\"iLqTiAFoVbIq\",\"lastName\":\"iLqTiAFoVbIq\",\"username\":\"iLqTiAFoVbIq\",\"id\":\"673ff877b0df5c00019b1eec\",\"_links\":{
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.sp
  03:20:51.235 [front-end] Posting Customer: {"username":"cqPFUedoarsUCI","password":"BNbmkot","email":"cqPFUedoarsUCI@gmail.com","firstName":"cqPFUedoarsUCI","lastName":"cqPFUedoarsUCI"}
  03:20:54.897 [front-end] Posting Customer: {"username":"cfTPDbfduekTBf","password":"FQrLzttH","email":"cfTPDbfduekTBf@gmail.com","firstName":"cfTPDbfduekTBf","lastName":"cfTPDbfduekTBf"
  03:20:58.176 [front-end] Received response: "{\"firstName\":\"MpDJxkmv\",\"lastName\":\"MpDJxkmv\",\"username\":\"MpDJxkmv\",\"id\":\"673ff87eb0df5c00019b1f00\",\"_links\":{\"addresses\
  03:20:59.688 [carts] 2024-11-22 03:20:59.688 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[OPTIONS],produces=[applica
  03:20:59.783 [carts] 2024-11-22 03:20:59.783 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal
  03:20:59.789 [carts] 2024-11-22 03:20:59.789 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[OPTIONS],produc
  03:21:00.716 [front-end] Posting Customer: {"username":"bDjuXlWHATfWj","password":"ynjkfXmXiY","email":"bDjuXlWHATfWj@gmail.com","firstName":"bDjuXlWHATfWj","lastName":"bDjuXlWHATfWj"}

## p0053
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-13T08:24:27.689Z
```
{"service":"redisservice1","message":"2021-08-13 08:24:27,689 | INFO | 0.0.0.1 | 172.17.0.4 | redisservice1 | b5f362adf3617528 | redis write success"}
```
Same service, the 2 minutes before (oldest first):
  08:24:22.685 [redisservice1] INFO service refuse, status_code: 200  (×3)
  08:24:22.947 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×3)
  08:24:23.019 [redisservice1] INFO redis write success  (×7)
  08:24:23.745 [redisservice1] INFO redis读取信息成功, status_code: 200  (×5)
  08:24:23.921 [redisservice1] INFO service accept, status_code: 200  (×2)
All services, 30 seconds either side (sampled):
  08:23:57.784 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  08:23:57.898 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×47)
  08:23:58.041 [dbservice1] INFO bfba778a-fbcc-11eb-8d0b-0242ac110004-vLPzKelQ-H:yjVplx2YI= token generate success token=MTYyODgxNDIzOC4wNDEzODI6YmZiYTc3OGEtZmJjYy0xMWViLThkMGItMDI0MmFjMTE
  08:23:58.336 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×50)
  08:23:58.523 [mobservice1] INFO info c034c8f0-fbcc-11eb-b36c-0242ac110003:KvpoNGOC write success
  08:23:58.774 [dbservice2] ERROR dbservice2 access redis service denied  (×46)
  08:23:59.030 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×47)
  08:23:59.178 [mobservice2] INFO info c0a0102e-fbcc-11eb-9c32-0242ac110004:ImYCctrK write success
  08:24:00.761 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×51)
  08:24:02.084 [mobservice2] INFO info c25b1530-fbcc-11eb-8d78-0242ac110003:nuXjsHUb write success
  08:24:04.018 [dbservice1] INFO c353f560-fbcc-11eb-b6db-0242ac110004-mwbCGSva-?GF.b6pov$k5 token generate success token=MTYyODgxNDI0NC4wMTg1Njc6YzM1M2Y1NjAtZmJjYy0xMWViLWI2ZGItMDI0MmFjMTE
  08:24:06.020 [mobservice2] INFO info c4bb48ea-fbcc-11eb-9681-0242ac110004:ISmxpnEs write success
  08:24:09.678 [mobservice2] INFO info c6e24eac-fbcc-11eb-8b74-0242ac110003:GsgASzin write success
  08:24:12.764 [mobservice1] INFO info c8b340a6-fbcc-11eb-b626-0242ac110003:CAQfZdjo write success
  08:24:14.853 [dbservice1] INFO c9bb20ea-fbcc-11eb-a193-0242ac110004-ljJOtheS-.@Pa#+/q>bg% token generate success token=MTYyODgxNDI1NC44NTI4Mjc1OmM5YmIyMGVhLWZiY2MtMTFlYi1hMTkzLTAyNDJhYzE
  08:24:17.724 [mobservice2] INFO info cbb048c6-fbcc-11eb-9356-0242ac110004:lkNrGYTL write success
  08:24:20.403 [dbservice1] INFO cd0da13c-fbcc-11eb-877d-0242ac110004-QNgzxusO-msv)gRlMu=0. token generate success token=MTYyODgxNDI2MC40MDMwMjk3OmNkMGRhMTNjLWZiY2MtMTFlYi04NzdkLTAyNDJhYzE
  08:24:23.986 [dbservice1] INFO cf3844e4-fbcc-11eb-be72-0242ac110004-LmHpecgO-{$XO7}iZEDzn token generate success token=MTYyODgxNDI2My45ODYzODA4OmNmMzg0NGU0LWZiY2MtMTFlYi1iZTcyLTAyNDJhYzE
  08:24:26.716 [mobservice2] INFO info d11123e4-fbcc-11eb-9ce6-0242ac110004:cforzalb write success
  08:24:29.394 [dbservice1] INFO d26c0466-fbcc-11eb-a6b5-0242ac110003-cvlIGRjC-l5}dC_?m/GUr token generate success token=MTYyODgxNDI2OS4zOTQyMzM6ZDI2YzA0NjYtZmJjYy0xMWViLWE2YjUtMDI0MmFjMTE
  08:24:32.213 [mobservice1] INFO info d44a87bc-fbcc-11eb-b308-0242ac110003:GOhWXRIV write success
  08:24:35.183 [mobservice1] INFO info d60f6888-fbcc-11eb-b2e8-0242ac110003:vOcCSRZA write success
  08:24:38.852 [mobservice2] INFO info d8460e18-fbcc-11eb-b3f0-0242ac110004:KPxfCQdu write success  (×2)
  08:24:42.023 [dbservice1] INFO d9dfa180-fbcc-11eb-8239-0242ac110003-MGhzxsST-cYbH0S^hJFm* token generate success token=MTYyODgxNDI4Mi4wMjIxMjkzOmQ5ZGZhMTgwLWZiY2MtMTFlYi04MjM5LTAyNDJhYzE
  08:24:45.069 [mobservice1] INFO info dbf50456-fbcc-11eb-b3a8-0242ac110003:vaHXLtfK write success
  08:24:47.821 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  08:24:50.613 [dbservice1] INFO def1b208-fbcc-11eb-b693-0242ac110003-uHrsPUfR-&IVwh=}zb.Hu token generate success token=MTYyODgxNDI5MC42MTMzMDIyOmRlZjFiMjA4LWZiY2MtMTFlYi1iNjkzLTAyNDJhYzE
  08:24:53.513 [mobservice1] INFO info e1024120-fbcc-11eb-ba76-0242ac110004:jyYHLuNM write success
  08:24:56.517 [mobservice1] INFO info e2c936a8-fbcc-11eb-bd05-0242ac110003:kicMwWKP write success

## p0543
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-preserve-other-service, 2024-12-07T18:19:12.960Z
```
{"timestamp":1733595552960948200,"container_name":"ts-preserve-other-service","pod_name":"ts-preserve-other-service-7cf4c487d7-fctlp","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:19:12.960  INFO 1 --- [io-14569-exec-9] p.service.PreserveOtherServiceImpl       : [Preserve Service] [Step 1] Check Security Complete. "}
```
Same service, the 2 minutes before (oldest first):
  18:17:41.083 [ts-preserve-other-service] 2024-12-07 18:17:41.082 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : TripResponse : TripResponse(tripId=Z1234, startingStation=Shang Hai, t
  18:17:41.084 [ts-preserve-other-service] 2024-12-07 18:17:41.083 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Tickets Enough
  18:17:41.084 [ts-preserve-other-service] 2024-12-07 18:17:41.083 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order
  18:17:41.085 [ts-preserve-other-service] 2024-12-07 18:17:41.085 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Station By Name]  (×2)
  18:17:41.214 [ts-preserve-other-service] 2024-12-07 18:17:41.214 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order] Order Travel Date: Sat Dec 07 00:00:00
  18:17:41.394 [ts-preserve-other-service] 2024-12-07 18:17:41.393 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order Price] Price is: 122.49999999999999
  18:17:41.394 [ts-preserve-other-service] 2024-12-07 18:17:41.394 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Contacts By Id] Creating....
  18:17:41.506 [ts-preserve-other-service] 2024-12-07 18:17:41.506 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order Complete
  18:17:41.506 [ts-preserve-other-service] 2024-12-07 18:17:41.506 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Service][Add Assurance Type For Order]
  18:17:41.680 [ts-preserve-other-service] 2024-12-07 18:17:41.680 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 5] Preserve Buy Assurance Success
  18:17:41.681 [ts-preserve-other-service] 2024-12-07 18:17:41.680 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Service][Add Preserve food Order] Creating....
  18:17:41.779 [ts-preserve-other-service] 2024-12-07 18:17:41.778 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 6] Buy Food Success
  18:17:41.779 [ts-preserve-other-service] 2024-12-07 18:17:41.778 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 7] Do not need to consign
  18:17:41.779 [ts-preserve-other-service] 2024-12-07 18:17:41.778 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Service]
  18:17:41.779 [ts-preserve-other-service] 2024-12-07 18:17:41.779 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Cancel Order Service][Get Order By Id]
  18:19:12.843 [ts-preserve-other-service] 2024-12-07 18:19:12.843 INFO 1 --- [io-14569-exec-9] p.controller.PreserveOtherController : [Preserve Other Service][Preserve] Account order from Shang Hai ----
  18:19:12.843 [ts-preserve-other-service] 2024-12-07 18:19:12.843 INFO 1 --- [io-14569-exec-9] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Verify Login] Success
  18:19:12.843 [ts-preserve-other-service] 2024-12-07 18:19:12.843 INFO 1 --- [io-14569-exec-9] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security
  18:19:12.843 [ts-preserve-other-service] 2024-12-07 18:19:12.843 INFO 1 --- [io-14569-exec-9] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Check Account Security] Checking....
All services, 30 seconds either side (sampled):
  18:18:43.118 [ts-auth-service] 2024-12-07 18:18:43.118 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×9)
  18:18:43.338 [ts-travel2-service] 2024-12-07 18:18:43.338 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×124)
  18:18:43.387 [ts-basic-service] 2024-12-07 18:18:43.387 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×7)
  18:18:43.422 [ts-order-other-service] 2024-12-07 18:18:43.422 INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×8)
  18:18:43.528 [ts-travel2-service] 2024-12-07 18:18:43.528 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×23)
  18:18:43.580 [ts-travel2-service] 2024-12-07 18:18:43.580 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×18)
  18:18:43.727 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:18:43 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 356 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×10)
  18:18:48.759 [ts-travel-service] 2024-12-07 18:18:48.759 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d  (×62)
  18:18:54.109 [ts-travel-service] 2024-12-07 18:18:54.109 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×33)
  18:18:55.101 [ts-travel-service] 2024-12-07 18:18:55.101 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×15)
  18:18:55.206 [ts-travel-service] 2024-12-07 18:18:55.206 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×3)
  18:18:58.239 [ts-travel2-service] 2024-12-07 18:18:58.239 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×15)
  18:18:58.402 [ts-travel2-service] 2024-12-07 18:18:58.402 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×4)
  18:18:58.472 [ts-travel2-service] 2024-12-07 18:18:58.472 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×4)
  18:19:06.924 [ts-order-service] 2024-12-07 18:19:06.924 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Query Order][Step 1] Get Orders Number of Account: 32
  18:19:07.282 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:19:07 +0800] "POST /api/v1/inside_pay_service/inside_payment HTTP/1.1" 200 71 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
  18:19:12.843 [ts-preserve-other-service] 2024-12-07 18:19:12.843 INFO 1 --- [io-14569-exec-9] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Verify Login] Success
  18:19:12.881 [ts-security-service] 2024-12-07 18:19:12.881 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Getting....
  18:19:12.972 [ts-contacts-service] 2024-12-07 18:19:12.971 INFO 1 --- [io-12347-exec-2] contacts.controller.ContactsController : [ContactsService][Contacts Id Print] d14da0ec-da93-46c3-842d-23fc3
  18:19:13.030 [ts-travel2-service] 2024-12-07 18:19:13.030 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [TravelService] [getTripAllDetailInfo] endPlaceID: nanjing
  18:19:13.896 [ts-seat-service] 2024-12-07 18:19:13.896 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService] TrainNumber start with other capital
  18:19:14.115 [ts-order-other-service] 2024-12-07 18:19:14.115 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Create Order] Create Order form shanghai --->
  18:19:14.203 [ts-preserve-other-service] 2024-12-07 18:19:14.202 INFO 1 --- [io-14569-exec-9] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 5] Preserve Buy Assurance Success
  18:19:18.270 [ts-basic-service] 2024-12-07 18:19:18.269 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×4)
  18:19:18.418 [ts-order-service] 2024-12-07 18:19:18.418 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 29
  18:19:18.678 [ts-travel-service] 2024-12-07 18:19:18.678 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×2)
  18:19:27.473 [ts-config-mongo] {"t":{"$date":"2024-12-07T18:19:27.473+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359556
  18:19:30.311 [ts-preserve-mongo] {"t":{"$date":"2024-12-07T18:19:30.311+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359557
  18:19:42.069 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T18:19:42.068+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359558

## p0050
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice2, 2021-08-13T08:15:11.252Z
```
{"service":"redisservice2","message":"2021-08-13 08:15:11,252 | INFO | 0.0.0.2 | redisservice2 | redis_helper.py -> keys_existence_check -> 107 | 2a1ea7e2216e71e6 | service refuse, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  08:15:06.753 [redisservice2] INFO service refuse, status_code: 200  (×2)
  08:15:06.899 [redisservice2] INFO redis write success  (×9)
  08:15:07.471 [redisservice2] INFO service accept, status_code: 200  (×4)
  08:15:08.037 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×3)
  08:15:09.671 [redisservice2] INFO redis读取信息成功, status_code: 200  (×2)
All services, 30 seconds either side (sampled):
  08:14:41.278 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '741cbf78-fbcb-11eb-92e3-0242ac110004', 'value': 'LUmfKNIy'}  (×47)
  08:14:41.456 [redisservice1] INFO redis读取信息成功, status_code: 200  (×43)
  08:14:41.551 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  08:14:41.808 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '74987366-fbcb-11eb-96f5-0242ac110003', 'value': '', 'ex': 10}  (×47)
  08:14:42.207 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×39)
  08:14:42.425 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '74987366-fbcb-11eb-96f5-0242ac110003'}  (×45)
  08:14:42.775 [redisservice2] INFO service accept, status_code: 200  (×23)
  08:14:44.157 [mobservice1] INFO info 75cd978e-fbcb-11eb-a53f-0242ac110003:nSPeKIZU write success
  08:14:45.426 [dbservice1] INFO 764b550c-fbcb-11eb-913d-0242ac110003-gSjZMlmO--CEXg)FY#_sv token generate success token=MTYyODgxMzY4NS40MjYwNjMzOjc2NGI1NTBjLWZiY2ItMTFlYi05MTNkLTAyNDJhYzE
  08:14:45.738 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×41)
  08:14:46.538 [mobservice1] INFO info 773d7774-fbcb-11eb-a238-0242ac110003:cSnIQPJM write success
  08:14:48.702 [mobservice1] INFO info 7886f538-fbcb-11eb-b315-0242ac110004:KPxfCQdu write success
  08:14:51.873 [mobservice2] INFO info 7a60c456-fbcb-11eb-9a37-0242ac110003:auOjVYlz write success
  08:14:54.349 [mobservice1] INFO info 7be6ba74-fbcb-11eb-82f5-0242ac110004:CkWFaQYZ write success
  08:14:57.032 [dbservice1] INFO 7d38b152-fbcb-11eb-855f-0242ac110003-kWcbAndl-+K)#TtAh_eL$ token generate success token=MTYyODgxMzY5Ny4wMzI1MzM6N2QzOGIxNTItZmJjYi0xMWViLTg1NWYtMDI0MmFjMTE
  08:15:00.245 [mobservice2] INFO info 7f5f66ba-fbcb-11eb-9431-0242ac110004:bAyVlxfw write success
  08:15:02.661 [dbservice1] INFO 808af1da-fbcb-11eb-b6e5-0242ac110003-xYHiSMPL-Gx3@4LTvA_5z token generate success token=MTYyODgxMzcwMi42NjA3NTE6ODA4YWYxZGEtZmJjYi0xMWViLWI2ZTUtMDI0MmFjMTE
  08:15:05.609 [dbservice1] INFO 824b7e90-fbcb-11eb-b25d-0242ac110003-uiZfvcTY-6xlZ>er?yf*z token generate success token=MTYyODgxMzcwNS42MDkxMzQ3OjgyNGI3ZTkwLWZiY2ItMTFlYi1iMjVkLTAyNDJhYzE
  08:15:08.801 [mobservice2] INFO info 847ad3aa-fbcb-11eb-93d8-0242ac110003:UFfHkLJX write success
  08:15:11.855 [mobservice1] INFO info 864f668c-fbcb-11eb-ab29-0242ac110003:LtXTsDKV write success
  08:15:14.526 [mobservice2] INFO info 87ec95b4-fbcb-11eb-bfc7-0242ac110003:COxkLyBN write success
  08:15:18.129 [mobservice2] INFO info 8a0a4148-fbcb-11eb-85ca-0242ac110003:MiawoxWe write success
  08:15:22.134 [mobservice2] INFO info 8c68033a-fbcb-11eb-9fc1-0242ac110003:kxDurOQh write success
  08:15:25.156 [mobservice2] INFO info 8e3c975c-fbcb-11eb-a688-0242ac110003:SjMAKXaq write success
  08:15:27.841 [dbservice1] INFO 8f9cdd32-fbcb-11eb-a0ef-0242ac110003-jnuiIECt-_JI:sCNEZ%ay token generate success token=MTYyODgxMzcyNy44NDEwMTg0OjhmOWNkZDMyLWZiY2ItMTFlYi1hMGVmLTAyNDJhYzE
  08:15:31.641 [dbservice1] INFO 91ec208e-fbcb-11eb-840a-0242ac110003-FAmtCcIX-WbpwIhFy&DB@ token generate success token=MTYyODgxMzczMS42NDA4MzI0OjkxZWMyMDhlLWZiY2ItMTFlYi04NDBhLTAyNDJhYzE

## p0368
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:37:39.894Z
```
{"timestamp":1732246659894799600,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:37:39.894715653Z caller=middlewares.go:75 method=GetUsers id=673ffc69b0df5c00019b2ae6 result=1 took=830.802µs"}
```
Same service, the 2 minutes before (oldest first):
  03:37:36.754 [user] ts=2024-11-22T03:37:36.754445127Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffc77b0df5c00019b2b16 took=1.760453ms  (×6)
  03:37:36.971 [user] ts=2024-11-22T03:37:36.970918818Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffc7bb0df5c00019b2b23 took=1.619299ms  (×5)
  03:37:37.019 [user] ts=2024-11-22T03:37:37.019326534Z caller=middlewares.go:46 method=Register username=aWlnoBDycQ email=aWlnoBDycQ@gmail.com took=1.027917ms
  03:37:38.603 [user] ts=2024-11-22T03:37:38.603746622Z caller=middlewares.go:46 method=Register username=sdtqfdQJsioGmP email=sdtqfdQJsioGmP@gmail.com took=997.658µs
  03:37:39.093 [user] ts=2024-11-22T03:37:39.093734377Z caller=middlewares.go:157 method=Health result=2 took=904.1µs  (×2)
  03:37:39.879 [user] ts=2024-11-22T03:37:39.879315455Z caller=middlewares.go:75 method=GetUsers id=673ffc69b0df5c00019b2ae6 result=1 took=867.821µs  (×3)
  03:37:39.894 [user] ts=2024-11-22T03:37:39.894567287Z caller=middlewares.go:104 method=GetAddresses id=673ffc72b0df5c00019b2aff result=1 took=958.839µs
  03:37:39.894 [user] ts=2024-11-22T03:37:39.8946143Z caller=middlewares.go:134 method=GetCards id=673ffc72b0df5c00019b2b00 result=1 took=611.724µs
All services, 30 seconds either side (sampled):
  03:37:09.909 [front-end] User cart deleted with status: 202  (×63)
  03:37:09.993 [front-end] { id: '673ffc65b0df5c00019b2adb' }  (×59)
  03:37:10.225 [front-end] GET Request to: http://user/customers/673ffc4fb0df5c00019b2aa0/addresses  (×116)
  03:37:10.259 [queue-master] Received shipment task: 673ffc4fb0df5c00019b2aa0  (×53)
  03:37:11.079 [front-end] Received response: "{\"firstName\":\"zZdaKyLrMrtaBR\",\"lastName\":\"zZdaKyLrMrtaBR\",\"username\":\"zZdaKyLrMrtaBR\",\"id\":\"673ffc4cb0df5c00019b2a97\",\"_lin
  03:37:11.782 [front-end] Attempting to delete cart for user: 673ffc5db0df5c00019b2ac5  (×62)
  03:37:12.243 [orders] 2024-11-22 03:37:12.242 INFO [orders,29215666b615bd62,bad00074fe25e338,false] 6 --- [-nio-80-exec-14] w.w.s.o.controllers.OrdersController : Sending payment req  (×22)
  03:37:13.678 [user] ts=2024-11-22T03:37:13.677807353Z caller=middlewares.go:46 method=Register username=ruUnBiE email=ruUnBiE@gmail.com took=962.03µs
  03:37:16.130 [front-end] Received response: "{\"firstName\":\"lVAux\",\"lastName\":\"lVAux\",\"username\":\"lVAux\",\"id\":\"673ffc52b0df5c00019b2aac\",\"_links\":{\"addresses\":{\"href
  03:37:19.169 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×5)
  03:37:20.936 [front-end] Received response: "{\"firstName\":\"ouvrfhhEHHIG\",\"lastName\":\"ouvrfhhEHHIG\",\"username\":\"ouvrfhhEHHIG\",\"id\":\"673ffc5eb0df5c00019b2ac8\",\"_links\":{
  03:37:24.119 [user] ts=2024-11-22T03:37:24.119264225Z caller=middlewares.go:46 method=Register username=KfxyYFwgU email=KfxyYFwgU@gmail.com took=954.552µs
  03:37:25.040 [user] ts=2024-11-22T03:37:25.039723042Z caller=middlewares.go:46 method=Register username=gaJpLNI email=gaJpLNI@gmail.com took=1.091683ms
  03:37:28.539 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc78d94b9000069b4673","customerId":"673ffc63b0df5c00019b2ad3","customer":{"id":null,"firstName":"aOSAEDRt","
  03:37:31.353 [user] ts=2024-11-22T03:37:31.353742548Z caller=middlewares.go:46 method=Register username=TlFyStg email=TlFyStg@gmail.com took=980.169µs
  03:37:32.866 [front-end] Order response: {"id":"673ffc7cd94b9000069b4677","customerId":"673ffc64b0df5c00019b2ad7","customer":{"id":null,"firstName":"YqDpRB","lastName":"YqDpRB","usernam
  03:37:33.744 [user] ts=2024-11-22T03:37:33.743920193Z caller=middlewares.go:46 method=Register username=aCIePDxY email=aCIePDxY@gmail.com took=4.263274ms
  03:37:35.535 [user] ts=2024-11-22T03:37:35.535180474Z caller=middlewares.go:46 method=Register username=BdYyzYfaQ email=BdYyzYfaQ@gmail.com took=1.085903ms
  03:37:40.133 [user] ts=2024-11-22T03:37:40.132903981Z caller=middlewares.go:46 method=Register username=LzntP email=LzntP@gmail.com took=993.463µs
  03:37:40.872 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  03:37:43.412 [front-end] Received response: "{\"firstName\":\"waNcPTeG\",\"lastName\":\"waNcPTeG\",\"username\":\"waNcPTeG\",\"id\":\"673ffc74b0df5c00019b2b0c\",\"_links\":{\"addresses\
  03:37:45.707 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc89d94b9000069b4686","customerId":"673ffc78b0df5c00019b2b18","customer":{"id":null,"firstName":"OQQQZlhzNOh
  03:37:47.275 [front-end] Order response: {"id":"673ffc8bd94b9000069b4689","customerId":"673ffc75b0df5c00019b2b0f","customer":{"id":null,"firstName":"gaJpLNI","lastName":"gaJpLNI","usern
  03:37:51.974 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc8fd94b9000069b468c","customerId":"673ffc7db0df5c00019b2b26","customer":{"id":null,"firstName":"aCIePDxY","
  03:37:54.839 [front-end] Posting Customer: {"username":"omfQNWYRP","password":"nEfSkY","email":"omfQNWYRP@gmail.com","firstName":"omfQNWYRP","lastName":"omfQNWYRP"}
  03:37:56.430 [front-end] Posting Customer: {"username":"PoYMDSfoEEGv","password":"zvceqf","email":"PoYMDSfoEEGv@gmail.com","firstName":"PoYMDSfoEEGv","lastName":"PoYMDSfoEEGv"}
  03:37:57.809 [front-end] Order response: {"id":"673ffc95d94b9000069b4691","customerId":"673ffc7fb0df5c00019b2b2b","customer":{"id":null,"firstName":"BdYyzYfaQ","lastName":"BdYyzYfaQ","u
  03:38:01.010 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc99d94b9000069b4694","customerId":"673ffc82b0df5c00019b2b36","customer":{"id":null,"firstName":"sdtqfdQJsio
  03:38:03.374 [front-end] Received response: "{\"firstName\":\"rfQupJSJRXX\",\"lastName\":\"rfQupJSJRXX\",\"username\":\"rfQupJSJRXX\",\"id\":\"673ffc86b0df5c00019b2b40\",\"_links\":{\"a
  03:38:08.280 [front-end] Received response: "{\"firstName\":\"fIqXbPpImrOV\",\"lastName\":\"fIqXbPpImrOV\",\"username\":\"fIqXbPpImrOV\",\"id\":\"673ffc88b0df5c00019b2b48\",\"_links\":{

## p0507
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:19:42.751Z
```
{"timestamp":1732353582751970300,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:19:42.751854721Z caller=middlewares.go:75 method=GetUsers id=67419e1da437380001df0ff4 result=1 took=2.514913ms"}
```
Same service, the 2 minutes before (oldest first):
  09:19:38.692 [user] ts=2024-11-23T09:19:38.692268328Z caller=middlewares.go:75 method=GetUsers id=67419e1aa437380001df0feb result=1 took=2.385867ms  (×4)
  09:19:39.090 [user] ts=2024-11-23T09:19:39.090405132Z caller=middlewares.go:46 method=Register username=sSLXvJIWPrKgXis email=sSLXvJIWPrKgXis@gmail.com took=2.596605ms  (×2)
  09:19:39.180 [user] ts=2024-11-23T09:19:39.18002462Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419e26a437380001df100e took=4.672746ms  (×5)
  09:19:39.195 [user] ts=2024-11-23T09:19:39.195845517Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419e26a437380001df100e took=4.561375ms  (×5)
  09:19:40.849 [user] ts=2024-11-23T09:19:40.849303067Z caller=middlewares.go:157 method=Health result=2 took=2.335839ms  (×2)
  09:19:41.775 [user] ts=2024-11-23T09:19:41.775218944Z caller=middlewares.go:46 method=Register username=niHVXNyJ email=niHVXNyJ@gmail.com took=1.907828ms
  09:19:42.387 [user] ts=2024-11-23T09:19:42.38725658Z caller=middlewares.go:46 method=Register username=uJMVVm email=uJMVVm@gmail.com took=2.687733ms
All services, 30 seconds either side (sampled):
  09:19:13.167 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67419e07a437380001df0fa6"}  (×58)
  09:19:13.263 [front-end] User cart deleted with status: 202  (×58)
  09:19:13.312 [carts] 2024-11-23 09:19:13.312 INFO [carts,c0878a4524f57c7b,88c10f4fedac6828,false] 7 --- [-nio-80-exec-16] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×27)
  09:19:13.452 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67419e02a437380001df0f9b\",\"_links\":{\"  (×60)
  09:19:13.463 [front-end] Order response: {"statusCode":400,"body":{"cause":{"cause":{"cause":null,"message":"Conflicting setter definitions for property \"items\": works.weave.socks.ord  (×60)
  09:19:13.662 [carts] 2024-11-23 09:19:13.662 INFO [carts,c84c766a34afbf7b,9a15929f3bc26093,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×31)
  09:19:14.214 [front-end] Merging carts for customer id: 67419e12a437380001df0fd6 and session id: qVMrBxGmee4Baz_ItL0NB1uBnNsK3VLT  (×56)
  09:19:14.677 [user] ts=2024-11-23T09:19:14.677018369Z caller=middlewares.go:46 method=Register username=ntxxoRfEjJswD email=ntxxoRfEjJswD@gmail.com took=2.353277ms  (×29)
  09:19:15.384 [catalogue] ts=2024-11-23T09:19:15Z caller=logging.go:85 method=Health result=2 took=28.055µs  (×40)
  09:19:19.709 [front-end] Received response: "{\"firstName\":\"LeJzXiQab\",\"lastName\":\"LeJzXiQab\",\"username\":\"LeJzXiQab\",\"id\":\"67419e04a437380001df0fa1\",\"_links\":{\"address
  09:19:22.181 [orders] 2024-11-23 09:19:22.181 ERROR [orders,97303fc106801b03,910a0afdfec0382a,false] 7 --- [-nio-80-exec-10] o.s.d.r.w.RepositoryRestExceptionHandler : Could not read  (×5)
  09:19:24.270 [carts-db] {"t":{"$date":"2024-11-23T09:19:24.270+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235356
  09:19:25.534 [user] ts=2024-11-23T09:19:25.534150675Z caller=middlewares.go:46 method=Register username=kosxYC email=kosxYC@gmail.com took=2.919084ms
  09:19:26.192 [user] ts=2024-11-23T09:19:26.192711303Z caller=middlewares.go:46 method=Register username=glcXzQ email=glcXzQ@gmail.com took=2.624805ms
  09:19:28.314 [front-end] Received response: "{\"firstName\":\"WTAoVHB\",\"lastName\":\"WTAoVHB\",\"username\":\"WTAoVHB\",\"id\":\"67419e04a437380001df0f9f\",\"_links\":{\"addresses\":{
  09:19:30.429 [front-end] Received response: "{\"firstName\":\"pbndm\",\"lastName\":\"pbndm\",\"username\":\"pbndm\",\"id\":\"67419e12a437380001df0fd6\",\"_links\":{\"addresses\":{\"href
  09:19:33.257 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×5)
  09:19:34.546 [front-end] Posting Customer: {"username":"dqwrDvzE","password":"nRjfipW","email":"dqwrDvzE@gmail.com","firstName":"dqwrDvzE","lastName":"dqwrDvzE"}
  09:19:37.477 [front-end] Received response: "{\"firstName\":\"oayeNqZ\",\"lastName\":\"oayeNqZ\",\"username\":\"oayeNqZ\",\"id\":\"67419e15a437380001df0fe2\",\"_links\":{\"addresses\":{
  09:19:42.379 [front-end] Posting Customer: {"username":"uJMVVm","password":"HbxAP","email":"uJMVVm@gmail.com","firstName":"uJMVVm","lastName":"uJMVVm"}
  09:19:44.140 [user] ts=2024-11-23T09:19:44.140708917Z caller=middlewares.go:46 method=Register username=GmvHxVjCB email=GmvHxVjCB@gmail.com took=2.880265ms
  09:19:47.967 [front-end] Received response: "{\"firstName\":\"XKsEvwhxtODCc\",\"lastName\":\"XKsEvwhxtODCc\",\"username\":\"XKsEvwhxtODCc\",\"id\":\"67419e1da437380001df0ff5\",\"_links\
  09:19:51.762 [front-end] Received response: "{\"firstName\":\"dqwrDvzE\",\"lastName\":\"dqwrDvzE\",\"username\":\"dqwrDvzE\",\"id\":\"67419e26a437380001df1011\",\"_links\":{\"addresses\
  09:19:55.758 [front-end] Posting Customer: {"username":"efJbZzcReTczu","password":"OZfWiNgA","email":"efJbZzcReTczu@gmail.com","firstName":"efJbZzcReTczu","lastName":"efJbZzcReTczu"}
  09:19:57.353 [front-end] Received response: "{\"firstName\":\"xpJyGBMv\",\"lastName\":\"xpJyGBMv\",\"username\":\"xpJyGBMv\",\"id\":\"67419e26a437380001df100d\",\"_links\":{\"addresses\
  09:19:59.627 [front-end] Posting Customer: {"username":"WgtkwctWrjBts","password":"QqKYW","email":"WgtkwctWrjBts@gmail.com","firstName":"WgtkwctWrjBts","lastName":"WgtkwctWrjBts"}
  09:20:03.131 [front-end] Posting Customer: {"username":"mgtNBYXSjcnJB","password":"QjgeIRVIc","email":"mgtNBYXSjcnJB@gmail.com","firstName":"mgtNBYXSjcnJB","lastName":"mgtNBYXSjcnJB"}
  09:20:07.944 [front-end] Posting Customer: {"username":"rQUBFxEFqGn","password":"reWGcVLZ","email":"rQUBFxEFqGn@gmail.com","firstName":"rQUBFxEFqGn","lastName":"rQUBFxEFqGn"}
  09:20:09.024 [front-end] Received response: "{\"firstName\":\"yZtAowxU\",\"lastName\":\"yZtAowxU\",\"username\":\"yZtAowxU\",\"id\":\"67419e36a437380001df1039\",\"_links\":{\"addresses\

## p0350
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service payment, 2024-11-22T03:27:34.844Z
```
{"timestamp":1732246054844166400,"container_name":"payment","pod_name":"payment-78bf948dc4-kdg7s","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:27:34Z caller=logging.go:40 method=Health result=1 took=5.054µs"}
```
Same service, the 2 minutes before (oldest first):
  03:27:22.696 [payment] ts=2024-11-22T03:27:22Z caller=logging.go:29 method=Authorise result=true took=846ns  (×9)
  03:27:22.843 [payment] ts=2024-11-22T03:27:22Z caller=logging.go:40 method=Health result=1 took=7.48µs  (×9)
  03:27:23.613 [payment] ts=2024-11-22T03:27:23Z caller=logging.go:29 method=Authorise result=true took=1.195µs  (×2)
All services, 30 seconds either side (sampled):
  03:27:05.275 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff9ffb0df5c00019b2387"}  (×66)
  03:27:05.375 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  03:27:06.034 [front-end] { id: '673ffa0ab0df5c00019b23a9' }  (×59)
  03:27:07.135 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×6)
  03:27:09.234 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×6)
  03:27:10.210 [user] ts=2024-11-22T03:27:10.210761788Z caller=middlewares.go:134 method=GetCards id=673ff9fbb0df5c00019b237e result=1 took=815.736µs  (×40)
  03:27:10.239 [front-end] Order response: {"id":"673ffa0ed94b9000069b44c7","customerId":"673ff9f4b0df5c00019b2371","customer":{"id":null,"firstName":"WbKHnDyVcJa","lastName":"WbKHnDyVcJa
  03:27:10.660 [front-end] Order response: {"id":"673ffa0ed94b9000069b44c8","customerId":"673ff9f6b0df5c00019b2375","customer":{"id":null,"firstName":"bbYWewjvzoix","lastName":"bbYWewjvzo
  03:27:12.289 [front-end] Received response: "{\"firstName\":\"CyawXQaJ\",\"lastName\":\"CyawXQaJ\",\"username\":\"CyawXQaJ\",\"id\":\"673ff9fdb0df5c00019b2382\",\"_links\":{\"addresses\
  03:27:13.394 [front-end] Posting Customer: {"username":"rmpUlzccFXpPIQ","password":"gvUyLV","email":"rmpUlzccFXpPIQ@gmail.com","firstName":"rmpUlzccFXpPIQ","lastName":"rmpUlzccFXpPIQ"}
  03:27:16.818 [front-end] Posting Customer: {"username":"rhWZtvHgaUJbj","password":"gUPGs","email":"rhWZtvHgaUJbj@gmail.com","firstName":"rhWZtvHgaUJbj","lastName":"rhWZtvHgaUJbj"}
  03:27:18.104 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa16d94b9000069b44d0","customerId":"673ff9fdb0df5c00019b2386","customer":{"id":null,"firstName":"MZNwuRjKqAC
  03:27:20.461 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×6)
  03:27:22.166 [front-end] Order response: {"id":"673ffa1ad94b9000069b44d4","customerId":"673ffa0bb0df5c00019b23b0","customer":{"id":null,"firstName":"DSnhBHKixU","lastName":"DSnhBHKixU",
  03:27:23.625 [front-end] Order response: {"id":"673ffa1bd94b9000069b44d7","customerId":"673ffa07b0df5c00019b23a0","customer":{"id":null,"firstName":"wDKANSSusfHVV","lastName":"wDKANSSus
  03:27:25.499 [front-end] Received response: "{\"firstName\":\"ebbhX\",\"lastName\":\"ebbhX\",\"username\":\"ebbhX\",\"id\":\"673ffa02b0df5c00019b238e\",\"_links\":{\"addresses\":{\"href
  03:27:29.764 [front-end] Received response: "{\"firstName\":\"UaskabiG\",\"lastName\":\"UaskabiG\",\"username\":\"UaskabiG\",\"id\":\"673ffa0eb0df5c00019b23be\",\"_links\":{\"addresses\
  03:27:31.567 [front-end] Order response: {"id":"673ffa23d94b9000069b44df","customerId":"673ffa11b0df5c00019b23c8","customer":{"id":null,"firstName":"RPpMC","lastName":"RPpMC","username"
  03:27:35.066 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa27d94b9000069b44e2","customerId":"673ffa14b0df5c00019b23d3","customer":{"id":null,"firstName":"rhWZtvHgaUJ
  03:27:37.794 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa29d94b9000069b44e5","customerId":"673ffa14b0df5c00019b23d2","customer":{"id":null,"firstName":"HIBdGX","la
  03:27:42.345 [front-end] Posting Customer: {"username":"LRCjsc","password":"dLbFi","email":"LRCjsc@gmail.com","firstName":"LRCjsc","lastName":"LRCjsc"}
  03:27:44.106 [front-end] Posting Customer: {"username":"bMaqCI","password":"XDgCFaZ","email":"bMaqCI@gmail.com","firstName":"bMaqCI","lastName":"bMaqCI"}
  03:27:47.343 [front-end] Posting Customer: {"username":"QvgDSKrkpORdVT","password":"gGGBWs","email":"QvgDSKrkpORdVT@gmail.com","firstName":"QvgDSKrkpORdVT","lastName":"QvgDSKrkpORdVT"}
  03:27:51.003 [front-end] Posting Customer: {"username":"yvPwZXtnc","password":"raWJcIxZu","email":"yvPwZXtnc@gmail.com","firstName":"yvPwZXtnc","lastName":"yvPwZXtnc"}
  03:27:52.502 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa38d94b9000069b44ed","customerId":"673ffa24b0df5c00019b23fc","customer":{"id":null,"firstName":"ANuwbUdSczC
  03:27:54.357 [user] ts=2024-11-22T03:27:54.357181767Z caller=middlewares.go:46 method=Register username=YKTDGnd email=YKTDGnd@gmail.com took=1.010209ms
  03:27:58.337 [queue-master] 2024-11-22 03:27:58.336 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×21)
  03:28:01.910 [front-end] Posting Customer: {"username":"DMbgRiN","password":"AgrvYcwjpp","email":"DMbgRiN@gmail.com","firstName":"DMbgRiN","lastName":"DMbgRiN"}
  03:28:03.588 [front-end] Received response: "{\"firstName\":\"BgPsShb\",\"lastName\":\"BgPsShb\",\"username\":\"BgPsShb\",\"id\":\"673ffa2eb0df5c00019b2413\",\"_links\":{\"addresses\":{

## p0093
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T21:50:33.503Z
```
{"service":"dbservice1","message":"2021-08-13 21:50:33,503 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 9ab26c9431c86723 | 6d9dac3a-fc3d-11eb-b734-0242ac110004-XdvDclow-.6V*l<n+>x/B token generate success token=MTYyODg2MjYzMy41MDMxNzE3OjZkOWRhYzNhLWZjM2QtMTFlYi1iNzM0LTAyNDJhYzExMDAwNFhkdkRjbG93LjZWKmw8bis-eC9COjE2Mjg4NjI2OTMuNTAzMTgyMjowODY3MThiZTA0M2VhNDNkZWRlYjY3MzU1MTRkYWZjMg=="}
```
Same service, the 2 minutes before (oldest first):
  21:50:25.891 [dbservice1] INFO 69064a6a-fc3d-11eb-8738-0242ac110004-hsWGAMiu-TpvY4Uf=Ir0S token generate success token=MTYyODg2MjYyNS44OTEwMjk6NjkwNjRhNmEtZmMzZC0xMWViLTg3MzgtMDI0MmFjMTE
  21:50:25.935 [dbservice1] INFO 69177e8e-fc3d-11eb-a59a-0242ac110004-rwmAxZUJ-sJ-O<z6y}5:. token generate success token=MTYyODg2MjYyNS45MzQ5NDM0OjY5MTc3ZThlLWZjM2QtMTFlYi1hNTlhLTAyNDJhYzE
  21:50:26.561 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  21:50:26.562 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  21:50:26.663 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  21:50:28.673 [dbservice1] INFO query = select passwards from username_table where user_name='lEKkjfpD'  (×4)
  21:50:28.750 [dbservice1] INFO 6ad6f6e6-fc3d-11eb-8d4f-0242ac110003-lEKkjfpD-^a37_&?:CJeS token generate success token=MTYyODg2MjYyOC43NDk2ODY3OjZhZDZmNmU2LWZjM2QtMTFlYi04ZDRmLTAyNDJhYzE
  21:50:29.607 [dbservice1] INFO 6b60ff8a-fc3d-11eb-86fb-0242ac110003-LCiNwseu-1Gx/6#-sue%D token generate success token=MTYyODg2MjYyOS42MDc1MzIzOjZiNjBmZjhhLWZjM2QtMTFlYi04NmZiLTAyNDJhYzE
  21:50:31.823 [dbservice1] INFO 6ca53122-fc3d-11eb-beb3-0242ac110004-aolWDIFH-Z(_kMcNp^guh token generate success token=MTYyODg2MjYzMS44MjI3Njk0OjZjYTUzMTIyLWZjM2QtMTFlYi1iZWIzLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  21:50:03.503 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×44)
  21:50:03.677 [mobservice1] INFO info 5c126e60-fc3d-11eb-811f-0242ac110004:cvBGfCKh write success
  21:50:03.818 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×42)
  21:50:04.083 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  21:50:04.751 [dbservice1] INFO query = select passwards from username_table where user_name='SDgLpeFn'  (×47)
  21:50:05.097 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×42)
  21:50:05.328 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×43)
  21:50:05.687 [dbservice2] INFO 5d0b3e46-fc3d-11eb-99c6-0242ac110003-OLdMPCWp-Ex_*#KLSv+d@ token generate success token=MTYyODg2MjYwNS42ODY2NjQzOjVkMGIzZTQ2LWZjM2QtMTFlYi05OWM2LTAyNDJhYzE
  21:50:07.727 [mobservice2] INFO info 5e843cdc-fc3d-11eb-9dfd-0242ac110003:isocSGgr write success
  21:50:09.598 [webservice1] ERROR an error occurred in the downstream service  (×4)
  21:50:11.930 [dbservice2] INFO 60c4974e-fc3d-11eb-8718-0242ac110003-JuoeTjfH-</8-1d:T#)+0 token generate success token=MTYyODg2MjYxMS45MzAxODM6NjBjNDk3NGUtZmMzZC0xMWViLTg3MTgtMDI0MmFjMTE
  21:50:14.501 [dbservice1] INFO 62530406-fc3d-11eb-9fa7-0242ac110004-qGsACact-OLn4e%19wo@B token generate success token=MTYyODg2MjYxNC41MDA4MjIzOjYyNTMwNDA2LWZjM2QtMTFlYi05ZmE3LTAyNDJhYzE
  21:50:19.791 [mobservice2] INFO info 65b143a6-fc3d-11eb-b3a4-0242ac110003:SxlGNrtW write success
  21:50:25.891 [dbservice1] INFO 69064a6a-fc3d-11eb-8738-0242ac110004-hsWGAMiu-TpvY4Uf=Ir0S token generate success token=MTYyODg2MjYyNS44OTEwMjk6NjkwNjRhNmEtZmMzZC0xMWViLTg3MzgtMDI0MmFjMTE
  21:50:28.397 [mobservice1] INFO info 6ad6f6e6-fc3d-11eb-8d4f-0242ac110003:lEKkjfpD write success
  21:50:31.018 [dbservice2] INFO 6c3f3f2a-fc3d-11eb-822c-0242ac110003-uanSAwbe-?}&24M+%6S7w token generate success token=MTYyODg2MjYzMS4wMTg1MDk6NmMzZjNmMmEtZmMzZC0xMWViLTgyMmMtMDI0MmFjMTE
  21:50:33.983 [mobservice1] INFO info 6e239264-fc3d-11eb-890c-0242ac110004:OZLcYfyD write success
  21:50:36.388 [mobservice1] INFO info 6f987c18-fc3d-11eb-ad82-0242ac110003:NWUBeIdk write success
  21:50:38.859 [mobservice2] INFO info 710831e2-fc3d-11eb-bb6f-0242ac110003:ITinMyWu write success
  21:50:41.282 [mobservice2] INFO info 7284ad48-fc3d-11eb-b914-0242ac110003:rhVoyqAc write success
  21:50:43.796 [dbservice1] INFO 73d8a01e-fc3d-11eb-b0a4-0242ac110003-kSydCulh-F.=SY-p}A<BQ token generate success token=MTYyODg2MjY0My43OTU5OTIxOjczZDhhMDFlLWZjM2QtMTFlYi1iMGE0LTAyNDJhYzE
  21:50:47.074 [dbservice1] INFO 75c2dd0e-fc3d-11eb-be6a-0242ac110004-ALRXkDds-%t(^UlzPXqY& token generate success token=MTYyODg2MjY0Ny4wNzQyNDc2Ojc1YzJkZDBlLWZjM2QtMTFlYi1iZTZhLTAyNDJhYzE
  21:50:49.654 [dbservice2] INFO 7748792c-fc3d-11eb-8b7c-0242ac110004-LCiNwseu-1Gx/6#-sue%D token generate success token=MTYyODg2MjY0OS42NTM2OTQ2Ojc3NDg3OTJjLWZjM2QtMTFlYi04YjdjLTAyNDJhYzE
  21:50:52.139 [dbservice1] INFO 78c2aa20-fc3d-11eb-b98a-0242ac110003-aSkwezTX-Doutvs-I7}05 token generate success token=MTYyODg2MjY1Mi4xMzg3NzI3Ojc4YzJhYTIwLWZjM2QtMTFlYi1iOThhLTAyNDJhYzE
  21:50:54.797 [dbservice1] INFO 7a3ffb50-fc3d-11eb-aba4-0242ac110003-frspTAey-W__pHMh/&E4v token generate success token=MTYyODg2MjY1NC43OTcyOTk2OjdhM2ZmYjUwLWZjM2QtMTFlYi1hYmE0LTAyNDJhYzE
  21:50:57.690 [mobservice1] INFO info 7c3867a8-fc3d-11eb-a3fb-0242ac110004:pyWndFNv write success
  21:51:00.506 [dbservice1] INFO 7dc0096e-fc3d-11eb-a19c-0242ac110004-pfVurBxD-Ztdq=blh$j*M token generate success token=MTYyODg2MjY2MC41MDYzNjQ4OjdkYzAwOTZlLWZjM2QtMTFlYi1hMTljLTAyNDJhYzE
  21:51:03.400 [dbservice1] INFO 7f779948-fc3d-11eb-892a-0242ac110003-bTcUudlx-Uo$*J-a97Ai} token generate success token=MTYyODg2MjY2My4zOTk5Mzk1OjdmNzc5OTQ4LWZjM2QtMTFlYi04OTJhLTAyNDJhYzE

## p0417
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T04:01:13.036Z
```
{"timestamp":1732248073036751600,"container_name":"front-end","pod_name":"front-end-ccbbfbf7f-szg8d","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"set cookie67400209b0df5c00019b3c1e"}
```
Same service, the 2 minutes before (oldest first):
  04:01:12.933 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67400
  04:01:12.933 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"674001f9b0df5c00019b3be2\",\"_links\":{\"
  04:01:12.933 [front-end] [ undefined, undefined ]
  04:01:12.933 [front-end] Posting Order: {"customer":"http://user/customers/674001f0b0df5c00019b3bcb","address":"http://user/addresses/674001f9b0df5c00019b3be1","card":"http://user/cards
  04:01:12.965 [front-end] Order response: {"statusCode":201,"body":{"id":"67400208d94b9000069b4aea","customerId":"674001f0b0df5c00019b3bcb","customer":{"id":null,"firstName":"mjtwTzv","l
  04:01:12.965 [front-end] Order response: {"id":"67400208d94b9000069b4aea","customerId":"674001f0b0df5c00019b3bcb","customer":{"id":null,"firstName":"mjtwTzv","lastName":"mjtwTzv","usern
  04:01:12.966 [front-end] Posting Customer: {"username":"aXptBLKX","password":"miLRxTDRZ","email":"aXptBLKX@gmail.com","firstName":"aXptBLKX","lastName":"aXptBLKX"}
  04:01:12.967 [front-end] POST /orders 201 - ms - -
  04:01:12.973 [front-end] { id: '67400208b0df5c00019b3c1d' }  (×2)
  04:01:12.973 [front-end] 67400208b0df5c00019b3c1d  (×2)
  04:01:12.973 [front-end] Merging carts for customer id: 67400208b0df5c00019b3c1d and session id: Dyf8Qatn1VrdBcswy_tGXy-dGV-jheja  (×2)
  04:01:12.996 [front-end] Carts merged.  (×2)
  04:01:12.996 [front-end] set cookie67400208b0df5c00019b3c1d
  04:01:12.997 [front-end] Sent cookies.
  04:01:12.998 [front-end] POST /register 200 30.772 ms - 33
  04:01:13.003 [front-end] Posting Customer: {"username":"aUyrX","password":"NwCNa","email":"aUyrX@gmail.com","firstName":"aUyrX","lastName":"aUyrX"}
All services, 30 seconds either side (sampled):
  04:00:43.120 [catalogue] ts=2024-11-22T04:00:43Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.841929ms  (×64)
  04:00:43.436 [front-end] GET Request to: http://user/customers/674001d6b0df5c00019b3b76/addresses  (×124)
  04:00:43.463 [orders] 2024-11-22 04:00:43.463 INFO [orders,2b68f4f547826431,5d926c6b3d2307d7,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×26)
  04:00:43.474 [front-end] POST to carts: http://carts/carts/674001e2b0df5c00019b3bab/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×32)
  04:00:43.582 [front-end] set cookie674001ebb0df5c00019b3bc0  (×62)
  04:00:44.611 [orders] 2024-11-22 04:00:44.611 INFO [orders,fb57031c77be58ae,8234b3b5a24a587b,false] 6 --- [p-nio-80-exec-7] w.w.s.o.controllers.OrdersController : Received payment re  (×36)
  04:00:45.433 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×6)
  04:00:46.981 [front-end] Received response: "{\"firstName\":\"XPwxBwkNNXQb\",\"lastName\":\"XPwxBwkNNXQb\",\"username\":\"XPwxBwkNNXQb\",\"id\":\"674001d9b0df5c00019b3b8c\",\"_links\":{
  04:00:48.789 [front-end] Posting Customer: {"username":"FpROClLXrgTaQu","password":"BQhIuBzIpy","email":"FpROClLXrgTaQu@gmail.com","firstName":"FpROClLXrgTaQu","lastName":"FpROClLXrgTaQ
  04:00:51.320 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×7)
  04:00:54.684 [front-end] Posting Customer: {"username":"lGtCgKUXeGfyN","password":"eyVAYoB","email":"lGtCgKUXeGfyN@gmail.com","firstName":"lGtCgKUXeGfyN","lastName":"lGtCgKUXeGfyN"}
  04:00:56.681 [front-end] Order response: {"id":"674001f8d94b9000069b4adb","customerId":"674001e1b0df5c00019b3ba9","customer":{"id":null,"firstName":"CpuuFDvkyVBlaLe","lastName":"CpuuFDv
  04:00:58.171 [front-end] Order response: {"statusCode":201,"body":{"id":"674001fad94b9000069b4add","customerId":"674001e2b0df5c00019b3bac","customer":{"id":null,"firstName":"soekMYcUEbs
  04:00:59.585 [front-end] Order response: {"id":"674001fbd94b9000069b4adf","customerId":"674001e8b0df5c00019b3bb3","customer":{"id":null,"firstName":"SIMHRHXbMegRoh","lastName":"SIMHRHXb
  04:01:03.515 [front-end] Order response: {"id":"674001ffd94b9000069b4ae2","customerId":"674001eab0df5c00019b3bb8","customer":{"id":null,"firstName":"sWEICyZsxBpGXFx","lastName":"sWEICyZ
  04:01:07.688 [user] ts=2024-11-22T04:01:07.688107435Z caller=middlewares.go:46 method=Register username=bjBTXWhy email=bjBTXWhy@gmail.com took=1.026899ms
  04:01:11.289 [front-end] Order response: {"id":"67400207d94b9000069b4ae7","customerId":"674001f5b0df5c00019b3bd9","customer":{"id":null,"firstName":"QaXlSaWylpxhFLT","lastName":"QaXlSaW
  04:01:12.966 [front-end] Posting Customer: {"username":"aXptBLKX","password":"miLRxTDRZ","email":"aXptBLKX@gmail.com","firstName":"aXptBLKX","lastName":"aXptBLKX"}
  04:01:15.489 [front-end] Order response: {"statusCode":201,"body":{"id":"6740020bd94b9000069b4aed","customerId":"674001f8b0df5c00019b3bde","customer":{"id":null,"firstName":"cnDPOFpKbVC
  04:01:18.800 [front-end] Order response: {"id":"6740020ed94b9000069b4af0","customerId":"674001f8b0df5c00019b3bdf","customer":{"id":null,"firstName":"ZVxEbVWQIdup","lastName":"ZVxEbVWQId
  04:01:19.450 [front-end] Posting Customer: {"username":"rjnaXWAPvACTM","password":"EdhAxBLjd","email":"rjnaXWAPvACTM@gmail.com","firstName":"rjnaXWAPvACTM","lastName":"rjnaXWAPvACTM"}
  04:01:21.629 [front-end] Order response: {"id":"67400211d94b9000069b4af6","customerId":"674001ffb0df5c00019b3c01","customer":{"id":null,"firstName":"YaBMSdwOErk","lastName":"YaBMSdwOErk
  04:01:24.666 [front-end] Order response: {"statusCode":201,"body":{"id":"67400214d94b9000069b4af8","customerId":"67400201b0df5c00019b3c0c","customer":{"id":null,"firstName":"reiDfcgUoaw
  04:01:29.154 [orders-db] {"t":{"$date":"2024-11-22T04:01:29.154+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224808
  04:01:31.237 [front-end] Posting Customer: {"username":"ZkjsIOEoVAb","password":"ykxoqK","email":"ZkjsIOEoVAb@gmail.com","firstName":"ZkjsIOEoVAb","lastName":"ZkjsIOEoVAb"}
  04:01:36.957 [front-end] Posting Customer: {"username":"bvZHHJIjOsnR","password":"YKMOTJDA","email":"bvZHHJIjOsnR@gmail.com","firstName":"bvZHHJIjOsnR","lastName":"bvZHHJIjOsnR"}
  04:01:39.885 [front-end] Order response: {"id":"67400223d94b9000069b4b01","customerId":"67400215b0df5c00019b3c39","customer":{"id":null,"firstName":"VnCRUBjowSa","lastName":"VnCRUBjowSa
  04:01:40.504 [front-end] Posting Customer: {"username":"HHXukTfpt","password":"lKSVHXpJ","email":"HHXukTfpt@gmail.com","firstName":"HHXukTfpt","lastName":"HHXukTfpt"}
  04:01:41.121 [front-end] Order response: {"id":"67400225d94b9000069b4b05","customerId":"67400211b0df5c00019b3c2c","customer":{"id":null,"firstName":"YZoSrOYEwuTvaRp","lastName":"YZoSrOY
