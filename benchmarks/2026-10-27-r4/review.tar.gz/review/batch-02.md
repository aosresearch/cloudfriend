## p0067
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T08:58:33.813Z
```
{"service":"dbservice1","message":"2021-08-13 08:58:33,813 | ERROR | 0.0.0.4 | dbservice1 | db_helper.py -> sql_ano_prob -> 92 | 55370813698192ae | (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)"}
```
Same service, the 2 minutes before (oldest first):
  08:58:26.007 [dbservice1] INFO query = select passwards from username_table where user_name='qfGXigUn'  (×5)
  08:58:26.084 [dbservice1] INFO 9056feaa-fbd1-11eb-9215-0242ac110004-qfGXigUn-23/FgZd1mV+c token generate success token=MTYyODgxNjMwNi4wODQzMTQ2OjkwNTZmZWFhLWZiZDEtMTFlYi05MjE1LTAyNDJhYzE
  08:58:28.071 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:58:28.071 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  08:58:28.191 [dbservice1] INFO 918cb756-fbd1-11eb-bac4-0242ac110003-rwmAxZUJ-sJ-O<z6y}5:. token generate success token=MTYyODgxNjMwOC4xOTEzMzE0OjkxOGNiNzU2LWZiZDEtMTFlYi1iYWM0LTAyNDJhYzE
  08:58:31.061 [dbservice1] INFO 934a4da6-fbd1-11eb-9e71-0242ac110004-RkyaDUzj-CP^rTmJ8QHM$ token generate success token=MTYyODgxNjMxMS4wNjExNzk5OjkzNGE0ZGE2LWZiZDEtMTFlYi05ZTcxLTAyNDJhYzE
  08:58:32.617 [dbservice1] INFO 94475802-fbd1-11eb-ba97-0242ac110004-Jcofhzdp-#N?Ss5kvhTH7 token generate success token=MTYyODgxNjMxMi42MTY2NTQ5Ojk0NDc1ODAyLWZiZDEtMTFlYi1iYTk3LTAyNDJhYzE
  08:58:33.374 [dbservice1] INFO 94b2095e-fbd1-11eb-97d0-0242ac110003-ockFwOnC-_0K6_54f^L?M token generate success token=MTYyODgxNjMxMy4zNzM2NDc1Ojk0YjIwOTVlLWZiZDEtMTFlYi05N2QwLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  08:58:03.833 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×50)
  08:58:04.081 [redisservice2] INFO redis读取信息成功, status_code: 200  (×56)
  08:58:04.190 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×54)
  08:58:04.349 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×49)
  08:58:04.580 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×56)
  08:58:04.677 [redisservice1] INFO redis write success  (×100)
  08:58:04.985 [mobservice1] INFO info 84020546-fbd1-11eb-baad-0242ac110003:VizMUmJR write success
  08:58:05.274 [webservice1] ERROR an error occurred in the downstream service  (×29)
  08:58:05.613 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '845bebf6-fbd1-11eb-8710-0242ac110004'}  (×58)
  08:58:06.466 [mobservice2] INFO info 84d5543c-fbd1-11eb-92b6-0242ac110003:WQyFOAmB write success
  08:58:09.266 [mobservice2] INFO info 868abc72-fbd1-11eb-a447-0242ac110003:geuyhpUk write success
  08:58:11.495 [mobservice1] INFO info 87e11b3e-fbd1-11eb-b636-0242ac110003:OSENDWPb write success
  08:58:15.779 [mobservice1] INFO info 8a65e556-fbd1-11eb-9eb9-0242ac110003:jhoAGDST write success
  08:58:19.167 [mobservice2] INFO info 8c6cbeba-fbd1-11eb-9dd1-0242ac110004:NGJTlZWq write success
  08:58:21.320 [dbservice1] INFO 8d77e5e6-fbd1-11eb-a844-0242ac110003-FqaTIXhn-^vCabrQL@MgF token generate success token=MTYyODgxNjMwMS4zMjAxMzM6OGQ3N2U1ZTYtZmJkMS0xMWViLWE4NDQtMDI0MmFjMTE
  08:58:24.901 [mobservice1] INFO info 8fdc4674-fbd1-11eb-be74-0242ac110004:QghyctJY write success
  08:58:28.702 [mobservice2] INFO info 92208ada-fbd1-11eb-83b0-0242ac110004:PQTXyvDH write success
  08:58:32.240 [mobservice1] INFO info 94475802-fbd1-11eb-ba97-0242ac110004:Jcofhzdp write success
  08:58:34.530 [mobservice1] INFO info 95a1eb36-fbd1-11eb-b6f0-0242ac110003:CkWFaQYZ write success
  08:58:37.351 [mobservice1] INFO info 975109c6-fbd1-11eb-b5b1-0242ac110004:ZvJLFkob write success
  08:58:39.449 [dbservice1] INFO 9845cbdc-fbd1-11eb-adf8-0242ac110003-yGBubvKi-!yU_oH%S}LDM token generate success token=MTYyODgxNjMxOS40NDkyOTQ2Ojk4NDVjYmRjLWZiZDEtMTFlYi1hZGY4LTAyNDJhYzE
  08:58:42.586 [mobservice1] INFO info 9a692738-fbd1-11eb-b7dc-0242ac110004:SBgdrmlT write success
  08:58:45.029 [dbservice1] INFO 9b9a5e38-fbd1-11eb-8212-0242ac110003-cNyGSbzR-+7>ux(b)B80C token generate success token=MTYyODgxNjMyNS4wMjkzOTAzOjliOWE1ZTM4LWZiZDEtMTFlYi04MjEyLTAyNDJhYzE
  08:58:47.400 [mobservice1] INFO info 9d50b93e-fbd1-11eb-9f76-0242ac110004:GNrVKoRp write success
  08:58:50.457 [mobservice1] INFO info 9f12cd48-fbd1-11eb-8a02-0242ac110004:ucARQwLG write success
  08:58:54.170 [mobservice2] INFO info a14daf4c-fbd1-11eb-8f81-0242ac110004:CkWFaQYZ write success
  08:58:56.483 [dbservice1] INFO a249b26a-fbd1-11eb-a03c-0242ac110003-WRrkiQEt-6aT9E1w<+@(I token generate success token=MTYyODgxNjMzNi40ODM0MTM3OmEyNDliMjZhLWZiZDEtMTFlYi1hMDNjLTAyNDJhYzE
  08:58:58.844 [mobservice1] INFO info a41d98a4-fbd1-11eb-9041-0242ac110003:WtfwAnYv write success
  08:59:01.738 [mobservice2] INFO info a5ca5192-fbd1-11eb-9335-0242ac110003:ucXDZIio write success

## p0527
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T11:00:14.702Z
```
{"timestamp":1732359614702685400,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 11:00:14.702  INFO [carts,fc724daa910597d9,466705d0e4fd7608,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController   : Merge carts request received for ids: 6741b5bea437380001df548e and -cFUsIYMj6JHIVSY_4UIcTVq9sYHNhrH"}
```
Same service, the 2 minutes before (oldest first):
  11:00:11.565 [carts] 2024-11-23 11:00:11.564 INFO [carts,5a2e21a486490bc1,97896900cee9f8fe,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.CartsController : Merge carts reques  (×3)
All services, 30 seconds either side (sampled):
  10:59:45.383 [catalogue] ts=2024-11-23T10:59:45Z caller=logging.go:85 method=Health result=2 took=25.69µs  (×40)
  10:59:47.946 [front-end] npm timing npm:load:whichnode Completed in 1ms
  10:59:47.947 [front-end] npm timing config:load:file:/usr/src/app/.npmrc Completed in 0ms
  10:59:47.947 [front-end] npm timing config:load:credentials Completed in 2ms
  10:59:47.947 [front-end] npm verb title npm start
  10:59:47.954 [front-end] npm verb logfile /home/myuser/.npm/_logs/2024-11-23T10_59_47_742Z-debug-0.log
  10:59:48.150 [front-end] > node server.js 
  11:00:11.544 [front-end] Posting Customer: {"username":"RupAdllGjrdNv","password":"zJBnIlEK","email":"RupAdllGjrdNv@gmail.com","firstName":"RupAdllGjrdNv","lastName":"RupAdllGjrdNv"}
  11:00:11.594 [front-end] Carts merged.  (×33)
  11:00:13.767 [user] ts=2024-11-23T11:00:13.766919711Z caller=middlewares.go:46 method=Register username=LeMVpBYJL email=LeMVpBYJL@gmail.com took=2.686048ms
  11:00:16.606 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b5bba437380001df548b"}  (×18)
  11:00:16.689 [front-end] Attempting to delete cart for user: 6741b5bba437380001df548b  (×17)
  11:00:16.737 [front-end] POST to carts: http://carts/carts/6741b5bba437380001df548b/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×8)
  11:00:17.406 [front-end] Posting Customer: {"username":"adIieUdxY","password":"BteFOOla","email":"adIieUdxY@gmail.com","firstName":"adIieUdxY","lastName":"adIieUdxY"}
  11:00:20.023 [carts] 2024-11-23 11:00:20.022 INFO [carts,d5126330e55b94df,bcb3e2fed3927393,false] 7 --- [-nio-80-exec-17] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×7)
  11:00:21.002 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×2)
  11:00:22.451 [user] ts=2024-11-23T11:00:22.451389801Z caller=middlewares.go:46 method=Register username=RQdkCu email=RQdkCu@gmail.com took=2.404383ms
  11:00:24.738 [front-end] Posting Customer: {"username":"HOLUtFoSuMcUtKu","password":"taAJbEDhs","email":"HOLUtFoSuMcUtKu@gmail.com","firstName":"HOLUtFoSuMcUtKu","lastName":"HOLUtFoSuMc
  11:00:26.582 [front-end] Posting Customer: {"username":"uNzZjss","password":"qBQBGP","email":"uNzZjss@gmail.com","firstName":"uNzZjss","lastName":"uNzZjss"}
  11:00:27.853 [front-end] Posting Customer: {"username":"BDiOqiotxyoSpO","password":"cTCVnedEd","email":"BDiOqiotxyoSpO@gmail.com","firstName":"BDiOqiotxyoSpO","lastName":"BDiOqiotxyoSpO
  11:00:29.293 [front-end] Posting Customer: {"username":"poHItb","password":"OCZNRP","email":"poHItb@gmail.com","firstName":"poHItb","lastName":"poHItb"}
  11:00:31.342 [front-end] Posting Customer: {"username":"zmoytuQKhEgaQg","password":"VuTNFnzXNw","email":"zmoytuQKhEgaQg@gmail.com","firstName":"zmoytuQKhEgaQg","lastName":"zmoytuQKhEgaQ
  11:00:32.066 [front-end] GET Request to: http://user/customers/6741b5bda437380001df548d/addresses  (×4)
  11:00:32.104 [user] ts=2024-11-23T11:00:32.104609508Z caller=middlewares.go:104 method=GetAddresses id=6741b5c3a437380001df5496 result=1 took=1.36226ms  (×2)
  11:00:32.160 [orders] 2024-11-23 11:00:32.159 INFO [orders,6dbf9c6f3a1bb664,c50a3ec28adebad8,false] 7 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req
  11:00:32.164 [payment] ts=2024-11-23T11:00:32Z caller=logging.go:29 method=Authorise result=true took=796ns
  11:00:32.168 [front-end] }
  11:00:32.180 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!

## p0370
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:38:22.817Z
```
{"timestamp":1732246702817406700,"container_name":"carts","pod_name":"carts-6cdcbc6cd7-bswq8","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:38:22.817  INFO [carts,c57e87e56a473d72,dbcf06088e30e78e,false] 7 --- [-nio-80-exec-10] w.w.s.cart.cart.CartContentsResource     : Adding for user: Cart{id='673ffcae2f1cab0007fac608', customerId='673ffca9b0df5c00019b2ba5', items=[]}, Item{id='673ffcae2f1cab0007fac609', itemId='808a2de1-1aaa-4c25-a9b9-6612e8f29a38', quantity=1, unitPrice=17.32}"}
```
Same service, the 2 minutes before (oldest first):
  03:38:16.106 [carts] 2024-11-22 03:38:16.106 INFO [carts,b267dc0f6fcec29d,63aee39e48ec1c4b,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)
  03:38:16.603 [carts] 2024-11-22 03:38:16.603 INFO [carts,b36779d9d6a74dc3,a7a8fe92d3813e5d,false] 7 --- [-nio-80-exec-12] w.w.s.cart.controllers.CartsController : Merge carts reques  (×6)
  03:38:16.922 [carts] 2024-11-22 03:38:16.921 INFO [carts,bf88c8b7ded7b532,0784c9af4644094a,false] 7 --- [p-nio-80-exec-6] w.w.s.cart.controllers.ItemsController : Did not find item.  (×3)
  03:38:17.608 [carts] 2024-11-22 03:38:17.608 INFO [carts,4000bb6b07ad4ce1,4b410d5eefda18bb,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×4)
  03:38:19.219 [carts] 2024-11-22 03:38:19.219 INFO [carts,66a85357330dbf79,cce6c0286882c6ba,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  03:38:19.225 [carts] 2024-11-22 03:38:19.225 INFO [carts,66a85357330dbf79,cce6c0286882c6ba,false] 7 --- [-nio-80-exec-11] w.w.s.cart.cart.CartContentsResource : Adding for user: Car
All services, 30 seconds either side (sampled):
  03:37:52.843 [payment] ts=2024-11-22T03:37:52Z caller=logging.go:40 method=Health result=1 took=7.437µs  (×40)
  03:37:52.961 [user] ts=2024-11-22T03:37:52.961210062Z caller=middlewares.go:46 method=Register username=YYkQWRtwR email=YYkQWRtwR@gmail.com took=1.004884ms
  03:37:53.151 [user] ts=2024-11-22T03:37:53.15137523Z caller=middlewares.go:104 method=GetAddresses id=673ffc7eb0df5c00019b2b29 result=1 took=1.221728ms  (×12)
  03:37:53.176 [front-end] POST /orders 201 - ms - -  (×62)
  03:37:54.839 [front-end] Posting Customer: {"username":"omfQNWYRP","password":"nEfSkY","email":"omfQNWYRP@gmail.com","firstName":"omfQNWYRP","lastName":"omfQNWYRP"}
  03:37:55.144 [catalogue] ts=2024-11-22T03:37:55Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.67054m  (×7)
  03:37:55.930 [front-end] Received response: "{\"firstName\":\"pzIcVNXU\",\"lastName\":\"pzIcVNXU\",\"username\":\"pzIcVNXU\",\"id\":\"673ffc7ab0df5c00019b2b1e\",\"_links\":{\"addresses\
  03:37:57.160 [front-end] Order response: {"id":"673ffc95d94b9000069b468f","customerId":"673ffc7db0df5c00019b2b27","customer":{"id":null,"firstName":"QaHfgB","lastName":"QaHfgB","usernam
  03:37:58.910 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc96d94b9000069b4692","customerId":"673ffc7bb0df5c00019b2b22","customer":{"id":null,"firstName":"DRLKFsjGgEC
  03:38:01.010 [front-end] Order response: {"id":"673ffc99d94b9000069b4694","customerId":"673ffc82b0df5c00019b2b36","customer":{"id":null,"firstName":"sdtqfdQJsioGmP","lastName":"sdtqfdQJ
  03:38:03.374 [front-end] Received response: "{\"firstName\":\"rfQupJSJRXX\",\"lastName\":\"rfQupJSJRXX\",\"username\":\"rfQupJSJRXX\",\"id\":\"673ffc86b0df5c00019b2b40\",\"_links\":{\"a
  03:38:07.248 [front-end] Order response: {"id":"673ffc9fd94b9000069b4699","customerId":"673ffc8db0df5c00019b2b58","customer":{"id":null,"firstName":"IdiTwgAYpCuvg","lastName":"IdiTwgAYp
  03:38:10.111 [front-end] Received response: "{\"firstName\":\"YkbhnZpVSCfkTSV\",\"lastName\":\"YkbhnZpVSCfkTSV\",\"username\":\"YkbhnZpVSCfkTSV\",\"id\":\"673ffc90b0df5c00019b2b5d\",\"_
  03:38:14.423 [front-end] Received response: "{\"firstName\":\"ZHqnMzYU\",\"lastName\":\"ZHqnMzYU\",\"username\":\"ZHqnMzYU\",\"id\":\"673ffc93b0df5c00019b2b63\",\"_links\":{\"addresses\
  03:38:15.347 [front-end] Order response: {"id":"673ffca7d94b9000069b46a0","customerId":"673ffc8bb0df5c00019b2b51","customer":{"id":null,"firstName":"UXVbJmKXYvNWcY","lastName":"UXVbJmKX
  03:38:17.894 [front-end] Posting Customer: {"username":"XkjlRreAZzB","password":"bweHF","email":"XkjlRreAZzB@gmail.com","firstName":"XkjlRreAZzB","lastName":"XkjlRreAZzB"}
  03:38:21.708 [front-end] Posting Customer: {"username":"YbjgCNEg","password":"HoOnqj","email":"YbjgCNEg@gmail.com","firstName":"YbjgCNEg","lastName":"YbjgCNEg"}
  03:38:24.547 [front-end] Received response: "{\"firstName\":\"nroitNhvO\",\"lastName\":\"nroitNhvO\",\"username\":\"nroitNhvO\",\"id\":\"673ffc94b0df5c00019b2b66\",\"_links\":{\"address
  03:38:26.173 [front-end] Order response: {"id":"673ffcb2d94b9000069b46aa","customerId":"673ffca1b0df5c00019b2b92","customer":{"id":null,"firstName":"DwAwcDO","lastName":"DwAwcDO","usern
  03:38:28.711 [orders-db] {"t":{"$date":"2024-11-22T03:38:28.711+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224670
  03:38:30.085 [user] ts=2024-11-22T03:38:30.08505609Z caller=middlewares.go:46 method=Register username=faMoaEE email=faMoaEE@gmail.com took=926.509µs
  03:38:35.160 [front-end] Posting Customer: {"username":"NVheHKS","password":"PxvVzV","email":"NVheHKS@gmail.com","firstName":"NVheHKS","lastName":"NVheHKS"}
  03:38:37.849 [front-end] Received response: "{\"firstName\":\"mdVgRkhUQRCLUl\",\"lastName\":\"mdVgRkhUQRCLUl\",\"username\":\"mdVgRkhUQRCLUl\",\"id\":\"673ffca9b0df5c00019b2ba5\",\"_lin
  03:38:40.916 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffcc0d94b9000069b46b4","customerId":"673ffcacb0df5c00019b2baf","customer":{"id":null,"firstName":"oIBOGMnFstr
  03:38:42.249 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffcc2d94b9000069b46b8","customerId":"673ffcadb0df5c00019b2bb1","customer":{"id":null,"firstName":"YbjgCNEg","
  03:38:44.354 [front-end] Order response: {"id":"673ffcc4d94b9000069b46ba","customerId":"673ffcadb0df5c00019b2bb0","customer":{"id":null,"firstName":"eXqVWwXYrv","lastName":"eXqVWwXYrv",
  03:38:47.352 [front-end] Posting Customer: {"username":"zegmicVMdH","password":"SMCTr","email":"zegmicVMdH@gmail.com","firstName":"zegmicVMdH","lastName":"zegmicVMdH"}
  03:38:51.153 [front-end] Received response: "{\"firstName\":\"RuwsjWrGsteZ\",\"lastName\":\"RuwsjWrGsteZ\",\"username\":\"RuwsjWrGsteZ\",\"id\":\"673ffcbab0df5c00019b2bdb\",\"_links\":{
  03:38:52.340 [front-end] Received response: "{\"firstName\":\"zQnfal\",\"lastName\":\"zQnfal\",\"username\":\"zQnfal\",\"id\":\"673ffcbab0df5c00019b2bda\",\"_links\":{\"addresses\":{\"h

## p0005
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice2, 2021-08-13T00:59:40.475Z
```
{"service":"logservice2","message":"2021-08-13 00:59:40,475 | ERROR | 0.0.0.2 | logservice2 | login_helper.py -> login_query_methods_model -> 76 | {traci_id} | uuid expired, invalid phone request"}
```
Same service, the 2 minutes before (oldest first):
  00:59:38.209 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
  00:59:38.209 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': 'ad5946b8-fb8e-11eb-9b98-0242ac110004', 'user_id': 'yjlLtMmx'}  (×3)
  00:59:38.911 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  00:59:38.912 [logservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  00:59:38.912 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'adcfdbfc-fb8e-11eb-9349-0242ac110003'}  (×4)
  00:59:38.961 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×2)
All services, 30 seconds either side (sampled):
  00:59:10.485 [redisservice1] INFO redis读取信息成功, status_code: 200  (×33)
  00:59:10.621 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  00:59:10.859 [webservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '9d562a6a-fb8e-11eb-80d5-0242ac110004', 'value': '', 'ex': 10}  (×43)
  00:59:11.074 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×46)
  00:59:11.263 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '9d562a6a-fb8e-11eb-80d5-0242ac110004'}  (×44)
  00:59:11.915 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×34)
  00:59:12.082 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×34)
  00:59:12.241 [webservice1] INFO complete information: {'uuid': '9e108504-fb8e-11eb-8671-0242ac110003', 'user_id': 'pGnBPZOX'}  (×36)
  00:59:12.833 [dbservice1] INFO 9e108504-fb8e-11eb-8671-0242ac110003-pGnBPZOX-6+L<CAUmwH}K token generate success token=MTYyODc4NzU1Mi44MzM1MDY2OjllMTA4NTA0LWZiOGUtMTFlYi04NjcxLTAyNDJhYzE
  00:59:14.543 [mobservice1] INFO info 9f51f75e-fb8e-11eb-bffd-0242ac110004:ocwNidgD write success
  00:59:16.568 [dbservice2] INFO a05422da-fb8e-11eb-b0a0-0242ac110004-aLCdNFuD->*a5MwtuL=pF token generate success token=MTYyODc4NzU1Ni41Njc0ODA2OmEwNTQyMmRhLWZiOGUtMTFlYi1iMGEwLTAyNDJhYzE
  00:59:18.559 [mobservice1] INFO info a1be4baa-fb8e-11eb-b416-0242ac110003:jFTtOqPD write success
  00:59:20.910 [mobservice2] INFO info a3229f14-fb8e-11eb-97f6-0242ac110003:oneLisuW write success
  00:59:23.384 [mobservice1] INFO info a4947958-fb8e-11eb-a504-0242ac110004:LmHpecgO write success
  00:59:25.384 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  00:59:36.004 [dbservice1] INFO abe89b12-fb8e-11eb-b53c-0242ac110003-pSzgtGmR-AbJNYZe+wsGL token generate success token=MTYyODc4NzU3Ni4wMDM5NTE4OmFiZTg5YjEyLWZiOGUtMTFlYi1iNTNjLTAyNDJhYzE  (×3)
  00:59:38.835 [mobservice1] INFO info adcfdbfc-fb8e-11eb-9349-0242ac110003:bCKBvESO write success
  00:59:40.436 [redisservice1] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400
  00:59:42.339 [dbservice2] INFO afb61e22-fb8e-11eb-80c1-0242ac110003-zAFcSJGh-WGbA}P/<Tcy7 token generate success token=MTYyODc4NzU4Mi4zMzkzNTk1OmFmYjYxZTIyLWZiOGUtMTFlYi04MGMxLTAyNDJhYzE
  00:59:45.321 [mobservice1] INFO info b1aaa05e-fb8e-11eb-a40d-0242ac110004:uGrcWJOt write success
  00:59:47.737 [mobservice2] INFO info b32168a0-fb8e-11eb-a1b3-0242ac110003:AFDxXgnQ write success
  00:59:50.053 [dbservice2] INFO b42f7a16-fb8e-11eb-99c4-0242ac110003-QSUqdTsv-er_ATbj}/nc7 token generate success token=MTYyODc4NzU5MC4wNTM0MDg2OmI0MmY3YTE2LWZiOGUtMTFlYi05OWM0LTAyNDJhYzE
  00:59:52.659 [dbservice2] INFO b5ce35d8-fb8e-11eb-b3b9-0242ac110004-IFyHcfZd-)BYaIRlCgv21 token generate success token=MTYyODc4NzU5Mi42NTkxNjQ0OmI1Y2UzNWQ4LWZiOGUtMTFlYi1iM2I5LTAyNDJhYzE
  00:59:54.850 [dbservice1] INFO b711b280-fb8e-11eb-9e3a-0242ac110004-cwpAkUMO-a)qtpDIghOB2 token generate success token=MTYyODc4NzU5NC44NTA1MzE6YjcxMWIyODAtZmI4ZS0xMWViLTllM2EtMDI0MmFjMTE
  00:59:57.376 [mobservice1] INFO info b8d4be6e-fb8e-11eb-95ee-0242ac110004:FuZbUPph write success
  00:59:59.392 [mobservice1] INFO info ba0e874c-fb8e-11eb-a33e-0242ac110003:DtNVdFIW write success
  01:00:01.746 [dbservice1] INFO bb38c63c-fb8e-11eb-8562-0242ac110004-QTpUuoqV-YqVdzJC)oyBb token generate success token=MTYyODc4NzYwMS43NDYyOTcxOmJiMzhjNjNjLWZiOGUtMTFlYi04NTYyLTAyNDJhYzE
  01:00:04.004 [mobservice1] INFO info bccdeb12-fb8e-11eb-a8bd-0242ac110003:HXuSgZPY write success
  01:00:06.600 [dbservice1] INFO be1fa988-fb8e-11eb-9f97-0242ac110004-cgKfeRjJ-?%FBPz^@kcZD token generate success token=MTYyODc4NzYwNi41OTk5OTc6YmUxZmE5ODgtZmI4ZS0xMWViLTlmOTctMDI0MmFjMTE
  01:00:09.083 [mobservice1] INFO info bfd2dcb4-fb8e-11eb-9fc0-0242ac110004:hfWmCetl write success

## p0163
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T06:25:05.805Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731911105805577700,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  06:25:03.707 [currencyservice] conversion request successful  (×14)
  06:25:03.742 [currencyservice] Getting supported currencies...  (×6)
All services, 30 seconds either side (sampled):
  06:24:35.807 [currencyservice] Getting supported currencies...  (×251)
  06:24:35.812 [frontend] request complete  (×306)
  06:24:35.840 [frontend] request started  (×304)
  06:24:35.852 [frontend] view user cart  (×56)
  06:24:35.903 [frontend] placing order  (×12)
  06:24:35.929 [paymentservice] Transaction processed: visa ending 4366 Amount: CAD2246.544799645  (×3)
  06:24:35.934 [shippingservice] [ShipOrder] completed request  (×12)
  06:24:35.944 [checkoutservice] order confirmation email sent to "james71@example.org"
  06:24:36.204 [adservice] received ad request (context_words=[accessories])  (×30)
  06:24:36.751 [frontend] ENV_PLATFORM is: aws  (×39)
  06:24:38.599 [adservice] received ad request (context_words=[kitchen])  (×47)
  06:24:38.697 [paymentservice] Transaction processed: visa ending 6714 Amount: GBP250.814908438  (×3)
  06:24:40.013 [frontend] setting currency  (×25)
  06:24:49.871 [checkoutservice] order confirmation email sent to "andrew63@example.com"
  06:24:58.364 [emailservice] A request to send order confirmation email to lori60@example.net has been received.
  06:25:06.018 [emailservice] A request to send order confirmation email to oadams@example.net has been received.
  06:25:16.072 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"48235","nanos":492260473},"credit_card":{"credit_card_number":"491975061165  (×2)
  06:25:16.086 [checkoutservice] order confirmation email sent to "samantha90@example.com"
  06:25:19.050 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"1023","nanos":790000000},"credit_card":{"credit_card_number":"4403898043899  (×4)
  06:25:19.065 [checkoutservice] order confirmation email sent to "rebekah66@example.com"
  06:25:29.375 [emailservice] A request to send order confirmation email to kennethsteele@example.org has been received.
  06:25:31.396 [checkoutservice] order confirmation email sent to "huntdavid@example.org"
  06:25:34.880 [emailservice] A request to send order confirmation email to elizabeth09@example.com has been received.

## p0508
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:20:43.790Z
```
{"timestamp":1732353643790926300,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:20:43.790597143Z caller=middlewares.go:75 method=GetUsers id=67419e5aa437380001df10a8 result=1 took=2.681249ms"}
```
Same service, the 2 minutes before (oldest first):
  09:20:41.535 [user] ts=2024-11-23T09:20:41.535002443Z caller=middlewares.go:75 method=GetUsers id=67419e56a437380001df1093 result=1 took=1.691907ms  (×14)
  09:20:41.934 [user] ts=2024-11-23T09:20:41.934242932Z caller=middlewares.go:46 method=Register username=YyCXUhHvnDEKj email=YyCXUhHvnDEKj@gmail.com took=2.745189ms
  09:20:42.093 [user] ts=2024-11-23T09:20:42.092974199Z caller=middlewares.go:46 method=Register username=pPdBh email=pPdBh@gmail.com took=2.180733ms
  09:20:42.710 [user] ts=2024-11-23T09:20:42.710846125Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419e63a437380001df10cb took=4.375467ms  (×2)
  09:20:42.769 [user] ts=2024-11-23T09:20:42.769726501Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419e63a437380001df10cb took=4.364439ms  (×2)
All services, 30 seconds either side (sampled):
  09:20:13.850 [user] ts=2024-11-23T09:20:13.849967081Z caller=middlewares.go:157 method=Health result=2 took=2.346965ms  (×30)
  09:20:14.916 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67419e48a437380001df1071"}  (×47)
  09:20:15.000 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×47)
  09:20:15.043 [front-end] Posting Customer: {"username":"TZFGfkTrgOmT","password":"TnUTCE","email":"TZFGfkTrgOmT@gmail.com","firstName":"TZFGfkTrgOmT","lastName":"TZFGfkTrgOmT"}
  09:20:15.057 [carts] 2024-11-23 09:20:15.057 INFO [carts,fdadad4d7721196f,2784977d9c507b7b,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.CartsController : Merge carts reques  (×23)
  09:20:15.378 [carts] 2024-11-23 09:20:15.378 INFO [carts,3bb1a59876323e4b,7432aef61436d21d,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.ItemsController : Did not find item.  (×21)
  09:20:15.830 [front-end] Received response: "{\"firstName\":\"PDSUNBPTblVv\",\"lastName\":\"PDSUNBPTblVv\",\"username\":\"PDSUNBPTblVv\",\"id\":\"67419e3ba437380001df1044\",\"_links\":{
  09:20:15.852 [orders] 2024-11-23 09:20:15.851 ERROR [orders,fe506af9f522e00c,f82aba816bad38df,false] 7 --- [p-nio-80-exec-2] o.s.d.r.w.RepositoryRestExceptionHandler : Could not read  (×43)
  09:20:15.854 [front-end] POST /orders 400 - ms - -  (×48)
  09:20:16.106 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
  09:20:17.968 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×13)
  09:20:19.243 [front-end] Posting Customer: {"username":"pdoCyx","password":"qgwMIHCM","email":"pdoCyx@gmail.com","firstName":"pdoCyx","lastName":"pdoCyx"}
  09:20:19.846 [front-end] Received response: "{\"firstName\":\"uBqzxJibnoB\",\"lastName\":\"uBqzxJibnoB\",\"username\":\"uBqzxJibnoB\",\"id\":\"67419e45a437380001df1062\",\"_links\":{\"a
  09:20:21.682 [front-end] Posting Customer: {"username":"cODHTlSydyPz","password":"AiSLu","email":"cODHTlSydyPz@gmail.com","firstName":"cODHTlSydyPz","lastName":"cODHTlSydyPz"}
  09:20:24.001 [front-end] Received response: "{\"firstName\":\"efJbZzcReTczu\",\"lastName\":\"efJbZzcReTczu\",\"username\":\"efJbZzcReTczu\",\"id\":\"67419e3ba437380001df1045\",\"_links\
  09:20:25.220 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×4)
  09:20:26.534 [user] ts=2024-11-23T09:20:26.533722457Z caller=middlewares.go:46 method=Register username=yijkhezwJ email=yijkhezwJ@gmail.com took=2.652718ms
  09:20:27.451 [user] ts=2024-11-23T09:20:27.451532224Z caller=middlewares.go:46 method=Register username=YOcBo email=YOcBo@gmail.com took=2.21776ms
  09:20:31.727 [front-end] Received response: "{\"firstName\":\"mJRrxAgZsMW\",\"lastName\":\"mJRrxAgZsMW\",\"username\":\"mJRrxAgZsMW\",\"id\":\"67419e4ca437380001df1077\",\"_links\":{\"a
  09:20:33.842 [user] ts=2024-11-23T09:20:33.842275519Z caller=middlewares.go:46 method=Register username=khPSja email=khPSja@gmail.com took=2.392403ms
  09:20:35.247 [front-end] Posting Customer: {"username":"AAEYWlePmyMMgHd","password":"NbAwuN","email":"AAEYWlePmyMMgHd@gmail.com","firstName":"AAEYWlePmyMMgHd","lastName":"AAEYWlePmyMMgH
  09:20:38.111 [front-end] Received response: "{\"firstName\":\"pYXhnBEljpz\",\"lastName\":\"pYXhnBEljpz\",\"username\":\"pYXhnBEljpz\",\"id\":\"67419e56a437380001df1098\",\"_links\":{\"a
  09:20:41.056 [front-end] Received response: "{\"firstName\":\"UPaYvPL\",\"lastName\":\"UPaYvPL\",\"username\":\"UPaYvPL\",\"id\":\"67419e53a437380001df108f\",\"_links\":{\"addresses\":{
  09:20:42.093 [user] ts=2024-11-23T09:20:42.092974199Z caller=middlewares.go:46 method=Register username=pPdBh email=pPdBh@gmail.com took=2.180733ms
  09:20:44.222 [user] ts=2024-11-23T09:20:44.222302105Z caller=middlewares.go:46 method=Register username=TCXdYVbv email=TCXdYVbv@gmail.com took=2.596196ms
  09:20:47.535 [front-end] Received response: "{\"firstName\":\"tCUBiVdwwIfZp\",\"lastName\":\"tCUBiVdwwIfZp\",\"username\":\"tCUBiVdwwIfZp\",\"id\":\"67419e5aa437380001df10a3\",\"_links\
  09:20:50.582 [front-end] Posting Customer: {"username":"WVvGtIgdcd","password":"GhhRx","email":"WVvGtIgdcd@gmail.com","firstName":"WVvGtIgdcd","lastName":"WVvGtIgdcd"}
  09:20:53.057 [front-end] Received response: "{\"firstName\":\"khPSja\",\"lastName\":\"khPSja\",\"username\":\"khPSja\",\"id\":\"67419e61a437380001df10c3\",\"_links\":{\"addresses\":{\"h
  09:20:55.614 [front-end] Received response: "{\"firstName\":\"tGvyZSVFv\",\"lastName\":\"tGvyZSVFv\",\"username\":\"tGvyZSVFv\",\"id\":\"67419e63a437380001df10c8\",\"_links\":{\"address

## p0038
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-13T07:57:46.501Z
```
{"service":"redisservice1","message":"2021-08-13 07:57:46,501 | ERROR | 0.0.0.1 | redisservice1 | redis_helper.py -> get_value_from_redis -> 67 | f872398f7cb5347b | 二维码已过期， 请刷新重新扫描, status_code: 400"}
```
Same service, the 2 minutes before (oldest first):
  07:57:32.297 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×4)
  07:57:32.353 [redisservice1] INFO redis write success  (×8)
  07:57:32.485 [redisservice1] INFO service accept, status_code: 200  (×3)
  07:57:33.278 [redisservice1] INFO redis读取信息成功, status_code: 200  (×5)
All services, 30 seconds either side (sampled):
  07:57:16.522 [redisservice2] INFO redis读取信息成功, status_code: 200  (×42)
  07:57:16.610 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×31)
  07:57:16.816 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '05bb7fee-fbc9-11eb-b7f6-0242ac110004', 'value': '', 'ex': 10}  (×36)
  07:57:17.020 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×33)
  07:57:17.229 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '05bb7fee-fbc9-11eb-b7f6-0242ac110004'}  (×41)
  07:57:17.365 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×40)
  07:57:17.729 [webservice1] INFO complete information: {'uuid': '062a0f0e-fbc9-11eb-b1d3-0242ac110003', 'user_id': 'KvpoNGOC'}  (×35)
  07:57:17.851 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '062a0f0e-fbc9-11eb-b1d3-0242ac110003', 'value': 'KvpoNGOC'}  (×38)
  07:57:18.168 [dbservice1] INFO 062a0f0e-fbc9-11eb-b1d3-0242ac110003-KvpoNGOC-2{r-4./W3G&K token generate success token=MTYyODgxMjYzOC4xNjc3NzEzOjA2MmEwZjBlLWZiYzktMTFlYi1iMWQzLTAyNDJhYzE
  07:57:20.068 [mobservice2] INFO info 077c3440-fbc9-11eb-925e-0242ac110003:UFfHkLJX write success
  07:57:22.254 [dbservice1] INFO 088893ec-fbc9-11eb-9d29-0242ac110004-zFRIyZKg-MH4f5}WvX/In token generate success token=MTYyODgxMjY0Mi4yNTQwMTk1OjA4ODg5M2VjLWZiYzktMTFlYi05ZDI5LTAyNDJhYzE
  07:57:24.262 [mobservice2] INFO info 09f582c6-fbc9-11eb-b4ae-0242ac110003:SsCTdeWm write success
  07:57:26.708 [mobservice1] INFO info 0b66ed5c-fbc9-11eb-967b-0242ac110003:vdlbugLI write success
  07:57:29.084 [mobservice2] INFO info 0cda5354-fbc9-11eb-ad69-0242ac110004:yWbZXEez write success
  07:57:31.035 [dbservice2] INFO 0dcb9818-fbc9-11eb-87e7-0242ac110004-hsyfMqgb-jR*%V942J+Kh token generate success token=MTYyODgxMjY1MS4wMzQ3MjIzOjBkY2I5ODE4LWZiYzktMTFlYi04N2U3LTAyNDJhYzE
  07:57:32.649 [dbservice1] INFO 0eccca84-fbc9-11eb-8565-0242ac110003-MfgEVxGn-&F1b%*m}.ro4 token generate success token=MTYyODgxMjY1Mi42NDkwNTI2OjBlY2NjYTg0LWZiYzktMTFlYi04NTY1LTAyNDJhYzE
  07:57:35.040 [mobservice1] INFO info 10639f62-fbc9-11eb-aa79-0242ac110004:zrnyoxBF write success
  07:57:43.473 [mobservice1] INFO info 15671ae8-fbc9-11eb-b537-0242ac110004:cFoEvJPG write success
  07:57:46.679 [logservice2] ERROR get information failed, fail code: 400
  07:57:49.359 [dbservice1] INFO 18b30bc6-fbc9-11eb-8bb4-0242ac110003-GsgASzin-v47{KN&<nj-h token generate success token=MTYyODgxMjY2OS4zNTg5MjA4OjE4YjMwYmM2LWZiYzktMTFlYi04YmI0LTAyNDJhYzE
  07:57:52.354 [dbservice2] INFO 1a73dd8c-fbc9-11eb-affe-0242ac110004-zZMHRjyN->TG12BRdz}ZU token generate success token=MTYyODgxMjY3Mi4zNTM2NTI6MWE3M2RkOGMtZmJjOS0xMWViLWFmZmUtMDI0MmFjMTE  (×2)
  07:57:54.817 [mobservice1] INFO info 1c2f05a2-fbc9-11eb-b984-0242ac110003:lykPtSEm write success
  07:57:57.609 [mobservice1] INFO info 1dcd51d4-fbc9-11eb-be4c-0242ac110003:qQRWFANX write success
  07:57:59.633 [dbservice2] INFO 1ed82f18-fbc9-11eb-9af1-0242ac110004-bhmAUvxt-bl!-9=:e3B{F token generate success token=MTYyODgxMjY3OS42MzMxMzM0OjFlZDgyZjE4LWZiYzktMTFlYi05YWYxLTAyNDJhYzE
  07:58:08.998 [dbservice2] INFO 246b8e66-fbc9-11eb-8544-0242ac110004-dNpfZrzW-Hw{Mg^WqrenK token generate success token=MTYyODgxMjY4OC45OTg1MTgyOjI0NmI4ZTY2LWZiYzktMTFlYi04NTQ0LTAyNDJhYzE
  07:58:11.484 [mobservice1] INFO info 2616873e-fbc9-11eb-a2de-0242ac110004:KrEDTxFN write success
  07:58:14.022 [mobservice1] INFO info 27a3c4f4-fbc9-11eb-a9d6-0242ac110003:YXLKvufE write success
  07:58:15.754 [dbservice1] INFO 287b7868-fbc9-11eb-854b-0242ac110003-FGqxBRpZ-}9s_LQ?u>hzS token generate success token=MTYyODgxMjY5NS43NTQzMzc1OjI4N2I3ODY4LWZiYzktMTFlYi04NTRiLTAyNDJhYzE

## p0661
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-11T08:00:26.503Z
```
{"service":"webservice1","message":"2021-08-11 08:00:26,503 | INFO | 0.0.0.1 | 172.17.0.3 | webservice1 | 74f99e9e2a2b1abf | request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '21f7e92e-fa37-11eb-8070-0242ac110003', 'value': '', 'ex': 10}"}
```
Same service, the 2 minutes before (oldest first):
  08:00:17.540 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '1ca033d2-fa37-11eb-9c4c-0242ac110003', 'value': '', 'ex': 10}  (×4)
  08:00:17.615 [webservice1] INFO uuid: 1ca033d2-fa37-11eb-9c4c-0242ac110003 write redis successfully  (×4)
  08:00:17.717 [webservice1] ERROR get a error [Errno 2] No such file or directory: 'resources/source_file/source_file.csv'  (×4)
  08:00:19.551 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  08:00:19.552 [webservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
All services, 30 seconds either side (sampled):
  07:59:56.512 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×3)
  07:59:56.658 [redisservice2] INFO redis write success  (×101)
  07:59:56.761 [redisservice2] INFO redis读取信息成功, status_code: 200  (×38)
  07:59:56.813 [logservice2] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '0ffbf53a-fa37-11eb-aa2b-0242ac110003', 'user_id': 'lnbVdqst'}  (×64)
  07:59:57.057 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×63)
  07:59:57.232 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×62)
  07:59:57.690 [dbservice2] INFO query = select passwards from username_table where user_name='dlSUhBPw'  (×30)
  07:59:58.447 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '111a5470-fa37-11eb-8a73-0242ac110004'}  (×34)
  07:59:58.618 [dbservice1] INFO 10e45906-fa37-11eb-b33f-0242ac110004-VMivmOPL-_z$IfwVSs+#T token generate success token=MTYyODYzOTk5OC42MTgwMDA3OjEwZTQ1OTA2LWZhMzctMTFlYi1iMzNmLTAyNDJhYzE
  07:59:58.751 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×54)
  07:59:59.523 [dbservice1] INFO 116d4f9a-fa37-11eb-a857-0242ac110003-ZKnXGxAN-Z@S_<_>310Yl token generate success token=MTYyODYzOTk5OS41MjMwNDY1OjExNmQ0ZjlhLWZhMzctMTFlYi1hODU3LTAyNDJhYzE
  08:00:01.462 [webservice1] ERROR get a error [Errno 2] No such file or directory: 'resources/source_file/source_file.csv'  (×52)
  08:00:03.380 [dbservice2] ERROR password in database of {user} is null, the user is not registered  (×2)
  08:00:05.039 [mobservice2] INFO info 14f519e0-fa37-11eb-a55b-0242ac110004:gDFlmhUH write success
  08:00:07.519 [dbservice1] INFO 16253020-fa37-11eb-93ce-0242ac110004-VcbkjSAZ-H}z)MI_t986B token generate success token=MTYyODY0MDAwNy41MTg2ODU6MTYyNTMwMjAtZmEzNy0xMWViLTkzY2UtMDI0MmFjMTE
  08:00:09.599 [mobservice2] INFO info 17ac02fc-fa37-11eb-894b-0242ac110004:jEWmrMqA write success
  08:00:11.839 [mobservice2] INFO info 1903516e-fa37-11eb-bd1d-0242ac110004:IREbBVhM write success
  08:00:15.054 [mobservice1] INFO info 1af0191c-fa37-11eb-9f3e-0242ac110004:zShwUfFn write success
  08:00:18.117 [mobservice2] INFO info 1cc050ae-fa37-11eb-820f-0242ac110004:XlGeVCEy write success
  08:00:20.735 [dbservice1] INFO 1e163626-fa37-11eb-9277-0242ac110004-fVwtyQDn-m0:RzXgt4@vn token generate success token=MTYyODY0MDAyMC43MzUzODk1OjFlMTYzNjI2LWZhMzctMTFlYi05Mjc3LTAyNDJhYzE
  08:00:31.325 [mobservice1] INFO info 249087ea-fa37-11eb-9258-0242ac110004:wVcuUpbK write success
  08:00:33.973 [dbservice1] INFO 25ef105c-fa37-11eb-8939-0242ac110004-tjrRfeJy-t5EnZ!FmiUq{ token generate success token=MTYyODY0MDAzMy45NzMxNDcyOjI1ZWYxMDVjLWZhMzctMTFlYi04OTM5LTAyNDJhYzE
  08:00:36.796 [dbservice2] INFO 27a3e738-fa37-11eb-9eb1-0242ac110004-IKTgrkvl-puzDw*h+_H#V token generate success token=MTYyODY0MDAzNi43OTYxMjE0OjI3YTNlNzM4LWZhMzctMTFlYi05ZWIxLTAyNDJhYzE
  08:00:41.054 [mobservice1] INFO info 2a5ccfee-fa37-11eb-b992-0242ac110004:TmVsgowE write success
  08:00:43.826 [mobservice2] INFO info 2c17190c-fa37-11eb-9669-0242ac110004:JtGfaIFA write success
  08:00:46.217 [dbservice1] INFO 2d4db718-fa37-11eb-a50d-0242ac110004-LNTWaneB-a-uy{c?erAX@ token generate success token=MTYyODY0MDA0Ni4yMTcwMTIyOjJkNGRiNzE4LWZhMzctMTFlYi1hNTBkLTAyNDJhYzE
  08:00:49.020 [dbservice2] INFO 2efbef4e-fa37-11eb-a331-0242ac110004-hHIokWie-DyHUpusE)bOX token generate success token=MTYyODY0MDA0OS4wMjAzMjQ1OjJlZmJlZjRlLWZhMzctMTFlYi1hMzMxLTAyNDJhYzE
  08:00:51.368 [mobservice2] INFO info 30990594-fa37-11eb-a751-0242ac110004:QurEfLHx write success
  08:00:53.107 [mobservice1] INFO info 31a0123e-fa37-11eb-a63e-0242ac110004:LeQUvMXs write success

## p0634
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T20:21:59.723Z
```
{"timestamp":1733602919723527000,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-f7tv2","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 20:21:59.723  INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl       : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50a90c90b04"}
```
Same service, the 2 minutes before (oldest first):
  20:21:55.149 [ts-travel2-service] 2024-12-07 20:21:55.148 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  20:21:55.178 [ts-travel2-service] 2024-12-07 20:21:55.178 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int
  20:21:55.178 [ts-travel2-service] 2024-12-07 20:21:55.178 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6
  20:21:55.183 [ts-travel2-service] 2024-12-07 20:21:55.183 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×2)
  20:21:55.183 [ts-travel2-service] 2024-12-07 20:21:55.183 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：20eb7122-3a11-423f-b10a-be0  (×7)
  20:21:55.191 [ts-travel2-service] 2024-12-07 20:21:55.191 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×7)
  20:21:59.695 [ts-travel2-service] 2024-12-07 20:21:59.695 INFO 1 --- [io-16346-exec-8] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
All services, 30 seconds either side (sampled):
  20:21:30.948 [ts-auth-mongo] {"t":{"$date":"2024-12-07T20:21:30.948+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360289
  20:21:31.858 [ts-user-mongo] {"t":{"$date":"2024-12-07T20:21:31.858+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360289
  20:21:33.973 [ts-auth-service] 2024-12-07 20:21:33.973 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×21)
  20:21:34.026 [ts-travel-service] 2024-12-07 20:21:34.025 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×21)
  20:21:34.075 [ts-basic-service] 2024-12-07 20:21:34.075 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×24)
  20:21:34.109 [ts-travel2-service] 2024-12-07 20:21:34.108 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×12)
  20:21:34.386 [ts-seat-service] 2024-12-07 20:21:34.386 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×49)
  20:21:34.566 [ts-auth-service] 2024-12-07 20:21:34.566 INFO 1 --- [io-12340-exec-8] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×12)
  20:21:40.734 [ts-basic-service] 2024-12-07 20:21:40.734 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×9)
  20:21:43.073 [ts-train-mongo] {"t":{"$date":"2024-12-07T20:21:43.073+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360290
  20:21:48.453 [ts-travel-service] 2024-12-07 20:21:48.453 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×2)
  20:21:49.688 [ts-basic-service] 2024-12-07 20:21:49.688 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×4)
  20:21:49.788 [ts-order-service] 2024-12-07 20:21:49.787 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×3)
  20:21:49.942 [ts-food-service] 2024-12-07 20:21:49.942 INFO 1 --- [o-18856-exec-10] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!
  20:21:50.028 [ts-preserve-service] 2024-12-07 20:21:50.027 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Other Service][Check Security] Checking....
  20:21:50.075 [ts-preserve-service] 2024-12-07 20:21:50.074 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security Complete
  20:21:50.093 [ts-travel-service] 2024-12-07 20:21:50.093 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : [TravelService] [TripAllDetailInfo] TripId: D1345
  20:21:50.459 [ts-preserve-service] 2024-12-07 20:21:50.458 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service][Order] Order Travel Date: Sat Dec 07 00:00:00 GMT
  20:21:50.508 [ts-order-service] 2024-12-07 20:21:50.508 INFO 1 --- [io-12031-exec-8] order.service.OrderServiceImpl : [Order Service][Create Order] Ready Create Order.
  20:21:50.553 [ts-preserve-service] 2024-12-07 20:21:50.553 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service][Step 6] Buy Food Success
  20:21:53.667 [ts-basic-service] 2024-12-07 20:21:53.666 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270  (×4)
  20:21:53.889 [ts-basic-service] 2024-12-07 20:21:53.889 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×5)
  20:22:03.370 [ts-basic-service] 2024-12-07 20:22:03.370 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2  (×2)
  20:22:10.366 [ts-food-service] 2024-12-07 20:22:10.365 INFO 1 --- [io-18856-exec-6] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!  (×2)
  20:22:22.712 [ts-preserve-other-service] 2024-12-07 20:22:22.712 INFO 1 --- [io-14569-exec-3] p.controller.PreserveOtherController : [Preserve Other Service][Preserve] Account order from Shang Hai ----
  20:22:22.770 [ts-preserve-other-service] 2024-12-07 20:22:22.770 INFO 1 --- [io-14569-exec-3] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] TripId: Z1234
  20:22:23.176 [ts-seat-service] 2024-12-07 20:22:23.175 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService distributeSeat] The result of getRouteResult is Response(status
  20:22:23.213 [ts-preserve-other-service] 2024-12-07 20:22:23.213 INFO 1 --- [io-14569-exec-3] p.service.PreserveOtherServiceImpl : [Preserve Service][Add Preserve food Order] Creating....
  20:22:28.542 [ts-route-mongo] {"t":{"$date":"2024-12-07T20:22:28.541+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360294

## p0070
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T09:01:56.187Z
```
{"service":"dbservice2","message":"2021-08-13 09:01:56,187 | ERROR | 0.0.0.2 | 172.17.0.2 | dbservice2 | 7ad1d51346c1b05b | (pymysql.err.OperationalError) (1054, \"Unknown column 'system_data_time' in 'field list'\")[SQL: select service_name, system_data_time, system_cpu_utilization, system_memory_usage,system_disk_usage, disk_io_read_count, disk_io_write_count,system_network, network_io_read_count, network_io_write_count from `metri…"}
```
Same service, the 2 minutes before (oldest first):
  09:01:44.515 [dbservice2] INFO query = select passwards from username_table where user_name='XKUdarkx'  (×4)
  09:01:44.592 [dbservice2] INFO 069c7c70-fbd2-11eb-bfde-0242ac110003-XKUdarkx-_N7M$3ZvV>(* token generate success token=MTYyODgxNjUwNC41OTIzNjM0OjA2OWM3YzcwLWZiZDItMTFlYi1iZmRlLTAyNDJhYzE
  09:01:47.346 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×6)
  09:01:47.346 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×6)
  09:01:47.459 [dbservice2] INFO 08591ece-fbd2-11eb-a0f4-0242ac110003-lGYXifIM-i_N$4ZeE79xr token generate success token=MTYyODgxNjUwNy40NTg3MDIzOjA4NTkxZWNlLWZiZDItMTFlYi1hMGY0LTAyNDJhYzE
  09:01:50.308 [dbservice2] INFO 0a12ee0c-fbd2-11eb-b74b-0242ac110004-WILFvAUY-@gqs5xJrY<v) token generate success token=MTYyODgxNjUxMC4zMDc2MDQ4OjBhMTJlZTBjLWZiZDItMTFlYi1iNzRiLTAyNDJhYzE
  09:01:56.181 [dbservice2] INFO 0d830068-fbd2-11eb-b493-0242ac110004-jKNlhwnV-1!Jx8w76_ZLp token generate success token=MTYyODgxNjUxNi4xODEwODU2OjBkODMwMDY4LWZiZDItMTFlYi1iNDkzLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  09:01:26.198 [dbservice1] INFO query = select passwards from username_table where user_name='WuXJGtdQ'  (×38)
  09:01:26.489 [webservice1] INFO complete information: {'uuid': 'fc383da0-fbd1-11eb-852a-0242ac110003', 'user_id': 'ayOIXsmT'}  (×43)
  09:01:26.630 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'fc383da0-fbd1-11eb-852a-0242ac110003'}  (×38)
  09:01:26.901 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×46)
  09:01:26.989 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  09:01:27.886 [mobservice2] INFO info fce6d45a-fbd1-11eb-bee3-0242ac110003:yjlLtMmx write success
  09:01:28.305 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'fd65df2a-fbd1-11eb-9b5f-0242ac110004', 'value': '', 'ex': 10}  (×37)
  09:01:28.487 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'fd65df2a-fbd1-11eb-9b5f-0242ac110004'}  (×42)
  09:01:28.819 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×33)
  09:01:29.954 [dbservice1] INFO fde892c6-fbd1-11eb-9026-0242ac110004-QurEfLHx-IHF}iJTM)pEg token generate success token=MTYyODgxNjQ4OS45NTQyOTczOmZkZTg5MmM2LWZiZDEtMTFlYi05MDI2LTAyNDJhYzE
  09:01:32.269 [dbservice2] INFO ff570be2-fbd1-11eb-8736-0242ac110004-PzgvQsFL-V%GQ*R{1naw@ token generate success token=MTYyODgxNjQ5Mi4yNjkwMzM0OmZmNTcwYmUyLWZiZDEtMTFlYi04NzM2LTAyNDJhYzE
  09:01:34.359 [mobservice1] INFO info 00d19794-fbd2-11eb-bae9-0242ac110003:HBlmbePk write success
  09:01:36.052 [mobservice2] INFO info 01c74c02-fbd2-11eb-ba6d-0242ac110003:NAVbZmOn write success
  09:01:38.511 [mobservice1] INFO info 0341feba-fbd2-11eb-a8c4-0242ac110003:HfckUWDQ write success
  09:01:41.152 [mobservice2] INFO info 04d19b5a-fbd2-11eb-82e8-0242ac110004:jrKReZbn write success
  09:01:43.464 [dbservice1] INFO 05ea8e48-fbd2-11eb-a859-0242ac110003-xwrmCNQd-VxKpC&#$T?.S token generate success token=MTYyODgxNjUwMy40NjQzNzEyOjA1ZWE4ZTQ4LWZiZDItMTFlYi1hODU5LTAyNDJhYzE
  09:01:49.975 [mobservice2] INFO info 0a12ee0c-fbd2-11eb-b74b-0242ac110004:WILFvAUY write success
  09:01:55.705 [mobservice1] INFO info 0d830068-fbd2-11eb-b493-0242ac110004:jKNlhwnV write success
  09:01:58.278 [mobservice2] INFO info 0f09836c-fbd2-11eb-bc2d-0242ac110003:pDXcZzKl write success
  09:02:00.177 [dbservice1] INFO 0ff20876-fbd2-11eb-bc40-0242ac110003-wHINnpBP-:ReXuAG#4}Vk token generate success token=MTYyODgxNjUyMC4xNzc1MDc2OjBmZjIwODc2LWZiZDItMTFlYi1iYzQwLTAyNDJhYzE
  09:02:02.485 [mobservice1] INFO info 1197f8fc-fbd2-11eb-8bd1-0242ac110004:YXLKvufE write success
  09:02:04.791 [dbservice2] INFO 12b25d2c-fbd2-11eb-89eb-0242ac110003-WcUSzNAM-4Tvi5PF$026m token generate success token=MTYyODgxNjUyNC43OTA1OTQ4OjEyYjI1ZDJjLWZiZDItMTFlYi04OWViLTAyNDJhYzE
  09:02:07.315 [mobservice2] INFO info 146750fa-fbd2-11eb-816e-0242ac110004:qhdLCnSU write success
  09:02:09.597 [dbservice2] INFO 1591a4e4-fbd2-11eb-93b4-0242ac110003-GEFNbRmp-9e0!Zzhbd3WR token generate success token=MTYyODgxNjUyOS41OTY1MzY2OjE1OTFhNGU0LWZiZDItMTFlYi05M2I0LTAyNDJhYzE
  09:02:11.742 [mobservice1] INFO info 171bc57e-fbd2-11eb-9e85-0242ac110004:QvNLTxkS write success
  09:02:14.509 [mobservice2] INFO info 18ad5c18-fbd2-11eb-95c4-0242ac110004:AizeDahx write success
  09:02:16.846 [dbservice2] INFO 19bd9ed8-fbd2-11eb-8d8b-0242ac110003-RhZNdLGi-5hPyJFcg^U*Z token generate success token=MTYyODgxNjUzNi44NDYyNDMxOjE5YmQ5ZWQ4LWZiZDItMTFlYi04ZDhiLTAyNDJhYzE
  09:02:19.738 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  09:02:22.123 [mobservice1] INFO info 1d48aa70-fbd2-11eb-b8ba-0242ac110003:VcbkjSAZ write success
  09:02:24.958 [mobservice1] INFO info 1efbe846-fbd2-11eb-a664-0242ac110004:OVLDMHZf write success

## p0521
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:42:28.622Z
```
{"timestamp":1732358548622705700,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"{ id: '6741b194a437380001df4ba5' }"}
```
Same service, the 2 minutes before (oldest first):
  10:42:27.638 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"6741b
  10:42:27.638 [front-end] [ undefined, undefined ]
  10:42:27.638 [front-end] Posting Order: {"customer":"http://user/customers/6741b17ea437380001df4b76","address":"http://user/addresses/6741b187a437380001df4b89","card":"http://user/cards
  10:42:27.682 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19301dd390007094e0f","customerId":"6741b17ea437380001df4b76","customer":{"id":null,"firstName":"DjEHXcoqHgW
  10:42:27.682 [front-end] Order response: {"id":"6741b19301dd390007094e0f","customerId":"6741b17ea437380001df4b76","customer":{"id":null,"firstName":"DjEHXcoqHgWxYbC","lastName":"DjEHXco
  10:42:27.683 [front-end] POST /orders 201 - ms - -
  10:42:27.987 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b18ba437380001df4b92"}
  10:42:27.999 [front-end] POST /addresses 200 - ms - -
  10:42:28.003 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"6741b18ba437380001df4b92"}
  10:42:28.017 [front-end] POST /cards 200 - ms - -
  10:42:28.064 [front-end] Attempting to delete cart for user: 6741b18ba437380001df4b92
  10:42:28.092 [front-end] User cart deleted with status: 202
  10:42:28.094 [front-end] DELETE /cart 202 - ms - -
  10:42:28.099 [front-end] Attempting to add to cart: {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","quantity":1}
  10:42:28.111 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata
  10:42:28.111 [front-end] POST to carts: http://carts/carts/6741b18ba437380001df4b92/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}
  10:42:28.167 [front-end] POST /cart 201 - ms - -
  10:42:28.300 [front-end] GET /catalogue 200 - ms - -  (×2)
  10:42:28.614 [front-end] Posting Customer: {"username":"zQXUmkCZssMpOLp","password":"xfQvDtBwM","email":"zQXUmkCZssMpOLp@gmail.com","firstName":"zQXUmkCZssMpOLp","lastName":"zQXUmkCZssM
All services, 30 seconds either side (sampled):
  10:41:58.708 [catalogue] ts=2024-11-23T10:41:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.628461ms  (×59)
  10:41:58.972 [front-end] Sent cookies.  (×60)
  10:41:59.244 [user] ts=2024-11-23T10:41:59.243766589Z caller=middlewares.go:104 method=GetAddresses id=6741b165a437380001df4b24 result=1 took=1.56731ms  (×59)
  10:41:59.273 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b17701dd390007094df5","customerId":"6741b15aa437380001df4b02","customer":{"id":null,"firstName":"BWhXBmIlk",
  10:42:00.383 [catalogue] ts=2024-11-23T10:42:00Z caller=logging.go:85 method=Health result=2 took=27.373µs  (×40)
  10:42:01.461 [front-end] Attempting to delete cart for user: 6741b172a437380001df4b56  (×60)
  10:42:01.967 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  10:42:03.351 [front-end] Received response: "{\"firstName\":\"WzPQXTXTGIDm\",\"lastName\":\"WzPQXTXTGIDm\",\"username\":\"WzPQXTXTGIDm\",\"id\":\"6741b16ba437380001df4b3b\",\"_links\":{
  10:42:05.061 [front-end] Order response: {"id":"6741b17d01dd390007094dfb","customerId":"6741b16aa437380001df4b3a","customer":{"id":null,"firstName":"sjfrIBFtnOMwhK","lastName":"sjfrIBFt
  10:42:06.550 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b17e01dd390007094dfe","customerId":"6741b165a437380001df4b27","customer":{"id":null,"firstName":"THlEsd","la
  10:42:08.990 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732358528987,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×7)
  10:42:13.530 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b18501dd390007094e02","customerId":"6741b16fa437380001df4b4a","customer":{"id":null,"firstName":"DSAgaYnbcBN
  10:42:15.696 [front-end] Order response: {"id":"6741b18701dd390007094e04","customerId":"6741b16ca437380001df4b3f","customer":{"id":null,"firstName":"JGDfadEFXS","lastName":"JGDfadEFXS",
  10:42:18.245 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b18a01dd390007094e08","customerId":"6741b175a437380001df4b60","customer":{"id":null,"firstName":"vqiGwzuJlek
  10:42:23.338 [front-end] Posting Customer: {"username":"hkNXgDJyv","password":"PMBaB","email":"hkNXgDJyv@gmail.com","firstName":"hkNXgDJyv","lastName":"hkNXgDJyv"}
  10:42:24.898 [front-end] Posting Customer: {"username":"SGHrmQKj","password":"zIZBNLHf","email":"SGHrmQKj@gmail.com","firstName":"SGHrmQKj","lastName":"SGHrmQKj"}
  10:42:26.560 [user] ts=2024-11-23T10:42:26.559867522Z caller=middlewares.go:46 method=Register username=EwfSFA email=EwfSFA@gmail.com took=2.875472ms
  10:42:28.803 [front-end] Posting Customer: {"username":"CFTBHrq","password":"OeWzI","email":"CFTBHrq@gmail.com","firstName":"CFTBHrq","lastName":"CFTBHrq"}
  10:42:31.520 [user] ts=2024-11-23T10:42:31.520420058Z caller=middlewares.go:46 method=Register username=YrFTjPuE email=YrFTjPuE@gmail.com took=2.447063ms
  10:42:34.751 [front-end] Order response: {"id":"6741b19a01dd390007094e13","customerId":"6741b184a437380001df4b82","customer":{"id":null,"firstName":"jsGRuUxRzen","lastName":"jsGRuUxRzen
  10:42:36.794 [user] ts=2024-11-23T10:42:36.793956559Z caller=middlewares.go:46 method=Register username=siRMHb email=siRMHb@gmail.com took=1.874171ms
  10:42:39.381 [front-end] Posting Customer: {"username":"ZxxOOqShAES","password":"YugUEGV","email":"ZxxOOqShAES@gmail.com","firstName":"ZxxOOqShAES","lastName":"ZxxOOqShAES"}
  10:42:42.197 [front-end] Received response: "{\"firstName\":\"SlOUiiS\",\"lastName\":\"SlOUiiS\",\"username\":\"SlOUiiS\",\"id\":\"6741b18ba437380001df4b92\",\"_links\":{\"addresses\":{
  10:42:44.910 [front-end] Received response: "{\"firstName\":\"zQXUmkCZssMpOLp\",\"lastName\":\"zQXUmkCZssMpOLp\",\"username\":\"zQXUmkCZssMpOLp\",\"id\":\"6741b194a437380001df4ba5\",\"_
  10:42:46.295 [user] ts=2024-11-23T10:42:46.295527389Z caller=middlewares.go:46 method=Register username=VWqTx email=VWqTx@gmail.com took=2.392521ms
  10:42:48.852 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b1a801dd390007094e1e","customerId":"6741b192a437380001df4b9d","customer":{"id":null,"firstName":"kpvsmqOHyaK
  10:42:52.472 [front-end] Received response: "{\"firstName\":\"FaALE\",\"lastName\":\"FaALE\",\"username\":\"FaALE\",\"id\":\"6741b19ca437380001df4bbe\",\"_links\":{\"addresses\":{\"href
  10:42:53.622 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b1ad01dd390007094e22","customerId":"6741b195a437380001df4ba9","customer":{"id":null,"firstName":"mGHHyeKOwbU
  10:42:55.138 [front-end] Received response: "{\"firstName\":\"ysfRffWVDnk\",\"lastName\":\"ysfRffWVDnk\",\"username\":\"ysfRffWVDnk\",\"id\":\"6741b19da437380001df4bc9\",\"_links\":{\"a
  10:42:57.238 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b1b101dd390007094e27","customerId":"6741b19ca437380001df4bc6","customer":{"id":null,"firstName":"cmRPGDROdbU

## p0398
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:28.634Z
```
{"timestamp":1732247188634517500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"firstName\\\":\\\"wwBhWHzXKhCBw\\\",\\\"lastName\\\":\\\"wwBhWHzXKhCBw\\\",\\\"username\\\":\\\"wwBhWHzXKhCBw\\\",\\\"id\\\":\\\"673ffe7ab0df5c00019b3146\\\",\\\"_links\\\":{\\\"addresses\\\":{\\\"href\\\":\\\"http://user/customers/673ffe7ab0df5c00019b3146/addresses\\\"},\\\"cards\\\":{\\\"href\\\":\\\"http://user/customers/673ffe7ab0df5c00019b3146/cards\\\"},\\\"customer\\\":{\\\"href\\\":\\\"http://user/customers/673ffe7ab0df5c00019b3146\\\"…"}
```
Same service, the 2 minutes before (oldest first):
  03:46:27.978 [front-end] Posting Customer: {"username":"gEqHWvVKGL","password":"YrvWJAsKRg","email":"gEqHWvVKGL@gmail.com","firstName":"gEqHWvVKGL","lastName":"gEqHWvVKGL"}
  03:46:27.983 [front-end] { id: '673ffe93b0df5c00019b3192' }  (×2)
  03:46:27.983 [front-end] 673ffe93b0df5c00019b3192  (×2)
  03:46:27.983 [front-end] Merging carts for customer id: 673ffe93b0df5c00019b3192 and session id: PSlPUDIdwepG9Uai4DI4b9Tuhr4NTDs-  (×2)
  03:46:27.997 [front-end] Carts merged.  (×2)
  03:46:27.997 [front-end] set cookie673ffe93b0df5c00019b3192  (×2)
  03:46:27.997 [front-end] Sent cookies.  (×2)
  03:46:27.999 [front-end] POST /register 200 19.331 ms - 33  (×2)
  03:46:28.177 [front-end] GET /catalogue 200 - ms - -  (×2)
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:28.627 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffe8db0df5c00019b3180"}
  03:46:28.628 [front-end] Request received with body: {}
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×27)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×47)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×60)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×48)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×48)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×46)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×46)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×46)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:30.035 [front-end] Posting Customer: {"username":"hCQLZMhz","password":"WOsAnFIK","email":"hCQLZMhz@gmail.com","firstName":"hCQLZMhz","lastName":"hCQLZMhz"}
  03:46:30.678 [front-end] Received response: "{\"firstName\":\"jwQwxgI\",\"lastName\":\"jwQwxgI\",\"username\":\"jwQwxgI\",\"id\":\"673ffe80b0df5c00019b315a\",\"_links\":{\"addresses\":{
  03:46:34.802 [front-end] Received response: "{\"firstName\":\"cnldH\",\"lastName\":\"cnldH\",\"username\":\"cnldH\",\"id\":\"673ffe86b0df5c00019b3168\",\"_links\":{\"addresses\":{\"href
  03:46:37.691 [front-end] Posting Customer: {"username":"qUtlLbPKVBxOY","password":"JxzbP","email":"qUtlLbPKVBxOY@gmail.com","firstName":"qUtlLbPKVBxOY","lastName":"qUtlLbPKVBxOY"}
  03:46:42.029 [front-end] Received response: "{\"firstName\":\"RIyyBeUhcpw\",\"lastName\":\"RIyyBeUhcpw\",\"username\":\"RIyyBeUhcpw\",\"id\":\"673ffe91b0df5c00019b318b\",\"_links\":{\"a
  03:46:47.039 [front-end] Posting Customer: {"username":"izKtQHadCL","password":"nHTsOd","email":"izKtQHadCL@gmail.com","firstName":"izKtQHadCL","lastName":"izKtQHadCL"}
  03:46:50.174 [user] ts=2024-11-22T03:46:50.174690437Z caller=middlewares.go:46 method=Register username=hXxXTfcxL email=hXxXTfcxL@gmail.com took=1.013245ms
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  03:46:51.467 [front-end] Received response: "{\"firstName\":\"saWqTMkh\",\"lastName\":\"saWqTMkh\",\"username\":\"saWqTMkh\",\"id\":\"673ffe96b0df5c00019b3199\",\"_links\":{\"addresses\
  03:46:52.671 [front-end] Received response: "{\"firstName\":\"luZnNKRyePrJMe\",\"lastName\":\"luZnNKRyePrJMe\",\"username\":\"luZnNKRyePrJMe\",\"id\":\"673ffe98b0df5c00019b319f\",\"_lin
  03:46:54.737 [front-end] Posting Customer: {"username":"FzuBTOQzDSvQQ","password":"yimch","email":"FzuBTOQzDSvQQ@gmail.com","firstName":"FzuBTOQzDSvQQ","lastName":"FzuBTOQzDSvQQ"}
  03:46:57.139 [front-end] Received response: "{\"firstName\":\"ZzayWIHhxNw\",\"lastName\":\"ZzayWIHhxNw\",\"username\":\"ZzayWIHhxNw\",\"id\":\"673ffe98b0df5c00019b31a0\",\"_links\":{\"a
  03:46:57.285 [carts] 2024-11-22 03:46:57.285 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/**] onto handler of type [class org.s

## p0219
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:49:06.819Z
```
{"timestamp":1731916146819222500,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  07:49:05.867 [frontend] adding to cart
  07:49:05.876 [frontend] request complete  (×6)
  07:49:05.879 [frontend] request started  (×5)
  07:49:05.879 [frontend] view user cart
  07:49:05.927 [frontend] placing order
  07:49:05.972 [frontend] order placed
  07:49:06.247 [frontend] home  (×2)
  07:49:06.294 [frontend] ENV_PLATFORM is: aws  (×2)
  07:49:06.507 [frontend] serving product page
All services, 30 seconds either side (sampled):
  07:48:37.223 [frontend] request started  (×330)
  07:48:37.231 [cartservice] GetCartAsync called with userId=33421b66-55b6-413b-9ba9-3230c85c58dc  (×275)
  07:48:37.253 [adservice] received ad request (context_words=[kitchen])  (×45)
  07:48:37.710 [adservice] received ad request (context_words=[clothing, tops])  (×18)
  07:48:37.717 [cartservice] AddItemAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55, productId=66VCHSJNUP, quantity=2  (×35)
  07:48:37.748 [shippingservice] [GetQuote] completed request  (×77)
  07:48:38.803 [frontend] home  (×39)
  07:48:38.965 [adservice] received ad request (context_words=[decor, home])  (×22)
  07:48:47.594 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"196","nanos":284829723},"credit_card":{"credit_card_number":"42762508717595  (×8)
  07:48:47.598 [shippingservice] [ShipOrder] received request  (×11)
  07:48:47.607 [emailservice] A request to send order confirmation email to xmitchell@example.com has been received.
  07:48:48.498 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', '0PUK6V6EV0', '2ZYFJ3GM2N', '66VCHSJNUP']  (×3)
  07:48:51.121 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"1679","nanos":890000000},"credit_card":{"credit_card_number":"4996980677738  (×2)
  07:48:51.137 [checkoutservice] order confirmation email sent to "ybrown@example.org"
  07:49:05.969 [emailservice] A request to send order confirmation email to kimrodriguez@example.com has been received.
  07:49:07.264 [checkoutservice] order confirmation email sent to "karenli@example.org"
  07:49:16.623 [emailservice] A request to send order confirmation email to richardsondawn@example.net has been received.
  07:49:18.547 [checkoutservice] order confirmation email sent to "johnhill@example.com"
  07:49:23.993 [emailservice] A request to send order confirmation email to travis83@example.org has been received.
  07:49:36.095 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"314","nanos":305711620},"credit_card":{"credit_card_number":"43999166534280
  07:49:36.110 [checkoutservice] order confirmation email sent to "aaron90@example.net"

## p0290
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T02:37:04.356Z
```
{"timestamp":1732243024356309500,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T02:37:04.356102818Z caller=middlewares.go:75 method=GetUsers id=673fee3eb0df5c00019aff90 result=1 took=953.698µs"}
```
Same service, the 2 minutes before (oldest first):
  02:37:02.555 [user] ts=2024-11-22T02:37:02.555777147Z caller=middlewares.go:75 method=GetUsers id=673fee36b0df5c00019aff7e result=1 took=797.619µs  (×8)
  02:37:02.566 [user] ts=2024-11-22T02:37:02.566282529Z caller=middlewares.go:134 method=GetCards id=673fee40b0df5c00019aff9c result=1 took=822.26µs  (×3)
  02:37:02.566 [user] ts=2024-11-22T02:37:02.566303238Z caller=middlewares.go:75 method=GetUsers id=673fee36b0df5c00019aff7e result=1 took=1.031612ms  (×2)
  02:37:02.566 [user] ts=2024-11-22T02:37:02.566332326Z caller=middlewares.go:104 method=GetAddresses id=673fee40b0df5c00019aff9b result=1 took=814.082µs  (×2)
  02:37:03.094 [user] ts=2024-11-22T02:37:03.094034566Z caller=middlewares.go:157 method=Health result=2 took=710.587µs  (×2)
  02:37:03.740 [user] ts=2024-11-22T02:37:03.739863863Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673fee47b0df5c00019affb3 took=1.618578ms
  02:37:03.754 [user] ts=2024-11-22T02:37:03.753871435Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673fee47b0df5c00019affb3 took=1.788433ms
  02:37:04.194 [user] ts=2024-11-22T02:37:04.194764113Z caller=middlewares.go:104 method=GetAddresses id=673fee44b0df5c00019affa6 result=1 took=1.027146ms
All services, 30 seconds either side (sampled):
  02:36:34.843 [payment] ts=2024-11-22T02:36:34Z caller=logging.go:40 method=Health result=1 took=8.487µs  (×40)
  02:36:35.069 [front-end] Received response: "{\"firstName\":\"NcGdzriiRpNv\",\"lastName\":\"NcGdzriiRpNv\",\"username\":\"NcGdzriiRpNv\",\"id\":\"673fee1eb0df5c00019aff31\",\"_links\":{
  02:36:35.102 [queue-master] 2024-11-22 02:36:35.102 INFO 6 --- [pool-6-thread-9] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×10)
  02:36:35.341 [front-end] Order response: {"timestamp":1732242995338,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.OrdersController$PaymentDecli  (×3)
  02:36:36.268 [front-end] Received response: "{\"firstName\":\"hdNcKovNgHYwtKy\",\"lastName\":\"hdNcKovNgHYwtKy\",\"username\":\"hdNcKovNgHYwtKy\",\"id\":\"673fee20b0df5c00019aff33\",\"_
  02:36:36.656 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee34d94b9000069b3b9c","customerId":"673fee1db0df5c00019aff2d","customer":{"id":null,"firstName":"vxrRusfOXX"
  02:36:36.765 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×10)
  02:36:38.373 [front-end] Posting Customer: {"username":"ZXmfjincHrhxM","password":"sZCqFXDm","email":"ZXmfjincHrhxM@gmail.com","firstName":"ZXmfjincHrhxM","lastName":"ZXmfjincHrhxM"}
  02:36:40.322 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee38d94b9000069b3b9f","customerId":"673fee25b0df5c00019aff42","customer":{"id":null,"firstName":"fIgxg","las
  02:36:43.886 [front-end] Order response: {"id":"673fee3bd94b9000069b3ba1","customerId":"673fee1fb0df5c00019aff32","customer":{"id":null,"firstName":"eCwiMXrUmXhsy","lastName":"eCwiMXrUm
  02:36:45.174 [front-end] Order response: {"id":"673fee3dd94b9000069b3ba5","customerId":"673fee2db0df5c00019aff64","customer":{"id":null,"firstName":"vvwOqlxPXSu","lastName":"vvwOqlxPXSu
  02:36:46.615 [front-end] Posting Customer: {"username":"IuIENGEvYHkc","password":"cmyPbOv","email":"IuIENGEvYHkc@gmail.com","firstName":"IuIENGEvYHkc","lastName":"IuIENGEvYHkc"}
  02:36:47.851 [front-end] Order response: {"id":"673fee3fd94b9000069b3bab","customerId":"673fee2ab0df5c00019aff60","customer":{"id":null,"firstName":"MKoyaxvRzlV","lastName":"MKoyaxvRzlV
  02:36:51.611 [front-end] Posting Customer: {"username":"YodqvxmAhY","password":"unQAjczir","email":"YodqvxmAhY@gmail.com","firstName":"YodqvxmAhY","lastName":"YodqvxmAhY"}
  02:36:55.704 [user] ts=2024-11-22T02:36:55.703857997Z caller=middlewares.go:46 method=Register username=eVSDn email=eVSDn@gmail.com took=985.26µs
  02:36:59.522 [front-end] Posting Customer: {"username":"fsolKAq","password":"lYOSaOhe","email":"fsolKAq@gmail.com","firstName":"fsolKAq","lastName":"fsolKAq"}
  02:37:01.801 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee4dd94b9000069b3bb5","customerId":"673fee34b0df5c00019aff78","customer":{"id":null,"firstName":"pUbZTskS","
  02:37:04.360 [front-end] Received response: "{\"firstName\":\"ZTwFoymzuVrf\",\"lastName\":\"ZTwFoymzuVrf\",\"username\":\"ZTwFoymzuVrf\",\"id\":\"673fee3eb0df5c00019aff90\",\"_links\":{
  02:37:07.701 [user] ts=2024-11-22T02:37:07.700860295Z caller=middlewares.go:46 method=Register username=HwrZc email=HwrZc@gmail.com took=1.059323ms
  02:37:08.764 [front-end] Posting Customer: {"username":"PlbndWakuk","password":"NkPBKqGde","email":"PlbndWakuk@gmail.com","firstName":"PlbndWakuk","lastName":"PlbndWakuk"}
  02:37:11.445 [front-end] Posting Customer: {"username":"wxNsKJlIbQ","password":"PeaprPrKB","email":"wxNsKJlIbQ@gmail.com","firstName":"wxNsKJlIbQ","lastName":"wxNsKJlIbQ"}
  02:37:14.886 [front-end] Received response: "{\"firstName\":\"eVSDn\",\"lastName\":\"eVSDn\",\"username\":\"eVSDn\",\"id\":\"673fee47b0df5c00019affb3\",\"_links\":{\"addresses\":{\"href
  02:37:16.783 [front-end] Posting Customer: {"username":"AvbuahykV","password":"sYRRjuRz","email":"AvbuahykV@gmail.com","firstName":"AvbuahykV","lastName":"AvbuahykV"}
  02:37:20.332 [user] ts=2024-11-22T02:37:20.332450994Z caller=middlewares.go:46 method=Register username=Yqsat email=Yqsat@gmail.com took=947.411µs
  02:37:24.007 [front-end] Order response: {"id":"673fee64d94b9000069b3bc9","customerId":"673fee4bb0df5c00019affc5","customer":{"id":null,"firstName":"QRHBt","lastName":"QRHBt","username"
  02:37:25.639 [front-end] Order response: {"id":"673fee65d94b9000069b3bcc","customerId":"673fee56b0df5c00019affe2","customer":{"id":null,"firstName":"BmgJhfaB","lastName":"BmgJhfaB","use
  02:37:29.180 [front-end] Received response: "{\"firstName\":\"KnbFKtq\",\"lastName\":\"KnbFKtq\",\"username\":\"KnbFKtq\",\"id\":\"673fee5ab0df5c00019afff0\",\"_links\":{\"addresses\":{
  02:37:31.452 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee6bd94b9000069b3bd3","customerId":"673fee53b0df5c00019affd7","customer":{"id":null,"firstName":"EbXgdaGAkYA
  02:37:33.064 [front-end] Received response: "{\"firstName\":\"HwrZc\",\"lastName\":\"HwrZc\",\"username\":\"HwrZc\",\"id\":\"673fee53b0df5c00019affd8\",\"_links\":{\"addresses\":{\"href

## p0790
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-23T20:43:34.193Z
```
{"timestamp":1732394614193376300,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-x6bhs","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-23 20:43:34.193  INFO 7 --- [ool-6-thread-28] o.apache.http.impl.execchain.RetryExec   : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught when processing request to {}->unix://localhost:80: No such file or directory"}
```
Same service, the 2 minutes before (oldest first):
  20:43:28.576 [queue-master] Received shipment task: 67423e5d48485600016b4dcb  (×3)
  20:43:28.576 [queue-master] 2024-11-23 20:43:28.576 INFO 7 --- [ool-6-thread-26] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×3)
  20:43:28.577 [queue-master] 2024-11-23 20:43:28.577 INFO 7 --- [ool-6-thread-26] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×6)
  20:43:28.577 [queue-master] 2024-11-23 20:43:28.577 INFO 7 --- [ool-6-thread-26] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×6)
  20:43:28.577 [queue-master] 2024-11-23 20:43:28.577 ERROR 7 --- [ool-6-thread-26] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×2)
All services, 30 seconds either side (sampled):
  20:43:04.264 [payment] ts=2024-11-23T20:43:04Z caller=logging.go:40 method=Health result=1 took=7.287µs  (×40)
  20:43:04.750 [front-end] Received response: "{\"firstName\":\"DYBVBIgznLympF\",\"lastName\":\"DYBVBIgznLympF\",\"username\":\"DYBVBIgznLympF\",\"id\":\"67423e4b48485600016b4d9d\",\"_lin
  20:43:04.797 [queue-master] 2024-11-23 20:43:04.797 INFO 7 --- [pool-6-thread-6] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×7)
  20:43:06.131 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e5a4ca85a00070c621e","customerId":"67423e4848485600016b4d99","customer":{"id":null,"firstName":"YcahqxTXFqB
  20:43:06.925 [front-end] DELETE /cart 202 - ms - -  (×62)
  20:43:07.083 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×14)
  20:43:11.024 [front-end] Received response: "{\"firstName\":\"yyXxRBF\",\"lastName\":\"yyXxRBF\",\"username\":\"yyXxRBF\",\"id\":\"67423e4748485600016b4d93\",\"_links\":{\"addresses\":{
  20:43:12.493 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e604ca85a00070c6222","customerId":"67423e4f48485600016b4da3","customer":{"id":null,"firstName":"jUtfnztT","
  20:43:15.194 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e634ca85a00070c6225","customerId":"67423e5148485600016b4da9","customer":{"id":null,"firstName":"Jiuiq","las
  20:43:19.344 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732394599343,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×4)
  20:43:21.863 [front-end] Received response: "{\"firstName\":\"SvmupWCu\",\"lastName\":\"SvmupWCu\",\"username\":\"SvmupWCu\",\"id\":\"67423e5a48485600016b4dba\",\"_links\":{\"addresses\
  20:43:22.921 [front-end] Order response: {"id":"67423e6a4ca85a00070c622a","customerId":"67423e5848485600016b4db8","customer":{"id":null,"firstName":"hpRqLaHh","lastName":"hpRqLaHh","use
  20:43:23.939 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e6b4ca85a00070c622d","customerId":"67423e5948485600016b4db9","customer":{"id":null,"firstName":"OsaphvDVlIw
  20:43:27.067 [front-end] Posting Customer: {"username":"DeiKe","password":"wDUPLXJ","email":"DeiKe@gmail.com","firstName":"DeiKe","lastName":"DeiKe"}
  20:43:32.241 [front-end] Posting Customer: {"username":"ghoLlUIFHRE","password":"OZXeTPhY","email":"ghoLlUIFHRE@gmail.com","firstName":"ghoLlUIFHRE","lastName":"ghoLlUIFHRE"}
  20:43:37.401 [front-end] Received response: "{\"firstName\":\"vkXVSmPXQsF\",\"lastName\":\"vkXVSmPXQsF\",\"username\":\"vkXVSmPXQsF\",\"id\":\"67423e6448485600016b4de0\",\"_links\":{\"a
  20:43:38.615 [front-end] npm timing config:load:file:/usr/src/app/.npmrc Completed in 0ms  (×2)
  20:43:38.615 [front-end] npm verb argv "start" "--loglevel" "verbose"  (×2)
  20:43:38.804 [front-end] > node server.js   (×2)
  20:43:40.783 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e7c4ca85a00070c6238","customerId":"67423e6d48485600016b4e03","customer":{"id":null,"firstName":"EWaaDKRDIip
  20:43:42.130 [front-end] Received response: "{\"firstName\":\"SNtfaKWZBMbyE\",\"lastName\":\"SNtfaKWZBMbyE\",\"username\":\"SNtfaKWZBMbyE\",\"id\":\"67423e6b48485600016b4dfe\",\"_links\
  20:43:43.448 [front-end] Order response: {"statusCode":201,"body":{"id":"67423e7f4ca85a00070c623e","customerId":"67423e6848485600016b4dec","customer":{"id":null,"firstName":"BSObbrkVRSr
  20:43:45.028 [front-end] Received response: "{\"firstName\":\"HnfwP\",\"lastName\":\"HnfwP\",\"username\":\"HnfwP\",\"id\":\"67423e6b48485600016b4dfd\",\"_links\":{\"addresses\":{\"href
  20:43:47.890 [front-end] Posting Customer: {"username":"dRtObNhLzllDI","password":"VigTUXouL","email":"dRtObNhLzllDI@gmail.com","firstName":"dRtObNhLzllDI","lastName":"dRtObNhLzllDI"}
  20:43:50.795 [front-end] Order response: {"id":"67423e864ca85a00070c6248","customerId":"67423e6f48485600016b4e0a","customer":{"id":null,"firstName":"OeRiOYxQG","lastName":"OeRiOYxQG","u
  20:43:55.364 [front-end] Order response: {"id":"67423e8b4ca85a00070c624b","customerId":"67423e7648485600016b4e25","customer":{"id":null,"firstName":"bILYhc","lastName":"bILYhc","usernam
  20:43:56.199 [front-end] npm verb stack at maybeClose (node:internal/child_process:1100:16)
  20:43:56.203 [front-end] npm verb code 1 
  20:44:02.840 [catalogue] ts=2024-11-23T20:44:02Z caller=logging.go:62 method=Get id=3395a43e-2d88-40de-b95f-e00e1502085b sock=3395a43e-2d88-40de-b95f-e00e1502085b err=null took=3.3282ms

## p0339
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:21:21.467Z
```
{"timestamp":1732245681467820500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"firstName\\\":\\\"EFvIPXnJWRPmy\\\",\\\"lastName\\\":\\\"EFvIPXnJWRPmy\\\",\\\"username\\\":\\\"EFvIPXnJWRPmy\\\",\\\"id\\\":\\\"673ff89db0df5c00019b1f53\\\",\\\"_links\\\":{\\\"addresses\\\":{\\\"href\\\":\\\"http://user/customers/673ff89db0df5c00019b1f53/addresses\\\"},\\\"cards\\\":{\\\"href\\\":\\\"http://user/customers/673ff89db0df5c00019b1f53/cards\\\"},\\\"customer\\\":{\\\"href\\\":\\\"http://user/customers/673ff89db0df5c00019b1f53\\\"…"}
```
Same service, the 2 minutes before (oldest first):
  03:21:20.222 [front-end] GET /catalogue 200 - ms - -  (×3)
  03:21:20.407 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b0d94b9000069b4397","customerId":"673ff899b0df5c00019b1f45","customer":{"id":null,"firstName":"pNgaEfQnfRl
  03:21:20.407 [front-end] Order response: {"id":"673ff8b0d94b9000069b4397","customerId":"673ff899b0df5c00019b1f45","customer":{"id":null,"firstName":"pNgaEfQnfRl","lastName":"pNgaEfQnfRl
  03:21:20.407 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b0d94b9000069b4396","customerId":"673ff893b0df5c00019b1f31","customer":{"id":null,"firstName":"nPklGOsvzh"
  03:21:20.407 [front-end] Order response: {"id":"673ff8b0d94b9000069b4396","customerId":"673ff893b0df5c00019b1f31","customer":{"id":null,"firstName":"nPklGOsvzh","lastName":"nPklGOsvzh",
  03:21:20.409 [front-end] POST /orders 201 - ms - -  (×3)
  03:21:20.805 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b0d94b9000069b4398","customerId":"673ff897b0df5c00019b1f3d","customer":{"id":null,"firstName":"PvCLeeg","l
  03:21:20.805 [front-end] Order response: {"id":"673ff8b0d94b9000069b4398","customerId":"673ff897b0df5c00019b1f3d","customer":{"id":null,"firstName":"PvCLeeg","lastName":"PvCLeeg","usern
  03:21:21.199 [front-end] POST /cart 201 - ms - -  (×7)
  03:21:21.459 [front-end] Request received with body: {}
All services, 30 seconds either side (sampled):
  03:20:51.496 [front-end] Request received with body: {}  (×58)
  03:20:51.547 [user] ts=2024-11-22T03:20:51.547474206Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff889b0df5c00019b1f1d took=1.580682ms  (×63)
  03:20:51.664 [front-end] DELETE /cart 503 - ms - -  (×63)
  03:20:52.005 [front-end] Sent cookies.  (×61)
  03:20:54.561 [front-end] Posting Customer: {"username":"LNstXzKIIEKneJ","password":"NZVezpyHM","email":"LNstXzKIIEKneJ@gmail.com","firstName":"LNstXzKIIEKneJ","lastName":"LNstXzKIIEKneJ
  03:20:56.805 [front-end] Posting Customer: {"username":"nLZjIlByeidrL","password":"SRNOEYM","email":"nLZjIlByeidrL@gmail.com","firstName":"nLZjIlByeidrL","lastName":"nLZjIlByeidrL"}
  03:20:59.685 [carts] 2024-11-22 03:20:59.685 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+json
  03:20:59.785 [carts] 2024-11-22 03:20:59.785 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[GET],produces=[  (×2)
  03:20:59.886 [carts] 2024-11-22 03:20:59.886 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[OPTIONS]}" onto public org.springfram
  03:21:02.584 [front-end] Posting Customer: {"username":"sQAAadzpZlKDfq","password":"reYll","email":"sQAAadzpZlKDfq@gmail.com","firstName":"sQAAadzpZlKDfq","lastName":"sQAAadzpZlKDfq"}
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]
  03:21:04.431 [user] ts=2024-11-22T03:21:04.431664332Z caller=middlewares.go:46 method=Register username=qklQL email=qklQL@gmail.com took=1.218175ms
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposur  (×2)
  03:21:10.838 [front-end] Posting Customer: {"username":"BXlkiHWqBVYl","password":"IUhQgOlH","email":"BXlkiHWqBVYl@gmail.com","firstName":"BXlkiHWqBVYl","lastName":"BXlkiHWqBVYl"}
  03:21:13.884 [carts] 2024-11-22 03:21:13.884 INFO [carts,,,] 7 --- [p-nio-80-exec-3] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  03:21:15.983 [carts] 2024-11-22 03:21:15.983 INFO [carts,145906930ffa3fb8,509bc3b9cc66abb6,false] 7 --- [p-nio-80-exec-6] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  03:21:18.296 [front-end] Received response: "{\"firstName\":\"nPklGOsvzh\",\"lastName\":\"nPklGOsvzh\",\"username\":\"nPklGOsvzh\",\"id\":\"673ff893b0df5c00019b1f31\",\"_links\":{\"addr
  03:21:18.617 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8aed94b9000069b438b","customerId":"673ff896b0df5c00019b1f3b","customer":{"id":null,"firstName":"LNstXzKIIEK
  03:21:19.192 [carts] 2024-11-22 03:21:19.191 ERROR [carts,,,] 7 --- [-nio-80-exec-21] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in co
  03:21:19.732 [front-end] Received response: "{\"firstName\":\"fnNnBGFeZwjz\",\"lastName\":\"fnNnBGFeZwjz\",\"username\":\"fnNnBGFeZwjz\",\"id\":\"673ff899b0df5c00019b1f44\",\"_links\":{
  03:21:20.489 [carts] 2024-11-22 03:21:20.489 INFO [carts,1a96d1a5e6677ef9,26c40acdb9a0d635,false] 7 --- [-nio-80-exec-22] w.w.s.cart.controllers.ItemsController : Did not find item.  (×19)
  03:21:22.904 [front-end] Order response: {"id":"673ff8b2d94b9000069b439a","customerId":"673ff898b0df5c00019b1f40","customer":{"id":null,"firstName":"TxflHMpaWteY","lastName":"TxflHMpaWt
  03:21:27.105 [front-end] Order response: {"id":"673ff8b7d94b9000069b439d","customerId":"673ff89fb0df5c00019b1f5d","customer":{"id":null,"firstName":"gxEQQKdgPqad","lastName":"gxEQQKdgPq
  03:21:32.309 [front-end] Received response: "{\"firstName\":\"vpxxpRNxF\",\"lastName\":\"vpxxpRNxF\",\"username\":\"vpxxpRNxF\",\"id\":\"673ff8a0b0df5c00019b1f63\",\"_links\":{\"address
  03:21:34.413 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8bed94b9000069b43a0","customerId":"673ff8a6b0df5c00019b1f7f","customer":{"id":null,"firstName":"BXlkiHWqBVY
  03:21:36.305 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8c0d94b9000069b43a2","customerId":"673ff8a7b0df5c00019b1f82","customer":{"id":null,"firstName":"onbFNMM","l
  03:21:38.705 [front-end] Order response: {"id":"673ff8c2d94b9000069b43a5","customerId":"673ff8acb0df5c00019b1f92","customer":{"id":null,"firstName":"jStfWCKVIxuZsZx","lastName":"jStfWCK
  03:21:42.644 [front-end] Posting Customer: {"username":"xJlcQpb","password":"oVqgWBllp","email":"xJlcQpb@gmail.com","firstName":"xJlcQpb","lastName":"xJlcQpb"}
  03:21:45.013 [front-end] Received response: "{\"firstName\":\"BHMHa\",\"lastName\":\"BHMHa\",\"username\":\"BHMHa\",\"id\":\"673ff8b3b0df5c00019b1f9d\",\"_links\":{\"addresses\":{\"href
  03:21:50.026 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8ced94b9000069b43ad","customerId":"673ff8b9b0df5c00019b1fac","customer":{"id":null,"firstName":"QoPcWQ","la

## p0500
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:12:28.222Z
```
{"timestamp":1732353148222411300,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:12:28.222348347Z caller=middlewares.go:75 method=GetUsers id=67419c67a437380001df0aac result=1 took=1.492145ms"}
```
Same service, the 2 minutes before (oldest first):
  09:12:25.606 [user] ts=2024-11-23T09:12:25.606144096Z caller=middlewares.go:75 method=GetUsers id=67419c61a437380001df0a97 result=1 took=2.134321ms  (×9)
  09:12:25.745 [user] ts=2024-11-23T09:12:25.745575028Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419c74a437380001df0ad6 took=4.478782ms  (×3)
  09:12:25.810 [user] ts=2024-11-23T09:12:25.809704788Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419c74a437380001df0ad6 took=4.790574ms  (×3)
  09:12:25.848 [user] ts=2024-11-23T09:12:25.848813863Z caller=middlewares.go:157 method=Health result=2 took=2.279815ms  (×2)
  09:12:25.982 [user] ts=2024-11-23T09:12:25.982117225Z caller=middlewares.go:46 method=Register username=JGPFGlNTcVyb email=JGPFGlNTcVyb@gmail.com took=2.511216ms
  09:12:26.284 [user] ts=2024-11-23T09:12:26.28454399Z caller=middlewares.go:46 method=Register username=PNSkm email=PNSkm@gmail.com took=3.037437ms
  09:12:26.866 [user] ts=2024-11-23T09:12:26.865963061Z caller=middlewares.go:46 method=Register username=gscExKGkP email=gscExKGkP@gmail.com took=2.651685ms
All services, 30 seconds either side (sampled):
  09:11:58.848 [user] ts=2024-11-23T09:11:58.84819459Z caller=middlewares.go:157 method=Health result=2 took=2.002453ms  (×40)
  09:11:58.972 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67419  (×60)
  09:11:58.984 [front-end] Order response: {"cause":{"cause":{"cause":null,"message":"Conflicting setter definitions for property \"items\": works.weave.socks.orders.entities.CustomerOrde  (×60)
  09:11:59.246 [front-end] Carts merged.  (×67)
  09:11:59.513 [user] ts=2024-11-23T09:11:59.512884636Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419c58a437380001df0a7d took=4.210522ms  (×63)
  09:11:59.580 [front-end] Attempting to delete cart for user: 67419c58a437380001df0a7d  (×63)
  09:11:59.649 [carts] 2024-11-23 09:11:59.649 INFO [carts,238c6e3c71df334e,7fe5c6dda5b5aec1,false] 7 --- [-nio-80-exec-11] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×28)
  09:12:00.320 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×10)
  09:12:02.304 [front-end] Posting Customer: {"username":"kcaLY","password":"rpkqS","email":"kcaLY@gmail.com","firstName":"kcaLY","lastName":"kcaLY"}
  09:12:07.690 [front-end] Received response: "{\"firstName\":\"zPHqciiwyqenSGN\",\"lastName\":\"zPHqciiwyqenSGN\",\"username\":\"zPHqciiwyqenSGN\",\"id\":\"67419c51a437380001df0a67\",\"_
  09:12:08.991 [front-end] Posting Customer: {"username":"qwyBNredl","password":"mhwwtbKRZ","email":"qwyBNredl@gmail.com","firstName":"qwyBNredl","lastName":"qwyBNredl"}
  09:12:11.585 [front-end] Posting Customer: {"username":"pkwMyGl","password":"YEDnL","email":"pkwMyGl@gmail.com","firstName":"pkwMyGl","lastName":"pkwMyGl"}
  09:12:13.466 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  09:12:14.501 [user] ts=2024-11-23T09:12:14.501031913Z caller=middlewares.go:46 method=Register username=EUMzXXa email=EUMzXXa@gmail.com took=1.812721ms
  09:12:15.386 [front-end] Received response: "{\"firstName\":\"vbiBfVqApke\",\"lastName\":\"vbiBfVqApke\",\"username\":\"vbiBfVqApke\",\"id\":\"67419c58a437380001df0a78\",\"_links\":{\"a
  09:12:18.441 [front-end] Received response: "{\"firstName\":\"rCxmFVCsVUZ\",\"lastName\":\"rCxmFVCsVUZ\",\"username\":\"rCxmFVCsVUZ\",\"id\":\"67419c5fa437380001df0a8b\",\"_links\":{\"a
  09:12:23.073 [front-end] Received response: "{\"firstName\":\"DdxFTBitBjaGGL\",\"lastName\":\"DdxFTBitBjaGGL\",\"username\":\"DdxFTBitBjaGGL\",\"id\":\"67419c66a437380001df0aaa\",\"_lin
  09:12:26.284 [user] ts=2024-11-23T09:12:26.28454399Z caller=middlewares.go:46 method=Register username=PNSkm email=PNSkm@gmail.com took=3.037437ms
  09:12:29.551 [front-end] Received response: "{\"firstName\":\"zJuRLJF\",\"lastName\":\"zJuRLJF\",\"username\":\"zJuRLJF\",\"id\":\"67419c69a437380001df0aaf\",\"_links\":{\"addresses\":{
  09:12:32.498 [front-end] Received response: "{\"firstName\":\"UNsnkGDY\",\"lastName\":\"UNsnkGDY\",\"username\":\"UNsnkGDY\",\"id\":\"67419c6fa437380001df0ac4\",\"_links\":{\"addresses\
  09:12:34.863 [front-end] Posting Customer: {"username":"ehbWySlKxtdw","password":"acmzjnCpKl","email":"ehbWySlKxtdw@gmail.com","firstName":"ehbWySlKxtdw","lastName":"ehbWySlKxtdw"}
  09:12:38.595 [front-end] Received response: "{\"firstName\":\"BblAmqOWJiD\",\"lastName\":\"BblAmqOWJiD\",\"username\":\"BblAmqOWJiD\",\"id\":\"67419c70a437380001df0ac9\",\"_links\":{\"a
  09:12:40.898 [user] ts=2024-11-23T09:12:40.898484853Z caller=middlewares.go:46 method=Register username=HITLIO email=HITLIO@gmail.com took=2.310988ms
  09:12:43.664 [user] ts=2024-11-23T09:12:43.663942953Z caller=middlewares.go:46 method=Register username=aDRJB email=aDRJB@gmail.com took=2.507339ms
  09:12:48.622 [front-end] Received response: "{\"firstName\":\"HOaNB\",\"lastName\":\"HOaNB\",\"username\":\"HOaNB\",\"id\":\"67419c7ca437380001df0af1\",\"_links\":{\"addresses\":{\"href
  09:12:50.323 [front-end] Posting Customer: {"username":"OqxPK","password":"HaViQu","email":"OqxPK@gmail.com","firstName":"OqxPK","lastName":"OqxPK"}
  09:12:54.708 [front-end] Posting Customer: {"username":"vgFJcOphqQKkmA","password":"TsjKOAjq","email":"vgFJcOphqQKkmA@gmail.com","firstName":"vgFJcOphqQKkmA","lastName":"vgFJcOphqQKkmA"
  09:12:57.122 [front-end] Received response: "{\"firstName\":\"ehbWySlKxtdw\",\"lastName\":\"ehbWySlKxtdw\",\"username\":\"ehbWySlKxtdw\",\"id\":\"67419c82a437380001df0afd\",\"_links\":{

## p0730
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-14T20:29:10.503Z
```
{"service":"dbservice1","message":"2021-08-14 20:29:10,503 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | b8696d75ccc7169a | 39937f32-fcfb-11eb-8d74-0242ac110004-aRNnXZPl-Eq0%L#J(4Boe token generate success token=MTYyODk0NDE1MC41MDM0Mjg1OjM5OTM3ZjMyLWZjZmItMTFlYi04ZDc0LTAyNDJhYzExMDAwNGFSTm5YWlBsRXEwJUwjSig0Qm9lOjE2Mjg5NDQyMTAuNTAzNDM5NDpiZDRmYjllYjk2YjNjNjEyMDlhNjA3N2JlNjBmYjRjYw=="}
```
Same service, the 2 minutes before (oldest first):
  20:29:00.274 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×6)
  20:29:00.327 [dbservice1] INFO query = select passwards from username_table where user_name='GkqNMDBg'  (×4)
  20:29:00.404 [dbservice1] INFO 3395ae48-fcfb-11eb-b112-0242ac110004-GkqNMDBg-ID.O_x7!3miT token generate success token=MTYyODk0NDE0MC40MDM5MjYxOjMzOTVhZTQ4LWZjZmItMTFlYi1iMTEyLTAyNDJhYzE
  20:29:03.203 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  20:29:03.363 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c  (×2)
  20:29:05.445 [dbservice1] INFO 368177fe-fcfb-11eb-b5e5-0242ac110003-uHrsPUfR-&IVwh=}zb.Hu token generate success token=MTYyODk0NDE0NS40NDQ5NzkyOjM2ODE3N2ZlLWZjZmItMTFlYi1iNWU1LTAyNDJhYzE
  20:29:09.653 [dbservice1] INFO 390b2092-fcfb-11eb-90f3-0242ac110003-WdLJXtHG-UZY)^Efxi>LV token generate success token=MTYyODk0NDE0OS42NTM0NjE6MzkwYjIwOTItZmNmYi0xMWViLTkwZjMtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  20:28:42.356 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  20:28:42.531 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×39)
  20:28:42.838 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  20:28:42.900 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×40)
  20:28:43.089 [dbservice1] INFO 2938b936-fcfb-11eb-a4f5-0242ac110003-QClFzynH-qP%6L:4dAwRi token generate success token=MTYyODk0NDEyMy4wODkyNjk0OjI5MzhiOTM2LWZjZmItMTFlYi1hNGY1LTAyNDJhYzE
  20:28:43.905 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×37)
  20:28:44.116 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  20:28:45.367 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×30)
  20:28:45.615 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '2aeb2408-fcfb-11eb-97a6-0242ac110003'}  (×33)
  20:28:46.270 [dbservice1] INFO 2b27ee74-fcfb-11eb-9d3b-0242ac110004-oJIvjPYZ-D^aCEpjQ4J*l token generate success token=MTYyODk0NDEyNi4yNzAzODM6MmIyN2VlNzQtZmNmYi0xMWViLTlkM2ItMDI0MmFjMTE
  20:28:48.863 [dbservice2] INFO 2ca15e8e-fcfb-11eb-ac81-0242ac110003-VkjGfAwW-1:P5T_I!BiLK token generate success token=MTYyODk0NDEyOC44NjM0Mjg4OjJjYTE1ZThlLWZjZmItMTFlYi1hYzgxLTAyNDJhYzE
  20:28:51.367 [dbservice2] INFO 2e2b16a0-fcfb-11eb-ab72-0242ac110004-cCODHfIu-x6(1%5_Mw>&: token generate success token=MTYyODk0NDEzMS4zNjcxMTQ1OjJlMmIxNmEwLWZjZmItMTFlYi1hYjcyLTAyNDJhYzE
  20:28:54.283 [mobservice2] INFO info 301476a0-fcfb-11eb-b088-0242ac110004:KrCJbket write success
  20:29:03.363 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c  (×3)
  20:29:04.608 [webservice2] ERROR an error occurred in the downstream service  (×2)
  20:29:07.180 [dbservice2] INFO 3791d76a-fcfb-11eb-a227-0242ac110003-AZDazHog-x0wyv=p$s&h( token generate success token=MTYyODk0NDE0Ny4xODAyNzg6Mzc5MWQ3NmEtZmNmYi0xMWViLWEyMjctMDI0MmFjMTE
  20:29:09.278 [mobservice1] INFO info 390b2092-fcfb-11eb-90f3-0242ac110003:WdLJXtHG write success
  20:29:11.962 [dbservice2] INFO 3a77ca3e-fcfb-11eb-bc3a-0242ac110004-ytsxAVue-cLXtJDSeQN>} token generate success token=MTYyODk0NDE1MS45NjE2MTQ2OjNhNzdjYTNlLWZjZmItMTFlYi1iYzNhLTAyNDJhYzE
  20:29:14.621 [mobservice1] INFO info 3c29497a-fcfb-11eb-80fb-0242ac110003:CuYtcsiR write success
  20:29:17.143 [mobservice2] INFO info 3dc781a2-fcfb-11eb-a33f-0242ac110004:bykmrCDS write success
  20:29:19.286 [dbservice2] INFO 3ec0af20-fcfb-11eb-92d9-0242ac110003-fVwtyQDn-m0:RzXgt4@vn token generate success token=MTYyODk0NDE1OS4yODYxOjNlYzBhZjIwLWZjZmItMTFlYi05MmQ5LTAyNDJhYzExMDA
  20:29:21.900 [dbservice1] INFO 40617d00-fcfb-11eb-95d8-0242ac110003-fwiKVRsI-Zn_hI=&Gmt4* token generate success token=MTYyODk0NDE2MS44OTk4NDE1OjQwNjE3ZDAwLWZjZmItMTFlYi05NWQ4LTAyNDJhYzE
  20:29:24.214 [mobservice1] INFO info 42013e20-fcfb-11eb-8788-0242ac110004:GKtJXRfS write success
  20:29:26.249 [dbservice1] INFO 4300d326-fcfb-11eb-a5d8-0242ac110004-UfMpdlBq-fL(<c!OYDx@^ token generate success token=MTYyODk0NDE2Ni4yNDk0Mjc4OjQzMDBkMzI2LWZjZmItMTFlYi1hNWQ4LTAyNDJhYzE
  20:29:28.795 [mobservice2] INFO info 44ac9f3e-fcfb-11eb-be67-0242ac110004:dNrOSsHL write success
  20:29:31.280 [dbservice2] INFO 45eac09c-fcfb-11eb-b1b7-0242ac110003-LXQegUZS-iNwdpV=%fU<F token generate success token=MTYyODk0NDE3MS4yNzk5NzE2OjQ1ZWFjMDljLWZjZmItMTFlYi1iMWI3LTAyNDJhYzE
  20:29:34.435 [mobservice1] INFO info 480f6350-fcfb-11eb-8eb0-0242ac110004:bHrMSWsj write success
  20:29:36.541 [dbservice1] INFO 4914af6c-fcfb-11eb-abb3-0242ac110003-PuHhfCZO-GImoA>p7EnU6 token generate success token=MTYyODk0NDE3Ni41NDE0NDQ4OjQ5MTRhZjZjLWZjZmItMTFlYi1hYmIzLTAyNDJhYzE
  20:29:38.728 [mobservice1] INFO info 4aa4620a-fcfb-11eb-8e4e-0242ac110004:oYbSglqf write success

## p0074
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-13T09:33:23.614Z
```
{"service":"logservice1","message":"2021-08-13 09:33:23,614 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | a589657b1ab9ff52 | now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  09:33:20.070 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '708bef18-fbd6-11eb-be80-0242ac110004', 'user_id': 'WRrkiQEt'}  (×5)
  09:33:20.269 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  09:33:20.270 [logservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×2)
  09:33:20.270 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '70a81a80-fbd6-11eb-bcff-0242ac110004'}  (×2)
  09:33:20.372 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×2)
  09:33:20.373 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×2)
  09:33:21.506 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×3)
  09:33:21.506 [logservice1] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×2)
All services, 30 seconds either side (sampled):
  09:32:53.622 [redisservice1] INFO redis write success  (×86)
  09:32:53.764 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×40)
  09:32:54.022 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×39)
  09:32:55.009 [mobservice2] ERROR uuid:5b290fe8-fbd6-11eb-a5f5-0242ac110003 information has expired, mobile phone login is invalid
  09:32:55.179 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  09:32:55.376 [webservice1] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×36)
  09:32:55.721 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×35)
  09:32:55.845 [redisservice1] INFO service accept, status_code: 200  (×38)
  09:32:56.266 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×39)
  09:32:57.109 [dbservice1] INFO 62ab1ee6-fbd6-11eb-b7a9-0242ac110004-MXIwargu-ua>(SrBpfXKs token generate success token=MTYyODgxODM3Ny4xMDk1MDA2OjYyYWIxZWU2LWZiZDYtMTFlYi1iN2E5LTAyNDJhYzE
  09:32:59.613 [mobservice2] INFO info 646eaf5e-fbd6-11eb-8a26-0242ac110004:AFDxXgnQ write success
  09:33:01.617 [dbservice1] INFO 6568f1f8-fbd6-11eb-a72e-0242ac110003-jIBRSGcQ-)ERfPKel{cTt token generate success token=MTYyODgxODM4MS42MTcxMTA3OjY1NjhmMWY4LWZiZDYtMTFlYi1hNzJlLTAyNDJhYzE
  09:33:05.539 [mobservice1] INFO info 6808f64c-fbd6-11eb-97b3-0242ac110003:pvKgfqae write success
  09:33:11.629 [dbservice2] INFO 6b69f340-fbd6-11eb-b8d4-0242ac110003-hTjCBtGX-eJrbTQXfMu<_ token generate success token=MTYyODgxODM5MS42Mjg2NTk1OjZiNjlmMzQwLWZiZDYtMTFlYi1iOGQ0LTAyNDJhYzE
  09:33:14.182 [mobservice2] INFO info 6d22bc08-fbd6-11eb-b85e-0242ac110004:IFyHcfZd write success
  09:33:16.607 [dbservice2] INFO 6e705ff2-fbd6-11eb-b773-0242ac110003-JZinoGDa-nw4#7?JZCUe) token generate success token=MTYyODgxODM5Ni42MDcxMTkzOjZlNzA1ZmYyLWZiZDYtMTFlYi1iNzczLTAyNDJhYzE
  09:33:18.741 [mobservice1] INFO info 6fe986b0-fbd6-11eb-93e4-0242ac110004:vyNKmojf write success
  09:33:21.845 [dbservice2] INFO 7167cb82-fbd6-11eb-93c0-0242ac110004-BlNycPMr-X$O4_}b1+_(N token generate success token=MTYyODgxODQwMS44NDU0MDYzOjcxNjdjYjgyLWZiZDYtMTFlYi05M2MwLTAyNDJhYzE
  09:33:24.694 [mobservice1] INFO info 737107ea-fbd6-11eb-bc4f-0242ac110003:RUxdhMNy write success
  09:33:27.172 [dbservice1] INFO 7486401e-fbd6-11eb-9daa-0242ac110004-dzcaqmiU-y0Gd$h@MNAoL token generate success token=MTYyODgxODQwNy4xNzIxOTQ3Ojc0ODY0MDFlLWZiZDYtMTFlYi05ZGFhLTAyNDJhYzE
  09:33:29.959 [mobservice2] INFO info 7687f538-fbd6-11eb-ab82-0242ac110004:WYMpZilL write success
  09:33:32.975 [mobservice1] INFO info 7865cdda-fbd6-11eb-81d2-0242ac110003:bHrMSWsj write success
  09:33:35.250 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×2)
  09:33:37.940 [dbservice2] INFO 7b18b7f4-fbd6-11eb-89e5-0242ac110004-OkyWpDvC-YSR3f{z?a:H/ token generate success token=MTYyODgxODQxNy45Mzk2NTY3OjdiMThiN2Y0LWZiZDYtMTFlYi04OWU1LTAyNDJhYzE
  09:33:40.773 [dbservice1] INFO 7cbd5cb8-fbd6-11eb-a281-0242ac110003-EAoGeZwV-fb^z8tm>W.Jk token generate success token=MTYyODgxODQyMC43NzM1MzM2OjdjYmQ1Y2I4LWZiZDYtMTFlYi1hMjgxLTAyNDJhYzE
  09:33:43.809 [dbservice2] INFO 7e874b62-fbd6-11eb-9901-0242ac110004-OvVHWlKe-(vX2)-M{rxI! token generate success token=MTYyODgxODQyMy44MDg2MDY2OjdlODc0YjYyLWZiZDYtMTFlYi05OTAxLTAyNDJhYzE
  09:33:46.378 [mobservice2] INFO info 804f55d4-fbd6-11eb-b189-0242ac110003:IvLqACZF write success
  09:33:49.122 [mobservice1] INFO info 8204efba-fbd6-11eb-89d8-0242ac110004:lAeMCLWx write success
  09:33:51.367 [mobservice2] INFO info 8355003a-fbd6-11eb-8714-0242ac110004:Qygqzmel write success
  09:33:53.204 [dbservice2] INFO 844a73c6-fbd6-11eb-ac8d-0242ac110004-acGlMCEq-XtWM=.lec?n8 token generate success token=MTYyODgxODQzMy4yMDQxNDkyOjg0NGE3M2M2LWZiZDYtMTFlYi1hYzhkLTAyNDJhYzE

## p0762
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T06:36:33.692Z
```
{"timestamp":1732257393692102400,"container_name":"carts","pod_name":"carts-6cdcbc6cd7-kqnt9","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 06:36:33.691  INFO [carts,,,] 7 --- [           main] o.s.d.r.w.RepositoryRestHandlerMapping   : Mapped \"{[/{repository}/{id}],methods=[GET],produces=[application/hal+json || application/json || application/*+json;charset=UTF-8]}\" onto public org.springframework.http.ResponseEntity<org.springframework.hateoas.Resource<?>> org.springframework.data.rest.webmvc.RepositoryEntityController.g…"}
```
Same service, the 2 minutes before (oldest first):
  06:36:15.684 [carts] 2024-11-22 06:36:15.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  06:36:18.788 [carts] 2024-11-22 06:36:18.787 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  06:36:19.090 [carts] 2024-11-22 06:36:19.090 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.ac
  06:36:21.290 [carts] 2024-11-22 06:36:21.290 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.sp
  06:36:21.290 [carts] 2024-11-22 06:36:21.290 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springfram
  06:36:21.290 [carts] 2024-11-22 06:36:21.290 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/browser/**] onto handler of type [class org.sp
  06:36:21.291 [carts] 2024-11-22 06:36:21.290 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr
  06:36:21.291 [carts] 2024-11-22 06:36:21.290 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/**] onto handler of type [class org.s
  06:36:21.887 [carts] 2024-11-22 06:36:21.887 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionHa
  06:36:21.887 [carts] 2024-11-22 06:36:21.887 INFO [carts,,,] 7 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected ResponseBodyAdvice implementation in org.springframewo
  06:36:22.588 [carts] 2024-11-22 06:36:22.588 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class or
  06:36:33.387 [carts] 2024-11-22 06:36:33.387 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.e
  06:36:33.390 [carts] 2024-11-22 06:36:33.389 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.actu
  06:36:33.687 [carts] 2024-11-22 06:36:33.686 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[HEAD],produces=[application/hal+json ||
  06:36:33.687 [carts] 2024-11-22 06:36:33.687 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[application/hal+json || 
  06:36:33.687 [carts] 2024-11-22 06:36:33.687 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+json
  06:36:33.691 [carts] 2024-11-22 06:36:33.690 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[OPTIONS],produces=[application/
  06:36:33.691 [carts] 2024-11-22 06:36:33.691 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[DELETE],produces=[applicat
  06:36:33.691 [carts] 2024-11-22 06:36:33.691 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/x-sp  (×2)
All services, 30 seconds either side (sampled):
  06:36:03.880 [catalogue] ts=2024-11-22T06:36:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=3.275299ms  (×55)
  06:36:04.066 [catalogue] ts=2024-11-22T06:36:04Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=3.245515  (×57)
  06:36:04.570 [front-end] POST /register 200 33.866 ms - 33  (×58)
  06:36:04.812 [user] ts=2024-11-22T06:36:04.812584501Z caller=middlewares.go:104 method=GetAddresses id=67402644768f35000114f25b result=1 took=3.025736ms  (×61)
  06:36:05.656 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×7)
  06:36:08.913 [front-end] Received response: "{\"firstName\":\"BmILFqpQQNs\",\"lastName\":\"BmILFqpQQNs\",\"username\":\"BmILFqpQQNs\",\"id\":\"67402645768f35000114f25f\",\"_links\":{\"a
  06:36:14.175 [front-end] Received response: "{\"firstName\":\"vetHfOa\",\"lastName\":\"vetHfOa\",\"username\":\"vetHfOa\",\"id\":\"67402646768f35000114f265\",\"_links\":{\"addresses\":{
  06:36:15.591 [carts] 2024-11-22 06:36:15.591 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  06:36:17.466 [front-end] Received response: "{\"firstName\":\"QJMFN\",\"lastName\":\"QJMFN\",\"username\":\"QJMFN\",\"id\":\"6740264b768f35000114f272\",\"_links\":{\"addresses\":{\"href
  06:36:21.291 [carts] 2024-11-22 06:36:21.290 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr
  06:36:24.801 [front-end] Posting Customer: {"username":"uMXWIJl","password":"PPMwnvT","email":"uMXWIJl@gmail.com","firstName":"uMXWIJl","lastName":"uMXWIJl"}
  06:36:30.643 [front-end] Posting Customer: {"username":"yfldIzlTyncAlo","password":"CjVLJ","email":"yfldIzlTyncAlo@gmail.com","firstName":"yfldIzlTyncAlo","lastName":"yfldIzlTyncAlo"}
  06:36:33.387 [carts] 2024-11-22 06:36:33.387 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.e
  06:36:33.693 [carts] 2024-11-22 06:36:33.693 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[HEAD],produces=[application/hal
  06:36:33.887 [carts] 2024-11-22 06:36:33.883 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[OPTIONS],produces=[appli
  06:36:36.389 [front-end] Posting Customer: {"username":"aKCwShlAwGPEhX","password":"qxliGKuiD","email":"aKCwShlAwGPEhX@gmail.com","firstName":"aKCwShlAwGPEhX","lastName":"aKCwShlAwGPEhX
  06:36:37.991 [carts] 2024-11-22 06:36:37.984 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.s
  06:36:39.342 [front-end] Received response: "{\"firstName\":\"Utiub\",\"lastName\":\"Utiub\",\"username\":\"Utiub\",\"id\":\"67402665768f35000114f2c4\",\"_links\":{\"addresses\":{\"href
  06:36:41.562 [carts-db] {"t":{"$date":"2024-11-22T06:36:41.562+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173225740
  06:36:44.889 [carts] 2024-11-22 06:36:44.889 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposur  (×2)
  06:36:46.062 [front-end] Posting Customer: {"username":"KzfLt","password":"RQKgOR","email":"KzfLt@gmail.com","firstName":"KzfLt","lastName":"KzfLt"}
  06:36:48.645 [front-end] Received response: "{\"firstName\":\"KUAXFRqoYpQTdbi\",\"lastName\":\"KUAXFRqoYpQTdbi\",\"username\":\"KUAXFRqoYpQTdbi\",\"id\":\"67402672768f35000114f2e6\",\"_
  06:36:51.919 [front-end] Posting Customer: {"username":"yymIsxhZQ","password":"nyGyyp","email":"yymIsxhZQ@gmail.com","firstName":"yymIsxhZQ","lastName":"yymIsxhZQ"}
  06:36:53.861 [front-end] Received response: "{\"firstName\":\"rKgpsuhxEFJiC\",\"lastName\":\"rKgpsuhxEFJiC\",\"username\":\"rKgpsuhxEFJiC\",\"id\":\"67402676768f35000114f2f6\",\"_links\
  06:36:55.010 [queue-master] 2024-11-22 06:36:55.010 ERROR 7 --- [pool-6-thread-2] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×9)
  06:36:55.208 [front-end] Order response: {"id":"67402687531af4000701df46","customerId":"6740266f768f35000114f2dd","customer":{"id":null,"firstName":"XeXhSPvQ","lastName":"XeXhSPvQ","use
  06:36:56.887 [carts] 2024-11-22 06:36:56.885 INFO [carts,07bf2a44dcbb04b4,9a00f1d0b9593733,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.controllers.ItemsController : Did not find item.  (×6)
  06:36:58.899 [queue-master] 2024-11-22 06:36:58.899 INFO 7 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×3)
  06:37:03.201 [front-end] Order response: {"statusCode":201,"body":{"id":"6740268f531af4000701df4e","customerId":"67402675768f35000114f2ef","customer":{"id":null,"firstName":"uUopaQr","l

## p0367
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:36:49.017Z
```
{"timestamp":1732246609017167400,"container_name":"carts","pod_name":"carts-6cdcbc6cd7-bswq8","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:36:49.017  INFO [carts,ef17c2f2eb7aa957,159ea883b1b95cf7,false] 7 --- [p-nio-80-exec-6] w.w.s.cart.cart.CartContentsResource     : Adding for user: Cart{id='673ffc502f1cab0007fac4a7', customerId='673ffc4bb0df5c00019b2a91', items=[]}, Item{id='673ffc512f1cab0007fac4a8', itemId='zzz4f044-b040-410d-8ead-4de0446aec7e', quantity=1, unitPrice=12.0}"}
```
Same service, the 2 minutes before (oldest first):
  03:36:44.340 [carts] 2024-11-22 03:36:44.339 INFO [carts,c6539271bfe92377,27b9b057d74cfc99,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)
  03:36:44.892 [carts] 2024-11-22 03:36:44.892 INFO [carts,a487521d19fd2563,527f6f3412b48f99,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×3)
  03:36:45.172 [carts] 2024-11-22 03:36:45.172 INFO [carts,7c9bf04d9eb565f2,de03bef508a36dae,false] 7 --- [-nio-80-exec-18] w.w.s.cart.controllers.ItemsController : Did not find item.  (×4)
  03:36:45.178 [carts] 2024-11-22 03:36:45.178 INFO [carts,7c9bf04d9eb565f2,de03bef508a36dae,false] 7 --- [-nio-80-exec-18] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)
  03:36:46.821 [carts] 2024-11-22 03:36:46.821 INFO [carts,3704ba1be3400a56,94c4e22c2f0f78e5,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.ItemsController : Did not find item.  (×4)
  03:36:47.031 [carts] 2024-11-22 03:36:47.031 INFO [carts,0b44965d316c7da6,f2badf45c6d52e5b,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.controllers.CartsController : Merge carts reques
All services, 30 seconds either side (sampled):
  03:36:19.225 [front-end] Request received with body: {}  (×57)
  03:36:19.262 [orders] 2024-11-22 03:36:19.262 INFO [orders,612d749c22f522a1,c7f2713b0d2d1d5d,false] 6 --- [p-nio-80-exec-8] w.w.s.o.controllers.OrdersController : Received payment re  (×35)
  03:36:19.410 [user] ts=2024-11-22T03:36:19.410208537Z caller=middlewares.go:46 method=Register username=TzpmEHoDBNcNj email=TzpmEHoDBNcNj@gmail.com took=1.075324ms  (×27)
  03:36:19.844 [payment] ts=2024-11-22T03:36:19Z caller=logging.go:40 method=Health result=1 took=8.514µs  (×40)
  03:36:21.252 [catalogue] ts=2024-11-22T03:36:21Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.117916ms  (×60)
  03:36:21.837 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×60)
  03:36:22.246 [front-end] Posting Customer: {"username":"jqdvFFlf","password":"JshiLcv","email":"jqdvFFlf@gmail.com","firstName":"jqdvFFlf","lastName":"jqdvFFlf"}
  03:36:23.193 [carts] 2024-11-22 03:36:23.193 INFO [carts,1160ab3ed132aa72,4eb796aed0210e59,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.controllers.ItemsController : Did not find item.  (×31)
  03:36:26.899 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×10)
  03:36:28.832 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc3cd94b9000069b463e","customerId":"673ffc23b0df5c00019b2a12","customer":{"id":null,"firstName":"TzbTYFIna",
  03:36:32.044 [front-end] Received response: "{\"firstName\":\"bgjkfAfrLnOixr\",\"lastName\":\"bgjkfAfrLnOixr\",\"username\":\"bgjkfAfrLnOixr\",\"id\":\"673ffc24b0df5c00019b2a1e\",\"_lin
  03:36:35.674 [front-end] Received response: "{\"firstName\":\"POxhkiv\",\"lastName\":\"POxhkiv\",\"username\":\"POxhkiv\",\"id\":\"673ffc34b0df5c00019b2a40\",\"_links\":{\"addresses\":{
  03:36:37.251 [user] ts=2024-11-22T03:36:37.25125601Z caller=middlewares.go:46 method=Register username=bqtPj email=bqtPj@gmail.com took=960.499µs
  03:36:39.911 [front-end] Order response: {"id":"673ffc47d94b9000069b4646","customerId":"673ffc33b0df5c00019b2a3e","customer":{"id":null,"firstName":"MabmetW","lastName":"MabmetW","usern
  03:36:41.956 [front-end] Order response: {"id":"673ffc49d94b9000069b4649","customerId":"673ffc2db0df5c00019b2a32","customer":{"id":null,"firstName":"MRYnLbahhGnKX","lastName":"MRYnLbahh
  03:36:43.885 [front-end] Posting Customer: {"username":"vNYfBsZi","password":"PSHhLkxT","email":"vNYfBsZi@gmail.com","firstName":"vNYfBsZi","lastName":"vNYfBsZi"}
  03:36:44.919 [front-end] Order response: {"id":"673ffc4cd94b9000069b464e","customerId":"673ffc38b0df5c00019b2a4b","customer":{"id":null,"firstName":"tjxzlUHEHhdRd","lastName":"tjxzlUHEH
  03:36:47.026 [user] ts=2024-11-22T03:36:47.025975224Z caller=middlewares.go:46 method=Register username=GKmDyaqen email=GKmDyaqen@gmail.com took=1.09441ms
  03:36:50.354 [front-end] Order response: {"id":"673ffc52d94b9000069b4653","customerId":"673ffc3fb0df5c00019b2a6a","customer":{"id":null,"firstName":"dSOOF","lastName":"dSOOF","username"
  03:36:51.808 [front-end] Order response: {"id":"673ffc53d94b9000069b4656","customerId":"673ffc41b0df5c00019b2a70","customer":{"id":null,"firstName":"TGEfJmjiZY","lastName":"TGEfJmjiZY",
  03:36:52.417 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc54d94b9000069b465a","customerId":"673ffc46b0df5c00019b2a83","customer":{"id":null,"firstName":"blwZDSnHRYM
  03:36:55.787 [front-end] Posting Customer: {"username":"AIpFJQ","password":"SlisRV","email":"AIpFJQ@gmail.com","firstName":"AIpFJQ","lastName":"AIpFJQ"}
  03:36:58.782 [front-end] Posting Customer: {"username":"SoXNHD","password":"MpnPP","email":"SoXNHD@gmail.com","firstName":"SoXNHD","lastName":"SoXNHD"}
  03:37:01.901 [front-end] Order response: {"id":"673ffc5dd94b9000069b4661","customerId":"673ffc47b0df5c00019b2a88","customer":{"id":null,"firstName":"iEQFXtQlNQZTcES","lastName":"iEQFXtQ
  03:37:07.295 [front-end] Received response: "{\"firstName\":\"AObUYqBlFGRlcO\",\"lastName\":\"AObUYqBlFGRlcO\",\"username\":\"AObUYqBlFGRlcO\",\"id\":\"673ffc55b0df5c00019b2aae\",\"_lin
  03:37:09.028 [user] ts=2024-11-22T03:37:09.028158268Z caller=middlewares.go:46 method=Register username=Tujouei email=Tujouei@gmail.com took=1.036403ms
  03:37:12.263 [front-end] Order response: {"id":"673ffc68d94b9000069b4668","customerId":"673ffc56b0df5c00019b2ab5","customer":{"id":null,"firstName":"wIVAIFir","lastName":"wIVAIFir","use
  03:37:16.130 [front-end] Received response: "{\"firstName\":\"lVAux\",\"lastName\":\"lVAux\",\"username\":\"lVAux\",\"id\":\"673ffc52b0df5c00019b2aac\",\"_links\":{\"addresses\":{\"href

## p0209
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T07:11:08.383Z
```
{"timestamp":1731913868383025000,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  07:11:07.243 [currencyservice] Getting supported currencies...  (×8)
  07:11:07.262 [currencyservice] conversion request successful  (×12)
All services, 30 seconds either side (sampled):
  07:10:38.387 [currencyservice] conversion request successful  (×777)
  07:10:38.405 [frontend] request complete  (×340)
  07:10:38.497 [currencyservice] Getting supported currencies...  (×276)
  07:10:38.556 [adservice] received ad request (context_words=[kitchen])  (×45)
  07:10:38.573 [frontend] view user cart  (×78)
  07:10:38.891 [frontend] home  (×38)
  07:10:38.971 [frontend] placing order  (×12)
  07:10:38.990 [paymentservice] Transaction processed: visa ending 7797 Amount: EUR108.739495801  (×4)
  07:10:38.994 [shippingservice] [ShipOrder] completed request  (×11)
  07:10:39.002 [checkoutservice] failed to send order confirmation to "oespinoza@example.net": rpc error: code = Unavailable desc = no healthy upstream
  07:10:39.923 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'LS4PSXUNUM', '9SIQT8TOJO', '1YMWWN1N4O']  (×8)
  07:10:44.933 [frontend] setting currency  (×25)
  07:10:48.751 [paymentservice] Transaction processed: visa ending 6156 Amount: CAD65.530133568  (×3)
  07:10:49.005 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"7469","nanos":479331326},"credit_card":{"credit_card_number":"4155672017669  (×2)
  07:10:49.996 [checkoutservice] failed to send order confirmation to "james09@example.org": rpc error: code = Unavailable desc = no healthy upstream
  07:11:01.804 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', 'OLJCESPC7Z']  (×2)
  07:11:09.475 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"1828","nanos":470000000},"credit_card":{"credit_card_number":"4083586225773  (×2)
  07:11:16.530 [checkoutservice] failed to send order confirmation to "gutierrezmichelle@example.net": rpc error: code = Unavailable desc = no healthy upstream
  07:11:17.082 [redis] 72:C 18 Nov 2024 07:11:17.081 * DB saved on disk
  07:11:21.647 [checkoutservice] failed to send order confirmation to "crawfordstephen@example.com": rpc error: code = Unavailable desc = no healthy upstream
  07:11:22.459 [paymentservice] }
  07:11:38.188 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', '0PUK6V6EV0', '66VCHSJNUP']

## p0275
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:23.049Z
```
{"timestamp":1732242503049410300,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Sent cookies."}
```
Same service, the 2 minutes before (oldest first):
  02:28:22.521 [front-end] { id: '673fec46b0df5c00019af994' }  (×2)
  02:28:22.521 [front-end] 673fec46b0df5c00019af994  (×2)
  02:28:22.521 [front-end] Merging carts for customer id: 673fec46b0df5c00019af994 and session id: KkZrOzNoqKgxA2YV9xemsYfowSvZTYBW  (×2)
  02:28:22.550 [front-end] Carts merged.  (×4)
  02:28:22.550 [front-end] set cookie673fec41b0df5c00019af98c  (×4)
  02:28:22.550 [front-end] Sent cookies.  (×3)
  02:28:22.552 [front-end] POST /register 200 4675.058 ms - 33  (×2)
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×48)
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -  (×48)
  02:28:03.203 [front-end] [ undefined, undefined ]  (×48)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×4)
  02:28:07.445 [orders] 2024-11-22 02:28:07.445 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
  02:28:10.277 [front-end] Posting Customer: {"username":"opFqwUnVow","password":"habyXFSF","email":"opFqwUnVow@gmail.com","firstName":"opFqwUnVow","lastName":"opFqwUnVow"}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
  02:28:23.301 [front-end] Received response: "{\"firstName\":\"HFHBXn\",\"lastName\":\"HFHBXn\",\"username\":\"HFHBXn\",\"id\":\"673fec34b0df5c00019af967\",\"_links\":{\"addresses\":{\"h
  02:28:24.999 [rabbitmq] 
  02:28:25.743 [carts] 2024-11-22 02:28:25.743 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×14)
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39d0","customerId":"673fec31b0df5c00019af95b","customer":{"id":null,"firstName":"bCCZHBaYc","lastName":"bCCZHBaYc","u
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×60)
  02:28:37.548 [user] ts=2024-11-22T02:28:37.548591Z caller=middlewares.go:46 method=Register username=OeZpiPZUn email=OeZpiPZUn@gmail.com took=1.009704ms
  02:28:40.321 [front-end] Order response: {"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR","lastName":"nbZCdAQyR","u
  02:28:42.162 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732242522152,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×2)
  02:28:44.338 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec5cd94b9000069b39e2","customerId":"673fec3ab0df5c00019af974","customer":{"id":null,"firstName":"opFqwUnVow"
  02:28:45.405 [front-end] Posting Customer: {"username":"crSMtAKNWrXaJJx","password":"TlwWXSanSW","email":"crSMtAKNWrXaJJx@gmail.com","firstName":"crSMtAKNWrXaJJx","lastName":"crSMtAKNWr
  02:28:47.575 [front-end] Received response: "{\"firstName\":\"QGHrdp\",\"lastName\":\"QGHrdp\",\"username\":\"QGHrdp\",\"id\":\"673fec41b0df5c00019af98c\",\"_links\":{\"addresses\":{\"h
  02:28:50.618 [front-end] Received response: "{\"firstName\":\"XsZRA\",\"lastName\":\"XsZRA\",\"username\":\"XsZRA\",\"id\":\"673fec4ab0df5c00019af99b\",\"_links\":{\"addresses\":{\"href

## p0750
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service shippingservice, 2024-11-23T14:21:39.207Z
```
{"timestamp":1732371699207305700,"container_name":"shippingservice","pod_name":"shippingservice-547ddf469c-zjmvs","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"[GetQuote] completed request"}
```
Same service, the 2 minutes before (oldest first):
  14:21:32.371 [shippingservice] [ShipOrder] completed request  (×2)
  14:21:33.391 [shippingservice] [GetQuote] received request  (×9)
  14:21:33.391 [shippingservice] [GetQuote] completed request  (×8)
  14:21:39.042 [shippingservice] [ShipOrder] received request
All services, 30 seconds either side (sampled):
  14:21:09.536 [frontend] request started  (×326)
  14:21:09.541 [cartservice] GetCartAsync called with userId=6e17f999-1f44-47b4-93f0-534a09a0d813  (×267)
  14:21:09.565 [adservice] received ad request (context_words=[kitchen])  (×53)
  14:21:09.840 [frontend] adding to cart  (×36)
  14:21:09.876 [shippingservice] [GetQuote] received request  (×75)
  14:21:09.890 [checkoutservice] [PlaceOrder] user_id="130330b7-3a65-4d26-a38c-4426081880e7" user_currency="EUR"  (×4)
  14:21:09.908 [checkoutservice] payment went through (transaction_id: 67acfd6a-65ed-4c98-aaee-5063d894a0d3)  (×11)
  14:21:09.913 [cartservice] EmptyCartAsync called with userId=130330b7-3a65-4d26-a38c-4426081880e7  (×11)
  14:21:09.920 [frontend] order placed  (×11)
  14:21:10.649 [frontend] ENV_PLATFORM is: aws  (×35)
  14:21:12.309 [adservice] received ad request (context_words=[decor, home])  (×13)
  14:21:15.916 [emailservice] A request to send order confirmation email to rogersjasmine@example.com has been received.
  14:21:22.556 [adservice] received ad request (context_words=[hair, beauty])  (×12)
  14:21:26.834 [paymentservice] Transaction processed: visa ending 3462 Amount: GBP94.928218481  (×3)
  14:21:31.087 [checkoutservice] [PlaceOrder] user_id="4abf74df-6c0b-4392-bdb0-f19f4d7ff511" user_currency="TRY"
  14:21:31.143 [emailservice] A request to send order confirmation email to ehall@example.org has been received.
  14:21:32.380 [checkoutservice] order confirmation email sent to "ashleycastillo@example.com"
  14:21:39.224 [checkoutservice] [PlaceOrder] user_id="706f37f6-1c4e-4686-b19d-4ff2d2c889ad" user_currency="CAD"  (×2)
  14:21:39.256 [emailservice] A request to send order confirmation email to kathleen63@example.com has been received.
  14:21:46.287 [emailservice] A request to send order confirmation email to autumnpowell@example.com has been received.
  14:21:55.733 [checkoutservice] order confirmation email sent to "ocruz@example.net"
  14:22:03.372 [checkoutservice] [PlaceOrder] user_id="4abf74df-6c0b-4392-bdb0-f19f4d7ff511" user_currency="USD"
  14:22:03.401 [emailservice] A request to send order confirmation email to jgonzalez@example.org has been received.

## p0418
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T04:01:55.244Z
```
{"timestamp":1732248115244533800,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T04:01:55.24432228Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=6740022eb0df5c00019b3c8c took=1.645282ms"}
```
Same service, the 2 minutes before (oldest first):
  04:01:54.093 [user] ts=2024-11-22T04:01:54.093108112Z caller=middlewares.go:157 method=Health result=2 took=833.234µs  (×2)
  04:01:54.533 [user] ts=2024-11-22T04:01:54.533032227Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=6740022cb0df5c00019b3c82 took=1.850907ms  (×3)
  04:01:54.547 [user] ts=2024-11-22T04:01:54.547076319Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6740022cb0df5c00019b3c82 took=1.708638ms  (×3)
  04:01:54.900 [user] ts=2024-11-22T04:01:54.90037507Z caller=middlewares.go:75 method=GetUsers id=6740021fb0df5c00019b3c58 result=1 took=990.034µs  (×8)
  04:01:54.918 [user] ts=2024-11-22T04:01:54.91822965Z caller=middlewares.go:104 method=GetAddresses id=67400225b0df5c00019b3c6d result=1 took=756.197µs  (×2)
  04:01:54.918 [user] ts=2024-11-22T04:01:54.918282944Z caller=middlewares.go:134 method=GetCards id=67400225b0df5c00019b3c6e result=1 took=678.789µs  (×2)
All services, 30 seconds either side (sampled):
  04:01:25.317 [front-end] Request received with body: {}  (×57)
  04:01:25.356 [payment] ts=2024-11-22T04:01:25Z caller=logging.go:29 method=Authorise result=true took=937ns  (×40)
  04:01:25.589 [user] ts=2024-11-22T04:01:25.589200638Z caller=middlewares.go:46 method=Register username=VnCRUBjowSa email=VnCRUBjowSa@gmail.com took=990.962µs  (×16)
  04:01:26.246 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6740020fb0df5c00019b3c26"}  (×66)
  04:01:26.354 [front-end] POST to carts: http://carts/carts/6740020fb0df5c00019b3c26/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}  (×36)
  04:01:27.528 [front-end] Posting Customer: {"username":"Utefkf","password":"DlnuWnIg","email":"Utefkf@gmail.com","firstName":"Utefkf","lastName":"Utefkf"}
  04:01:29.227 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×7)
  04:01:30.585 [front-end] Posting Customer: {"username":"XXbDLxygdKlR","password":"PAolAZqHk","email":"XXbDLxygdKlR@gmail.com","firstName":"XXbDLxygdKlR","lastName":"XXbDLxygdKlR"}
  04:01:33.433 [front-end] Order response: {"id":"6740021dd94b9000069b4afd","customerId":"6740020db0df5c00019b3c25","customer":{"id":null,"firstName":"uRWSle","lastName":"uRWSle","usernam
  04:01:37.352 [queue-master] 2024-11-22 04:01:37.352 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×27)
  04:01:39.860 [user] ts=2024-11-22T04:01:39.860555155Z caller=middlewares.go:104 method=GetAddresses id=6740021ab0df5c00019b3c4d result=1 took=1.147059ms  (×18)
  04:01:40.501 [front-end] Order response: {"statusCode":201,"body":{"id":"67400224d94b9000069b4b03","customerId":"6740020fb0df5c00019b3c26","customer":{"id":null,"firstName":"SpePcNvmaeO
  04:01:41.110 [front-end] Received response: "{\"firstName\":\"roKiiEXOqXdyg\",\"lastName\":\"roKiiEXOqXdyg\",\"username\":\"roKiiEXOqXdyg\",\"id\":\"67400212b0df5c00019b3c35\",\"_links\
  04:01:44.518 [front-end] Posting Customer: {"username":"uZXptwfj","password":"XRkCRQjMX","email":"uZXptwfj@gmail.com","firstName":"uZXptwfj","lastName":"uZXptwfj"}
  04:01:49.005 [front-end] Posting Customer: {"username":"YsqtiInB","password":"wRMge","email":"YsqtiInB@gmail.com","firstName":"YsqtiInB","lastName":"YsqtiInB"}
  04:01:51.589 [front-end] Order response: {"statusCode":201,"body":{"id":"6740022fd94b9000069b4b0b","customerId":"6740021bb0df5c00019b3c53","customer":{"id":null,"firstName":"ZkjsIOEoVAb
  04:01:53.104 [user] ts=2024-11-22T04:01:53.104171461Z caller=middlewares.go:46 method=Register username=DSPbGDN email=DSPbGDN@gmail.com took=1.092359ms
  04:01:57.100 [front-end] Order response: {"id":"67400235d94b9000069b4b12","customerId":"67400219b0df5c00019b3c4b","customer":{"id":null,"firstName":"rTRejMNFcGlJS","lastName":"rTRejMNFc
  04:02:01.252 [user] ts=2024-11-22T04:02:01.252508852Z caller=middlewares.go:46 method=Register username=wXyypFHf email=wXyypFHf@gmail.com took=1.296334ms
  04:02:03.750 [front-end] Received response: "{\"firstName\":\"eNdngzVVve\",\"lastName\":\"eNdngzVVve\",\"username\":\"eNdngzVVve\",\"id\":\"6740022cb0df5c00019b3c82\",\"_links\":{\"addr
  04:02:05.194 [front-end] Received response: "{\"firstName\":\"CtRbrVxS\",\"lastName\":\"CtRbrVxS\",\"username\":\"CtRbrVxS\",\"id\":\"67400224b0df5c00019b3c6a\",\"_links\":{\"addresses\
  04:02:06.803 [front-end] Received response: "{\"firstName\":\"HHXukTfpt\",\"lastName\":\"HHXukTfpt\",\"username\":\"HHXukTfpt\",\"id\":\"67400224b0df5c00019b3c68\",\"_links\":{\"address
  04:02:10.895 [catalogue] ts=2024-11-22T04:02:10Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=4.0891ms  (×2)
  04:02:12.492 [front-end] Order response: {"id":"67400244d94b9000069b4b1f","customerId":"6740022eb0df5c00019b3c8c","customer":{"id":null,"firstName":"DUkKlBk","lastName":"DUkKlBk","usern
  04:02:15.359 [front-end] Received response: "{\"firstName\":\"DSPbGDN\",\"lastName\":\"DSPbGDN\",\"username\":\"DSPbGDN\",\"id\":\"67400231b0df5c00019b3c94\",\"_links\":{\"addresses\":{
  04:02:19.318 [front-end] Posting Customer: {"username":"adycrCEEj","password":"hNbJO","email":"adycrCEEj@gmail.com","firstName":"adycrCEEj","lastName":"adycrCEEj"}
  04:02:20.884 [front-end] Order response: {"statusCode":201,"body":{"id":"6740024cd94b9000069b4b27","customerId":"67400237b0df5c00019b3ca5","customer":{"id":null,"firstName":"JGBElO","la
  04:02:25.009 [front-end] Received response: "{\"firstName\":\"gWApGYGd\",\"lastName\":\"gWApGYGd\",\"username\":\"gWApGYGd\",\"id\":\"6740023cb0df5c00019b3cae\",\"_links\":{\"addresses\

## p0240
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T08:02:48.703Z
```
{"timestamp":1731916968703659500,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-h247x","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  08:02:47.809 [currencyservice] conversion request successful  (×14)
  08:02:47.872 [currencyservice] Getting supported currencies...  (×6)
All services, 30 seconds either side (sampled):
  08:02:19.313 [frontend] request started  (×353)
  08:02:19.320 [cartservice] GetCartAsync called with userId=adf41e5f-12f6-4c40-88a0-a1bcf421e416  (×287)
  08:02:19.347 [adservice] received ad request (context_words=[footwear])  (×20)
  08:02:20.460 [adservice] received ad request (context_words=[decor, home])  (×21)
  08:02:20.585 [frontend] view user cart  (×90)
  08:02:20.608 [shippingservice] [GetQuote] completed request  (×102)
  08:02:22.112 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="CAD"  (×4)
  08:02:22.132 [checkoutservice] payment went through (transaction_id: 680e8906-2d2a-4f60-873d-39f34fffe65f)  (×12)
  08:02:22.136 [cartservice] EmptyCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×12)
  08:02:22.142 [checkoutservice] failed to send order confirmation to "christopherevans@example.org": rpc error: code = Internal desc = Failed to serialize response!
  08:02:23.141 [frontend] setting currency  (×17)
  08:02:23.195 [adservice] received ad request (context_words=[])  (×23)
  08:02:25.991 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="EUR"  (×2)
  08:02:26.025 [emailservice] A request to send order confirmation email to megan53@example.net has been received.
  08:02:40.840 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"56616","nanos":689960833},"credit_card":{"credit_card_number":"456258524699  (×2)
  08:02:40.854 [checkoutservice] failed to send order confirmation to "christophertran@example.net": rpc error: code = Internal desc = Failed to serialize response!
  08:02:56.703 [paymentservice] Transaction processed: visa ending 5662 Amount: TRY19673.804139853  (×3)
  08:02:58.222 [emailservice] A request to send order confirmation email to randy59@example.com has been received.
  08:03:03.791 [checkoutservice] failed to send order confirmation to "omack@example.com": rpc error: code = Internal desc = Failed to serialize response!
  08:03:08.341 [emailservice] A request to send order confirmation email to terrelltroy@example.org has been received.
  08:03:09.007 [checkoutservice] failed to send order confirmation to "christina07@example.net": rpc error: code = Internal desc = Failed to serialize response!
  08:03:13.310 [paymentservice] Transaction processed: visa ending 8003 Amount: GBP534.458873944
  08:03:16.767 [emailservice] A request to send order confirmation email to garciajohn@example.org has been received.
  08:03:17.842 [checkoutservice] failed to send order confirmation to "riverslaura@example.com": rpc error: code = Internal desc = Failed to serialize response!

## p0189
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T06:48:32.381Z
```
{"timestamp":1731912512381681000,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-svrwm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"EmptyCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121"}
```
Same service, the 2 minutes before (oldest first):
  06:48:29.532 [cartservice] GetCartAsync called with userId=c216dec4-2181-4773-8cc5-aa587ee59fcc  (×15)
  06:48:29.789 [cartservice] AddItemAsync called with userId=79b6fc41-70d8-42ea-9810-1ae877ff7add, productId=66VCHSJNUP, quantity=1  (×4)
  06:48:30.057 [cartservice] EmptyCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03
All services, 30 seconds either side (sampled):
  06:48:24.473 [frontend] request started  (×188)
  06:48:24.477 [currencyservice] Getting supported currencies...  (×157)
  06:48:24.488 [currencyservice] conversion request successful  (×395)
  06:48:24.504 [adservice] received ad request (context_words=[decor, home])  (×9)
  06:48:24.556 [adservice] received ad request (context_words=[accessories])  (×20)
  06:48:24.564 [cartservice] AddItemAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03, productId=OLJCESPC7Z, quantity=1  (×18)
  06:48:24.603 [shippingservice] [GetQuote] received request  (×45)
  06:48:25.170 [adservice] received ad request (context_words=[kitchen])  (×30)
  06:48:26.158 [frontend] setting currency  (×13)
  06:48:26.211 [frontend] ENV_PLATFORM is: aws  (×18)
  06:48:26.901 [adservice] received ad request (context_words=[clothing, tops])  (×7)
  06:48:27.795 [adservice] received ad request (context_words=[hair, beauty])  (×17)
  06:48:30.014 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="JPY"
  06:48:30.051 [paymentservice] Transaction processed: visa ending 4133 Amount: JPY147999.249890397
  06:48:30.054 [shippingservice] [ShipOrder] received request  (×2)
  06:48:30.057 [cartservice] EmptyCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03
  06:48:30.063 [checkoutservice] order confirmation email sent to "mccoymelissa@example.net"
  06:48:32.337 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="GBP"
  06:48:32.374 [paymentservice] Transaction processed: visa ending 3003 Amount: GBP1238.66859775
  06:48:32.389 [checkoutservice] order confirmation email sent to "ericlewis@example.org"

## p0737
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-22T12:26:09.075Z
```
{"timestamp":1732278369075709400,"container_name":"frontend","pod_name":"frontend-588fbcd66b-fjnp2","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"serving product page"}
```
Same service, the 2 minutes before (oldest first):
  12:26:07.545 [frontend] request complete  (×5)
  12:26:07.863 [frontend] request started  (×5)
  12:26:07.863 [frontend] serving product page  (×3)
  12:26:07.898 [frontend] failed to retrieve ads  (×3)
  12:26:07.898 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14  (×3)
  12:26:08.384 [frontend] view user cart
All services, 30 seconds either side (sampled):
  12:25:39.129 [frontend] request started  (×302)
  12:25:39.133 [frontend] home  (×30)
  12:25:39.147 [currencyservice] conversion request successful  (×685)
  12:25:39.283 [frontend] failed to retrieve ads  (×170)
  12:25:39.390 [adservice] Tracing enabled but temporarily unavailable  (×2)
  12:25:39.857 [frontend] view user cart  (×71)
  12:25:39.886 [shippingservice] [GetQuote] completed request  (×83)
  12:25:41.084 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  12:25:41.349 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '0PUK6V6EV0', '66VCHSJNUP']  (×11)
  12:25:41.755 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"122","nanos":930000000},"credit_card":{"credit_card_number":"41976842479913  (×4)
  12:25:41.759 [shippingservice] [ShipOrder] received request  (×12)
  12:25:41.769 [emailservice] A request to send order confirmation email to bennettjames@example.net has been received.
  12:25:45.233 [checkoutservice] [PlaceOrder] user_id="622c169c-0d0a-41a5-9033-a384314a893d" user_currency="TRY"  (×2)
  12:25:45.272 [emailservice] A request to send order confirmation email to nicole69@example.com has been received.
  12:25:48.721 [checkoutservice] order confirmation email sent to "katherine46@example.org"
  12:25:52.826 [paymentservice] Transaction processed: visa ending 6502 Amount: GBP54.692281288  (×2)
  12:25:57.636 [emailservice] A request to send order confirmation email to richard52@example.net has been received.
  12:26:04.166 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"476","nanos":80367984},"credit_card":{"credit_card_number":"484260123303825  (×2)
  12:26:04.179 [checkoutservice] order confirmation email sent to "mclay@example.org"
  12:26:09.778 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '6E92ZMYYFZ', '0PUK6V6EV0', 'OLJCESPC7Z']  (×3)
  12:26:26.515 [checkoutservice] [PlaceOrder] user_id="85c06a3e-35d2-4fb8-a638-39a4504f3364" user_currency="JPY"  (×2)
  12:26:26.577 [emailservice] A request to send order confirmation email to harrislisa@example.com has been received.
  12:26:31.684 [checkoutservice] order confirmation email sent to "cwilliams@example.com"
  12:26:35.526 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', 'LS4PSXUNUM']

## p0185
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service shippingservice, 2024-11-18T06:48:25.701Z
```
{"timestamp":1731912505701064700,"container_name":"shippingservice","pod_name":"shippingservice-547ddf469c-vjbwz","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"[GetQuote] received request"}
```
Same service, the 2 minutes before (oldest first):
  06:48:24.603 [shippingservice] [GetQuote] received request  (×2)
  06:48:24.603 [shippingservice] [GetQuote] completed request  (×2)
All services, 30 seconds either side (sampled):
  06:48:24.473 [frontend] request started  (×154)
  06:48:24.477 [currencyservice] Getting supported currencies...  (×127)
  06:48:24.488 [currencyservice] conversion request successful  (×322)
  06:48:24.504 [adservice] received ad request (context_words=[decor, home])  (×7)
  06:48:24.556 [adservice] received ad request (context_words=[accessories])  (×18)
  06:48:24.564 [cartservice] AddItemAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03, productId=OLJCESPC7Z, quantity=1  (×16)
  06:48:24.603 [shippingservice] [GetQuote] received request  (×33)
  06:48:25.170 [adservice] received ad request (context_words=[kitchen])  (×24)
  06:48:26.158 [frontend] setting currency  (×11)
  06:48:26.211 [frontend] ENV_PLATFORM is: aws  (×15)
  06:48:26.901 [adservice] received ad request (context_words=[clothing, tops])  (×3)
  06:48:27.795 [adservice] received ad request (context_words=[hair, beauty])  (×16)
  06:48:30.014 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="JPY"
  06:48:30.051 [paymentservice] Transaction processed: visa ending 4133 Amount: JPY147999.249890397
  06:48:30.054 [shippingservice] [ShipOrder] received request  (×2)
  06:48:30.057 [cartservice] EmptyCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03  (×2)
  06:48:30.063 [checkoutservice] order confirmation email sent to "mccoymelissa@example.net"
  06:48:32.337 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="GBP"
  06:48:32.374 [paymentservice] Transaction processed: visa ending 3003 Amount: GBP1238.66859775
  06:48:32.389 [checkoutservice] order confirmation email sent to "ericlewis@example.org"

## p0094
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:05:38.645Z
```
{"timestamp":1731906338645648000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"adding to cart"}
```
Same service, the 2 minutes before (oldest first):
  05:05:37.535 [frontend] request complete  (×6)
  05:05:37.799 [frontend] request started  (×7)
  05:05:37.800 [frontend] serving product page  (×4)
  05:05:38.383 [frontend] home  (×2)
  05:05:38.431 [frontend] ENV_PLATFORM is: aws
All services, 30 seconds either side (sampled):
  05:05:28.413 [frontend] request started  (×199)
  05:05:28.422 [cartservice] GetCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×166)
  05:05:28.449 [adservice] received ad request (context_words=[accessories])  (×17)
  05:05:28.458 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=1YMWWN1N4O, quantity=7  (×18)
  05:05:28.497 [shippingservice] [GetQuote] completed request  (×44)
  05:05:28.996 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="USD"  (×5)
  05:05:29.017 [checkoutservice] payment went through (transaction_id: e43c7587-0e24-4a72-8d85-16a465855b2a)  (×7)
  05:05:29.021 [cartservice] EmptyCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×7)
  05:05:29.030 [frontend] order placed  (×7)
  05:05:31.741 [adservice] received ad request (context_words=[decor, home])  (×9)
  05:05:32.748 [frontend] ENV_PLATFORM is: aws  (×26)
  05:05:33.869 [adservice] received ad request (context_words=[footwear])  (×14)
  05:05:33.972 [paymentservice] Transaction processed: visa ending 2652 Amount: CAD426.701933656
  05:05:38.673 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×2)
  05:05:46.056 [emailservice] A request to send order confirmation email to fcontreras@example.com has been received.
  05:05:51.642 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13  (×2)
  05:05:51.663 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  05:05:52.043 [redis] 1:M 18 Nov 2024 05:05:52.043 * Background saving started by pid 47
  05:05:52.145 [redis] 1:M 18 Nov 2024 05:05:52.144 * Background saving terminated with success
  05:05:52.522 [paymentservice] Transaction processed: visa ending 2457 Amount: EUR565.165855819
  05:06:04.238 [emailservice] A request to send order confirmation email to michaelacosta@example.net has been received.
  05:06:07.915 [checkoutservice] order confirmation email sent to "cwilson@example.com"

## p0233
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:56:53.908Z
```
{"timestamp":1731916613908871000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  07:56:52.710 [frontend] request started  (×7)
  07:56:52.710 [frontend] view user cart  (×2)
  07:56:52.768 [frontend] request complete  (×5)
  07:56:52.974 [frontend] home
  07:56:53.023 [frontend] ENV_PLATFORM is: aws
  07:56:53.825 [frontend] serving product page  (×3)
  07:56:53.862 [frontend] adding to cart
All services, 30 seconds either side (sampled):
  07:56:23.964 [frontend] request started  (×341)
  07:56:23.972 [cartservice] GetCartAsync called with userId=adf41e5f-12f6-4c40-88a0-a1bcf421e416  (×281)
  07:56:23.996 [adservice] received ad request (context_words=[kitchen])  (×61)
  07:56:24.022 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '6E92ZMYYFZ', 'OLJCESPC7Z', '9SIQT8TOJO']  (×8)
  07:56:24.541 [adservice] received ad request (context_words=[accessories])  (×40)
  07:56:25.506 [frontend] home  (×30)
  07:56:25.716 [adservice] received ad request (context_words=[decor, home])  (×15)
  07:56:26.096 [redis] 81:C 18 Nov 2024 07:56:26.095 * DB saved on disk
  07:56:27.848 [frontend] adding to cart  (×41)
  07:56:27.912 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="JPY"  (×4)
  07:56:27.944 [checkoutservice] payment went through (transaction_id: 959bcadb-4b97-4dcf-a47e-db195ea87a0d)  (×18)
  07:56:27.948 [cartservice] EmptyCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×18)
  07:56:27.956 [checkoutservice] failed to send order confirmation to "wilsonchristopher@example.com": rpc error: code = Internal desc = Failed to serialize response!  (×2)
  07:56:28.348 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"4590","nanos":30589162},"credit_card":{"credit_card_number":"47689647916719  (×4)
  07:56:28.363 [checkoutservice] failed to send order confirmation to "nealmichelle@example.org": rpc error: code = Internal desc = Failed to serialize response!
  07:56:29.169 [paymentservice] Transaction processed: visa ending 6182 Amount: GBP98.46104375  (×3)
  07:56:31.204 [checkoutservice] [PlaceOrder] user_id="adf41e5f-12f6-4c40-88a0-a1bcf421e416" user_currency="CAD"  (×2)
  07:56:31.239 [emailservice] A request to send order confirmation email to xrivera@example.com has been received.
  07:56:38.039 [emailservice] A request to send order confirmation email to uwilliams@example.net has been received.
  07:56:47.038 [emailservice] A request to send order confirmation email to david50@example.net has been received.
  07:56:49.861 [checkoutservice] failed to send order confirmation to "hubbardamanda@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:56:54.657 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', 'L9ECAV7KIM', '66VCHSJNUP']
  07:56:54.755 [paymentservice] Transaction processed: visa ending 2949 Amount: EUR1154.117647067  (×3)
  07:56:55.765 [emailservice] A request to send order confirmation email to courtneyreilly@example.net has been received.
  07:57:03.670 [checkoutservice] failed to send order confirmation to "larry83@example.com": rpc error: code = Internal desc = Failed to serialize response!
  07:57:05.304 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="USD"  (×2)
  07:57:05.335 [emailservice] A request to send order confirmation email to crosbylarry@example.net has been received.
  07:57:18.938 [checkoutservice] failed to send order confirmation to "emily09@example.net": rpc error: code = Internal desc = Failed to serialize response!
  07:57:23.746 [emailservice] A request to send order confirmation email to margaret86@example.com has been received.
  07:57:23.777 [checkoutservice] failed to send order confirmation to "derrick59@example.net": rpc error: code = Internal desc = Failed to serialize response!

## p0260
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:15.701Z
```
{"timestamp":1732242495701600300,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"{ id: '673fec3fb0df5c00019af986' }"}
```
Same service, the 2 minutes before (oldest first):
  02:28:14.147 [front-end] Posting Order: {"customer":"http://user/customers/673fec26b0df5c00019af932","address":"http://user/addresses/673fec2cb0df5c00019af94c","card":"http://user/cards
  02:28:14.181 [front-end] User cart deleted with status: 503
  02:28:14.185 [front-end] DELETE /cart 503 - ms - -
  02:28:14.190 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  02:28:14.191 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242494188,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:14.191 [front-end] Order response: {"timestamp":1732242494188,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:14.194 [front-end] POST /orders 500 - ms - -
  02:28:14.197 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  02:28:14.197 [front-end] POST to carts: http://carts/carts/673fec34b0df5c00019af967/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  02:28:14.238 [front-end] POST /cart 500 46.629 ms - 64
  02:28:14.311 [front-end] Posting Customer: {"username":"AIwPgMB","password":"ciKTe","email":"AIwPgMB@gmail.com","firstName":"AIwPgMB","lastName":"AIwPgMB"}
  02:28:14.317 [front-end] { id: '673fec3eb0df5c00019af985' }
  02:28:14.317 [front-end] 673fec3eb0df5c00019af985
  02:28:14.317 [front-end] Merging carts for customer id: 673fec3eb0df5c00019af985 and session id: y5_hKG3jcMa48JRLX0HxhdItvM_uuPGj
  02:28:14.337 [front-end] Carts merged.
  02:28:14.337 [front-end] set cookie673fec3eb0df5c00019af985
  02:28:14.337 [front-end] Sent cookies.
  02:28:14.339 [front-end] POST /register 200 27.005 ms - 33
  02:28:15.632 [front-end] GET /catalogue 200 - ms - -
  02:28:15.696 [front-end] Posting Customer: {"username":"NGQZYvsdKz","password":"rioCzg","email":"NGQZYvsdKz@gmail.com","firstName":"NGQZYvsdKz","lastName":"NGQZYvsdKz"}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×41)
  02:28:03.174 [front-end] User cart deleted with status: 503  (×41)
  02:28:03.202 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe  (×42)
  02:28:03.249 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×17)
  02:28:03.410 [front-end] Carts merged.  (×39)
  02:28:04.973 [front-end] Posting Customer: {"username":"HFHBXn","password":"EOgUhihln","email":"HFHBXn@gmail.com","firstName":"HFHBXn","lastName":"HFHBXn"}
  02:28:05.351 [user] ts=2024-11-22T02:28:05.351787827Z caller=middlewares.go:46 method=Register username=vuOxCKL email=vuOxCKL@gmail.com took=4.581531ms
  02:28:08.095 [front-end] Received response: "{\"firstName\":\"RsyjMQXEZqDOIBa\",\"lastName\":\"RsyjMQXEZqDOIBa\",\"username\":\"RsyjMQXEZqDOIBa\",\"id\":\"673fec1eb0df5c00019af912\",\"_
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:15.136 [carts] 2024-11-22 02:28:15.041 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 160.989 seconds (JVM running for 167.0
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:22.317 [front-end] Received response: "{\"firstName\":\"JGQXvUjPbFrtK\",\"lastName\":\"JGQXvUjPbFrtK\",\"username\":\"JGQXvUjPbFrtK\",\"id\":\"673fec34b0df5c00019af964\",\"_links\
  02:28:23.143 [orders] 2024-11-22 02:28:23.143 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×9)
  02:28:24.588 [shipping] Adding shipment to queue...  (×24)
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:26.156 [front-end] POST /cart 201 - ms - -  (×26)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d8","customerId":"673fec2cb0df5c00019af949","customer":{"id":null,"firstName":"KoWsmDtUqsE
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:30.547 [front-end] Received response: "{\"firstName\":\"vvgsHcY\",\"lastName\":\"vvgsHcY\",\"username\":\"vvgsHcY\",\"id\":\"673fec35b0df5c00019af968\",\"_links\":{\"addresses\":{
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.645 [queue-master] 2024-11-22 02:28:32.645 INFO 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×15)
  02:28:37.005 [user] ts=2024-11-22T02:28:37.005380807Z caller=middlewares.go:46 method=Register username=XTqSaA email=XTqSaA@gmail.com took=624.562µs
  02:28:40.136 [front-end] Order response: {"id":"673fec58d94b9000069b39dc","customerId":"673fec41b0df5c00019af98b","customer":{"id":null,"firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe",
  02:28:41.723 [user] ts=2024-11-22T02:28:41.723279742Z caller=middlewares.go:46 method=Register username=yaELjpCD email=yaELjpCD@gmail.com took=1.302265ms
  02:28:43.812 [front-end] Order response: {"id":"673fec5bd94b9000069b39e0","customerId":"673fec47b0df5c00019af996","customer":{"id":null,"firstName":"bhZuEQ","lastName":"bhZuEQ","usernam
  02:28:45.163 [front-end] Received response: "{\"firstName\":\"oqYeDriHaX\",\"lastName\":\"oqYeDriHaX\",\"username\":\"oqYeDriHaX\",\"id\":\"673fec49b0df5c00019af999\",\"_links\":{\"addr

## p0606
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-07T20:05:51.491Z
```
{"timestamp":1733601951491422700,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-67hjc","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 20:05:51.491  INFO 1 --- [io-11178-exec-8] route.controller.RouteController         : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04"}
```
Same service, the 2 minutes before (oldest first):
  20:05:46.416 [ts-route-service] 2024-12-07 20:05:46.416 INFO 1 --- [io-11178-exec-8] route.controller.RouteController : Route id: 084837bb-53c8-4438-87c8-0321a4d09917  (×18)
  20:05:47.560 [ts-route-service] 2024-12-07 20:05:47.559 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: f3d4d4ef-693b-4456-8eed-59c0d717dd08  (×2)
All services, 30 seconds either side (sampled):
  20:05:22.202 [ts-admin-basic-info-service] 2024-12-07 20:05:22.202 INFO 1 --- [io-18767-exec-4] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×15)
  20:05:24.166 [ts-basic-service] 2024-12-07 20:05:24.166 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×5)
  20:05:24.206 [ts-order-other-service] 2024-12-07 20:05:24.206 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×2)
  20:05:24.383 [ts-order-other-service] 2024-12-07 20:05:24.383 INFO 1 --- [io-12032-exec-2] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×10)
  20:05:24.667 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:05:24 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 200 119 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)  (×2)
  20:05:25.101 [ts-security-service] 2024-12-07 20:05:25.101 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....
  20:05:25.193 [ts-preserve-other-service] 2024-12-07 20:05:25.193 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Contacts By Id is] Getting....
  20:05:25.379 [ts-order-other-service] 2024-12-07 20:05:25.379 INFO 1 --- [io-12032-exec-4] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 49  (×8)
  20:05:25.748 [ts-travel2-service] 2024-12-07 20:05:25.748 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×9)
  20:05:25.809 [ts-order-other-service] 2024-12-07 20:05:25.809 INFO 1 --- [io-12032-exec-8] other.service.OrderOtherServiceImpl : [Order Other Service][Create Order] Ready Create Order
  20:05:26.152 [ts-auth-service] 2024-12-07 20:05:26.151 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
  20:05:26.447 [ts-travel-service] 2024-12-07 20:05:26.447 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×21)
  20:05:28.041 [ts-basic-service] 2024-12-07 20:05:28.041 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270  (×4)
  20:05:28.143 [ts-order-service] 2024-12-07 20:05:28.143 INFO 1 --- [io-12031-exec-2] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×19)
  20:05:28.305 [ts-price-mongo] {"t":{"$date":"2024-12-07T20:05:28.304+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360192
  20:05:28.344 [ts-basic-service] 2024-12-07 20:05:28.344 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : indexStart : 1 __ indexEnd : 2  (×4)
  20:05:30.799 [ts-station-mongo] {"t":{"$date":"2024-12-07T20:05:30.799+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360193
  20:05:31.703 [ts-user-mongo] {"t":{"$date":"2024-12-07T20:05:31.702+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360193
  20:05:34.007 [ts-order-service] 2024-12-07 20:05:34.007 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : Name List is: Response(status=1, msg=Success, data=[Nan Jing, Shang Hai Ho  (×4)
  20:05:34.722 [ts-seat-service] 2024-12-07 20:05:34.722 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  20:05:38.182 [ts-order-other-service] 2024-12-07 20:05:38.182 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Get Order By Id] Order Id: 353b7e60-d9a4-44e9
  20:05:42.909 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T20:05:42.908+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360194
  20:05:43.791 [ts-food-map-service] 2024-12-07 20:05:43.791 INFO 1 --- [io-18855-exec-7] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×3)
  20:05:51.723 [ts-basic-service] 2024-12-07 20:05:51.723 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×5)
  20:06:18.896 [ts-travel2-service] 2024-12-07 20:06:18.895 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  20:06:20.698 [ts-preserve-service] 2024-12-07 20:06:20.697 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Preserve Other Service][Check Security] Checking....
  20:06:20.783 [ts-preserve-service] 2024-12-07 20:06:20.783 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Contacts Id: b0f23465-83b1-4055-b110-ecd
  20:06:21.276 [ts-preserve-service] 2024-12-07 20:06:21.275 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 4] Do Order
  20:06:21.421 [ts-order-service] 2024-12-07 20:06:21.420 INFO 1 --- [io-12031-exec-9] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at 
  20:06:21.468 [ts-food-service] 2024-12-07 20:06:21.468 INFO 1 --- [io-18856-exec-1] foodsearch.controller.FoodController : [Food Service]Try to Create a FoodOrder!

## p0197
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service checkoutservice, 2024-11-18T06:53:53.004Z
```
{"timestamp":1731912833004617000,"container_name":"checkoutservice","pod_name":"checkoutservice-7ff8db989f-zrkdv","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"payment went through (transaction_id: 3b6ae679-cf08-458c-80a2-12ea74eebbfb)"}
```
Same service, the 2 minutes before (oldest first):
  06:53:04.102 [checkoutservice] order confirmation email sent to "patricia89@example.com"
  06:53:07.371 [checkoutservice] [PlaceOrder] user_id="acc735c5-72d0-48e6-b237-46a63eac4c4d" user_currency="TRY"  (×2)
  06:53:07.392 [checkoutservice] payment went through (transaction_id: d0438457-dba0-402a-a375-a043e883e993)  (×6)
  06:53:07.405 [checkoutservice] order confirmation email sent to "webersheila@example.org"
  06:53:13.301 [checkoutservice] order confirmation email sent to "mariarichardson@example.com"
  06:53:17.635 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="GBP"  (×3)
  06:53:17.671 [checkoutservice] order confirmation email sent to "pmack@example.net"
  06:53:26.931 [checkoutservice] order confirmation email sent to "john17@example.com"
  06:53:30.134 [checkoutservice] order confirmation email sent to "annponce@example.com"
  06:53:43.500 [checkoutservice] [PlaceOrder] user_id="c216dec4-2181-4773-8cc5-aa587ee59fcc" user_currency="JPY"
  06:53:43.546 [checkoutservice] order confirmation email sent to "danacampos@example.net"
  06:53:52.958 [checkoutservice] [PlaceOrder] user_id="418ce0b6-15a4-4228-a6cf-27e322509121" user_currency="USD"
All services, 30 seconds either side (sampled):
  06:53:23.371 [frontend] request started  (×328)
  06:53:23.380 [cartservice] GetCartAsync called with userId=b63bea0e-d05f-4589-be71-8fef43557432  (×271)
  06:53:23.403 [adservice] received ad request (context_words=[decor, home])  (×21)
  06:53:23.523 [frontend] adding to cart  (×35)
  06:53:23.559 [shippingservice] [GetQuote] received request  (×84)
  06:53:23.861 [frontend] ENV_PLATFORM is: aws  (×40)
  06:53:24.599 [adservice] received ad request (context_words=[accessories])  (×38)
  06:53:26.891 [frontend] placing order  (×13)
  06:53:26.916 [paymentservice] Transaction processed: visa ending 8332 Amount: GBP466.800750106  (×3)
  06:53:26.919 [shippingservice] [ShipOrder] completed request  (×13)
  06:53:26.931 [checkoutservice] order confirmation email sent to "john17@example.com"
  06:53:30.132 [emailservice] A request to send order confirmation email to annponce@example.com has been received.
  06:53:39.081 [adservice] received ad request (context_words=[footwear])  (×12)
  06:53:43.533 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"57937","nanos":153473087},"credit_card":{"credit_card_number":"436240858876  (×3)
  06:53:43.546 [checkoutservice] order confirmation email sent to "danacampos@example.net"
  06:53:53.000 [paymentservice] Transaction processed: visa ending 3265 Amount: USD1309.660000000  (×2)
  06:54:06.635 [emailservice] A request to send order confirmation email to stricklandmelissa@example.net has been received.
  06:54:06.912 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"394","nanos":745687759},"credit_card":{"credit_card_number":"49237152726698  (×2)
  06:54:06.927 [checkoutservice] order confirmation email sent to "bbenjamin@example.net"
  06:54:07.125 [paymentservice] Transaction processed: visa ending 0066 Amount: TRY7986.327080097  (×2)
  06:54:08.707 [emailservice] A request to send order confirmation email to jreed@example.net has been received.
  06:54:13.055 [checkoutservice] order confirmation email sent to "devon86@example.org"
  06:54:14.163 [paymentservice] Transaction processed: visa ending 8298 Amount: CAD88.265624061
  06:54:14.275 [emailservice] A request to send order confirmation email to ellisonann@example.org has been received.
  06:54:16.073 [checkoutservice] order confirmation email sent to "clarkgabriel@example.org"

## p0105
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:07:47.102Z
```
{"timestamp":1731906467102854400,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  05:07:46.464 [frontend] serving product page  (×5)
  05:07:46.501 [frontend] request complete  (×7)
  05:07:46.504 [frontend] request started  (×6)
  05:07:46.504 [frontend] adding to cart
  05:07:46.516 [frontend] view user cart
All services, 30 seconds either side (sampled):
  05:07:17.620 [frontend] request started  (×289)
  05:07:17.623 [currencyservice] Getting supported currencies...  (×241)
  05:07:17.633 [currencyservice] conversion request successful  (×709)
  05:07:17.652 [adservice] received ad request (context_words=[decor, home])  (×20)
  05:07:17.828 [frontend] home  (×36)
  05:07:17.884 [adservice] received ad request (context_words=[])  (×36)
  05:07:18.435 [frontend] view user cart  (×56)
  05:07:18.461 [shippingservice] [GetQuote] completed request  (×58)
  05:07:19.669 [adservice] received ad request (context_words=[accessories])  (×21)
  05:07:21.378 [frontend] adding to cart  (×23)
  05:07:21.404 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', '1YMWWN1N4O', '2ZYFJ3GM2N']  (×13)
  05:07:22.525 [frontend] placing order  (×2)
  05:07:22.558 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"1554","nanos":631161437},"credit_card":{"credit_card_number":"4174870612239
  05:07:22.562 [checkoutservice] payment went through (transaction_id: 91d4b46b-fc91-4021-8201-848625a7bc29)  (×2)
  05:07:22.563 [shippingservice] [ShipOrder] completed request  (×2)
  05:07:22.573 [emailservice] A request to send order confirmation email to jacksonthomas@example.org has been received.
  05:07:22.574 [frontend] order placed  (×2)
  05:07:30.871 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', '2ZYFJ3GM2N', '1YMWWN1N4O', '6E92ZMYYFZ']  (×4)
  05:07:49.725 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"3949","nanos":9356054},"credit_card":{"credit_card_number":"451854648735098
  05:07:49.739 [emailservice] A request to send order confirmation email to zhenry@example.net has been received.
  05:07:59.369 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', '1YMWWN1N4O']

## p0638
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-preserve-other-service, 2024-12-07T20:24:09.232Z
```
{"timestamp":1733603049232086000,"container_name":"ts-preserve-other-service","pod_name":"ts-preserve-other-service-7cf4c487d7-qmstq","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 20:24:09.231  INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl       : [Preserve Service][Step 5] Do not need to buy assurance"}
```
Same service, the 2 minutes before (oldest first):
  20:24:08.752 [ts-preserve-other-service] 2024-12-07 20:24:08.751 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security
  20:24:08.752 [ts-preserve-other-service] 2024-12-07 20:24:08.751 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Check Account Security] Checking....
  20:24:08.804 [ts-preserve-other-service] 2024-12-07 20:24:08.804 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security Complete. 
  20:24:08.804 [ts-preserve-other-service] 2024-12-07 20:24:08.804 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 2] Find contacts
  20:24:08.804 [ts-preserve-other-service] 2024-12-07 20:24:08.804 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 2] Contacts Id: b0f23465-83b1-4055-b110
  20:24:08.804 [ts-preserve-other-service] 2024-12-07 20:24:08.804 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Contacts By Id is] Getting....
  20:24:08.815 [ts-preserve-other-service] 2024-12-07 20:24:08.814 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Step 2] Complete
  20:24:08.815 [ts-preserve-other-service] 2024-12-07 20:24:08.815 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Check tickets num
  20:24:08.815 [ts-preserve-other-service] 2024-12-07 20:24:08.815 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] TripId: Z1234
  20:24:08.815 [ts-preserve-other-service] 2024-12-07 20:24:08.815 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting....
  20:24:09.115 [ts-preserve-other-service] 2024-12-07 20:24:09.115 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : TripAllDetail : TripAllDetail(status=false, message=null, tripResponse
  20:24:09.115 [ts-preserve-other-service] 2024-12-07 20:24:09.115 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : TripResponse : TripResponse(tripId=Z1234, startingStation=Shang Hai, t
  20:24:09.115 [ts-preserve-other-service] 2024-12-07 20:24:09.115 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 3] Tickets Enough
  20:24:09.115 [ts-preserve-other-service] 2024-12-07 20:24:09.115 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order
  20:24:09.115 [ts-preserve-other-service] 2024-12-07 20:24:09.115 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Station By Name]  (×2)
  20:24:09.178 [ts-preserve-other-service] 2024-12-07 20:24:09.178 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order] Order Travel Date: Sat Dec 07 00:00:00
  20:24:09.224 [ts-preserve-other-service] 2024-12-07 20:24:09.223 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order Price] Price is: 122.49999999999999
  20:24:09.224 [ts-preserve-other-service] 2024-12-07 20:24:09.223 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Contacts By Id] Creating....
  20:24:09.232 [ts-preserve-other-service] 2024-12-07 20:24:09.231 INFO 1 --- [io-14569-exec-7] p.service.PreserveOtherServiceImpl : [Preserve Other Service] [Step 4] Do Order Complete
All services, 30 seconds either side (sampled):
  20:23:41.297 [ts-auth-service] 2024-12-07 20:23:41.297 INFO 1 --- [io-12340-exec-7] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×5)
  20:23:41.513 [ts-travel-service] 2024-12-07 20:23:41.513 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×10)
  20:23:41.638 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:23:41 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×6)
  20:23:42.165 [ts-basic-service] 2024-12-07 20:23:42.165 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×27)
  20:23:42.191 [ts-order-other-service] 2024-12-07 20:23:42.191 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×3)
  20:23:42.245 [ts-travel2-service] 2024-12-07 20:23:42.245 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×44)
  20:23:42.329 [ts-seat-service] 2024-12-07 20:23:42.329 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×38)
  20:23:42.399 [ts-order-other-service] 2024-12-07 20:23:42.399 INFO 1 --- [io-12032-exec-1] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×19)
  20:23:43.269 [ts-auth-service] 2024-12-07 20:23:43.269 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID  (×3)
  20:23:44.963 [ts-consign-service] 2024-12-07 20:23:44.962 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : Order ID is :4dcbde92-d8e0-4326-893d-19eb61e90077
  20:23:54.055 [ts-order-other-service] 2024-12-07 20:23:54.054 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×21)
  20:23:56.470 [ts-inside-payment-service] 2024-12-07 20:23:56.469 INFO 1 --- [io-18673-exec-2] i.service.InsidePaymentServiceImpl : Out pay result: Response(status=1, msg=Pay Success, data=null)
  20:23:57.228 [ts-basic-service] 2024-12-07 20:23:57.227 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×10)
  20:23:57.348 [ts-travel-service] 2024-12-07 20:23:57.348 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr  (×12)
  20:23:57.503 [ts-travel-service] 2024-12-07 20:23:57.502 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×12)
  20:24:02.081 [ts-assurance-service] 2024-12-07 20:24:02.081 INFO 1 --- [io-18888-exec-3] a.controller.AssuranceController : [Assurances Service][Get Assurance Type]  (×2)
  20:24:02.118 [ts-security-service] 2024-12-07 20:24:02.118 INFO 1 --- [o-11188-exec-10] security.controller.SecurityController : [Security Service][Check Security] Check Account Id: 4d2a46c7-71cb
  20:24:02.148 [ts-preserve-other-service] 2024-12-07 20:24:02.147 INFO 1 --- [io-14569-exec-4] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security Complete.   (×2)
  20:24:02.160 [ts-preserve-other-service] 2024-12-07 20:24:02.160 INFO 1 --- [io-14569-exec-4] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting....  (×2)
  20:24:02.278 [ts-basic-service] 2024-12-07 20:24:02.277 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing
  20:24:02.574 [ts-preserve-other-service] 2024-12-07 20:24:02.574 INFO 1 --- [io-14569-exec-4] p.service.PreserveOtherServiceImpl : TripResponse : TripResponse(tripId=Z1234, startingStation=Shang Hai, t  (×2)
  20:24:02.682 [ts-seat-service] 2024-12-07 20:24:02.682 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService distributeSeat] Use a new seat number! 206004012  (×2)
  20:24:02.696 [ts-preserve-other-service] 2024-12-07 20:24:02.696 INFO 1 --- [io-14569-exec-4] p.service.PreserveOtherServiceImpl : [Preserve Service][Step 6] Do not need to buy food  (×2)
  20:24:05.894 [ts-auth-service] 2024-12-07 20:24:05.894 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×2)
  20:24:08.758 [ts-security-service] 2024-12-07 20:24:08.758 INFO 1 --- [io-11188-exec-2] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....
  20:24:13.867 [ts-order-mongo] {"t":{"$date":"2024-12-07T20:24:13.867+00:00"},"s":"W", "c":"COMMAND", "id":5578800, "ctx":"conn16","msg":"Deprecated operation requested. The client driver may
  20:24:15.337 [ts-travel-service] 2024-12-07 20:24:15.337 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  20:24:28.476 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-07T20:24:28.476+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360306
  20:24:31.279 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T20:24:31.279+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360307

## p0665
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice1, 2021-08-11T08:12:18.502Z
```
{"service":"webservice1","message":"2021-08-11 08:12:18,502 | INFO | 0.0.0.1 | 172.17.0.3 | webservice1 | d81b320d8745b891 | complete information: {'uuid': 'ca4185ee-fa38-11eb-b1ad-0242ac110003', 'user_id': 'sSHyNrVB'}"}
```
Same service, the 2 minutes before (oldest first):
  08:12:15.119 [webservice1] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×3)
  08:12:15.120 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×3)
  08:12:16.640 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  08:12:16.641 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  08:12:16.641 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'c93e51cc-fa38-11eb-a312-0242ac110003', 'value': '', 'ex': 10}  (×3)
  08:12:16.696 [webservice1] INFO uuid: c93e51cc-fa38-11eb-a312-0242ac110003 write redis successfully  (×3)
  08:12:16.802 [webservice1] INFO complete information: {'uuid': 'c93e51cc-fa38-11eb-a312-0242ac110003', 'user_id': 'TrtKhHmF'}  (×2)
All services, 30 seconds either side (sampled):
  08:11:48.509 [webservice1] INFO uuid: b8708752-fa38-11eb-a85c-0242ac110003 write redis successfully  (×48)
  08:11:48.730 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×36)
  08:11:48.845 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': 'b8708752-fa38-11eb-a85c-0242ac110003', 'user_id': 'IKAZGYCc'}  (×93)
  08:11:49.035 [redisservice1] INFO service accept, status_code: 200  (×44)
  08:11:49.471 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'b8ec9f4a-fa38-11eb-a2cb-0242ac110003'}  (×46)
  08:11:49.609 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×43)
  08:11:49.762 [redisservice1] INFO redis读取信息成功, status_code: 200  (×48)
  08:11:50.086 [webservice2] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×45)
  08:11:52.061 [dbservice1] INFO ba3db172-fa38-11eb-a6da-0242ac110003-fjEOpuqm-<9>^jfG#2%K@ token generate success token=MTYyODY0MDcxMi4wNjEyODkzOmJhM2RiMTcyLWZhMzgtMTFlYi1hNmRhLTAyNDJhYzE
  08:11:54.766 [dbservice1] INFO bbb4d512-fa38-11eb-876e-0242ac110003-ucXDZIio-})1EO<#nT*!K token generate success token=MTYyODY0MDcxNC43NjYwMjMyOmJiYjRkNTEyLWZhMzgtMTFlYi04NzZlLTAyNDJhYzE
  08:11:57.278 [dbservice2] INFO bd593f98-fa38-11eb-9f87-0242ac110003-TPLgkydZ-JzLaE1$ZSh<= token generate success token=MTYyODY0MDcxNy4yNzgxMDk2OmJkNTkzZjk4LWZhMzgtMTFlYi05Zjg3LTAyNDJhYzE
  08:12:00.043 [mobservice2] INFO info bf23f62e-fa38-11eb-877d-0242ac110004:PDUHwGKg write success
  08:12:02.516 [mobservice2] INFO info c09a1466-fa38-11eb-9c4d-0242ac110004:VvLhTogZ write success
  08:12:04.993 [mobservice2] INFO info c2187620-fa38-11eb-a9e4-0242ac110003:NptDIkKG write success
  08:12:07.592 [mobservice2] INFO info c3a30334-fa38-11eb-a217-0242ac110004:gZxMbovT write success
  08:12:10.154 [mobservice2] INFO info c533830e-fa38-11eb-8b52-0242ac110003:GYQsHOyA write success
  08:12:12.697 [mobservice2] INFO info c6a300fc-fa38-11eb-9b43-0242ac110003:yjlLtMmx write success
  08:12:15.547 [mobservice1] INFO info c85b83ec-fa38-11eb-a93a-0242ac110004:SDgLpeFn write success
  08:12:18.210 [dbservice2] INFO c9ba0830-fa38-11eb-801b-0242ac110003-ZnrSqIKU-6AR>9IyOXx/3 token generate success token=MTYyODY0MDczOC4yMDk2MDMzOmM5YmEwODMwLWZhMzgtMTFlYi04MDFiLTAyNDJhYzE
  08:12:21.145 [mobservice2] INFO info cbb5a338-fa38-11eb-aca1-0242ac110003:UOwaWosV write success
  08:12:23.781 [mobservice1] INFO info cd3e2108-fa38-11eb-99e9-0242ac110004:BGRWzCUk write success
  08:12:26.550 [dbservice1] INFO ceb52bbc-fa38-11eb-b141-0242ac110004-ldRtFqHz-bh}86eDVi=P+ token generate success token=MTYyODY0MDc0Ni41NDk2MTkyOmNlYjUyYmJjLWZhMzgtMTFlYi1iMTQxLTAyNDJhYzE
  08:12:29.314 [dbservice2] INFO d05cf198-fa38-11eb-b1d6-0242ac110004-jSevQlNq-y=u7{-jE?dDK token generate success token=MTYyODY0MDc0OS4zMTM5MTY6ZDA1Y2YxOTgtZmEzOC0xMWViLWIxZDYtMDI0MmFjMTE
  08:12:31.857 [dbservice2] INFO d1df7068-fa38-11eb-8995-0242ac110003-IAuXacwS-7@_}S6lBDAxp token generate success token=MTYyODY0MDc1MS44NTY2NzA0OmQxZGY3MDY4LWZhMzgtMTFlYi04OTk1LTAyNDJhYzE
  08:12:34.520 [dbservice1] INFO d3736718-fa38-11eb-b7a6-0242ac110003-gKUmCyre-YL:T*me_uhSJ token generate success token=MTYyODY0MDc1NC41MjAzMjgzOmQzNzM2NzE4LWZhMzgtMTFlYi1iN2E2LTAyNDJhYzE
  08:12:37.158 [dbservice1] INFO d505fffa-fa38-11eb-8d2f-0242ac110004-xgKipZPG-}vC$Ij:iYe.8 token generate success token=MTYyODY0MDc1Ny4xNTc2NjM2OmQ1MDVmZmZhLWZhMzgtMTFlYi04ZDJmLTAyNDJhYzE
  08:12:39.463 [dbservice1] INFO d6789532-fa38-11eb-96d1-0242ac110003-gKPfDFAT-9+We6@G>7w{K token generate success token=MTYyODY0MDc1OS40NjI4NDU4OmQ2Nzg5NTMyLWZhMzgtMTFlYi05NmQxLTAyNDJhYzE
  08:12:41.993 [dbservice2] INFO d7f1cd84-fa38-11eb-8c38-0242ac110003-ocwNidgD-vr7adT}&{R=! token generate success token=MTYyODY0MDc2MS45OTMxNzA1OmQ3ZjFjZDg0LWZhMzgtMTFlYi04YzM4LTAyNDJhYzE
  08:12:44.764 [dbservice1] INFO d9966672-fa38-11eb-8b78-0242ac110004-pKxfZBio-*wUb}zXdlquF token generate success token=MTYyODY0MDc2NC43NjQ1ODI5OmQ5OTY2NjcyLWZhMzgtMTFlYi04Yjc4LTAyNDJhYzE
  08:12:47.600 [dbservice2] INFO db46caac-fa38-11eb-82c6-0242ac110004-qepNbChc-fH.oSuxnyI{B token generate success token=MTYyODY0MDc2Ny41OTk1Mzc6ZGI0NmNhYWMtZmEzOC0xMWViLTgyYzYtMDI0MmFjMTE

## p0335
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:21:17.389Z
```
{"timestamp":1732245677389738200,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Order: {\"customer\":\"http://user/customers/673ff89db0df5c00019b1f52\",\"address\":\"http://user/addresses/673ff8a6b0df5c00019b1f79\",\"card\":\"http://user/cards/673ff8a6b0df5c00019b1f7a\",\"items\":\"http://carts/carts/673ff89db0df5c00019b1f52/items\"}"}
```
Same service, the 2 minutes before (oldest first):
  03:21:16.315 [front-end] Posting Order: {"customer":"http://user/customers/673ff891b0df5c00019b1f2a","address":"http://user/addresses/673ff89bb0df5c00019b1f4a","card":"http://user/cards
  03:21:16.418 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff8a4b0df5c00019b1f73"}  (×2)
  03:21:16.426 [front-end] POST /addresses 200 - ms - -  (×2)
  03:21:16.430 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff8a4b0df5c00019b1f73"}
  03:21:16.440 [front-end] POST /cards 200 - ms - -
  03:21:16.484 [front-end] Attempting to delete cart for user: 673ff8a4b0df5c00019b1f73
  03:21:16.993 [front-end] GET /catalogue 200 - ms - -
  03:21:17.300 [front-end] Posting Customer: {"username":"nzRGBLrbgctCr","password":"OAMJSzo","email":"nzRGBLrbgctCr@gmail.com","firstName":"nzRGBLrbgctCr","lastName":"nzRGBLrbgctCr"}
  03:21:17.306 [front-end] { id: '673ff8adb0df5c00019b1f95' }
  03:21:17.306 [front-end] 673ff8adb0df5c00019b1f95
  03:21:17.306 [front-end] Merging carts for customer id: 673ff8adb0df5c00019b1f95 and session id: aUgDmJNDzupnjsxZq7f2mWpnV3EvrTDz
  03:21:17.378 [front-end] Request received with body: {}
  03:21:17.383 [front-end] Received response: "{\"firstName\":\"isaznhmc\",\"lastName\":\"isaznhmc\",\"username\":\"isaznhmc\",\"id\":\"673ff89db0df5c00019b1f52\",\"_links\":{\"addresses\
  03:21:17.383 [front-end] GET Request to: http://user/customers/673ff89db0df5c00019b1f52/addresses  (×2)
  03:21:17.389 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff8a6b0df5c00019b1f7a\",\"_links\":{\"
  03:21:17.389 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:21:17.389 [front-end] [ undefined, undefined ]
All services, 30 seconds either side (sampled):
  03:20:47.390 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732245647387,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×23)
  03:20:47.759 [user] ts=2024-11-22T03:20:47.758527808Z caller=middlewares.go:104 method=GetAddresses id=673ff884b0df5c00019b1f0e result=1 took=1.207293ms  (×13)
  03:20:48.039 [front-end] Carts merged.  (×64)
  03:20:48.147 [front-end] DELETE /cart 503 - ms - -  (×60)
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr
  03:20:51.541 [front-end] Received response: "{\"firstName\":\"MKGIsEbVYi\",\"lastName\":\"MKGIsEbVYi\",\"username\":\"MKGIsEbVYi\",\"id\":\"673ff87eb0df5c00019b1eff\",\"_links\":{\"addr
  03:20:55.766 [front-end] Posting Customer: {"username":"PvCLeeg","password":"pTqmeIPqX","email":"PvCLeeg@gmail.com","firstName":"PvCLeeg","lastName":"PvCLeeg"}
  03:20:59.489 [carts] 2024-11-22 03:20:59.489 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.actu
  03:20:59.690 [carts] 2024-11-22 03:20:59.690 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/hal+  (×2)
  03:20:59.794 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×7)
  03:21:02.584 [front-end] Posting Customer: {"username":"UFhesIA","password":"rCvijGSfoG","email":"UFhesIA@gmail.com","firstName":"UFhesIA","lastName":"UFhesIA"}
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:21:04.427 [front-end] Posting Customer: {"username":"qklQL","password":"OfLCWzLJmr","email":"qklQL@gmail.com","firstName":"qklQL","lastName":"qklQL"}
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetected
  03:21:10.780 [front-end] Received response: "{\"firstName\":\"MGpVgwryvJC\",\"lastName\":\"MGpVgwryvJC\",\"username\":\"MGpVgwryvJC\",\"id\":\"673ff894b0df5c00019b1f32\",\"_links\":{\"a
  03:21:13.304 [front-end] Received response: "{\"firstName\":\"XYDErsNhuY\",\"lastName\":\"XYDErsNhuY\",\"username\":\"XYDErsNhuY\",\"id\":\"673ff88fb0df5c00019b1f26\",\"_links\":{\"addr
  03:21:15.893 [carts-db] {"t":{"$date":"2024-11-22T03:21:15.892+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:5832  (×17)
  03:21:18.289 [carts] 2024-11-22 03:21:18.289 INFO [carts,fb7913950d676f18,6e117eba14b3663e,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{reposi  (×24)
  03:21:18.613 [queue-master] 2024-11-22 03:21:18.613 ERROR 6 --- [ool-6-thread-44] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×24)
  03:21:18.904 [front-end] Order response: {"id":"673ff8aed94b9000069b4390","customerId":"673ff896b0df5c00019b1f3a","customer":{"id":null,"firstName":"aZnbBrPviPwcYcC","lastName":"aZnbBrP
  03:21:19.679 [front-end] Received response: "{\"firstName\":\"qklQL\",\"lastName\":\"qklQL\",\"username\":\"qklQL\",\"id\":\"673ff8a0b0df5c00019b1f61\",\"_links\":{\"addresses\":{\"href
  03:21:20.407 [front-end] Order response: {"id":"673ff8b0d94b9000069b4396","customerId":"673ff893b0df5c00019b1f31","customer":{"id":null,"firstName":"nPklGOsvzh","lastName":"nPklGOsvzh",
  03:21:22.641 [front-end] Received response: "{\"firstName\":\"TxflHMpaWteY\",\"lastName\":\"TxflHMpaWteY\",\"username\":\"TxflHMpaWteY\",\"id\":\"673ff898b0df5c00019b1f40\",\"_links\":{
  03:21:26.847 [front-end] Received response: "{\"firstName\":\"gxEQQKdgPqad\",\"lastName\":\"gxEQQKdgPqad\",\"username\":\"gxEQQKdgPqad\",\"id\":\"673ff89fb0df5c00019b1f5d\",\"_links\":{
  03:21:32.045 [front-end] Posting Customer: {"username":"tEhusfT","password":"HAHzo","email":"tEhusfT@gmail.com","firstName":"tEhusfT","lastName":"tEhusfT"}
  03:21:34.256 [front-end] Order response: {"id":"673ff8bed94b9000069b439f","customerId":"673ff8a8b0df5c00019b1f85","customer":{"id":null,"firstName":"yXmVwShR","lastName":"yXmVwShR","use
  03:21:36.220 [front-end] Received response: "{\"firstName\":\"IhtqcyEyd\",\"lastName\":\"IhtqcyEyd\",\"username\":\"IhtqcyEyd\",\"id\":\"673ff8a2b0df5c00019b1f6d\",\"_links\":{\"address
  03:21:38.509 [front-end] Received response: "{\"firstName\":\"jStfWCKVIxuZsZx\",\"lastName\":\"jStfWCKVIxuZsZx\",\"username\":\"jStfWCKVIxuZsZx\",\"id\":\"673ff8acb0df5c00019b1f92\",\"_
  03:21:42.179 [user] ts=2024-11-22T03:21:42.179090694Z caller=middlewares.go:46 method=Register username=aQnXDQax email=aQnXDQax@gmail.com took=1.031852ms
  03:21:44.661 [user] ts=2024-11-22T03:21:44.661227434Z caller=middlewares.go:46 method=Register username=uJQuaCc email=uJQuaCc@gmail.com took=988.72µs

## p0628
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-07T20:18:04.654Z
```
{"timestamp":1733602684654043400,"container_name":"ts-route-service","pod_name":"ts-route-service-6f78466fb7-9ll65","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:18:04.653  INFO 1 --- [           main] route.RouteApplication                   : Started RouteApplication in 44.111 seconds (JVM running for 61.482)"}
```
Same service, the 2 minutes before (oldest first):
  20:18:03.854 [ts-route-service] 2024-12-07 20:18:03.853 INFO 1 --- [ main] org.mongodb.driver.connection : Opened connection [connectionId{localValue:2, serverValue:25}] to ts-route-mongo:2701
  20:18:04.256 [ts-route-service] 2024-12-07 20:18:04.256 INFO 1 --- [ main] route.service.RouteServiceImpl : Modify success  (×10)
  20:18:04.256 [ts-route-service] 2024-12-07 20:18:04.256 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: nanjing End: beijing
  20:18:04.265 [ts-route-service] 2024-12-07 20:18:04.265 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: taiyuan End: shanghai
  20:18:04.273 [ts-route-service] 2024-12-07 20:18:04.273 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: shanghai End: taiyuan
  20:18:04.358 [ts-route-service] 2024-12-07 20:18:04.358 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: shanghaihongqiao End: hangzhou
  20:18:04.366 [ts-route-service] 2024-12-07 20:18:04.366 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: nanjing End: shanghai  (×3)
  20:18:04.554 [ts-route-service] 2024-12-07 20:18:04.554 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: suzhou End: shanghai
  20:18:04.564 [ts-route-service] 2024-12-07 20:18:04.563 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: shanghai End: suzhou
All services, 30 seconds either side (sampled):
  20:17:34.828 [ts-admin-basic-info-service] 2024-12-07 20:17:34.828 INFO 1 --- [io-18767-exec-8] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×13)
  20:17:35.686 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:35 +0800] "POST /api/v1/users/login HTTP/1.1" 200 380 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×22)
  20:17:36.137 [ts-order-service] 2024-12-07 20:17:36.137 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 78
  20:17:36.474 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:17:36 +0800] "POST /api/v1/inside_pay_service/inside_payment HTTP/1.1" 200 83 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)  (×2)
  20:17:37.568 [ts-route-service] 2024-12-07 20:17:37.568 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'objectPostProcessor' of type [org.springframework.security.config.an
  20:17:38.770 [ts-travel-service] 2024-12-07 20:17:38.770 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×2)
  20:17:42.177 [ts-route-service] 2024-12-07 20:17:42.176 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 16914 ms
  20:17:46.369 [ts-route-service] 2024-12-07 20:17:46.368 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-route-mongo:27017 to client view of cluster
  20:17:48.495 [ts-travel-service] 2024-12-07 20:17:48.495 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×2)
  20:17:51.172 [ts-route-service] 2024-12-07 20:17:51.171 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/configuration/ui]}" onto org.springframework.http.ResponseEntit
  20:17:52.761 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  20:17:52.765 [ts-route-service] 2024-12-07 20:17:52.765 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/vnd.spring-bo
  20:17:55.659 [ts-route-service] 2024-12-07 20:17:55.659 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class org.springfra
  20:18:00.972 [ts-route-service] 2024-12-07 20:18:00.972 INFO 1 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  20:18:03.461 [ts-route-service] 2024-12-07 20:18:03.461 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 11178 (http)
  20:18:08.456 [ts-route-service] 2024-12-07 20:18:08.456 INFO 1 --- [io-11178-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  20:18:10.355 [ts-travel-service] 2024-12-07 20:18:10.355 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×12)
  20:18:11.766 [ts-basic-service] 2024-12-07 20:18:11.766 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×2)
  20:18:11.820 [ts-order-other-service] 2024-12-07 20:18:11.820 INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×3)
  20:18:11.922 [ts-order-other-service] 2024-12-07 20:18:11.922 INFO 1 --- [io-12032-exec-3] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×8)
  20:18:12.011 [ts-travel2-service] 2024-12-07 20:18:12.010 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×7)
  20:18:15.187 [ts-order-other-service] 2024-12-07 20:18:15.187 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-
  20:18:21.328 [ts-order-other-service] 2024-12-07 20:18:21.328 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0
  20:18:22.761 [ts-travel-service] 2024-12-07 20:18:22.760 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×6)
  20:18:23.067 [ts-order-service] 2024-12-07 20:18:23.067 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×10)
  20:18:23.581 [ts-basic-service] 2024-12-07 20:18:23.581 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieT  (×2)
  20:18:28.497 [ts-config-mongo] {"t":{"$date":"2024-12-07T20:18:28.496+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360270
  20:18:31.608 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T20:18:31.608+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360271

## p0648
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice2, 2021-08-11T01:27:29.502Z
```
{"service":"redisservice2","message":"2021-08-11 01:27:29,502 | WARNING | 0.0.0.2 | redisservice2 | redis_helper.py -> get_value_from_redis -> 72 | dabc1eee9db2c3c7 | 用户未扫描，请等待！, status_code: 300"}
```
Same service, the 2 minutes before (oldest first):
  01:27:25.172 [redisservice2] INFO redis读取信息成功, status_code: 200  (×5)
  01:27:25.299 [redisservice2] INFO service accept, status_code: 200  (×5)
  01:27:25.633 [redisservice2] INFO redis write success  (×7)
  01:27:25.729 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×3)
All services, 30 seconds either side (sampled):
  01:26:59.508 [redisservice2] INFO redis读取信息成功, status_code: 200  (×45)
  01:26:59.642 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  01:26:59.928 [webservice1] INFO uuid: 2b50f696-fa00-11eb-b8ed-0242ac110003 write redis successfully  (×44)
  01:27:00.164 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '2b50f696-fa00-11eb-b8ed-0242ac110003', 'value': 'LGXUBrmd'}  (×41)
  01:27:00.410 [redisservice1] INFO redis读取信息成功, status_code: 200  (×38)
  01:27:00.645 [dbservice2] INFO query = select passwards from username_table where user_name='TlCqjeNt'  (×43)
  01:27:02.779 [mobservice2] INFO info 2cd724cc-fa00-11eb-aa07-0242ac110003:McTYFJZL write success
  01:27:03.177 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '2d199636-fa00-11eb-b1f5-0242ac110003', 'value': 'nSPeKIZU'}  (×42)
  01:27:03.390 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×39)
  01:27:05.904 [mobservice2] INFO info 2eb27e04-fa00-11eb-a75d-0242ac110004:ZcstOImC write success
  01:27:08.693 [mobservice1] INFO info 303fb926-fa00-11eb-96c6-0242ac110003:NmlBnobg write success
  01:27:14.620 [mobservice1] INFO info 33e2ad9a-fa00-11eb-a2c4-0242ac110004:XUtTqLre write success
  01:27:20.674 [dbservice2] INFO 373b9b64-fa00-11eb-b59e-0242ac110004-LmPAoyvh-Ay^K:tkP%L+m token generate success token=MTYyODYxNjQ0MC42NzQwODE6MzczYjliNjQtZmEwMC0xMWViLWI1OWUtMDI0MmFjMTE
  01:27:23.005 [dbservice2] INFO 38b8bfc6-fa00-11eb-80c5-0242ac110003-vpUgXqzC-iQ9Zu4A?U^<5 token generate success token=MTYyODYxNjQ0My4wMDUyOTg6MzhiOGJmYzYtZmEwMC0xMWViLTgwYzUtMDI0MmFjMTE
  01:27:25.388 [dbservice1] INFO 3a1bbba2-fa00-11eb-95bc-0242ac110004-CuYtcsiR-P{VU^&6hNk.i token generate success token=MTYyODYxNjQ0NS4zODc3ODUyOjNhMWJiYmEyLWZhMDAtMTFlYi05NWJjLTAyNDJhYzE
  01:27:27.715 [dbservice1] INFO 3b7e4cf8-fa00-11eb-95db-0242ac110004-GrKgOByV-n@*{TE_p^JR3 token generate success token=MTYyODYxNjQ0Ny43MTUzNjA0OjNiN2U0Y2Y4LWZhMDAtMTFlYi05NWRiLTAyNDJhYzE
  01:27:29.883 [dbservice2] INFO 3cd6dd36-fa00-11eb-b829-0242ac110003-yjlLtMmx-<?.ZdYVR2js- token generate success token=MTYyODYxNjQ0OS44ODMwMjA0OjNjZDZkZDM2LWZhMDAtMTFlYi1iODI5LTAyNDJhYzE
  01:27:32.944 [mobservice1] INFO info 3ec9a812-fa00-11eb-955c-0242ac110003:tLUwrBsD write success
  01:27:35.407 [mobservice1] INFO info 404ec99c-fa00-11eb-af19-0242ac110004:kmlOKZGI write success
  01:27:37.900 [dbservice1] INFO 41892604-fa00-11eb-ad42-0242ac110004-ZnrSqIKU-6AR>9IyOXx/3 token generate success token=MTYyODYxNjQ1Ny45MDAzNDI1OjQxODkyNjA0LWZhMDAtMTFlYi1hZDQyLTAyNDJhYzE
  01:27:40.900 [mobservice1] INFO info 43891428-fa00-11eb-b502-0242ac110004:IwBSEYcZ write success
  01:27:43.719 [dbservice2] INFO 44f8f27e-fa00-11eb-a7b4-0242ac110004-NXVPlvyB-(si6MhI%SkyT token generate success token=MTYyODYxNjQ2My43MTg3NTM6NDRmOGYyN2UtZmEwMC0xMWViLWE3YjQtMDI0MmFjMTE
  01:27:46.517 [dbservice2] INFO 46999566-fa00-11eb-8e6c-0242ac110004-dULDJpwo--J=t5_1H_3.l token generate success token=MTYyODYxNjQ2Ni41MTY4MzI2OjQ2OTk5NTY2LWZhMDAtMTFlYi04ZTZjLTAyNDJhYzE
  01:27:49.162 [mobservice2] INFO info 486d91e4-fa00-11eb-8403-0242ac110003:cdoHPZSl write success
  01:27:52.083 [mobservice2] INFO info 4a34be1c-fa00-11eb-9c1a-0242ac110003:saJCEzRp write success
  01:27:54.838 [mobservice2] INFO info 4bd0ab82-fa00-11eb-ab02-0242ac110003:SBgdrmlT write success
  01:27:57.406 [mobservice2] INFO info 4d6cd128-fa00-11eb-b777-0242ac110003:UlXetfSn write success

## p0396
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:27.485Z
```
{"timestamp":1732247187485157600,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"timestamp\":1732247187482,\"status\":500,\"error\":\"Internal Server Error\",\"exception\":\"java.lang.IllegalStateException\",\"message\":\"Unable to create order due to unspecified IO error.\",\"path\":\"/orders\"}"}
```
Same service, the 2 minutes before (oldest first):
  03:46:26.987 [front-end] set cookie673ffe92b0df5c00019b318f
  03:46:26.987 [front-end] Sent cookies.
  03:46:26.988 [front-end] POST /register 200 69.729 ms - 33
  03:46:26.994 [front-end] POST /cards 200 - ms - -
  03:46:27.039 [front-end] Attempting to delete cart for user: 673ffe88b0df5c00019b3174
  03:46:27.098 [front-end] User cart deleted with status: 503
  03:46:27.101 [front-end] DELETE /cart 503 - ms - -
  03:46:27.107 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  03:46:27.113 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  03:46:27.113 [front-end] POST to carts: http://carts/carts/673ffe88b0df5c00019b3174/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  03:46:27.170 [front-end] POST /cart 500 61.224 ms - 64
  03:46:27.454 [front-end] Request received with body: {}
  03:46:27.460 [front-end] Received response: "{\"firstName\":\"acXEVLvnjUxlkJf\",\"lastName\":\"acXEVLvnjUxlkJf\",\"username\":\"acXEVLvnjUxlkJf\",\"id\":\"673ffe79b0df5c00019b3143\",\"_
  03:46:27.460 [front-end] GET Request to: http://user/customers/673ffe79b0df5c00019b3143/addresses  (×2)
  03:46:27.466 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe83b0df5c00019b315d\",\"_links\":{\"
  03:46:27.466 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:46:27.466 [front-end] [ undefined, undefined ]
  03:46:27.466 [front-end] Posting Order: {"customer":"http://user/customers/673ffe79b0df5c00019b3143","address":"http://user/addresses/673ffe83b0df5c00019b315c","card":"http://user/cards
  03:46:27.485 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732247187482,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×27)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×45)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×60)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×48)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×47)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×46)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×46)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×46)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h
  03:46:57.285 [carts] 2024-11-22 03:46:57.285 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr

## p0114
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:14:54.771Z
```
{"timestamp":1731906894771491600,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"serving product page"}
```
Same service, the 2 minutes before (oldest first):
  05:14:53.553 [frontend] request started  (×7)
  05:14:53.553 [frontend] placing order
  05:14:53.605 [frontend] order placed
  05:14:53.629 [frontend] request complete  (×6)
  05:14:53.812 [frontend] serving product page  (×2)
  05:14:54.272 [frontend] adding to cart
  05:14:54.288 [frontend] view user cart  (×2)
All services, 30 seconds either side (sampled):
  05:14:25.103 [frontend] request started  (×322)
  05:14:25.107 [frontend] home  (×37)
  05:14:25.122 [currencyservice] conversion request successful  (×792)
  05:14:25.158 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', '9SIQT8TOJO', 'OLJCESPC7Z', '6E92ZMYYFZ', 'L9ECAV7KIM']  (×226)
  05:14:25.449 [adservice] received ad request (context_words=[footwear])  (×14)
  05:14:26.460 [shippingservice] [GetQuote] completed request  (×80)
  05:14:26.642 [cartservice] AddItemAsync called with userId=736a09b5-665e-4823-8520-b8602b0bdbff, productId=OLJCESPC7Z, quantity=7  (×35)
  05:14:29.261 [adservice] received ad request (context_words=[decor, home])  (×9)
  05:14:42.546 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"261","nanos":256081385},"credit_card":{"credit_card_number":"47478464233859  (×2)
  05:14:42.550 [shippingservice] [ShipOrder] received request  (×9)
  05:14:42.560 [emailservice] A request to send order confirmation email to dianaobrien@example.net has been received.
  05:14:43.523 [checkoutservice] [PlaceOrder] user_id="c216dec4-2181-4773-8cc5-aa587ee59fcc" user_currency="TRY"
  05:14:43.552 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', '6E92ZMYYFZ', '9SIQT8TOJO']
  05:14:43.650 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="GBP"  (×3)
  05:14:43.711 [emailservice] A request to send order confirmation email to joshuahenderson@example.com has been received.
  05:14:53.589 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"1861","nanos":714172491},"credit_card":{"credit_card_number":"4476090273543  (×2)
  05:14:53.604 [checkoutservice] order confirmation email sent to "kimberly02@example.net"
  05:15:02.368 [checkoutservice] order confirmation email sent to "beckyanderson@example.net"
  05:15:06.051 [checkoutservice] order confirmation email sent to "nicholas22@example.com"
  05:15:15.732 [checkoutservice] [PlaceOrder] user_id="adf41e5f-12f6-4c40-88a0-a1bcf421e416" user_currency="JPY"
  05:15:15.799 [emailservice] A request to send order confirmation email to ramirezcrystal@example.org has been received.
  05:15:22.652 [checkoutservice] order confirmation email sent to "jasonhansen@example.org"

## p0744
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service redis, 2024-11-23T12:58:56.101Z
```
{"timestamp":1732366736101497600,"container_name":"redis","pod_name":"redis-cart-c98b4b87b-wnnxt","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"33:C 23 Nov 2024 12:58:56.101 * Fork CoW for RDB: current 0 MB, peak 0 MB, average 0 MB"}
```
Same service, the 2 minutes before (oldest first):
  12:58:56.096 [redis] 1:M 23 Nov 2024 12:58:56.096 * 100 changes in 300 seconds. Saving...
  12:58:56.096 [redis] 1:M 23 Nov 2024 12:58:56.096 * Background saving started by pid 33
  12:58:56.101 [redis] 33:C 23 Nov 2024 12:58:56.101 * DB saved on disk
All services, 30 seconds either side (sampled):
  12:58:26.102 [currencyservice] conversion request successful  (×724)
  12:58:26.123 [frontend] request complete  (×308)
  12:58:26.266 [currencyservice] Getting supported currencies...  (×250)
  12:58:26.288 [shippingservice] [GetQuote] completed request  (×74)
  12:58:27.047 [frontend] adding to cart  (×31)
  12:58:27.284 [frontend] home  (×38)
  12:58:27.403 [adservice] received ad request (context_words=[hair, beauty])  (×16)
  12:58:31.330 [frontend] placing order  (×12)
  12:58:31.345 [paymentservice] Transaction processed: visa ending 7713 Amount: TRY146.115134010
  12:58:31.350 [shippingservice] [ShipOrder] completed request  (×12)
  12:58:31.360 [checkoutservice] order confirmation email sent to "karenbenton@example.com"
  12:58:31.765 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"298","nanos":814683775},"credit_card":{"credit_card_number":"41445836464278  (×3)
  12:58:31.780 [checkoutservice] order confirmation email sent to "boydjulie@example.com"
  12:58:39.475 [emailservice] A request to send order confirmation email to shannon68@example.com has been received.
  12:58:51.295 [checkoutservice] [PlaceOrder] user_id="48ab811e-292b-4e0c-aa9b-b8f85d1e86a4" user_currency="USD"  (×4)
  12:58:51.325 [emailservice] A request to send order confirmation email to nyoung@example.net has been received.
  12:58:51.491 [checkoutservice] order confirmation email sent to "tararose@example.com"
  12:58:54.620 [paymentservice] Transaction processed: visa ending 2488 Amount: CAD1022.80063684  (×2)
  12:58:56.096 [redis] 1:M 23 Nov 2024 12:58:56.096 * 100 changes in 300 seconds. Saving...
  12:58:56.197 [redis] 1:M 23 Nov 2024 12:58:56.197 * Background saving terminated with success
  12:59:08.359 [checkoutservice] [PlaceOrder] user_id="69da4256-dda1-4804-8ebf-4dca622316e6" user_currency="GBP"
  12:59:08.393 [emailservice] A request to send order confirmation email to franciselizabeth@example.net has been received.
  12:59:14.734 [checkoutservice] [PlaceOrder] user_id="6e17f999-1f44-47b4-93f0-534a09a0d813" user_currency="JPY"
  12:59:14.772 [emailservice] A request to send order confirmation email to rachelknight@example.org has been received.
  12:59:17.481 [checkoutservice] order confirmation email sent to "omedina@example.net"
  12:59:22.076 [emailservice] A request to send order confirmation email to kevinmcgrath@example.net has been received.

## p0641
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-07T20:25:17.968Z
```
{"timestamp":1733603117968367600,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-nsc8q","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:25:17.968  INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl             : [SeatService getLeftTicketOfInterval] The request seat type is economyClass and the total num is 2147483647"}
```
Same service, the 2 minutes before (oldest first):
  20:25:17.668 [ts-seat-service] 2024-12-07 20:25:17.668 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri
  20:25:17.697 [ts-seat-service] 2024-12-07 20:25:17.697 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×3)
  20:25:17.697 [ts-seat-service] 2024-12-07 20:25:17.697 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×3)
  20:25:17.709 [ts-seat-service] 2024-12-07 20:25:17.708 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes  (×3)
  20:25:17.717 [ts-seat-service] 2024-12-07 20:25:17.717 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×3)
  20:25:17.729 [ts-seat-service] 2024-12-07 20:25:17.729 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×3)
  20:25:17.729 [ts-seat-service] 2024-12-07 20:25:17.729 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
  20:25:17.734 [ts-seat-service] 2024-12-07 20:25:17.734 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×2)
  20:25:17.882 [ts-seat-service] 2024-12-07 20:25:17.882 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
All services, 30 seconds either side (sampled):
  20:24:47.969 [ts-route-service] 2024-12-07 20:24:47.968 INFO 1 --- [io-11178-exec-3] route.controller.RouteController : Route id: 20eb7122-3a11-423f-b10a-be0dc5bce7db  (×264)
  20:24:48.008 [ts-travel-service] 2024-12-07 20:24:48.008 INFO 1 --- [io-12346-exec-6] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×16)
  20:24:48.050 [ts-seat-service] 2024-12-07 20:24:48.050 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×44)
  20:24:49.019 [ts-route-service] 2024-12-07 20:24:49.018 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: f3d4d4ef-693b-4456-8eed-59c0d717dd08  (×30)
  20:24:53.455 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:24:53 +0800] "POST /api/v1/users/login HTTP/1.1" 200 380 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×22)
  20:24:53.542 [ts-basic-service] 2024-12-07 20:24:53.541 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×25)
  20:24:53.569 [ts-order-other-service] 2024-12-07 20:24:53.569 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 59  (×9)
  20:24:53.674 [ts-travel2-service] 2024-12-07 20:24:53.674 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×16)
  20:24:54.704 [ts-travel-service] 2024-12-07 20:24:54.704 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×67)
  20:24:57.107 [ts-order-other-service] 2024-12-07 20:24:57.107 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : Stations name list is : Response(status=1, msg=Success, data=[Shang H
  20:24:57.149 [ts-consign-service] 2024-12-07 20:24:57.148 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : SAVE consign result : ConsignRecord(id=22a09c8a-fee9-4e1d-ad28-d6f88cc  (×3)
  20:24:58.216 [ts-order-service] 2024-12-07 20:24:58.215 INFO 1 --- [io-12031-exec-2] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 79  (×12)
  20:24:58.405 [ts-seat-service] 2024-12-07 20:24:58.404 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×3)
  20:24:58.477 [ts-preserve-service] 2024-12-07 20:24:58.477 INFO 1 --- [io-14568-exec-4] preserve.controller.PreserveController : [Preserve Service][Preserve] Account order from Shang Hai -----> S  (×2)
  20:24:58.513 [ts-security-service] 2024-12-07 20:24:58.512 INFO 1 --- [io-11188-exec-8] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Last One Hour:  (×2)
  20:24:58.602 [ts-preserve-service] 2024-12-07 20:24:58.601 INFO 1 --- [io-14568-exec-4] preserve.service.PreserveServiceImpl : [Preserve Service][Step 2] Complete  (×2)
  20:24:58.804 [ts-travel-service] 2024-12-07 20:24:58.803 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×14)
  20:24:58.992 [ts-seat-service] 2024-12-07 20:24:58.992 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Left ticket info is : Response(status=1, msg=Success, data=LeftTicketInfo{so  (×2)
  20:24:59.023 [ts-order-service] 2024-12-07 20:24:59.023 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 22.5  (×2)
  20:24:59.060 [ts-food-service] 2024-12-07 20:24:59.059 INFO 1 --- [io-18856-exec-6] foodsearch.service.FoodServiceImpl : [Food-Service][AddFoodOrder] Success.  (×2)
  20:25:01.090 [ts-order-service] 2024-12-07 20:25:01.089 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Query Order][Step 1] Get Orders Number of Account: 83  (×2)
  20:25:05.506 [ts-travel2-service] 2024-12-07 20:25:05.506 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  20:25:10.881 [ts-basic-service] 2024-12-07 20:25:10.880 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef
  20:25:12.451 [ts-order-service] 2024-12-07 20:25:12.451 INFO 1 --- [io-12031-exec-7] order.service.OrderServiceImpl : Name List is: Response(status=1, msg=Success, data=[Nan Jing, Shang Hai Ho
  20:25:12.643 [ts-seat-service] 2024-12-07 20:25:12.643 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da  (×16)
  20:25:13.005 [ts-basic-service] 2024-12-07 20:25:13.005 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieT  (×2)
  20:25:17.743 [ts-travel-service] 2024-12-07 20:25:17.743 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×6)
  20:25:28.370 [ts-travel-mongo] {"t":{"$date":"2024-12-07T20:25:28.370+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360312
  20:25:31.313 [ts-consign-mongo] {"t":{"$date":"2024-12-07T20:25:31.312+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360313
  20:25:39.469 [ts-admin-travel-service] 2024-12-07 20:25:39.469 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)

## p0349
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:27:19.831Z
```
{"timestamp":1732246039831063300,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Attempting to add to cart: {\"id\":\"03fef6ac-1896-4ce8-bd69-b798f85c6e0b\",\"quantity\":1}"}
```
Same service, the 2 minutes before (oldest first):
  03:27:19.126 [front-end] GET /catalogue 200 - ms - -  (×2)
  03:27:19.427 [front-end] Request received with body: {}
  03:27:19.434 [front-end] Received response: "{\"firstName\":\"jLOLG\",\"lastName\":\"jLOLG\",\"username\":\"jLOLG\",\"id\":\"673ff9ffb0df5c00019b2387\",\"_links\":{\"addresses\":{\"href
  03:27:19.434 [front-end] GET Request to: http://user/customers/673ff9ffb0df5c00019b2387/addresses  (×2)
  03:27:19.441 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffa09b0df5c00019b23a6\",\"_links\":{\"
  03:27:19.441 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:27:19.441 [front-end] [ undefined, undefined ]
  03:27:19.441 [front-end] Posting Order: {"customer":"http://user/customers/673ff9ffb0df5c00019b2387","address":"http://user/addresses/673ffa09b0df5c00019b23a5","card":"http://user/cards
  03:27:19.473 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa17d94b9000069b44d1","customerId":"673ff9ffb0df5c00019b2387","customer":{"id":null,"firstName":"jLOLG","las
  03:27:19.473 [front-end] Order response: {"id":"673ffa17d94b9000069b44d1","customerId":"673ff9ffb0df5c00019b2387","customer":{"id":null,"firstName":"jLOLG","lastName":"jLOLG","username"
  03:27:19.476 [front-end] POST /orders 201 - ms - -
  03:27:19.694 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffa12b0df5c00019b23cc"}
  03:27:19.702 [front-end] POST /addresses 200 - ms - -
  03:27:19.750 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffa12b0df5c00019b23cc"}
  03:27:19.759 [front-end] POST /cards 200 - ms - -
  03:27:19.804 [front-end] Attempting to delete cart for user: 673ffa12b0df5c00019b23cc
  03:27:19.822 [front-end] User cart deleted with status: 202
  03:27:19.824 [front-end] DELETE /cart 202 - ms - -
All services, 30 seconds either side (sampled):
  03:26:49.843 [payment] ts=2024-11-22T03:26:49Z caller=logging.go:40 method=Health result=1 took=7.546µs  (×40)
  03:26:50.274 [user] ts=2024-11-22T03:26:50.274072523Z caller=middlewares.go:75 method=GetUsers id=673ff9e8b0df5c00019b234c result=1 took=1.028391ms  (×56)
  03:26:50.297 [front-end] Order response: {"id":"673ff9fad94b9000069b44ba","customerId":"673ff9e8b0df5c00019b234c","customer":{"id":null,"firstName":"yDRpxgSzGkP","lastName":"yDRpxgSzGkP
  03:26:50.694 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}  (×57)
  03:26:51.164 [carts] 2024-11-22 03:26:51.163 INFO [carts,4340fbb4966bd36a,3c2ef33764ce79e8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×28)
  03:26:51.482 [front-end] set cookie673ff9fbb0df5c00019b237f  (×60)
  03:26:52.250 [front-end] Order response: {"id":"673ff9fcd94b9000069b44bc","customerId":"673ff9ebb0df5c00019b2352","customer":{"id":null,"firstName":"PGvrpbeqbJK","lastName":"PGvrpbeqbJK
  03:26:53.871 [user] ts=2024-11-22T03:26:53.870789558Z caller=middlewares.go:46 method=Register username=MZNwuRjKqACeny email=MZNwuRjKqACeny@gmail.com took=979.308µs  (×15)
  03:26:54.370 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9fed94b9000069b44bf","customerId":"673ff9e5b0df5c00019b233f","customer":{"id":null,"firstName":"JCXypIK","l
  03:26:56.557 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×3)
  03:26:58.840 [payment] ts=2024-11-22T03:26:58Z caller=logging.go:29 method=Authorise result=false took=7.846µs  (×9)
  03:27:01.151 [front-end] Order response: {"id":"673ffa05d94b9000069b44c3","customerId":"673ff9f2b0df5c00019b236c","customer":{"id":null,"firstName":"WyENrdocEAUpElL","lastName":"WyENrdo
  03:27:03.129 [front-end] Posting Customer: {"username":"JrPqblRjlEzmDuN","password":"KIBVjymn","email":"JrPqblRjlEzmDuN@gmail.com","firstName":"JrPqblRjlEzmDuN","lastName":"JrPqblRjlEzm
  03:27:06.029 [front-end] Posting Customer: {"username":"OSOtNxlu","password":"UTkfcz","email":"OSOtNxlu@gmail.com","firstName":"OSOtNxlu","lastName":"OSOtNxlu"}
  03:27:10.620 [front-end] Received response: "{\"firstName\":\"bbYWewjvzoix\",\"lastName\":\"bbYWewjvzoix\",\"username\":\"bbYWewjvzoix\",\"id\":\"673ff9f6b0df5c00019b2375\",\"_links\":{
  03:27:12.330 [front-end] Order response: {"id":"673ffa10d94b9000069b44ca","customerId":"673ff9fdb0df5c00019b2382","customer":{"id":null,"firstName":"CyawXQaJ","lastName":"CyawXQaJ","use
  03:27:15.809 [front-end] Received response: "{\"firstName\":\"iIXcHccHLS\",\"lastName\":\"iIXcHccHLS\",\"username\":\"iIXcHccHLS\",\"id\":\"673ff9fdb0df5c00019b2385\",\"_links\":{\"addr
  03:27:17.661 [front-end] Received response: "{\"firstName\":\"kBTWAyi\",\"lastName\":\"kBTWAyi\",\"username\":\"kBTWAyi\",\"id\":\"673ff9fbb0df5c00019b237f\",\"_links\":{\"addresses\":{
  03:27:18.274 [user] ts=2024-11-22T03:27:18.27459785Z caller=middlewares.go:46 method=Register username=xcQJJmCn email=xcQJJmCn@gmail.com took=1.116186ms
  03:27:21.676 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa19d94b9000069b44d3","customerId":"673ffa05b0df5c00019b239a","customer":{"id":null,"firstName":"jLwainknX",
  03:27:22.671 [front-end] Received response: "{\"firstName\":\"advkZLgCiNjnvhN\",\"lastName\":\"advkZLgCiNjnvhN\",\"username\":\"advkZLgCiNjnvhN\",\"id\":\"673ffa05b0df5c00019b239b\",\"_
  03:27:24.374 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa1cd94b9000069b44d9","customerId":"673ffa07b0df5c00019b239e","customer":{"id":null,"firstName":"JrPqblRjlEz
  03:27:28.942 [front-end] Received response: "{\"firstName\":\"gtntOzXCF\",\"lastName\":\"gtntOzXCF\",\"username\":\"gtntOzXCF\",\"id\":\"673ffa0fb0df5c00019b23c1\",\"_links\":{\"address
  03:27:30.786 [user] ts=2024-11-22T03:27:30.786260404Z caller=middlewares.go:46 method=Register username=ACtrKB email=ACtrKB@gmail.com took=1.170248ms
  03:27:33.161 [front-end] Order response: {"id":"673ffa25d94b9000069b44e0","customerId":"673ffa12b0df5c00019b23cd","customer":{"id":null,"firstName":"UanScqGYLbDK","lastName":"UanScqGYLb
  03:27:36.383 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffa28d94b9000069b44e3","customerId":"673ffa19b0df5c00019b23e2","customer":{"id":null,"firstName":"nnaTmmb","l
  03:27:40.480 [front-end] Posting Customer: {"username":"HcUwYy","password":"DJQLI","email":"HcUwYy@gmail.com","firstName":"HcUwYy","lastName":"HcUwYy"}
  03:27:42.902 [front-end] Posting Customer: {"username":"bWHqBEcheSaGE","password":"kVFcIjA","email":"bWHqBEcheSaGE@gmail.com","firstName":"bWHqBEcheSaGE","lastName":"bWHqBEcheSaGE"}
  03:27:44.988 [front-end] Received response: "{\"firstName\":\"ACtrKB\",\"lastName\":\"ACtrKB\",\"username\":\"ACtrKB\",\"id\":\"673ffa22b0df5c00019b23f3\",\"_links\":{\"addresses\":{\"h
  03:27:49.811 [front-end] Posting Customer: {"username":"pcilM","password":"oBwpoxDq","email":"pcilM@gmail.com","firstName":"pcilM","lastName":"pcilM"}
