## p0334
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:21:17.383Z
```
{"timestamp":1732245677383379200,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"GET Request to: http://user/customers/673ff89db0df5c00019b1f52/cards"}
```
Same service, the 2 minutes before (oldest first):
  03:21:16.308 [front-end] GET Request to: http://user/customers/673ff891b0df5c00019b1f2a/cards  (×2)
  03:21:16.315 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff89bb0df5c00019b1f4b\",\"_links\":{\"
  03:21:16.315 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:21:16.315 [front-end] [ undefined, undefined ]
  03:21:16.315 [front-end] Posting Order: {"customer":"http://user/customers/673ff891b0df5c00019b1f2a","address":"http://user/addresses/673ff89bb0df5c00019b1f4a","card":"http://user/cards
  03:21:16.418 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff8a4b0df5c00019b1f73"}  (×2)
  03:21:16.426 [front-end] POST /addresses 200 - ms - -  (×2)
  03:21:16.430 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff8a4b0df5c00019b1f73"}
  03:21:16.440 [front-end] POST /cards 200 - ms - -
  03:21:16.484 [front-end] Attempting to delete cart for user: 673ff8a4b0df5c00019b1f73
  03:21:16.993 [front-end] GET /catalogue 200 - ms - -
  03:21:17.300 [front-end] Posting Customer: {"username":"nzRGBLrbgctCr","password":"OAMJSzo","email":"nzRGBLrbgctCr@gmail.com","firstName":"nzRGBLrbgctCr","lastName":"nzRGBLrbgctCr"}
  03:21:17.306 [front-end] { id: '673ff8adb0df5c00019b1f95' }
  03:21:17.306 [front-end] 673ff8adb0df5c00019b1f95
  03:21:17.306 [front-end] Merging carts for customer id: 673ff8adb0df5c00019b1f95 and session id: aUgDmJNDzupnjsxZq7f2mWpnV3EvrTDz
  03:21:17.378 [front-end] Request received with body: {}
  03:21:17.383 [front-end] Received response: "{\"firstName\":\"isaznhmc\",\"lastName\":\"isaznhmc\",\"username\":\"isaznhmc\",\"id\":\"673ff89db0df5c00019b1f52\",\"_links\":{\"addresses\
All services, 30 seconds either side (sampled):
  03:20:47.387 [orders] 2024-11-22 03:20:47.387 ERROR [orders,,,] 6 --- [p-nio-80-exec-8] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×13)
  03:20:47.751 [front-end] [ undefined, undefined ]  (×56)
  03:20:48.039 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff885b0df5c00019b1f10"}  (×60)
  03:20:48.147 [front-end] DELETE /cart 503 - ms - -  (×60)
  03:20:49.085 [carts] 2024-11-22 03:20:49.085 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr
  03:20:51.541 [front-end] Received response: "{\"firstName\":\"MKGIsEbVYi\",\"lastName\":\"MKGIsEbVYi\",\"username\":\"MKGIsEbVYi\",\"id\":\"673ff87eb0df5c00019b1eff\",\"_links\":{\"addr
  03:20:55.766 [front-end] Posting Customer: {"username":"PvCLeeg","password":"pTqmeIPqX","email":"PvCLeeg@gmail.com","firstName":"PvCLeeg","lastName":"PvCLeeg"}
  03:20:59.489 [carts] 2024-11-22 03:20:59.489 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.actu
  03:20:59.690 [carts] 2024-11-22 03:20:59.690 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/hal+  (×2)
  03:20:59.794 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×7)
  03:21:02.584 [front-end] Posting Customer: {"username":"UFhesIA","password":"rCvijGSfoG","email":"UFhesIA@gmail.com","firstName":"UFhesIA","lastName":"UFhesIA"}
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:21:04.427 [front-end] Posting Customer: {"username":"qklQL","password":"OfLCWzLJmr","email":"qklQL@gmail.com","firstName":"qklQL","lastName":"qklQL"}
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetected
  03:21:10.780 [front-end] Received response: "{\"firstName\":\"MGpVgwryvJC\",\"lastName\":\"MGpVgwryvJC\",\"username\":\"MGpVgwryvJC\",\"id\":\"673ff894b0df5c00019b1f32\",\"_links\":{\"a
  03:21:13.304 [front-end] Received response: "{\"firstName\":\"XYDErsNhuY\",\"lastName\":\"XYDErsNhuY\",\"username\":\"XYDErsNhuY\",\"id\":\"673ff88fb0df5c00019b1f26\",\"_links\":{\"addr
  03:21:15.893 [carts-db] {"t":{"$date":"2024-11-22T03:21:15.892+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:5832  (×17)
  03:21:18.289 [carts] 2024-11-22 03:21:18.289 INFO [carts,fb7913950d676f18,6e117eba14b3663e,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{reposi  (×24)
  03:21:18.613 [queue-master] 2024-11-22 03:21:18.613 ERROR 6 --- [ool-6-thread-44] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×24)
  03:21:18.904 [front-end] Order response: {"id":"673ff8aed94b9000069b4390","customerId":"673ff896b0df5c00019b1f3a","customer":{"id":null,"firstName":"aZnbBrPviPwcYcC","lastName":"aZnbBrP
  03:21:19.679 [front-end] Received response: "{\"firstName\":\"qklQL\",\"lastName\":\"qklQL\",\"username\":\"qklQL\",\"id\":\"673ff8a0b0df5c00019b1f61\",\"_links\":{\"addresses\":{\"href
  03:21:20.407 [front-end] Order response: {"id":"673ff8b0d94b9000069b4396","customerId":"673ff893b0df5c00019b1f31","customer":{"id":null,"firstName":"nPklGOsvzh","lastName":"nPklGOsvzh",
  03:21:22.641 [front-end] Received response: "{\"firstName\":\"TxflHMpaWteY\",\"lastName\":\"TxflHMpaWteY\",\"username\":\"TxflHMpaWteY\",\"id\":\"673ff898b0df5c00019b1f40\",\"_links\":{
  03:21:26.847 [front-end] Received response: "{\"firstName\":\"gxEQQKdgPqad\",\"lastName\":\"gxEQQKdgPqad\",\"username\":\"gxEQQKdgPqad\",\"id\":\"673ff89fb0df5c00019b1f5d\",\"_links\":{
  03:21:32.045 [front-end] Posting Customer: {"username":"tEhusfT","password":"HAHzo","email":"tEhusfT@gmail.com","firstName":"tEhusfT","lastName":"tEhusfT"}
  03:21:34.256 [front-end] Order response: {"id":"673ff8bed94b9000069b439f","customerId":"673ff8a8b0df5c00019b1f85","customer":{"id":null,"firstName":"yXmVwShR","lastName":"yXmVwShR","use
  03:21:36.220 [front-end] Received response: "{\"firstName\":\"IhtqcyEyd\",\"lastName\":\"IhtqcyEyd\",\"username\":\"IhtqcyEyd\",\"id\":\"673ff8a2b0df5c00019b1f6d\",\"_links\":{\"address
  03:21:38.509 [front-end] Received response: "{\"firstName\":\"jStfWCKVIxuZsZx\",\"lastName\":\"jStfWCKVIxuZsZx\",\"username\":\"jStfWCKVIxuZsZx\",\"id\":\"673ff8acb0df5c00019b1f92\",\"_
  03:21:42.179 [user] ts=2024-11-22T03:21:42.179090694Z caller=middlewares.go:46 method=Register username=aQnXDQax email=aQnXDQax@gmail.com took=1.031852ms
  03:21:44.661 [user] ts=2024-11-22T03:21:44.661227434Z caller=middlewares.go:46 method=Register username=uJQuaCc email=uJQuaCc@gmail.com took=988.72µs

## p0494
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:10:29.672Z
```
{"timestamp":1732353029672445400,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:10:29.672362444Z caller=middlewares.go:75 method=GetUsers id=67419bf0a437380001df0939 result=1 took=1.820736ms"}
```
Same service, the 2 minutes before (oldest first):
  09:10:24.874 [user] ts=2024-11-23T09:10:24.874535342Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419bfba437380001df0955 took=4.81969ms  (×3)
  09:10:24.890 [user] ts=2024-11-23T09:10:24.890639679Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419bfba437380001df0955 took=4.32519ms  (×3)
  09:10:25.848 [user] ts=2024-11-23T09:10:25.84883186Z caller=middlewares.go:157 method=Health result=2 took=1.914254ms  (×4)
  09:10:26.083 [user] ts=2024-11-23T09:10:26.083762596Z caller=middlewares.go:46 method=Register username=xKiPwI email=xKiPwI@gmail.com took=2.382499ms
  09:10:26.192 [user] ts=2024-11-23T09:10:26.192194051Z caller=middlewares.go:46 method=Register username=XhmTeQuHZAmulqG email=XhmTeQuHZAmulqG@gmail.com took=2.60413ms  (×2)
  09:10:27.907 [user] ts=2024-11-23T09:10:27.906998793Z caller=middlewares.go:46 method=Register username=XkVsXZdj email=XkVsXZdj@gmail.com took=2.051876ms
  09:10:28.269 [user] ts=2024-11-23T09:10:28.268812645Z caller=middlewares.go:46 method=Register username=iwOfMYXSl email=iwOfMYXSl@gmail.com took=1.834763ms
  09:10:28.726 [user] ts=2024-11-23T09:10:28.726262027Z caller=middlewares.go:75 method=GetUsers id=67419bf2a437380001df0942 result=1 took=2.314195ms  (×5)
All services, 30 seconds either side (sampled):
  09:09:59.674 [carts] 2024-11-23 09:09:59.674 INFO [carts,b26458144c6a64bf,47484185e6ff8df6,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×34)
  09:09:59.797 [front-end] POST /register 200 31.948 ms - 33  (×62)
  09:10:00.863 [front-end] Attempting to delete cart for user: 67419bdfa437380001df08fe  (×62)
  09:10:01.012 [front-end] Request received with body: {}  (×64)
  09:10:01.219 [front-end] Posting Customer: {"username":"DaesKhcrGFoJWqE","password":"bvVoQpg","email":"DaesKhcrGFoJWqE@gmail.com","firstName":"DaesKhcrGFoJWqE","lastName":"DaesKhcrGFoJW
  09:10:02.947 [front-end] Received response: "{\"firstName\":\"eOEUkSIZ\",\"lastName\":\"eOEUkSIZ\",\"username\":\"eOEUkSIZ\",\"id\":\"67419bcda437380001df08c1\",\"_links\":{\"addresses\
  09:10:06.927 [front-end] Received response: "{\"firstName\":\"eYZwSF\",\"lastName\":\"eYZwSF\",\"username\":\"eYZwSF\",\"id\":\"67419bd9a437380001df08e6\",\"_links\":{\"addresses\":{\"h
  09:10:10.416 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×7)
  09:10:12.122 [front-end] Posting Customer: {"username":"SLrgdKUbWHBo","password":"pkCOin","email":"SLrgdKUbWHBo@gmail.com","firstName":"SLrgdKUbWHBo","lastName":"SLrgdKUbWHBo"}
  09:10:15.452 [orders] 2024-11-23 09:10:15.452 INFO [orders,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.sp
  09:10:17.145 [front-end] Received response: "{\"firstName\":\"qktMZWTCCUAJkn\",\"lastName\":\"qktMZWTCCUAJkn\",\"username\":\"qktMZWTCCUAJkn\",\"id\":\"67419be3a437380001df090c\",\"_lin
  09:10:20.175 [front-end] Posting Customer: {"username":"MruDczovaR","password":"gIbFO","email":"MruDczovaR@gmail.com","firstName":"MruDczovaR","lastName":"MruDczovaR"}
  09:10:23.048 [orders] 2024-11-23 09:10:23.048 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[GET],produces=[application/x-s
  09:10:23.136 [orders] 2024-11-23 09:10:23.135 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[DELETE],produces=[applica
  09:10:23.141 [orders] 2024-11-23 09:10:23.141 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicat
  09:10:24.562 [front-end] Posting Customer: {"username":"weoLGLUsT","password":"mHEpVeM","email":"weoLGLUsT@gmail.com","firstName":"weoLGLUsT","lastName":"weoLGLUsT"}
  09:10:25.438 [orders] 2024-11-23 09:10:25.438 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=
  09:10:25.535 [orders] 2024-11-23 09:10:25.535 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[app
  09:10:28.732 [front-end] Received response: "{\"firstName\":\"hZzUAUPzUL\",\"lastName\":\"hZzUAUPzUL\",\"username\":\"hZzUAUPzUL\",\"id\":\"67419bf2a437380001df0942\",\"_links\":{\"addr
  09:10:29.841 [orders] 2024-11-23 09:10:29.841 INFO [orders,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as M
  09:10:32.758 [user] ts=2024-11-23T09:10:32.757847602Z caller=middlewares.go:46 method=Register username=kQEvN email=kQEvN@gmail.com took=2.526221ms
  09:10:34.444 [orders] Caused by: java.lang.IllegalArgumentException: Conflicting setter definitions for property "items": works.weave.socks.orders.entities.CustomerOrder#setItems(1 p  (×27)
  09:10:37.450 [front-end] Posting Customer: {"username":"XFeeVfI","password":"NkRMtoV","email":"XFeeVfI@gmail.com","firstName":"XFeeVfI","lastName":"XFeeVfI"}
  09:10:41.956 [front-end] Posting Customer: {"username":"JuJgbb","password":"nNXuPB","email":"JuJgbb@gmail.com","firstName":"JuJgbb","lastName":"JuJgbb"}
  09:10:45.531 [front-end] Posting Customer: {"username":"OwYYdiHSGi","password":"AhhCvWPpx","email":"OwYYdiHSGi@gmail.com","firstName":"OwYYdiHSGi","lastName":"OwYYdiHSGi"}
  09:10:49.259 [front-end] Posting Customer: {"username":"GSOQJLbPb","password":"tfEMUV","email":"GSOQJLbPb@gmail.com","firstName":"GSOQJLbPb","lastName":"GSOQJLbPb"}
  09:10:55.388 [front-end] Received response: "{\"firstName\":\"MWkDmiEWUqrxCG\",\"lastName\":\"MWkDmiEWUqrxCG\",\"username\":\"MWkDmiEWUqrxCG\",\"id\":\"67419c0ba437380001df0985\",\"_lin
  09:10:57.247 [front-end] Posting Customer: {"username":"ZtITZPSAjyw","password":"BydYgdg","email":"ZtITZPSAjyw@gmail.com","firstName":"ZtITZPSAjyw","lastName":"ZtITZPSAjyw"}

## p0747
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-23T13:05:03.685Z
```
{"timestamp":1732367103685266200,"container_name":"frontend","pod_name":"frontend-588fbcd66b-ssq9c","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  13:05:03.246 [frontend] failed to retrieve ads  (×4)
  13:05:03.246 [frontend] request complete  (×4)
  13:05:03.361 [frontend] request started  (×4)
  13:05:03.361 [frontend] setting currency
  13:05:03.364 [frontend] home
  13:05:03.369 [frontend] serving product page  (×2)
  13:05:03.398 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14  (×3)
  13:05:03.401 [frontend] ENV_PLATFORM is: aws
All services, 30 seconds either side (sampled):
  13:04:33.694 [shippingservice] [GetQuote] received request  (×70)
  13:04:33.703 [frontend] request complete  (×314)
  13:04:33.706 [currencyservice] Getting supported currencies...  (×256)
  13:04:34.191 [frontend] serving product page  (×150)
  13:04:34.280 [frontend] home  (×37)
  13:04:34.560 [adservice] received ad request (context_words=[kitchen])  (×18)
  13:04:34.773 [adservice] received ad request (context_words=[accessories])  (×10)
  13:04:37.271 [adservice] received ad request (context_words=[clothing, tops])  (×7)
  13:04:55.299 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 4  (×127)
  13:04:55.401 [frontend] failed to retrieve ads  (×127)
  13:04:59.000 [adservice] AdService starting.  (×3)
  13:05:00.399 [adservice] Exception in thread "main" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000 at io.grpc.netty.NettyServer.start(NettyServer.java:333) at io.g  (×3)
  13:05:02.976 [checkoutservice] [PlaceOrder] user_id="48ab811e-292b-4e0c-aa9b-b8f85d1e86a4" user_currency="TRY"  (×2)
  13:05:02.999 [checkoutservice] payment went through (transaction_id: 51ad5dda-2d21-4218-950c-88acc180168b)  (×7)
  13:05:03.003 [cartservice] EmptyCartAsync called with userId=48ab811e-292b-4e0c-aa9b-b8f85d1e86a4  (×7)
  13:05:03.011 [frontend] order placed  (×7)
  13:05:05.146 [paymentservice] Transaction processed: visa ending 2645 Amount: CAD122.964344974  (×4)
  13:05:07.129 [emailservice] A request to send order confirmation email to berryryan@example.net has been received.
  13:05:07.926 [checkoutservice] order confirmation email sent to "smithcrystal@example.org"
  13:05:11.548 [paymentservice] Transaction processed: visa ending 9095 Amount: JPY419266.731537048
  13:05:17.301 [emailservice] A request to send order confirmation email to hwhite@example.net has been received.
  13:05:26.942 [checkoutservice] order confirmation email sent to "perkinstimothy@example.com"

## p0510
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:40:51.084Z
```
{"timestamp":1732358451084346000,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"_embedded\\\":{\\\"card\\\":[{\\\"longNum\\\":\\\"123123321\\\",\\\"expires\\\":\\\"1232\\\",\\\"ccv\\\":\\\"123\\\",\\\"id\\\":\\\"6741b129a437380001df4a73\\\",\\\"_links\\\":{\\\"card\\\":{\\\"href\\\":\\\"http://user/cards/6741b129a437380001df4a73\\\"},\\\"self\\\":{\\\"href\\\":\\\"http://user/cards/6741b129a437380001df4a73\\\"}}}]}}\\n\""}
```
Same service, the 2 minutes before (oldest first):
  10:40:51.011 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b12aa437380001df4a77\",\"_links\":{\"
  10:40:51.011 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"6741b
  10:40:51.011 [front-end] [ undefined, undefined ]
  10:40:51.011 [front-end] Posting Order: {"customer":"http://user/customers/6741b123a437380001df4a67","address":"http://user/addresses/6741b12aa437380001df4a76","card":"http://user/cards
  10:40:51.011 [front-end] GET /catalogue 200 - ms - -
  10:40:51.050 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b12da437380001df4a7e"}
  10:40:51.057 [front-end] Request received with body: {}
  10:40:51.059 [front-end] POST /addresses 200 - ms - -
  10:40:51.062 [front-end] Order response: {"statusCode":503,"body":"upstream connect error or disconnect/reset before headers. retried and the latest reset reason: remote connection fail
  10:40:51.062 [front-end] Order response: "upstream connect error or disconnect/reset before headers. retried and the latest reset reason: remote connection failure, transport failure re
  10:40:51.063 [front-end] POST /orders 503 - ms - -
  10:40:51.070 [front-end] Received response: "{\"firstName\":\"VeudtRN\",\"lastName\":\"VeudtRN\",\"username\":\"VeudtRN\",\"id\":\"6741b11fa437380001df4a52\",\"_links\":{\"addresses\":{
  10:40:51.070 [front-end] GET Request to: http://user/customers/6741b11fa437380001df4a52/addresses  (×2)
All services, 30 seconds either side (sampled):
  10:40:51.001 [user] ts=2024-11-23T10:40:51.001253583Z caller=middlewares.go:75 method=GetUsers id=6741b123a437380001df4a67 result=1 took=2.561807ms  (×127)
  10:40:51.057 [front-end] Request received with body: {}  (×34)
  10:40:51.115 [front-end] POST /cards 200 - ms - -  (×33)
  10:40:51.243 [carts] 2024-11-23 10:40:51.243 INFO [carts,d2c2e6abee6853ca,7c11b7f04a005886,false] 7 --- [p-nio-80-exec-4] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×15)
  10:40:51.650 [carts] 2024-11-23 10:40:51.644 INFO [carts,ce28dad27a7f1e73,b550dd7d93e87a62,false] 7 --- [-nio-80-exec-11] w.w.s.cart.controllers.CartsController : Merge carts reques  (×20)
  10:40:52.715 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×4)
  10:40:54.042 [carts] 2024-11-23 10:40:54.042 INFO [carts,55279b5e8192e632,8c77ccf18a9ceab9,false] 7 --- [-nio-80-exec-16] w.w.s.cart.controllers.ItemsController : Did not find item.  (×18)
  10:40:55.439 [front-end] Posting Customer: {"username":"RWEKCzZbyoL","password":"eCgDEu","email":"RWEKCzZbyoL@gmail.com","firstName":"RWEKCzZbyoL","lastName":"RWEKCzZbyoL"}
  10:40:57.337 [orders] 2024-11-23 10:40:57.337 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+jso
  10:40:57.345 [orders] 2024-11-23 10:40:57.345 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PUT],produces=[applicatio
  10:40:57.435 [orders] 2024-11-23 10:40:57.435 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicat
  10:40:57.546 [orders] 2024-11-23 10:40:57.546 INFO [orders,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http
  10:40:58.821 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  10:40:59.450 [orders] 2024-11-23 10:40:59.450 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=
  10:40:59.540 [orders] 2024-11-23 10:40:59.540 INFO [orders,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[app
  10:41:02.850 [front-end] Posting Customer: {"username":"oljxrbkvgRPchx","password":"KICnrSMycj","email":"oljxrbkvgRPchx@gmail.com","firstName":"oljxrbkvgRPchx","lastName":"oljxrbkvgRPch
  10:41:04.149 [orders] 2024-11-23 10:41:04.149 INFO [orders,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering w
  10:41:06.939 [orders] 2024-11-23 10:41:06.843 INFO [orders,,,] 7 --- [p-nio-80-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization starte
  10:41:08.897 [front-end] Received response: "{\"firstName\":\"FoMnUsWRwtr\",\"lastName\":\"FoMnUsWRwtr\",\"username\":\"FoMnUsWRwtr\",\"id\":\"6741b133a437380001df4a8e\",\"_links\":{\"a
  10:41:09.781 [front-end] Posting Customer: {"username":"gzAwltOvrAOlwZ","password":"mvbfevmrG","email":"gzAwltOvrAOlwZ@gmail.com","firstName":"gzAwltOvrAOlwZ","lastName":"gzAwltOvrAOlwZ
  10:41:10.346 [queue-master] 2024-11-23 10:41:10.346 INFO 7 --- [ool-6-thread-24] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×18)
  10:41:10.951 [orders-db] {"t":{"$date":"2024-11-23T10:41:10.951+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:4145  (×10)
  10:41:11.658 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b14601dd390007094dcc","customerId":"6741b12ea437380001df4a7f","customer":{"id":null,"firstName":"vDSVmUfFkYR
  10:41:11.740 [front-end] Order response: {"id":"6741b14601dd390007094dcb","customerId":"6741b135a437380001df4a95","customer":{"id":null,"firstName":"oMOnLjzHZXUV","lastName":"oMOnLjzHZX
  10:41:11.746 [front-end] Order response: {"id":"6741b14601dd390007094dcd","customerId":"6741b133a437380001df4a8d","customer":{"id":null,"firstName":"PMMsVPkCBtB","lastName":"PMMsVPkCBtB
  10:41:13.508 [user] ts=2024-11-23T10:41:13.508595513Z caller=middlewares.go:46 method=Register username=AQxdn email=AQxdn@gmail.com took=2.184408ms
  10:41:15.043 [front-end] Order response: {"id":"6741b14a01dd390007094dd4","customerId":"6741b132a437380001df4a8a","customer":{"id":null,"firstName":"mfkgXqTHaTye","lastName":"mfkgXqTHaT
  10:41:17.757 [front-end] Received response: "{\"firstName\":\"RPAyWJFRkAtx\",\"lastName\":\"RPAyWJFRkAtx\",\"username\":\"RPAyWJFRkAtx\",\"id\":\"6741b138a437380001df4aa1\",\"_links\":{
  10:41:20.018 [front-end] Received response: "{\"firstName\":\"qqkRVDrhVVQ\",\"lastName\":\"qqkRVDrhVVQ\",\"username\":\"qqkRVDrhVVQ\",\"id\":\"6741b138a437380001df4aa2\",\"_links\":{\"a

## p0793
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-08T08:30:49.040Z
```
{"timestamp":1733646649040639500,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-f2x5m","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-08 08:30:49.040  INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl  : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50a90c90b04"}
```
Same service, the 2 minutes before (oldest first):
  08:30:48.748 [ts-basic-service] 2024-12-08 08:30:48.748 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87
  08:30:48.757 [ts-basic-service] 2024-12-08 08:30:48.757 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  08:30:48.758 [ts-basic-service] 2024-12-08 08:30:48.758 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23
  08:30:48.771 [ts-basic-service] 2024-12-08 08:30:48.771 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  08:30:48.772 [ts-basic-service] 2024-12-08 08:30:48.772 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×4)
  08:30:48.776 [ts-basic-service] 2024-12-08 08:30:48.776 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×5)
  08:30:48.779 [ts-basic-service] 2024-12-08 08:30:48.779 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing
  08:30:48.779 [ts-basic-service] 2024-12-08 08:30:48.779 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1
  08:30:48.779 [ts-basic-service] 2024-12-08 08:30:48.779 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4
  08:30:48.979 [ts-basic-service] 2024-12-08 08:30:48.979 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha
  08:30:49.024 [ts-basic-service] 2024-12-08 08:30:49.023 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
  08:30:49.028 [ts-basic-service] 2024-12-08 08:30:49.028 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  08:30:49.031 [ts-basic-service] 2024-12-08 08:30:49.031 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa
All services, 30 seconds either side (sampled):
  08:30:19.076 [ts-auth-service] 2024-12-08 08:30:19.075 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×3)
  08:30:19.137 [ts-basic-service] 2024-12-08 08:30:19.137 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×13)
  08:30:19.198 [ts-basic-service] 2024-12-08 08:30:19.198 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×7)
  08:30:19.285 [ts-seat-service] 2024-12-08 08:30:19.285 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×24)
  08:30:19.330 [ts-seat-service] 2024-12-08 08:30:19.329 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×12)
  08:30:19.578 [ts-travel2-service] 2024-12-08 08:30:19.577 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×20)
  08:30:19.887 [ts-preserve-other-service] 2024-12-08 08:30:19.887 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Verify Login] Success
  08:30:19.919 [ts-order-other-service] 2024-12-08 08:30:19.919 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Security Info Get]
  08:30:19.954 [ts-contacts-service] 2024-12-08 08:30:19.954 INFO 1 --- [io-12347-exec-1] contacts.controller.ContactsController : [ContactsService][VerifyLogin] Success.
  08:30:20.108 [ts-price-service] 2024-12-08 08:30:20.107 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×3)
  08:30:20.992 [ts-seat-service] 2024-12-08 08:30:20.992 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Left ticket info is : Response(status=1, msg=Success, data=LeftTicketInfo{so
  08:30:21.028 [ts-order-other-service] 2024-12-08 08:30:21.027 INFO 1 --- [io-12032-exec-9] other.service.OrderOtherServiceImpl : [Order Other Service][Order Create] Success.
  08:30:21.062 [ts-preserve-other-service] 2024-12-08 08:30:21.062 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Cancel Order Service][Get Order By Id]
  08:30:22.114 [ts-travel-service] 2024-12-08 08:30:22.114 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d  (×90)
  08:30:22.222 [ts-travel-service] 2024-12-08 08:30:22.222 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3  (×18)
  08:30:25.391 [ts-admin-basic-info-service] 2024-12-08 08:30:25.391 INFO 1 --- [io-18767-exec-9] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×15)
  08:30:26.779 [ts-seat-service] 2024-12-08 08:30:26.779 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  08:30:28.235 [ts-travel-service] 2024-12-08 08:30:28.235 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
  08:30:38.884 [ts-auth-service] 2024-12-08 08:30:38.883 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null
  08:30:47.538 [ts-order-service] 2024-12-08 08:30:47.538 INFO 1 --- [io-12031-exec-6] order.service.OrderServiceImpl : Name List is: Response(status=1, msg=Success, data=[Nan Jing, Shang Hai Ho
  08:30:51.631 [ts-travel-service] 2024-12-08 08:30:51.630 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Travel Service] Query TripResponse
  08:30:51.743 [ts-travel-service] 2024-12-08 08:30:51.743 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×3)
  08:30:51.968 [ts-travel-service] 2024-12-08 08:30:51.968 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:00:00 GMT 2013  (×6)
  08:30:52.542 [ts-seat-service] 2024-12-08 08:30:52.541 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da
  08:31:09.505 [ts-train-mongo] {"t":{"$date":"2024-12-08T08:31:09.504+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364666
  08:31:09.866 [ts-notification-mongo] {"t":{"$date":"2024-12-08T08:31:09.866+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364666
  08:31:10.687 [ts-basic-service] 2024-12-08 08:31:10.687 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  08:31:11.443 [ts-price-mongo] {"t":{"$date":"2024-12-08T08:31:11.442+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364667

## p0347
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:26:13.392Z
```
{"timestamp":1732245973392942000,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:26:13.392753478Z caller=middlewares.go:104 method=GetAddresses id=673ff9ccb0df5c00019b22f9 result=1 took=739.124µs"}
```
Same service, the 2 minutes before (oldest first):
  03:26:11.097 [user] ts=2024-11-22T03:26:11.097665789Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff9cab0df5c00019b22f2 took=1.761856ms
  03:26:11.370 [user] ts=2024-11-22T03:26:11.369820393Z caller=middlewares.go:46 method=Register username=XcvSPWHV email=XcvSPWHV@gmail.com took=1.061708ms
  03:26:12.056 [user] ts=2024-11-22T03:26:12.056011593Z caller=middlewares.go:46 method=Register username=DwMuq email=DwMuq@gmail.com took=998.936µs
  03:26:12.093 [user] ts=2024-11-22T03:26:12.093792943Z caller=middlewares.go:157 method=Health result=2 took=800.956µs
  03:26:12.094 [user] ts=2024-11-22T03:26:12.093998109Z caller=middlewares.go:157 method=Health result=2 took=1.005955ms
  03:26:12.238 [user] ts=2024-11-22T03:26:12.237925692Z caller=middlewares.go:75 method=GetUsers id=673ff9bfb0df5c00019b22d1 result=1 took=898.41µs  (×10)
  03:26:12.255 [user] ts=2024-11-22T03:26:12.254874961Z caller=middlewares.go:134 method=GetCards id=673ff9c6b0df5c00019b22ea result=1 took=859.556µs  (×2)
  03:26:12.255 [user] ts=2024-11-22T03:26:12.255072298Z caller=middlewares.go:104 method=GetAddresses id=673ff9c6b0df5c00019b22e8 result=1 took=897.06µs  (×2)
  03:26:13.377 [user] ts=2024-11-22T03:26:13.37746229Z caller=middlewares.go:75 method=GetUsers id=673ff9c3b0df5c00019b22e0 result=1 took=1.073496ms
All services, 30 seconds either side (sampled):
  03:25:43.406 [front-end] Attempting to delete cart for user: 673ff9b0b0df5c00019b2296  (×66)
  03:25:43.986 [front-end] GET /catalogue 200 - ms - -  (×59)
  03:25:44.375 [front-end] { id: '673ff9b8b0df5c00019b22b2' }  (×59)
  03:25:44.869 [front-end] Received response: "{\"firstName\":\"tpjRRKrkAy\",\"lastName\":\"tpjRRKrkAy\",\"username\":\"tpjRRKrkAy\",\"id\":\"673ff9a3b0df5c00019b226d\",\"_links\":{\"addr
  03:25:44.901 [queue-master] Received shipment task: 673ff9a3b0df5c00019b226d  (×59)
  03:25:45.099 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×5)
  03:25:46.115 [front-end] Received response: "{\"firstName\":\"NrEezuUqbtNb\",\"lastName\":\"NrEezuUqbtNb\",\"username\":\"NrEezuUqbtNb\",\"id\":\"673ff99eb0df5c00019b2264\",\"_links\":{
  03:25:46.970 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9bad94b9000069b447e","customerId":"673ff9a1b0df5c00019b226b","customer":{"id":null,"firstName":"UqiEOVKHeZI
  03:25:49.519 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×4)
  03:25:53.169 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9c1d94b9000069b4481","customerId":"673ff9afb0df5c00019b2295","customer":{"id":null,"firstName":"buHkRVtKiNV
  03:25:55.054 [front-end] Posting Customer: {"username":"fgwYPx","password":"GoqPj","email":"fgwYPx@gmail.com","firstName":"fgwYPx","lastName":"fgwYPx"}
  03:25:57.502 [front-end] Order response: {"id":"673ff9c5d94b9000069b4485","customerId":"673ff9b6b0df5c00019b22ac","customer":{"id":null,"firstName":"srZNODABzO","lastName":"srZNODABzO",
  03:25:58.529 [front-end] Posting Customer: {"username":"LJNDKHTUFzaG","password":"HSTcz","email":"LJNDKHTUFzaG@gmail.com","firstName":"LJNDKHTUFzaG","lastName":"LJNDKHTUFzaG"}
  03:26:01.505 [front-end] Received response: "{\"firstName\":\"PEjAqFOqapQ\",\"lastName\":\"PEjAqFOqapQ\",\"username\":\"PEjAqFOqapQ\",\"id\":\"673ff9b0b0df5c00019b2296\",\"_links\":{\"a
  03:26:02.043 [front-end] Posting Customer: {"username":"NDdGdkpxMdxFxES","password":"YqzwAmuN","email":"NDdGdkpxMdxFxES@gmail.com","firstName":"NDdGdkpxMdxFxES","lastName":"NDdGdkpxMdxF
  03:26:05.448 [front-end] Posting Customer: {"username":"XQCShlgHtGX","password":"PbuEMta","email":"XQCShlgHtGX@gmail.com","firstName":"XQCShlgHtGX","lastName":"XQCShlgHtGX"}
  03:26:08.113 [front-end] Order response: {"id":"673ff9d0d94b9000069b4494","customerId":"673ff9b9b0df5c00019b22b8","customer":{"id":null,"firstName":"RDVynAJmSRALu","lastName":"RDVynAJmS
  03:26:10.577 [front-end] Posting Customer: {"username":"hithHmB","password":"dvitDtN","email":"hithHmB@gmail.com","firstName":"hithHmB","lastName":"hithHmB"}
  03:26:13.381 [front-end] Received response: "{\"firstName\":\"eyTuKhbozb\",\"lastName\":\"eyTuKhbozb\",\"username\":\"eyTuKhbozb\",\"id\":\"673ff9c3b0df5c00019b22e0\",\"_links\":{\"addr
  03:26:15.552 [front-end] Order response: {"id":"673ff9d7d94b9000069b449b","customerId":"673ff9bcb0df5c00019b22c6","customer":{"id":null,"firstName":"CgCcq","lastName":"CgCcq","username"
  03:26:19.169 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9dbd94b9000069b449e","customerId":"673ff9c9b0df5c00019b22f1","customer":{"id":null,"firstName":"SDAdRBTG","
  03:26:20.413 [front-end] Posting Customer: {"username":"DGaHQIQYti","password":"uMJVAiG","email":"DGaHQIQYti@gmail.com","firstName":"DGaHQIQYti","lastName":"DGaHQIQYti"}
  03:26:24.749 [front-end] Posting Customer: {"username":"GITcg","password":"LJhXELR","email":"GITcg@gmail.com","firstName":"GITcg","lastName":"GITcg"}
  03:26:27.211 [front-end] Posting Customer: {"username":"sVUXhRNaV","password":"fEaitS","email":"sVUXhRNaV@gmail.com","firstName":"sVUXhRNaV","lastName":"sVUXhRNaV"}
  03:26:29.149 [front-end] Posting Customer: {"username":"rmkuBEoreHDHSf","password":"pAWMasMCq","email":"rmkuBEoreHDHSf@gmail.com","firstName":"rmkuBEoreHDHSf","lastName":"rmkuBEoreHDHSf
  03:26:31.365 [user] ts=2024-11-22T03:26:31.365570086Z caller=middlewares.go:46 method=Register username=xyjpVB email=xyjpVB@gmail.com took=1.055322ms
  03:26:33.315 [front-end] Order response: {"id":"673ff9e9d94b9000069b44ac","customerId":"673ff9d7b0df5c00019b231a","customer":{"id":null,"firstName":"joLLg","lastName":"joLLg","username"
  03:26:34.665 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9ead94b9000069b44af","customerId":"673ff9dfb0df5c00019b232e","customer":{"id":null,"firstName":"pwGqvq","la
  03:26:37.690 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9edd94b9000069b44b2","customerId":"673ff9d6b0df5c00019b2315","customer":{"id":null,"firstName":"BIQSaFmxLaz
  03:26:42.720 [front-end] Posting Customer: {"username":"WyENrdocEAUpElL","password":"LhGQgOmL","email":"WyENrdocEAUpElL@gmail.com","firstName":"WyENrdocEAUpElL","lastName":"WyENrdocEAUp

## p0459
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service queue-master, 2024-11-23T08:06:40.900Z
```
{"timestamp":1732349200900702700,"container_name":"queue-master","pod_name":"queue-master-7fd5784c78-zmfhr","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:40.900  WARN 7 --- [enerContainer-1] s.a.r.l.ConditionalRejectingErrorHandler : Execution of Rabbit message listener failed.\n"}
```
Same service, the 2 minutes before (oldest first):
  08:05:30.803 [queue-master] 2024-11-23 08:05:30.718 INFO 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0  (×2)
  08:05:32.624 [queue-master] 2024-11-23 08:05:32.623 INFO 7 --- [enerContainer-1] o.s.a.r.c.CachingConnectionFactory : Created new connection: SimpleConnection@53c83726 [delegate=amqp://gue
  08:05:32.625 [queue-master] 2024-11-23 08:05:32.625 INFO 7 --- [enerContainer-1] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-durable, auto-delete, or exclusive Queue (shipping-  (×2)
  08:05:33.423 [queue-master] 2024-11-23 08:05:33.417 INFO 7 --- [ main] s.a.ScheduledAnnotationBeanPostProcessor : No TaskScheduler/ScheduledExecutorService bean found for scheduled process
  08:05:34.107 [queue-master] 2024-11-23 08:05:34.106 INFO 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:05:34.299 [queue-master] 2024-11-23 08:05:34.299 INFO 7 --- [ main] w.w.s.q.QueueMasterApplication : Started QueueMasterApplication in 66.192 seconds (JVM running for 70.627)
  08:05:43.228 [queue-master] 2024-11-23 08:05:43.228 INFO 7 --- [p-nio-80-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  08:05:43.228 [queue-master] 2024-11-23 08:05:43.228 INFO 7 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization started
  08:05:43.320 [queue-master] 2024-11-23 08:05:43.319 INFO 7 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization completed in 91 ms
  08:06:35.505 [queue-master] Received shipment task: 67418cf2a437380001deec94
  08:06:40.816 [queue-master] 2024-11-23 08:06:40.815 INFO 7 --- [a-jaxrs-async-0] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×3)
  08:06:40.816 [queue-master] 2024-11-23 08:06:40.816 INFO 7 --- [a-jaxrs-async-0] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×3)
  08:06:40.821 [queue-master] 2024-11-23 08:06:40.821 ERROR 7 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  08:06:40.821 [queue-master] org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket-factory-20
All services, 30 seconds either side (sampled):
  08:06:11.523 [front-end] Posting Customer: {"username":"rxOPSacxRgokAg","password":"DczpYFJjq","email":"rxOPSacxRgokAg@gmail.com","firstName":"rxOPSacxRgokAg","lastName":"rxOPSacxRgokAg
  08:06:12.370 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418ce8a437380001deec7e\",\"_links\":{\"  (×61)
  08:06:12.820 [user] ts=2024-11-23T08:06:12.820404156Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418cefa437380001deec8f took=3.987487ms  (×57)
  08:06:13.368 [front-end] Posting Customer: {"username":"teNYQYg","password":"RSvopaezd","email":"teNYQYg@gmail.com","firstName":"teNYQYg","lastName":"teNYQYg"}
  08:06:14.400 [shipping] 2024-11-23 08:06:14.400 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX ser
  08:06:15.800 [carts] 2024-11-23 08:06:15.800 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[HEAD],produces=[applicatio
  08:06:15.811 [carts] 2024-11-23 08:06:15.811 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces=
  08:06:16.434 [front-end] Posting Customer: {"username":"GXUtAA","password":"OZQmnTELUP","email":"GXUtAA@gmail.com","firstName":"GXUtAA","lastName":"GXUtAA"}
  08:06:19.002 [carts] 2024-11-23 08:06:19.002 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  08:06:19.108 [carts] 2024-11-23 08:06:19.108 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/
  08:06:23.082 [carts-db] {"t":{"$date":"2024-11-23T08:06:23.081+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173234918
  08:06:25.334 [front-end] Received response: "{\"firstName\":\"JAEXlZGcwnm\",\"lastName\":\"JAEXlZGcwnm\",\"username\":\"JAEXlZGcwnm\",\"id\":\"67418cefa437380001deec8d\",\"_links\":{\"a
  08:06:27.201 [carts] 2024-11-23 08:06:27.200 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 119.694 seconds (JVM running for 124.0
  08:06:30.330 [front-end] Posting Customer: {"username":"pFbuHLdxmNq","password":"LQDNwOWSPu","email":"pFbuHLdxmNq@gmail.com","firstName":"pFbuHLdxmNq","lastName":"pFbuHLdxmNq"}
  08:06:32.257 [front-end] Received response: "{\"firstName\":\"zFhFddnpfqKhWz\",\"lastName\":\"zFhFddnpfqKhWz\",\"username\":\"zFhFddnpfqKhWz\",\"id\":\"67418cf1a437380001deec93\",\"_lin
  08:06:34.206 [carts-db] {"t":{"$date":"2024-11-23T08:06:34.206+00:00"},"s":"I", "c":"STORAGE", "id":20320, "ctx":"conn18","msg":"createCollection","attr":{"namespace":"data.item","uuid  (×4)
  08:06:35.457 [front-end] Posting Customer: {"username":"KarxuPo","password":"sUyEQyb","email":"KarxuPo@gmail.com","firstName":"KarxuPo","lastName":"KarxuPo"}
  08:06:36.202 [front-end] Order response: {"id":"67418d0b3f77060008864e3c","customerId":"67418cf3a437380001deec98","customer":{"id":null,"firstName":"rxOPSacxRgokAg","lastName":"rxOPSacx
  08:06:40.816 [queue-master] 2024-11-23 08:06:40.816 INFO 7 --- [a-jaxrs-async-0] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×3)
  08:06:41.833 [front-end] Order response: {"id":"67418d113f77060008864e43","customerId":"67418cf5a437380001deec9b","customer":{"id":null,"firstName":"teNYQYg","lastName":"teNYQYg","usern
  08:06:43.917 [queue-master] 2024-11-23 08:06:43.917 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×84)
  08:06:47.815 [front-end] Order response: {"id":"67418d173f77060008864e49","customerId":"67418cfba437380001deecae","customer":{"id":null,"firstName":"HsVUYJlBshmzPAV","lastName":"HsVUYJl
  08:06:49.640 [front-end] Received response: "{\"firstName\":\"QzQEpmSQXDM\",\"lastName\":\"QzQEpmSQXDM\",\"username\":\"QzQEpmSQXDM\",\"id\":\"67418d02a437380001deecc0\",\"_links\":{\"a
  08:06:52.690 [front-end] Order response: {"id":"67418d1c3f77060008864e52","customerId":"67418d05a437380001deecd0","customer":{"id":null,"firstName":"cuFLCUGugozmeyi","lastName":"cuFLCUG
  08:06:56.455 [front-end] Received response: "{\"firstName\":\"bUcof\",\"lastName\":\"bUcof\",\"username\":\"bUcof\",\"id\":\"67418d03a437380001deecc8\",\"_links\":{\"addresses\":{\"href
  08:06:59.900 [front-end] Posting Customer: {"username":"aRsDOnaJOXjmYPE","password":"HiLCbrdK","email":"aRsDOnaJOXjmYPE@gmail.com","firstName":"aRsDOnaJOXjmYPE","lastName":"aRsDOnaJOXjm
  08:07:01.540 [front-end] Received response: "{\"firstName\":\"Wnzho\",\"lastName\":\"Wnzho\",\"username\":\"Wnzho\",\"id\":\"67418d12a437380001deecfe\",\"_links\":{\"addresses\":{\"href
  08:07:03.856 [user] ts=2024-11-23T08:07:03.856646091Z caller=middlewares.go:46 method=Register username=DgQhwohJs email=DgQhwohJs@gmail.com took=2.640021ms
  08:07:10.245 [front-end] Posting Customer: {"username":"LWLynHPJvYC","password":"hLkYf","email":"LWLynHPJvYC@gmail.com","firstName":"LWLynHPJvYC","lastName":"LWLynHPJvYC"}

## p0297
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T02:41:00.732Z
```
{"timestamp":1732243260732125400,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T02:41:00.73200157Z caller=middlewares.go:75 method=GetUsers id=673fef2bb0df5c00019b026a result=1 took=717.144µs"}
```
Same service, the 2 minutes before (oldest first):
  02:40:56.961 [user] ts=2024-11-22T02:40:56.96143831Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673fef30b0df5c00019b0271 took=1.67812ms  (×6)
  02:40:57.017 [user] ts=2024-11-22T02:40:57.01716274Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673fef2fb0df5c00019b026f took=1.788927ms  (×5)
  02:40:57.095 [user] ts=2024-11-22T02:40:57.09418846Z caller=middlewares.go:157 method=Health result=2 took=1.041834ms  (×2)
  02:40:57.387 [user] ts=2024-11-22T02:40:57.387330489Z caller=middlewares.go:46 method=Register username=BQYURXKWgvBljTm email=BQYURXKWgvBljTm@gmail.com took=1.078646ms  (×2)
  02:40:58.886 [user] ts=2024-11-22T02:40:58.8860966Z caller=middlewares.go:46 method=Register username=gFwGSMD email=gFwGSMD@gmail.com took=1.062385ms
  02:41:00.093 [user] ts=2024-11-22T02:41:00.093244139Z caller=middlewares.go:157 method=Health result=2 took=888.224µs  (×2)
  02:41:00.726 [user] ts=2024-11-22T02:41:00.726334253Z caller=middlewares.go:75 method=GetUsers id=673fef2bb0df5c00019b026a result=1 took=956.67µs  (×2)
All services, 30 seconds either side (sampled):
  02:40:30.902 [front-end] Posting Customer: {"username":"JHQDyXvbjdMxuW","password":"SMhJMH","email":"JHQDyXvbjdMxuW@gmail.com","firstName":"JHQDyXvbjdMxuW","lastName":"JHQDyXvbjdMxuW"}
  02:40:30.968 [front-end] POST /register 200 63.053 ms - 33  (×57)
  02:40:31.515 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fef19b0df5c00019b0232"}  (×63)
  02:40:31.620 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×4)
  02:40:32.212 [front-end] GET Request to: http://user/customers/673fef07b0df5c00019b01fc/addresses  (×120)
  02:40:32.268 [orders] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×59)
  02:40:33.093 [user] ts=2024-11-22T02:40:33.092918484Z caller=middlewares.go:157 method=Health result=2 took=758.949µs  (×29)
  02:40:34.220 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×6)
  02:40:35.657 [front-end] Posting Customer: {"username":"PoBsjRafzrwcJ","password":"iXdlU","email":"PoBsjRafzrwcJ@gmail.com","firstName":"PoBsjRafzrwcJ","lastName":"PoBsjRafzrwcJ"}
  02:40:36.986 [carts] 2024-11-22 02:40:36.985 INFO [carts,,,] 7 --- [ main] ationConfigEmbeddedWebApplicationContext : Refreshing org.springframework.boot.context.embedded.Annotation
  02:40:43.213 [front-end] Received response: "{\"firstName\":\"HlMUNkzG\",\"lastName\":\"HlMUNkzG\",\"username\":\"HlMUNkzG\",\"id\":\"673fef13b0df5c00019b0229\",\"_links\":{\"addresses\
  02:40:47.469 [front-end] Received response: "{\"firstName\":\"QNeVMbVoBU\",\"lastName\":\"QNeVMbVoBU\",\"username\":\"QNeVMbVoBU\",\"id\":\"673fef1bb0df5c00019b0238\",\"_links\":{\"addr
  02:40:49.128 [front-end] Posting Customer: {"username":"JnQvyzuS","password":"bVkkM","email":"JnQvyzuS@gmail.com","firstName":"JnQvyzuS","lastName":"JnQvyzuS"}
  02:40:50.697 [front-end] Posting Customer: {"username":"ObRYPFONF","password":"Pnylzm","email":"ObRYPFONF@gmail.com","firstName":"ObRYPFONF","lastName":"ObRYPFONF"}
  02:40:51.930 [user] ts=2024-11-22T02:40:51.930562539Z caller=middlewares.go:46 method=Register username=EBwwAzPf email=EBwwAzPf@gmail.com took=974.586µs
  02:40:55.205 [front-end] Received response: "{\"firstName\":\"JHQDyXvbjdMxuW\",\"lastName\":\"JHQDyXvbjdMxuW\",\"username\":\"JHQDyXvbjdMxuW\",\"id\":\"673fef1eb0df5c00019b0241\",\"_lin
  02:40:56.608 [front-end] Received response: "{\"firstName\":\"NTVswfCZbJvd\",\"lastName\":\"NTVswfCZbJvd\",\"username\":\"NTVswfCZbJvd\",\"id\":\"673fef23b0df5c00019b024e\",\"_links\":{
  02:41:01.365 [front-end] Received response: "{\"firstName\":\"JMdLBsoR\",\"lastName\":\"JMdLBsoR\",\"username\":\"JMdLBsoR\",\"id\":\"673fef29b0df5c00019b0267\",\"_links\":{\"addresses\
  02:41:03.889 [carts] 2024-11-22 02:41:03.889 INFO [carts,,,] 7 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.cloud.sleuth.instrument.async.AsyncDe
  02:41:04.874 [front-end] Posting Customer: {"username":"WvsGOY","password":"FTbThg","email":"WvsGOY@gmail.com","firstName":"WvsGOY","lastName":"WvsGOY"}
  02:41:08.987 [carts] 2024-11-22 02:41:08.986 INFO [carts,,,] 7 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.cloud.sleuth.instrument.web.TraceWebA
  02:41:13.015 [front-end] Received response: "{\"firstName\":\"ObRYPFONF\",\"lastName\":\"ObRYPFONF\",\"username\":\"ObRYPFONF\",\"id\":\"673fef32b0df5c00019b027b\",\"_links\":{\"address
  02:41:15.938 [front-end] Posting Customer: {"username":"MBWYkClFaOz","password":"QvlaIlE","email":"MBWYkClFaOz@gmail.com","firstName":"MBWYkClFaOz","lastName":"MBWYkClFaOz"}
  02:41:16.895 [front-end] Received response: "{\"firstName\":\"akOijWxf\",\"lastName\":\"akOijWxf\",\"username\":\"akOijWxf\",\"id\":\"673fef33b0df5c00019b027d\",\"_links\":{\"addresses\
  02:41:19.432 [front-end] Posting Customer: {"username":"OMSOhS","password":"VQsuxSUDHw","email":"OMSOhS@gmail.com","firstName":"OMSOhS","lastName":"OMSOhS"}
  02:41:21.705 [front-end] Received response: "{\"firstName\":\"BQYURXKWgvBljTm\",\"lastName\":\"BQYURXKWgvBljTm\",\"username\":\"BQYURXKWgvBljTm\",\"id\":\"673fef39b0df5c00019b0294\",\"_
  02:41:24.643 [front-end] Received response: "{\"firstName\":\"XMZBSEB\",\"lastName\":\"XMZBSEB\",\"username\":\"XMZBSEB\",\"id\":\"673fef40b0df5c00019b02ab\",\"_links\":{\"addresses\":{
  02:41:27.690 [orders-db] {"t":{"$date":"2024-11-22T02:41:27.690+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224328

## p0212
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:40:18.958Z
```
{"timestamp":1731915618958103800,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  07:40:18.438 [frontend] request complete  (×7)
  07:40:18.441 [frontend] request started  (×6)
  07:40:18.441 [frontend] adding to cart
  07:40:18.452 [frontend] view user cart  (×2)
  07:40:18.506 [frontend] serving product page  (×2)
  07:40:18.507 [frontend] placing order
  07:40:18.571 [frontend] order placed
All services, 30 seconds either side (sampled):
  07:39:52.000 [cartservice] GetCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×264)
  07:39:52.024 [adservice] received ad request (context_words=[accessories])  (×35)
  07:39:52.029 [frontend] adding to cart  (×43)
  07:39:52.043 [currencyservice] Getting supported currencies...  (×263)
  07:39:52.283 [frontend] serving product page  (×150)
  07:39:52.973 [adservice] received ad request (context_words=[kitchen])  (×58)
  07:39:53.236 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"504","nanos":190000000},"credit_card":{"credit_card_number":"41250039999184  (×2)
  07:39:53.240 [shippingservice] [ShipOrder] received request  (×12)
  07:39:53.250 [emailservice] A request to send order confirmation email to thomas49@example.org has been received.
  07:39:54.637 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', 'L9ECAV7KIM', '66VCHSJNUP', '2ZYFJ3GM2N']  (×11)
  07:39:55.516 [adservice] received ad request (context_words=[])  (×29)
  07:39:59.923 [frontend] setting currency  (×18)
  07:40:02.310 [paymentservice] Transaction processed: visa ending 2430 Amount: EUR366.404245918  (×2)
  07:40:02.812 [emailservice] A request to send order confirmation email to calvinmoore@example.org has been received.
  07:40:03.039 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"97","nanos":410089340},"credit_card":{"credit_card_number":"442775504324461  (×2)
  07:40:03.052 [checkoutservice] order confirmation email sent to "christopherjackson@example.net"
  07:40:06.993 [paymentservice] Transaction processed: visa ending 4598 Amount: JPY13744.672269244  (×3)
  07:40:18.508 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="GBP"  (×2)
  07:40:18.568 [emailservice] A request to send order confirmation email to martin51@example.net has been received.
  07:40:24.448 [checkoutservice] order confirmation email sent to "stevenortiz@example.net"
  07:40:38.182 [emailservice] A request to send order confirmation email to uwashington@example.com has been received.
  07:40:40.769 [checkoutservice] order confirmation email sent to "barrettmichael@example.net"
  07:40:46.500 [emailservice] A request to send order confirmation email to stephen11@example.net has been received.
  07:40:47.470 [checkoutservice] order confirmation email sent to "floresnicole@example.net"

## p0395
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:27.170Z
```
{"timestamp":1732247187170175500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /cart 500 61.224 ms - 64"}
```
Same service, the 2 minutes before (oldest first):
  03:46:26.582 [front-end] Order response: {"timestamp":1732247186579,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:46:26.585 [front-end] POST /orders 500 - ms - -
  03:46:26.917 [front-end] Posting Customer: {"username":"SGNMlFJX","password":"XYhpJWT","email":"SGNMlFJX@gmail.com","firstName":"SGNMlFJX","lastName":"SGNMlFJX"}
  03:46:26.923 [front-end] { id: '673ffe92b0df5c00019b318f' }
  03:46:26.923 [front-end] 673ffe92b0df5c00019b318f
  03:46:26.923 [front-end] Merging carts for customer id: 673ffe92b0df5c00019b318f and session id: WBQmvmG8ZZ73Yt0J1h_a1KN42Tyi_nOi
  03:46:26.972 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ffe88b0df5c00019b3174"}
  03:46:26.981 [front-end] POST /addresses 200 - ms - -
  03:46:26.985 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffe88b0df5c00019b3174"}
  03:46:26.987 [front-end] Carts merged.
  03:46:26.987 [front-end] set cookie673ffe92b0df5c00019b318f
  03:46:26.987 [front-end] Sent cookies.
  03:46:26.988 [front-end] POST /register 200 69.729 ms - 33
  03:46:26.994 [front-end] POST /cards 200 - ms - -
  03:46:27.039 [front-end] Attempting to delete cart for user: 673ffe88b0df5c00019b3174
  03:46:27.098 [front-end] User cart deleted with status: 503
  03:46:27.101 [front-end] DELETE /cart 503 - ms - -
  03:46:27.107 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  03:46:27.113 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  03:46:27.113 [front-end] POST to carts: http://carts/carts/673ffe88b0df5c00019b3174/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×27)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×45)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×60)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×48)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×47)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×45)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×45)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×44)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h

## p0498
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:11:41.682Z
```
{"timestamp":1732353101682631000,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:11:41.682550859Z caller=middlewares.go:75 method=GetUsers id=67419c36a437380001df0a0b result=1 took=1.841391ms"}
```
Same service, the 2 minutes before (oldest first):
  09:11:39.791 [user] ts=2024-11-23T09:11:39.791799391Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419c41a437380001df0a36 took=4.016655ms  (×5)
  09:11:39.807 [user] ts=2024-11-23T09:11:39.806796356Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419c41a437380001df0a36 took=3.970939ms  (×5)
  09:11:39.934 [user] ts=2024-11-23T09:11:39.934696127Z caller=middlewares.go:75 method=GetUsers id=67419c3aa437380001df0a19 result=1 took=2.208543ms  (×7)
  09:11:39.986 [user] ts=2024-11-23T09:11:39.986281624Z caller=middlewares.go:46 method=Register username=cukgCZcrwar email=cukgCZcrwar@gmail.com took=2.646924ms
  09:11:40.849 [user] ts=2024-11-23T09:11:40.84955361Z caller=middlewares.go:157 method=Health result=2 took=2.406297ms  (×2)
All services, 30 seconds either side (sampled):
  09:11:11.781 [front-end] Request received with body: {}  (×62)
  09:11:11.816 [orders] 2024-11-23 09:11:11.815 ERROR [orders,29673b23d0a77904,b8e13c3ad0ab5ce7,false] 7 --- [p-nio-80-exec-4] o.s.d.r.w.RepositoryRestExceptionHandler : Could not read  (×57)
  09:11:11.831 [user] ts=2024-11-23T09:11:11.830955212Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419c25a437380001df09dd took=4.49905ms  (×60)
  09:11:11.923 [front-end] Attempting to add to cart: {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","quantity":1}  (×60)
  09:11:12.451 [front-end] Received response: "{\"firstName\":\"rebXy\",\"lastName\":\"rebXy\",\"username\":\"rebXy\",\"id\":\"67419c20a437380001df09cd\",\"_links\":{\"addresses\":{\"href
  09:11:13.208 [front-end] Merging carts for customer id: 67419c31a437380001df09ff and session id: a5M015NkRrt3jkJ4g7F8NvyoPzSq9BnT  (×62)
  09:11:13.444 [carts] 2024-11-23 09:11:13.444 INFO [carts,f7d7cca37ce1a046,5b0a21e3567c1d43,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.CartsController : Merge carts reques  (×30)
  09:11:16.485 [front-end] Received response: "{\"firstName\":\"HASCG\",\"lastName\":\"HASCG\",\"username\":\"HASCG\",\"id\":\"67419c26a437380001df09e0\",\"_links\":{\"addresses\":{\"href
  09:11:17.897 [front-end] Received response: "{\"firstName\":\"mryGvonx\",\"lastName\":\"mryGvonx\",\"username\":\"mryGvonx\",\"id\":\"67419c20a437380001df09cf\",\"_links\":{\"addresses\
  09:11:19.002 [front-end] Received response: "{\"firstName\":\"xLzIv\",\"lastName\":\"xLzIv\",\"username\":\"xLzIv\",\"id\":\"67419c25a437380001df09dd\",\"_links\":{\"addresses\":{\"href
  09:11:21.227 [user] ts=2024-11-23T09:11:21.226973721Z caller=middlewares.go:46 method=Register username=JVtYXBYH email=JVtYXBYH@gmail.com took=1.687004ms
  09:11:24.768 [orders-db] {"t":{"$date":"2024-11-23T09:11:24.767+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235308
  09:11:26.698 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×6)
  09:11:27.932 [front-end] Received response: "{\"firstName\":\"LgUTGapEXRLJpb\",\"lastName\":\"LgUTGapEXRLJpb\",\"username\":\"LgUTGapEXRLJpb\",\"id\":\"67419c2ba437380001df09ed\",\"_lin
  09:11:30.986 [front-end] Received response: "{\"firstName\":\"oRrNigKgvxGvvj\",\"lastName\":\"oRrNigKgvxGvvj\",\"username\":\"oRrNigKgvxGvvj\",\"id\":\"67419c28a437380001df09e8\",\"_lin
  09:11:32.599 [front-end] Posting Customer: {"username":"lhgmiffJeDsEQsr","password":"ZYmjc","email":"lhgmiffJeDsEQsr@gmail.com","firstName":"lhgmiffJeDsEQsr","lastName":"lhgmiffJeDsEQsr
  09:11:34.762 [front-end] Received response: "{\"firstName\":\"ChywMOlVcmclv\",\"lastName\":\"ChywMOlVcmclv\",\"username\":\"ChywMOlVcmclv\",\"id\":\"67419c35a437380001df0a04\",\"_links\
  09:11:38.853 [front-end] Posting Customer: {"username":"CEoQrTAJXAByo","password":"GWzYYFX","email":"CEoQrTAJXAByo@gmail.com","firstName":"CEoQrTAJXAByo","lastName":"CEoQrTAJXAByo"}
  09:11:41.864 [front-end] Received response: "{\"firstName\":\"SSYKGYpAizXru\",\"lastName\":\"SSYKGYpAizXru\",\"username\":\"SSYKGYpAizXru\",\"id\":\"67419c38a437380001df0a12\",\"_links\
  09:11:45.603 [front-end] Received response: "{\"firstName\":\"NgoFsrlxTCHsua\",\"lastName\":\"NgoFsrlxTCHsua\",\"username\":\"NgoFsrlxTCHsua\",\"id\":\"67419c3da437380001df0a21\",\"_lin
  09:11:47.739 [front-end] Received response: "{\"firstName\":\"uJUSIJZmGwWu\",\"lastName\":\"uJUSIJZmGwWu\",\"username\":\"uJUSIJZmGwWu\",\"id\":\"67419c42a437380001df0a3d\",\"_links\":{
  09:11:51.850 [front-end] Received response: "{\"firstName\":\"tbYEfOv\",\"lastName\":\"tbYEfOv\",\"username\":\"tbYEfOv\",\"id\":\"67419c3fa437380001df0a2c\",\"_links\":{\"addresses\":{
  09:11:54.197 [front-end] Posting Customer: {"username":"ozfgYZdwdGz","password":"MFWKTrRp","email":"ozfgYZdwdGz@gmail.com","firstName":"ozfgYZdwdGz","lastName":"ozfgYZdwdGz"}
  09:11:58.961 [front-end] Received response: "{\"firstName\":\"JMbeJLQj\",\"lastName\":\"JMbeJLQj\",\"username\":\"JMbeJLQj\",\"id\":\"67419c41a437380001df0a36\",\"_links\":{\"addresses\
  09:12:00.203 [front-end] Received response: "{\"firstName\":\"yrWFnsmFSR\",\"lastName\":\"yrWFnsmFSR\",\"username\":\"yrWFnsmFSR\",\"id\":\"67419c48a437380001df0a4c\",\"_links\":{\"addr
  09:12:06.855 [front-end] Posting Customer: {"username":"DdxFTBitBjaGGL","password":"orFpbqqk","email":"DdxFTBitBjaGGL@gmail.com","firstName":"DdxFTBitBjaGGL","lastName":"DdxFTBitBjaGGL"
  09:12:08.767 [front-end] Received response: "{\"firstName\":\"HjlyVM\",\"lastName\":\"HjlyVM\",\"username\":\"HjlyVM\",\"id\":\"67419c56a437380001df0a73\",\"_links\":{\"addresses\":{\"h
  09:12:11.511 [front-end] Received response: "{\"firstName\":\"MRcMjY\",\"lastName\":\"MRcMjY\",\"username\":\"MRcMjY\",\"id\":\"67419c51a437380001df0a66\",\"_links\":{\"addresses\":{\"h

## p0434
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-23T08:05:49.486Z
```
{"timestamp":1732349149486445600,"container_name":"orders","pod_name":"orders-7fff6698cb-rlq5k","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-23 08:05:49.394 ERROR [orders,,,] 8 --- [p-nio-80-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalStateException: Unable to create order due to unspecified IO error.] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  08:05:41.195 [orders] 2024-11-23 08:05:41.195 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[app
  08:05:41.198 [orders] 2024-11-23 08:05:41.198 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produce
  08:05:43.084 [orders] 2024-11-23 08:05:43.084 INFO [orders,,,] 8 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  08:05:44.588 [orders] 2024-11-23 08:05:44.587 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:05:44.685 [orders] 2024-11-23 08:05:44.685 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetecte
  08:05:44.686 [orders] 2024-11-23 08:05:44.686 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposu  (×2)
  08:05:44.688 [orders] 2024-11-23 08:05:44.687 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  08:05:44.688 [orders] 2024-11-23 08:05:44.687 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX exp
  08:05:44.691 [orders] 2024-11-23 08:05:44.690 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX serve
  08:05:44.792 [orders] 2024-11-23 08:05:44.791 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'restartEndpoint': registering with JMX server a  (×2)
  08:05:44.886 [orders] 2024-11-23 08:05:44.886 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'refreshScope': registering with JMX server as M
  08:05:44.894 [orders] 2024-11-23 08:05:44.894 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering w
  08:05:45.989 [orders] 2024-11-23 08:05:45.989 INFO [orders,,,] 8 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  08:05:46.587 [orders] 2024-11-23 08:05:46.586 INFO [orders,,,] 8 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  08:05:46.592 [orders] 2024-11-23 08:05:46.592 INFO [orders,,,] 8 --- [ main] w.weave.socks.orders.OrderApplication : Started OrderApplication in 80.202 seconds (JVM running for 83.09
  08:05:47.587 [orders] 2024-11-23 08:05:47.587 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  08:05:47.587 [orders] 2024-11-23 08:05:47.587 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization starte
  08:05:47.988 [orders] 2024-11-23 08:05:47.988 INFO [orders,,,] 8 --- [p-nio-80-exec-1] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comple
All services, 30 seconds either side (sampled):
  08:05:19.513 [queue-master] 2024-11-23 08:05:19.513 INFO 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.actuate.autoc
  08:05:20.542 [front-end] Posting Customer: {"username":"rsVXS","password":"uVNkH","email":"rsVXS@gmail.com","firstName":"rsVXS","lastName":"rsVXS"}
  08:05:20.765 [front-end] POST to carts: http://carts/carts/67418cb7a437380001deebdf/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}  (×27)
  08:05:21.696 [orders] 2024-11-23 08:05:21.696 INFO [orders,,,] 8 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mes
  08:05:26.322 [queue-master] 2024-11-23 08:05:26.317 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.embedded.Ann
  08:05:26.609 [queue-master] 2024-11-23 08:05:26.608 INFO 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}/{propertyId}],methods=[DELETE],produ
  08:05:27.702 [queue-master] 2024-11-23 08:05:27.618 INFO 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/json]}" ont
  08:05:27.912 [carts] 2024-11-23 08:05:27.912 INFO [carts,,,] 7 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  08:05:30.347 [front-end] Received response: "{\"firstName\":\"lnUJCOGPOEIgTcq\",\"lastName\":\"lnUJCOGPOEIgTcq\",\"username\":\"lnUJCOGPOEIgTcq\",\"id\":\"67418cb3a437380001deebcd\",\"_
  08:05:32.017 [rabbitmq] 
  08:05:35.382 [front-end] Received response: "{\"firstName\":\"iFVPDhisWkusfR\",\"lastName\":\"iFVPDhisWkusfR\",\"username\":\"iFVPDhisWkusfR\",\"id\":\"67418cc0a437380001deebfa\",\"_lin
  08:05:38.557 [front-end] Posting Customer: {"username":"lYvQmmCWwWuvT","password":"cBYjNxlFd","email":"lYvQmmCWwWuvT@gmail.com","firstName":"lYvQmmCWwWuvT","lastName":"lYvQmmCWwWuvT"}
  08:05:39.193 [orders] 2024-11-23 08:05:39.193 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT |
  08:05:39.898 [front-end] Received response: "{\"firstName\":\"rmXotuT\",\"lastName\":\"rmXotuT\",\"username\":\"rmXotuT\",\"id\":\"67418cbda437380001deebf2\",\"_links\":{\"addresses\":{
  08:05:41.195 [orders] 2024-11-23 08:05:41.195 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[app
  08:05:44.688 [orders] 2024-11-23 08:05:44.687 INFO [orders,,,] 8 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX exp
  08:05:48.861 [front-end] Received response: "{\"firstName\":\"hXEwrKNJwlXqYDy\",\"lastName\":\"hXEwrKNJwlXqYDy\",\"username\":\"hXEwrKNJwlXqYDy\",\"id\":\"67418cc8a437380001deec17\",\"_
  08:05:50.339 [user] ts=2024-11-23T08:05:50.339862718Z caller=middlewares.go:46 method=Register username=WUyAw email=WUyAw@gmail.com took=3.668769ms
  08:05:54.904 [shipping] 2024-11-23 08:05:54.904 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/trace || /trace.json],methods=[GET],produces=[applica
  08:05:55.766 [front-end] Received response: "{\"firstName\":\"pSeQWyL\",\"lastName\":\"pSeQWyL\",\"username\":\"pSeQWyL\",\"id\":\"67418cd0a437380001deec2e\",\"_links\":{\"addresses\":{
  08:05:59.705 [front-end] Posting Customer: {"username":"RKNDdSk","password":"qMAtnYqE","email":"RKNDdSk@gmail.com","firstName":"RKNDdSk","lastName":"RKNDdSk"}
  08:06:03.410 [carts] 2024-11-23 08:06:03.409 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  08:06:07.000 [shipping] 2024-11-23 08:06:07.000 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[HEAD],produces=[application/hal+json
  08:06:07.099 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[HEAD],produces=[appli
  08:06:10.127 [front-end] Posting Customer: {"username":"SPVlWNNsjeesK","password":"GJzTi","email":"SPVlWNNsjeesK@gmail.com","firstName":"SPVlWNNsjeesK","lastName":"SPVlWNNsjeesK"}
  08:06:14.400 [shipping] 2024-11-23 08:06:14.400 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX ser
  08:06:15.803 [carts] 2024-11-23 08:06:15.803 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[DELETE],produces=[applicat
  08:06:15.968 [front-end] Posting Customer: {"username":"ADJLNqHnQSjIpaY","password":"BVKQdfwKCt","email":"ADJLNqHnQSjIpaY@gmail.com","firstName":"ADJLNqHnQSjIpaY","lastName":"ADJLNqHnQS
  08:06:19.008 [carts] 2024-11-23 08:06:19.007 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.s

## p0832
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-seat-service, 2024-12-08T12:22:56.504Z
```
{"timestamp":1733660576504181800,"container_name":"ts-seat-service","pod_name":"ts-seat-service-5cd7c676cf-hq66v","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-08 12:22:56.503  INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl             : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Success"}
```
Same service, the 2 minutes before (oldest first):
  12:22:56.005 [ts-seat-service] 2024-12-08 12:22:56.004 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×2)
  12:22:56.019 [ts-seat-service] 2024-12-08 12:22:56.019 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×3)
  12:22:56.019 [ts-seat-service] 2024-12-08 12:22:56.019 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×2)
  12:22:56.068 [ts-seat-service] 2024-12-08 12:22:56.068 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  12:22:56.096 [ts-seat-service] 2024-12-08 12:22:56.095 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×3)
  12:22:56.096 [ts-seat-service] 2024-12-08 12:22:56.095 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital
  12:22:56.116 [ts-seat-service] 2024-12-08 12:22:56.116 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon
  12:22:56.140 [ts-seat-service] 2024-12-08 12:22:56.140 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass 
  12:22:56.406 [ts-seat-service] 2024-12-08 12:22:56.406 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×2)
  12:22:56.431 [ts-seat-service] 2024-12-08 12:22:56.430 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Succes
  12:22:56.442 [ts-seat-service] 2024-12-08 12:22:56.442 INFO 1 --- [io-18898-exec-1] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Order is Null., da
All services, 30 seconds either side (sampled):
  12:22:27.070 [ts-auth-service] 2024-12-08 12:22:27.070 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×9)
  12:22:27.337 [ts-travel-service] 2024-12-08 12:22:27.337 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×12)
  12:22:30.905 [ts-auth-service] 2024-12-08 12:22:30.905 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×14)
  12:22:31.215 [ts-price-service] 2024-12-08 12:22:31.215 INFO 1 --- [io-16579-exec-9] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×23)
  12:22:31.280 [ts-seat-service] 2024-12-08 12:22:31.280 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, trainN  (×41)
  12:22:31.308 [ts-seat-service] 2024-12-08 12:22:31.307 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×10)
  12:22:31.467 [ts-admin-basic-info-service] 2024-12-08 12:22:31.467 INFO 1 --- [o-18767-exec-10] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×3)
  12:22:31.987 [ts-seat-service] 2024-12-08 12:22:31.987 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  12:22:37.075 [ts-travel-service] 2024-12-08 12:22:37.074 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Travel Service] Query TripResponse
  12:22:37.128 [ts-travel-service] 2024-12-08 12:22:37.128 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×3)
  12:22:37.239 [ts-seat-service] 2024-12-08 12:22:37.239 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×6)
  12:22:37.464 [ts-food-map-service] 2024-12-08 12:22:37.464 INFO 1 --- [io-18855-exec-8] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]  (×3)
  12:22:37.557 [ts-security-service] 2024-12-08 12:22:37.556 INFO 1 --- [io-11188-exec-7] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....  (×2)
  12:22:37.592 [ts-preserve-service] 2024-12-08 12:22:37.592 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Contacts By Id] Getting....
  12:22:37.706 [ts-travel-service] 2024-12-08 12:22:37.706 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s  (×5)
  12:22:37.985 [ts-seat-service] 2024-12-08 12:22:37.985 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService distributeSeat] TrainNumber start with G|D
  12:22:38.060 [ts-order-service] 2024-12-08 12:22:38.059 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : [Order Service][Order Create] Success.
  12:22:38.101 [ts-preserve-service] 2024-12-08 12:22:38.101 INFO 1 --- [io-14568-exec-8] preserve.service.PreserveServiceImpl : [Preserve Service][Step 7] Do not need to consign
  12:22:47.581 [ts-order-other-service] 2024-12-08 12:22:47.581 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=178781  (×3)
  12:22:56.573 [ts-basic-service] 2024-12-08 12:22:56.573 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：aefcef3f-3f
  12:23:00.180 [ts-order-service] 2024-12-08 12:23:00.179 INFO 1 --- [io-12031-exec-2] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 4d2a46c7-71cb-4cf1-
  12:23:00.432 [ts-consign-service] 2024-12-08 12:23:00.432 INFO 1 --- [io-16111-exec-2] consign.service.ConsignServiceImpl : SAVE consign result : ConsignRecord(id=80838481-bf44-4b43-a534-876bd8d
  12:23:01.696 [ts-preserve-other-service] 2024-12-08 12:23:01.696 INFO 1 --- [io-14569-exec-5] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security
  12:23:01.777 [ts-travel2-service] 2024-12-08 12:23:01.777 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [TravelService] [getTripAllDetailInfo] gtdi info: TripAllDetailInfo(tr
  12:23:01.872 [ts-basic-service] 2024-12-08 12:23:01.871 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4
  12:23:02.254 [ts-order-other-service] 2024-12-08 12:23:02.253 INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController : [Order Other Service][Create Order] Create Order form shanghai --->
  12:23:02.286 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:20:23:02 +0800] "POST /api/v1/preserveotherservice/preserveOther HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7
  12:23:12.135 [ts-preserve-other-mongo] {"t":{"$date":"2024-12-08T12:23:12.135+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366059
  12:23:14.680 [ts-consign-price-mongo] {"t":{"$date":"2024-12-08T12:23:14.680+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366059

## p0165
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:25:47.903Z
```
{"timestamp":1731911147903219200,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  06:25:47.103 [frontend] request started  (×7)
  06:25:47.103 [frontend] serving product page  (×4)
  06:25:47.142 [frontend] request complete  (×6)
  06:25:47.233 [frontend] adding to cart
  06:25:47.246 [frontend] view user cart  (×2)
All services, 30 seconds either side (sampled):
  06:25:17.941 [currencyservice] conversion request successful  (×732)
  06:25:17.956 [frontend] request complete  (×332)
  06:25:18.039 [currencyservice] Getting supported currencies...  (×267)
  06:25:18.068 [adservice] received ad request (context_words=[accessories])  (×29)
  06:25:18.928 [cartservice] AddItemAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121, productId=0PUK6V6EV0, quantity=3  (×37)
  06:25:18.966 [shippingservice] [GetQuote] completed request  (×86)
  06:25:19.050 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"1023","nanos":790000000},"credit_card":{"credit_card_number":"4403898043899  (×6)
  06:25:19.054 [shippingservice] [ShipOrder] received request  (×18)
  06:25:19.064 [emailservice] A request to send order confirmation email to rebekah66@example.com has been received.
  06:25:19.781 [frontend] setting currency  (×27)
  06:25:20.949 [adservice] received ad request (context_words=[footwear])  (×11)
  06:25:27.071 [emailservice] A request to send order confirmation email to ycook@example.org has been received.
  06:25:29.375 [checkoutservice] order confirmation email sent to "kennethsteele@example.org"
  06:25:31.385 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"8967","nanos":270871274},"credit_card":{"credit_card_number":"4965533174528  (×4)
  06:25:31.396 [checkoutservice] order confirmation email sent to "huntdavid@example.org"
  06:25:32.777 [paymentservice] Transaction processed: visa ending 9970 Amount: JPY26589.282619120  (×4)
  06:25:34.880 [emailservice] A request to send order confirmation email to elizabeth09@example.com has been received.
  06:25:38.752 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="EUR"  (×4)
  06:25:39.061 [emailservice] A request to send order confirmation email to lrivas@example.net has been received.
  06:25:39.190 [checkoutservice] order confirmation email sent to "kanekimberly@example.org"
  06:25:45.552 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', 'LS4PSXUNUM', '0PUK6V6EV0', 'L9ECAV7KIM']
  06:25:52.899 [emailservice] A request to send order confirmation email to davischristy@example.com has been received.
  06:25:58.052 [checkoutservice] order confirmation email sent to "nicholasacosta@example.org"
  06:26:00.574 [emailservice] A request to send order confirmation email to justin01@example.com has been received.
  06:26:04.270 [checkoutservice] order confirmation email sent to "audreycunningham@example.net"
  06:26:08.047 [redis] 1:M 18 Nov 2024 06:26:08.046 * 100 changes in 300 seconds. Saving...
  06:26:08.052 [redis] 63:C 18 Nov 2024 06:26:08.052 * Fork CoW for RDB: current 0 MB, peak 0 MB, average 0 MB
  06:26:14.422 [checkoutservice] order confirmation email sent to "lisaruiz@example.net"

## p0028
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service webservice2, 2021-08-13T07:36:03.452Z
```
{"service":"webservice2","message":"2021-08-13 07:36:03,452 | INFO | 0.0.0.3 | 172.17.0.4 | webservice2 | dc4d67a2e1e60e73 | call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  07:35:58.303 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×3)
  07:35:58.304 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×3)
  07:35:58.305 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '0bae19c8-fbc6-11eb-9d66-0242ac110004', 'value': '', 'ex': 10}  (×3)
  07:35:58.365 [webservice2] INFO uuid: 0bae19c8-fbc6-11eb-9d66-0242ac110004 write redis successfully  (×3)
  07:35:58.469 [webservice2] INFO complete information: {'uuid': '0bae19c8-fbc6-11eb-9d66-0242ac110004', 'user_id': 'iBxJIdNQ'}  (×3)
  07:35:58.479 [webservice2] INFO call service:mobservice2, inst:http://0.0.0.4:9383 as a downstream service  (×2)
  07:35:58.479 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×2)
  07:35:59.100 [webservice2] ERROR an error occurred in the downstream service
All services, 30 seconds either side (sampled):
  07:35:33.464 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×42)
  07:35:33.803 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  07:35:34.114 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×48)
  07:35:34.363 [logservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'fd13a77a-fbc5-11eb-9846-0242ac110003'}  (×41)
  07:35:34.515 [dbservice2] INFO query = select passwards from username_table where user_name='dDmGvhol'  (×37)
  07:35:35.067 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  07:35:35.239 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  07:35:35.520 [webservice1] ERROR an error occurred in the downstream service  (×3)
  07:35:37.469 [mobservice1] INFO info ff100744-fbc5-11eb-94ed-0242ac110003:mHwMQugd write success
  07:35:39.735 [mobservice1] INFO info 00684304-fbc6-11eb-abe6-0242ac110004:LtXTsDKV write success
  07:35:42.237 [mobservice1] INFO info 01de3306-fbc6-11eb-855a-0242ac110004:bCtvogcT write success
  07:35:49.477 [mobservice1] INFO info 063c162a-fbc6-11eb-8510-0242ac110003:jyDKkYiT write success
  07:35:52.033 [mobservice1] INFO info 07c17dbe-fbc6-11eb-a6c8-0242ac110003:uloJcsne write success
  07:35:55.048 [mobservice1] INFO info 097f479e-fbc6-11eb-99e4-0242ac110004:FgWeZKzi write success
  07:35:57.780 [mobservice2] INFO info 0b252730-fbc6-11eb-b7c4-0242ac110004:npqwesLI write success
  07:36:00.810 [mobservice2] INFO info 0cfc7018-fbc6-11eb-82f5-0242ac110003:ocwNidgD write success
  07:36:03.328 [dbservice1] INFO 0e48518a-fbc6-11eb-baa6-0242ac110003-jHRvwBZi-&*URqDJ1T%i) token generate success token=MTYyODgxMTM2My4zMjc3NTI6MGU0ODUxOGEtZmJjNi0xMWViLWJhYTYtMDI0MmFjMTE
  07:36:06.014 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  07:36:08.579 [dbservice1] INFO 1154fd42-fbc6-11eb-b2e4-0242ac110004-NXYiMcPr-J6dEzX+o4}bS token generate success token=MTYyODgxMTM2OC41Nzk1MTM1OjExNTRmZDQyLWZiYzYtMTFlYi1iMmU0LTAyNDJhYzE
  07:36:11.176 [dbservice1] INFO 12ecaa24-fbc6-11eb-823a-0242ac110004-RcoJYnsh-sPdxZat-)M%I token generate success token=MTYyODgxMTM3MS4xNzY1MTM6MTJlY2FhMjQtZmJjNi0xMWViLTgyM2EtMDI0MmFjMTE
  07:36:13.863 [dbservice1] INFO 148520aa-fbc6-11eb-a56e-0242ac110003-ELQbKFma-9T(1h8zuNDx_ token generate success token=MTYyODgxMTM3My44NjMzOTc6MTQ4NTIwYWEtZmJjNi0xMWViLWE1NmUtMDI0MmFjMTE
  07:36:16.667 [dbservice1] INFO 1631a5cc-fbc6-11eb-9178-0242ac110003-pvKgfqae-d8&7hNc*1gTi token generate success token=MTYyODgxMTM3Ni42NjcyOTE5OjE2MzFhNWNjLWZiYzYtMTFlYi05MTc4LTAyNDJhYzE
  07:36:19.242 [dbservice2] INFO 17b46754-fbc6-11eb-bcd3-0242ac110004-FWZKSkEd-d*WN%Kbw7ZHk token generate success token=MTYyODgxMTM3OS4yNDE4MDIyOjE3YjQ2NzU0LWZiYzYtMTFlYi1iY2QzLTAyNDJhYzE
  07:36:22.047 [mobservice2] INFO info 19b1963a-fbc6-11eb-a313-0242ac110003:xYHiSMPL write success
  07:36:24.983 [dbservice1] INFO 1b28e5d6-fbc6-11eb-abce-0242ac110004-NFrlOSIe-=YK{V2Rx*D6H token generate success token=MTYyODgxMTM4NC45ODI4MDEyOjFiMjhlNWQ2LWZiYzYtMTFlYi1hYmNlLTAyNDJhYzE
  07:36:27.408 [dbservice2] INFO 1c9d2864-fbc6-11eb-ad29-0242ac110004-MGClVmwF-=l9b/XFzu&>h token generate success token=MTYyODgxMTM4Ny40MDgyNDUzOjFjOWQyODY0LWZiYzYtMTFlYi1hZDI5LTAyNDJhYzE
  07:36:30.172 [dbservice1] INFO 1e3aeac6-fbc6-11eb-86fc-0242ac110004-lmvshOqT-%2#uLB3dNKSs token generate success token=MTYyODgxMTM5MC4xNzE2MDEzOjFlM2FlYWM2LWZiYzYtMTFlYi04NmZjLTAyNDJhYzE
  07:36:32.951 [dbservice2] INFO 1ff8782e-fbc6-11eb-9f6a-0242ac110003-HfckUWDQ-tbA<=n&}flog token generate success token=MTYyODgxMTM5Mi45NTA1NDk4OjFmZjg3ODJlLWZiYzYtMTFlYi05ZjZhLTAyNDJhYzE

## p0522
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T10:42:29.227Z
```
{"timestamp":1732358549227631400,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"6741b195a437380001df4ba9"}
```
Same service, the 2 minutes before (oldest first):
  10:42:28.813 [front-end] 6741b194a437380001df4ba6
  10:42:28.813 [front-end] Merging carts for customer id: 6741b194a437380001df4ba6 and session id: 8vAvUyLFOs8XsLibodi4Xj2f9QEfs7NI
  10:42:28.846 [front-end] Carts merged.
  10:42:28.846 [front-end] set cookie6741b194a437380001df4ba6
  10:42:28.847 [front-end] Sent cookies.
  10:42:28.848 [front-end] POST /register 200 43.413 ms - 33
  10:42:28.996 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b18ba437380001df4b93"}
  10:42:29.008 [front-end] POST /addresses 200 - ms - -
  10:42:29.013 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"6741b18ba437380001df4b93"}
  10:42:29.025 [front-end] POST /cards 200 - ms - -
  10:42:29.072 [front-end] Attempting to delete cart for user: 6741b18ba437380001df4b93
  10:42:29.098 [front-end] User cart deleted with status: 202
  10:42:29.099 [front-end] DELETE /cart 202 - ms - -
  10:42:29.104 [front-end] Attempting to add to cart: {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","quantity":1}
  10:42:29.116 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed
  10:42:29.116 [front-end] POST to carts: http://carts/carts/6741b18ba437380001df4b93/items body: {"itemId":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","unitPrice":99.99}
  10:42:29.152 [front-end] GET /catalogue 200 - ms - -
  10:42:29.170 [front-end] POST /cart 201 - ms - -
  10:42:29.218 [front-end] Posting Customer: {"username":"mGHHyeKOwbUN","password":"QBuLJML","email":"mGHHyeKOwbUN@gmail.com","firstName":"mGHHyeKOwbUN","lastName":"mGHHyeKOwbUN"}
  10:42:29.227 [front-end] { id: '6741b195a437380001df4ba9' }
All services, 30 seconds either side (sampled):
  10:41:59.230 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b165a437380001df4b26\",\"_links\":{\"  (×60)
  10:41:59.266 [queue-master] Received shipment task: 6741b15aa437380001df4b02  (×53)
  10:41:59.276 [front-end] 6741b177a437380001df4b65  (×59)
  10:42:00.258 [front-end] GET Request to: http://user/customers/6741b165a437380001df4b2c/addresses  (×118)
  10:42:01.380 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b172a437380001df4b56"}  (×60)
  10:42:01.504 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×9)
  10:42:02.224 [front-end] Received response: "{\"firstName\":\"AsWOJvoKNL\",\"lastName\":\"AsWOJvoKNL\",\"username\":\"AsWOJvoKNL\",\"id\":\"6741b163a437380001df4b1e\",\"_links\":{\"addr
  10:42:03.531 [front-end] Posting Customer: {"username":"FLiqlpA","password":"RXZQGbiNI","email":"FLiqlpA@gmail.com","firstName":"FLiqlpA","lastName":"FLiqlpA"}
  10:42:05.506 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b17d01dd390007094dfc","customerId":"6741b16ba437380001df4b3c","customer":{"id":null,"firstName":"IfOkjlIP","
  10:42:06.719 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×12)
  10:42:10.052 [front-end] Received response: "{\"firstName\":\"kHyjCHYyJ\",\"lastName\":\"kHyjCHYyJ\",\"username\":\"kHyjCHYyJ\",\"id\":\"6741b169a437380001df4b37\",\"_links\":{\"address
  10:42:13.944 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×3)
  10:42:17.238 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b18901dd390007094e05","customerId":"6741b176a437380001df4b64","customer":{"id":null,"firstName":"BBoDQLZVQIz
  10:42:19.785 [front-end] Posting Customer: {"username":"mOsUajmTCOuD","password":"PclXD","email":"mOsUajmTCOuD@gmail.com","firstName":"mOsUajmTCOuD","lastName":"mOsUajmTCOuD"}
  10:42:23.996 [front-end] Received response: "{\"firstName\":\"jGtfmTYFLF\",\"lastName\":\"jGtfmTYFLF\",\"username\":\"jGtfmTYFLF\",\"id\":\"6741b17ba437380001df4b72\",\"_links\":{\"addr
  10:42:24.904 [user] ts=2024-11-23T10:42:24.904623485Z caller=middlewares.go:46 method=Register username=SGHrmQKj email=SGHrmQKj@gmail.com took=2.263575ms
  10:42:27.029 [front-end] Posting Customer: {"username":"drIpSVYoFYMY","password":"YGkAbaE","email":"drIpSVYoFYMY@gmail.com","firstName":"drIpSVYoFYMY","lastName":"drIpSVYoFYMY"}
  10:42:29.218 [front-end] Posting Customer: {"username":"mGHHyeKOwbUN","password":"QBuLJML","email":"mGHHyeKOwbUN@gmail.com","firstName":"mGHHyeKOwbUN","lastName":"mGHHyeKOwbUN"}
  10:42:32.458 [front-end] Received response: "{\"firstName\":\"fMqkVIscpJAub\",\"lastName\":\"fMqkVIscpJAub\",\"username\":\"fMqkVIscpJAub\",\"id\":\"6741b183a437380001df4b7f\",\"_links\
  10:42:34.927 [queue-master] 2024-11-23 10:42:34.927 INFO 7 --- [pool-6-thread-3] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×9)
  10:42:37.074 [front-end] Posting Customer: {"username":"kIGeXyfwDdcnX","password":"HYvjBVQVkK","email":"kIGeXyfwDdcnX@gmail.com","firstName":"kIGeXyfwDdcnX","lastName":"kIGeXyfwDdcnX"}
  10:42:39.648 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b19f01dd390007094e16","customerId":"6741b18fa437380001df4b9a","customer":{"id":null,"firstName":"hkNXgDJyv",
  10:42:42.256 [front-end] Order response: {"id":"6741b1a201dd390007094e19","customerId":"6741b190a437380001df4b9c","customer":{"id":null,"firstName":"juGLviwwFqYBQb","lastName":"juGLviww
  10:42:44.968 [front-end] Order response: {"id":"6741b1a401dd390007094e1b","customerId":"6741b194a437380001df4ba5","customer":{"id":null,"firstName":"zQXUmkCZssMpOLp","lastName":"zQXUmkC
  10:42:46.608 [user] ts=2024-11-23T10:42:46.608545965Z caller=middlewares.go:46 method=Register username=LFlcXJd email=LFlcXJd@gmail.com took=1.991812ms
  10:42:49.045 [front-end] Posting Customer: {"username":"BRyiIgIUue","password":"qvGmbS","email":"BRyiIgIUue@gmail.com","firstName":"BRyiIgIUue","lastName":"BRyiIgIUue"}
  10:42:52.524 [front-end] Order response: {"id":"6741b1ac01dd390007094e1f","customerId":"6741b19ca437380001df4bbe","customer":{"id":null,"firstName":"FaALE","lastName":"FaALE","username"
  10:42:54.294 [front-end] Received response: "{\"firstName\":\"drIpSVYoFYMY\",\"lastName\":\"drIpSVYoFYMY\",\"username\":\"drIpSVYoFYMY\",\"id\":\"6741b193a437380001df4ba1\",\"_links\":{
  10:42:55.192 [front-end] Order response: {"statusCode":201,"body":{"id":"6741b1af01dd390007094e26","customerId":"6741b19da437380001df4bc9","customer":{"id":null,"firstName":"ysfRffWVDnk
  10:42:57.419 [front-end] Received response: "{\"firstName\":\"kIGeXyfwDdcnX\",\"lastName\":\"kIGeXyfwDdcnX\",\"username\":\"kIGeXyfwDdcnX\",\"id\":\"6741b19da437380001df4bc7\",\"_links\

## p0146
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T05:36:43.635Z
```
{"timestamp":1731908203635468500,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-sd8v2","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  05:36:43.503 [currencyservice] conversion request successful  (×17)
  05:36:43.512 [currencyservice] Getting supported currencies...  (×3)
All services, 30 seconds either side (sampled):
  05:36:13.709 [frontend] request started  (×334)
  05:36:13.718 [cartservice] GetCartAsync called with userId=418ce0b6-15a4-4228-a6cf-27e322509121  (×280)
  05:36:13.744 [adservice] received ad request (context_words=[hair, beauty])  (×16)
  05:36:13.823 [frontend] view user cart  (×62)
  05:36:14.404 [frontend] home  (×32)
  05:36:14.452 [adservice] received ad request (context_words=[])  (×32)
  05:36:15.158 [adservice] received ad request (context_words=[kitchen])  (×62)
  05:36:19.182 [frontend] placing order  (×12)
  05:36:19.203 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"5251","nanos":665634788},"credit_card":{"credit_card_number":"4055923497348  (×2)
  05:36:19.208 [shippingservice] [ShipOrder] received request  (×12)
  05:36:19.220 [emailservice] A request to send order confirmation email to ogardner@example.com has been received.
  05:36:26.987 [checkoutservice] [PlaceOrder] user_id="f3509d43-91d9-45a0-a174-70f597a55fb4" user_currency="USD"  (×3)
  05:36:27.035 [emailservice] A request to send order confirmation email to batesryan@example.com has been received.
  05:36:39.459 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="TRY"  (×3)
  05:36:39.502 [emailservice] A request to send order confirmation email to stephensdaniel@example.net has been received.
  05:36:40.214 [checkoutservice] [PlaceOrder] user_id="d4e28c38-1561-4a66-b120-02013f892c20" user_currency="GBP"
  05:36:40.252 [emailservice] A request to send order confirmation email to christopherreyes@example.com has been received.
  05:36:43.557 [checkoutservice] order confirmation email sent to "jamesstewart@example.org"
  05:36:57.606 [emailservice] A request to send order confirmation email to dramos@example.com has been received.
  05:37:01.703 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"553","nanos":841365765},"credit_card":{"credit_card_number":"48271869938489
  05:37:01.718 [checkoutservice] order confirmation email sent to "deanserrano@example.org"
  05:37:06.088 [paymentservice] Transaction processed: visa ending 5151 Amount: EUR2001.530296335  (×2)
  05:37:09.589 [emailservice] A request to send order confirmation email to kevinmartin@example.com has been received.
  05:37:11.357 [checkoutservice] order confirmation email sent to "peterward@example.net"

## p0559
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-ui-dashboard, 2024-12-07T18:27:20.886Z
```
{"timestamp":1733596040886146000,"container_name":"ts-ui-dashboard","pod_name":"ts-ui-dashboard-667c5cdd98-x99xl","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"127.0.0.1 - - [08/Dec/2024:02:27:20 +0800] \"POST /api/v1/users/login HTTP/1.1\" 200 380 \"http://localhost:8080/client_login.html\" \"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.107 Safari/537.36\""}
```
Same service, the 2 minutes before (oldest first):
  18:27:09.255 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:27:09 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 356 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×2)
  18:27:11.790 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:27:11 +0800] "POST /api/v1/users/login HTTP/1.1" 200 353 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel   (×4)
  18:27:11.961 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:27:11 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×3)
  18:27:13.259 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:27:13 +0800] "GET /api/v1/adminbasicservice/adminbasic/prices HTTP/1.1" 200 1697 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×6)
  18:27:18.591 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:27:18 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 200 339 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe
  18:27:18.603 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:27:18 +0800] "GET /api/v1/assuranceservice/assurances/types HTTP/1.1" 200 119 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
  18:27:18.712 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:27:18 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 3056 "-" "Mozilla/5.0 (Macintosh;
  18:27:18.726 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:27:18 +0800] "GET /api/v1/contactservice/contacts/account/4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f HTTP/1.1" 200 471 "-" "Mozilla/5.0 
  18:27:19.321 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:27:19 +0800] "POST /api/v1/preserveservice/preserve HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWeb
All services, 30 seconds either side (sampled):
  18:26:50.968 [ts-auth-service] 2024-12-07 18:26:50.967 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×23)
  18:26:51.033 [ts-basic-service] 2024-12-07 18:26:51.033 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×16)
  18:26:51.072 [ts-basic-service] 2024-12-07 18:26:51.072 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : route.getDistances().size : 4  (×18)
  18:26:51.263 [ts-seat-service] 2024-12-07 18:26:51.262 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×2)
  18:26:51.314 [ts-travel2-service] 2024-12-07 18:26:51.313 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×24)
  18:26:51.446 [ts-seat-service] 2024-12-07 18:26:51.446 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×17)
  18:26:56.309 [ts-seat-service] 2024-12-07 18:26:56.309 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×20)
  18:26:58.278 [ts-travel-service] 2024-12-07 18:26:58.278 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×10)
  18:26:58.766 [ts-travel-service] 2024-12-07 18:26:58.765 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×4)
  18:27:01.533 [ts-basic-service] 2024-12-07 18:27:01.533 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 9270  (×2)
  18:27:01.632 [ts-order-service] 2024-12-07 18:27:01.632 INFO 1 --- [io-12031-exec-3] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×15)
  18:27:02.172 [ts-price-service] 2024-12-07 18:27:02.172 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×3)
  18:27:08.941 [ts-basic-service] 2024-12-07 18:27:08.940 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×3)
  18:27:09.195 [ts-order-other-service] 2024-12-07 18:27:09.194 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×2)
  18:27:18.418 [ts-seat-service] 2024-12-07 18:27:18.418 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×3)
  18:27:18.712 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:27:18 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 3056 "-" "Mozilla/5.0 (Macintosh;  (×2)
  18:27:18.747 [ts-security-service] 2024-12-07 18:27:18.746 INFO 1 --- [io-11188-exec-2] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Getting....
  18:27:18.779 [ts-preserve-service] 2024-12-07 18:27:18.779 INFO 1 --- [io-14568-exec-5] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Contacts Id: b0f23465-83b1-4055-b110-ecd
  18:27:19.054 [ts-seat-service] 2024-12-07 18:27:19.053 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345
  18:27:19.211 [ts-basic-service] 2024-12-07 18:27:19.211 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : suzhou
  18:27:19.269 [ts-order-service] 2024-12-07 18:27:19.269 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at 
  18:27:19.298 [ts-food-service] 2024-12-07 18:27:19.298 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food-Service][AddFoodOrder] Success.
  18:27:27.442 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-07T18:27:27.441+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359604
  18:27:29.904 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T18:27:29.904+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359604
  18:27:30.461 [ts-consign-service] 2024-12-07 18:27:30.460 INFO 1 --- [io-16111-exec-1] consign.service.ConsignServiceImpl : The handle date is 2024-12-07  (×2)
  18:27:30.902 [ts-order-mongo] {"t":{"$date":"2024-12-07T18:27:30.901+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359605
  18:27:36.385 [ts-travel2-service] 2024-12-07 18:27:36.385 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  18:27:38.486 [ts-auth-service] 2024-12-07 18:27:38.485 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 7e245371-0433-455a-9952-3039be62f341 USER ID
  18:27:43.945 [ts-basic-service] 2024-12-07 18:27:43.944 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO

## p0221
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:49:14.394Z
```
{"timestamp":1731916154394182700,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request complete"}
```
Same service, the 2 minutes before (oldest first):
  07:49:12.257 [frontend] serving product page  (×4)
  07:49:12.295 [frontend] request complete  (×6)
  07:49:12.999 [frontend] request started  (×6)
  07:49:12.999 [frontend] view user cart
  07:49:13.355 [frontend] setting currency
  07:49:13.358 [frontend] home
  07:49:13.404 [frontend] ENV_PLATFORM is: aws
All services, 30 seconds either side (sampled):
  07:48:44.709 [frontend] request started  (×337)
  07:48:44.716 [cartservice] GetCartAsync called with userId=acc735c5-72d0-48e6-b237-46a63eac4c4d  (×280)
  07:48:44.735 [shippingservice] [GetQuote] completed request  (×81)
  07:48:44.852 [frontend] serving product page  (×161)
  07:48:45.216 [adservice] received ad request (context_words=[kitchen])  (×52)
  07:48:45.224 [cartservice] AddItemAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43, productId=9SIQT8TOJO, quantity=8  (×37)
  07:48:46.645 [frontend] ENV_PLATFORM is: aws  (×38)
  07:48:47.572 [checkoutservice] [PlaceOrder] user_id="e68474c6-7c27-4a5d-9e2c-d5e430b87e55" user_currency="EUR"  (×8)
  07:48:47.597 [checkoutservice] payment went through (transaction_id: d9d7b769-ac77-4ede-ac4f-8608835462b3)  (×12)
  07:48:47.602 [cartservice] EmptyCartAsync called with userId=e68474c6-7c27-4a5d-9e2c-d5e430b87e55  (×12)
  07:48:47.610 [frontend] order placed  (×12)
  07:48:51.030 [recommendationservice] [Recv ListRecommendations] product_ids=['1YMWWN1N4O', 'OLJCESPC7Z']
  07:48:51.121 [paymentservice] Transaction processed: visa ending 8743 Amount: USD1679.890000000  (×2)
  07:48:53.308 [frontend] setting currency  (×20)
  07:49:05.969 [emailservice] A request to send order confirmation email to kimrodriguez@example.com has been received.
  07:49:07.264 [checkoutservice] order confirmation email sent to "karenli@example.org"
  07:49:16.623 [emailservice] A request to send order confirmation email to richardsondawn@example.net has been received.
  07:49:18.547 [checkoutservice] order confirmation email sent to "johnhill@example.com"
  07:49:23.993 [emailservice] A request to send order confirmation email to travis83@example.org has been received.
  07:49:36.095 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"314","nanos":305711620},"credit_card":{"credit_card_number":"43999166534280
  07:49:36.110 [checkoutservice] order confirmation email sent to "aaron90@example.net"
  07:49:39.755 [paymentservice] Transaction processed: visa ending 8837 Amount: JPY100713.15480938

## p0342
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:21:31.995Z
```
{"timestamp":1732245691995150600,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /cart 201 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  03:21:30.989 [front-end] User cart deleted with status: 202  (×2)
  03:21:30.993 [front-end] DELETE /cart 202 - ms - -  (×2)
  03:21:30.997 [front-end] Attempting to add to cart: {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×2)
  03:21:31.004 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca
  03:21:31.004 [front-end] POST to carts: http://carts/carts/673ff8b1b0df5c00019b1f9a/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}
  03:21:31.136 [front-end] GET /catalogue 200 - ms - -  (×4)
  03:21:31.393 [front-end] POST /cart 201 - ms - -
  03:21:31.504 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff8b3b0df5c00019b1f9d"}
  03:21:31.513 [front-end] POST /addresses 200 - ms - -
  03:21:31.519 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff8b3b0df5c00019b1f9d"}
  03:21:31.527 [front-end] POST /cards 200 - ms - -
  03:21:31.575 [front-end] Attempting to delete cart for user: 673ff8b3b0df5c00019b1f9d
  03:21:31.613 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
  03:21:31.613 [front-end] POST to carts: http://carts/carts/673ff8b3b0df5c00019b1f9d/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}
All services, 30 seconds either side (sampled):
  03:21:02.119 [front-end] Posting Customer: {"username":"gKGbBfBuFal","password":"jTPEzN","email":"gKGbBfBuFal@gmail.com","firstName":"gKGbBfBuFal","lastName":"gKGbBfBuFal"}
  03:21:02.279 [front-end] POST /addresses 200 - ms - -  (×62)
  03:21:02.411 [front-end] Received response: "{\"firstName\":\"HWsmCvxoMrNqX\",\"lastName\":\"HWsmCvxoMrNqX\",\"username\":\"HWsmCvxoMrNqX\",\"id\":\"673ff884b0df5c00019b1f0d\",\"_links\
  03:21:02.491 [front-end] Order response: {"timestamp":1732245662488,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×13)
  03:21:03.084 [carts] 2024-11-22 03:21:03.083 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/dump || /dump.json],methods=[GET],produces=[application/
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  03:21:04.667 [user] ts=2024-11-22T03:21:04.666811852Z caller=middlewares.go:46 method=Register username=vpxxpRNxF email=vpxxpRNxF@gmail.com took=1.013941ms
  03:21:07.798 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×9)
  03:21:09.390 [carts] 2024-11-22 03:21:09.390 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'configurationPropertiesRebinder': registering wi
  03:21:12.988 [carts] 2024-11-22 03:21:12.988 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  03:21:15.384 [carts] 2024-11-22 03:21:15.288 INFO [carts,3f5ded192e0aa198,2b329af2190446f0,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.CartsController : Merge carts reques  (×13)
  03:21:17.904 [front-end] Received response: "{\"firstName\":\"aZnbBrPviPwcYcC\",\"lastName\":\"aZnbBrPviPwcYcC\",\"username\":\"aZnbBrPviPwcYcC\",\"id\":\"673ff896b0df5c00019b1f3a\",\"_
  03:21:18.612 [queue-master] Received shipment task: 673ff896b0df5c00019b1f3b  (×49)
  03:21:18.809 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8aed94b9000069b438f","customerId":"673ff89db0df5c00019b1f52","customer":{"id":null,"firstName":"isaznhmc","
  03:21:19.500 [queue-master] 2024-11-22 03:21:19.500 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×27)
  03:21:20.204 [front-end] Order response: {"id":"673ff8b0d94b9000069b4395","customerId":"673ff8a0b0df5c00019b1f61","customer":{"id":null,"firstName":"qklQL","lastName":"qklQL","username"
  03:21:21.517 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b1d94b9000069b4399","customerId":"673ff89db0df5c00019b1f53","customer":{"id":null,"firstName":"EFvIPXnJWRP
  03:21:25.703 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b5d94b9000069b439c","customerId":"673ff8a0b0df5c00019b1f5e","customer":{"id":null,"firstName":"qYmtssHEvF"
  03:21:28.688 [carts-db] {"t":{"$date":"2024-11-22T03:21:28.688+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224568
  03:21:34.025 [user] ts=2024-11-22T03:21:34.025362573Z caller=middlewares.go:46 method=Register username=sKNBT email=sKNBT@gmail.com took=982.453µs
  03:21:35.701 [front-end] Posting Customer: {"username":"mtTZvDvJ","password":"BtPgLRCi","email":"mtTZvDvJ@gmail.com","firstName":"mtTZvDvJ","lastName":"mtTZvDvJ"}
  03:21:37.306 [front-end] Order response: {"id":"673ff8c1d94b9000069b43a4","customerId":"673ff8a2b0df5c00019b1f6f","customer":{"id":null,"firstName":"YOkVqshziuS","lastName":"YOkVqshziuS
  03:21:40.261 [front-end] Order response: {"id":"673ff8c4d94b9000069b43a7","customerId":"673ff8a5b0df5c00019b1f74","customer":{"id":null,"firstName":"pMqcnDbPZ","lastName":"pMqcnDbPZ","u
  03:21:43.598 [user] ts=2024-11-22T03:21:43.598237387Z caller=middlewares.go:46 method=Register username=espLdeEx email=espLdeEx@gmail.com took=942.397µs
  03:21:45.861 [front-end] Order response: {"id":"673ff8c9d94b9000069b43ab","customerId":"673ff8abb0df5c00019b1f8d","customer":{"id":null,"firstName":"xlSpYB","lastName":"xlSpYB","usernam
  03:21:50.933 [front-end] Received response: "{\"firstName\":\"mtTZvDvJ\",\"lastName\":\"mtTZvDvJ\",\"username\":\"mtTZvDvJ\",\"id\":\"673ff8bfb0df5c00019b1fb8\",\"_links\":{\"addresses\
  03:21:55.069 [user] ts=2024-11-22T03:21:55.069222744Z caller=middlewares.go:46 method=Register username=UyPmLD email=UyPmLD@gmail.com took=998.258µs
  03:21:56.558 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8d4d94b9000069b43b5","customerId":"673ff8c0b0df5c00019b1fbc","customer":{"id":null,"firstName":"DXXEAuEZfGx
  03:21:57.860 [front-end] Order response: {"id":"673ff8d5d94b9000069b43b8","customerId":"673ff8c2b0df5c00019b1fbe","customer":{"id":null,"firstName":"otqrpqrI","lastName":"otqrpqrI","use

## p0205
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T07:00:09.781Z
```
{"timestamp":1731913209781791200,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  07:00:09.196 [frontend] request started  (×6)
  07:00:09.196 [frontend] placing order
  07:00:09.199 [frontend] view user cart
  07:00:09.228 [frontend] setting currency
  07:00:09.228 [frontend] request complete  (×6)
  07:00:09.231 [frontend] home
  07:00:09.238 [frontend] order placed
  07:00:09.276 [frontend] ENV_PLATFORM is: aws
  07:00:09.437 [frontend] serving product page  (×2)
All services, 30 seconds either side (sampled):
  06:59:39.869 [frontend] request started  (×290)
  06:59:39.871 [currencyservice] Getting supported currencies...  (×249)
  06:59:39.886 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', 'L9ECAV7KIM', '6E92ZMYYFZ', '2ZYFJ3GM2N', '1YMWWN1N4O']  (×215)
  06:59:39.896 [adservice] received ad request (context_words=[accessories])  (×44)
  06:59:40.215 [frontend] adding to cart  (×24)
  06:59:40.547 [adservice] received ad request (context_words=[hair, beauty])  (×21)
  06:59:41.214 [frontend] home  (×29)
  06:59:44.082 [frontend] setting currency  (×18)
  06:59:48.128 [frontend] placing order  (×9)
  06:59:48.180 [paymentservice] Transaction processed: visa ending 3454 Amount: JPY109185.896507681  (×3)
  06:59:48.184 [shippingservice] [ShipOrder] completed request  (×9)
  06:59:48.194 [checkoutservice] order confirmation email sent to "ericalucero@example.org"
  06:59:54.192 [checkoutservice] order confirmation email sent to "douglasgaines@example.net"
  07:00:00.370 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"575","nanos":145015481},"credit_card":{"credit_card_number":"40109138676549  (×3)
  07:00:00.385 [checkoutservice] order confirmation email sent to "katiegordon@example.com"
  07:00:01.971 [paymentservice] Transaction processed: visa ending 6010 Amount: GBP1629.346329924
  07:00:09.235 [emailservice] A request to send order confirmation email to margaretthomas@example.net has been received.
  07:00:20.297 [checkoutservice] order confirmation email sent to "xbrandt@example.org"
  07:00:24.979 [paymentservice] Transaction processed: visa ending 0279 Amount: EUR299.831932774  (×2)
  07:00:30.477 [checkoutservice] span hipstershop.EmailService/SendOrderConfirmation failed with gRPC status 14  (×2)
  07:00:32.546 [emailservice] Profiler disabled.  (×2)
  07:00:34.600 [checkoutservice] failed to send order confirmation to "pateldennis@example.net": rpc error: code = Unavailable desc = no healthy upstream

## p0797
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-service, 2024-12-08T08:40:29.532Z
```
{"timestamp":1733647229532260900,"container_name":"ts-order-service","pod_name":"ts-order-service-7596478c9d-lv9n7","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-08 08:40:29.531 ERROR 1 --- [io-12031-exec-7] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalArgumentException: Invalid UUID string: ] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  08:39:42.513 [ts-order-service] 2024-12-08 08:39:42.513 INFO 1 --- [io-12031-exec-4] order.service.OrderServiceImpl : [Order Service][Order Create] Price: 50.0
  08:39:55.020 [ts-order-service] 2024-12-08 08:39:55.020 INFO 1 --- [io-12031-exec-5] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sun Dec 08 00:00:00   (×3)
  08:39:55.022 [ts-order-service] 2024-12-08 08:39:55.022 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×3)
  08:39:55.068 [ts-order-service] 2024-12-08 08:39:55.067 INFO 1 --- [io-12031-exec-6] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024  (×5)
  08:39:55.069 [ts-order-service] 2024-12-08 08:39:55.069 INFO 1 --- [io-12031-exec-6] order.service.OrderServiceImpl : Left ticket info is empty  (×5)
  08:39:55.381 [ts-order-service] 2024-12-08 08:39:55.380 INFO 1 --- [o-12031-exec-10] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024
  08:39:55.383 [ts-order-service] 2024-12-08 08:39:55.382 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is empty
  08:40:29.519 [ts-order-service] 2024-12-08 08:40:29.519 INFO 1 --- [io-12031-exec-7] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 
All services, 30 seconds either side (sampled):
  08:40:01.012 [ts-auth-service] 2024-12-08 08:40:01.012 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×2)
  08:40:01.207 [ts-route-service] 2024-12-08 08:40:01.206 INFO 1 --- [io-11178-exec-2] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×139)
  08:40:01.254 [ts-price-service] 2024-12-08 08:40:01.254 INFO 1 --- [io-16579-exec-8] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×17)
  08:40:01.282 [ts-basic-service] 2024-12-08 08:40:01.282 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×9)
  08:40:01.343 [ts-order-other-service] 2024-12-08 08:40:01.342 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GM  (×30)
  08:40:01.457 [ts-travel2-service] 2024-12-08 08:40:01.457 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: 0b23bd3e-876a-4af3-b920-c50a90c90b0  (×4)
  08:40:02.773 [ts-price-service] 2024-12-08 08:40:02.773 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×2)
  08:40:02.886 [ts-travel2-service] 2024-12-08 08:40:02.886 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×24)
  08:40:02.975 [ts-travel2-service] 2024-12-08 08:40:02.975 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×24)
  08:40:04.169 [ts-auth-mongo] {"t":{"$date":"2024-12-08T08:40:04.169+00:00"},"s":"I", "c":"NETWORK", "id":22944, "ctx":"conn32","msg":"Connection ended","attr":{"remote":"127.0.0.6:60305","u  (×3)
  08:40:08.025 [ts-travel-service] 2024-12-08 08:40:08.024 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d  (×17)
  08:40:09.733 [ts-order-other-mongo] {"t":{"$date":"2024-12-08T08:40:09.732+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364720
  08:40:09.978 [ts-config-mongo] {"t":{"$date":"2024-12-08T08:40:09.978+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364720
  08:40:12.483 [ts-auth-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/  (×2)
  08:40:15.284 [ts-auth-service] 2024-12-08 08:40:15.284 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default  (×2)
  08:40:26.048 [ts-basic-service] 2024-12-08 08:40:26.047 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×3)
  08:40:29.598 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:16:40:29 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 500 210 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Apple  (×2)
  08:40:33.625 [ts-travel-service] 2024-12-08 08:40:33.625 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×6)
  08:40:33.687 [ts-basic-service] 2024-12-08 08:40:33.687 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe  (×3)
  08:40:33.757 [ts-seat-service] 2024-12-08 08:40:33.757 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×6)
  08:40:33.857 [ts-order-service] 2024-12-08 08:40:33.857 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sun Dec 08 00:00:00 GMT 2024  (×4)
  08:40:35.879 [ts-auth-service] 2024-12-08 08:40:35.878 INFO 1 --- [ main] o.apache.catalina.core.StandardService : Starting service [Tomcat]  (×2)
  08:40:41.288 [ts-auth-service] 2024-12-08 08:40:41.287 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClust  (×2)
  08:40:42.680 [ts-order-other-service] 2024-12-08 08:40:42.679 INFO 1 --- [io-12032-exec-8] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 
  08:40:43.529 [ts-travel-service] 2024-12-08 08:40:43.529 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×3)
  08:40:43.818 [ts-travel-service] 2024-12-08 08:40:43.817 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×2)
  08:40:51.079 [ts-auth-service] 2024-12-08 08:40:51.079 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/{userId}],methods=[DELETE]}" onto public org.sprin
  08:40:53.389 [ts-auth-service] 2024-12-08 08:40:53.389 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  08:40:53.392 [ts-auth-service] 2024-12-08 08:40:53.392 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  08:40:54.487 [ts-auth-service] 2024-12-08 08:40:54.486 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.embedded.A

## p0322
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:21:02.411Z
```
{"timestamp":1732245662411375900,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"firstName\\\":\\\"HWsmCvxoMrNqX\\\",\\\"lastName\\\":\\\"HWsmCvxoMrNqX\\\",\\\"username\\\":\\\"HWsmCvxoMrNqX\\\",\\\"id\\\":\\\"673ff884b0df5c00019b1f0d\\\",\\\"_links\\\":{\\\"addresses\\\":{\\\"href\\\":\\\"http://user/customers/673ff884b0df5c00019b1f0d/addresses\\\"},\\\"cards\\\":{\\\"href\\\":\\\"http://user/customers/673ff884b0df5c00019b1f0d/cards\\\"},\\\"customer\\\":{\\\"href\\\":\\\"http://user/customers/673ff884b0df5c00019b1f0d\\\"…"}
```
Same service, the 2 minutes before (oldest first):
  03:21:02.119 [front-end] Posting Customer: {"username":"gKGbBfBuFal","password":"jTPEzN","email":"gKGbBfBuFal@gmail.com","firstName":"gKGbBfBuFal","lastName":"gKGbBfBuFal"}
  03:21:02.126 [front-end] { id: '673ff89eb0df5c00019b1f54' }
  03:21:02.126 [front-end] 673ff89eb0df5c00019b1f54
  03:21:02.126 [front-end] Merging carts for customer id: 673ff89eb0df5c00019b1f54 and session id: rrS1mEHOo4YitGXARYyweWtoOysIjwDD
  03:21:02.133 [front-end] GET /catalogue 200 - ms - -
  03:21:02.165 [front-end] Carts merged.
  03:21:02.165 [front-end] set cookie673ff89eb0df5c00019b1f54
  03:21:02.166 [front-end] Sent cookies.
  03:21:02.168 [front-end] POST /register 200 46.470 ms - 33
  03:21:02.270 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff896b0df5c00019b1f37"}
  03:21:02.279 [front-end] POST /addresses 200 - ms - -
  03:21:02.283 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ff896b0df5c00019b1f37"}
  03:21:02.291 [front-end] POST /cards 200 - ms - -
  03:21:02.338 [front-end] Attempting to delete cart for user: 673ff896b0df5c00019b1f37
  03:21:02.366 [front-end] User cart deleted with status: 503
  03:21:02.368 [front-end] DELETE /cart 503 - ms - -
  03:21:02.375 [front-end] Attempting to add to cart: {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","quantity":1}
  03:21:02.383 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  03:21:02.383 [front-end] POST to carts: http://carts/carts/673ff896b0df5c00019b1f37/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  03:21:02.403 [front-end] Request received with body: {}
All services, 30 seconds either side (sampled):
  03:20:32.428 [catalogue] ts=2024-11-22T03:20:32Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=3.433368ms  (×61)
  03:20:32.747 [front-end] Request received with body: {}  (×59)
  03:20:32.807 [front-end] Order response: {"timestamp":1732245632804,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×38)
  03:20:33.935 [user] ts=2024-11-22T03:20:33.935694632Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff87bb0df5c00019b1efc took=1.962293ms  (×59)
  03:20:34.536 [front-end] Received response: "{\"firstName\":\"burOTnWrVFcFcR\",\"lastName\":\"burOTnWrVFcFcR\",\"username\":\"burOTnWrVFcFcR\",\"id\":\"673ff86eb0df5c00019b1ed0\",\"_lin
  03:20:37.986 [front-end] Posting Customer: {"username":"WwpBLC","password":"ngXKNthnRa","email":"WwpBLC@gmail.com","firstName":"WwpBLC","lastName":"WwpBLC"}
  03:20:41.044 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×5)
  03:20:43.389 [carts] 2024-11-22 03:20:43.389 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
  03:20:48.998 [front-end] Posting Customer: {"username":"asYAoymkBkzj","password":"aSSKLjGTT","email":"asYAoymkBkzj@gmail.com","firstName":"asYAoymkBkzj","lastName":"asYAoymkBkzj"}
  03:20:51.541 [front-end] Received response: "{\"firstName\":\"MKGIsEbVYi\",\"lastName\":\"MKGIsEbVYi\",\"username\":\"MKGIsEbVYi\",\"id\":\"673ff87eb0df5c00019b1eff\",\"_links\":{\"addr
  03:20:56.307 [front-end] Posting Customer: {"username":"TxflHMpaWteY","password":"HuykDEusv","email":"TxflHMpaWteY@gmail.com","firstName":"TxflHMpaWteY","lastName":"TxflHMpaWteY"}
  03:20:59.685 [carts] 2024-11-22 03:20:59.685 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+json
  03:20:59.785 [carts] 2024-11-22 03:20:59.785 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[GET],produces=[  (×2)
  03:20:59.886 [carts] 2024-11-22 03:20:59.886 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http.
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public jav
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  03:21:06.274 [front-end] Received response: "{\"firstName\":\"WwpBLC\",\"lastName\":\"WwpBLC\",\"username\":\"WwpBLC\",\"id\":\"673ff885b0df5c00019b1f10\",\"_links\":{\"addresses\":{\"h
  03:21:09.238 [front-end] Posting Customer: {"username":"pMqcnDbPZ","password":"kxLei","email":"pMqcnDbPZ@gmail.com","firstName":"pMqcnDbPZ","lastName":"pMqcnDbPZ"}
  03:21:12.194 [front-end] Posting Customer: {"username":"yXmVwShR","password":"JrCRXcAWLQ","email":"yXmVwShR@gmail.com","firstName":"yXmVwShR","lastName":"yXmVwShR"}
  03:21:14.190 [carts] 2024-11-22 03:21:14.190 INFO [carts,,,] 7 --- [p-nio-80-exec-3] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization complet
  03:21:16.388 [carts] 2024-11-22 03:21:16.294 INFO [carts,4f4200e92a2346f2,c605b8bba205809d,false] 7 --- [-nio-80-exec-10] org.mongodb.driver.connection : Opened connection [connecti  (×8)
  03:21:18.602 [orders] 2024-11-22 03:21:18.602 INFO [orders,40393c2387463fc4,20a8cb1f4ece78de,false] 6 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Received payment re  (×11)
  03:21:18.708 [front-end] Order response: {"id":"673ff8aed94b9000069b438d","customerId":"673ff891b0df5c00019b1f2a","customer":{"id":null,"firstName":"asYAoymkBkzj","lastName":"asYAoymkBk
  03:21:19.450 [front-end] Received response: "{\"firstName\":\"gKGbBfBuFal\",\"lastName\":\"gKGbBfBuFal\",\"username\":\"gKGbBfBuFal\",\"id\":\"673ff89eb0df5c00019b1f54\",\"_links\":{\"a
  03:21:20.103 [front-end] Order response: {"id":"673ff8b0d94b9000069b4394","customerId":"673ff899b0df5c00019b1f44","customer":{"id":null,"firstName":"fnNnBGFeZwjz","lastName":"fnNnBGFeZw
  03:21:20.805 [front-end] Order response: {"id":"673ff8b0d94b9000069b4398","customerId":"673ff897b0df5c00019b1f3d","customer":{"id":null,"firstName":"PvCLeeg","lastName":"PvCLeeg","usern
  03:21:24.101 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b4d94b9000069b439b","customerId":"673ff89eb0df5c00019b1f57","customer":{"id":null,"firstName":"UFhesIA","l
  03:21:28.398 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732245688395,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde

## p0828
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-basic-service, 2024-12-08T12:14:57.504Z
```
{"timestamp":1733660097504257000,"container_name":"ts-basic-service","pod_name":"ts-basic-service-7c46c5c98f-58w5c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-08 12:14:57.502  INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl  : [Basic Information Service][Check Station Exists] Station Name: Shang Hai"}
```
Same service, the 2 minutes before (oldest first):
  12:14:54.747 [ts-basic-service] 2024-12-08 12:14:54.747 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×5)
  12:14:54.837 [ts-basic-service] 2024-12-08 12:14:54.837 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×2)
  12:14:54.843 [ts-basic-service] 2024-12-08 12:14:54.843 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S
  12:14:54.848 [ts-basic-service] 2024-12-08 12:14:54.848 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO
  12:14:54.859 [ts-basic-service] 2024-12-08 12:14:54.859 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：a3f256c1-0e
  12:14:54.868 [ts-basic-service] 2024-12-08 12:14:54.868 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  12:14:54.868 [ts-basic-service] 2024-12-08 12:14:54.868 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2
  12:14:54.876 [ts-basic-service] 2024-12-08 12:14:54.876 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i
  12:14:54.877 [ts-basic-service] 2024-12-08 12:14:54.876 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×4)
  12:14:54.886 [ts-basic-service] 2024-12-08 12:14:54.886 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : startingPlaceId : nanjingendPlaceId : shanghai
  12:14:54.886 [ts-basic-service] 2024-12-08 12:14:54.886 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 2
  12:14:54.886 [ts-basic-service] 2024-12-08 12:14:54.886 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : route.getDistances().size : 3
All services, 30 seconds either side (sampled):
  12:14:27.506 [ts-auth-service] 2024-12-08 12:14:27.506 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×10)
  12:14:27.547 [ts-travel-service] 2024-12-08 12:14:27.546 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, tr  (×15)
  12:14:27.583 [ts-order-service] 2024-12-08 12:14:27.583 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is empty  (×2)
  12:14:27.691 [ts-basic-service] 2024-12-08 12:14:27.691 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×4)
  12:14:27.768 [ts-travel2-service] 2024-12-08 12:14:27.768 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×125)
  12:14:27.802 [ts-basic-service] 2024-12-08 12:14:27.802 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×11)
  12:14:27.913 [ts-basic-service] 2024-12-08 12:14:27.913 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×7)
  12:14:28.025 [ts-travel-service] 2024-12-08 12:14:28.025 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×16)
  12:14:28.313 [ts-travel-service] 2024-12-08 12:14:28.313 INFO 1 --- [io-12346-exec-8] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×32)
  12:14:29.720 [ts-seat-service] 2024-12-08 12:14:29.719 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×9)
  12:14:31.993 [ts-basic-service] 2024-12-08 12:14:31.993 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69  (×5)
  12:14:32.260 [ts-food-service] 2024-12-08 12:14:32.260 INFO 1 --- [io-18856-exec-4] foodsearch.service.FoodServiceImpl : data=2021-07-14 start=Shang Hai end=Su Zhou tripid=D1345  (×7)
  12:14:32.343 [ts-preserve-service] 2024-12-08 12:14:32.343 INFO 1 --- [io-14568-exec-3] preserve.service.PreserveServiceImpl : [Preserve Other Service][Check Security] Checking....  (×2)
  12:14:32.393 [ts-security-service] 2024-12-08 12:14:32.393 INFO 1 --- [io-11188-exec-8] security.service.SecurityServiceImpl : [Security Service] Max In One Hour: 2147483647 Max Not Use: 21474836  (×2)
  12:14:32.475 [ts-preserve-service] 2024-12-08 12:14:32.475 INFO 1 --- [io-14568-exec-3] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 3] TripId: D1345  (×2)
  12:14:32.549 [ts-basic-service] 2024-12-08 12:14:32.549 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：f3d4d4ef-69
  12:14:32.776 [ts-travel-service] 2024-12-08 12:14:32.776 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×4)
  12:14:33.049 [ts-price-service] 2024-12-08 12:14:33.049 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×3)
  12:14:33.178 [ts-order-service] 2024-12-08 12:14:33.177 INFO 1 --- [io-12031-exec-5] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at   (×2)
  12:14:33.213 [ts-preserve-service] 2024-12-08 12:14:33.213 INFO 1 --- [io-14568-exec-3] preserve.service.PreserveServiceImpl : [Preserve Service][Add food Order] Creating....
  12:14:33.996 [ts-travel2-service] 2024-12-08 12:14:33.996 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×3)
  12:14:41.483 [ts-admin-basic-info-service] 2024-12-08 12:14:41.482 INFO 1 --- [io-18767-exec-2] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×11)
  12:14:54.279 [ts-travel-service] 2024-12-08 12:14:54.279 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=nanjing)  (×7)
  12:15:00.151 [ts-order-service] 2024-12-08 12:15:00.151 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=625927415, 
  12:15:11.495 [ts-train-mongo] {"t":{"$date":"2024-12-08T12:15:11.495+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366011
  12:15:12.154 [ts-config-mongo] {"t":{"$date":"2024-12-08T12:15:12.153+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173366011
  12:15:14.389 [ts-order-service] 2024-12-08 12:15:14.389 INFO 1 --- [io-12031-exec-6] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 137
  12:15:14.682 [ts-consign-service] 2024-12-08 12:15:14.682 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : SAVE consign result : ConsignRecord(id=d336e26e-da69-4d45-b088-10a456b  (×2)
  12:15:24.323 [ts-auth-service] 2024-12-08 12:15:24.322 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice

## p0716
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice2, 2021-08-14T08:20:17.500Z
```
{"service":"logservice2","message":"2021-08-14 08:20:17,500 | INFO | 0.0.0.2 | 172.17.0.3 | logservice2 | 1bffa2f177130bc1 | request http://0.0.0.3:9384/login_model_implement and param={'uuid': '66dd792c-fc95-11eb-8302-0242ac110003', 'user_id': 'yeMqQbFt'}"}
```
Same service, the 2 minutes before (oldest first):
  08:20:14.859 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×3)
  08:20:14.860 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×3)
  08:20:14.860 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '6523a66a-fc95-11eb-94a8-0242ac110004', 'user_id': 'dzcaqmiU'}  (×4)
  08:20:15.314 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×2)
  08:20:15.314 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×2)
  08:20:16.710 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  08:20:16.711 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  08:20:16.711 [logservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '665a1550-fc95-11eb-8427-0242ac110003'}  (×2)
All services, 30 seconds either side (sampled):
  08:19:47.507 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×46)
  08:19:47.761 [redisservice1] INFO redis write success  (×88)
  08:19:47.981 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×42)
  08:19:48.216 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×51)
  08:19:48.357 [redisservice2] INFO service accept, status_code: 200  (×49)
  08:19:48.709 [webservice2] INFO complete information: {'uuid': '55d381c6-fc95-11eb-8408-0242ac110004', 'user_id': 'HodXCbQS'}  (×44)
  08:19:49.615 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×41)
  08:19:49.819 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×33)
  08:19:51.632 [mobservice2] INFO info 576453bc-fc95-11eb-90ff-0242ac110004:rwdmTblM write success
  08:19:54.521 [dbservice1] INFO 58db539e-fc95-11eb-b39a-0242ac110003-BYtUlIXT-*I$93migj8.c token generate success token=MTYyODkwMDM5NC41MjA4NzQ3OjU4ZGI1MzllLWZjOTUtMTFlYi1iMzlhLTAyNDJhYzE
  08:19:56.833 [dbservice1] INFO 5a5589b0-fc95-11eb-b778-0242ac110004-UVDQSlfP-pIa$R%rCt-+4 token generate success token=MTYyODkwMDM5Ni44MzI5NDE1OjVhNTU4OWIwLWZjOTUtMTFlYi1iNzc4LTAyNDJhYzE
  08:20:00.213 [dbservice2] INFO 5c562c60-fc95-11eb-a227-0242ac110004-PtpxFCHR-o#ehxpV6iN_T token generate success token=MTYyODkwMDQwMC4yMTI1NTE6NWM1NjJjNjAtZmM5NS0xMWViLWEyMjctMDI0MmFjMTE
  08:20:02.787 [dbservice1] INFO 5ddc2bca-fc95-11eb-a7e6-0242ac110004-CzojFELq-MU6*h.QSdBWf token generate success token=MTYyODkwMDQwMi43ODc2MDEyOjVkZGMyYmNhLWZjOTUtMTFlYi1hN2U2LTAyNDJhYzE
  08:20:05.510 [dbservice1] INFO 5f7a9df4-fc95-11eb-84c4-0242ac110004-DQJsnMlT-Nc3Z_Ei.#d7& token generate success token=MTYyODkwMDQwNS41MTAzMjg6NWY3YTlkZjQtZmM5NS0xMWViLTg0YzQtMDI0MmFjMTE
  08:20:08.226 [dbservice1] INFO 6100fc68-fc95-11eb-9503-0242ac110003-VbMWntAq-T2bc)3h}>4-M token generate success token=MTYyODkwMDQwOC4yMjU4OTkyOjYxMDBmYzY4LWZjOTUtMTFlYi05NTAzLTAyNDJhYzE
  08:20:10.777 [dbservice1] INFO 629cf946-fc95-11eb-ad2c-0242ac110003-FpcKvnCm-UjT*)>?iS97{ token generate success token=MTYyODkwMDQxMC43Nzc0ODk3OjYyOWNmOTQ2LWZjOTUtMTFlYi1hZDJjLTAyNDJhYzE
  08:20:13.333 [dbservice2] INFO 6425bdc0-fc95-11eb-ae88-0242ac110004-PYaoLpfS-bW9F%P+AUv_Q token generate success token=MTYyODkwMDQxMy4zMzMyODg3OjY0MjViZGMwLWZjOTUtMTFlYi1hZTg4LTAyNDJhYzE
  08:20:16.173 [dbservice1] INFO 65c9aa1a-fc95-11eb-bea2-0242ac110004-jliMGRSf-@UO%!NH}$bsm token generate success token=MTYyODkwMDQxNi4xNzMzMTM5OjY1YzlhYTFhLWZjOTUtMTFlYi1iZWEyLTAyNDJhYzE
  08:20:18.719 [dbservice1] INFO 67519924-fc95-11eb-8ebd-0242ac110004-SBgdrmlT-HkpM0UVa+&9- token generate success token=MTYyODkwMDQxOC43MTg2OTY2OjY3NTE5OTI0LWZjOTUtMTFlYi04ZWJkLTAyNDJhYzE
  08:20:21.333 [dbservice1] INFO 68e9d454-fc95-11eb-967e-0242ac110004-CapPHYsG-_8-3dh}qnA>K token generate success token=MTYyODkwMDQyMS4zMzI5OTQyOjY4ZTlkNDU0LWZjOTUtMTFlYi05NjdlLTAyNDJhYzE
  08:20:23.842 [mobservice1] INFO info 6aa58644-fc95-11eb-b607-0242ac110004:tcvLYMig write success
  08:20:26.669 [mobservice2] INFO info 6c55d048-fc95-11eb-9439-0242ac110004:nqLzRCkG write success
  08:20:29.487 [mobservice1] INFO info 6e0c7842-fc95-11eb-9871-0242ac110004:pKzgewir write success
  08:20:31.758 [mobservice1] INFO info 6f6661ee-fc95-11eb-a88f-0242ac110003:vMrkdEDG write success
  08:20:34.302 [mobservice2] INFO info 70e5fb56-fc95-11eb-bbed-0242ac110003:PadWlNwG write success
  08:20:36.954 [mobservice2] INFO info 7278bcec-fc95-11eb-bef8-0242ac110004:riyTUAVs write success
  08:20:40.336 [dbservice1] INFO 744a92de-fc95-11eb-b791-0242ac110004-AMFryZUz-jrK#m*:OpaoS token generate success token=MTYyODkwMDQ0MC4zMzY0NjgyOjc0NGE5MmRlLWZjOTUtMTFlYi1iNzkxLTAyNDJhYzE
  08:20:47.277 [dbservice2] INFO 784ed052-fc95-11eb-878a-0242ac110003-CyDlcYMP-RIuS(51-$4.P token generate success token=MTYyODkwMDQ0Ny4yNzcxOTE6Nzg0ZWQwNTItZmM5NS0xMWViLTg3OGEtMDI0MmFjMTE

## p0387
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:21.584Z
```
{"timestamp":1732247181584707000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Merging carts for customer id: 673ffe8db0df5c00019b3180 and session id: DJgh-aP7GXWW3SFEl2AnBT8Zgj4ojU2q"}
```
Same service, the 2 minutes before (oldest first):
  03:46:20.397 [front-end] User cart deleted with status: 503
  03:46:20.400 [front-end] DELETE /cart 503 - ms - -
  03:46:20.406 [front-end] Attempting to add to cart: {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","quantity":1}
  03:46:20.413 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with 
  03:46:20.413 [front-end] POST to carts: http://carts/carts/673ffe87b0df5c00019b316c/items body: {"itemId":"510a0d7e-8e83-4193-b483-e27e09ddc34d","unitPrice":15}
  03:46:20.428 [front-end] Request received with body: {}
  03:46:20.433 [front-end] Received response: "{\"firstName\":\"DHCGNkyEyawp\",\"lastName\":\"DHCGNkyEyawp\",\"username\":\"DHCGNkyEyawp\",\"id\":\"673ffe74b0df5c00019b3136\",\"_links\":{
  03:46:20.433 [front-end] GET Request to: http://user/customers/673ffe74b0df5c00019b3136/addresses  (×2)
  03:46:20.439 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe7db0df5c00019b314c\",\"_links\":{\"
  03:46:20.439 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff
  03:46:20.439 [front-end] [ undefined, undefined ]
  03:46:20.439 [front-end] Posting Order: {"customer":"http://user/customers/673ffe74b0df5c00019b3136","address":"http://user/addresses/673ffe7db0df5c00019b314b","card":"http://user/cards
  03:46:20.470 [front-end] POST /cart 500 62.300 ms - 64
  03:46:20.514 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732247180511,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:46:20.514 [front-end] Order response: {"timestamp":1732247180511,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:46:20.516 [front-end] POST /orders 500 - ms - -
  03:46:21.578 [front-end] Posting Customer: {"username":"SaDANnAadkaT","password":"jyIUfCc","email":"SaDANnAadkaT@gmail.com","firstName":"SaDANnAadkaT","lastName":"SaDANnAadkaT"}
  03:46:21.584 [front-end] { id: '673ffe8db0df5c00019b3180' }
  03:46:21.584 [front-end] 673ffe8db0df5c00019b3180
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×25)
  03:46:10.147 [front-end] 673ffe82b0df5c00019b315b  (×37)
  03:46:10.351 [catalogue] ts=2024-11-22T03:46:10Z caller=logging.go:85 method=Health result=2 took=27.37µs  (×28)
  03:46:10.817 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe78b0df5c00019b3141\",\"_links\":{\"  (×40)
  03:46:10.843 [payment] ts=2024-11-22T03:46:10Z caller=logging.go:40 method=Health result=1 took=7.196µs  (×28)
  03:46:10.940 [front-end] Received response: "{\"firstName\":\"jnTZDLVwW\",\"lastName\":\"jnTZDLVwW\",\"username\":\"jnTZDLVwW\",\"id\":\"673ffe65b0df5c00019b3100\",\"_links\":{\"address
  03:46:11.161 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673ffe79b0df5c00019b3143"}  (×42)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×42)
  03:46:11.318 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×5)
  03:46:12.141 [user] ts=2024-11-22T03:46:12.141108416Z caller=middlewares.go:46 method=Register username=VaPxY email=VaPxY@gmail.com took=1.01883ms
  03:46:12.669 [orders] 2024-11-22 03:46:12.668 ERROR [orders,,,] 6 --- [p-nio-80-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×22)
  03:46:14.786 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  03:46:15.206 [user] ts=2024-11-22T03:46:15.206068871Z caller=middlewares.go:46 method=Register username=GIUFZZyI email=GIUFZZyI@gmail.com took=1.199135ms
  03:46:16.945 [user] ts=2024-11-22T03:46:16.945426009Z caller=middlewares.go:46 method=Register username=ANUgD email=ANUgD@gmail.com took=1.061751ms
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:22.962 [user] ts=2024-11-22T03:46:22.961891483Z caller=middlewares.go:46 method=Register username=YNeGDXzX email=YNeGDXzX@gmail.com took=1.087598ms
  03:46:25.991 [user] ts=2024-11-22T03:46:25.991686067Z caller=middlewares.go:46 method=Register username=jAAETa email=jAAETa@gmail.com took=1.020993ms
  03:46:26.921 [user] ts=2024-11-22T03:46:26.921445594Z caller=middlewares.go:46 method=Register username=SGNMlFJX email=SGNMlFJX@gmail.com took=998.659µs
  03:46:28.865 [orders-db] {"t":{"$date":"2024-11-22T03:46:28.864+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224718
  03:46:30.040 [user] ts=2024-11-22T03:46:30.040199562Z caller=middlewares.go:46 method=Register username=hCQLZMhz email=hCQLZMhz@gmail.com took=1.097772ms
  03:46:30.678 [front-end] Received response: "{\"firstName\":\"jwQwxgI\",\"lastName\":\"jwQwxgI\",\"username\":\"jwQwxgI\",\"id\":\"673ffe80b0df5c00019b315a\",\"_links\":{\"addresses\":{
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.099 [front-end] Posting Customer: {"username":"THBqBDDcBz","password":"PRiYTiQkw","email":"THBqBDDcBz@gmail.com","firstName":"THBqBDDcBz","lastName":"THBqBDDcBz"}
  03:46:40.280 [front-end] Posting Customer: {"username":"GFexg","password":"iTpJx","email":"GFexg@gmail.com","firstName":"GFexg","lastName":"GFexg"}
  03:46:42.343 [front-end] Posting Customer: {"username":"PscIdXcmCyQHmMr","password":"qvNYdZI","email":"PscIdXcmCyQHmMr@gmail.com","firstName":"PscIdXcmCyQHmMr","lastName":"PscIdXcmCyQHm
  03:46:47.377 [front-end] Received response: "{\"firstName\":\"hCQLZMhz\",\"lastName\":\"hCQLZMhz\",\"username\":\"hCQLZMhz\",\"id\":\"673ffe96b0df5c00019b3197\",\"_links\":{\"addresses\
  03:46:50.786 [front-end] Received response: "{\"firstName\":\"WrRpd\",\"lastName\":\"WrRpd\",\"username\":\"WrRpd\",\"id\":\"673ffe94b0df5c00019b3193\",\"_links\":{\"addresses\":{\"href
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon

## p0345
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:25:04.910Z
```
{"timestamp":1732245904910377000,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:25:04.909847757Z caller=middlewares.go:134 method=GetCards id=673ff97fb0df5c00019b2209 result=1 took=637.361µs"}
```
Same service, the 2 minutes before (oldest first):
  03:25:03.351 [user] ts=2024-11-22T03:25:03.351408489Z caller=middlewares.go:134 method=GetCards id=673ff982b0df5c00019b2213 result=1 took=626.489µs  (×2)
  03:25:03.564 [user] ts=2024-11-22T03:25:03.564756398Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ff98ab0df5c00019b222f took=1.817281ms
  03:25:03.606 [user] ts=2024-11-22T03:25:03.605964487Z caller=middlewares.go:75 method=GetUsers id=673ff978b0df5c00019b21ee result=1 took=882.495µs  (×10)
  03:25:03.623 [user] ts=2024-11-22T03:25:03.62280133Z caller=middlewares.go:104 method=GetAddresses id=673ff981b0df5c00019b220f result=1 took=828.647µs  (×3)
  03:25:03.623 [user] ts=2024-11-22T03:25:03.623768454Z caller=middlewares.go:134 method=GetCards id=673ff981b0df5c00019b2210 result=1 took=1.120049ms
  03:25:03.625 [user] ts=2024-11-22T03:25:03.625771295Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff98ab0df5c00019b222f took=1.82026ms
  03:25:04.151 [user] ts=2024-11-22T03:25:04.150939624Z caller=middlewares.go:46 method=Register username=JYHlaVyeKunja email=JYHlaVyeKunja@gmail.com took=967.059µs
  03:25:04.554 [user] ts=2024-11-22T03:25:04.554073844Z caller=middlewares.go:75 method=GetUsers id=673ff97fb0df5c00019b2206 result=1 took=1.024013ms
All services, 30 seconds either side (sampled):
  03:24:35.504 [front-end] Request received with body: {}  (×58)
  03:24:35.537 [front-end] Posting Customer: {"username":"CpCKDCyiSIqIu","password":"qNtgDn","email":"CpCKDCyiSIqIu@gmail.com","firstName":"CpCKDCyiSIqIu","lastName":"CpCKDCyiSIqIu"}
  03:24:35.548 [queue-master] 2024-11-22 03:24:35.548 INFO 6 --- [ool-6-thread-25] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×126)
  03:24:35.847 [payment] ts=2024-11-22T03:24:35Z caller=logging.go:29 method=Authorise result=true took=849ns  (×26)
  03:24:36.925 [front-end] Received response: "{\"firstName\":\"qkDtJyihfFNun\",\"lastName\":\"qkDtJyihfFNun\",\"username\":\"qkDtJyihfFNun\",\"id\":\"673ff963b0df5c00019b21b6\",\"_links\
  03:24:37.244 [front-end] Attempting to delete cart for user: 673ff96cb0df5c00019b21c7  (×62)
  03:24:37.843 [payment] ts=2024-11-22T03:24:37Z caller=logging.go:40 method=Health result=1 took=7.384µs  (×40)
  03:24:39.302 [carts] 2024-11-22 03:24:39.302 INFO [carts,6f72b5483a511bca,aa474909cf93e2f6,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.ItemsController : Did not find item.  (×19)
  03:24:41.346 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff979d94b9000069b4444","customerId":"673ff967b0df5c00019b21bc","customer":{"id":null,"firstName":"raoJiBLWBmn
  03:24:43.417 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732245883415,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×7)
  03:24:46.368 [front-end] Received response: "{\"firstName\":\"TIgbtPXVzxZDXw\",\"lastName\":\"TIgbtPXVzxZDXw\",\"username\":\"TIgbtPXVzxZDXw\",\"id\":\"673ff971b0df5c00019b21d7\",\"_lin
  03:24:47.662 [front-end] Order response: {"id":"673ff97fd94b9000069b4449","customerId":"673ff96ab0df5c00019b21c5","customer":{"id":null,"firstName":"fwPISWdy","lastName":"fwPISWdy","use
  03:24:49.930 [front-end] Posting Customer: {"username":"wwjWviWvLklhrtd","password":"pxbmb","email":"wwjWviWvLklhrtd@gmail.com","firstName":"wwjWviWvLklhrtd","lastName":"wwjWviWvLklhrtd
  03:24:55.497 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×4)
  03:24:56.464 [front-end] Posting Customer: {"username":"QSOYr","password":"qoJOWvJQs","email":"QSOYr@gmail.com","firstName":"QSOYr","lastName":"QSOYr"}
  03:24:59.136 [front-end] Posting Customer: {"username":"yIMtPQTOVjcmzU","password":"MhjhfC","email":"yIMtPQTOVjcmzU@gmail.com","firstName":"yIMtPQTOVjcmzU","lastName":"yIMtPQTOVjcmzU"}
  03:25:01.285 [front-end] Received response: "{\"firstName\":\"ZksJtiHSjg\",\"lastName\":\"ZksJtiHSjg\",\"username\":\"ZksJtiHSjg\",\"id\":\"673ff97db0df5c00019b21fe\",\"_links\":{\"addr
  03:25:03.376 [front-end] Order response: {"id":"673ff98fd94b9000069b4456","customerId":"673ff97cb0df5c00019b21fb","customer":{"id":null,"firstName":"evQVeD","lastName":"evQVeD","usernam
  03:25:05.187 [front-end] Posting Customer: {"username":"UTTIQvnNwPP","password":"ZSuCZPg","email":"UTTIQvnNwPP@gmail.com","firstName":"UTTIQvnNwPP","lastName":"UTTIQvnNwPP"}
  03:25:05.702 [front-end] Received response: "{\"firstName\":\"xlPHJmoyoiG\",\"lastName\":\"xlPHJmoyoiG\",\"username\":\"xlPHJmoyoiG\",\"id\":\"673ff977b0df5c00019b21ea\",\"_links\":{\"a
  03:25:07.178 [front-end] Received response: "{\"firstName\":\"wwjWviWvLklhrtd\",\"lastName\":\"wwjWviWvLklhrtd\",\"username\":\"wwjWviWvLklhrtd\",\"id\":\"673ff981b0df5c00019b2211\",\"_
  03:25:10.050 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff996d94b9000069b4461","customerId":"673ff982b0df5c00019b2215","customer":{"id":null,"firstName":"BsJSXkRiQqG
  03:25:12.267 [front-end] Posting Customer: {"username":"WdNLegpQMMkDw","password":"HhLCmONPg","email":"WdNLegpQMMkDw@gmail.com","firstName":"WdNLegpQMMkDw","lastName":"WdNLegpQMMkDw"}
  03:25:17.493 [front-end] Order response: {"id":"673ff99dd94b9000069b4466","customerId":"673ff988b0df5c00019b222a","customer":{"id":null,"firstName":"FFWgQR","lastName":"FFWgQR","usernam
  03:25:19.401 [user] ts=2024-11-22T03:25:19.401040868Z caller=middlewares.go:46 method=Register username=BecggAUt email=BecggAUt@gmail.com took=1.033398ms
  03:25:21.358 [front-end] Posting Customer: {"username":"KePXAo","password":"xHfJL","email":"KePXAo@gmail.com","firstName":"KePXAo","lastName":"KePXAo"}
  03:25:24.056 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9a4d94b9000069b446c","customerId":"673ff994b0df5c00019b224e","customer":{"id":null,"firstName":"yITGxslcXJr
  03:25:26.519 [front-end] Received response: "{\"firstName\":\"WdNLegpQMMkDw\",\"lastName\":\"WdNLegpQMMkDw\",\"username\":\"WdNLegpQMMkDw\",\"id\":\"673ff998b0df5c00019b2256\",\"_links\
  03:25:27.888 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff9a7d94b9000069b4471","customerId":"673ff995b0df5c00019b224f","customer":{"id":null,"firstName":"yymOaTlJZaA
  03:25:33.847 [front-end] Posting Customer: {"username":"wLqZk","password":"acsxqUFb","email":"wLqZk@gmail.com","firstName":"wLqZk","lastName":"wLqZk"}

## p0122
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:18:18.646Z
```
{"timestamp":1731907098646175500,"container_name":"adservice","pod_name":"adservice-574c5fd7b4-tmkhn","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"Stats enabled, but temporarily unavailable"}
```
Same service, the 2 minutes before (oldest first):
  05:17:38.742 [adservice] received ad request (context_words=[kitchen])  (×2)
  05:17:38.820 [adservice] received ad request (context_words=[])  (×2)
  05:17:40.210 [adservice] *** shutting down gRPC ads server since JVM is shutting down
  05:17:40.213 [adservice] *** server shut down
  05:17:43.747 [adservice] AdService starting.  (×2)
  05:17:43.839 [adservice] Stats enabled, but temporarily unavailable  (×2)
  05:17:43.840 [adservice] Tracing enabled but temporarily unavailable  (×2)
  05:17:43.841 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.  (×2)
  05:17:43.842 [adservice] Tracing enabled - Stackdriver exporter initialized.  (×2)
  05:17:45.449 [adservice] Exception in thread "main" java.io.IOException: Failed to bind to address 0.0.0.0/0.0.0.0:15000 at io.grpc.netty.NettyServer.start(NettyServer.java:333) at io.g  (×2)
  05:17:45.450 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
All services, 30 seconds either side (sampled):
  05:17:49.359 [frontend] request started  (×291)
  05:17:49.368 [cartservice] GetCartAsync called with userId=adf41e5f-12f6-4c40-88a0-a1bcf421e416  (×245)
  05:17:49.388 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 4  (×173)
  05:17:49.497 [frontend] adding to cart  (×28)
  05:17:49.541 [shippingservice] [GetQuote] received request  (×73)
  05:17:49.561 [checkoutservice] [PlaceOrder] user_id="82f11995-8adf-4db5-b1c6-416954168927" user_currency="CAD"
  05:17:49.589 [checkoutservice] payment went through (transaction_id: b8ee51d3-3b17-4fba-b69a-4f014013c8cc)  (×8)
  05:17:49.595 [cartservice] EmptyCartAsync called with userId=82f11995-8adf-4db5-b1c6-416954168927  (×8)
  05:17:49.604 [frontend] order placed  (×8)
  05:17:52.100 [frontend] ENV_PLATFORM is: aws  (×34)
  05:17:53.543 [adservice] AdService starting.  (×2)
  05:17:53.544 [adservice] Tracing enabled - Stackdriver exporter initialized.  (×2)
  05:17:55.239 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="EUR"  (×2)
  05:17:55.276 [emailservice] A request to send order confirmation email to alopez@example.org has been received.
  05:18:02.284 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"725","nanos":428863340},"credit_card":{"credit_card_number":"47716610325023  (×3)
  05:18:02.298 [checkoutservice] order confirmation email sent to "caseyhoward@example.com"
  05:18:22.550 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"GBP","units":"1521","nanos":300176901},"credit_card":{"credit_card_number":"4909740041071
  05:18:22.564 [checkoutservice] order confirmation email sent to "janetbrown@example.org"
  05:18:25.981 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"106183","nanos":826626688},"credit_card":{"credit_card_number":"48642226849  (×2)
  05:18:25.994 [checkoutservice] order confirmation email sent to "bradycarla@example.net"
  05:18:26.960 [paymentservice] UnacceptedCreditCard [Error]: Sorry, we cannot process visa_electron credit cards. Only VISA or MasterCard is accepted. at charge (/usr/src/app/charge.js:74:68)
  05:18:32.594 [emailservice] A request to send order confirmation email to tashawolf@example.org has been received.
  05:18:35.671 [checkoutservice] order confirmation email sent to "daniel24@example.org"

## p0756
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service catalogue, 2024-11-22T06:34:15.124Z
```
{"timestamp":1732257255124077000,"container_name":"catalogue","pod_name":"catalogue-b98c66547-xmpfr","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"ts=2024-11-22T06:34:15Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=3.371549ms"}
```
Same service, the 2 minutes before (oldest first):
  06:34:06.358 [catalogue] ts=2024-11-22T06:34:06Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=3.444661ms  (×9)
  06:34:08.121 [catalogue] ts=2024-11-22T06:34:08Z caller=logging.go:85 method=Health result=2 took=35.575µs  (×6)
  06:34:09.190 [catalogue] ts=2024-11-22T06:34:09Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=3.154492  (×4)
  06:34:11.959 [catalogue] ts=2024-11-22T06:34:11Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=3.16421m
All services, 30 seconds either side (sampled):
  06:33:45.127 [catalogue] ts=2024-11-22T06:33:45Z caller=logging.go:62 method=Get id=d3588630-ad8e-49df-bbd7-3167f7efb246 sock=d3588630-ad8e-49df-bbd7-3167f7efb246 err=null took=3.16072m  (×6)
  06:33:45.300 [front-end] POST /addresses 200 - ms - -  (×58)
  06:33:45.391 [catalogue] ts=2024-11-22T06:33:45Z caller=logging.go:62 method=Get id=510a0d7e-8e83-4193-b483-e27e09ddc34d sock=510a0d7e-8e83-4193-b483-e27e09ddc34d err=null took=3.391916  (×53)
  06:33:45.795 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67402  (×61)
  06:33:45.820 [front-end] POST /orders 406 - ms - -  (×61)
  06:33:46.993 [queue-master] 2024-11-22 06:33:46.993 INFO 7 --- [ool-6-thread-27] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×72)
  06:33:47.030 [carts] 2024-11-22 06:33:47.030 INFO [carts,d00c799d846a254e,043ba36f5e42e0b6,false] 7 --- [-nio-80-exec-17] w.w.s.cart.controllers.CartsController : Merge carts reques  (×23)
  06:33:49.426 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×9)
  06:33:50.654 [front-end] Received response: "{\"firstName\":\"uzGbkaWOG\",\"lastName\":\"uzGbkaWOG\",\"username\":\"uzGbkaWOG\",\"id\":\"674025bf768f35000114f0d3\",\"_links\":{\"address
  06:33:52.151 [carts] 2024-11-22 06:33:52.151 INFO [carts,dbd5f067593c69ac,87e8925a6fdd394f,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.CartsController : Merge carts reques  (×7)
  06:33:56.749 [front-end] Posting Customer: {"username":"puYWKRxWST","password":"PvuxyPg","email":"puYWKRxWST@gmail.com","firstName":"puYWKRxWST","lastName":"puYWKRxWST"}
  06:33:58.114 [user] ts=2024-11-22T06:33:58.113786069Z caller=middlewares.go:46 method=Register username=aQOvOuiac email=aQOvOuiac@gmail.com took=2.50765ms
  06:33:59.483 [front-end] Order response: {"statusCode":201,"body":{"id":"674025d7531af4000701df35","customerId":"674025c4768f35000114f0e0","customer":{"id":null,"firstName":"vbEPCUDAuwh
  06:34:01.789 [front-end] Order response: {"id":"674025d9531af4000701df38","customerId":"674025c4768f35000114f0e3","customer":{"id":null,"firstName":"UVAef","lastName":"UVAef","username"
  06:34:06.518 [front-end] Order response: {"id":"674025de531af4000701df39","customerId":"674025c5768f35000114f0e7","customer":{"id":null,"firstName":"mhFfOUK","lastName":"mhFfOUK","usern
  06:34:08.336 [front-end] Received response: "{\"firstName\":\"vSRGMKp\",\"lastName\":\"vSRGMKp\",\"username\":\"vSRGMKp\",\"id\":\"674025d0768f35000114f10f\",\"_links\":{\"addresses\":{
  06:34:11.313 [front-end] Received response: "{\"firstName\":\"XtACduEsdbe\",\"lastName\":\"XtACduEsdbe\",\"username\":\"XtACduEsdbe\",\"id\":\"674025c9768f35000114f0f7\",\"_links\":{\"a
  06:34:13.984 [front-end] Order response: {"id":"674025e5531af4000701df40","customerId":"674025d4768f35000114f117","customer":{"id":null,"firstName":"puYWKRxWST","lastName":"puYWKRxWST",
  06:34:16.835 [user] ts=2024-11-22T06:34:16.834935873Z caller=middlewares.go:46 method=Register username=TwSBNcvH email=TwSBNcvH@gmail.com took=2.005812ms
  06:34:18.649 [user] ts=2024-11-22T06:34:18.648797125Z caller=middlewares.go:46 method=Register username=BOazKdKDZ email=BOazKdKDZ@gmail.com took=3.227531ms
  06:34:21.819 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732257261816,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","  (×27)
  06:34:24.730 [front-end] Posting Customer: {"username":"xZPoptlMd","password":"wzXjUMPjKk","email":"xZPoptlMd@gmail.com","firstName":"xZPoptlMd","lastName":"xZPoptlMd"}
  06:34:29.510 [front-end] Posting Customer: {"username":"rihiQz","password":"avnMz","email":"rihiQz@gmail.com","firstName":"rihiQz","lastName":"rihiQz"}
  06:34:33.230 [front-end] Received response: "{\"firstName\":\"CMuMqIeuKjFoF\",\"lastName\":\"CMuMqIeuKjFoF\",\"username\":\"CMuMqIeuKjFoF\",\"id\":\"674025db768f35000114f129\",\"_links\
  06:34:36.438 [front-end] Posting Customer: {"username":"makPRZxYA","password":"FoUzdGHk","email":"makPRZxYA@gmail.com","firstName":"makPRZxYA","lastName":"makPRZxYA"}
  06:34:40.895 [orders-db] {"t":{"$date":"2024-11-22T06:34:40.894+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173225728
  06:34:42.089 [front-end] Received response: "{\"firstName\":\"ayvYoEACgbM\",\"lastName\":\"ayvYoEACgbM\",\"username\":\"ayvYoEACgbM\",\"id\":\"674025e8768f35000114f148\",\"_links\":{\"a
  06:34:44.775 [front-end] Received response: "{\"firstName\":\"CCykUIXtrHGaddn\",\"lastName\":\"CCykUIXtrHGaddn\",\"username\":\"CCykUIXtrHGaddn\",\"id\":\"674025e8768f35000114f147\",\"_

## p0571
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:01.656Z
```
{"timestamp":1733596261656641300,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:01.655  INFO 1 --- [           main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped \"{[/error],produces=[text/html]}\" onto public org.springframework.web.servlet.ModelAndView org.springframework.boot.autoconfigure.web.BasicErrorController.errorHtml(javax.servlet.http.HttpServletRequest,javax.servlet.http.HttpServletResponse)"}
```
Same service, the 2 minutes before (oldest first):
  18:30:49.764 [ts-auth-service] 2024-12-07 18:30:49.764 INFO 1 --- [ost-startStop-1] .s.DelegatingFilterProxyRegistrationBean : Mapping filter: 'springSecurityFilterChain' to: [/*]
  18:30:49.764 [ts-auth-service] 2024-12-07 18:30:49.764 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'webRequestLoggingFilter' to: [/*]  (×2)
  18:30:49.764 [ts-auth-service] 2024-12-07 18:30:49.764 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  18:30:51.479 [ts-auth-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/
  18:30:51.661 [ts-auth-service] 2024-12-07 18:30:51.661 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClust
  18:30:51.661 [ts-auth-service] 2024-12-07 18:30:51.661 INFO 1 --- [ main] org.mongodb.driver.cluster : Adding discovered server ts-auth-mongo:27017 to client view of cluster
  18:30:52.554 [ts-auth-service] 2024-12-07 18:30:52.553 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.connection : Opened connection [connectionId{localValue:1, serverValue:20}] to ts-auth-m
  18:30:52.557 [ts-auth-service] 2024-12-07 18:30:52.557 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description ServerDescrip
  18:30:52.562 [ts-auth-service] 2024-12-07 18:30:52.561 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  18:30:53.685 [ts-auth-service] 2024-12-07 18:30:53.678 INFO 1 --- [ main] auth.AuthApplication : Starting AuthApplication v1.0 on ts-auth-service-75dfb9459b-ctqkr with PID 1 (/app/ts-auth-ser
  18:30:53.685 [ts-auth-service] 2024-12-07 18:30:53.685 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default
  18:30:54.486 [ts-auth-service] 2024-12-07 18:30:54.485 INFO 1 --- [ main] ationConfigEmbeddedWebApplicationContext : Refreshing org.springframework.boot.context.embedded.AnnotationConfigEmbed
  18:31:00.863 [ts-auth-service] 2024-12-07 18:31:00.862 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  18:31:01.562 [ts-auth-service] 2024-12-07 18:31:01.562 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/hello],methods=[GET]}" onto public java.lang.Objec
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users],methods=[GET]}" onto public org.springframework.h
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/{userId}],methods=[DELETE]}" onto public org.sprin
  18:31:01.563 [ts-auth-service] 2024-12-07 18:31:01.563 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/login],methods=[POST]}" onto public org.springfram
  18:31:01.654 [ts-auth-service] 2024-12-07 18:31:01.653 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth/hello],methods=[GET]}" onto public java.lang.String
  18:31:01.654 [ts-auth-service] 2024-12-07 18:31:01.653 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/auth],methods=[POST]}" onto public org.springframework.h
All services, 30 seconds either side (sampled):
  18:30:31.939 [ts-order-service] 2024-12-07 18:30:31.939 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Other Service][Query Orders] Query Orders for 
  18:30:37.714 [ts-travel2-service] 2024-12-07 18:30:37.713 INFO 1 --- [io-16346-exec-5] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse  (×11)
  18:30:37.795 [ts-basic-service] 2024-12-07 18:30:37.795 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×19)
  18:30:37.825 [ts-order-other-service] 2024-12-07 18:30:37.825 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×10)
  18:30:37.914 [ts-seat-service] 2024-12-07 18:30:37.913 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×35)
  18:30:39.463 [ts-auth-service] 2024-12-07 18:30:39.463 INFO 1 --- [ main] faultConfiguringBeanFactoryPostProcessor : No bean named 'errorChannel' has been explicitly defined. Therefore, a def  (×2)
  18:30:40.512 [ts-order-other-service] 2024-12-07 18:30:40.512 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 24  (×3)
  18:30:41.360 [ts-auth-service] 2024-12-07 18:30:41.359 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.access.expression.method.DefaultMethodS  (×2)
  18:30:42.209 [ts-order-other-mongo] {"t":{"$date":"2024-12-07T18:30:42.208+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359624
  18:30:42.430 [ts-travel-service] 2024-12-07 18:30:42.430 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×11)
  18:30:47.127 [ts-basic-service] 2024-12-07 18:30:47.127 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Su   (×12)
  18:30:47.200 [ts-basic-service] 2024-12-07 18:30:47.199 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: f3d4  (×3)
  18:30:47.286 [ts-travel-service] 2024-12-07 18:30:47.286 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6
  18:30:49.754 [ts-auth-service] 2024-12-07 18:30:49.754 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.FilterRegistrationBean : Mapping filter: 'metricsFilter' to: [/*]  (×8)
  18:30:52.562 [ts-auth-service] 2024-12-07 18:30:52.561 INFO 1 --- [uth-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  18:30:57.130 [ts-seat-service] 2024-12-07 18:30:57.129 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×3)
  18:31:00.863 [ts-auth-service] 2024-12-07 18:31:00.862 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  18:31:02.163 [ts-auth-service] 2024-12-07 18:31:02.162 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**/favicon.ico] onto handler of type [class org.springfra
  18:31:03.869 [ts-auth-service] 2024-12-07 18:31:03.869 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/auditevents || /auditevents.json],methods=[GET],produces=[applicati
  18:31:04.078 [ts-order-service] 2024-12-07 18:31:04.078 INFO 1 --- [o-12031-exec-10] order.service.OrderServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=686798160, 
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.467 INFO 1 --- [ main] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 1 subscriber(s).
  18:31:11.697 [ts-travel-service] 2024-12-07 18:31:11.697 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234  (×5)
  18:31:12.245 [ts-basic-service] 2024-12-07 18:31:12.245 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2
  18:31:19.258 [ts-auth-service] 2024-12-07 18:31:19.257 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×7)
  18:31:20.904 [ts-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×2)
  18:31:28.040 [ts-auth-service] 2024-12-07 18:31:28.039 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
  18:31:29.893 [ts-station-mongo] {"t":{"$date":"2024-12-07T18:31:29.893+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:31.064 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null

## p0357
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service catalogue, 2024-11-22T03:32:06.318Z
```
{"timestamp":1732246326318007300,"container_name":"catalogue","pod_name":"catalogue-b98c66547-q2k66","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:32:06Z caller=logging.go:62 method=Get id=3395a43e-2d88-40de-b95f-e00e1502085b sock=3395a43e-2d88-40de-b95f-e00e1502085b err=null took=3.451152ms"}
```
Same service, the 2 minutes before (oldest first):
  03:31:57.126 [catalogue] ts=2024-11-22T03:31:57Z caller=logging.go:62 method=Get id=a0a4f044-b040-410d-8ead-4de0446aec7e sock=a0a4f044-b040-410d-8ead-4de0446aec7e err=null took=4.039119  (×6)
  03:31:57.820 [catalogue] ts=2024-11-22T03:31:57Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.7506ms  (×8)
  03:31:58.352 [catalogue] ts=2024-11-22T03:31:58Z caller=logging.go:85 method=Health result=2 took=28.897µs  (×6)
All services, 30 seconds either side (sampled):
  03:31:36.512 [front-end] Request received with body: {}  (×56)
  03:31:36.543 [orders] 2024-11-22 03:31:36.543 INFO [orders,8ced20a2fd348ad8,a49a15acb3c9e187,false] 6 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Sending payment req  (×22)
  03:31:36.871 [shipping] Adding shipment to queue...  (×35)
  03:31:37.054 [front-end] 673ffb19b0df5c00019b26e0  (×61)
  03:31:37.440 [user] ts=2024-11-22T03:31:37.440630197Z caller=middlewares.go:46 method=Register username=YVdsb email=YVdsb@gmail.com took=967.871µs
  03:31:38.482 [front-end] POST /addresses 200 - ms - -  (×64)
  03:31:38.643 [carts] 2024-11-22 03:31:38.643 INFO [carts,f7c3dc7561e7559c,76f52415d0e04836,false] 7 --- [p-nio-80-exec-8] w.w.s.cart.controllers.ItemsController : Did not find item.  (×17)
  03:31:39.643 [user] ts=2024-11-22T03:31:39.643381031Z caller=middlewares.go:46 method=Register username=eHcHzwgAZKJ email=eHcHzwgAZKJ@gmail.com took=1.127936ms  (×15)
  03:31:41.680 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×15)
  03:31:43.326 [front-end] Order response: {"id":"673ffb1fd94b9000069b45bf","customerId":"673ffb0bb0df5c00019b26be","customer":{"id":null,"firstName":"CswuDVCdWISj","lastName":"CswuDVCdWI
  03:31:47.280 [front-end] Order response: {"id":"673ffb23d94b9000069b45c0","customerId":"673ffb08b0df5c00019b26b8","customer":{"id":null,"firstName":"RFgpCcDGC","lastName":"RFgpCcDGC","u
  03:31:51.726 [queue-master] 2024-11-22 03:31:51.726 INFO 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Spawning new container  (×28)
  03:31:52.212 [user] ts=2024-11-22T03:31:52.212276055Z caller=middlewares.go:46 method=Register username=uwyCGsa email=uwyCGsa@gmail.com took=920.047µs
  03:31:54.719 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffb2ad94b9000069b45c5","customerId":"673ffb12b0df5c00019b26d1","customer":{"id":null,"firstName":"uBPmvyVkhAm
  03:31:56.908 [front-end] Posting Customer: {"username":"nMXWYHGGOgwT","password":"oRDQBU","email":"nMXWYHGGOgwT@gmail.com","firstName":"nMXWYHGGOgwT","lastName":"nMXWYHGGOgwT"}
  03:31:59.269 [front-end] Received response: "{\"firstName\":\"RCsNHvlwh\",\"lastName\":\"RCsNHvlwh\",\"username\":\"RCsNHvlwh\",\"id\":\"673ffb1eb0df5c00019b26ef\",\"_links\":{\"address
  03:32:02.399 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×3)
  03:32:03.056 [front-end] Posting Customer: {"username":"bBRhtdPVqn","password":"fDanNrLt","email":"bBRhtdPVqn@gmail.com","firstName":"bBRhtdPVqn","lastName":"bBRhtdPVqn"}
  03:32:05.719 [user] ts=2024-11-22T03:32:05.719220295Z caller=middlewares.go:46 method=Register username=okGFHNG email=okGFHNG@gmail.com took=1.036883ms
  03:32:09.468 [front-end] Posting Customer: {"username":"VFebmgOfCZwKHC","password":"FTanpUPtSJ","email":"VFebmgOfCZwKHC@gmail.com","firstName":"VFebmgOfCZwKHC","lastName":"VFebmgOfCZwKH
  03:32:10.932 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffb3ad94b9000069b45d7","customerId":"673ffb1fb0df5c00019b26f7","customer":{"id":null,"firstName":"qlqSFqMXh",
  03:32:13.107 [front-end] Received response: "{\"firstName\":\"nMXWYHGGOgwT\",\"lastName\":\"nMXWYHGGOgwT\",\"username\":\"nMXWYHGGOgwT\",\"id\":\"673ffb2cb0df5c00019b271e\",\"_links\":{
  03:32:15.000 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffb3ed94b9000069b45dc","customerId":"673ffb24b0df5c00019b2707","customer":{"id":null,"firstName":"aauDDkJrjXW
  03:32:17.729 [front-end] Posting Customer: {"username":"VieWm","password":"YwDjdW","email":"VieWm@gmail.com","firstName":"VieWm","lastName":"VieWm"}
  03:32:20.291 [user] ts=2024-11-22T03:32:20.290915852Z caller=middlewares.go:46 method=Register username=bviIQkm email=bviIQkm@gmail.com took=1.015085ms
  03:32:21.258 [carts-db] {"t":{"$date":"2024-11-22T03:32:21.258+00:00"},"s":"I", "c":"NETWORK", "id":22944, "ctx":"conn87","msg":"Connection ended","attr":{"remote":"127.0.0.6:34811","u  (×18)
  03:32:23.546 [front-end] Posting Customer: {"username":"FzgHRgaHtEX","password":"qKHPSJln","email":"FzgHRgaHtEX@gmail.com","firstName":"FzgHRgaHtEX","lastName":"FzgHRgaHtEX"}
  03:32:29.797 [carts] 2024-11-22 03:32:29.796 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Exception in monitor thread while connecting to server carts-db:270
  03:32:32.508 [front-end] Received response: "{\"firstName\":\"COmsLlalv\",\"lastName\":\"COmsLlalv\",\"username\":\"COmsLlalv\",\"id\":\"673ffb3db0df5c00019b2743\",\"_links\":{\"address
  03:32:35.341 [user] ts=2024-11-22T03:32:35.341377184Z caller=middlewares.go:46 method=Register username=gRfIUzoG email=gRfIUzoG@gmail.com took=1.033852ms

## p0614
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T20:16:00.635Z
```
{"timestamp":1733602560635558000,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-w6jt4","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:16:00.635  INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl         : Query for Station id is: Response(status=1, msg=Success, data=suzhou)"}
```
Same service, the 2 minutes before (oldest first):
  20:16:00.430 [ts-travel-service] 2024-12-07 20:16:00.430 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×4)
  20:16:00.462 [ts-travel-service] 2024-12-07 20:16:00.462 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×2)
  20:16:00.468 [ts-travel-service] 2024-12-07 20:16:00.468 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×2)
  20:16:00.468 [ts-travel-service] 2024-12-07 20:16:00.468 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：aefcef3f-3f42-46e8-afd7-6cb2a  (×3)
  20:16:00.475 [ts-travel-service] 2024-12-07 20:16:00.474 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
  20:16:00.481 [ts-travel-service] 2024-12-07 20:16:00.480 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×2)
  20:16:00.535 [ts-travel-service] 2024-12-07 20:16:00.535 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Ts-basic-service ticket info is: Response(status=1, msg=Success, data={s
  20:16:00.543 [ts-travel-service] 2024-12-07 20:16:00.542 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat
  20:16:00.554 [ts-travel-service] 2024-12-07 20:16:00.554 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)
  20:16:00.567 [ts-travel-service] 2024-12-07 20:16:00.566 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)
  20:16:00.567 [ts-travel-service] 2024-12-07 20:16:00.566 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr
  20:16:00.572 [ts-travel-service] 2024-12-07 20:16:00.572 INFO 1 --- [io-12346-exec-1] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1236
All services, 30 seconds either side (sampled):
  20:15:30.639 [ts-seat-service] 2024-12-07 20:15:30.639 INFO 1 --- [io-18898-exec-4] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×38)
  20:15:30.673 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:15:30 +0800] "POST /api/v1/travel2service/trips/left HTTP/1.1" 200 343 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleW  (×12)
  20:15:31.180 [ts-assurance-mongo] {"t":{"$date":"2024-12-07T20:15:31.179+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360253
  20:15:31.298 [ts-travel-service] 2024-12-07 20:15:31.296 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×24)
  20:15:31.348 [ts-travel-service] 2024-12-07 20:15:31.348 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×20)
  20:15:31.646 [ts-security-mongo] {"t":{"$date":"2024-12-07T20:15:31.646+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360253
  20:15:36.872 [ts-admin-basic-info-service] 2024-12-07 20:15:36.872 INFO 1 --- [io-18767-exec-6] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×12)
  20:15:42.628 [ts-basic-service] 2024-12-07 20:15:42.628 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: S  (×23)
  20:15:42.653 [ts-price-service] 2024-12-07 20:15:42.653 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×3)
  20:15:42.677 [ts-order-other-service] 2024-12-07 20:15:42.676 INFO 1 --- [io-12032-exec-9] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 54  (×11)
  20:15:42.756 [ts-seat-service] 2024-12-07 20:15:42.756 INFO 1 --- [io-18898-exec-8] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×18)
  20:15:42.859 [ts-basic-service] 2024-12-07 20:15:42.859 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×8)
  20:15:43.049 [ts-auth-service] 2024-12-07 20:15:43.049 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  20:15:43.362 [ts-price-service] 2024-12-07 20:15:43.361 INFO 1 --- [io-16579-exec-1] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×18)
  20:15:45.827 [ts-travel2-service] 2024-12-07 20:15:45.827 INFO 1 --- [o-16346-exec-10] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236
  20:15:45.860 [ts-seat-service] 2024-12-07 20:15:45.860 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass   (×3)
  20:15:46.678 [ts-basic-service] 2024-12-07 20:15:46.678 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×2)
  20:15:46.705 [ts-basic-service] 2024-12-07 20:15:46.705 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : indexStart : 3 __ indexEnd : 4  (×3)
  20:15:46.800 [ts-seat-service] 2024-12-07 20:15:46.800 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×17)
  20:15:46.960 [ts-travel-service] 2024-12-07 20:15:46.960 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×18)
  20:15:47.380 [ts-basic-service] 2024-12-07 20:15:47.380 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：084837bb-53
  20:15:48.161 [ts-travel-service] 2024-12-07 20:15:48.160 INFO 1 --- [io-12346-exec-4] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×2)
  20:15:55.406 [ts-travel2-service] 2024-12-07 20:15:55.406 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×4)
  20:15:57.150 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:15:57 +0800] "POST /api/v1/orderOtherService/orderOther/refresh HTTP/1.1" 200 24818 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10
  20:16:00.256 [ts-basic-service] 2024-12-07 20:16:00.256 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：92708982-77  (×2)
  20:16:00.732 [ts-basic-service] 2024-12-07 20:16:00.732 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：084837bb-53
  20:16:10.254 [ts-order-service] 2024-12-07 20:16:10.254 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 78  (×2)
  20:16:18.608 [ts-travel-service] 2024-12-07 20:16:18.608 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  20:16:19.015 [ts-basic-service] 2024-12-07 20:16:19.014 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N
  20:16:28.405 [ts-price-mongo] {"t":{"$date":"2024-12-07T20:16:28.405+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360258

## p0453
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:06:24.621Z
```
{"timestamp":1732349184621404200,"container_name":"front-end","pod_name":"front-end-f77549869-bx88h","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Order response: {\"statusCode\":500,\"body\":{\"timestamp\":1732349184618,\"status\":500,\"error\":\"Internal Server Error\",\"exception\":\"java.lang.IllegalStateException\",\"message\":\"Unable to create order due to unspecified IO error.\",\"path\":\"/orders\"},\"headers\":{\"x-application-context\":\"orders:80\",\"content-type\":\"application/json;charset=UTF-8\",\"date\":\"Sat, 23 Nov 2024 08:06:24 GMT\",\"x-envoy-upstream-service…"}
```
Same service, the 2 minutes before (oldest first):
  08:06:23.944 [front-end] GET /catalogue 200 - ms - -
  08:06:24.154 [front-end] Request received with body: {}  (×2)
  08:06:24.164 [front-end] Received response: "{\"firstName\":\"zAsYuxcfKqH\",\"lastName\":\"zAsYuxcfKqH\",\"username\":\"zAsYuxcfKqH\",\"id\":\"67418cefa437380001deec8f\",\"_links\":{\"a
  08:06:24.164 [front-end] GET Request to: http://user/customers/67418cefa437380001deec8f/addresses  (×4)
  08:06:24.173 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"67418cf4a437380001deec9a\",\"_links\":{\"  (×2)
  08:06:24.173 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418  (×2)
  08:06:24.173 [front-end] [ undefined, undefined ]  (×2)
  08:06:24.173 [front-end] Posting Order: {"customer":"http://user/customers/67418cefa437380001deec8f","address":"http://user/addresses/67418cf4a437380001deec99","card":"http://user/cards  (×2)
  08:06:24.222 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732349184220,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  08:06:24.222 [front-end] Order response: {"timestamp":1732349184220,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  08:06:24.225 [front-end] POST /orders 500 - ms - -
  08:06:24.580 [front-end] Received response: "{\"firstName\":\"djVRqry\",\"lastName\":\"djVRqry\",\"username\":\"djVRqry\",\"id\":\"67418cf2a437380001deec95\",\"_links\":{\"addresses\":{
All services, 30 seconds either side (sampled):
  08:05:54.737 [payment] ts=2024-11-23T08:05:54Z caller=logging.go:40 method=Health result=1 took=7.147µs  (×40)
  08:05:54.953 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"67418cd8a437380001deec46"}  (×62)
  08:05:55.061 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×62)
  08:05:55.494 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67418  (×63)
  08:05:55.927 [front-end] Received response: "{\"firstName\":\"vAqpjQQYV\",\"lastName\":\"vAqpjQQYV\",\"username\":\"vAqpjQQYV\",\"id\":\"67418ccba437380001deec21\",\"_links\":{\"address
  08:05:59.414 [shipping] 2024-11-23 08:05:59.414 INFO [shipping,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  08:06:04.890 [front-end] Received response: "{\"firstName\":\"lYvQmmCWwWuvT\",\"lastName\":\"lYvQmmCWwWuvT\",\"username\":\"lYvQmmCWwWuvT\",\"id\":\"67418cd2a437380001deec36\",\"_links\
  08:06:07.002 [shipping] 2024-11-23 08:06:07.002 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[OPTIONS],produces=[appl
  08:06:07.050 [front-end] Posting Customer: {"username":"JAEXlZGcwnm","password":"slZRIUj","email":"JAEXlZGcwnm@gmail.com","firstName":"JAEXlZGcwnm","lastName":"JAEXlZGcwnm"}
  08:06:07.808 [front-end] Posting Customer: {"username":"XJzSyDLxvp","password":"LfpbN","email":"XJzSyDLxvp@gmail.com","firstName":"XJzSyDLxvp","lastName":"XJzSyDLxvp"}
  08:06:13.834 [front-end] Received response: "{\"firstName\":\"bzxtLtBzUaRfo\",\"lastName\":\"bzxtLtBzUaRfo\",\"username\":\"bzxtLtBzUaRfo\",\"id\":\"67418ce5a437380001deec6f\",\"_links\
  08:06:15.699 [carts] 2024-11-23 08:06:15.699 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[HEAD],produces=[application/hal+json ||
  08:06:15.806 [carts] 2024-11-23 08:06:15.806 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[PATCH || PUT ||
  08:06:16.403 [shipping] 2024-11-23 08:06:16.402 INFO [shipping,,,] 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0  (×2)
  08:06:19.002 [carts] 2024-11-23 08:06:19.002 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto public j
  08:06:19.274 [front-end] Posting Customer: {"username":"ctDNRPS","password":"kZNuA","email":"ctDNRPS@gmail.com","firstName":"ctDNRPS","lastName":"ctDNRPS"}
  08:06:24.004 [carts] 2024-11-23 08:06:24.003 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  08:06:26.093 [front-end] Received response: "{\"firstName\":\"XJzSyDLxvp\",\"lastName\":\"XJzSyDLxvp\",\"username\":\"XJzSyDLxvp\",\"id\":\"67418cefa437380001deec90\",\"_links\":{\"addr
  08:06:28.351 [front-end] Received response: "{\"firstName\":\"VnaknAEtTvwY\",\"lastName\":\"VnaknAEtTvwY\",\"username\":\"VnaknAEtTvwY\",\"id\":\"67418ceca437380001deec88\",\"_links\":{
  08:06:31.705 [carts-db] {"t":{"$date":"2024-11-23T08:06:31.705+00:00"},"s":"I", "c":"STORAGE", "id":20320, "ctx":"conn4","msg":"createCollection","attr":{"namespace":"data.cart","uuidD  (×8)
  08:06:32.828 [shipping] 2024-11-23 08:06:32.828 INFO [shipping,,,] 7 --- [p-nio-80-exec-2] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization star
  08:06:34.918 [rabbitmq] accepting AMQP connection <0.573.0> (127.0.0.6:57579 -> 192.168.93.151:5672) 
  08:06:36.198 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d0b3f77060008864e3f","customerId":"67418cf2a437380001deec94","customer":{"id":null,"firstName":"SPVlWNNsjee
  08:06:40.396 [front-end] Posting Customer: {"username":"ehjzbOPHpDjC","password":"qwbmwOfmZE","email":"ehjzbOPHpDjC@gmail.com","firstName":"ehjzbOPHpDjC","lastName":"ehjzbOPHpDjC"}
  08:06:41.695 [front-end] Received response: "{\"firstName\":\"teNYQYg\",\"lastName\":\"teNYQYg\",\"username\":\"teNYQYg\",\"id\":\"67418cf5a437380001deec9b\",\"_links\":{\"addresses\":{
  08:06:43.917 [queue-master] 2024-11-23 08:06:43.917 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×54)
  08:06:47.815 [front-end] Order response: {"id":"67418d173f77060008864e49","customerId":"67418cfba437380001deecae","customer":{"id":null,"firstName":"HsVUYJlBshmzPAV","lastName":"HsVUYJl
  08:06:49.690 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d193f77060008864e4e","customerId":"67418d02a437380001deecc0","customer":{"id":null,"firstName":"QzQEpmSQXDM
  08:06:52.805 [front-end] Order response: {"statusCode":201,"body":{"id":"67418d1c3f77060008864e53","customerId":"67418cfba437380001deecad","customer":{"id":null,"firstName":"ctDNRPS","l

## p0796
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-08T08:40:26.503Z
```
{"timestamp":1733647226503793000,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-54fv6","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-08 08:40:26.503  INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl       : [Travel Other Service][Get Route By Id] Success."}
```
Same service, the 2 minutes before (oldest first):
  08:40:26.225 [ts-travel2-service] 2024-12-08 08:40:26.224 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：1367db1f-461e-4ab7-87ad-2bc  (×4)
  08:40:26.230 [ts-travel2-service] 2024-12-08 08:40:26.229 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×3)
  08:40:26.264 [ts-travel2-service] 2024-12-08 08:40:26.263 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  08:40:26.271 [ts-travel2-service] 2024-12-08 08:40:26.271 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  08:40:26.305 [ts-travel2-service] 2024-12-08 08:40:26.304 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sun Dec 08 00:00:00 GMT 2024,   (×2)
  08:40:26.310 [ts-travel2-service] 2024-12-08 08:40:26.310 INFO 1 --- [io-16346-exec-4] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×2)
  08:40:26.316 [ts-travel2-service] 2024-12-08 08:40:26.316 INFO 1 --- [io-16346-exec-4] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×2)
  08:40:26.371 [ts-travel2-service] 2024-12-08 08:40:26.370 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×2)
  08:40:26.490 [ts-travel2-service] 2024-12-08 08:40:26.490 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6
  08:40:26.499 [ts-travel2-service] 2024-12-08 08:40:26.499 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×2)
All services, 30 seconds either side (sampled):
  08:39:58.201 [ts-auth-service] 2024-12-08 08:39:58.201 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×3)
  08:39:58.412 [ts-route-service] 2024-12-08 08:39:58.412 INFO 1 --- [io-11178-exec-7] route.controller.RouteController : Route id: 0b23bd3e-876a-4af3-b920-c50a90c90b04  (×146)
  08:39:58.460 [ts-price-service] 2024-12-08 08:39:58.460 INFO 1 --- [io-16579-exec-7] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: d693a2c5-ef87-4a3c-bef  (×18)
  08:39:58.483 [ts-order-other-service] 2024-12-08 08:39:58.482 INFO 1 --- [io-12032-exec-6] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×14)
  08:39:58.555 [ts-seat-service] 2024-12-08 08:39:58.554 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×19)
  08:39:58.844 [ts-admin-basic-info-service] 2024-12-08 08:39:58.844 INFO 1 --- [io-18767-exec-5] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×9)
  08:40:01.266 [ts-travel2-service] 2024-12-08 08:40:01.266 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×4)
  08:40:01.465 [ts-travel2-service] 2024-12-08 08:40:01.464 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×8)
  08:40:02.959 [ts-seat-service] 2024-12-08 08:40:02.959 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×3)
  08:40:04.165 [ts-auth-service] 2024-12-08 08:40:04.165 INFO 1 --- [ Thread-5] o.s.j.e.a.AnnotationMBeanExporter : Unregistering JMX-exposed beans on shutdown
  08:40:08.016 [ts-food-service] 2024-12-08 08:40:08.016 INFO 1 --- [o-18856-exec-10] foodsearch.service.FoodServiceImpl : [Food Service]Get Train Food List!
  08:40:09.692 [ts-contacts-mongo] {"t":{"$date":"2024-12-08T08:40:09.692+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364720
  08:40:09.978 [ts-config-mongo] {"t":{"$date":"2024-12-08T08:40:09.978+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173364720
  08:40:12.483 [ts-auth-service] ( ( )\___ | '_ | '_| | '_ \/ _` | \ \ \ \ \\/ ___)| |_)| | | | | || (_| | ) ) ) ) ' |____| .__|_| |_|_| |_\__, | / / / / =========|_|==============|___/=/_/_/_/  (×2)
  08:40:15.284 [ts-auth-service] 2024-12-08 08:40:15.284 INFO 1 --- [ main] auth.AuthApplication : No active profile set, falling back to default profiles: default  (×2)
  08:40:26.048 [ts-basic-service] 2024-12-08 08:40:26.047 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×3)
  08:40:29.532 [ts-order-service] java.lang.IllegalArgumentException: Invalid UUID string: at java.util.UUID.fromString(UUID.java:194) ~[na:1.8.0_402] at order.service.OrderServiceImpl.queryOrde  (×2)
  08:40:33.611 [ts-travel-service] 2024-12-08 08:40:33.608 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Travel Service] Query TripResponse  (×2)
  08:40:33.670 [ts-travel-service] 2024-12-08 08:40:33.669 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×2)
  08:40:33.752 [ts-travel-service] 2024-12-08 08:40:33.752 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sun Dec 08 00:00:00 GMT 2024, tr  (×4)
  08:40:33.851 [ts-travel-service] 2024-12-08 08:40:33.850 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×2)
  08:40:35.394 [ts-auth-service] 2024-12-08 08:40:35.393 INFO 1 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat initialized with port(s): 12340 (http)  (×2)
  08:40:41.288 [ts-auth-service] 2024-12-08 08:40:41.287 INFO 1 --- [ main] org.mongodb.driver.cluster : Cluster created with settings {hosts=[ts-auth-mongo:27017], mode=MULTIPLE, requiredClust
  08:40:42.680 [ts-order-other-service] 2024-12-08 08:40:42.679 INFO 1 --- [io-12032-exec-8] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for 
  08:40:43.529 [ts-travel-service] 2024-12-08 08:40:43.529 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×3)
  08:40:43.818 [ts-travel-service] 2024-12-08 08:40:43.817 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×2)
  08:40:51.079 [ts-auth-service] 2024-12-08 08:40:51.079 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/users/{userId}],methods=[DELETE]}" onto public org.sprin
  08:40:53.389 [ts-auth-service] 2024-12-08 08:40:53.389 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/heapdump || /heapdump.json],methods=[GET],produces=[application/oct
  08:40:53.392 [ts-auth-service] 2024-12-08 08:40:53.392 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/health || /health.json],methods=[GET],produces=[application/vnd.spr
  08:40:54.487 [ts-auth-service] 2024-12-08 08:40:54.486 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context.embedded.A

## p0502
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T09:14:15.852Z
```
{"timestamp":1732353255852969500,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T09:14:15.852892778Z caller=middlewares.go:75 method=GetUsers id=67419cd8a437380001df0c12 result=1 took=2.388089ms"}
```
Same service, the 2 minutes before (oldest first):
  09:14:11.856 [user] ts=2024-11-23T09:14:11.856369592Z caller=middlewares.go:75 method=GetUsers id=67419cc9a437380001df0be2 result=1 took=2.206043ms  (×9)
  09:14:12.683 [user] ts=2024-11-23T09:14:12.683021266Z caller=middlewares.go:46 method=Register username=yihcBzldBQwmdm email=yihcBzldBQwmdm@gmail.com took=2.217203ms  (×3)
  09:14:13.219 [user] ts=2024-11-23T09:14:13.219192197Z caller=middlewares.go:46 method=Register username=diIZwaOc email=diIZwaOc@gmail.com took=2.518978ms
  09:14:13.329 [user] ts=2024-11-23T09:14:13.32878087Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67419cdca437380001df0c1a took=4.050141ms  (×2)
  09:14:13.384 [user] ts=2024-11-23T09:14:13.384377408Z caller=middlewares.go:118 method=PostCard card=*****3321 user=67419cdca437380001df0c1a took=4.000023ms  (×2)
  09:14:13.848 [user] ts=2024-11-23T09:14:13.848282356Z caller=middlewares.go:157 method=Health result=2 took=1.944091ms  (×2)
  09:14:13.853 [user] ts=2024-11-23T09:14:13.852959648Z caller=middlewares.go:46 method=Register username=xOsNjR email=xOsNjR@gmail.com took=2.372085ms
All services, 30 seconds either side (sampled):
  09:13:46.268 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"67419cc2a437380001df0bd0"}  (×62)
  09:13:46.306 [user] ts=2024-11-23T09:13:46.305970654Z caller=middlewares.go:75 method=GetUsers id=67419cb5a437380001df0b9f result=1 took=2.118025ms  (×176)
  09:13:46.331 [orders] 2024-11-23 09:13:46.330 ERROR [orders,bb7ca878c9c05418,662201f3d0c01491,false] 7 --- [p-nio-80-exec-9] o.s.d.r.w.RepositoryRestExceptionHandler : Could not read  (×53)
  09:13:46.339 [front-end] Attempting to delete cart for user: 67419cc2a437380001df0bd0  (×62)
  09:13:46.399 [carts] 2024-11-23 09:13:46.399 INFO [carts,81f53fbfb48e6213,690ad173116e8298,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.ItemsController : Did not find item.  (×34)
  09:13:46.829 [user] ts=2024-11-23T09:13:46.829216752Z caller=middlewares.go:46 method=Register username=PhfiNkfoXEC email=PhfiNkfoXEC@gmail.com took=2.123129ms  (×33)
  09:13:46.854 [front-end] set cookie67419ccaa437380001df0be7  (×56)
  09:13:48.215 [front-end] POST to carts: http://carts/carts/67419cc6a437380001df0bd9/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}  (×29)
  09:13:49.471 [front-end] Received response: "{\"firstName\":\"blXIiXPcg\",\"lastName\":\"blXIiXPcg\",\"username\":\"blXIiXPcg\",\"id\":\"67419cb9a437380001df0bae\",\"_links\":{\"address
  09:13:52.135 [front-end] Received response: "{\"firstName\":\"GDvNNCyyCOnaLB\",\"lastName\":\"GDvNNCyyCOnaLB\",\"username\":\"GDvNNCyyCOnaLB\",\"id\":\"67419cb7a437380001df0ba8\",\"_lin
  09:13:57.085 [front-end] Received response: "{\"firstName\":\"WnTqRplrpnFnO\",\"lastName\":\"WnTqRplrpnFnO\",\"username\":\"WnTqRplrpnFnO\",\"id\":\"67419cbfa437380001df0bcd\",\"_links\
  09:13:58.871 [front-end] Received response: "{\"firstName\":\"lidUJBtYzU\",\"lastName\":\"lidUJBtYzU\",\"username\":\"lidUJBtYzU\",\"id\":\"67419cbea437380001df0bc5\",\"_links\":{\"addr
  09:14:01.445 [front-end] Received response: "{\"firstName\":\"vaEbvd\",\"lastName\":\"vaEbvd\",\"username\":\"vaEbvd\",\"id\":\"67419cc2a437380001df0bd0\",\"_links\":{\"addresses\":{\"h
  09:14:04.053 [user] ts=2024-11-23T09:14:04.05304348Z caller=middlewares.go:46 method=Register username=RGyotv email=RGyotv@gmail.com took=2.355968ms
  09:14:05.387 [front-end] Received response: "{\"firstName\":\"tyRHn\",\"lastName\":\"tyRHn\",\"username\":\"tyRHn\",\"id\":\"67419cc3a437380001df0bd3\",\"_links\":{\"addresses\":{\"href
  09:14:07.933 [front-end] Received response: "{\"firstName\":\"XPFoGZbguxdJEv\",\"lastName\":\"XPFoGZbguxdJEv\",\"username\":\"XPFoGZbguxdJEv\",\"id\":\"67419ccda437380001df0bf6\",\"_lin
  09:14:11.792 [front-end] Posting Customer: {"username":"JwxjMs","password":"BjltUOaC","email":"JwxjMs@gmail.com","firstName":"JwxjMs","lastName":"JwxjMs"}
  09:14:13.846 [front-end] Posting Customer: {"username":"xOsNjR","password":"JORhrYZ","email":"xOsNjR@gmail.com","firstName":"xOsNjR","lastName":"xOsNjR"}
  09:14:16.147 [user] ts=2024-11-23T09:14:16.147627538Z caller=middlewares.go:46 method=Register username=OIAqF email=OIAqF@gmail.com took=2.389083ms
  09:14:20.044 [front-end] Posting Customer: {"username":"pfiPHHPytpAo","password":"KACiRlKn","email":"pfiPHHPytpAo@gmail.com","firstName":"pfiPHHPytpAo","lastName":"pfiPHHPytpAo"}
  09:14:22.576 [front-end] Received response: "{\"firstName\":\"mnPzJqBv\",\"lastName\":\"mnPzJqBv\",\"username\":\"mnPzJqBv\",\"id\":\"67419cd5a437380001df0c0d\",\"_links\":{\"addresses\
  09:14:26.030 [front-end] Received response: "{\"firstName\":\"VFoRgieoxKBu\",\"lastName\":\"VFoRgieoxKBu\",\"username\":\"VFoRgieoxKBu\",\"id\":\"67419cdfa437380001df0c24\",\"_links\":{
  09:14:28.721 [front-end] Posting Customer: {"username":"kZuIiGFVhQTIKv","password":"QYDOaAeBIt","email":"kZuIiGFVhQTIKv@gmail.com","firstName":"kZuIiGFVhQTIKv","lastName":"kZuIiGFVhQTIK
  09:14:30.696 [front-end] Posting Customer: {"username":"pSuAeS","password":"znzMWhUcyr","email":"pSuAeS@gmail.com","firstName":"pSuAeS","lastName":"pSuAeS"}
  09:14:35.068 [front-end] Received response: "{\"firstName\":\"xOsNjR\",\"lastName\":\"xOsNjR\",\"username\":\"xOsNjR\",\"id\":\"67419ce5a437380001df0c35\",\"_links\":{\"addresses\":{\"h
  09:14:36.898 [front-end] Received response: "{\"firstName\":\"pfkPDtBBoGPvln\",\"lastName\":\"pfkPDtBBoGPvln\",\"username\":\"pfkPDtBBoGPvln\",\"id\":\"67419ce3a437380001df0c2f\",\"_lin
  09:14:41.053 [front-end] Posting Customer: {"username":"qEdZWLilc","password":"kGJFuZh","email":"qEdZWLilc@gmail.com","firstName":"qEdZWLilc","lastName":"qEdZWLilc"}
  09:14:42.374 [front-end] Received response: "{\"firstName\":\"AKszTwNymLp\",\"lastName\":\"AKszTwNymLp\",\"username\":\"AKszTwNymLp\",\"id\":\"67419ceca437380001df0c48\",\"_links\":{\"a
  09:14:45.732 [user] ts=2024-11-23T09:14:45.731874903Z caller=middlewares.go:46 method=Register username=wNYuYNBz email=wNYuYNBz@gmail.com took=2.276385ms

## p0615
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-route-service, 2024-12-07T20:16:41.903Z
```
{"timestamp":1733602601903624200,"container_name":"ts-route-service","pod_name":"ts-route-service-6bdc49b787-g5zvb","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"Error opening zip file or JAR manifest missing : /tmp/opentelemetry-javaagent.jar"}
```
Same service, the 2 minutes before (oldest first):
  20:16:40.102 [ts-route-service] 2024-12-07 20:16:40.102 INFO 1 --- [io-11178-exec-2] route.controller.RouteController : Route id: 92708982-77af-4318-be25-57ccb0ff69ad  (×18)
  20:16:40.151 [ts-route-service] 2024-12-07 20:16:40.151 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 084837bb-53c8-4438-87c8-0321a4d09917  (×2)
All services, 30 seconds either side (sampled):
  20:16:15.218 [ts-auth-service] 2024-12-07 20:16:15.217 INFO 1 --- [io-12340-exec-4] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×9)
  20:16:15.483 [ts-basic-service] 2024-12-07 20:16:15.483 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×39)
  20:16:15.532 [ts-basic-service] 2024-12-07 20:16:15.531 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：0b23bd3e-87  (×3)
  20:16:15.556 [ts-basic-service] 2024-12-07 20:16:15.555 INFO 1 --- [io-15680-exec-1] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1  (×8)
  20:16:15.609 [ts-travel-service] 2024-12-07 20:16:15.609 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×65)
  20:16:15.633 [ts-travel2-service] 2024-12-07 20:16:15.633 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×12)
  20:16:15.660 [ts-seat-service] 2024-12-07 20:16:15.660 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×17)
  20:16:15.755 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:15 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 200 5520 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) A  (×11)
  20:16:17.420 [ts-travel2-service] 2024-12-07 20:16:17.420 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×12)
  20:16:17.621 [ts-seat-service] 2024-12-07 20:16:17.621 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×3)
  20:16:17.673 [ts-travel2-service] 2024-12-07 20:16:17.673 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×2)
  20:16:18.608 [ts-travel-service] 2024-12-07 20:16:18.608 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  20:16:18.708 [ts-travel-service] 2024-12-07 20:16:18.708 INFO 1 --- [io-12346-exec-3] travel.controller.TravelController : [Travel Service] Query TripResponse
  20:16:18.815 [ts-order-service] 2024-12-07 20:16:18.814 INFO 1 --- [io-12031-exec-2] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×3)
  20:16:18.878 [ts-order-service] 2024-12-07 20:16:18.877 INFO 1 --- [io-12031-exec-3] order.service.OrderServiceImpl : Left ticket info is empty  (×5)
  20:16:19.036 [ts-basic-service] 2024-12-07 20:16:19.036 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.  (×2)
  20:16:19.273 [ts-price-service] 2024-12-07 20:16:19.273 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: a3f256c1-0e43-4f7d-9c2  (×2)
  20:16:19.808 [ts-order-service] 2024-12-07 20:16:19.807 INFO 1 --- [io-12031-exec-1] order.service.OrderServiceImpl : [Order Service][Query Order] Get order num: 78  (×2)
  20:16:22.767 [ts-admin-basic-info-service] 2024-12-07 20:16:22.766 INFO 1 --- [io-18767-exec-2] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×12)
  20:16:28.485 [ts-config-mongo] {"t":{"$date":"2024-12-07T20:16:28.485+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360258
  20:16:31.142 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T20:16:31.142+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360259
  20:16:31.540 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:31 +0800] "POST /api/v1/orderOtherService/orderOther/refresh HTTP/1.1" 200 24818 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10
  20:16:31.581 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:31 +0800] "PUT /api/v1/consignservice/consigns HTTP/1.1" 200 400 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebK  (×2)
  20:16:31.811 [ts-user-mongo] {"t":{"$date":"2024-12-07T20:16:31.811+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360259
  20:16:32.958 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:16:32 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 5994 "-" "Mozilla/5.0 (Macintosh;  (×2)
  20:16:42.993 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T20:16:42.993+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360260
  20:16:57.351 [ts-seat-service] 2024-12-07 20:16:57.351 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat
  20:16:57.634 [ts-route-service] 2024-12-07 20:16:57.634 INFO 1 --- [ Thread-5] org.mongodb.driver.connection : Closed connection [connectionId{localValue:2, serverValue:22}] to ts-route-mongo:  (×2)
  20:17:02.705 [ts-admin-travel-service] 2024-12-07 20:17:02.705 ERROR 1 --- [io-16114-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×3)

## p0319
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:20:51.502Z
```
{"timestamp":1732245651502841600,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"firstName\\\":\\\"znIVGAMLgnSste\\\",\\\"lastName\\\":\\\"znIVGAMLgnSste\\\",\\\"username\\\":\\\"znIVGAMLgnSste\\\",\\\"id\\\":\\\"673ff880b0df5c00019b1f04\\\",\\\"_links\\\":{\\\"addresses\\\":{\\\"href\\\":\\\"http://user/customers/673ff880b0df5c00019b1f04/addresses\\\"},\\\"cards\\\":{\\\"href\\\":\\\"http://user/customers/673ff880b0df5c00019b1f04/cards\\\"},\\\"customer\\\":{\\\"href\\\":\\\"http://user/customers/673ff880b0df5c00019b1f0…"}
```
Same service, the 2 minutes before (oldest first):
  03:20:49.225 [front-end] POST to carts: http://carts/carts/673ff887b0df5c00019b1f13/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  03:20:49.270 [front-end] POST /cart 500 50.725 ms - 64
  03:20:49.517 [front-end] GET /catalogue 200 - ms - -
  03:20:49.809 [front-end] Posting Customer: {"username":"YwTYsSUGcmNRsJY","password":"vPzbHQOPY","email":"YwTYsSUGcmNRsJY@gmail.com","firstName":"YwTYsSUGcmNRsJY","lastName":"YwTYsSUGcmN
  03:20:49.814 [front-end] { id: '673ff891b0df5c00019b1f2d' }  (×2)
  03:20:49.814 [front-end] 673ff891b0df5c00019b1f2d  (×2)
  03:20:49.814 [front-end] Merging carts for customer id: 673ff891b0df5c00019b1f2d and session id: uXbKmnZAMKoU_w4Qqg1PC4Vfbn_15hFE  (×2)
  03:20:49.849 [front-end] Carts merged.  (×2)
  03:20:49.849 [front-end] set cookie673ff891b0df5c00019b1f2d  (×2)
  03:20:49.850 [front-end] Sent cookies.  (×2)
  03:20:49.852 [front-end] POST /register 200 40.902 ms - 33  (×2)
  03:20:51.235 [front-end] Posting Customer: {"username":"cqPFUedoarsUCI","password":"BNbmkot","email":"cqPFUedoarsUCI@gmail.com","firstName":"cqPFUedoarsUCI","lastName":"cqPFUedoarsUCI"}
  03:20:51.496 [front-end] Request received with body: {}
All services, 30 seconds either side (sampled):
  03:20:21.524 [front-end] Attempting to delete cart for user: 673ff86cb0df5c00019b1ec9  (×59)
  03:20:21.882 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ff86cb0df5c00019b1ecb\",\"_links\":{\"  (×64)
  03:20:22.631 [catalogue] ts=2024-11-22T03:20:22Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=5.14108ms  (×57)
  03:20:23.469 [user] ts=2024-11-22T03:20:23.468981118Z caller=middlewares.go:75 method=GetUsers id=673ff863b0df5c00019b1ea2 result=1 took=1.092281ms  (×78)
  03:20:24.305 [user] ts=2024-11-22T03:20:24.305500894Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ff86eb0df5c00019b1ed0 took=1.65864ms  (×58)
  03:20:26.469 [front-end] Received response: "{\"firstName\":\"tbhaDXI\",\"lastName\":\"tbhaDXI\",\"username\":\"tbhaDXI\",\"id\":\"673ff865b0df5c00019b1ea5\",\"_links\":{\"addresses\":{
  03:20:30.256 [user] ts=2024-11-22T03:20:30.255965253Z caller=middlewares.go:46 method=Register username=MKGIsEbVYi email=MKGIsEbVYi@gmail.com took=961.498µs  (×6)
  03:20:34.045 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×9)
  03:20:37.989 [user] ts=2024-11-22T03:20:37.989642518Z caller=middlewares.go:46 method=Register username=WwpBLC email=WwpBLC@gmail.com took=1.140838ms
  03:20:41.176 [front-end] Received response: "{\"firstName\":\"dpZIGojLodgB\",\"lastName\":\"dpZIGojLodgB\",\"username\":\"dpZIGojLodgB\",\"id\":\"673ff87bb0df5c00019b1efc\",\"_links\":{
  03:20:43.389 [carts] 2024-11-22 03:20:43.389 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
  03:20:48.920 [front-end] Posting Customer: {"username":"DnjBelnPao","password":"eQMYAKREBx","email":"DnjBelnPao@gmail.com","firstName":"DnjBelnPao","lastName":"DnjBelnPao"}
  03:20:51.541 [front-end] Received response: "{\"firstName\":\"MKGIsEbVYi\",\"lastName\":\"MKGIsEbVYi\",\"username\":\"MKGIsEbVYi\",\"id\":\"673ff87eb0df5c00019b1eff\",\"_links\":{\"addr
  03:20:55.770 [user] ts=2024-11-22T03:20:55.770582148Z caller=middlewares.go:46 method=Register username=PvCLeeg email=PvCLeeg@gmail.com took=1.055848ms
  03:20:59.685 [carts] 2024-11-22 03:20:59.684 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[GET],produces=[application/hal+json || 
  03:20:59.783 [carts] 2024-11-22 03:20:59.783 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[POST],produces=[application/hal
  03:20:59.885 [carts] 2024-11-22 03:20:59.885 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile/{repository}],methods=[OPTIONS],produces=[appli
  03:21:02.584 [front-end] Posting Customer: {"username":"UFhesIA","password":"rCvijGSfoG","email":"UFhesIA@gmail.com","firstName":"UFhesIA","lastName":"UFhesIA"}
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:21:04.292 [front-end] Posting Customer: {"username":"qYmtssHEvF","password":"vzVuXfLZSc","email":"qYmtssHEvF@gmail.com","firstName":"qYmtssHEvF","lastName":"qYmtssHEvF"}
  03:21:08.790 [carts] 2024-11-22 03:21:08.790 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  03:21:09.807 [front-end] Received response: "{\"firstName\":\"URVWiLVbByzZ\",\"lastName\":\"URVWiLVbByzZ\",\"username\":\"URVWiLVbByzZ\",\"id\":\"673ff889b0df5c00019b1f1d\",\"_links\":{
  03:21:12.988 [carts] 2024-11-22 03:21:12.988 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  03:21:15.278 [user] ts=2024-11-22T03:21:15.27845523Z caller=middlewares.go:46 method=Register username=xlSpYB email=xlSpYB@gmail.com took=1.032808ms
  03:21:17.383 [front-end] Received response: "{\"firstName\":\"isaznhmc\",\"lastName\":\"isaznhmc\",\"username\":\"isaznhmc\",\"id\":\"673ff89db0df5c00019b1f52\",\"_links\":{\"addresses\
  03:21:18.602 [orders] 2024-11-22 03:21:18.602 INFO [orders,145906930ffa3fb8,359c2f868402564c,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×6)
  03:21:18.708 [front-end] Order response: {"id":"673ff8aed94b9000069b438d","customerId":"673ff891b0df5c00019b1f2a","customer":{"id":null,"firstName":"asYAoymkBkzj","lastName":"asYAoymkBk
  03:21:19.317 [front-end] Order response: {"id":"673ff8afd94b9000069b4391","customerId":"673ff896b0df5c00019b1f3c","customer":{"id":null,"firstName":"cfTPDbfduekTBf","lastName":"cfTPDbfd
  03:21:19.922 [front-end] Received response: "{\"firstName\":\"pNgaEfQnfRl\",\"lastName\":\"pNgaEfQnfRl\",\"username\":\"pNgaEfQnfRl\",\"id\":\"673ff899b0df5c00019b1f45\",\"_links\":{\"a
  03:21:20.783 [carts] 2024-11-22 03:21:20.783 INFO [carts,c68cb8218e3d30a3,e9e627c1a2386c43,false] 7 --- [p-nio-80-exec-5] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)

## p0095
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:05:40.030Z
```
{"timestamp":1731906340030942000,"container_name":"adservice","pod_name":"adservice-b9bcc6cc9-h4k2c","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"received ad request (context_words=[clothing, tops])"}
```
Same service, the 2 minutes before (oldest first):
  05:05:34.104 [adservice] received ad request (context_words=[decor, home])
  05:05:34.127 [adservice] received ad request (context_words=[accessories])  (×3)
  05:05:35.094 [adservice] received ad request (context_words=[clothing, tops])  (×4)
  05:05:35.448 [adservice] received ad request (context_words=[])  (×4)
  05:05:37.302 [adservice] received ad request (context_words=[footwear])
  05:05:37.831 [adservice] received ad request (context_words=[kitchen])  (×6)
  05:05:38.212 [adservice] received ad request (context_words=[hair, beauty])
All services, 30 seconds either side (sampled):
  05:05:28.413 [frontend] request started  (×208)
  05:05:28.422 [cartservice] GetCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×173)
  05:05:28.449 [adservice] received ad request (context_words=[accessories])  (×17)
  05:05:28.458 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=1YMWWN1N4O, quantity=7  (×20)
  05:05:28.497 [shippingservice] [GetQuote] completed request  (×47)
  05:05:28.996 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="USD"  (×5)
  05:05:29.017 [checkoutservice] payment went through (transaction_id: e43c7587-0e24-4a72-8d85-16a465855b2a)  (×7)
  05:05:29.021 [cartservice] EmptyCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×7)
  05:05:29.030 [frontend] order placed  (×7)
  05:05:31.741 [adservice] received ad request (context_words=[decor, home])  (×9)
  05:05:32.748 [frontend] ENV_PLATFORM is: aws  (×27)
  05:05:33.869 [adservice] received ad request (context_words=[footwear])  (×14)
  05:05:33.972 [paymentservice] Transaction processed: visa ending 2652 Amount: CAD426.701933656
  05:05:38.673 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×3)
  05:05:46.056 [emailservice] A request to send order confirmation email to fcontreras@example.com has been received.
  05:05:51.642 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13  (×2)
  05:05:51.663 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  05:05:52.043 [redis] 1:M 18 Nov 2024 05:05:52.043 * Background saving started by pid 47
  05:05:52.145 [redis] 1:M 18 Nov 2024 05:05:52.144 * Background saving terminated with success
  05:05:52.522 [paymentservice] Transaction processed: visa ending 2457 Amount: EUR565.165855819
  05:06:04.238 [emailservice] A request to send order confirmation email to michaelacosta@example.net has been received.
  05:06:07.915 [checkoutservice] order confirmation email sent to "cwilson@example.com"

## p0555
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel-service, 2024-12-07T18:22:51.038Z
```
{"timestamp":1733595771038437000,"container_name":"ts-travel-service","pod_name":"ts-travel-service-f6b66dc4d-894nw","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:22:51.038  INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl         : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-53c8-4438-87c8-0321a4d09917, stations=[suzhou, shanghai], distances=[0, 50], startStationId=suzhou, terminalStationId=shanghai})"}
```
Same service, the 2 minutes before (oldest first):
  18:22:50.361 [ts-travel-service] 2024-12-07 18:22:50.361 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d  (×2)
  18:22:50.367 [ts-travel-service] 2024-12-07 18:22:50.367 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×2)
  18:22:50.368 [ts-travel-service] 2024-12-07 18:22:50.368 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Route is: Route{id='f3d4d4ef-693b-4456-8eed-59c0d717dd08', stations=[sha  (×2)
  18:22:50.409 [ts-travel-service] 2024-12-07 18:22:50.409 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter
  18:22:50.420 [ts-travel-service] 2024-12-07 18:22:50.419 INFO 1 --- [io-12346-exec-5] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×2)
  18:22:50.528 [ts-travel-service] 2024-12-07 18:22:50.528 INFO 1 --- [io-12346-exec-4] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  18:22:50.992 [ts-travel-service] 2024-12-07 18:22:50.992 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×4)
  18:22:50.998 [ts-travel-service] 2024-12-07 18:22:50.998 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7
  18:22:50.998 [ts-travel-service] 2024-12-07 18:22:50.998 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×3)
  18:22:51.014 [ts-travel-service] 2024-12-07 18:22:51.014 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=aefcef3f-3
  18:22:51.027 [ts-travel-service] 2024-12-07 18:22:51.027 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0
All services, 30 seconds either side (sampled):
  18:22:21.276 [ts-food-service] 2024-12-07 18:22:21.276 INFO 1 --- [io-18856-exec-4] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×4)
  18:22:23.139 [ts-auth-service] 2024-12-07 18:22:23.139 INFO 1 --- [io-12340-exec-5] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×13)
  18:22:23.362 [ts-basic-service] 2024-12-07 18:22:23.362 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa  (×19)
  18:22:23.404 [ts-order-other-service] 2024-12-07 18:22:23.404 INFO 1 --- [io-12032-exec-6] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×14)
  18:22:23.497 [ts-seat-service] 2024-12-07 18:22:23.496 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left  (×2)
  18:22:23.628 [ts-seat-service] 2024-12-07 18:22:23.628 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : Configs is : Config(name=DirectTicketAllocationProportion, value=0.5, descri  (×58)
  18:22:25.468 [ts-auth-service] 2024-12-07 18:22:25.467 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×3)
  18:22:27.512 [ts-route-mongo] {"t":{"$date":"2024-12-07T18:22:27.512+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359574
  18:22:30.549 [ts-security-mongo] {"t":{"$date":"2024-12-07T18:22:30.549+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359575
  18:22:32.377 [ts-travel-service] 2024-12-07 18:22:32.376 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=084837bb-5  (×13)
  18:22:35.708 [ts-travel-service] 2024-12-07 18:22:35.708 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=nanjing)  (×21)
  18:22:35.851 [ts-travel-service] 2024-12-07 18:22:35.851 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, tr  (×28)
  18:22:35.985 [ts-travel-service] 2024-12-07 18:22:35.985 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×6)
  18:22:42.091 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T18:22:42.091+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359576
  18:22:49.689 [ts-travel2-service] 2024-12-07 18:22:49.688 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  18:22:49.898 [ts-travel-service] 2024-12-07 18:22:49.898 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×2)
  18:22:50.013 [ts-preserve-service] 2024-12-07 18:22:50.013 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 1] Check Security
  18:22:50.066 [ts-security-service] 2024-12-07 18:22:50.064 INFO 1 --- [io-11188-exec-6] security.service.SecurityServiceImpl : [Security Service] Max In One Hour: 2147483647 Max Not Use: 21474836  (×2)
  18:22:50.085 [ts-preserve-service] 2024-12-07 18:22:50.084 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Trip All Detail Information] Getting...
  18:22:50.426 [ts-preserve-service] 2024-12-07 18:22:50.426 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Station Name]  (×2)
  18:22:50.603 [ts-order-service] 2024-12-07 18:22:50.603 INFO 1 --- [io-12031-exec-4] order.controller.OrderController : [Order Service][Verify Login] Success
  18:22:50.639 [ts-preserve-service] 2024-12-07 18:22:50.638 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : [Cancel Order Service][Get Order By Id]
  18:22:52.678 [ts-order-other-service] 2024-12-07 18:22:52.678 INFO 1 --- [io-12032-exec-9] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou  (×2)
  18:22:52.820 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:22:52 +0800] "PUT /api/v1/consignservice/consigns HTTP/1.1" 200 400 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebK
  18:22:57.920 [ts-travel2-service] 2024-12-07 18:22:57.920 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat  (×2)
  18:22:58.228 [ts-preserve-other-service] 2024-12-07 18:22:58.228 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Service] [Step 1] Check Security
  18:22:58.328 [ts-travel2-service] 2024-12-07 18:22:58.328 INFO 1 --- [io-16346-exec-1] travel2.service.Travel2ServiceImpl : [TravelService] [getTripAllDetailInfo] endPlaceID: nanjing
  18:22:58.763 [ts-preserve-other-service] 2024-12-07 18:22:58.763 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Get Contacts By Id] Creating....
  18:22:58.843 [ts-preserve-other-service] 2024-12-07 18:22:58.843 INFO 1 --- [io-14569-exec-6] p.service.PreserveOtherServiceImpl : [Preserve Service]

## p0042
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T08:00:01.228Z
```
{"service":"dbservice2","message":"2021-08-13 08:00:01,228 | ERROR | 0.0.0.2 | dbservice2 | db_helper.py -> db_login_methods -> 42 | 650afb69e5001a4a | dbservice2 access redis service denied"}
```
Same service, the 2 minutes before (oldest first):
  07:59:54.533 [dbservice2] INFO 6355071a-fbc9-11eb-bb05-0242ac110004-ZnrSqIKU-6AR>9IyOXx/3 token generate success token=MTYyODgxMjc5NC41MzMxMTczOjYzNTUwNzFhLWZiYzktMTFlYi1iYjA1LTAyNDJhYzE
  07:59:57.233 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  07:59:57.234 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  07:59:57.298 [dbservice2] INFO query = select passwards from username_table where user_name='CWflULak'  (×4)
  07:59:57.375 [dbservice2] INFO 64ff81e4-fbc9-11eb-909c-0242ac110003-CWflULak-k45a%Ng8.W1z token generate success token=MTYyODgxMjc5Ny4zNzUzNTk1OjY0ZmY4MWU0LWZiYzktMTFlYi05MDljLTAyNDJhYzE
  07:59:57.969 [dbservice2] INFO 655ce0d2-fbc9-11eb-bf83-0242ac110004-LUmfKNIy-SHVeob!8dBT= token generate success token=MTYyODgxMjc5Ny45NjkwNzk6NjU1Y2UwZDItZmJjOS0xMWViLWJmODMtMDI0MmFjMTE
  08:00:00.220 [dbservice2] INFO 66b44038-fbc9-11eb-b542-0242ac110004-SYUdXTMn-#?+cKu8b!U&_ token generate success token=MTYyODgxMjgwMC4yMjAwMTM2OjY2YjQ0MDM4LWZiYzktMTFlYi1iNTQyLTAyNDJhYzE
  08:00:00.476 [dbservice2] INFO 66db9a34-fbc9-11eb-bc14-0242ac110003-GNqpIFum-6p{Revl/Jr90 token generate success token=MTYyODgxMjgwMC40NzYxMjA1OjY2ZGI5YTM0LWZiYzktMTFlYi1iYzE0LTAyNDJhYzE
  08:00:01.227 [dbservice2] ERROR service refuse
All services, 30 seconds either side (sampled):
  07:59:31.232 [webservice1] INFO uuid: 55ca4f6a-fbc9-11eb-9d8c-0242ac110003 write redis successfully  (×37)
  07:59:31.489 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '55ca4f6a-fbc9-11eb-9d8c-0242ac110003', 'value': 'PBlgjmAH'}  (×42)
  07:59:31.609 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  07:59:31.734 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×42)
  07:59:31.789 [dbservice2] INFO query = select passwards from username_table where user_name='PBlgjmAH'  (×18)
  07:59:32.032 [webservice2] INFO uuid: 564a7564-fbc9-11eb-b80a-0242ac110004 write redis successfully  (×35)
  07:59:32.255 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '564a7564-fbc9-11eb-b80a-0242ac110004', 'value': 'SjMAKXaq'}  (×30)
  07:59:33.127 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×31)
  07:59:33.359 [dbservice1] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)  (×3)
  07:59:34.909 [dbservice2] INFO 579f00d8-fbc9-11eb-bc9b-0242ac110004-TdjVXoHa-%Gy+D.NQ!s7p token generate success token=MTYyODgxMjc3NC45MDg5Njk5OjU3OWYwMGQ4LWZiYzktMTFlYi1iYzliLTAyNDJhYzE
  07:59:36.443 [dbservice1] INFO 58925c56-fbc9-11eb-82ba-0242ac110003-pyWndFNv-k$0)mK!%.@XT token generate success token=MTYyODgxMjc3Ni40NDM1NDI6NTg5MjVjNTYtZmJjOS0xMWViLTgyYmEtMDI0MmFjMTE
  07:59:38.602 [mobservice1] INFO info 5a0a5296-fbc9-11eb-8ce9-0242ac110003:AIKNYSvf write success
  07:59:40.541 [dbservice2] INFO 5af7e3b2-fbc9-11eb-94f0-0242ac110004-HfPCXKQO-ko9a.361RV:P token generate success token=MTYyODgxMjc4MC41NDEyOTQ4OjVhZjdlM2IyLWZiYzktMTFlYi05NGYwLTAyNDJhYzE
  07:59:42.939 [dbservice1] INFO 5c67f5a2-fbc9-11eb-9d01-0242ac110003-tjrRfeJy-t5EnZ!FmiUq{ token generate success token=MTYyODgxMjc4Mi45Mzg5MzQzOjVjNjdmNWEyLWZiYzktMTFlYi05ZDAxLTAyNDJhYzE
  07:59:46.025 [dbservice2] INFO 5e3f5d16-fbc9-11eb-8d23-0242ac110004-JdtfzjpK-tGDi)ny2^q0o token generate success token=MTYyODgxMjc4Ni4wMjQ0MzYyOjVlM2Y1ZDE2LWZiYzktMTFlYi04ZDIzLTAyNDJhYzE
  07:59:56.161 [redisservice1] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400
  07:59:56.977 [mobservice2] INFO info 64ff81e4-fbc9-11eb-909c-0242ac110003:CWflULak write success
  07:59:59.246 [mobservice2] INFO info 66585c8c-fbc9-11eb-bb91-0242ac110003:ITDnZiPv write success
  08:00:01.213 [redisservice1] INFO service refuse, status_code: 200  (×11)
  08:00:02.761 [dbservice1] INFO 68319f50-fbc9-11eb-88ed-0242ac110004-lvCfjILw-D1@9U_jQh_$a token generate success token=MTYyODgxMjgwMi43NjE1MTU2OjY4MzE5ZjUwLWZiYzktMTFlYi04OGVkLTAyNDJhYzE
  08:00:05.685 [mobservice2] INFO info 6a1765b6-fbc9-11eb-94ef-0242ac110004:FjQZnIyb write success
  08:00:08.717 [mobservice2] INFO info 6bfabe3c-fbc9-11eb-b484-0242ac110004:KmknXdcJ write success
  08:00:11.946 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  08:00:16.141 [mobservice2] INFO info 706adb5a-fbc9-11eb-83ab-0242ac110003:NAVbZmOn write success
  08:00:18.829 [dbservice1] INFO 71d5a13c-fbc9-11eb-89e4-0242ac110003-hTjCBtGX-eJrbTQXfMu<_ token generate success token=MTYyODgxMjgxOC44Mjg2Mjg1OjcxZDVhMTNjLWZiYzktMTFlYi04OWU0LTAyNDJhYzE
  08:00:22.500 [mobservice2] INFO info 7426d9ba-fbc9-11eb-ad36-0242ac110003:NxPGARft write success

## p0340
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:21:27.606Z
```
{"timestamp":1732245687606451500,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /addresses 200 - ms - -"}
```
Same service, the 2 minutes before (oldest first):
  03:21:27.105 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b7d94b9000069b439d","customerId":"673ff89fb0df5c00019b1f5d","customer":{"id":null,"firstName":"gxEQQKdgPqa
  03:21:27.105 [front-end] Order response: {"id":"673ff8b7d94b9000069b439d","customerId":"673ff89fb0df5c00019b1f5d","customer":{"id":null,"firstName":"gxEQQKdgPqad","lastName":"gxEQQKdgPq
  03:21:27.107 [front-end] POST /orders 201 - ms - -
  03:21:27.187 [front-end] User cart deleted with status: 202  (×3)
  03:21:27.193 [front-end] DELETE /cart 202 - ms - -  (×3)
  03:21:27.198 [front-end] Attempting to add to cart: {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","quantity":1}  (×3)
  03:21:27.203 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×2)
  03:21:27.203 [front-end] POST to carts: http://carts/carts/673ff8abb0df5c00019b1f8d/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}  (×2)
  03:21:27.405 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":
  03:21:27.405 [front-end] POST to carts: http://carts/carts/673ff8acb0df5c00019b1f91/items body: {"itemId":"819e1fbf-8b7e-4f6d-811f-693534916a8b","unitPrice":14}
  03:21:27.521 [front-end] GET /catalogue 200 - ms - -
  03:21:27.597 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673ff8aab0df5c00019b1f8c"}
All services, 30 seconds either side (sampled):
  03:20:57.661 [front-end] Carts merged.  (×58)
  03:20:58.153 [catalogue] ts=2024-11-22T03:20:58Z caller=logging.go:62 method=Get id=03fef6ac-1896-4ce8-bd69-b798f85c6e0b sock=03fef6ac-1896-4ce8-bd69-b798f85c6e0b err=null took=5.109327  (×57)
  03:20:58.190 [user] ts=2024-11-22T03:20:58.190466948Z caller=middlewares.go:75 method=GetUsers id=673ff87eb0df5c00019b1f00 result=1 took=2.170063ms  (×44)
  03:20:59.102 [front-end] 673ff89bb0df5c00019b1f4c  (×57)
  03:20:59.689 [carts] 2024-11-22 03:20:59.689 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[GET],produces=[application
  03:20:59.788 [carts] 2024-11-22 03:20:59.788 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search],methods=[GET],produces=[applicati
  03:21:00.093 [user] ts=2024-11-22T03:21:00.09301447Z caller=middlewares.go:157 method=Health result=2 took=769.193µs  (×35)
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/resume || /resume.json],methods=[POST]}" onto public jav
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  03:21:04.782 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×8)
  03:21:08.987 [carts] 2024-11-22 03:21:08.987 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  03:21:11.685 [carts] 2024-11-22 03:21:11.685 INFO [carts,,,] 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  03:21:14.097 [user] ts=2024-11-22T03:21:14.097040605Z caller=middlewares.go:46 method=Register username=GaVMS email=GaVMS@gmail.com took=1.031461ms
  03:21:16.388 [carts] 2024-11-22 03:21:16.294 INFO [carts,4f4200e92a2346f2,c605b8bba205809d,false] 7 --- [-nio-80-exec-10] org.mongodb.driver.connection : Opened connection [connecti  (×8)
  03:21:18.602 [orders] 2024-11-22 03:21:18.602 INFO [orders,40393c2387463fc4,20a8cb1f4ece78de,false] 6 --- [p-nio-80-exec-5] w.w.s.o.controllers.OrdersController : Received payment re  (×30)
  03:21:18.809 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8aed94b9000069b438e","customerId":"673ff896b0df5c00019b1f37","customer":{"id":null,"firstName":"kJMPYF","la
  03:21:19.500 [queue-master] 2024-11-22 03:21:19.500 INFO 6 --- [pool-6-thread-4] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×27)
  03:21:20.204 [front-end] Order response: {"id":"673ff8b0d94b9000069b4395","customerId":"673ff8a0b0df5c00019b1f61","customer":{"id":null,"firstName":"qklQL","lastName":"qklQL","username"
  03:21:21.517 [front-end] Order response: {"id":"673ff8b1d94b9000069b4399","customerId":"673ff89db0df5c00019b1f53","customer":{"id":null,"firstName":"EFvIPXnJWRPmy","lastName":"EFvIPXnJW
  03:21:26.555 [front-end] Posting Customer: {"username":"ZaeWmQ","password":"ITGipAu","email":"ZaeWmQ@gmail.com","firstName":"ZaeWmQ","lastName":"ZaeWmQ"}
  03:21:29.663 [user] ts=2024-11-22T03:21:29.663548471Z caller=middlewares.go:46 method=Register username=QoPcWQ email=QoPcWQ@gmail.com took=1.079037ms
  03:21:34.256 [front-end] Order response: {"id":"673ff8bed94b9000069b439f","customerId":"673ff8a8b0df5c00019b1f85","customer":{"id":null,"firstName":"yXmVwShR","lastName":"yXmVwShR","use
  03:21:36.221 [front-end] Received response: "{\"firstName\":\"onbFNMM\",\"lastName\":\"onbFNMM\",\"username\":\"onbFNMM\",\"id\":\"673ff8a7b0df5c00019b1f82\",\"_links\":{\"addresses\":{
  03:21:38.705 [front-end] Order response: {"id":"673ff8c2d94b9000069b43a5","customerId":"673ff8acb0df5c00019b1f92","customer":{"id":null,"firstName":"jStfWCKVIxuZsZx","lastName":"jStfWCK
  03:21:42.648 [user] ts=2024-11-22T03:21:42.648286081Z caller=middlewares.go:46 method=Register username=xJlcQpb email=xJlcQpb@gmail.com took=1.008427ms
  03:21:45.051 [front-end] Order response: {"id":"673ff8c9d94b9000069b43aa","customerId":"673ff8b3b0df5c00019b1f9d","customer":{"id":null,"firstName":"BHMHa","lastName":"BHMHa","username"
  03:21:50.280 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8ced94b9000069b43ae","customerId":"673ff8bdb0df5c00019b1fb2","customer":{"id":null,"firstName":"sYvdDM","la
  03:21:54.473 [front-end] Order response: {"id":"673ff8d2d94b9000069b43b1","customerId":"673ff8bcb0df5c00019b1fb1","customer":{"id":null,"firstName":"tEhusfT","lastName":"tEhusfT","usern
  03:21:56.520 [front-end] Received response: "{\"firstName\":\"DXXEAuEZfGxuPq\",\"lastName\":\"DXXEAuEZfGxuPq\",\"username\":\"DXXEAuEZfGxuPq\",\"id\":\"673ff8c0b0df5c00019b1fbc\",\"_lin

## p0525
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-23T10:58:14.852Z
```
{"timestamp":1732359494852999000,"container_name":"user","pod_name":"user-558cdfd768-hxw6d","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"ts=2024-11-23T10:58:14.852862371Z caller=middlewares.go:75 method=GetUsers id=6741b535a437380001df5468 result=1 took=1.850271ms"}
```
Same service, the 2 minutes before (oldest first):
  10:58:09.963 [user] ts=2024-11-23T10:58:09.963528829Z caller=middlewares.go:46 method=Register username=ivmpz email=ivmpz@gmail.com took=2.097412ms
  10:58:10.171 [user] ts=2024-11-23T10:58:10.171237669Z caller=middlewares.go:46 method=Register username=vpSECXgC email=vpSECXgC@gmail.com took=2.660884ms
  10:58:10.711 [user] ts=2024-11-23T10:58:10.710936619Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=6741b538a437380001df5469 took=4.720837ms  (×3)
  10:58:10.725 [user] ts=2024-11-23T10:58:10.725705905Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6741b538a437380001df5469 took=3.810876ms  (×3)
  10:58:10.819 [user] ts=2024-11-23T10:58:10.819289252Z caller=middlewares.go:46 method=Register username=wScMVduv email=wScMVduv@gmail.com took=2.911071ms
  10:58:10.848 [user] ts=2024-11-23T10:58:10.848889419Z caller=middlewares.go:157 method=Health result=2 took=2.29858ms  (×4)
  10:58:10.888 [user] ts=2024-11-23T10:58:10.888284398Z caller=middlewares.go:46 method=Register username=NIhXZJjJLUsCq email=NIhXZJjJLUsCq@gmail.com took=2.139829ms  (×4)
  10:58:13.055 [user] ts=2024-11-23T10:58:13.055151044Z caller=middlewares.go:46 method=Register username=WcpWgwhF email=WcpWgwhF@gmail.com took=2.200825ms
  10:58:14.181 [user] ts=2024-11-23T10:58:14.180710733Z caller=middlewares.go:46 method=Register username=joUpLDVGg email=joUpLDVGg@gmail.com took=1.601965ms
  10:58:14.554 [user] ts=2024-11-23T10:58:14.554600165Z caller=middlewares.go:46 method=Register username=eNIubTXdi email=eNIubTXdi@gmail.com took=2.509084ms
All services, 30 seconds either side (sampled):
  10:57:45.384 [catalogue] ts=2024-11-23T10:57:45Z caller=logging.go:85 method=Health result=2 took=31.021µs  (×40)
  10:57:53.940 [front-end] GET /catalogue 200 - ms - -  (×50)
  10:57:57.603 [front-end] 6741b535a437380001df5468  (×21)
  10:57:57.638 [front-end] set cookie6741b535a437380001df5468  (×21)
  10:58:00.663 [carts] 2024-11-23 10:58:00.663 INFO [carts,0de42ae5d773b963,95c349d174013d5e,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×8)
  10:58:02.031 [front-end] Posting Customer: {"username":"TRIBx","password":"psKUl","email":"TRIBx@gmail.com","firstName":"TRIBx","lastName":"TRIBx"}
  10:58:04.648 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b535a437380001df5468"}  (×7)
  10:58:04.675 [user] ts=2024-11-23T10:58:04.674837946Z caller=middlewares.go:118 method=PostCard card=*****3321 user=6741b535a437380001df5468 took=4.342692ms  (×7)
  10:58:04.757 [front-end] DELETE /cart 202 - ms - -  (×7)
  10:58:04.774 [front-end] POST to carts: http://carts/carts/6741b535a437380001df5468/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}  (×4)
  10:58:07.148 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  10:58:07.343 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca
  10:58:08.977 [front-end] Posting Customer: {"username":"pOzMeLaxbALvLyJ","password":"xmCzYil","email":"pOzMeLaxbALvLyJ@gmail.com","firstName":"pOzMeLaxbALvLyJ","lastName":"pOzMeLaxbALvL
  10:58:09.767 [user] ts=2024-11-23T10:58:09.766942866Z caller=middlewares.go:46 method=Register username=nteTFRaAE email=nteTFRaAE@gmail.com took=3.141973ms
  10:58:10.163 [front-end] Posting Customer: {"username":"vpSECXgC","password":"ZrJDPHyp","email":"vpSECXgC@gmail.com","firstName":"vpSECXgC","lastName":"vpSECXgC"}
  10:58:10.822 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata
  10:58:13.048 [front-end] Posting Customer: {"username":"WcpWgwhF","password":"iIirtYMa","email":"WcpWgwhF@gmail.com","firstName":"WcpWgwhF","lastName":"WcpWgwhF"}
  10:58:14.174 [front-end] Posting Customer: {"username":"joUpLDVGg","password":"GXkBHIi","email":"joUpLDVGg@gmail.com","firstName":"joUpLDVGg","lastName":"joUpLDVGg"}
  10:58:14.845 [front-end] Request received with body: {}
  10:58:14.873 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b53ca437380001df546f\",\"_links\":{\"
  10:58:14.890 [user] ts=2024-11-23T10:58:14.890724743Z caller=middlewares.go:104 method=GetAddresses id=6741b53ca437380001df546e result=1 took=1.818989ms
  10:58:14.910 [orders] 2024-11-23 10:58:14.910 INFO [orders,8a17b4e84f8ec2d0,40f87b260ecc2b79,false] 7 --- [p-nio-80-exec-8] w.w.s.o.controllers.OrdersController : Received payment re
  10:58:14.921 [queue-master] 2024-11-23 10:58:14.921 INFO 7 --- [ool-6-thread-22] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×3)
  10:58:14.937 [front-end] Order response: undefined
  10:58:14.948 [front-end] npm timing command:run-script Completed in 39004ms
  10:58:14.949 [front-end] npm notice Changelog: <https://github.com/npm/cli/releases/tag/v10.9.1>
  10:58:14.950 [front-end] npm verb code 1

## p0552
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T18:22:14.448Z
```
{"timestamp":1733595734448258600,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-kwkx6","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 18:22:14.448  INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl       : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Internal Success, data=1073741802)"}
```
Same service, the 2 minutes before (oldest first):
  18:22:12.880 [ts-travel2-service] 2024-12-07 18:22:12.880 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×7)
  18:22:12.886 [ts-travel2-service] 2024-12-07 18:22:12.885 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×7)
  18:22:14.166 [ts-travel2-service] 2024-12-07 18:22:14.166 INFO 1 --- [io-16346-exec-3] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
  18:22:14.317 [ts-travel2-service] 2024-12-07 18:22:14.316 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  18:22:14.330 [ts-travel2-service] 2024-12-07 18:22:14.329 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  18:22:14.391 [ts-travel2-service] 2024-12-07 18:22:14.390 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024, 
  18:22:14.398 [ts-travel2-service] 2024-12-07 18:22:14.398 INFO 1 --- [io-16346-exec-6] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234
  18:22:14.406 [ts-travel2-service] 2024-12-07 18:22:14.406 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
All services, 30 seconds either side (sampled):
  18:21:44.454 [ts-travel-service] 2024-12-07 18:21:44.453 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：f3d4d4ef-693b-4456-8eed-59c0d  (×68)
  18:21:46.059 [ts-basic-service] 2024-12-07 18:21:46.059 INFO 1 --- [io-15680-exec-2] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×96)
  18:21:46.125 [ts-price-service] 2024-12-07 18:21:46.125 INFO 1 --- [io-16579-exec-5] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×24)
  18:21:46.192 [ts-seat-service] 2024-12-07 18:21:46.191 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D G1234  (×11)
  18:21:46.348 [ts-seat-service] 2024-12-07 18:21:46.348 INFO 1 --- [io-18898-exec-9] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×20)
  18:21:46.478 [ts-basic-service] 2024-12-07 18:21:46.478 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×7)
  18:21:46.729 [ts-seat-service] 2024-12-07 18:21:46.729 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×3)
  18:21:47.499 [ts-admin-basic-info-service] 2024-12-07 18:21:47.499 INFO 1 --- [io-18767-exec-6] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Config by admin   (×11)
  18:21:52.907 [ts-travel-service] 2024-12-07 18:21:52.906 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×7)
  18:21:55.978 [ts-basic-service] 2024-12-07 18:21:55.978 INFO 1 --- [io-15680-exec-9] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×6)
  18:21:56.213 [ts-order-other-service] 2024-12-07 18:21:56.212 INFO 1 --- [io-12032-exec-5] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×31)
  18:21:56.694 [ts-travel2-service] 2024-12-07 18:21:56.694 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×11)
  18:21:59.048 [ts-travel-service] 2024-12-07 18:21:59.048 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=suzhou)  (×6)
  18:21:59.286 [ts-seat-service] 2024-12-07 18:21:59.285 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×3)
  18:21:59.406 [ts-security-service] 2024-12-07 18:21:59.405 INFO 1 --- [io-11188-exec-9] security.controller.SecurityController : [Security Service][Check Security] Check Account Id: 4d2a46c7-71cb
  18:21:59.462 [ts-preserve-service] 2024-12-07 18:21:59.462 INFO 1 --- [io-14568-exec-6] preserve.service.PreserveServiceImpl : [Preserve Service] [Step 2] Find contacts
  18:21:59.596 [ts-basic-service] 2024-12-07 18:21:59.596 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: DongChe  (×2)
  18:22:00.177 [ts-seat-service] 2024-12-07 18:22:00.176 INFO 1 --- [io-18898-exec-7] seat.service.SeatServiceImpl : [SeatService distributeSeat] TrainNumber start with G|D
  18:22:00.294 [ts-order-service] 2024-12-07 18:22:00.294 INFO 1 --- [io-12031-exec-5] order.service.OrderServiceImpl : [Order Service][Order Create] Success.
  18:22:01.343 [ts-preserve-other-service] 2024-12-07 18:22:01.342 INFO 1 --- [io-14569-exec-8] p.controller.PreserveOtherController : [Preserve Other Service][Preserve] Account order from Shang Hai ----
  18:22:01.388 [ts-security-service] 2024-12-07 18:22:01.388 INFO 1 --- [o-11188-exec-10] security.service.SecurityServiceImpl : [Security Service][Get Security Config Info]
  18:22:01.437 [ts-order-other-service] 2024-12-07 18:22:01.436 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order] Get order num: 23
  18:22:01.779 [ts-preserve-other-service] 2024-12-07 18:22:01.778 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Step 2] Complete
  18:22:02.241 [ts-preserve-other-service] 2024-12-07 18:22:02.240 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Other Service][Order] Order Travel Date: Sat Dec 07 00:00:00
  18:22:02.311 [ts-preserve-other-service] 2024-12-07 18:22:02.311 INFO 1 --- [io-14569-exec-8] p.service.PreserveOtherServiceImpl : [Preserve Service][Add Assurance Type For Order]
  18:22:03.530 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:22:03 +0800] "POST /api/v1/orderservice/order/refresh HTTP/1.1" 200 14819 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) App  (×2)
  18:22:19.996 [ts-price-service] 2024-12-07 18:22:19.995 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route And Train Type] Rote: 0b23bd3e-876a-4af3-b92  (×2)
  18:22:25.468 [ts-auth-service] 2024-12-07 18:22:25.466 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×2)
  18:22:29.805 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T18:22:29.805+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359574
  18:22:35.972 [ts-travel-service] 2024-12-07 18:22:35.972 INFO 1 --- [o-12346-exec-10] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234

## p0291
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T02:38:05.958Z
```
{"timestamp":1732243085958524700,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T02:38:05.958310419Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673fee88b0df5c00019b007c took=1.503631ms"}
```
Same service, the 2 minutes before (oldest first):
  02:38:02.628 [user] ts=2024-11-22T02:38:02.628048623Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673fee85b0df5c00019b0074 took=1.538877ms  (×5)
  02:38:02.674 [user] ts=2024-11-22T02:38:02.674168877Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673fee83b0df5c00019b0069 took=1.504781ms  (×5)
  02:38:03.093 [user] ts=2024-11-22T02:38:03.093733431Z caller=middlewares.go:157 method=Health result=2 took=760.057µs  (×2)
  02:38:04.159 [user] ts=2024-11-22T02:38:04.15934174Z caller=middlewares.go:75 method=GetUsers id=673fee7fb0df5c00019b0064 result=1 took=1.030313ms  (×2)
  02:38:04.165 [user] ts=2024-11-22T02:38:04.165823446Z caller=middlewares.go:75 method=GetUsers id=673fee7fb0df5c00019b0064 result=1 took=721.003µs  (×2)
  02:38:04.175 [user] ts=2024-11-22T02:38:04.175282703Z caller=middlewares.go:104 method=GetAddresses id=673fee86b0df5c00019b0076 result=1 took=698.073µs
  02:38:04.175 [user] ts=2024-11-22T02:38:04.175667303Z caller=middlewares.go:134 method=GetCards id=673fee86b0df5c00019b0078 result=1 took=947.067µs
  02:38:04.687 [user] ts=2024-11-22T02:38:04.686912742Z caller=middlewares.go:46 method=Register username=wKBrh email=wKBrh@gmail.com took=1.022238ms
  02:38:05.586 [user] ts=2024-11-22T02:38:05.586086586Z caller=middlewares.go:46 method=Register username=BlXXP email=BlXXP@gmail.com took=1.056389ms
All services, 30 seconds either side (sampled):
  02:37:36.093 [user] ts=2024-11-22T02:37:36.093752256Z caller=middlewares.go:157 method=Health result=2 took=760.767µs  (×38)
  02:37:36.393 [front-end] Sent cookies.  (×61)
  02:37:36.926 [front-end] Attempting to add to cart: {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","quantity":1}  (×61)
  02:37:37.504 [user] ts=2024-11-22T02:37:37.504402472Z caller=middlewares.go:75 method=GetUsers id=673fee60b0df5c00019b0007 result=1 took=928.384µs  (×174)
  02:37:37.534 [orders] 2024-11-22 02:37:37.533 INFO [orders,0b606114762bb612,c0575e42c4a7e37d,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re  (×24)
  02:37:38.918 [queue-master] Received shipment task: 673fee5fb0df5c00019b0001  (×51)
  02:37:39.570 [user] ts=2024-11-22T02:37:39.570109574Z caller=middlewares.go:46 method=Register username=dRtRtCrsx email=dRtRtCrsx@gmail.com took=962.532µs
  02:37:40.437 [front-end] Received response: "{\"firstName\":\"zDsICrcQerytPbB\",\"lastName\":\"zDsICrcQerytPbB\",\"username\":\"zDsICrcQerytPbB\",\"id\":\"673fee62b0df5c00019b0010\",\"_
  02:37:41.767 [front-end] Posting Customer: {"username":"senehdf","password":"HpJNDmJrcw","email":"senehdf@gmail.com","firstName":"senehdf","lastName":"senehdf"}
  02:37:44.126 [front-end] {"id":"03fef6ac-1896-4ce8-bd69-b798f85c6e0b","name":"Holy","description":"Socks fit for a Messiah. You too can experience walking in water with these special ed  (×5)
  02:37:47.074 [front-end] Received response: "{\"firstName\":\"jYuOxvFQtR\",\"lastName\":\"jYuOxvFQtR\",\"username\":\"jYuOxvFQtR\",\"id\":\"673fee6db0df5c00019b0034\",\"_links\":{\"addr
  02:37:50.027 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee7ed94b9000069b3be7","customerId":"673fee6ab0df5c00019b002b","customer":{"id":null,"firstName":"YyImEFH","l
  02:37:52.558 [front-end] Received response: "{\"firstName\":\"ZypLtE\",\"lastName\":\"ZypLtE\",\"username\":\"ZypLtE\",\"id\":\"673fee70b0df5c00019b0039\",\"_links\":{\"addresses\":{\"h
  02:37:54.723 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee82d94b9000069b3bec","customerId":"673fee72b0df5c00019b003d","customer":{"id":null,"firstName":"uvSVJERRqrH
  02:37:56.938 [user] ts=2024-11-22T02:37:56.938090374Z caller=middlewares.go:46 method=Register username=PRfNWzJMJqg email=PRfNWzJMJqg@gmail.com took=973.162µs  (×6)
  02:38:01.014 [front-end] Received response: "{\"firstName\":\"lOysifocIyaP\",\"lastName\":\"lOysifocIyaP\",\"username\":\"lOysifocIyaP\",\"id\":\"673fee6db0df5c00019b0033\",\"_links\":{
  02:38:04.683 [front-end] Posting Customer: {"username":"wKBrh","password":"GYrtanzQ","email":"wKBrh@gmail.com","firstName":"wKBrh","lastName":"wKBrh"}
  02:38:07.487 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee8fd94b9000069b3bf3","customerId":"673fee78b0df5c00019b0054","customer":{"id":null,"firstName":"gLTrOHLOOlj
  02:38:08.564 [front-end] Posting Customer: {"username":"OTmchGTAvvrH","password":"OemszTPLUD","email":"OTmchGTAvvrH@gmail.com","firstName":"OTmchGTAvvrH","lastName":"OTmchGTAvvrH"}
  02:38:11.042 [front-end] Received response: "{\"firstName\":\"aERlPcwCIQtcOHc\",\"lastName\":\"aERlPcwCIQtcOHc\",\"username\":\"aERlPcwCIQtcOHc\",\"id\":\"673fee7ab0df5c00019b005a\",\"_
  02:38:13.061 [front-end] Order response: {"statusCode":201,"body":{"id":"673fee95d94b9000069b3bfa","customerId":"673fee85b0df5c00019b0075","customer":{"id":null,"firstName":"PYKlcZVdA",
  02:38:14.563 [front-end] Order response: {"id":"673fee96d94b9000069b3bfc","customerId":"673fee80b0df5c00019b0066","customer":{"id":null,"firstName":"yHNGklHdnZmumTM","lastName":"yHNGklH
  02:38:19.091 [front-end] Received response: "{\"firstName\":\"MFPenYarqDA\",\"lastName\":\"MFPenYarqDA\",\"username\":\"MFPenYarqDA\",\"id\":\"673fee88b0df5c00019b007c\",\"_links\":{\"a
  02:38:19.859 [front-end] Posting Customer: {"username":"uVapLGZrlWwgs","password":"XVvQPXcBT","email":"uVapLGZrlWwgs@gmail.com","firstName":"uVapLGZrlWwgs","lastName":"uVapLGZrlWwgs"}
  02:38:22.153 [front-end] Order response: {"id":"673fee9ed94b9000069b3c04","customerId":"673fee87b0df5c00019b007b","customer":{"id":null,"firstName":"NdCRwdn","lastName":"NdCRwdn","usern
  02:38:26.693 [front-end] Order response: {"statusCode":201,"body":{"id":"673feea2d94b9000069b3c07","customerId":"673fee90b0df5c00019b0094","customer":{"id":null,"firstName":"SogMqHGdJMs
  02:38:28.695 [user] ts=2024-11-22T02:38:28.694768209Z caller=middlewares.go:46 method=Register username=yfgASniKQ email=yfgASniKQ@gmail.com took=912.852µs
  02:38:29.600 [front-end] Posting Customer: {"username":"RcxBkQyVUiYGB","password":"PQuBZau","email":"RcxBkQyVUiYGB@gmail.com","firstName":"RcxBkQyVUiYGB","lastName":"RcxBkQyVUiYGB"}
  02:38:31.315 [front-end] Posting Customer: {"username":"jCRdMb","password":"bFvQKUQW","email":"jCRdMb@gmail.com","firstName":"jCRdMb","lastName":"jCRdMb"}
  02:38:32.159 [front-end] Order response: {"id":"673feea8d94b9000069b3c0d","customerId":"673fee8cb0df5c00019b0088","customer":{"id":null,"firstName":"wKBrh","lastName":"wKBrh","username"

## p0629
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T20:18:08.488Z
```
{"timestamp":1733602688488359200,"container_name":"ts-auth-service","pod_name":"ts-auth-service-75dfb9459b-ntppp","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 20:18:08.488  INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl       : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbIlJPTEVfQURNSU4iXSwiaWQiOiI3ZTI0NTM3MS0wNDMzLTQ1NWEtOTk1Mi0zMDM5YmU2MmYzNDEiLCJpYXQiOjE3MzM2MDI2ODgsImV4cCI6MTczMzYwNjI4OH0.q8ewS3xXQFWxO9W0LhKi4iV1VALyVXjY3nEKVKfWKrsUSER TOKEN"}
```
Same service, the 2 minutes before (oldest first):
  20:17:53.865 [ts-auth-service] 2024-12-07 20:17:53.865 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×5)
  20:17:53.865 [ts-auth-service] 2024-12-07 20:17:53.865 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×5)
  20:17:57.112 [ts-auth-service] 2024-12-07 20:17:57.112 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×2)
  20:17:57.112 [ts-auth-service] 2024-12-07 20:17:57.112 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×2)
  20:17:59.249 [ts-auth-service] 2024-12-07 20:17:59.249 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×2)
  20:17:59.249 [ts-auth-service] 2024-12-07 20:17:59.249 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×2)
  20:18:08.262 [ts-auth-service] 2024-12-07 20:18:08.261 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null
  20:18:08.262 [ts-auth-service] 2024-12-07 20:18:08.261 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin
All services, 30 seconds either side (sampled):
  20:17:38.748 [ts-food-service] 2024-12-07 20:17:38.748 INFO 1 --- [io-18856-exec-5] foodsearch.controller.FoodController : [Food Service]Get the Get Food Request!  (×2)
  20:17:38.802 [ts-food-service] org.springframework.web.client.HttpServerErrorException: 500 Internal Server Error at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Def
  20:17:40.283 [ts-admin-travel-service] org.springframework.web.client.HttpServerErrorException: 500 Internal Server Error at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Def  (×7)
  20:17:42.177 [ts-route-service] 2024-12-07 20:17:42.176 INFO 1 --- [ost-startStop-1] o.s.web.context.ContextLoader : Root WebApplicationContext: initialization completed in 16914 ms
  20:17:43.876 [ts-route-service] 2024-12-07 20:17:43.875 INFO 1 --- [ost-startStop-1] o.s.b.w.servlet.ServletRegistrationBean : Mapping servlet: 'dispatcherServlet' to [/]
  20:17:46.960 [ts-route-service] 2024-12-07 20:17:46.959 INFO 1 --- [ute-mongo:27017] org.mongodb.driver.cluster : Discovered cluster type of STANDALONE
  20:17:51.167 [ts-route-service] 2024-12-07 20:17:51.167 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/api/v1/routeservice/routes/{routeId}],methods=[DELETE]}" onto p
  20:17:51.174 [ts-route-service] 2024-12-07 20:17:51.174 INFO 1 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.ResponseEntity<ja
  20:17:52.761 [ts-route-service] 2024-12-07 20:17:52.761 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/loggers || /loggers.json],methods=[GET],produces=[application/vnd.s
  20:17:53.676 [ts-auth-service] 2024-12-07 20:17:53.676 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×8)
  20:17:53.924 [ts-travel2-service] org.springframework.web.client.HttpServerErrorException: 503 Service Unavailable at org.springframework.web.client.DefaultResponseErrorHandler.handleError(Defau  (×3)
  20:17:57.955 [ts-travel-service] 2024-12-07 20:17:57.955 INFO 1 --- [io-12346-exec-7] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×15)
  20:18:00.972 [ts-route-service] 2024-12-07 20:18:00.972 INFO 1 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  20:18:03.286 [ts-basic-service] 2024-12-07 20:18:03.286 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan  (×3)
  20:18:04.554 [ts-route-service] 2024-12-07 20:18:04.554 INFO 1 --- [ main] route.service.RouteServiceImpl : Create And Modify Start: suzhou End: shanghai
  20:18:09.861 [ts-travel-service] 2024-12-07 20:18:09.861 INFO 1 --- [io-12346-exec-4] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×37)
  20:18:10.565 [ts-travel2-service] 2024-12-07 20:18:10.564 INFO 1 --- [io-16346-exec-3] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×69)
  20:18:11.797 [ts-price-service] 2024-12-07 20:18:11.796 INFO 1 --- [io-16579-exec-4] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×9)
  20:18:11.878 [ts-travel2-service] 2024-12-07 20:18:11.878 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×8)
  20:18:11.927 [ts-seat-service] 2024-12-07 20:18:11.927 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=1, msg=Success, data=Left
  20:18:12.011 [ts-travel2-service] 2024-12-07 20:18:12.010 INFO 1 --- [io-16346-exec-9] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success  (×9)
  20:18:15.169 [ts-price-service] 2024-12-07 20:18:15.169 INFO 1 --- [o-16579-exec-10] price.service.PriceServiceImpl : [Price Service][Find By Route Id And Train Type]  (×2)
  20:18:15.453 [ts-inside-payment-service] 2024-12-07 20:18:15.453 INFO 1 --- [io-18673-exec-1] i.service.InsidePaymentServiceImpl : [Inside Payment Service][Pay] Error. Order status Not allowed to Pay.
  20:18:22.705 [ts-basic-service] 2024-12-07 20:18:22.705 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×4)
  20:18:22.854 [ts-travel-service] 2024-12-07 20:18:22.853 INFO 1 --- [io-12346-exec-1] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234  (×11)
  20:18:23.077 [ts-admin-travel-service] 2024-12-07 20:18:23.077 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get Travel From ts-travel-service successfully!]  (×2)
  20:18:23.586 [ts-basic-service] 2024-12-07 20:18:23.586 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：084837bb-53  (×2)
  20:18:28.302 [ts-travel-mongo] {"t":{"$date":"2024-12-07T20:18:28.302+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360270
  20:18:31.165 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-07T20:18:31.165+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360271
  20:18:32.263 [ts-order-mongo] {"t":{"$date":"2024-12-07T20:18:32.263+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360271
