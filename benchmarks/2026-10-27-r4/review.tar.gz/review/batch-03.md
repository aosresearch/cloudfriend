## p0646
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice1, 2021-08-11T00:23:01.466Z
```
{"service":"logservice1","message":"2021-08-11 00:23:01,466 | INFO | 0.0.0.3 | 172.17.0.3 | logservice1 | e8a1a3d07adab105 | now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  00:22:58.188 [logservice1] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': '392cf94e-f9f7-11eb-857b-0242ac110004', 'user_id': 'Jcofhzdp'}  (×5)
  00:22:58.862 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×3)
  00:22:58.862 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×2)
  00:23:00.442 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×2)
  00:23:00.443 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×2)
  00:23:00.444 [logservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '3a9c60a8-f9f7-11eb-9d57-0242ac110003'}  (×2)
  00:23:00.503 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×2)
  00:23:00.504 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×2)
All services, 30 seconds either side (sampled):
  00:22:31.499 [redisservice1] INFO service accept, status_code: 200  (×44)
  00:22:31.826 [webservice1] INFO complete information: {'uuid': '29b22692-f9f7-11eb-9e7b-0242ac110003', 'user_id': 'LKtqBVoF'}  (×39)
  00:22:31.973 [mobservice1] INFO info 29b22692-f9f7-11eb-9e7b-0242ac110003:LKtqBVoF write success
  00:22:32.106 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×42)
  00:22:32.182 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×42)
  00:22:32.347 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '29f3cf98-f9f7-11eb-a6ef-0242ac110004'}  (×40)
  00:22:32.803 [dbservice2] INFO 29f3cf98-f9f7-11eb-a6ef-0242ac110004-AfSqKhsi->emTu&{%^-K? token generate success token=MTYyODYxMjU1Mi44MDI1NDk6MjlmM2NmOTgtZjlmNy0xMWViLWE2ZWYtMDI0MmFjMTE
  00:22:34.576 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×41)
  00:22:35.185 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×38)
  00:22:37.435 [dbservice1] INFO 2cb2d9c2-f9f7-11eb-897a-0242ac110004-QzCIyEtF-!pHZI}Si_Uby token generate success token=MTYyODYxMjU1Ny40MzQ4ODcyOjJjYjJkOWMyLWY5ZjctMTFlYi04OTdhLTAyNDJhYzE
  00:22:39.878 [dbservice1] INFO 2e2aedf8-f9f7-11eb-98d2-0242ac110003-IQZdkFax-nM=:B>7Dz)0a token generate success token=MTYyODYxMjU1OS44Nzc5NzQ3OjJlMmFlZGY4LWY5ZjctMTFlYi05OGQyLTAyNDJhYzE
  00:22:42.383 [dbservice1] INFO 2f9ce0a6-f9f7-11eb-8a39-0242ac110004-VyLzqQJk-}pyOM4tuZwb_ token generate success token=MTYyODYxMjU2Mi4zODM1MToyZjljZTBhNi1mOWY3LTExZWItOGEzOS0wMjQyYWMxMTA
  00:22:44.873 [dbservice1] INFO 31183354-f9f7-11eb-aae7-0242ac110003-ELQbKFma-9T(1h8zuNDx_ token generate success token=MTYyODYxMjU2NC44NzI5ODY6MzExODMzNTQtZjlmNy0xMWViLWFhZTctMDI0MmFjMTE
  00:22:47.534 [dbservice1] INFO 32af8f8c-f9f7-11eb-91fa-0242ac110003-plhmCNjI-Qi)olTmvH02J token generate success token=MTYyODYxMjU2Ny41MzQ0MzQ2OjMyYWY4ZjhjLWY5ZjctMTFlYi05MWZhLTAyNDJhYzE
  00:22:50.160 [dbservice2] INFO 344186ac-f9f7-11eb-929e-0242ac110003-IKTgrkvl-puzDw*h+_H#V token generate success token=MTYyODYxMjU3MC4xNjA0MDgzOjM0NDE4NmFjLWY5ZjctMTFlYi05MjllLTAyNDJhYzE
  00:22:52.865 [dbservice1] INFO 35dafbba-f9f7-11eb-9a12-0242ac110003-LXQegUZS-iNwdpV=%fU<F token generate success token=MTYyODYxMjU3Mi44NjQ2ODk2OjM1ZGFmYmJhLWY5ZjctMTFlYi05YTEyLTAyNDJhYzE
  00:22:55.566 [dbservice2] INFO 378124d0-f9f7-11eb-bd74-0242ac110004-bGtJCiAM-5{+Aa/EZ2QN( token generate success token=MTYyODYxMjU3NS41NjU1ODkyOjM3ODEyNGQwLWY5ZjctMTFlYi1iZDc0LTAyNDJhYzE
  00:22:58.693 [mobservice1] INFO info 39822176-f9f7-11eb-adb7-0242ac110004:uLFWxbvM write success
  00:23:03.771 [mobservice2] INFO info 3c9bec0c-f9f7-11eb-89df-0242ac110004:SsCTdeWm write success
  00:23:12.008 [mobservice2] INFO info 41856bee-f9f7-11eb-97f0-0242ac110004:LxiphWgj write success
  00:23:14.617 [dbservice1] INFO 42e5404a-f9f7-11eb-aa72-0242ac110003-IKTgrkvl-puzDw*h+_H#V token generate success token=MTYyODYxMjU5NC42MTczMDQzOjQyZTU0MDRhLWY5ZjctMTFlYi1hYTcyLTAyNDJhYzE
  00:23:17.384 [dbservice1] INFO 44809422-f9f7-11eb-9ffd-0242ac110004-vLPzKelQ-H:yjVplx2YI= token generate success token=MTYyODYxMjU5Ny4zODQ1MDUzOjQ0ODA5NDIyLWY5ZjctMTFlYi05ZmZkLTAyNDJhYzE
  00:23:19.958 [dbservice1] INFO 460a1f34-f9f7-11eb-83f6-0242ac110004-IlvgFiyE-c.4uo}8aEr6G token generate success token=MTYyODYxMjU5OS45NTgwNTg0OjQ2MGExZjM0LWY5ZjctMTFlYi04M2Y2LTAyNDJhYzE
  00:23:22.368 [dbservice1] INFO 477e1226-f9f7-11eb-800b-0242ac110003-dMOcrJWb-_!QcK%2x(ubj token generate success token=MTYyODYxMjYwMi4zNjgzMDk6NDc3ZTEyMjYtZjlmNy0xMWViLTgwMGItMDI0MmFjMTE
  00:23:24.903 [dbservice2] INFO 490168aa-f9f7-11eb-baac-0242ac110004-rYEevjPt-9g@Kz:0PJDTN token generate success token=MTYyODYxMjYwNC45MDMzODM1OjQ5MDE2OGFhLWY5ZjctMTFlYi1iYWFjLTAyNDJhYzE
  00:23:27.425 [dbservice2] INFO 4a75e60c-f9f7-11eb-9295-0242ac110004-HkLmPgZU-^/Kv(%ND.k0T token generate success token=MTYyODYxMjYwNy40MjUwNDE3OjRhNzVlNjBjLWY5ZjctMTFlYi05Mjk1LTAyNDJhYzE
  00:23:30.320 [mobservice2] INFO info 4c6f0c9a-f9f7-11eb-a18a-0242ac110004:HBUrWkyb write success

## p0160
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:48:14.112Z, and 1 identical event(s) in the same minute
```
{"timestamp":1731908894112856000,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"serving product page"}
```
Same service, the 2 minutes before (oldest first):
  05:48:11.955 [frontend] order placed
  05:48:11.975 [frontend] request complete  (×6)
  05:48:11.976 [frontend] request started  (×7)
  05:48:11.976 [frontend] serving product page  (×5)
  05:48:14.090 [frontend] view user cart
All services, 30 seconds either side (sampled):
  05:47:44.479 [frontend] request started  (×307)
  05:47:44.487 [cartservice] GetCartAsync called with userId=0727db9d-83b9-44b7-acab-68a4f8f289c0  (×247)
  05:47:44.510 [adservice] received ad request (context_words=[accessories])  (×37)
  05:47:45.418 [frontend] home  (×29)
  05:47:46.494 [frontend] adding to cart  (×40)
  05:47:46.499 [cartservice] info: Grpc.AspNetCore.Server.ServerCallHandler[7] Error status code 'FailedPrecondition' with detail 'Can't access cart storage. System.OverflowException: Value  (×40)
  05:47:47.127 [checkoutservice] [PlaceOrder] user_id="acc735c5-72d0-48e6-b237-46a63eac4c4d" user_currency="JPY"  (×4)
  05:47:47.140 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"1005","nanos":162317560},"credit_card":{"credit_card_number":"4962481487115  (×4)
  05:47:47.144 [shippingservice] [ShipOrder] received request  (×20)
  05:47:47.152 [emailservice] A request to send order confirmation email to rparsons@example.net has been received.
  05:47:47.654 [frontend] view user cart  (×34)
  05:47:48.484 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="CAD"  (×5)
  05:47:48.513 [emailservice] A request to send order confirmation email to ellenlee@example.net has been received.
  05:47:48.858 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"48","nanos":705044670},"credit_card":{"credit_card_number":"498780861780457  (×6)
  05:47:48.870 [checkoutservice] order confirmation email sent to "tkline@example.net"
  05:47:49.763 [frontend] setting currency  (×19)
  05:47:52.557 [paymentservice] Transaction processed: visa ending 3925 Amount: GBP6.836535161  (×2)
  05:47:52.572 [checkoutservice] order confirmation email sent to "christophersimmons@example.com"  (×2)
  05:47:56.375 [checkoutservice] order confirmation email sent to "lauramoss@example.net"
  05:48:06.976 [emailservice] A request to send order confirmation email to jonesstephanie@example.com has been received.
  05:48:11.942 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"8","nanos":990000000},"credit_card":{"credit_card_number":"4454364788431370  (×2)
  05:48:11.954 [checkoutservice] order confirmation email sent to "brendacurry@example.com"
  05:48:20.784 [paymentservice] Transaction processed: visa ending 2766 Amount: EUR7.952233525
  05:48:28.700 [emailservice] A request to send order confirmation email to melanie48@example.com has been received.
  05:48:32.632 [checkoutservice] order confirmation email sent to "fitzgeraldgregory@example.org"  (×2)
  05:48:35.779 [emailservice] A request to send order confirmation email to campbellmichael@example.org has been received.
  05:48:36.747 [checkoutservice] order confirmation email sent to "heathermitchell@example.com"
  05:48:39.858 [emailservice] A request to send order confirmation email to wardraymond@example.org has been received.
  05:48:43.881 [checkoutservice] order confirmation email sent to "anaellison@example.net"

## p0689
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-12T06:44:32.074Z
```
{"service":"mobservice1","message":"2021-08-12 06:44:32,074 | WARNING | 0.0.0.1 | 172.17.0.5 | mobservice1 | a27e0e3748d14b9d | wait for 11 seconds for follow-up operations to simulate the login failure of the QR code expired"}
```
Same service, the 2 minutes before (oldest first):
  06:44:25.370 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  06:44:25.371 [mobservice1] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'ad921dec-faf5-11eb-9c7e-0242ac110003'}  (×4)
  06:44:25.436 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'ad921dec-faf5-11eb-9c7e-0242ac110003', 'value': 'cCODHfIu'}  (×4)
  06:44:25.496 [mobservice1] INFO info ad921dec-faf5-11eb-9c7e-0242ac110003:cCODHfIu write success
  06:44:28.055 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  06:44:28.189 [mobservice1] INFO info af2cb46e-faf5-11eb-9c50-0242ac110003:hpcKRNdx write success
  06:44:29.704 [mobservice1] INFO info b01a7b86-faf5-11eb-ac48-0242ac110004:TIjYgWhS write success
  06:44:31.339 [mobservice1] INFO info b10f7cee-faf5-11eb-af3a-0242ac110003:MBoWvOAG write success
All services, 30 seconds either side (sampled):
  06:44:02.163 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  06:44:02.330 [logservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×42)
  06:44:02.458 [logservice2] INFO request http://0.0.0.2:9389/db_login_methods and param={'uuid': '9fb91086-faf5-11eb-9108-0242ac110003', 'user_id': 'CeJfdxpR'}  (×79)
  06:44:02.731 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'a03d7fb0-faf5-11eb-ad34-0242ac110003', 'value': '', 'ex': 10}  (×41)
  06:44:03.181 [logservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×38)
  06:44:03.424 [dbservice2] INFO a03d7fb0-faf5-11eb-ad34-0242ac110003-bGtJCiAM-5{+Aa/EZ2QN( token generate success token=MTYyODcyMTg0My40MjQyMDg2OmEwM2Q3ZmIwLWZhZjUtMTFlYi1hZDM0LTAyNDJhYzE
  06:44:03.703 [webservice2] INFO call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×38)
  06:44:06.511 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': 'a24f1de0-faf5-11eb-8837-0242ac110003', 'value': 'pKxfZBio'}  (×35)
  06:44:09.917 [dbservice1] INFO a405d4da-faf5-11eb-ae05-0242ac110003-zLGEjrhw-D*Rm7c>0WY.N token generate success token=MTYyODcyMTg0OS45MTcyNjY0OmE0MDVkNGRhLWZhZjUtMTFlYi1hZTA1LTAyNDJhYzE
  06:44:12.891 [dbservice2] INFO a5cff034-faf5-11eb-b23f-0242ac110004-VMivmOPL-_z$IfwVSs+#T token generate success token=MTYyODcyMTg1Mi44OTEwMzE1OmE1Y2ZmMDM0LWZhZjUtMTFlYi1iMjNmLTAyNDJhYzE
  06:44:15.604 [dbservice2] INFO a77b881c-faf5-11eb-983c-0242ac110003-UfMpdlBq-fL(<c!OYDx@^ token generate success token=MTYyODcyMTg1NS42MDM3NDE2OmE3N2I4ODFjLWZhZjUtMTFlYi05ODNjLTAyNDJhYzE
  06:44:18.267 [mobservice2] INFO info a944daf4-faf5-11eb-8679-0242ac110004:xcEhGPZd write success
  06:44:20.820 [mobservice2] INFO info aac99248-faf5-11eb-9202-0242ac110004:kXfZVAUx write success
  06:44:23.506 [dbservice2] ERROR password in database of {user} is null, the user is not registered
  06:44:25.920 [dbservice1] INFO ad921dec-faf5-11eb-9c7e-0242ac110003-cCODHfIu-x6(1%5_Mw>&: token generate success token=MTYyODcyMTg2NS45MTk5NzIyOmFkOTIxZGVjLWZhZjUtMTFlYi05YzdlLTAyNDJhYzE
  06:44:28.189 [mobservice1] INFO info af2cb46e-faf5-11eb-9c50-0242ac110003:hpcKRNdx write success
  06:44:31.339 [mobservice1] INFO info b10f7cee-faf5-11eb-af3a-0242ac110003:MBoWvOAG write success
  06:44:34.665 [mobservice1] INFO info b3041ffa-faf5-11eb-9e2f-0242ac110003:mwbCGSva write success
  06:44:38.037 [mobservice2] INFO info b510e3dc-faf5-11eb-973d-0242ac110004:DjXaKYNR write success
  06:44:41.281 [mobservice1] INFO info b6fea062-faf5-11eb-af19-0242ac110004:KmknXdcJ write success
  06:44:43.267 [redisservice2] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400
  06:44:46.159 [dbservice2] INFO b9a56288-faf5-11eb-964a-0242ac110003-mTjXOuZo-G/o^jX*g(<l9 token generate success token=MTYyODcyMTg4Ni4xNTkzOTM6YjlhNTYyODgtZmFmNS0xMWViLTk2NGEtMDI0MmFjMTE
  06:44:49.096 [mobservice2] INFO info bba3b2c4-faf5-11eb-8cb0-0242ac110003:CMzFsYZh write success
  06:44:51.625 [mobservice2] INFO info bd2aba48-faf5-11eb-a10e-0242ac110003:kWcbAndl write success
  06:44:54.547 [mobservice2] INFO info bed8ce66-faf5-11eb-81e5-0242ac110004:oneLisuW write success
  06:44:56.917 [mobservice2] INFO info c055e7d8-faf5-11eb-9b09-0242ac110004:DHpIOPcr write success
  06:44:59.745 [dbservice2] INFO c1ce60e0-faf5-11eb-87fe-0242ac110004-ALRXkDds-%t(^UlzPXqY& token generate success token=MTYyODcyMTg5OS43NDUzMzE6YzFjZTYwZTAtZmFmNS0xMWViLTg3ZmUtMDI0MmFjMTE

## p0112
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service currencyservice, 2024-11-18T05:13:08.891Z
```
{"timestamp":1731906788891657700,"container_name":"currencyservice","pod_name":"currencyservice-85dcb6b767-sd8v2","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"conversion request successful"}
```
Same service, the 2 minutes before (oldest first):
  05:13:07.277 [currencyservice] conversion request successful  (×14)
  05:13:07.656 [currencyservice] Getting supported currencies...  (×6)
All services, 30 seconds either side (sampled):
  05:12:38.899 [frontend] request started  (×326)
  05:12:38.901 [adservice] received ad request (context_words=[accessories])  (×39)
  05:12:38.903 [frontend] request complete  (×327)
  05:12:38.912 [currencyservice] conversion request successful  (×721)
  05:12:38.929 [adservice] received ad request (context_words=[footwear])  (×12)
  05:12:39.990 [adservice] received ad request (context_words=[hair, beauty])  (×17)
  05:12:40.333 [frontend] home  (×38)
  05:12:40.383 [adservice] received ad request (context_words=[])  (×38)
  05:12:40.625 [shippingservice] [GetQuote] received request  (×72)
  05:12:41.492 [frontend] adding to cart  (×39)
  05:12:41.500 [adservice] received ad request (context_words=[decor, home])  (×15)
  05:12:41.554 [frontend] placing order  (×9)
  05:12:41.574 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"58","nanos":345864663},"credit_card":{"credit_card_number":"414549902054232  (×3)
  05:12:41.577 [checkoutservice] payment went through (transaction_id: 7738ad07-f548-402a-99ac-99be3a8f907f)  (×9)
  05:12:41.578 [shippingservice] [ShipOrder] completed request  (×9)
  05:12:41.585 [emailservice] A request to send order confirmation email to btorres@example.net has been received.
  05:12:41.587 [frontend] order placed  (×9)
  05:12:44.450 [checkoutservice] [PlaceOrder] user_id="c216dec4-2181-4773-8cc5-aa587ee59fcc" user_currency="USD"  (×4)
  05:12:44.474 [paymentservice] Transaction processed: visa ending 0124 Amount: USD460.790000000  (×4)
  05:12:44.488 [checkoutservice] order confirmation email sent to "alexandria09@example.net"
  05:12:51.845 [emailservice] A request to send order confirmation email to bethany14@example.com has been received.
  05:12:52.211 [emailservice] A request to send order confirmation email to stephen33@example.net has been received.
  05:12:58.688 [emailservice] A request to send order confirmation email to rodriguezjason@example.com has been received.
  05:13:02.183 [emailservice] A request to send order confirmation email to wilsondeborah@example.com has been received.
  05:13:04.851 [emailservice] A request to send order confirmation email to mdavis@example.net has been received.
  05:13:09.769 [checkoutservice] [PlaceOrder] user_id="33421b66-55b6-413b-9ba9-3230c85c58dc" user_currency="JPY"  (×2)
  05:13:09.804 [paymentservice] Transaction processed: visa ending 7902 Amount: JPY24131.722247122  (×2)
  05:13:09.818 [checkoutservice] order confirmation email sent to "markmarks@example.net"
  05:13:20.110 [checkoutservice] order confirmation email sent to "jessicahamilton@example.net"

## p0330
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:21:09.189Z
```
{"timestamp":1732245669189039600,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"2024-11-22 03:21:09.188  INFO [carts,,,] 7 --- [           main] o.s.j.e.a.AnnotationMBeanExporter        : Located managed bean 'restartEndpoint': registering with JMX server as MBean [org.springframework.cloud.context.restart:name=restartEndpoint,type=RestartEndpoint]"}
```
Same service, the 2 minutes before (oldest first):
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env],methods=[POST]}" onto public java.lang.Object org.s
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/reset],methods=[POST]}" onto public java.util.Map<ja
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]
  03:21:03.088 [carts] 2024-11-22 03:21:03.088 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env || /env.json],methods=[GET],produces=[application/js
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[text/html]}" onto 
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/restart || /restart.json],methods=[POST]}" onto public j
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/pause || /pause.json],methods=[POST]}" onto public java.
  03:21:03.090 [carts] 2024-11-22 03:21:03.090 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[
  03:21:03.184 [carts] 2024-11-22 03:21:03.183 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/configprops || /configprops.json],methods=[GET],produces
  03:21:03.285 [carts] 2024-11-22 03:21:03.285 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/info || /info.json],methods=[GET],produces=[application/
  03:21:06.490 [carts] 2024-11-22 03:21:06.489 INFO [carts,,,] 7 --- [ main] o.s.s.c.ThreadPoolTaskScheduler : Initializing ExecutorService 
  03:21:08.790 [carts] 2024-11-22 03:21:08.790 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Registering beans for JMX exposure on startup
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'configurationPropertiesRebinder' has been autodetected
  03:21:08.985 [carts] 2024-11-22 03:21:08.985 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposur  (×2)
  03:21:08.986 [carts] 2024-11-22 03:21:08.986 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  03:21:08.987 [carts] 2024-11-22 03:21:08.987 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  03:21:08.990 [carts] 2024-11-22 03:21:08.990 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX server
All services, 30 seconds either side (sampled):
  03:20:39.224 [catalogue] ts=2024-11-22T03:20:39Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.944796ms  (×60)
  03:20:39.801 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×9)
  03:20:40.193 [front-end] Sent cookies.  (×59)
  03:20:41.191 [user] ts=2024-11-22T03:20:41.191529187Z caller=middlewares.go:134 method=GetCards id=673ff881b0df5c00019b1f08 result=1 took=952.324µs  (×41)
  03:20:42.704 [user] ts=2024-11-22T03:20:42.704694233Z caller=middlewares.go:75 method=GetUsers id=673ff871b0df5c00019b1eda result=1 took=675.443µs  (×156)
  03:20:43.391 [carts] 2024-11-22 03:20:43.390 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.spring
  03:20:49.001 [user] ts=2024-11-22T03:20:49.001760928Z caller=middlewares.go:46 method=Register username=asYAoymkBkzj email=asYAoymkBkzj@gmail.com took=935.752µs  (×5)
  03:20:51.970 [front-end] Posting Customer: {"username":"nPklGOsvzh","password":"YuEpn","email":"nPklGOsvzh@gmail.com","firstName":"nPklGOsvzh","lastName":"nPklGOsvzh"}
  03:20:56.307 [front-end] Posting Customer: {"username":"TxflHMpaWteY","password":"HuykDEusv","email":"TxflHMpaWteY@gmail.com","firstName":"TxflHMpaWteY","lastName":"TxflHMpaWteY"}
  03:20:59.685 [carts] 2024-11-22 03:20:59.685 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],methods=[OPTIONS],produces=[application/hal+json
  03:20:59.785 [carts] 2024-11-22 03:20:59.785 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[GET],produces=[  (×2)
  03:20:59.886 [carts] 2024-11-22 03:20:59.886 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/profile],methods=[GET]}" onto org.springframework.http.
  03:21:02.990 [carts] 2024-11-22 03:21:02.990 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/beans || /beans.json],methods=[GET],produces=[applicatio
  03:21:03.089 [carts] 2024-11-22 03:21:03.089 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/actuator || /actuator.json],produces=[application/json]}
  03:21:04.667 [user] ts=2024-11-22T03:21:04.666811852Z caller=middlewares.go:46 method=Register username=vpxxpRNxF email=vpxxpRNxF@gmail.com took=1.013941ms
  03:21:08.990 [carts] 2024-11-22 03:21:08.990 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX server
  03:21:11.685 [carts] 2024-11-22 03:21:11.685 INFO [carts,,,] 7 --- [ main] o.s.c.support.DefaultLifecycleProcessor : Starting beans in phase 0
  03:21:14.093 [front-end] Posting Customer: {"username":"GaVMS","password":"VbNEvaWqm","email":"GaVMS@gmail.com","firstName":"GaVMS","lastName":"GaVMS"}
  03:21:16.231 [front-end] Posting Customer: {"username":"jStfWCKVIxuZsZx","password":"iRGdzUAo","email":"jStfWCKVIxuZsZx@gmail.com","firstName":"jStfWCKVIxuZsZx","lastName":"jStfWCKVIxuZ
  03:21:18.600 [payment] ts=2024-11-22T03:21:18Z caller=logging.go:29 method=Authorise result=true took=1.111µs  (×10)
  03:21:18.619 [front-end] Order response: {"id":"673ff8aed94b9000069b438c","customerId":"673ff89cb0df5c00019b1f51","customer":{"id":null,"firstName":"bDjuXlWHATfWj","lastName":"bDjuXlWHA
  03:21:19.317 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8afd94b9000069b4391","customerId":"673ff896b0df5c00019b1f3c","customer":{"id":null,"firstName":"cfTPDbfduek
  03:21:19.922 [front-end] Received response: "{\"firstName\":\"pNgaEfQnfRl\",\"lastName\":\"pNgaEfQnfRl\",\"username\":\"pNgaEfQnfRl\",\"id\":\"673ff899b0df5c00019b1f45\",\"_links\":{\"a
  03:21:20.784 [carts] 2024-11-22 03:21:20.784 INFO [carts,72b808adb3c8c537,be68402c14e1faf0,false] 7 --- [-nio-80-exec-13] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×8)
  03:21:23.289 [user] ts=2024-11-22T03:21:23.288846104Z caller=middlewares.go:46 method=Register username=BHMHa email=BHMHa@gmail.com took=1.099634ms
  03:21:28.386 [orders-db] {"t":{"$date":"2024-11-22T03:21:28.386+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224568
  03:21:32.503 [front-end] Order response: {"id":"673ff8bcd94b9000069b439e","customerId":"673ff8a0b0df5c00019b1f63","customer":{"id":null,"firstName":"vpxxpRNxF","lastName":"vpxxpRNxF","u
  03:21:34.712 [front-end] Received response: "{\"firstName\":\"eSafJJOuc\",\"lastName\":\"eSafJJOuc\",\"username\":\"eSafJJOuc\",\"id\":\"673ff8abb0df5c00019b1f8e\",\"_links\":{\"address
  03:21:36.307 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8c0d94b9000069b43a3","customerId":"673ff8a2b0df5c00019b1f6d","customer":{"id":null,"firstName":"IhtqcyEyd",

## p0734
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service checkoutservice, 2024-11-22T12:23:09.038Z
```
{"service":"checkoutservice","operation":"hipstershop.CheckoutService/PlaceOrder","method":"PlaceOrder","status_code":13,"duration_us":33794,"trace_id":"6c1a5489386d4360f0d347e428dcfed7","message":"span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13"}
```
Same service, the 2 minutes before (oldest first):
  12:22:48.878 [checkoutservice] order confirmation email sent to "snydershannon@example.com"
  12:22:49.548 [checkoutservice] [PlaceOrder] user_id="b1978cca-deb1-4a57-89d8-dda1e4c67888" user_currency="CAD"  (×3)
  12:22:49.597 [checkoutservice] payment went through (transaction_id: 767b8471-660d-40f7-84af-b0d2944a1151)  (×6)
  12:22:49.609 [checkoutservice] order confirmation email sent to "hannah68@example.com"
  12:22:57.727 [checkoutservice] [PlaceOrder] user_id="07008eda-9426-4259-a693-c0275e226c75" user_currency="JPY"
  12:22:57.822 [checkoutservice] order confirmation email sent to "aanderson@example.org"
  12:23:00.130 [checkoutservice] order confirmation email sent to "jennifermayer@example.org"
  12:23:03.043 [checkoutservice] [PlaceOrder] user_id="8840e449-c562-4c1b-a872-f1dda11ad3bc" user_currency="GBP"  (×2)
  12:23:03.119 [checkoutservice] order confirmation email sent to "lisa64@example.net"
  12:23:04.509 [checkoutservice] order confirmation email sent to "floressteven@example.com"
  12:23:06.238 [checkoutservice] order confirmation email sent to "vrussell@example.com"
  12:23:09.038 [checkoutservice] [PlaceOrder] user_id="d01583c7-1498-45eb-a9a8-e4d2cc36d456" user_currency="TRY"
All services, 30 seconds either side (sampled):
  12:22:39.445 [frontend] request started  (×352)
  12:22:39.449 [frontend] home  (×42)
  12:22:39.464 [currencyservice] conversion request successful  (×804)
  12:22:39.742 [frontend] serving product page  (×147)
  12:22:40.491 [adservice] received ad request (context_words=[accessories])  (×41)
  12:22:40.509 [frontend] view user cart  (×76)
  12:22:40.539 [shippingservice] [GetQuote] completed request  (×90)
  12:22:44.844 [adservice] received ad request (context_words=[decor, home])  (×14)
  12:22:48.106 [checkoutservice] [PlaceOrder] user_id="4685a666-2807-489a-bc47-9c225a054c9e" user_currency="TRY"  (×3)
  12:22:48.140 [checkoutservice] payment went through (transaction_id: e5517cc2-2faf-488c-a1fe-709e9c4ccf59)  (×13)
  12:22:48.149 [cartservice] EmptyCartAsync called with userId=4685a666-2807-489a-bc47-9c225a054c9e  (×13)
  12:22:48.159 [frontend] order placed  (×13)
  12:22:48.864 [paymentservice] Transaction processed: visa ending 6582 Amount: JPY11621.420610630  (×3)
  12:22:49.494 [recommendationservice] [Recv ListRecommendations] product_ids=['0PUK6V6EV0', '6E92ZMYYFZ', '66VCHSJNUP', 'OLJCESPC7Z']  (×5)
  12:22:49.594 [paymentservice] Transaction processed: visa ending 6505 Amount: CAD2635.831529409  (×5)
  12:22:57.821 [emailservice] A request to send order confirmation email to aanderson@example.org has been received.
  12:23:00.130 [checkoutservice] order confirmation email sent to "jennifermayer@example.org"
  12:23:03.104 [paymentservice] Transaction processed: visa ending 1957 Amount: GBP67.642914637  (×2)
  12:23:04.507 [emailservice] A request to send order confirmation email to floressteven@example.com has been received.
  12:23:06.238 [checkoutservice] order confirmation email sent to "vrussell@example.com"
  12:23:09.068 [paymentservice] span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400
  12:23:09.073 [frontend] request error
  12:23:20.666 [emailservice] A request to send order confirmation email to imcdaniel@example.com has been received.
  12:23:24.631 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"78","nanos":681999117},"credit_card":{"credit_card_number":"405989720820570
  12:23:24.644 [checkoutservice] order confirmation email sent to "elizabeth72@example.com"
  12:23:38.654 [emailservice] A request to send order confirmation email to debbie49@example.org has been received.

## p0400
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T03:46:29.429Z
```
{"timestamp":1732247189429045800,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Order: {\"customer\":\"http://user/customers/673ffe7db0df5c00019b314a\",\"address\":\"http://user/addresses/673ffe83b0df5c00019b3160\",\"card\":\"http://user/cards/673ffe83b0df5c00019b3161\",\"items\":\"http://carts/carts/673ffe7db0df5c00019b314a/items\"}"}
```
Same service, the 2 minutes before (oldest first):
  03:46:28.951 [front-end] POST /orders 500 - ms - -  (×2)
  03:46:29.284 [front-end] GET /catalogue 200 - ms - -
  03:46:29.345 [front-end] Request received with body: {}  (×2)
  03:46:29.352 [front-end] Received response: "{\"firstName\":\"pJzRppEBFhEk\",\"lastName\":\"pJzRppEBFhEk\",\"username\":\"pJzRppEBFhEk\",\"id\":\"673ffe7db0df5c00019b3151\",\"_links\":{
  03:46:29.352 [front-end] GET Request to: http://user/customers/673ffe7db0df5c00019b3151/addresses  (×4)
  03:46:29.358 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673ff  (×2)
  03:46:29.358 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffe88b0df5c00019b316f\",\"_links\":{\"  (×2)
  03:46:29.358 [front-end] [ undefined, undefined ]  (×2)
  03:46:29.358 [front-end] Posting Order: {"customer":"http://user/customers/673ffe7db0df5c00019b3151","address":"http://user/addresses/673ffe88b0df5c00019b316e","card":"http://user/cards
  03:46:29.417 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732247189415,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  03:46:29.417 [front-end] Order response: {"timestamp":1732247189415,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
All services, 30 seconds either side (sampled):
  03:46:09.093 [user] ts=2024-11-22T03:46:09.093317089Z caller=middlewares.go:157 method=Health result=2 took=895.523µs  (×27)
  03:46:10.147 [front-end] Merging carts for customer id: 673ffe82b0df5c00019b315b and session id: BfWIMoLVmqk0r6MgLbHR8UqFhdN3fR0_  (×48)
  03:46:10.807 [user] ts=2024-11-22T03:46:10.807338711Z caller=middlewares.go:75 method=GetUsers id=673ffe72b0df5c00019b3133 result=1 took=1.041719ms  (×60)
  03:46:10.818 [front-end] Posting Order: {"customer":"http://user/customers/673ffe72b0df5c00019b3133","address":"http://user/addresses/673ffe78b0df5c00019b3140","card":"http://user/cards  (×47)
  03:46:10.852 [front-end] Order response: {"timestamp":1732247170849,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat  (×48)
  03:46:11.155 [front-end] POST /addresses 200 - ms - -  (×48)
  03:46:11.295 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}  (×48)
  03:46:11.402 [front-end] POST /cart 500 94.381 ms - 64  (×47)
  03:46:12.530 [user] ts=2024-11-22T03:46:12.530413445Z caller=middlewares.go:46 method=Register username=YWRstkOr email=YWRstkOr@gmail.com took=1.030146ms
  03:46:14.496 [front-end] Posting Customer: {"username":"cnldH","password":"gEOrucHcq","email":"cnldH@gmail.com","firstName":"cnldH","lastName":"cnldH"}
  03:46:15.102 [user] ts=2024-11-22T03:46:15.101952378Z caller=middlewares.go:46 method=Register username=sgJiwtPKZ email=sgJiwtPKZ@gmail.com took=871.966µs
  03:46:16.942 [front-end] Posting Customer: {"username":"ANUgD","password":"rpKdb","email":"ANUgD@gmail.com","firstName":"ANUgD","lastName":"ANUgD"}
  03:46:19.841 [front-end] Received response: "{\"firstName\":\"TQGCLmsnLWDzp\",\"lastName\":\"TQGCLmsnLWDzp\",\"username\":\"TQGCLmsnLWDzp\",\"id\":\"673ffe74b0df5c00019b3138\",\"_links\
  03:46:23.688 [front-end] Received response: "{\"firstName\":\"umsOpcncwKWNJe\",\"lastName\":\"umsOpcncwKWNJe\",\"username\":\"umsOpcncwKWNJe\",\"id\":\"673ffe74b0df5c00019b3137\",\"_lin
  03:46:26.403 [front-end] Posting Customer: {"username":"nszyXJzeoHo","password":"iAZLRNiVzx","email":"nszyXJzeoHo@gmail.com","firstName":"nszyXJzeoHo","lastName":"nszyXJzeoHo"}
  03:46:28.497 [front-end] Posting Customer: {"username":"WrRpd","password":"DXDWNgF","email":"WrRpd@gmail.com","firstName":"WrRpd","lastName":"WrRpd"}
  03:46:29.422 [front-end] Received response: "{\"firstName\":\"hZAavbryVbxDF\",\"lastName\":\"hZAavbryVbxDF\",\"username\":\"hZAavbryVbxDF\",\"id\":\"673ffe7db0df5c00019b314a\",\"_links\
  03:46:30.568 [front-end] Received response: "{\"firstName\":\"ptkQMzQKHy\",\"lastName\":\"ptkQMzQKHy\",\"username\":\"ptkQMzQKHy\",\"id\":\"673ffe89b0df5c00019b3175\",\"_links\":{\"addr
  03:46:33.533 [front-end] Received response: "{\"firstName\":\"GIUFZZyI\",\"lastName\":\"GIUFZZyI\",\"username\":\"GIUFZZyI\",\"id\":\"673ffe87b0df5c00019b316c\",\"_links\":{\"addresses\
  03:46:37.512 [front-end] Posting Customer: {"username":"gMfIXaRTde","password":"cPMPIT","email":"gMfIXaRTde@gmail.com","firstName":"gMfIXaRTde","lastName":"gMfIXaRTde"}
  03:46:40.449 [front-end] Received response: "{\"firstName\":\"sgJiwtPKZ\",\"lastName\":\"sgJiwtPKZ\",\"username\":\"sgJiwtPKZ\",\"id\":\"673ffe87b0df5c00019b316b\",\"_links\":{\"address
  03:46:43.231 [front-end] Received response: "{\"firstName\":\"ANUgD\",\"lastName\":\"ANUgD\",\"username\":\"ANUgD\",\"id\":\"673ffe88b0df5c00019b3174\",\"_links\":{\"addresses\":{\"href
  03:46:50.170 [front-end] Posting Customer: {"username":"hXxXTfcxL","password":"KJTcctDGf","email":"hXxXTfcxL@gmail.com","firstName":"hXxXTfcxL","lastName":"hXxXTfcxL"}
  03:46:51.089 [carts] 2024-11-22 03:46:51.089 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  03:46:51.186 [carts] 2024-11-22 03:46:51.185 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  03:46:52.605 [user] ts=2024-11-22T03:46:52.605146948Z caller=middlewares.go:46 method=Register username=KouXEnVz email=KouXEnVz@gmail.com took=930.937µs
  03:46:54.684 [carts] 2024-11-22 03:46:54.684 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  03:46:56.230 [front-end] Received response: "{\"firstName\":\"gOQlBf\",\"lastName\":\"gOQlBf\",\"username\":\"gOQlBf\",\"id\":\"673ffe9cb0df5c00019b31af\",\"_links\":{\"addresses\":{\"h
  03:46:57.285 [carts] 2024-11-22 03:46:57.285 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr
  03:46:57.791 [user] ts=2024-11-22T03:46:57.791031339Z caller=middlewares.go:46 method=Register username=kHKtAIS email=kHKtAIS@gmail.com took=1.166895ms

## p0018
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T06:36:56.503Z
```
{"service":"dbservice1","message":"2021-08-13 06:36:56,503 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 3777afb38914a5cf | cc30c0c8-fbbd-11eb-a6c3-0242ac110003-pVIaJPSL-/6iJQ_4ro#jO token generate success token=MTYyODgwNzgxNi41MDM1MTkzOmNjMzBjMGM4LWZiYmQtMTFlYi1hNmMzLTAyNDJhYzExMDAwM3BWSWFKUFNMLzZpSlFfNHJvI2pPOjE2Mjg4MDc4NzYuNTAzNTM6OTExNDY2OWM0ODU3YzgwOTlhZWIwMDNiNDIxNjYyZWM="}
```
Same service, the 2 minutes before (oldest first):
  06:36:50.336 [dbservice1] INFO c8816054-fbbd-11eb-b9ae-0242ac110003-mgvTPLKy-UE!Q+o#:Kz9% token generate success token=MTYyODgwNzgxMC4zMzY1NzI2OmM4ODE2MDU0LWZiYmQtMTFlYi1iOWFlLTAyNDJhYzE
  06:36:50.681 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  06:36:50.681 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  06:36:50.741 [dbservice1] INFO query = select passwards from username_table where user_name='rtRkpsfM'  (×5)
  06:36:50.818 [dbservice1] INFO c8c82534-fbbd-11eb-8f4a-0242ac110004-rtRkpsfM-ul#Hy_*g:KTb token generate success token=MTYyODgwNzgxMC44MTc2NzpjOGM4MjUzNC1mYmJkLTExZWItOGY0YS0wMjQyYWMxMTA
  06:36:52.428 [dbservice1] INFO c9be8960-fbbd-11eb-91f9-0242ac110003-ulnvrqij-9:#.kKu^Q_1% token generate success token=MTYyODgwNzgxMi40Mjg1OTMyOmM5YmU4OTYwLWZiYmQtMTFlYi05MWY5LTAyNDJhYzE
  06:36:54.876 [dbservice1] INFO cb3e3dbc-fbbd-11eb-a0a5-0242ac110004-NdFpoUqE-1-FDZOflo.4X token generate success token=MTYyODgwNzgxNC44NzYyMTQ6Y2IzZTNkYmMtZmJiZC0xMWViLWEwYTUtMDI0MmFjMTE
  06:36:55.696 [dbservice1] INFO cbb4d652-fbbd-11eb-8fc1-0242ac110003-HxQpIWMr-prs7#j4K0Dz1 token generate success token=MTYyODgwNzgxNS42OTYxNTpjYmI0ZDY1Mi1mYmJkLTExZWItOGZjMS0wMjQyYWMxMTA
All services, 30 seconds either side (sampled):
  06:36:26.574 [webservice1] INFO complete information: {'uuid': 'baaa0030-fbbd-11eb-86a9-0242ac110003', 'user_id': 'IAuXacwS'}  (×44)
  06:36:26.757 [redisservice2] INFO redis write success  (×71)
  06:36:26.920 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': 'baaa0030-fbbd-11eb-86a9-0242ac110003', 'user_id': 'IAuXacwS'}  (×82)
  06:36:27.112 [dbservice2] INFO baaa0030-fbbd-11eb-86a9-0242ac110003-IAuXacwS-7@_}S6lBDAxp token generate success token=MTYyODgwNzc4Ny4xMTE4ODE6YmFhYTAwMzAtZmJiZC0xMWViLTg2YTktMDI0MmFjMTE
  06:36:29.849 [redisservice1] INFO service accept, status_code: 200  (×47)
  06:36:31.610 [webservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  06:36:32.420 [mobservice1] INFO info be085448-fbbd-11eb-8355-0242ac110004:IpBPDOnW write success
  06:36:32.907 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  06:36:33.626 [mobservice1] INFO info bec20bea-fbbd-11eb-ac06-0242ac110004:GxrcRlDj write success
  06:36:35.771 [webservice1] ERROR an error occurred in the downstream service  (×2)
  06:36:38.540 [mobservice1] INFO info c1a6d5ac-fbbd-11eb-8f47-0242ac110004:JZinoGDa write success
  06:36:40.891 [mobservice1] INFO info c3132fa8-fbbd-11eb-8f78-0242ac110004:HnGradOx write success
  06:36:43.464 [mobservice1] INFO info c4933508-fbbd-11eb-a0c2-0242ac110003:bykmrCDS write success
  06:36:46.582 [dbservice1] INFO c637c32e-fbbd-11eb-85fc-0242ac110003-VnGSpqai-jIe*x?+nDlz> token generate success token=MTYyODgwNzgwNi41ODE2NDA3OmM2MzdjMzJlLWZiYmQtMTFlYi04NWZjLTAyNDJhYzE
  06:36:49.253 [dbservice1] INFO c7d59184-fbbd-11eb-8957-0242ac110003-HygISCUR-nDh8._Bb7*Ce token generate success token=MTYyODgwNzgwOS4yNTI5ODE6YzdkNTkxODQtZmJiZC0xMWViLTg5NTctMDI0MmFjMTE
  06:36:51.605 [dbservice2] INFO c94775b4-fbbd-11eb-a208-0242ac110003-AkaZFCps-BVsW974Lbmjc token generate success token=MTYyODgwNzgxMS42MDU0Njk1OmM5NDc3NWI0LWZiYmQtMTFlYi1hMjA4LTAyNDJhYzE  (×2)
  06:36:54.548 [mobservice1] INFO info cb3e3dbc-fbbd-11eb-a0a5-0242ac110004:NdFpoUqE write success
  06:36:57.373 [dbservice1] INFO ccaaa00a-fbbd-11eb-9430-0242ac110004-lTYxuZoK-3UtL7AG$HnN5 token generate success token=MTYyODgwNzgxNy4zNzMzNjU5OmNjYWFhMDBhLWZiYmQtMTFlYi05NDMwLTAyNDJhYzE
  06:36:59.866 [dbservice2] INFO ce365054-fbbd-11eb-9e7b-0242ac110003-OiYedVug-CgNB*r/q!wic token generate success token=MTYyODgwNzgxOS44NjYyODM6Y2UzNjUwNTQtZmJiZC0xMWViLTllN2ItMDI0MmFjMTE
  06:37:02.978 [mobservice1] INFO info d041d2e2-fbbd-11eb-8f89-0242ac110004:Bmsjcfbe write success
  06:37:05.427 [mobservice2] INFO info d1b58ba0-fbbd-11eb-84fe-0242ac110004:kicMwWKP write success
  06:37:07.861 [mobservice2] INFO info d32a5222-fbbd-11eb-9b25-0242ac110004:QghyctJY write success
  06:37:10.339 [mobservice2] INFO info d49ded80-fbbd-11eb-9e78-0242ac110004:TMBcRIPk write success
  06:37:13.078 [dbservice2] INFO d605a640-fbbd-11eb-8886-0242ac110003-dlznWOTR-j<7FGs8(h_fA token generate success token=MTYyODgwNzgzMy4wNzc5OTc3OmQ2MDVhNjQwLWZiYmQtMTFlYi04ODg2LTAyNDJhYzE
  06:37:15.926 [dbservice2] INFO d7affc70-fbbd-11eb-8c53-0242ac110003-EfYjQxDP-^#<7YEpfJHm/ token generate success token=MTYyODgwNzgzNS45MjYyNzI2OmQ3YWZmYzcwLWZiYmQtMTFlYi04YzUzLTAyNDJhYzE
  06:37:18.515 [mobservice2] INFO info d98051ee-fbbd-11eb-a274-0242ac110003:mVtTqAor write success
  06:37:21.425 [mobservice1] INFO info db39a828-fbbd-11eb-835f-0242ac110004:rGxaBlKJ write success

## p0017
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice1, 2021-08-13T06:34:13.544Z
```
{"service":"mobservice1","message":"2021-08-13 06:34:13,544 | INFO | 0.0.0.1 | 172.17.0.5 | mobservice1 | 1bf6b5a0273322a9 | request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '6b4ae0e0-fbbd-11eb-9759-0242ac110003', 'value': 'rGxaBlKJ'}"}
```
Same service, the 2 minutes before (oldest first):
  06:34:03.165 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '651bf920-fbbd-11eb-be7f-0242ac110004', 'value': 'mwbCGSva'}  (×4)
  06:34:03.233 [mobservice1] INFO info 651bf920-fbbd-11eb-be7f-0242ac110004:mwbCGSva write success
  06:34:08.434 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  06:34:08.435 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  06:34:08.435 [mobservice1] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '684a5d30-fbbd-11eb-ad64-0242ac110003'}  (×4)
  06:34:08.578 [mobservice1] INFO info 684a5d30-fbbd-11eb-ad64-0242ac110003:afgSwRro write success
  06:34:10.324 [mobservice1] INFO info 69512ede-fbbd-11eb-bda8-0242ac110004:npqwesLI write success
  06:34:11.198 [mobservice1] INFO info 69e27c4a-fbbd-11eb-a711-0242ac110003:VizMUmJR write success
All services, 30 seconds either side (sampled):
  06:33:43.594 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×45)
  06:33:43.769 [webservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '59b92e40-fbbd-11eb-83f0-0242ac110003', 'value': '', 'ex': 10}  (×41)
  06:33:44.008 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×40)
  06:33:44.125 [redisservice1] INFO redis write success  (×81)
  06:33:44.280 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×46)
  06:33:44.359 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×46)
  06:33:44.551 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×35)
  06:33:44.709 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×34)
  06:33:45.798 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '5abe61e8-fbbd-11eb-9ce6-0242ac110003', 'value': 'TMBcRIPk'}  (×40)
  06:33:47.351 [mobservice2] INFO info 5ba1ba2e-fbbd-11eb-9ea8-0242ac110004:DkpCcNIV write success
  06:33:49.665 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c  (×2)
  06:33:51.537 [dbservice1] INFO 5dea7046-fbbd-11eb-acbf-0242ac110004-CyQWkovZ-&-Rhe1{6)8Gf token generate success token=MTYyODgwNzYzMS41MzY5MjkxOjVkZWE3MDQ2LWZiYmQtMTFlYi1hY2JmLTAyNDJhYzE
  06:33:53.722 [mobservice2] INFO info 5f6b9544-fbbd-11eb-8b6a-0242ac110004:dzLawjCD write success
  06:33:56.288 [mobservice2] INFO info 60faf666-fbbd-11eb-9f13-0242ac110003:JazlhZoG write success
  06:33:58.827 [mobservice2] INFO info 627acf70-fbbd-11eb-a7cc-0242ac110004:NhtsWobx write success
  06:34:00.932 [dbservice1] INFO 637bee68-fbbd-11eb-be5c-0242ac110003-TIlYNQVq-j_xRrUNP7T31 token generate success token=MTYyODgwNzY0MC45MzI1NTM6NjM3YmVlNjgtZmJiZC0xMWViLWJlNWMtMDI0MmFjMTE  (×4)
  06:34:03.233 [mobservice1] INFO info 651bf920-fbbd-11eb-be7f-0242ac110004:mwbCGSva write success
  06:34:06.154 [dbservice2] INFO 669fb908-fbbd-11eb-aa74-0242ac110003-dneSsIED-8P7mNRZk<p&e token generate success token=MTYyODgwNzY0Ni4xNTQzNzk4OjY2OWZiOTA4LWZiYmQtMTFlYi1hYTc0LTAyNDJhYzE
  06:34:08.578 [mobservice1] INFO info 684a5d30-fbbd-11eb-ad64-0242ac110003:afgSwRro write success
  06:34:10.879 [dbservice2] INFO 696f533c-fbbd-11eb-bcb3-0242ac110003-saHAJjFe-$p8NUBRnq{X< token generate success token=MTYyODgwNzY1MC44Nzg3OTg6Njk2ZjUzM2MtZmJiZC0xMWViLWJjYjMtMDI0MmFjMTE
  06:34:13.670 [dbservice1] INFO 6b20f672-fbbd-11eb-8848-0242ac110004-GrAcpCvX-wI^E_!dvb}L* token generate success token=MTYyODgwNzY1My42NzAwMDY1OjZiMjBmNjcyLWZiYmQtMTFlYi04ODQ4LTAyNDJhYzE
  06:34:16.582 [dbservice1] INFO 6cca83a8-fbbd-11eb-ab51-0242ac110004-WRbeulvc-0f:Vh7l3E#r% token generate success token=MTYyODgwNzY1Ni41ODIwMjE3OjZjY2E4M2E4LWZiYmQtMTFlYi1hYjUxLTAyNDJhYzE
  06:34:18.909 [mobservice2] INFO info 6e6e5e96-fbbd-11eb-8842-0242ac110004:ropVRsqh write success
  06:34:22.032 [dbservice2] INFO 700a9bca-fbbd-11eb-831c-0242ac110003-goQRiNCP-)zFr<CeO}*{g token generate success token=MTYyODgwNzY2Mi4wMzIwMDc3OjcwMGE5YmNhLWZiYmQtMTFlYi04MzFjLTAyNDJhYzE
  06:34:28.276 [dbservice2] INFO 73ca1fec-fbbd-11eb-aed8-0242ac110003-evnbrmSs-gom=Yi$#jkD3 token generate success token=MTYyODgwNzY2OC4yNzU4Mjc2OjczY2ExZmVjLWZiYmQtMTFlYi1hZWQ4LTAyNDJhYzE
  06:34:33.458 [dbservice1] INFO 76e1768a-fbbd-11eb-938a-0242ac110004-tvuRByVz-Z!wxLpc+3i7b token generate success token=MTYyODgwNzY3My40NTc4NTc0Ojc2ZTE3NjhhLWZiYmQtMTFlYi05MzhhLTAyNDJhYzE
  06:34:35.896 [mobservice1] INFO info 78909eb6-fbbd-11eb-9a06-0242ac110003:rJHuqoXG write success
  06:34:38.205 [dbservice2] INFO 79a4dda8-fbbd-11eb-85ce-0242ac110004-mFYdOIbz-A}O9cl-$UaIV token generate success token=MTYyODgwNzY3OC4yMDUwNTY0Ojc5YTRkZGE4LWZiYmQtMTFlYi04NWNlLTAyNDJhYzE
  06:34:40.563 [mobservice2] INFO info 7b56ce2c-fbbd-11eb-89d2-0242ac110004:IFyHcfZd write success
  06:34:42.902 [mobservice1] INFO info 7cb3e840-fbbd-11eb-9fcc-0242ac110003:iBnyvbLP write success

## p0244
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:03.519Z
```
{"timestamp":1732242483519979300,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Posting Customer: {\"username\":\"sgQXbZQ\",\"password\":\"MIojoNS\",\"email\":\"sgQXbZQ@gmail.com\",\"firstName\":\"sgQXbZQ\",\"lastName\":\"sgQXbZQ\"}"}
```
Same service, the 2 minutes before (oldest first):
  02:28:03.203 [front-end] Posting Order: {"customer":"http://user/customers/673fec21b0df5c00019af922","address":"http://user/addresses/673fec28b0df5c00019af93a","card":"http://user/cards
  02:28:03.236 [front-end] Attempting to delete cart for user: 673fec2bb0df5c00019af944
  02:28:03.248 [front-end] POST /cart 500 63.892 ms - 64  (×2)
  02:28:03.249 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:03.249 [front-end] Order response: {"timestamp":1732242483245,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:03.252 [front-end] POST /orders 500 - ms - -
  02:28:03.265 [front-end] User cart deleted with status: 503
  02:28:03.268 [front-end] DELETE /cart 503 - ms - -
  02:28:03.274 [front-end] Attempting to add to cart: {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","quantity":1}
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata
  02:28:03.281 [front-end] POST to carts: http://carts/carts/673fec2bb0df5c00019af944/items body: {"itemId":"d3588630-ad8e-49df-bbd7-3167f7efb246","unitPrice":10.99}
  02:28:03.387 [front-end] Posting Customer: {"username":"kMzzAppFcYY","password":"BdsJf","email":"kMzzAppFcYY@gmail.com","firstName":"kMzzAppFcYY","lastName":"kMzzAppFcYY"}
  02:28:03.392 [front-end] { id: '673fec33b0df5c00019af962' }
  02:28:03.392 [front-end] 673fec33b0df5c00019af962
  02:28:03.392 [front-end] Merging carts for customer id: 673fec33b0df5c00019af962 and session id: D-ltML2PKwiyNToE8YIFfZBS5CSXH2nW
  02:28:03.410 [front-end] Carts merged.
  02:28:03.410 [front-end] set cookie673fec33b0df5c00019af962
  02:28:03.411 [front-end] Sent cookies.
  02:28:03.413 [front-end] POST /register 200 24.797 ms - 33
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×30)
  02:28:03.118 [catalogue] ts=2024-11-22T02:28:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.040202ms  (×32)
  02:28:03.190 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af953/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×16)
  02:28:03.211 [user] ts=2024-11-22T02:28:03.211690554Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=1.207621ms  (×36)
  02:28:03.252 [front-end] POST /orders 500 - ms - -  (×30)
  02:28:03.410 [front-end] Carts merged.  (×30)
  02:28:04.933 [user] ts=2024-11-22T02:28:04.933089482Z caller=middlewares.go:46 method=Register username=JGQXvUjPbFrtK email=JGQXvUjPbFrtK@gmail.com took=1.129271ms  (×10)
  02:28:05.175 [front-end] Posting Customer: {"username":"vvgsHcY","password":"qfZoo","email":"vvgsHcY@gmail.com","firstName":"vvgsHcY","lastName":"vvgsHcY"}
  02:28:07.408 [front-end] Received response: "{\"firstName\":\"iTdzWTHcUAJJ\",\"lastName\":\"iTdzWTHcUAJJ\",\"username\":\"iTdzWTHcUAJJ\",\"id\":\"673fec22b0df5c00019af923\",\"_links\":{
  02:28:09.014 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×4)
  02:28:10.451 [carts] 2024-11-22 02:28:10.451 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  02:28:11.653 [user] ts=2024-11-22T02:28:11.653746097Z caller=middlewares.go:75 method=GetUsers id=673fec2ab0df5c00019af942 result=1 took=692µs
  02:28:14.311 [front-end] Posting Customer: {"username":"AIwPgMB","password":"ciKTe","email":"AIwPgMB@gmail.com","firstName":"AIwPgMB","lastName":"AIwPgMB"}
  02:28:16.228 [front-end] Posting Customer: {"username":"yTFoonPwqaY","password":"UsabiUKuuH","email":"yTFoonPwqaY@gmail.com","firstName":"yTFoonPwqaY","lastName":"yTFoonPwqaY"}
  02:28:17.978 [front-end] Posting Customer: {"username":"XaRPipq","password":"IPVIE","email":"XaRPipq@gmail.com","firstName":"XaRPipq","lastName":"XaRPipq"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.114 [front-end] Received response: "{\"firstName\":\"bCCZHBaYc\",\"lastName\":\"bCCZHBaYc\",\"username\":\"bCCZHBaYc\",\"id\":\"673fec31b0df5c00019af95b\",\"_links\":{\"address
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=673ns  (×9)
  02:28:23.749 [front-end] Posting Customer: {"username":"bhZuEQ","password":"CYefrd","email":"bhZuEQ@gmail.com","firstName":"bhZuEQ","lastName":"bhZuEQ"}
  02:28:24.870 [front-end] Received response: "{\"firstName\":\"sgQXbZQ\",\"lastName\":\"sgQXbZQ\",\"username\":\"sgQXbZQ\",\"id\":\"673fec33b0df5c00019af963\",\"_links\":{\"addresses\":{
  02:28:25.471 [front-end] Received response: "{\"firstName\":\"TcTuIokN\",\"lastName\":\"TcTuIokN\",\"username\":\"TcTuIokN\",\"id\":\"673fec32b0df5c00019af95c\",\"_links\":{\"addresses\
  02:28:25.838 [carts] 2024-11-22 02:28:25.837 INFO [carts,041812a6e38b1a0d,28fc13fb8146605a,false] 7 --- [-nio-80-exec-10] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×7)
  02:28:26.670 [orders-db] {"t":{"$date":"2024-11-22T02:28:26.670+00:00"},"s":"I", "c":"STORAGE", "id":20279, "ctx":"conn2","msg":"Conflicted creating a collection","attr":{"namespace":"d
  02:28:26.957 [front-end] Order response: {"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","lastName":"vuOxCKL","usern
  02:28:26.962 [front-end] Order response: {"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPb
  02:28:27.060 [front-end] Order response: {"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","lastName":"HFHBXn","usernam
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.842 [front-end] Posting Customer: {"username":"UsfOoRUlayKw","password":"RviRN","email":"UsfOoRUlayKw@gmail.com","firstName":"UsfOoRUlayKw","lastName":"UsfOoRUlayKw"}
  02:28:32.341 [queue-master] Caused by: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket
  02:28:32.649 [queue-master] 2024-11-22 02:28:32.649 ERROR 6 --- [ool-6-thread-10] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.  (×4)

## p0169
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T06:30:59.441Z
```
{"timestamp":1731911459441033700,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"request started"}
```
Same service, the 2 minutes before (oldest first):
  06:30:57.753 [frontend] request complete  (×7)
  06:30:57.820 [frontend] request started  (×6)
  06:30:57.820 [frontend] serving product page  (×2)
  06:30:58.729 [frontend] view user cart  (×2)
  06:30:58.755 [frontend] setting currency
  06:30:58.759 [frontend] home
  06:30:58.804 [frontend] ENV_PLATFORM is: aws
All services, 30 seconds either side (sampled):
  06:30:30.206 [frontend] request started  (×291)
  06:30:30.213 [cartservice] GetCartAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43  (×246)
  06:30:30.237 [adservice] received ad request (context_words=[kitchen])  (×65)
  06:30:31.660 [frontend] view user cart  (×61)
  06:30:32.366 [frontend] setting currency  (×15)
  06:30:32.420 [adservice] received ad request (context_words=[])  (×23)
  06:30:34.069 [cartservice] AddItemAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43, productId=OLJCESPC7Z, quantity=7  (×31)
  06:30:34.115 [checkoutservice] [PlaceOrder] user_id="5e004f2d-a61a-45b2-840d-6bfd47a2be43" user_currency="TRY"  (×4)
  06:30:34.136 [checkoutservice] payment went through (transaction_id: 317285a1-a55d-46ad-bae0-1e0b75c2920d)  (×8)
  06:30:34.140 [cartservice] EmptyCartAsync called with userId=5e004f2d-a61a-45b2-840d-6bfd47a2be43  (×8)
  06:30:34.148 [frontend] order placed  (×8)
  06:30:35.299 [paymentservice] Transaction processed: visa ending 6961 Amount: EUR15.904467050
  06:30:36.105 [adservice] received ad request (context_words=[footwear])  (×15)
  06:30:40.241 [paymentservice] Transaction processed: visa ending 1466 Amount: CAD72.180833256  (×2)
  06:30:44.779 [recommendationservice] [Recv ListRecommendations] product_ids=['OLJCESPC7Z', 'LS4PSXUNUM', '66VCHSJNUP']  (×3)
  06:31:04.431 [checkoutservice] order confirmation email sent to "danielmartinez@example.net"
  06:31:09.010 [redis] 64:C 18 Nov 2024 06:31:09.010 * DB saved on disk
  06:31:10.465 [emailservice] A request to send order confirmation email to ashley54@example.com has been received.
  06:31:20.421 [checkoutservice] order confirmation email sent to "mitchellhunt@example.com"
  06:31:23.758 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', '66VCHSJNUP', '6E92ZMYYFZ', '2ZYFJ3GM2N']
  06:31:23.843 [paymentservice] Transaction processed: visa ending 7061 Amount: USD867.630000000

## p0663
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-11T08:09:19.503Z
```
{"service":"dbservice2","message":"2021-08-11 08:09:19,503 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | 636bc1c995f41623 | 5f349cb4-fa38-11eb-8ad7-0242ac110004-GtoYwjTK-f!Aq7{}_JxO# token generate success token=MTYyODY0MDU1OS41MDI2NTAzOjVmMzQ5Y2I0LWZhMzgtMTFlYi04YWQ3LTAyNDJhYzExMDAwNEd0b1l3alRLZiFBcTd7fV9KeE8jOjE2Mjg2NDA2MTkuNTAyNjYzNDo2YTRjMmYyOGI1MzVhNTIzY2YxNzQ2ZjI0ODBjZTIyNw=="}
```
Same service, the 2 minutes before (oldest first):
  08:09:12.542 [dbservice2] INFO query = select passwards from username_table where user_name='FjQZnIyb'  (×5)
  08:09:12.620 [dbservice2] INFO 5b12ab08-fa38-11eb-9f5a-0242ac110004-FjQZnIyb-N?AQYWzUJSXj token generate success token=MTYyODY0MDU1Mi42MjAyODMxOjViMTJhYjA4LWZhMzgtMTFlYi05ZjVhLTAyNDJhYzE
  08:09:12.761 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:09:12.768 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  08:09:12.910 [dbservice2] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  08:09:14.175 [dbservice2] INFO 5c119604-fa38-11eb-9fdc-0242ac110004-XlGeVCEy-Dx=81Fp5#0!: token generate success token=MTYyODY0MDU1NC4xNzUxMjk0OjVjMTE5NjA0LWZhMzgtMTFlYi05ZmRjLTAyNDJhYzE
  08:09:17.148 [dbservice2] INFO 5dbde142-fa38-11eb-8e24-0242ac110004-GrKgOByV-n@*{TE_p^JR3 token generate success token=MTYyODY0MDU1Ny4xNDc1NjQ2OjVkYmRlMTQyLWZhMzgtMTFlYi04ZTI0LTAyNDJhYzE
  08:09:17.977 [dbservice2] INFO 5e4d9d3c-fa38-11eb-89c0-0242ac110004-rAmXuCJg-%$eQN0lfASj) token generate success token=MTYyODY0MDU1Ny45NzY2NzY3OjVlNGQ5ZDNjLWZhMzgtMTFlYi04OWMwLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  08:08:49.525 [redisservice1] INFO redis write success  (×92)
  08:08:49.635 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×30)
  08:08:49.752 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×26)
  08:08:50.036 [webservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×61)
  08:08:50.177 [webservice2] INFO uuid: 4e26c9ba-fa38-11eb-9704-0242ac110004 write redis successfully  (×62)
  08:08:50.445 [mobservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×24)
  08:08:50.597 [redisservice2] INFO redis读取信息成功, status_code: 200  (×35)
  08:08:50.792 [mobservice2] INFO info 4e566d5a-fa38-11eb-8f46-0242ac110004:JIoWshby write success
  08:08:52.136 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×32)
  08:08:52.289 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  08:08:53.680 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×28)
  08:08:56.024 [dbservice2] INFO 512cc8da-fa38-11eb-9bed-0242ac110004-aRNnXZPl-Eq0%L#J(4Boe token generate success token=MTYyODY0MDUzNi4wMjM1MzU3OjUxMmNjOGRhLWZhMzgtMTFlYi05YmVkLTAyNDJhYzE
  08:08:58.280 [dbservice1] INFO 5292aa46-fa38-11eb-8683-0242ac110004-glaSXZGO-iB:Guv&kX(1a token generate success token=MTYyODY0MDUzOC4yODA0Mjg2OjUyOTJhYTQ2LWZhMzgtMTFlYi04NjgzLTAyNDJhYzE
  08:09:01.764 [mobservice2] INFO info 54d8aeae-fa38-11eb-8ddd-0242ac110004:qhdLCnSU write success
  08:09:04.644 [mobservice2] INFO info 5696f30e-fa38-11eb-b8ab-0242ac110004:OYPSuZEk write success
  08:09:07.401 [mobservice2] INFO info 5840da3a-fa38-11eb-92cb-0242ac110004:dUFBYtEJ write success
  08:09:10.604 [mobservice1] INFO info 5a1cacf8-fa38-11eb-a1cd-0242ac110004:BGRWzCUk write success
  08:09:12.620 [dbservice2] INFO 5b12ab08-fa38-11eb-9f5a-0242ac110004-FjQZnIyb-N?AQYWzUJSXj token generate success token=MTYyODY0MDU1Mi42MjAyODMxOjViMTJhYjA4LWZhMzgtMTFlYi05ZjVhLTAyNDJhYzE
  08:09:15.503 [mobservice1] INFO info 5cfa8a58-fa38-11eb-b2eb-0242ac110004:HxQpIWMr write success
  08:09:17.616 [mobservice2] INFO info 5e4d9d3c-fa38-11eb-89c0-0242ac110004:rAmXuCJg write success
  08:09:20.968 [dbservice1] INFO 600de8d4-fa38-11eb-8e66-0242ac110004-VyLzqQJk-}pyOM4tuZwb_ token generate success token=MTYyODY0MDU2MC45Njg1MzgzOjYwMGRlOGQ0LWZhMzgtMTFlYi04ZTY2LTAyNDJhYzE
  08:09:23.829 [dbservice2] INFO 61c60b70-fa38-11eb-94b4-0242ac110004-FqaTIXhn-^vCabrQL@MgF token generate success token=MTYyODY0MDU2My44Mjg1MjEzOjYxYzYwYjcwLWZhMzgtMTFlYi05NGI0LTAyNDJhYzE
  08:09:25.969 [dbservice2] INFO 63129aac-fa38-11eb-948b-0242ac110004-lEKkjfpD-^a37_&?:CJeS token generate success token=MTYyODY0MDU2NS45NjkzMzg0OjYzMTI5YWFjLWZhMzgtMTFlYi05NDhiLTAyNDJhYzE
  08:09:28.927 [dbservice2] ERROR (pymysql.err.OperationalError) (1065, 'Query was empty')(Background on this error at: http://sqlalche.me/e/14/e3q8)
  08:09:31.213 [dbservice1] INFO 662ac110-fa38-11eb-a31d-0242ac110004-bTPjsUVJ-/OMn<NHZb.me token generate success token=MTYyODY0MDU3MS4yMTMwMDg0OjY2MmFjMTEwLWZhMzgtMTFlYi1hMzFkLTAyNDJhYzE
  08:09:33.764 [mobservice2] INFO info 67ede72a-fa38-11eb-8336-0242ac110004:hpcKRNdx write success
  08:09:36.139 [dbservice1] INFO 691b6fdc-fa38-11eb-b223-0242ac110004-jDuLxAwt-4Z=}YxLyb1Sp token generate success token=MTYyODY0MDU3Ni4xMzk0NTo2OTFiNmZkYy1mYTM4LTExZWItYjIyMy0wMjQyYWMxMTA
  08:09:38.789 [dbservice2] INFO 6ab630f2-fa38-11eb-9c0d-0242ac110004-QPshVMni-fRh+&gdSX4F> token generate success token=MTYyODY0MDU3OC43ODkxMzU1OjZhYjYzMGYyLWZhMzgtMTFlYi05YzBkLTAyNDJhYzE
  08:09:42.281 [dbservice1] ERROR password in database of {user} is null, the user is not registered

## p0727
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-14T18:55:41.502Z
```
{"service":"mobservice2","message":"2021-08-14 18:55:41,502 | INFO | 0.0.0.4 | 172.17.0.2 | mobservice2 | 58792c04c9550354 | now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service"}
```
Same service, the 2 minutes before (oldest first):
  18:55:37.765 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×4)
  18:55:37.765 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': '2865765a-fcee-11eb-8963-0242ac110003'}  (×4)
  18:55:37.819 [mobservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '2865765a-fcee-11eb-8963-0242ac110003', 'value': 'NFrlOSIe'}  (×4)
  18:55:37.876 [mobservice2] INFO info 2865765a-fcee-11eb-8963-0242ac110003:NFrlOSIe write success
  18:55:38.889 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  18:55:39.080 [mobservice2] INFO info 290c2842-fcee-11eb-8b5c-0242ac110004:OKolGsUM write success
  18:55:39.917 [mobservice2] INFO info 299eff0a-fcee-11eb-ba22-0242ac110003:cUsPLdAz write success
  18:55:40.780 [mobservice2] INFO info 2a1ab7f8-fcee-11eb-8c36-0242ac110004:MxLzTnND write success
All services, 30 seconds either side (sampled):
  18:55:11.542 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  18:55:11.674 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×49)
  18:55:11.811 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×43)
  18:55:11.878 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×43)
  18:55:11.917 [logservice2] INFO now call service:dbservice2, inst:http://0.0.0.2:9389 as a downstream service  (×51)
  18:55:12.263 [webservice2] INFO uuid: 19515ab2-fcee-11eb-b77f-0242ac110004 write redis successfully  (×46)
  18:55:13.308 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×50)
  18:55:14.253 [mobservice1] INFO info 1a507114-fcee-11eb-9e18-0242ac110004:aZMCtwXA write success
  18:55:14.983 [dbservice1] INFO 1a7f144c-fcee-11eb-b430-0242ac110003-ToeLCkHR-(_n2MJ%R.Uw0 token generate success token=MTYyODkzODUxNC45ODMyMTEzOjFhN2YxNDRjLWZjZWUtMTFlYi1iNDMwLTAyNDJhYzE
  18:55:17.507 [mobservice2] INFO info 1c3f353c-fcee-11eb-93b7-0242ac110004:aLCdNFuD write success
  18:55:19.882 [mobservice2] INFO info 1da58e30-fcee-11eb-a0cd-0242ac110004:geuyhpUk write success
  18:55:22.715 [dbservice1] INFO 1f2b6a5e-fcee-11eb-afd9-0242ac110003-nlMAOLaH-.+x$_%GPZ*lV token generate success token=MTYyODkzODUyMi43MTUxOTc6MWYyYjZhNWUtZmNlZS0xMWViLWFmZDktMDI0MmFjMTE
  18:55:25.081 [dbservice2] INFO 2094ddee-fcee-11eb-9258-0242ac110004-lTYxuZoK-3UtL7AG$HnN5 token generate success token=MTYyODkzODUyNS4wODEzODY4OjIwOTRkZGVlLWZjZWUtMTFlYi05MjU4LTAyNDJhYzE
  18:55:28.411 [dbservice1] INFO 2282bbd0-fcee-11eb-80bc-0242ac110004-kWPHSeaC-nKV<}+zw:Zk% token generate success token=MTYyODkzODUyOC40MTA5MjE4OjIyODJiYmQwLWZjZWUtMTFlYi04MGJjLTAyNDJhYzE
  18:55:31.239 [dbservice1] INFO 24335566-fcee-11eb-a801-0242ac110004-rtRkpsfM-ul#Hy_*g:KTb token generate success token=MTYyODkzODUzMS4yMzkwODk1OjI0MzM1NTY2LWZjZWUtMTFlYi1hODAxLTAyNDJhYzE
  18:55:33.540 [dbservice2] INFO 25a79f60-fcee-11eb-b068-0242ac110004-etgkwBmP-D<TlS9enGxsY token generate success token=MTYyODkzODUzMy41Mzk4MjA0OjI1YTc5ZjYwLWZjZWUtMTFlYi1iMDY4LTAyNDJhYzE
  18:55:36.003 [dbservice1] INFO 2712172c-fcee-11eb-bde1-0242ac110003-cgKfeRjJ-?%FBPz^@kcZD token generate success token=MTYyODkzODUzNi4wMDI2MjM2OjI3MTIxNzJjLWZjZWUtMTFlYi1iZGUxLTAyNDJhYzE
  18:55:38.510 [dbservice1] INFO 28861c2a-fcee-11eb-8e30-0242ac110003-GLwvPubR-c9O=AoplwGk_ token generate success token=MTYyODkzODUzOC41MTA1MTY6Mjg4NjFjMmEtZmNlZS0xMWViLThlMzAtMDI0MmFjMTE  (×3)
  18:55:41.161 [dbservice1] INFO 2a1ab7f8-fcee-11eb-8c36-0242ac110004-MxLzTnND-Vr<g@j{uqoD> token generate success token=MTYyODkzODU0MS4xNjA3NDI4OjJhMWFiN2Y4LWZjZWUtMTFlYi04YzM2LTAyNDJhYzE
  18:55:43.872 [dbservice1] INFO 2bbbfa86-fcee-11eb-a93c-0242ac110004-dImbafKg-u#L?}jdp-2_5 token generate success token=MTYyODkzODU0My44NzI1NjgxOjJiYmJmYTg2LWZjZWUtMTFlYi1hOTNjLTAyNDJhYzE
  18:55:46.740 [mobservice2] INFO info 2da96e46-fcee-11eb-a9d2-0242ac110004:LEFinroh write success
  18:55:49.697 [dbservice1] INFO 2f2c535a-fcee-11eb-a292-0242ac110003-DGlMEFgf-hDX.AML@KH9e token generate success token=MTYyODkzODU0OS42OTY3MzgyOjJmMmM1MzVhLWZjZWUtMTFlYi1hMjkyLTAyNDJhYzE
  18:55:52.688 [mobservice2] INFO info 313b2b12-fcee-11eb-a489-0242ac110003:qhdLCnSU write success
  18:55:55.578 [dbservice1] INFO 32aea4c4-fcee-11eb-a361-0242ac110004-DhdfCMlE-06Cn#%rGUWLg token generate success token=MTYyODkzODU1NS41Nzc4MTE3OjMyYWVhNGM0LWZjZWUtMTFlYi1hMzYxLTAyNDJhYzE
  18:55:58.503 [mobservice1] INFO info 34a7e236-fcee-11eb-852a-0242ac110004:wkgeEpUD write success
  18:56:01.255 [dbservice1] INFO 36131f50-fcee-11eb-a2f7-0242ac110003-yjlLtMmx-<?.ZdYVR2js- token generate success token=MTYyODkzODU2MS4yNTU1NDIzOjM2MTMxZjUwLWZjZWUtMTFlYi1hMmY3LTAyNDJhYzE
  18:56:03.812 [dbservice2] INFO 3795bdb0-fcee-11eb-a69f-0242ac110004-NptDIkKG--%hyo201DjM@ token generate success token=MTYyODkzODU2My44MTIyMjQ5OjM3OTViZGIwLWZjZWUtMTFlYi1hNjlmLTAyNDJhYzE
  18:56:06.644 [mobservice1] INFO info 398ba9e0-fcee-11eb-9282-0242ac110003:ropVRsqh write success
  18:56:09.599 [mobservice1] INFO info 3b4aeaca-fcee-11eb-a7c5-0242ac110004:CzojFELq write success

## p0012
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T06:12:44.264Z
```
{"service":"dbservice2","message":"2021-08-13 06:12:44,264 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | 9d2c04237c7f5834 | 6a90ae26-fbba-11eb-a037-0242ac110004-OzKQAVJF-y0PH2h:lM}5T token generate success token=MTYyODgwNjM2NC4yNjQwODc0OjZhOTBhZTI2LWZiYmEtMTFlYi1hMDM3LTAyNDJhYzExMDAwNE96S1FBVkpGeTBQSDJoOmxNfTVUOjE2Mjg4MDY0MjQuMjY0MTo2MzJlYmQ1NDM2MzI3NTk3Nzk3OTVhODVmMmZjNWYyNw=="}
```
Same service, the 2 minutes before (oldest first):
  06:12:38.298 [dbservice2] INFO 67003e02-fbba-11eb-9621-0242ac110004-IAqgbwQB-^lEzKvT%j{F_ token generate success token=MTYyODgwNjM1OC4yOTc3MDQ3OjY3MDAzZTAyLWZiYmEtMTFlYi05NjIxLTAyNDJhYzE
  06:12:39.055 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  06:12:39.056 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  06:12:39.121 [dbservice2] INFO query = select passwards from username_table where user_name='qONAMdbK'  (×5)
  06:12:39.199 [dbservice2] INFO 677f56c4-fbba-11eb-ae48-0242ac110003-qONAMdbK-U5b4*vyY%+>A token generate success token=MTYyODgwNjM1OS4xOTg0OTU6Njc3ZjU2YzQtZmJiYS0xMWViLWFlNDgtMDI0MmFjMTE
  06:12:39.992 [dbservice2] INFO 68087bde-fbba-11eb-9f57-0242ac110003-DHpIOPcr--ZJF#vtu)<Ez token generate success token=MTYyODgwNjM1OS45OTE4NTU5OjY4MDg3YmRlLWZiYmEtMTFlYi05ZjU3LTAyNDJhYzE
  06:12:40.849 [dbservice2] INFO 688518c4-fbba-11eb-a0bf-0242ac110003-NSiQolUW-T3rg/Jh_qz#l token generate success token=MTYyODgwNjM2MC44NDkxOTEyOjY4ODUxOGM0LWZiYmEtMTFlYi1hMGJmLTAyNDJhYzE
  06:12:42.569 [dbservice2] INFO 69996526-fbba-11eb-8c56-0242ac110003-SgtQlrMk-1<ViNJ$gM^?l token generate success token=MTYyODgwNjM2Mi41Njk0NzY0OjY5OTk2NTI2LWZiYmEtMTFlYi04YzU2LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  06:12:14.310 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  06:12:14.486 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×38)
  06:12:14.654 [mobservice1] INFO info 5925847c-fbba-11eb-97e5-0242ac110004:rZfAFMBU write success
  06:12:14.767 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '5925847c-fbba-11eb-97e5-0242ac110004', 'user_id': 'rZfAFMBU'}  (×81)
  06:12:14.935 [dbservice2] INFO query = select passwards from username_table where user_name='rZfAFMBU'  (×41)
  06:12:15.271 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×43)
  06:12:15.570 [redisservice1] INFO redis读取信息成功, status_code: 200  (×42)
  06:12:15.835 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×40)
  06:12:16.639 [dbservice2] INFO 5a15c6e4-fbba-11eb-ab91-0242ac110003-FAmtCcIX-WbpwIhFy&DB@ token generate success token=MTYyODgwNjMzNi42Mzg4MTc6NWExNWM2ZTQtZmJiYS0xMWViLWFiOTEtMDI0MmFjMTE
  06:12:18.233 [dbservice1] INFO 5b083726-fbba-11eb-bba8-0242ac110003-DtNVdFIW-^*x0{Xp?zMmG token generate success token=MTYyODgwNjMzOC4yMzMwMjg0OjViMDgzNzI2LWZiYmEtMTFlYi1iYmE4LTAyNDJhYzE
  06:12:20.400 [mobservice2] INFO info 5c93a882-fbba-11eb-b6d5-0242ac110003:pdAkGNZq write success
  06:12:22.329 [dbservice1] INFO 5d855024-fbba-11eb-854d-0242ac110004-UztohuyV-)xno$&{aC4EX token generate success token=MTYyODgwNjM0Mi4zMjg4NTE3OjVkODU1MDI0LWZiYmEtMTFlYi04NTRkLTAyNDJhYzE
  06:12:24.981 [dbservice1] INFO 5ef00f80-fbba-11eb-af4c-0242ac110004-zrFvXilR-FLZtA/04V6Mi token generate success token=MTYyODgwNjM0NC45ODE1NTU1OjVlZjAwZjgwLWZiYmEtMTFlYi1hZjRjLTAyNDJhYzE
  06:12:32.964 [mobservice1] INFO info 640d8f4c-fbba-11eb-be36-0242ac110003:qexisTfm write success
  06:12:36.594 [dbservice2] INFO 65ff5e66-fbba-11eb-85e2-0242ac110004-DjXaKYNR-/Q*Yd=S2X37R token generate success token=MTYyODgwNjM1Ni41OTM4MDU6NjVmZjVlNjYtZmJiYS0xMWViLTg1ZTItMDI0MmFjMTE
  06:12:39.199 [dbservice2] INFO 677f56c4-fbba-11eb-ae48-0242ac110003-qONAMdbK-U5b4*vyY%+>A token generate success token=MTYyODgwNjM1OS4xOTg0OTU6Njc3ZjU2YzQtZmJiYS0xMWViLWFlNDgtMDI0MmFjMTE
  06:12:41.693 [mobservice1] INFO info 69438156-fbba-11eb-98ac-0242ac110003:kpLnyIUm write success
  06:12:43.905 [mobservice1] INFO info 6a90ae26-fbba-11eb-a037-0242ac110004:OzKQAVJF write success
  06:12:46.568 [mobservice1] INFO info 6c1d4a42-fbba-11eb-9b44-0242ac110003:CeJfdxpR write success  (×2)
  06:12:48.626 [dbservice2] INFO 6d22e9ec-fbba-11eb-9281-0242ac110003-hPlvogHR-K>5beft3ioYy token generate success token=MTYyODgwNjM2OC42MjU4NDE0OjZkMjJlOWVjLWZiYmEtMTFlYi05MjgxLTAyNDJhYzE
  06:12:50.744 [dbservice2] INFO 6e748d00-fbba-11eb-8197-0242ac110004-dnDTbBha-yx8)4Fs?KhJg token generate success token=MTYyODgwNjM3MC43NDM5OTc6NmU3NDhkMDAtZmJiYS0xMWViLTgxOTctMDI0MmFjMTE
  06:12:53.334 [mobservice1] INFO info 701ca0ac-fbba-11eb-b8ab-0242ac110004:zAFcSJGh write success
  06:12:56.019 [dbservice2] INFO 71932fa0-fbba-11eb-ab96-0242ac110003-CkWFaQYZ-7JwrWYRM-C^D token generate success token=MTYyODgwNjM3Ni4wMTg1Njk3OjcxOTMyZmEwLWZiYmEtMTFlYi1hYjk2LTAyNDJhYzE
  06:12:58.232 [mobservice1] INFO info 731b0cf8-fbba-11eb-8f01-0242ac110004:BrtsWueY write success
  06:13:00.005 [mobservice2] INFO info 7428169a-fbba-11eb-9ffb-0242ac110003:OVLDMHZf write success
  06:13:02.302 [dbservice2] INFO 75498d60-fbba-11eb-b717-0242ac110003-PVFHnXol-4ksJ2?fe(UZ- token generate success token=MTYyODgwNjM4Mi4zMDIyMzEzOjc1NDk4ZDYwLWZiYmEtMTFlYi1iNzE3LTAyNDJhYzE
  06:13:05.049 [mobservice1] INFO info 772d9c7a-fbba-11eb-a906-0242ac110004:OLdMPCWp write success
  06:13:07.595 [mobservice1] INFO info 78b05a2e-fbba-11eb-9dfd-0242ac110004:cNyGSbzR write success
  06:13:09.889 [mobservice2] INFO info 7a0fffdc-fbba-11eb-a32a-0242ac110004:HIfdKLoq write success
  06:13:12.507 [dbservice2] INFO 7b6e91ae-fbba-11eb-a4fd-0242ac110004-CeJfdxpR-q&(u@BeE#Z9h token generate success token=MTYyODgwNjM5Mi41MDcwMjE3OjdiNmU5MWFlLWZiYmEtMTFlYi1hNGZkLTAyNDJhYzE

## p0099
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service paymentservice, 2024-11-18T05:05:51.663Z
```
{"service":"paymentservice","operation":"grpc.hipstershop.PaymentService/Charge","method":"Charge","status_code":400,"duration_us":702,"trace_id":"bfc52b9eb6fef86dcd193fc701e0f189","message":"span grpc.hipstershop.PaymentService/Charge failed with gRPC status 400"}
```
Same service, the 2 minutes before (oldest first):
  05:05:29.016 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"156","nanos":910000000},"credit_card":{"credit_card_number":"47921052651543  (×3)
  05:05:29.016 [paymentservice] Transaction processed: visa ending 4329 Amount: USD156.910000000  (×3)
  05:05:33.972 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"426","nanos":701933656},"credit_card":{"credit_card_number":"47774499442426  (×2)
  05:05:33.972 [paymentservice] Transaction processed: visa ending 2652 Amount: CAD426.701933656
  05:05:51.663 [paymentservice] UnacceptedCreditCard [Error]: Sorry, we cannot process visa_electron credit cards. Only VISA or MasterCard is accepted. at charge (/usr/src/app/charge.js:74:68)
  05:05:51.663 [paymentservice] }
All services, 30 seconds either side (sampled):
  05:05:28.413 [frontend] request started  (×265)
  05:05:28.422 [cartservice] GetCartAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20  (×218)
  05:05:28.449 [adservice] received ad request (context_words=[accessories])  (×17)
  05:05:28.458 [cartservice] AddItemAsync called with userId=d4e28c38-1561-4a66-b120-02013f892c20, productId=1YMWWN1N4O, quantity=7  (×26)
  05:05:28.497 [shippingservice] [GetQuote] completed request  (×59)
  05:05:28.996 [checkoutservice] [PlaceOrder] user_id="49eac425-0b6d-4e41-b8ac-4be1a27aeb58" user_currency="USD"  (×6)
  05:05:29.017 [checkoutservice] payment went through (transaction_id: e43c7587-0e24-4a72-8d85-16a465855b2a)  (×9)
  05:05:29.021 [cartservice] EmptyCartAsync called with userId=49eac425-0b6d-4e41-b8ac-4be1a27aeb58  (×9)
  05:05:29.030 [frontend] order placed  (×9)
  05:05:31.741 [adservice] received ad request (context_words=[decor, home])  (×11)
  05:05:32.748 [frontend] ENV_PLATFORM is: aws  (×39)
  05:05:33.869 [adservice] received ad request (context_words=[footwear])  (×17)
  05:05:33.972 [paymentservice] Transaction processed: visa ending 2652 Amount: CAD426.701933656
  05:05:38.673 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', 'L9ECAV7KIM', 'OLJCESPC7Z']  (×4)
  05:05:46.056 [emailservice] A request to send order confirmation email to fcontreras@example.com has been received.
  05:05:51.642 [checkoutservice] span hipstershop.CheckoutService/PlaceOrder failed with gRPC status 13  (×2)
  05:05:51.667 [frontend] request error
  05:05:52.048 [redis] 47:C 18 Nov 2024 05:05:52.048 * DB saved on disk
  05:05:52.502 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="EUR"
  05:05:52.540 [emailservice] A request to send order confirmation email to vsimpson@example.net has been received.
  05:06:04.238 [checkoutservice] order confirmation email sent to "michaelacosta@example.net"
  05:06:10.954 [emailservice] A request to send order confirmation email to michael03@example.com has been received.
  05:06:12.456 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"107763","nanos":686865077},"credit_card":{"credit_card_number":"43292417215
  05:06:12.472 [checkoutservice] order confirmation email sent to "leenathaniel@example.org"

## p0277
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:23.543Z
```
{"timestamp":1732242503543710200,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"set cookie673fec45b0df5c00019af990"}
```
Same service, the 2 minutes before (oldest first):
  02:28:23.094 [front-end] GET /catalogue 200 - ms - -  (×2)
  02:28:23.137 [front-end] Carts merged.  (×2)
  02:28:23.137 [front-end] set cookie673fec41b0df5c00019af98b
  02:28:23.137 [front-end] Sent cookies.
  02:28:23.139 [front-end] POST /register 200 5585.892 ms - 33
  02:28:23.295 [front-end] Request received with body: {}
  02:28:23.301 [front-end] Received response: "{\"firstName\":\"HFHBXn\",\"lastName\":\"HFHBXn\",\"username\":\"HFHBXn\",\"id\":\"673fec34b0df5c00019af967\",\"_links\":{\"addresses\":{\"h
  02:28:23.301 [front-end] GET Request to: http://user/customers/673fec34b0df5c00019af967/addresses  (×2)
  02:28:23.308 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:23.308 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec3eb0df5c00019af984\",\"_links\":{\"
  02:28:23.308 [front-end] [ undefined, undefined ]
  02:28:23.308 [front-end] Posting Order: {"customer":"http://user/customers/673fec34b0df5c00019af967","address":"http://user/addresses/673fec3eb0df5c00019af983","card":"http://user/cards
  02:28:23.340 [front-end] User cart deleted with status: 202
  02:28:23.342 [front-end] DELETE /cart 202 - ms - -
  02:28:23.354 [front-end] Attempting to add to cart: {"id":"837ab141-399e-4c1f-9abc-bace40296bac","quantity":1}
  02:28:23.362 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["
  02:28:23.362 [front-end] POST to carts: http://carts/carts/673fec3eb0df5c00019af985/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×49)
  02:28:03.176 [front-end] DELETE /cart 503 - ms - -  (×49)
  02:28:03.203 [front-end] [ undefined, undefined ]  (×48)
  02:28:03.281 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×5)
  02:28:03.519 [front-end] Posting Customer: {"username":"sgQXbZQ","password":"MIojoNS","email":"sgQXbZQ@gmail.com","firstName":"sgQXbZQ","lastName":"sgQXbZQ"}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images  (×4)
  02:28:07.445 [orders] 2024-11-22 02:28:07.445 ERROR [orders,,,] 6 --- [-nio-80-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c
  02:28:10.277 [front-end] Posting Customer: {"username":"opFqwUnVow","password":"habyXFSF","email":"opFqwUnVow@gmail.com","firstName":"opFqwUnVow","lastName":"opFqwUnVow"}
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.552 [front-end] Posting Customer: {"username":"YvfCwaQKfe","password":"dPEcBDI","email":"YvfCwaQKfe@gmail.com","firstName":"YvfCwaQKfe","lastName":"YvfCwaQKfe"}
  02:28:20.035 [carts] 2024-11-22 02:28:20.035 INFO [carts,d3d9b0ce3a88c8d9,21bdcf90922fb619,false] 7 --- [p-nio-80-exec-5] org.mongodb.driver.connection : Opened connection [connecti  (×9)
  02:28:22.590 [front-end] Posting Customer: {"username":"BinEtfHdGk","password":"MbOyyriEOV","email":"BinEtfHdGk@gmail.com","firstName":"BinEtfHdGk","lastName":"BinEtfHdGk"}
  02:28:23.301 [front-end] Received response: "{\"firstName\":\"HFHBXn\",\"lastName\":\"HFHBXn\",\"username\":\"HFHBXn\",\"id\":\"673fec34b0df5c00019af967\",\"_links\":{\"addresses\":{\"h
  02:28:24.999 [rabbitmq] 
  02:28:25.743 [carts] 2024-11-22 02:28:25.743 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×14)
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39d0","customerId":"673fec31b0df5c00019af95b","customer":{"id":null,"firstName":"bCCZHBaYc","lastName":"bCCZHBaYc","u
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.645 [carts-db] {"t":{"$date":"2024-11-22T02:28:27.645+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:32.249 [queue-master] 2024-11-22 02:28:32.248 ERROR 6 --- [a-jaxrs-async-0] c.g.d.core.async.ResultCallbackTemplate : Error during callback 
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×60)
  02:28:37.548 [user] ts=2024-11-22T02:28:37.548591Z caller=middlewares.go:46 method=Register username=OeZpiPZUn email=OeZpiPZUn@gmail.com took=1.009704ms
  02:28:40.321 [front-end] Order response: {"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR","lastName":"nbZCdAQyR","u
  02:28:42.162 [front-end] Order response: {"statusCode":406,"body":{"timestamp":1732242522152,"status":406,"error":"Not Acceptable","exception":"works.weave.socks.orders.controllers.Orde  (×2)
  02:28:44.338 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec5cd94b9000069b39e2","customerId":"673fec3ab0df5c00019af974","customer":{"id":null,"firstName":"opFqwUnVow"
  02:28:45.405 [front-end] Posting Customer: {"username":"crSMtAKNWrXaJJx","password":"TlwWXSanSW","email":"crSMtAKNWrXaJJx@gmail.com","firstName":"crSMtAKNWrXaJJx","lastName":"crSMtAKNWr
  02:28:47.575 [front-end] Received response: "{\"firstName\":\"QGHrdp\",\"lastName\":\"QGHrdp\",\"username\":\"QGHrdp\",\"id\":\"673fec41b0df5c00019af98c\",\"_links\":{\"addresses\":{\"h
  02:28:50.618 [front-end] Received response: "{\"firstName\":\"XsZRA\",\"lastName\":\"XsZRA\",\"username\":\"XsZRA\",\"id\":\"673fec4ab0df5c00019af99b\",\"_links\":{\"addresses\":{\"href

## p0072
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T09:03:51.243Z
```
{"service":"dbservice2","message":"2021-08-13 09:03:51,243 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | 2bfce10f2fa55542 | 521eb1e0-fbd2-11eb-9263-0242ac110004-dIHpsMvT-UQ)#EA.:F_XL token generate success token=MTYyODgxNjYzMS4yNDI5MzMzOjUyMWViMWUwLWZiZDItMTFlYi05MjYzLTAyNDJhYzExMDAwNGRJSHBzTXZUVVEpI0VBLjpGX1hMOjE2Mjg4MTY2OTEuMjQyOTQ0Nzo2YzBjYzA1NmFmOWMxZGQwNGU0MmUxY2Q3OTVlNDU1Ng=="}
```
Same service, the 2 minutes before (oldest first):
  09:03:45.131 [dbservice2] INFO 4e8be228-fbd2-11eb-ac45-0242ac110003-QoXmzFit-OWK_0QrnFE_{ token generate success token=MTYyODgxNjYyNS4xMzA5Mzc6NGU4YmUyMjgtZmJkMi0xMWViLWFjNDUtMDI0MmFjMTE
  09:03:45.446 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  09:03:45.446 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  09:03:45.462 [dbservice2] INFO query = select passwards from username_table where user_name='sSHyNrVB'  (×5)
  09:03:45.540 [dbservice2] INFO 4ec932a4-fbd2-11eb-b698-0242ac110004-sSHyNrVB-$=dDovf1IJC# token generate success token=MTYyODgxNjYyNS41Mzk5MTU6NGVjOTMyYTQtZmJkMi0xMWViLWI2OTgtMDI0MmFjMTE
  09:03:45.948 [dbservice2] INFO 4f069950-fbd2-11eb-9e61-0242ac110004-fxyAUSmc-SB0MREGuyO8- token generate success token=MTYyODgxNjYyNS45NDc3NTo0ZjA2OTk1MC1mYmQyLTExZWItOWU2MS0wMjQyYWMxMTA
  09:03:48.338 [dbservice2] INFO 507403d6-fbd2-11eb-9fc2-0242ac110003-FfCPbjsD-:BLSZWw/_-d! token generate success token=MTYyODgxNjYyOC4zMzg0MzU0OjUwNzQwM2Q2LWZiZDItMTFlYi05ZmMyLTAyNDJhYzE
  09:03:48.939 [dbservice2] INFO 50df9a92-fbd2-11eb-a680-0242ac110003-mgvTPLKy-UE!Q+o#:Kz9% token generate success token=MTYyODgxNjYyOC45Mzg2NDIzOjUwZGY5YTkyLWZiZDItMTFlYi1hNjgwLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  09:03:21.356 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×41)
  09:03:21.530 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×41)
  09:03:21.708 [mobservice2] INFO info 40c851ee-fbd2-11eb-84e6-0242ac110004:URMboZjf write success
  09:03:21.765 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '40c851ee-fbd2-11eb-84e6-0242ac110004', 'user_id': 'URMboZjf'}  (×82)
  09:03:21.937 [dbservice1] INFO query = select passwards from username_table where user_name='URMboZjf'  (×38)
  09:03:22.355 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×36)
  09:03:22.462 [mobservice1] INFO info 4138fab6-fbd2-11eb-9d51-0242ac110004:yZPEbHDA write success
  09:03:22.698 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×47)
  09:03:22.923 [dbservice2] INFO 4138fab6-fbd2-11eb-9d51-0242ac110004-yZPEbHDA-w_sWfyK+X01Y token generate success token=MTYyODgxNjYwMi45MjI4MTQ2OjQxMzhmYWI2LWZiZDItMTFlYi05ZDUxLTAyNDJhYzE  (×2)
  09:03:25.070 [mobservice2] INFO info 42bdff1c-fbd2-11eb-bf50-0242ac110003:rsGCqSOE write success
  09:03:26.627 [mobservice1] INFO info 43b257c4-fbd2-11eb-bca9-0242ac110003:zfawCciR write success
  09:03:28.726 [dbservice2] INFO 44c03bc2-fbd2-11eb-81df-0242ac110004-hTjCBtGX-eJrbTQXfMu<_ token generate success token=MTYyODgxNjYwOC43MjU5NTU6NDRjMDNiYzItZmJkMi0xMWViLTgxZGYtMDI0MmFjMTE
  09:03:31.115 [mobservice1] INFO info 466ce89e-fbd2-11eb-9cc5-0242ac110004:yAHjfLsg write success
  09:03:33.476 [dbservice1] INFO 478d14f6-fbd2-11eb-95ea-0242ac110003-ToeLCkHR-(_n2MJ%R.Uw0 token generate success token=MTYyODgxNjYxMy40NzYxMDI2OjQ3OGQxNGY2LWZiZDItMTFlYi05NWVhLTAyNDJhYzE
  09:03:39.638 [mobservice2] INFO info 4b6bf0e2-fbd2-11eb-a1e4-0242ac110003:ySjkNPYT write success
  09:03:45.540 [dbservice2] INFO 4ec932a4-fbd2-11eb-b698-0242ac110004-sSHyNrVB-$=dDovf1IJC# token generate success token=MTYyODgxNjYyNS41Mzk5MTU6NGVjOTMyYTQtZmJkMi0xMWViLWI2OTgtMDI0MmFjMTE
  09:03:48.040 [mobservice1] INFO info 507403d6-fbd2-11eb-9fc2-0242ac110003:FfCPbjsD write success
  09:03:50.115 [mobservice2] INFO info 51b84edc-fbd2-11eb-90d1-0242ac110004:IREbBVhM write success
  09:03:52.555 [mobservice2] INFO info 531efe7e-fbd2-11eb-b395-0242ac110004:HkuCdjLo write success
  09:03:54.339 [dbservice1] INFO 540b718c-fbd2-11eb-bf96-0242ac110004-ckfeNPTM-WcHR.sT#4DEu token generate success token=MTYyODgxNjYzNC4zMzg4MDk1OjU0MGI3MThjLWZiZDItMTFlYi1iZjk2LTAyNDJhYzE
  09:03:56.972 [dbservice2] INFO 5581c5de-fbd2-11eb-8dfe-0242ac110003-TMBcRIPk-t>ebO}qX)ah8 token generate success token=MTYyODgxNjYzNi45NzIyMDY2OjU1ODFjNWRlLWZiZDItMTFlYi04ZGZlLTAyNDJhYzE
  09:04:00.577 [dbservice1] INFO 57a05ca4-fbd2-11eb-b782-0242ac110004-nlMAOLaH-.+x$_%GPZ*lV token generate success token=MTYyODgxNjY0MC41NzcxMDM5OjU3YTA1Y2E0LWZiZDItMTFlYi1iNzgyLTAyNDJhYzE
  09:04:02.735 [dbservice1] INFO 58f80ebc-fbd2-11eb-a7ed-0242ac110003-ODxjMiJU-a8j<f^QX)sES token generate success token=MTYyODgxNjY0Mi43MzUwMTE4OjU4ZjgwZWJjLWZiZDItMTFlYi1hN2VkLTAyNDJhYzE
  09:04:05.354 [dbservice1] INFO 5a8f49b6-fbd2-11eb-b4ad-0242ac110003-hTjCBtGX-eJrbTQXfMu<_ token generate success token=MTYyODgxNjY0NS4zNTM3ODAzOjVhOGY0OWI2LWZiZDItMTFlYi1iNGFkLTAyNDJhYzE
  09:04:07.913 [dbservice1] INFO 5c179ff4-fbd2-11eb-8932-0242ac110004-ZPMYDESe-rfv@?Vc+0&Tm token generate success token=MTYyODgxNjY0Ny45MTI3OTA1OjVjMTc5ZmY0LWZiZDItMTFlYi04OTMyLTAyNDJhYzE
  09:04:10.689 [mobservice2] INFO info 5dec77f0-fbd2-11eb-911d-0242ac110003:cCODHfIu write success
  09:04:12.649 [dbservice2] INFO 5eea622a-fbd2-11eb-85f1-0242ac110003-AdPXowjJ-4>$2wY*8ErhR token generate success token=MTYyODgxNjY1Mi42NDkwNjI5OjVlZWE2MjJhLWZiZDItMTFlYi04NWYxLTAyNDJhYzE
  09:04:14.725 [mobservice2] INFO info 605a41a2-fbd2-11eb-8bd1-0242ac110004:OiYedVug write success
  09:04:17.442 [mobservice2] INFO info 61f064f6-fbd2-11eb-9e33-0242ac110003:nulqIiBE write success
  09:04:19.764 [dbservice1] INFO 631bf99e-fbd2-11eb-b43b-0242ac110004-gZxMbovT-6)_=b$i/Ye}A token generate success token=MTYyODgxNjY1OS43NjQwNDEyOjYzMWJmOTllLWZiZDItMTFlYi1iNDNiLTAyNDJhYzE

## p0821
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-admin-travel-service, 2024-12-10T13:27:47.428Z
```
{"timestamp":1733837267428228000,"container_name":"ts-admin-travel-service","pod_name":"ts-admin-travel-service-5c866595d6-bscdc","node_name":"ip-192-168-51-182.ap-southeast-2.compute.internal","message":"2024-12-10 13:27:47.427 ERROR 1 --- [io-16114-exec-7] edu.fudan.common.security.jwt.JWTUtil    : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwtException: JWT strings must contain exactly 2 period characters. Found: 0"}
```
Same service, the 2 minutes before (oldest first):
  13:27:06.326 [ts-admin-travel-service] 2024-12-10 13:27:06.325 ERROR 1 --- [io-16114-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×6)
  13:27:06.326 [ts-admin-travel-service] edu.fudan.common.exception.TokenException: Token is not properly constructed at edu.fudan.common.security.jwt.JWTUtil.validateToken(JWTUtil.java:109) ~[ts-commo  (×7)
  13:27:10.732 [ts-admin-travel-service] 2024-12-10 13:27:10.732 ERROR 1 --- [io-16114-exec-7] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×5)
  13:27:29.527 [ts-admin-travel-service] 2024-12-10 13:27:29.526 ERROR 1 --- [o-16114-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  13:27:29.527 [ts-admin-travel-service] 2024-12-10 13:27:29.527 ERROR 1 --- [o-16114-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
All services, 30 seconds either side (sampled):
  13:27:17.837 [ts-auth-service] 2024-12-10 13:27:17.837 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×11)
  13:27:18.015 [ts-auth-service] 2024-12-10 13:27:18.015 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : 763cdad2-044b-466f-a5dc-11dbb90b599a USER ID  (×22)
  13:27:18.031 [ts-admin-travel-service] 2024-12-10 13:27:18.031 ERROR 1 --- [io-16114-exec-5] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×12)
  13:27:19.754 [ts-admin-basic-info-service] 2024-12-10 13:27:19.754 ERROR 1 --- [io-18767-exec-8] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×20)
  13:27:19.757 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:19 +0800] "GET /api/v1/adminbasicservice/adminbasic/configs HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15  (×12)
  13:27:20.714 [ts-auth-service] 2024-12-10 13:27:20.714 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×4)
  13:27:20.730 [ts-travel2-service] 2024-12-10 13:27:20.730 ERROR 1 --- [io-16346-exec-8] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×13)
  13:27:21.040 [ts-admin-basic-info-service] 2024-12-10 13:27:21.040 ERROR 1 --- [o-18767-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×3)
  13:27:21.117 [ts-auth-service] 2024-12-10 13:27:21.116 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null  (×11)
  13:27:21.744 [ts-order-service] 2024-12-10 13:27:21.743 ERROR 1 --- [io-12031-exec-8] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with 
  13:27:24.348 [ts-food-service] 2024-12-10 13:27:24.347 ERROR 1 --- [io-18856-exec-4] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×3)
  13:27:24.352 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:24 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 500 259 "-" "Mozilla/5.0 (Macintosh;   (×3)
  13:27:41.459 [ts-travel-service] 2024-12-10 13:27:41.458 ERROR 1 --- [io-12346-exec-1] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×2)
  13:27:41.462 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:27:41 +0800] "POST /api/v1/travelservice/trips/left HTTP/1.1" 500 227 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWe  (×2)
  13:28:11.545 [ts-order-other-service] 2024-12-10 13:28:11.545 ERROR 1 --- [io-12032-exec-4] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt
  13:28:11.550 [ts-ui-dashboard] 127.0.0.1 - - [10/Dec/2024:21:28:11 +0800] "POST /api/v1/orderOtherService/orderOther/refresh HTTP/1.1" 500 239 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_1
  13:28:11.989 [ts-station-mongo] {"t":{"$date":"2024-12-10T13:28:11.989+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383729
  13:28:12.333 [ts-consign-price-mongo] {"t":{"$date":"2024-12-10T13:28:12.332+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383729
  13:28:12.657 [ts-ticket-office-mongo] {"t":{"$date":"2024-12-10T13:28:12.657+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383729
  13:28:12.829 [ts-notification-mongo] {"t":{"$date":"2024-12-10T13:28:12.828+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383729
  13:28:13.336 [ts-security-mongo] {"t":{"$date":"2024-12-10T13:28:13.336+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383729
  13:28:13.356 [ts-price-mongo] {"t":{"$date":"2024-12-10T13:28:13.356+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383729
  13:28:15.055 [ts-inside-payment-mongo] {"t":{"$date":"2024-12-10T13:28:15.055+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383729
  13:28:15.222 [ts-consign-mongo] {"t":{"$date":"2024-12-10T13:28:15.222+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173383729

## p0284
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:33:39.292Z
```
{"timestamp":1732242819292471000,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Attempting to delete cart for user: 673fed7db0df5c00019afd3f"}
```
Same service, the 2 minutes before (oldest first):
  02:33:39.033 [front-end] Posting Customer: {"username":"ULDviaMi","password":"SQCAZHz","email":"ULDviaMi@gmail.com","firstName":"ULDviaMi","lastName":"ULDviaMi"}
  02:33:39.040 [front-end] { id: '673fed83b0df5c00019afd4e' }  (×2)
  02:33:39.040 [front-end] 673fed83b0df5c00019afd4e  (×2)
  02:33:39.040 [front-end] Merging carts for customer id: 673fed83b0df5c00019afd4e and session id: KkZrOzNoqKgxA2YV9xemsYfowSvZTYBW  (×2)
  02:33:39.059 [front-end] Carts merged.  (×2)
  02:33:39.059 [front-end] set cookie673fed83b0df5c00019afd4e  (×2)
  02:33:39.060 [front-end] Sent cookies.  (×2)
  02:33:39.062 [front-end] POST /register 200 26.435 ms - 33  (×2)
  02:33:39.071 [front-end] Posting Customer: {"username":"mPiPBPdqdRzMvA","password":"KFJSFXzv","email":"mPiPBPdqdRzMvA@gmail.com","firstName":"mPiPBPdqdRzMvA","lastName":"mPiPBPdqdRzMvA"
  02:33:39.225 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fed7db0df5c00019afd3f"}
  02:33:39.234 [front-end] POST /addresses 200 - ms - -
  02:33:39.239 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fed7db0df5c00019afd3f"}
  02:33:39.247 [front-end] POST /cards 200 - ms - -
All services, 30 seconds either side (sampled):
  02:33:09.516 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fed5eb0df5c00019afcdd"}  (×62)
  02:33:09.641 [carts] 2024-11-22 02:33:09.641 INFO [carts,ff238918cef29a75,bb728b7310c7ba23,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.ItemsController : Did not find item.  (×37)
  02:33:09.921 [user] ts=2024-11-22T02:33:09.921678538Z caller=middlewares.go:134 method=GetCards id=673fed55b0df5c00019afcbe result=1 took=1.066595ms  (×36)
  02:33:10.175 [carts] 2024-11-22 02:33:10.175 INFO [carts,9e72de1c7dd3bd76,848e1abafd4d89ec,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.ItemsController : Did not find item.  (×25)
  02:33:11.777 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed67d94b9000069b3ad5","customerId":"673fed53b0df5c00019afcb5","customer":{"id":null,"firstName":"mHDgAKduxrE
  02:33:11.989 [front-end] POST /register 200 20.379 ms - 33  (×55)
  02:33:12.803 [user] ts=2024-11-22T02:33:12.803150577Z caller=middlewares.go:46 method=Register username=abGZf email=abGZf@gmail.com took=995.315µs
  02:33:14.190 [catalogue] ts=2024-11-22T02:33:14Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=4.70433m  (×5)
  02:33:16.210 [payment] ts=2024-11-22T02:33:16Z caller=logging.go:29 method=Authorise result=false took=6.901µs  (×6)
  02:33:17.917 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed6dd94b9000069b3adf","customerId":"673fed59b0df5c00019afcca","customer":{"id":null,"firstName":"WokLCvgJysz
  02:33:19.496 [front-end] Received response: "{\"firstName\":\"NkSsDjCQNkRnKiz\",\"lastName\":\"NkSsDjCQNkRnKiz\",\"username\":\"NkSsDjCQNkRnKiz\",\"id\":\"673fed5db0df5c00019afcd5\",\"_
  02:33:21.209 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed71d94b9000069b3ae5","customerId":"673fed5fb0df5c00019afcde","customer":{"id":null,"firstName":"nRfKsNsnFHg
  02:33:24.020 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed74d94b9000069b3ae8","customerId":"673fed60b0df5c00019afce4","customer":{"id":null,"firstName":"fbngm","las
  02:33:26.787 [user] ts=2024-11-22T02:33:26.787709569Z caller=middlewares.go:46 method=Register username=BnbbQji email=BnbbQji@gmail.com took=1.029252ms
  02:33:30.323 [front-end] Order response: {"id":"673fed7ad94b9000069b3aed","customerId":"673fed64b0df5c00019afcf2","customer":{"id":null,"firstName":"pWEkDvwMEXAtMq","lastName":"pWEkDvwM
  02:33:32.200 [front-end] Posting Customer: {"username":"KoqWcP","password":"fccRMxa","email":"KoqWcP@gmail.com","firstName":"KoqWcP","lastName":"KoqWcP"}
  02:33:34.164 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed7ed94b9000069b3af3","customerId":"673fed69b0df5c00019afd06","customer":{"id":null,"firstName":"geLOLRZuTes
  02:33:37.815 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed81d94b9000069b3af6","customerId":"673fed72b0df5c00019afd25","customer":{"id":null,"firstName":"VqiVbr","la
  02:33:41.722 [user] ts=2024-11-22T02:33:41.721970749Z caller=middlewares.go:46 method=Register username=HFlyxx email=HFlyxx@gmail.com took=1.098045ms
  02:33:44.213 [front-end] Order response: {"id":"673fed88d94b9000069b3af8","customerId":"673fed76b0df5c00019afd2c","customer":{"id":null,"firstName":"BnbbQji","lastName":"BnbbQji","usern
  02:33:46.811 [front-end] Order response: {"id":"673fed8ad94b9000069b3afa","customerId":"673fed7ab0df5c00019afd36","customer":{"id":null,"firstName":"wccSoJGxedaBYzQ","lastName":"wccSoJG
  02:33:49.503 [front-end] Order response: {"id":"673fed8dd94b9000069b3afd","customerId":"673fed7cb0df5c00019afd3c","customer":{"id":null,"firstName":"KoqWcP","lastName":"KoqWcP","usernam
  02:33:52.146 [front-end] Posting Customer: {"username":"zChpPcvAuCjkHis","password":"IcSNuwSXm","email":"zChpPcvAuCjkHis@gmail.com","firstName":"zChpPcvAuCjkHis","lastName":"zChpPcvAuCj
  02:33:56.244 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed94d94b9000069b3b03","customerId":"673fed85b0df5c00019afd5a","customer":{"id":null,"firstName":"MrneIKw","l
  02:33:59.466 [front-end] Received response: "{\"firstName\":\"yuluEqyUJABv\",\"lastName\":\"yuluEqyUJABv\",\"username\":\"yuluEqyUJABv\",\"id\":\"673fed86b0df5c00019afd5e\",\"_links\":{
  02:34:01.715 [front-end] Order response: {"statusCode":201,"body":{"id":"673fed99d94b9000069b3b08","customerId":"673fed83b0df5c00019afd52","customer":{"id":null,"firstName":"tiZilkkvzQW
  02:34:04.941 [front-end] Received response: "{\"firstName\":\"HFlyxx\",\"lastName\":\"HFlyxx\",\"username\":\"HFlyxx\",\"id\":\"673fed85b0df5c00019afd5c\",\"_links\":{\"addresses\":{\"h
  02:34:07.115 [front-end] Order response: {"id":"673fed9fd94b9000069b3b0f","customerId":"673fed8eb0df5c00019afd75","customer":{"id":null,"firstName":"NlbqBUAHbYoCKV","lastName":"NlbqBUAH

## p0482
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-23T08:57:00.758Z
```
{"timestamp":1732352220758396400,"container_name":"front-end","pod_name":"front-end-f77549869-lq8xh","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"Request received with body: {}"}
```
Same service, the 2 minutes before (oldest first):
  08:56:59.331 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"674198d3a437380001deff98"}
  08:56:59.343 [front-end] POST /addresses 200 - ms - -
  08:56:59.388 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674198d3a437380001deff98"}
  08:56:59.401 [front-end] POST /cards 200 - ms - -
  08:56:59.448 [front-end] Attempting to delete cart for user: 674198d3a437380001deff98
  08:56:59.468 [front-end] User cart deleted with status: 202
  08:56:59.469 [front-end] DELETE /cart 202 - ms - -
  08:56:59.474 [front-end] Attempting to add to cart: {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","quantity":1}
  08:56:59.484 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla
  08:56:59.485 [front-end] POST to carts: http://carts/carts/674198d3a437380001deff98/items body: {"itemId":"zzz4f044-b040-410d-8ead-4de0446aec7e","unitPrice":12}
  08:56:59.524 [front-end] POST /cart 201 - ms - -
  08:57:00.540 [front-end] GET /catalogue 200 - ms - -
  08:57:00.720 [front-end] Request received with body: {}
  08:57:00.731 [front-end] Received response: "{\"firstName\":\"nuXAdkfqQQTG\",\"lastName\":\"nuXAdkfqQQTG\",\"username\":\"nuXAdkfqQQTG\",\"id\":\"674198caa437380001deff7c\",\"_links\":{
  08:57:00.731 [front-end] GET Request to: http://user/customers/674198caa437380001deff7c/addresses  (×2)
  08:57:00.742 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"674198d0a437380001deff91\",\"_links\":{\"
  08:57:00.743 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"67419
  08:57:00.744 [front-end] [ undefined, undefined ]
  08:57:00.744 [front-end] Posting Order: {"customer":"http://user/customers/674198caa437380001deff7c","address":"http://user/addresses/674198d0a437380001deff90","card":"http://user/cards
All services, 30 seconds either side (sampled):
  08:56:58.007 [catalogue] ts=2024-11-23T08:56:58Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.869902ms  (×36)
  08:56:58.018 [orders] 2024-11-23 08:56:58.018 INFO [orders,6baef7816fdf67ff,4dc9cbe9bd6cff45,false] 8 --- [p-nio-80-exec-6] w.w.s.o.controllers.OrdersController : Received payment re  (×25)
  08:56:58.029 [front-end] Order response: {"statusCode":201,"body":{"id":"674198da3f77060008865384","customerId":"674198bfa437380001deff45","customer":{"id":null,"firstName":"ztfESzW","l
  08:56:59.388 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"674198d3a437380001deff98"}  (×29)
  08:56:59.483 [catalogue] ts=2024-11-23T08:56:59Z caller=logging.go:62 method=Get id=zzz4f044-b040-410d-8ead-4de0446aec7e sock=zzz4f044-b040-410d-8ead-4de0446aec7e err=null took=3.990138  (×27)
  08:57:00.720 [front-end] Request received with body: {}  (×25)
  08:57:00.744 [front-end] Posting Order: {"customer":"http://user/customers/674198caa437380001deff7c","address":"http://user/addresses/674198d0a437380001deff90","card":"http://user/cards  (×26)
  08:57:01.048 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca  (×5)
  08:57:01.165 [front-end] 674198dda437380001deffa9  (×33)
  08:57:02.787 [front-end] Received response: "{\"firstName\":\"iEYCUjoH\",\"lastName\":\"iEYCUjoH\",\"username\":\"iEYCUjoH\",\"id\":\"674198c5a437380001deff67\",\"_links\":{\"addresses\
  08:57:03.057 [front-end] Order response: {"statusCode":201,"body":{"id":"674198df3f77060008865387","customerId":"674198caa437380001deff7e","customer":{"id":null,"firstName":"qzkCXXFW","
  08:57:04.140 [front-end] Received response: "{\"firstName\":\"TlHaLWqJVqW\",\"lastName\":\"TlHaLWqJVqW\",\"username\":\"TlHaLWqJVqW\",\"id\":\"674198d0a437380001deff92\",\"_links\":{\"a
  08:57:05.392 [orders] 2024-11-23 08:57:05.392 INFO [orders,3c526066b205402a,acb1c0fc61191c83,false] 8 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×2)
  08:57:07.035 [front-end] Order response: {"statusCode":201,"body":{"id":"674198e33f7706000886538a","customerId":"674198caa437380001deff7d","customer":{"id":null,"firstName":"vidoaLMiMZn
  08:57:08.980 [queue-master] 2024-11-23 08:57:08.980 INFO 7 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×48)
  08:57:09.152 [front-end] Order response: {"id":"674198e53f7706000886538c","customerId":"674198d2a437380001deff95","customer":{"id":null,"firstName":"zUGYrCgol","lastName":"zUGYrCgol","u
  08:57:11.533 [front-end] {"id":"819e1fbf-8b7e-4f6d-811f-693534916a8b","name":"Figueroa","description":"enim officia aliqua excepteur esse deserunt quis aliquip nostrud anim","imageUrl":  (×6)
  08:57:13.005 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  08:57:14.121 [front-end] Posting Customer: {"username":"JCYeKSjM","password":"MYIoBCiY","email":"JCYeKSjM@gmail.com","firstName":"JCYeKSjM","lastName":"JCYeKSjM"}
  08:57:15.678 [front-end] Order response: {"id":"674198eb3f7706000886538f","customerId":"674198cfa437380001deff8c","customer":{"id":null,"firstName":"FygEtnQmntW","lastName":"FygEtnQmntW
  08:57:18.424 [user] ts=2024-11-23T08:57:18.424838811Z caller=middlewares.go:46 method=Register username=bqLFOFtK email=bqLFOFtK@gmail.com took=2.548455ms
  08:57:19.305 [front-end] Received response: "{\"firstName\":\"aXWRmKRnN\",\"lastName\":\"aXWRmKRnN\",\"username\":\"aXWRmKRnN\",\"id\":\"674198d9a437380001deffa4\",\"_links\":{\"address
  08:57:22.096 [front-end] Posting Customer: {"username":"ErqkMC","password":"qwrMe","email":"ErqkMC@gmail.com","firstName":"ErqkMC","lastName":"ErqkMC"}
  08:57:24.110 [front-end] Order response: {"id":"674198f43f77060008865392","customerId":"674198dfa437380001deffad","customer":{"id":null,"firstName":"wqgJPHku","lastName":"wqgJPHku","use
  08:57:25.404 [front-end] Order response: {"id":"674198f53f77060008865393","customerId":"674198e2a437380001deffb0","customer":{"id":null,"firstName":"tVFCKe","lastName":"tVFCKe","usernam
  08:57:26.581 [front-end] Received response: "{\"firstName\":\"aQTVfKPpOQTV\",\"lastName\":\"aQTVfKPpOQTV\",\"username\":\"aQTVfKPpOQTV\",\"id\":\"674198e5a437380001deffb4\",\"_links\":{
  08:57:27.415 [front-end] Order response: {"statusCode":201,"body":{"id":"674198f73f77060008865398","customerId":"674198dda437380001deffa9","customer":{"id":null,"firstName":"eWMmgZPhWLI
  08:57:30.058 [front-end] Order response: {"id":"674198fa3f77060008865399","customerId":"674198e7a437380001deffbe","customer":{"id":null,"firstName":"bVfUCqC","lastName":"bVfUCqC","usern

## p0121
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:17:47.762Z
```
{"timestamp":1731907067762986800,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"failed to retrieve ads"}
```
Same service, the 2 minutes before (oldest first):
  05:17:46.146 [frontend] request complete  (×5)
  05:17:46.383 [frontend] request started  (×5)
  05:17:46.383 [frontend] serving product page  (×2)
  05:17:46.416 [frontend] span hipstershop.AdService/GetAds failed with gRPC status 14  (×2)
  05:17:46.419 [frontend] failed to retrieve ads  (×2)
  05:17:46.791 [frontend] home
  05:17:46.839 [frontend] ENV_PLATFORM is: aws
  05:17:46.843 [frontend] view user cart  (×2)
All services, 30 seconds either side (sampled):
  05:17:18.102 [frontend] request started  (×266)
  05:17:18.108 [cartservice] GetCartAsync called with userId=cc66be0e-8e02-45b2-add1-49cd8f1b4b03  (×228)
  05:17:18.128 [shippingservice] [GetQuote] completed request  (×72)
  05:17:19.396 [frontend] serving product page  (×125)
  05:17:20.133 [frontend] ENV_PLATFORM is: aws  (×29)
  05:17:21.520 [adservice] received ad request (context_words=[accessories])  (×7)
  05:17:21.673 [cartservice] AddItemAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53, productId=2ZYFJ3GM2N, quantity=5  (×22)
  05:17:24.086 [frontend] placing order  (×5)
  05:17:24.111 [paymentservice] Transaction processed: visa ending 1703 Amount: CAD346.438559926  (×2)
  05:17:24.116 [shippingservice] [ShipOrder] completed request  (×5)
  05:17:24.126 [checkoutservice] order confirmation email sent to "adamholder@example.org"
  05:17:25.111 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"TRY","units":"1234","nanos":366782847},"credit_card":{"credit_card_number":"4248456254034  (×2)
  05:17:25.127 [checkoutservice] order confirmation email sent to "coxchristine@example.net"
  05:17:31.653 [adservice] received ad request (context_words=[clothing, tops])  (×4)
  05:17:40.213 [adservice] *** server shut down
  05:17:43.747 [adservice] AdService starting.  (×2)
  05:17:43.841 [adservice] See https://github.com/GoogleCloudPlatform/microservices-demo/issues/422 for more info.  (×2)
  05:17:45.450 [adservice] Caused by: java.net.BindException: Address in use at java.base/sun.nio.ch.Net.bind0(Native Method) at java.base/sun.nio.ch.Net.bind(Unknown Source) at java.base  (×2)
  05:17:55.239 [checkoutservice] [PlaceOrder] user_id="cc66be0e-8e02-45b2-add1-49cd8f1b4b03" user_currency="EUR"
  05:17:55.276 [emailservice] A request to send order confirmation email to alopez@example.org has been received.
  05:18:02.298 [checkoutservice] order confirmation email sent to "caseyhoward@example.com"

## p0076
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service logservice2, 2021-08-13T11:02:47.504Z
```
{"service":"logservice2","message":"2021-08-13 11:02:47,504 | INFO | 0.0.0.2 | 172.17.0.3 | logservice2 | 53fd9e6fbacbe229 | the list of all available services are logservice1: http://0.0.0.3:9384"}
```
Same service, the 2 minutes before (oldest first):
  11:02:42.265 [logservice2] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×6)
  11:02:42.265 [logservice2] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': 'ecbf9024-fbe2-11eb-8c5f-0242ac110003', 'user_id': 'FNabDRjg'}  (×6)
  11:02:43.161 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×5)
  11:02:47.457 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387
  11:02:47.458 [logservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service
  11:02:47.458 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'efe85db2-fbe2-11eb-8dca-0242ac110004'}
All services, 30 seconds either side (sampled):
  11:02:17.568 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'de11b4e4-fbe2-11eb-915f-0242ac110003', 'value': 'AMFryZUz'}  (×39)
  11:02:17.710 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×40)
  11:02:17.843 [logservice1] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': 'de11b4e4-fbe2-11eb-915f-0242ac110003', 'user_id': 'AMFryZUz'}  (×80)
  11:02:18.254 [webservice1] INFO uuid: dea868da-fbe2-11eb-9422-0242ac110003 write redis successfully  (×42)
  11:02:18.465 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×45)
  11:02:18.812 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×39)
  11:02:19.190 [webservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×39)
  11:02:19.429 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×34)
  11:02:19.652 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×40)
  11:02:21.493 [mobservice2] INFO info e06cb090-fbe2-11eb-924d-0242ac110003:ZadRMLrA write success
  11:02:23.771 [dbservice2] INFO e1778f1e-fbe2-11eb-b894-0242ac110004-VkYhsQXg-wW@U3A6^R4)_ token generate success token=MTYyODgyMzc0My43NzA5ODY4OmUxNzc4ZjFlLWZiZTItMTFlYi1iODk0LTAyNDJhYzE
  11:02:26.699 [mobservice2] INFO info e38f5048-fbe2-11eb-ae4d-0242ac110003:SxlGNrtW write success
  11:02:28.890 [dbservice2] INFO e492086e-fbe2-11eb-8594-0242ac110003-FCehRaxD-e:mpjQI*cKli token generate success token=MTYyODgyMzc0OC44ODk4NDUxOmU0OTIwODZlLWZiZTItMTFlYi04NTk0LTAyNDJhYzE
  11:02:31.818 [dbservice1] INFO e65473c6-fbe2-11eb-ad3d-0242ac110003-EJMXPwRO-D/+vO)A*gblM token generate success token=MTYyODgyMzc1MS44MTgzNDY1OmU2NTQ3M2M2LWZiZTItMTFlYi1hZDNkLTAyNDJhYzE
  11:02:34.781 [dbservice1] INFO e8183148-fbe2-11eb-a3c9-0242ac110004-UfMpdlBq-fL(<c!OYDx@^ token generate success token=MTYyODgyMzc1NC43ODAxODE2OmU4MTgzMTQ4LWZiZTItMTFlYi1hM2M5LTAyNDJhYzE
  11:02:37.371 [dbservice1] INFO e9ab1ad4-fbe2-11eb-b293-0242ac110004-KvxBQDHV-N^C_Y{W4r5#y token generate success token=MTYyODgyMzc1Ny4zNzA4MDY3OmU5YWIxYWQ0LWZiZTItMTFlYi1iMjkzLTAyNDJhYzE  (×2)
  11:02:41.270 [mobservice2] INFO info ec41fa10-fbe2-11eb-a9b4-0242ac110004:wkgeEpUD write success
  11:02:45.514 [mobservice2] INFO info eec82890-fbe2-11eb-88ef-0242ac110003:QYryCKLk write success
  11:02:48.326 [mobservice1] INFO info f0673da8-fbe2-11eb-9151-0242ac110003:KXtHNvbZ write success
  11:02:51.005 [mobservice2] INFO info f1ed5e3c-fbe2-11eb-be01-0242ac110003:KvxBQDHV write success
  11:02:54.525 [mobservice2] INFO info f416ff6a-fbe2-11eb-8fbf-0242ac110004:HfPCXKQO write success
  11:02:57.310 [mobservice2] INFO info f5cb4d8e-fbe2-11eb-9155-0242ac110003:NPtZUmhc write success
  11:03:00.234 [mobservice2] INFO info f78677e8-fbe2-11eb-9114-0242ac110004:GNqpIFum write success
  11:03:02.245 [dbservice2] INFO f89cce3e-fbe2-11eb-97d8-0242ac110004-YaLWCkue-xv)&z?wb>HN+ token generate success token=MTYyODgyMzc4Mi4yNDUyNjQ1OmY4OWNjZTNlLWZiZTItMTFlYi05N2Q4LTAyNDJhYzE
  11:03:04.266 [mobservice1] INFO info f9f46f08-fbe2-11eb-8925-0242ac110004:SjMAKXaq write success
  11:03:06.219 [dbservice2] INFO fae43c7c-fbe2-11eb-aa2e-0242ac110003-SUYGNuEo-GUX9z)qOC/KL token generate success token=MTYyODgyMzc4Ni4yMTg5NzU4OmZhZTQzYzdjLWZiZTItMTFlYi1hYTJlLTAyNDJhYzE
  11:03:08.717 [mobservice2] INFO info fc980846-fbe2-11eb-87f0-0242ac110004:Bmsjcfbe write success
  11:03:11.136 [dbservice1] INFO fdc47394-fbe2-11eb-98b8-0242ac110003-mHwMQugd-6@1g+F.Th7c& token generate success token=MTYyODgyMzc5MS4xMzY1MTM3OmZkYzQ3Mzk0LWZiZTItMTFlYi05OGI4LTAyNDJhYzE
  11:03:13.364 [mobservice2] INFO info ff5de7da-fbe2-11eb-aada-0242ac110003:ycKvOJwP write success
  11:03:15.718 [webservice2] ERROR an error occurred in the downstream service

## p0054
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T08:30:38.316Z
```
{"service":"dbservice2","message":"2021-08-13 08:30:38,316 | ERROR | 0.0.0.2 | dbservice2 | permission_operate.py -> permission_operation -> 81 | 35a62efa392a1b5a | service refuse"}
```
Same service, the 2 minutes before (oldest first):
  08:30:33.460 [dbservice2] ERROR service refuse  (×5)
  08:30:33.460 [dbservice2] ERROR dbservice2 access redis service denied  (×5)
  08:30:34.706 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:30:34.706 [dbservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
All services, 30 seconds either side (sampled):
  08:30:08.324 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×36)
  08:30:08.370 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×31)
  08:30:08.590 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×37)
  08:30:08.638 [logservice1] INFO request http://0.0.0.2:9385/login_model_implement and param={'uuid': '9cb339ec-fbcd-11eb-ab09-0242ac110003', 'user_id': 'NFBuWbaS'}  (×76)
  08:30:08.733 [webservice1] ERROR an error occurred in the downstream service  (×21)
  08:30:08.959 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×38)
  08:30:10.869 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '9e35def0-fbcd-11eb-97c1-0242ac110003', 'value': 'aCdZXfNn'}  (×39)
  08:30:13.592 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '9fdbc418-fbcd-11eb-9577-0242ac110003'}  (×38)
  08:30:13.819 [logservice2] INFO now call service:logservice1, inst:http://0.0.0.3:9384 as a downstream service  (×41)
  08:30:18.803 [webservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×39)
  08:30:18.961 [webservice2] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×39)
  08:30:20.195 [logservice1] ERROR uuid expired, invalid phone request
  08:30:21.820 [mobservice2] INFO info a4b6adea-fbcd-11eb-84f2-0242ac110003:APxbpyWu write success
  08:30:23.578 [mobservice1] INFO info a5c43dd8-fbcd-11eb-a4ef-0242ac110004:rDnqUwke write success  (×2)
  08:30:25.581 [mobservice2] INFO info a6f876ce-fbcd-11eb-8f46-0242ac110004:WYMpZilL write success
  08:30:27.685 [dbservice1] INFO a7f1b856-fbcd-11eb-895a-0242ac110003-tBueHCAS-:8Y<_S=dT!{e token generate success token=MTYyODgxNDYyNy42ODQ4MDU2OmE3ZjFiODU2LWZiY2QtMTFlYi04OTVhLTAyNDJhYzE
  08:30:30.217 [mobservice1] INFO info a9ad0506-fbcd-11eb-b5cd-0242ac110004:kmPegpXw write success
  08:30:33.284 [dbservice1] INFO ab45527e-fbcd-11eb-9129-0242ac110004-TzNJoquC-HD=#x)&^AZ14 token generate success token=MTYyODgxNDYzMy4yODQzMzA4OmFiNDU1MjdlLWZiY2QtMTFlYi05MTI5LTAyNDJhYzE
  08:30:35.872 [mobservice1] INFO info ad116f02-fbcd-11eb-923f-0242ac110004:NrfVcbxl write success
  08:30:38.866 [mobservice2] INFO info aecd4df2-fbcd-11eb-b2d5-0242ac110003:AkMRXwoH write success
  08:30:41.943 [dbservice1] INFO b0787082-fbcd-11eb-9ed1-0242ac110004-TFaxVQiG-bQrY_.{J3<U+ token generate success token=MTYyODgxNDY0MS45NDMyNzgzOmIwNzg3MDgyLWZiY2QtMTFlYi05ZWQxLTAyNDJhYzE
  08:30:44.561 [mobservice1] INFO info b237d8b8-fbcd-11eb-ae6c-0242ac110003:HkuCdjLo write success
  08:30:47.277 [dbservice1] INFO b3a75818-fbcd-11eb-b48e-0242ac110003-Egncqoka-7hZP8@jvo*H} token generate success token=MTYyODgxNDY0Ny4yNzc1OTYyOmIzYTc1ODE4LWZiY2QtMTFlYi1iNDhlLTAyNDJhYzE
  08:30:49.694 [dbservice1] INFO b4ff989c-fbcd-11eb-a324-0242ac110004-rxiVPwZL-#kN4x}e6EY-J token generate success token=MTYyODgxNDY0OS42OTM2MzU3OmI0ZmY5ODljLWZiY2QtMTFlYi1hMzI0LTAyNDJhYzE
  08:30:51.772 [mobservice2] INFO info b68f7bfa-fbcd-11eb-91ee-0242ac110004:cwpAkUMO write success
  08:30:58.413 [mobservice2] INFO info ba84b2ac-fbcd-11eb-862c-0242ac110004:qhdLCnSU write success
  08:31:00.963 [mobservice2] INFO info bbff90c0-fbcd-11eb-a5e2-0242ac110003:IcmKxDtR write success
  08:31:03.467 [mobservice1] INFO info bd78aec8-fbcd-11eb-90ed-0242ac110004:HYsctkhi write success
  08:31:05.960 [mobservice1] INFO info bef2caa4-fbcd-11eb-8722-0242ac110004:RhZNdLGi write success
  08:31:07.922 [dbservice1] ERROR (pymysql.err.ProgrammingError) (1146, "Table 'cloudwise_micross.system_metric_datas' doesn't exist")[SQL: select service_names, system_data_time, system_c

## p0035
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T07:53:46.485Z
```
{"service":"dbservice2","message":"2021-08-13 07:53:46,485 | INFO | 0.0.0.2 | 172.17.0.2 | dbservice2 | 52f47e62cf8fd363 | 87f2fae2-fbc8-11eb-afa4-0242ac110004-edQqtaui-Nyq_U<Q^_uRZ token generate success token=MTYyODgxMjQyNi40ODUzODE0Ojg3ZjJmYWUyLWZiYzgtMTFlYi1hZmE0LTAyNDJhYzExMDAwNGVkUXF0YXVpTnlxX1U8UV5fdVJaOjE2Mjg4MTI0ODYuNDg1MzkzNTo0MjVlNzYwOTRiYmMyODEwNGNiNjFhZmI3Zjc5Yjk3Yw=="}
```
Same service, the 2 minutes before (oldest first):
  07:53:35.521 [dbservice2] INFO 816a687c-fbc8-11eb-af7a-0242ac110003-SZKcrGIR-xPE^X0ln_KYI token generate success token=MTYyODgxMjQxNS41MjE0MTM6ODE2YTY4N2MtZmJjOC0xMWViLWFmN2EtMDI0MmFjMTE
  07:53:36.279 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  07:53:36.279 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  07:53:36.316 [dbservice2] INFO query = select passwards from username_table where user_name='nAxhWmpD'  (×5)
  07:53:36.394 [dbservice2] INFO 81e81e5c-fbc8-11eb-8d9c-0242ac110003-nAxhWmpD-Rz0a{-P@5/:o token generate success token=MTYyODgxMjQxNi4zOTM1OTc4OjgxZTgxZTVjLWZiYzgtMTFlYi04ZDljLTAyNDJhYzE
  07:53:37.125 [dbservice2] INFO 8267eaf6-fbc8-11eb-9fb0-0242ac110004-jSevQlNq-y=u7{-jE?dDK token generate success token=MTYyODgxMjQxNy4xMjQ5MDk5OjgyNjdlYWY2LWZiYzgtMTFlYi05ZmIwLTAyNDJhYzE
  07:53:42.326 [dbservice2] INFO 856f7cbe-fbc8-11eb-8136-0242ac110003-tJwGvlrd-_X.0m+hp>Z-/ token generate success token=MTYyODgxMjQyMi4zMjY1MDQ1Ojg1NmY3Y2JlLWZiYzgtMTFlYi04MTM2LTAyNDJhYzE
  07:53:44.909 [dbservice2] INFO 86f9e894-fbc8-11eb-833e-0242ac110004-yHBRGerA-+zo}cYnN=3wO token generate success token=MTYyODgxMjQyNC45MDg3NzU6ODZmOWU4OTQtZmJjOC0xMWViLTgzM2UtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  07:53:16.507 [dbservice2] INFO 7620fa76-fbc8-11eb-92f1-0242ac110003-xgKipZPG-}vC$Ij:iYe.8 token generate success token=MTYyODgxMjM5Ni41MDcwMDQ6NzYyMGZhNzYtZmJjOC0xMWViLTkyZjEtMDI0MmFjMTE
  07:53:16.618 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '7690432c-fbc8-11eb-831d-0242ac110004', 'value': '', 'ex': 10}  (×41)
  07:53:16.776 [webservice2] INFO complete information: {'uuid': '7690432c-fbc8-11eb-831d-0242ac110004', 'user_id': 'OBgRIvmU'}  (×41)
  07:53:16.837 [mobservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×31)
  07:53:16.928 [mobservice1] INFO info 7690432c-fbc8-11eb-831d-0242ac110004:OBgRIvmU write success
  07:53:17.061 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '7690432c-fbc8-11eb-831d-0242ac110004', 'user_id': 'OBgRIvmU'}  (×82)
  07:53:17.186 [redisservice2] INFO service accept, status_code: 200  (×43)
  07:53:17.334 [dbservice1] INFO 768b1050-fbc8-11eb-a806-0242ac110003-IwBSEYcZ-(ytghoMs$0KL token generate success token=MTYyODgxMjM5Ny4zMzQwNDE2Ojc2OGIxMDUwLWZiYzgtMTFlYi1hODA2LTAyNDJhYzE
  07:53:17.874 [logservice2] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×36)
  07:53:19.778 [mobservice2] INFO info 784209b2-fbc8-11eb-a161-0242ac110004:wKjLqdJi write success
  07:53:22.139 [dbservice1] INFO 796f2004-fbc8-11eb-ac23-0242ac110004-xgKipZPG-}vC$Ij:iYe.8 token generate success token=MTYyODgxMjQwMi4xMzk2MDg5Ojc5NmYyMDA0LWZiYzgtMTFlYi1hYzIzLTAyNDJhYzE
  07:53:24.198 [mobservice1] INFO info 7ae239e4-fbc8-11eb-8fec-0242ac110004:QlZMgGXD write success
  07:53:26.667 [mobservice1] INFO info 7c4e9304-fbc8-11eb-98e3-0242ac110004:FyRfJQAa write success
  07:53:29.599 [dbservice1] INFO 7de0a428-fbc8-11eb-862b-0242ac110003-GNqpIFum-6p{Revl/Jr90 token generate success token=MTYyODgxMjQwOS41OTg3NzU5OjdkZTBhNDI4LWZiYzgtMTFlYi04NjJiLTAyNDJhYzE
  07:53:32.133 [dbservice1] INFO 7f642e78-fbc8-11eb-b764-0242ac110003-tRLZzuQg-6=h^0Kp$%lJx token generate success token=MTYyODgxMjQxMi4xMzMxNDQxOjdmNjQyZTc4LWZiYzgtMTFlYi1iNzY0LTAyNDJhYzE
  07:53:35.220 [mobservice1] INFO info 816a687c-fbc8-11eb-af7a-0242ac110003:SZKcrGIR write success
  07:53:39.353 [redisservice1] ERROR 二维码已过期， 请刷新重新扫描, status_code: 400  (×2)
  07:53:44.486 [mobservice2] INFO info 86f9e894-fbc8-11eb-833e-0242ac110004:yHBRGerA write success
  07:53:47.016 [mobservice1] INFO info 8874290a-fbc8-11eb-b737-0242ac110003:oYbSglqf write success
  07:53:48.986 [dbservice2] INFO 8976f59e-fbc8-11eb-954b-0242ac110003-jliMGRSf-@UO%!NH}$bsm token generate success token=MTYyODgxMjQyOC45ODYyOTU1Ojg5NzZmNTllLWZiYzgtMTFlYi05NTRiLTAyNDJhYzE
  07:53:51.025 [mobservice2] INFO info 8ae3a3fa-fbc8-11eb-b3d7-0242ac110004:EQWxHTiy write success
  07:53:53.407 [mobservice2] INFO info 8c50ecca-fbc8-11eb-a654-0242ac110004:SYUdXTMn write success
  07:53:55.611 [dbservice2] INFO 8d5eb174-fbc8-11eb-a2fc-0242ac110003-fLyAPDBT-rm}hd*$L1SIo token generate success token=MTYyODgxMjQzNS42MTExOTY1OjhkNWViMTc0LWZiYzgtMTFlYi1hMmZjLTAyNDJhYzE
  07:53:57.824 [mobservice1] INFO info 8eeb68b6-fbc8-11eb-bb3f-0242ac110003:SpsReQKd write success
  07:54:00.455 [mobservice2] INFO info 907f81ee-fbc8-11eb-b0e2-0242ac110004:lvCfjILw write success
  07:54:02.902 [mobservice2] INFO info 91f70ef2-fbc8-11eb-a6b1-0242ac110004:kpLnyIUm write success
  07:54:06.148 [mobservice1] INFO info 93e0e0ee-fbc8-11eb-b7c3-0242ac110004:zWngqvYN write success
  07:54:08.651 [mobservice2] INFO info 955a23cc-fbc8-11eb-b344-0242ac110003:VxubFBRX write success
  07:54:11.142 [mobservice1] INFO info 96dae7ea-fbc8-11eb-aef0-0242ac110004:jHRvwBZi write success
  07:54:13.576 [dbservice2] INFO 981cf06c-fbc8-11eb-85d7-0242ac110003-pdAkGNZq-7sD/*Q(>%?OT token generate success token=MTYyODgxMjQ1My41NzU1MjE1Ojk4MWNmMDZjLWZiYzgtMTFlYi04NWQ3LTAyNDJhYzE

## p0142
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service frontend, 2024-11-18T05:34:09.734Z
```
{"timestamp":1731908049734961200,"container_name":"frontend","pod_name":"frontend-588fbcd66b-rzd62","node_name":"ip-192-168-24-141.ap-southeast-2.compute.internal","message":"placing order"}
```
Same service, the 2 minutes before (oldest first):
  05:34:08.501 [frontend] serving product page  (×4)
  05:34:08.536 [frontend] request complete  (×6)
  05:34:08.550 [frontend] request started  (×7)
  05:34:08.883 [frontend] view user cart  (×2)
  05:34:09.673 [frontend] adding to cart
All services, 30 seconds either side (sampled):
  05:33:39.787 [frontend] request started  (×317)
  05:33:39.797 [cartservice] GetCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×264)
  05:33:39.817 [shippingservice] [GetQuote] completed request  (×81)
  05:33:40.013 [frontend] serving product page  (×155)
  05:33:41.193 [adservice] received ad request (context_words=[clothing, tops])  (×23)
  05:33:41.441 [frontend] ENV_PLATFORM is: aws  (×28)
  05:33:44.869 [frontend] adding to cart  (×34)
  05:33:48.578 [frontend] placing order  (×11)
  05:33:48.605 [paymentservice] Transaction processed: visa ending 1526 Amount: TRY752.679850516  (×3)
  05:33:48.609 [shippingservice] [ShipOrder] completed request  (×12)
  05:33:48.619 [checkoutservice] order confirmation email sent to "bakercarmen@example.net"
  05:33:51.028 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"58","nanos":345864663},"credit_card":{"credit_card_number":"474074875381591  (×2)
  05:33:51.041 [checkoutservice] order confirmation email sent to "whiteshannon@example.net"
  05:33:54.722 [adservice] received ad request (context_words=[hair, beauty])  (×10)
  05:33:58.459 [checkoutservice] order confirmation email sent to "rclark@example.com"
  05:34:04.565 [checkoutservice] order confirmation email sent to "rsmith@example.net"
  05:34:07.206 [paymentservice] Transaction processed: visa ending 7248 Amount: USD208.890000000  (×3)
  05:34:09.736 [checkoutservice] [PlaceOrder] user_id="0727db9d-83b9-44b7-acab-68a4f8f289c0" user_currency="JPY"  (×3)
  05:34:09.778 [emailservice] A request to send order confirmation email to landryjeffrey@example.net has been received.
  05:34:11.248 [checkoutservice] order confirmation email sent to "hollyayala@example.org"
  05:34:20.010 [recommendationservice] [Recv ListRecommendations] product_ids=['L9ECAV7KIM', '9SIQT8TOJO', '6E92ZMYYFZ', '0PUK6V6EV0']  (×2)
  05:34:33.708 [emailservice] A request to send order confirmation email to raymond19@example.net has been received.
  05:34:39.650 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"CAD","units":"584","nanos":498816456},"credit_card":{"credit_card_number":"45338846186671
  05:34:39.666 [checkoutservice] order confirmation email sent to "nathan13@example.com"

## p0081
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service redisservice1, 2021-08-13T13:28:19.118Z
```
{"service":"redisservice1","message":"2021-08-13 13:28:19,118 | INFO | 0.0.0.1 | 172.17.0.4 | redisservice1 | cd3802bfd2176832 | redis读取信息成功, status_code: 200"}
```
Same service, the 2 minutes before (oldest first):
  13:28:09.569 [redisservice1] WARNING 用户未扫描，请等待！, status_code: 300  (×5)
  13:28:09.625 [redisservice1] INFO redis write success  (×7)
  13:28:12.929 [redisservice1] INFO service accept, status_code: 200  (×4)
  13:28:15.658 [redisservice1] INFO redis读取信息成功, status_code: 200  (×4)
All services, 30 seconds either side (sampled):
  13:27:49.121 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '32820376-fbf7-11eb-8469-0242ac110004', 'value': 'OZQbWUnN'}  (×43)
  13:27:49.234 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×44)
  13:27:49.281 [logservice2] INFO request http://0.0.0.3:9384/login_model_implement and param={'uuid': '32820376-fbf7-11eb-8469-0242ac110004', 'user_id': 'OZQbWUnN'}  (×82)
  13:27:49.397 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×46)
  13:27:49.475 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×50)
  13:27:49.669 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×37)
  13:27:50.678 [redisservice1] INFO service accept, status_code: 200  (×40)
  13:27:51.044 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×39)
  13:27:52.030 [mobservice1] INFO info 342ff930-fbf7-11eb-8311-0242ac110003:dUFBYtEJ write success
  13:27:53.673 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  13:27:55.193 [dbservice2] INFO 35bff46c-fbf7-11eb-9c17-0242ac110003-ITinMyWu-yv/ef>@J!O?L token generate success token=MTYyODgzMjQ3NS4xOTMwNjIzOjM1YmZmNDZjLWZiZjctMTFlYi05YzE3LTAyNDJhYzE
  13:27:57.645 [dbservice1] INFO 375f4dc2-fbf7-11eb-a0cf-0242ac110003-IREbBVhM-dHJS-+VlW)C? token generate success token=MTYyODgzMjQ3Ny42NDQ5MDg6Mzc1ZjRkYzItZmJmNy0xMWViLWEwY2YtMDI0MmFjMTE
  13:27:59.830 [mobservice2] INFO info 38d9b6ec-fbf7-11eb-8e7f-0242ac110003:cQWNVZmi write success
  13:28:01.919 [dbservice2] INFO 39f0db8c-fbf7-11eb-88d2-0242ac110003-AmhGSJRK-dWueNw!<8>i6 token generate success token=MTYyODgzMjQ4MS45MTg3NTU1OjM5ZjBkYjhjLWZiZjctMTFlYi04OGQyLTAyNDJhYzE
  13:28:04.672 [dbservice1] ERROR password in database of {user} is null, the user is not registered
  13:28:06.651 [mobservice1] INFO info 3ce808d8-fbf7-11eb-9e62-0242ac110003:TKYsgkdQ write success
  13:28:08.678 [dbservice2] INFO 3df2a8aa-fbf7-11eb-8736-0242ac110004-wpiyObsr-WJ.&AIR!3rPn token generate success token=MTYyODgzMjQ4OC42Nzc4NTc6M2RmMmE4YWEtZmJmNy0xMWViLTg3MzYtMDI0MmFjMTE
  13:28:17.210 [mobservice1] INFO info 433ce3b6-fbf7-11eb-878e-0242ac110003:NXYiMcPr write success
  13:28:20.468 [dbservice1] INFO 44f3ba9a-fbf7-11eb-9aed-0242ac110004-rXbZtUoM-Rw%Nn/U}9<h. token generate success token=MTYyODgzMjUwMC40NjgzNDIzOjQ0ZjNiYTlhLWZiZjctMTFlYi05YWVkLTAyNDJhYzE  (×2)
  13:28:23.173 [mobservice1] INFO info 46b9e7aa-fbf7-11eb-b327-0242ac110003:Bmsjcfbe write success
  13:28:25.435 [dbservice1] INFO 47e9e684-fbf7-11eb-9a29-0242ac110003-KrCJbket-SDY(Ra?xklfj token generate success token=MTYyODgzMjUwNS40MzUyOTA2OjQ3ZTllNjg0LWZiZjctMTFlYi05YTI5LTAyNDJhYzE
  13:28:27.735 [mobservice1] INFO info 4973083c-fbf7-11eb-87e9-0242ac110004:fNPgFxnR write success
  13:28:30.801 [dbservice1] INFO 4ae45e28-fbf7-11eb-b860-0242ac110003-PJMibIFO-5U{+BxgJH$VY token generate success token=MTYyODgzMjUxMC44MDE0MzE3OjRhZTQ1ZTI4LWZiZjctMTFlYi1iODYwLTAyNDJhYzE
  13:28:33.451 [dbservice2] INFO 4ca3ecb0-fbf7-11eb-8d39-0242ac110003-JKrdHZDV-END!RH0>_qOJ token generate success token=MTYyODgzMjUxMy40NTA0OTc2OjRjYTNlY2IwLWZiZjctMTFlYi04ZDM5LTAyNDJhYzE
  13:28:36.054 [dbservice2] INFO 4e4a9f6e-fbf7-11eb-97e6-0242ac110004-HfckUWDQ-tbA<=n&}flog token generate success token=MTYyODgzMjUxNi4wNTQyMjg6NGU0YTlmNmUtZmJmNy0xMWViLTk3ZTYtMDI0MmFjMTE
  13:28:38.602 [dbservice1] INFO 4fd5a2b6-fbf7-11eb-8966-0242ac110004-WdLJXtHG-UZY)^Efxi>LV token generate success token=MTYyODgzMjUxOC42MDIwNjo0ZmQ1YTJiNi1mYmY3LTExZWItODk2Ni0wMjQyYWMxMTA
  13:28:40.689 [mobservice2] INFO info 513c424a-fbf7-11eb-9466-0242ac110004:MZHWTqUt write success
  13:28:42.793 [dbservice1] INFO 52402008-fbf7-11eb-95fe-0242ac110004-ZadRMLrA-qU=K:N/SjTlv token generate success token=MTYyODgzMjUyMi43OTMxODQzOjUyNDAyMDA4LWZiZjctMTFlYi05NWZlLTAyNDJhYzE
  13:28:45.068 [dbservice1] INFO 539cc848-fbf7-11eb-b12b-0242ac110004-ahqTsjZo-nrIS=t2q}{_x token generate success token=MTYyODgzMjUyNS4wNjc4MzIyOjUzOWNjODQ4LWZiZjctMTFlYi1iMTJiLTAyNDJhYzE
  13:28:47.579 [mobservice1] INFO info 555f849a-fbf7-11eb-a8f9-0242ac110003:NpSktBQI write success

## p0056
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T08:35:57.337Z
```
{"service":"dbservice1","message":"2021-08-13 08:35:57,337 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 28103bc3f56c6671 | 6c6a5986-fbce-11eb-9771-0242ac110003-qHGVUSPX-2X6L_bVf5*I< token generate success token=MTYyODgxNDk1Ny4zMzY3MTg4OjZjNmE1OTg2LWZiY2UtMTFlYi05NzcxLTAyNDJhYzExMDAwM3FIR1ZVU1BYMlg2TF9iVmY1Kkk8OjE2Mjg4MTUwMTcuMzM2NzM6OTA0NTc5YzUyZWE2MTZmNTkxYTZkMTkxYjMwYTM3ZjA="}
```
Same service, the 2 minutes before (oldest first):
  08:35:49.803 [dbservice1] ERROR password in database of {user} is null, the user is not registered  (×2)
  08:35:50.593 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:35:50.593 [dbservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×5)
  08:35:50.659 [dbservice1] INFO query = select passwards from username_table where user_name='GtreMfPE'  (×5)
  08:35:53.223 [dbservice1] INFO 69f71f72-fbce-11eb-8bad-0242ac110003-lcIzRtym-stnKM@HiB>bU token generate success token=MTYyODgxNDk1My4yMjMzNzQ4OjY5ZjcxZjcyLWZiY2UtMTFlYi04YmFkLTAyNDJhYzE
  08:35:55.661 [dbservice1] INFO 6b65f752-fbce-11eb-abe1-0242ac110004-sftcByNh--3)PoD^K$Fey token generate success token=MTYyODgxNDk1NS42NjEwNDM0OjZiNjVmNzUyLWZiY2UtMTFlYi1hYmUxLTAyNDJhYzE
  08:35:56.466 [dbservice1] INFO 6bef9ec6-fbce-11eb-9370-0242ac110003-JkrwUiSI-coACm)X5D6hn token generate success token=MTYyODgxNDk1Ni40NjU2ODo2YmVmOWVjNi1mYmNlLTExZWItOTM3MC0wMjQyYWMxMTA
All services, 30 seconds either side (sampled):
  08:35:27.370 [webservice2] INFO complete information: {'uuid': '5aeb40c6-fbce-11eb-983b-0242ac110004', 'user_id': 'Egncqoka'}  (×41)
  08:35:27.441 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '5aeb40c6-fbce-11eb-983b-0242ac110004', 'value': 'Egncqoka'}  (×35)
  08:35:27.579 [logservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': '5aeb40c6-fbce-11eb-983b-0242ac110004'}  (×32)
  08:35:27.678 [logservice1] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×31)
  08:35:27.789 [dbservice1] INFO 5aeb40c6-fbce-11eb-983b-0242ac110004-Egncqoka-7hZP8@jvo*H} token generate success token=MTYyODgxNDkyNy43ODg3NzI2OjVhZWI0MGM2LWZiY2UtMTFlYi05ODNiLTAyNDJhYzE
  08:35:28.102 [webservice1] INFO complete information: {'uuid': '5b5879fc-fbce-11eb-a4cf-0242ac110003', 'user_id': 'zrnyoxBF'}  (×39)
  08:35:28.211 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': '5b5879fc-fbce-11eb-a4cf-0242ac110003', 'value': 'zrnyoxBF'}  (×45)
  08:35:29.103 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '5c0a8d4a-fbce-11eb-a5d1-0242ac110004', 'value': '', 'ex': 10}  (×40)
  08:35:29.645 [redisservice1] INFO service refuse, status_code: 200  (×15)
  08:35:32.209 [logservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×47)
  08:35:32.313 [logservice2] INFO now call service:dbservice1, inst:http://0.0.0.4:9388 as a downstream service  (×47)
  08:35:39.986 [mobservice2] ERROR uuid:5bcdb8ac-fbce-11eb-b2c4-0242ac110003 information has expired, mobile phone login is invalid
  08:35:40.650 [mobservice1] INFO info 62b1a2a0-fbce-11eb-aa0c-0242ac110004:igXqQZLm write success
  08:35:42.741 [dbservice1] INFO 63bfefe4-fbce-11eb-b6be-0242ac110004-rzupZVkA-Qd<YFATn8+k) token generate success token=MTYyODgxNDk0Mi43NDA3MzU6NjNiZmVmZTQtZmJjZS0xMWViLWI2YmUtMDI0MmFjMTE
  08:35:45.456 [dbservice1] INFO 65567d96-fbce-11eb-9a48-0242ac110003-JTPZbGUX-owRC0.<$@!D) token generate success token=MTYyODgxNDk0NS40NTYyMzo2NTU2N2Q5Ni1mYmNlLTExZWItOWE0OC0wMjQyYWMxMTA
  08:35:48.146 [dbservice1] INFO 66e93f72-fbce-11eb-a078-0242ac110004-kWcbAndl-+K)#TtAh_eL$ token generate success token=MTYyODgxNDk0OC4xNDYyNzcyOjY2ZTkzZjcyLWZiY2UtMTFlYi1hMDc4LTAyNDJhYzE  (×2)
  08:35:50.340 [mobservice1] INFO info 6877ce12-fbce-11eb-8901-0242ac110004:GtreMfPE write success
  08:35:53.833 [mobservice1] INFO info 6a7d05ba-fbce-11eb-8a4f-0242ac110003:HfPCXKQO write success
  08:35:56.466 [dbservice1] INFO 6bef9ec6-fbce-11eb-9370-0242ac110003-JkrwUiSI-coACm)X5D6hn token generate success token=MTYyODgxNDk1Ni40NjU2ODo2YmVmOWVjNi1mYmNlLTExZWItOTM3MC0wMjQyYWMxMTA
  08:35:58.990 [dbservice1] INFO 6d6bb1fe-fbce-11eb-9f7e-0242ac110004-mCkaEIVe-%4QxON(snAYv token generate success token=MTYyODgxNDk1OC45OTAwOTk3OjZkNmJiMWZlLWZiY2UtMTFlYi05ZjdlLTAyNDJhYzE
  08:36:01.036 [mobservice1] INFO info 6edc3e00-fbce-11eb-8cf1-0242ac110004:AaVSnOsU write success
  08:36:03.501 [dbservice1] INFO 701853ee-fbce-11eb-a796-0242ac110004-UlXetfSn-i#KQO@L$Ef9X token generate success token=MTYyODgxNDk2My41MDA5MjYzOjcwMTg1M2VlLWZiY2UtMTFlYi1hNzk2LTAyNDJhYzE
  08:36:06.174 [mobservice2] INFO info 71db53d4-fbce-11eb-8932-0242ac110003:rYEevjPt write success
  08:36:09.027 [mobservice1] INFO info 738c10e2-fbce-11eb-b042-0242ac110004:DHpIOPcr write success
  08:36:12.089 [mobservice2] INFO info 756e3318-fbce-11eb-9e2c-0242ac110004:yODGvlBa write success
  08:36:15.148 [mobservice1] INFO info 773ccfec-fbce-11eb-872c-0242ac110003:COxkLyBN write success
  08:36:17.981 [dbservice1] INFO 78bda4c2-fbce-11eb-b0c3-0242ac110004-lwqgfHWY-v6_!Y%NgK=A) token generate success token=MTYyODgxNDk3Ny45ODExNjI1Ojc4YmRhNGMyLWZiY2UtMTFlYi1iMGMzLTAyNDJhYzE
  08:36:20.476 [mobservice1] INFO info 7a73ea2e-fbce-11eb-b0f0-0242ac110003:pfVurBxD write success
  08:36:22.930 [mobservice1] INFO info 7bf00310-fbce-11eb-89a4-0242ac110003:DQJsnMlT write success
  08:36:24.907 [dbservice1] INFO 7cdfe114-fbce-11eb-947e-0242ac110003-AdPXowjJ-4>$2wY*8ErhR token generate success token=MTYyODgxNDk4NC45MDcyMzk3OjdjZGZlMTE0LWZiY2UtMTFlYi05NDdlLTAyNDJhYzE

## p0022
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice2, 2021-08-13T06:47:31.730Z
```
{"service":"dbservice2","message":"2021-08-13 06:47:31,730 | ERROR | 0.0.0.2 | dbservice2 | db_helper.py -> sql_ano_prob -> 93 | 78208b14dc9d83ce | (pymysql.err.OperationalError) (1054, \"Unknown column 'system_data_time' in 'field list'\")[SQL: select service_name, system_data_time, system_cpu_utilization, system_memory_usage,system_disk_usage, disk_io_read_count, disk_io_write_count,system_network, network_io_read_count, network_io…"}
```
Same service, the 2 minutes before (oldest first):
  06:47:25.298 [dbservice2] INFO query = select passwards from username_table where user_name='mgvTPLKy'  (×5)
  06:47:25.377 [dbservice2] INFO 4304a038-fbbf-11eb-a63c-0242ac110004-mgvTPLKy-UE!Q+o#:Kz9% token generate success token=MTYyODgwODQ0NS4zNzczMDQ2OjQzMDRhMDM4LWZiYmYtMTFlYi1hNjNjLTAyNDJhYzE
  06:47:26.936 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  06:47:26.936 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  06:47:27.030 [dbservice2] INFO 4405c8e0-fbbf-11eb-b216-0242ac110004-IfxPKRFv-Sw2k9hm_g1fH token generate success token=MTYyODgwODQ0Ny4wMjk2Njc0OjQ0MDVjOGUwLWZiYmYtMTFlYi1iMjE2LTAyNDJhYzE
  06:47:27.807 [dbservice2] INFO 447b1442-fbbf-11eb-82b9-0242ac110004-WILFvAUY-@gqs5xJrY<v) token generate success token=MTYyODgwODQ0Ny44MDcxMzI1OjQ0N2IxNDQyLWZiYmYtMTFlYi04MmI5LTAyNDJhYzE
  06:47:28.650 [dbservice2] INFO 44f5bb84-fbbf-11eb-b40c-0242ac110003-eRTPmDsV-Q!>Vw29I<Kh& token generate success token=MTYyODgwODQ0OC42NDk1NDYxOjQ0ZjViYjg0LWZiYmYtMTFlYi1iNDBjLTAyNDJhYzE
  06:47:31.123 [dbservice2] INFO 46775558-fbbf-11eb-b27c-0242ac110003-jIBRSGcQ-)ERfPKel{cTt token generate success token=MTYyODgwODQ1MS4xMjI5MDcyOjQ2Nzc1NTU4LWZiYmYtMTFlYi1iMjdjLTAyNDJhYzE
All services, 30 seconds either side (sampled):
  06:47:01.733 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  06:47:01.964 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×43)
  06:47:02.116 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×35)
  06:47:02.224 [logservice1] INFO request http://0.0.0.4:9388/db_login_methods and param={'uuid': '3558f772-fbbf-11eb-b8ee-0242ac110003', 'user_id': 'ckaGqjZH'}  (×84)
  06:47:02.441 [webservice2] INFO uuid: 35bb9ac6-fbbf-11eb-b034-0242ac110004 write redis successfully  (×42)
  06:47:02.688 [mobservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '35bb9ac6-fbbf-11eb-b034-0242ac110004', 'value': 'iBHTmjqo'}  (×42)
  06:47:03.031 [dbservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×47)
  06:47:03.269 [dbservice1] INFO 35d4a05c-fbbf-11eb-a9a2-0242ac110003-qhdLCnSU-I!Hg(Dukw}{) token generate success token=MTYyODgwODQyMy4yNjg4MzQ2OjM1ZDRhMDVjLWZiYmYtMTFlYi1hOWEyLTAyNDJhYzE
  06:47:05.702 [dbservice2] INFO 374da3d4-fbbf-11eb-99af-0242ac110003-NPtZUmhc-F{kw7GTK)n/. token generate success token=MTYyODgwODQyNS43MDIxNTU4OjM3NGRhM2Q0LWZiYmYtMTFlYi05OWFmLTAyNDJhYzE
  06:47:08.000 [dbservice2] INFO 38b8316c-fbbf-11eb-a4e8-0242ac110003-YKwDOXcq-^yVRxMeUlsTA token generate success token=MTYyODgwODQyOC4wMDAwNzEzOjM4YjgzMTZjLWZiYmYtMTFlYi1hNGU4LTAyNDJhYzE
  06:47:10.863 [mobservice2] INFO info 3a961fe4-fbbf-11eb-825c-0242ac110003:XKUdarkx write success
  06:47:13.269 [mobservice2] INFO info 3c015c0e-fbbf-11eb-9cc6-0242ac110004:SoisjlVQ write success
  06:47:15.762 [mobservice2] INFO info 3d7c7834-fbbf-11eb-a5db-0242ac110004:qyhWbUnC write success
  06:47:18.379 [mobservice1] INFO info 3f10625a-fbbf-11eb-b413-0242ac110003:QSUqdTsv write success
  06:47:20.899 [mobservice1] INFO info 408f8f98-fbbf-11eb-b684-0242ac110004:tWMvxnLr write success
  06:47:23.375 [mobservice1] INFO info 420fe520-fbbf-11eb-ad6d-0242ac110003:PNmIMWHV write success
  06:47:26.285 [dbservice1] INFO 4386174e-fbbf-11eb-9bda-0242ac110003-bhmAUvxt-bl!-9=:e3B{F token generate success token=MTYyODgwODQ0Ni4yODUwOTQ3OjQzODYxNzRlLWZiYmYtMTFlYi05YmRhLTAyNDJhYzE
  06:47:29.156 [mobservice2] INFO info 45736782-fbbf-11eb-b987-0242ac110004:cqyYsFCP write success
  06:47:31.949 [dbservice2] INFO 46f05502-fbbf-11eb-b609-0242ac110003-lvCfjILw-D1@9U_jQh_$a token generate success token=MTYyODgwODQ1MS45NDkxNTY4OjQ2ZjA1NTAyLWZiYmYtMTFlYi1iNjA5LTAyNDJhYzE
  06:47:35.123 [mobservice2] INFO info 49066ad4-fbbf-11eb-b621-0242ac110003:rJyVYctH write success
  06:47:37.871 [mobservice1] INFO info 4a9f5496-fbbf-11eb-bbbb-0242ac110003:ITinMyWu write success
  06:47:45.548 [mobservice1] INFO info 4f3e37b0-fbbf-11eb-afea-0242ac110003:BeqngSzw write success
  06:47:49.126 [mobservice1] INFO info 515fb064-fbbf-11eb-b72c-0242ac110004:CPiYkQrA write success
  06:47:51.710 [dbservice1] INFO 5299e508-fbbf-11eb-94ef-0242ac110003-bTPjsUVJ-/OMn<NHZb.me token generate success token=MTYyODgwODQ3MS43MTAwODc1OjUyOTllNTA4LWZiYmYtMTFlYi05NGVmLTAyNDJhYzE
  06:47:54.957 [mobservice2] INFO info 54d93bb6-fbbf-11eb-a75a-0242ac110004:osKDHrgX write success
  06:47:57.377 [dbservice1] INFO 560c9a46-fbbf-11eb-bead-0242ac110003-ZDqHGEXv-$Fe*7dcf0>Yv token generate success token=MTYyODgwODQ3Ny4zNzY2NTQxOjU2MGM5YTQ2LWZiYmYtMTFlYi1iZWFkLTAyNDJhYzE
  06:48:00.210 [dbservice2] INFO 57bcc0f0-fbbf-11eb-bc2e-0242ac110003-HCzNJuWb-bP$YVW7=McS1 token generate success token=MTYyODgwODQ4MC4yMDk1OTU6NTdiY2MwZjAtZmJiZi0xMWViLWJjMmUtMDI0MmFjMTE

## p0768
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service orders, 2024-11-23T19:26:00.347Z
```
{"timestamp":1732389960347558100,"container_name":"orders","pod_name":"orders-7fff6698cb-7hdjk","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"2024-11-23 19:26:00.347 ERROR [orders,,,] 7 --- [p-nio-80-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet]    : Servlet.service() for servlet [dispatcherServlet] in context with path [] threw exception [Request processing failed; nested exception is java.lang.IllegalStateException: Unable to create order due to unspecified IO error.] with root cause\n"}
```
Same service, the 2 minutes before (oldest first):
  19:25:47.138 [orders] 2024-11-23 19:25:47.138 INFO [orders,fd6d23969d88d245,e7573c1c0e1e0a20,false] 7 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Sending payment req  (×9)
  19:25:47.142 [orders] 2024-11-23 19:25:47.142 INFO [orders,fd6d23969d88d245,e7573c1c0e1e0a20,false] 7 --- [p-nio-80-exec-9] w.w.s.o.controllers.OrdersController : Received payment re  (×9)
  19:25:48.615 [orders] 2024-11-23 19:25:48.615 INFO [orders,271d844522a6d069,488fa5fc8d6a746e,false] 7 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req
  19:25:48.620 [orders] 2024-11-23 19:25:48.619 INFO [orders,271d844522a6d069,488fa5fc8d6a746e,false] 7 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Received payment re
All services, 30 seconds either side (sampled):
  19:25:30.375 [front-end] Posting Customer: {"username":"yaLKPdl","password":"mdUmtqRXp","email":"yaLKPdl@gmail.com","firstName":"yaLKPdl","lastName":"yaLKPdl"}
  19:25:30.544 [front-end] Request received with body: {}  (×63)
  19:25:30.585 [user] ts=2024-11-23T19:25:30.585516835Z caller=middlewares.go:134 method=GetCards id=67422c1948485600016b1628 result=1 took=3.751727ms  (×63)
  19:25:30.607 [queue-master] 2024-11-23 19:25:30.606 ERROR 7 --- [pool-6-thread-9] w.weave.socks.queuemaster.DockerSpawner : Exception trying to launch/remove worker container. javax.ws.rs.
  19:25:30.694 [front-end] POST /cards 200 - ms - -  (×67)
  19:25:30.761 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}  (×67)
  19:25:30.930 [catalogue] ts=2024-11-23T19:25:30Z caller=logging.go:85 method=Health result=2 took=24.132µs  (×40)
  19:25:31.174 [front-end] Received response: "{\"firstName\":\"jgzxrQZXHMO\",\"lastName\":\"jgzxrQZXHMO\",\"username\":\"jgzxrQZXHMO\",\"id\":\"67422c1b48485600016b1635\",\"_links\":{\"a
  19:25:32.072 [front-end] Posting Customer: {"username":"JhuCh","password":"FSWThRV","email":"JhuCh@gmail.com","firstName":"JhuCh","lastName":"JhuCh"}
  19:25:34.889 [front-end] Received response: "{\"firstName\":\"WnsIYdcgpNQYa\",\"lastName\":\"WnsIYdcgpNQYa\",\"username\":\"WnsIYdcgpNQYa\",\"id\":\"67422c1648485600016b1623\",\"_links\
  19:25:36.862 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×6)
  19:25:39.887 [front-end] Order response: {"statusCode":201,"body":{"id":"67422c334ca85a00070c5288","customerId":"67422c2048485600016b163e","customer":{"id":null,"firstName":"qpZIWBek","
  19:25:41.242 [front-end] Order response: {"id":"67422c354ca85a00070c528b","customerId":"67422c2148485600016b1642","customer":{"id":null,"firstName":"lscjKSxBNdS","lastName":"lscjKSxBNdS
  19:25:43.652 [front-end] Order response: {"statusCode":201,"body":{"id":"67422c374ca85a00070c528d","customerId":"67422c2348485600016b1648","customer":{"id":null,"firstName":"XKiGD","las
  19:25:44.783 [front-end] Order response: {"id":"67422c384ca85a00070c5290","customerId":"67422c2548485600016b164b","customer":{"id":null,"firstName":"aNpOtPaWu","lastName":"aNpOtPaWu","u
  19:25:47.190 [front-end] Posting Customer: {"username":"HnphKTnKRHBLmxd","password":"NMMftl","email":"HnphKTnKRHBLmxd@gmail.com","firstName":"HnphKTnKRHBLmxd","lastName":"HnphKTnKRHBLmx
  19:25:49.017 [front-end] Posting Customer: {"username":"dSpnzjvZV","password":"zrKZE","email":"dSpnzjvZV@gmail.com","firstName":"dSpnzjvZV","lastName":"dSpnzjvZV"}
  19:25:50.566 [front-end] Posting Customer: {"username":"VVHDXt","password":"XIthMlVI","email":"VVHDXt@gmail.com","firstName":"VVHDXt","lastName":"VVHDXt"}
  19:25:52.392 [front-end] Order response: {"statusCode":201,"body":{"id":"67422c404ca85a00070c5296","customerId":"67422c2c48485600016b165d","customer":{"id":null,"firstName":"JhuCh","las
  19:25:56.973 [front-end] Order response: {"statusCode":201,"body":{"id":"67422c444ca85a00070c5297","customerId":"67422c3348485600016b167b","customer":{"id":null,"firstName":"sBqll","las
  19:25:59.992 [front-end] POST /cart 500 47.168 ms - 64  (×30)
  19:26:01.678 [user] ts=2024-11-23T19:26:01.678208421Z caller=middlewares.go:46 method=Register username=QGveaEFvl email=QGveaEFvl@gmail.com took=5.104741ms
  19:26:05.358 [front-end] Received response: "{\"firstName\":\"VjFZoYKCeXfbTG\",\"lastName\":\"VjFZoYKCeXfbTG\",\"username\":\"VjFZoYKCeXfbTG\",\"id\":\"67422c3948485600016b1682\",\"_lin
  19:26:09.620 [front-end] Received response: "{\"firstName\":\"RvmTgs\",\"lastName\":\"RvmTgs\",\"username\":\"RvmTgs\",\"id\":\"67422c3d48485600016b168e\",\"_links\":{\"addresses\":{\"h
  19:26:12.225 [front-end] Received response: "{\"firstName\":\"AnfITfpoSgHTzM\",\"lastName\":\"AnfITfpoSgHTzM\",\"username\":\"AnfITfpoSgHTzM\",\"id\":\"67422c3e48485600016b1690\",\"_lin
  19:26:13.898 [carts] Caused by: java.net.ConnectException: Connection refused (Connection refused) at java.net.PlainSocketImpl.socketConnect(Native Method) ~[na:1.8.0_131] at java.n
  19:26:15.639 [user] ts=2024-11-23T19:26:15.638931858Z caller=middlewares.go:46 method=Register username=ELtTnecX email=ELtTnecX@gmail.com took=5.429568ms
  19:26:18.357 [user] ts=2024-11-23T19:26:18.35784749Z caller=middlewares.go:46 method=Register username=qAmnBz email=qAmnBz@gmail.com took=4.806248ms
  19:26:22.683 [front-end] Posting Customer: {"username":"EtSIzsYUhk","password":"CfVwL","email":"EtSIzsYUhk@gmail.com","firstName":"EtSIzsYUhk","lastName":"EtSIzsYUhk"}
  19:26:27.037 [front-end] Received response: "{\"firstName\":\"QfoArW\",\"lastName\":\"QfoArW\",\"username\":\"QfoArW\",\"id\":\"67422c5448485600016b16db\",\"_links\":{\"addresses\":{\"h

## p0698
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-12T13:52:52.502Z
```
{"service":"dbservice1","message":"2021-08-12 13:52:52,502 | INFO | 0.0.0.4 | 172.17.0.3 | dbservice1 | 236d436503339c0c | 87f32ca2-fb31-11eb-b1c9-0242ac110004-SUYGNuEo-GUX9z)qOC/KL token generate success token=MTYyODc0NzU3Mi41MDE3NjE0Ojg3ZjMyY2EyLWZiMzEtMTFlYi1iMWM5LTAyNDJhYzExMDAwNFNVWUdOdUVvR1VYOXopcU9DL0tMOjE2Mjg3NDc2MzIuNTAxNzcyOToyY2E4NzA5YjM0ZWUyMTVlMmFkODU1YTJmMmQ2N2Y4Mg=="}
```
Same service, the 2 minutes before (oldest first):
  13:52:43.612 [dbservice1] INFO 828f4296-fb31-11eb-999c-0242ac110004-TuOeLVZp-oM^!RSHCyT6} token generate success token=MTYyODc0NzU2My42MTIxODk1OjgyOGY0Mjk2LWZiMzEtMTFlYi05OTljLTAyNDJhYzE
  13:52:43.627 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  13:52:43.627 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  13:52:43.658 [dbservice1] INFO query = select passwards from username_table where user_name='irpbvSZq'  (×5)
  13:52:43.737 [dbservice1] INFO 82b542f2-fb31-11eb-820a-0242ac110004-irpbvSZq-51dywGEFt+kI token generate success token=MTYyODc0NzU2My43MzY5NTE2OjgyYjU0MmYyLWZiMzEtMTFlYi04MjBhLTAyNDJhYzE
  13:52:46.583 [dbservice1] INFO 84571a36-fb31-11eb-88a0-0242ac110004-QurEfLHx-IHF}iJTM)pEg token generate success token=MTYyODc0NzU2Ni41ODMyMDM4Ojg0NTcxYTM2LWZiMzEtMTFlYi04OGEwLTAyNDJhYzE
  13:52:47.761 [dbservice1] INFO 853153e0-fb31-11eb-b95d-0242ac110003-gfWraMPC-=@%?+Z9iR0SY token generate success token=MTYyODc0NzU2Ny43NjE1NjU3Ojg1MzE1M2UwLWZiMzEtMTFlYi1iOTVkLTAyNDJhYzE
  13:52:48.512 [dbservice1] INFO 859f4f08-fb31-11eb-b17c-0242ac110004-kdncspNK-/mUDr*ZR)9Ls token generate success token=MTYyODc0NzU2OC41MTIxNDE6ODU5ZjRmMDgtZmIzMS0xMWViLWIxN2MtMDI0MmFjMTE
All services, 30 seconds either side (sampled):
  13:52:22.571 [redisservice2] WARNING 用户未扫描，请等待！, status_code: 300  (×41)
  13:52:22.721 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×35)
  13:52:22.825 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×37)
  13:52:23.013 [webservice1] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '76cd3e04-fb31-11eb-8c36-0242ac110003', 'value': '', 'ex': 10}  (×32)
  13:52:23.196 [mobservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×38)
  13:52:23.358 [webservice2] INFO request http://0.0.0.1:9386/set_key_value_into_redis and param={'keys': '7702295c-fb31-11eb-8549-0242ac110004', 'value': '', 'ex': 10}  (×41)
  13:52:23.653 [mobservice1] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×35)
  13:52:24.184 [logservice2] INFO now call service:redisservice1, inst:http://0.0.0.1:9386 as a downstream service  (×39)
  13:52:24.483 [dbservice2] INFO 774366d8-fb31-11eb-81a2-0242ac110003-CZFJjyRk-1QN4a<C{jpM> token generate success token=MTYyODc0NzU0NC40ODI1NTgzOjc3NDM2NmQ4LWZiMzEtMTFlYi04MWEyLTAyNDJhYzE
  13:52:26.906 [dbservice2] INFO 78b238e6-fb31-11eb-a1c8-0242ac110003-vpUgXqzC-iQ9Zu4A?U^<5 token generate success token=MTYyODc0NzU0Ni45MDYzNzc4Ojc4YjIzOGU2LWZiMzEtMTFlYi1hMWM4LTAyNDJhYzE
  13:52:34.968 [dbservice1] INFO 7d9380c2-fb31-11eb-ac2e-0242ac110003-roAFtIPD-=sjpw>m*#Pav token generate success token=MTYyODc0NzU1NC45Njc3NTg3OjdkOTM4MGMyLWZiMzEtMTFlYi1hYzJlLTAyNDJhYzE
  13:52:42.927 [logservice1] ERROR get information failed, fail code: 400
  13:52:44.653 [dbservice2] INFO 83389daa-fb31-11eb-9a08-0242ac110004-gKUmCyre-YL:T*me_uhSJ token generate success token=MTYyODc0NzU2NC42NTM0NzE1OjgzMzg5ZGFhLWZiMzEtMTFlYi05YTA4LTAyNDJhYzE
  13:52:46.798 [mobservice1] INFO info 84bdc060-fb31-11eb-89ed-0242ac110003:GiuNzrvJ write success
  13:52:49.026 [mobservice2] INFO info 861d0a1a-fb31-11eb-8f7e-0242ac110004:pKxfZBio write success
  13:52:51.329 [mobservice2] INFO info 8781d2a0-fb31-11eb-b7e5-0242ac110004:HMKVRZeu write success
  13:52:53.877 [mobservice1] INFO info 88fa6de0-fb31-11eb-9502-0242ac110003:yeMqQbFt write success
  13:52:55.864 [dbservice1] INFO 89f5bdd0-fb31-11eb-8d8a-0242ac110004-Xkwacyxi-.bPJi_tp#MW- token generate success token=MTYyODc0NzU3NS44NjQ0MDA2Ojg5ZjViZGQwLWZiMzEtMTFlYi04ZDhhLTAyNDJhYzE
  13:52:58.266 [dbservice1] INFO 8b6349e4-fb31-11eb-b889-0242ac110004-SDgLpeFn-kr3n*Mg_:JQ4 token generate success token=MTYyODc0NzU3OC4yNjU2NDI2OjhiNjM0OWU0LWZiMzEtMTFlYi1iODg5LTAyNDJhYzE
  13:53:01.047 [dbservice1] INFO 8cf1ce20-fb31-11eb-aa49-0242ac110003-tjrRfeJy-t5EnZ!FmiUq{ token generate success token=MTYyODc0NzU4MS4wNDY3MzQzOjhjZjFjZTIwLWZiMzEtMTFlYi1hYTQ5LTAyNDJhYzE
  13:53:03.849 [dbservice2] INFO 8eb31e3a-fb31-11eb-ac2d-0242ac110004-uZrYXDKb-MT}4%L2EhXFS token generate success token=MTYyODc0NzU4My44NDg0Mzg1OjhlYjMxZTNhLWZiMzEtMTFlYi1hYzJkLTAyNDJhYzE
  13:53:06.538 [mobservice1] INFO info 90887e3a-fb31-11eb-b797-0242ac110003:FGqxBRpZ write success
  13:53:08.908 [mobservice1] INFO info 91e4969c-fb31-11eb-acf8-0242ac110003:EGieKLYv write success
  13:53:10.752 [dbservice1] INFO 92dafcbc-fb31-11eb-88c3-0242ac110003-xUAQKIOl-SZl=)D>^PYVI token generate success token=MTYyODc0NzU5MC43NTI0MTk6OTJkYWZjYmMtZmIzMS0xMWViLTg4YzMtMDI0MmFjMTE
  13:53:13.301 [dbservice1] INFO 945e5d72-fb31-11eb-a212-0242ac110004-hVyjbRgD-f%@HSIq-)KE2 token generate success token=MTYyODc0NzU5My4zMDE2MDkzOjk0NWU1ZDcyLWZiMzEtMTFlYi1hMjEyLTAyNDJhYzE
  13:53:15.564 [mobservice2] INFO info 95ed5e7c-fb31-11eb-a928-0242ac110003:GqOpyFdr write success
  13:53:18.235 [mobservice1] INFO info 977b049c-fb31-11eb-8949-0242ac110003:eVRETvqC write success
  13:53:20.725 [mobservice1] INFO info 98f84672-fb31-11eb-9911-0242ac110003:eJuaFIik write success

## p0584
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-auth-service, 2024-12-07T18:31:41.179Z
```
{"timestamp":1733596301179031800,"container_name":"ts-auth-service","pod_name":"ts-auth-service-54976f76bc-h7r6c","node_name":"ip-192-168-18-27.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:41.178  INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl       : nullUSER TOKEN"}
```
Same service, the 2 minutes before (oldest first):
  18:31:30.676 [ts-auth-service] 2024-12-07 18:31:30.675 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : nullUSER TOKEN  (×4)
  18:31:30.676 [ts-auth-service] 2024-12-07 18:31:30.676 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID  (×4)
  18:31:31.064 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null
  18:31:31.065 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : nullUSER TOKEN
  18:31:31.278 [ts-auth-service] 2024-12-07 18:31:31.277 INFO 1 --- [o-12340-exec-10] auth.service.impl.TokenServiceImpl : 4d2a46c7-71cb-4cf1-b5bb-b68406d9da6f USER ID
  18:31:36.611 [ts-auth-service] 2024-12-07 18:31:36.611 INFO 1 --- [io-12340-exec-2] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:fdse_microservice __ 111111 __ null
  18:31:36.611 [ts-auth-service] 2024-12-07 18:31:36.611 INFO 1 --- [io-12340-exec-2] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice
  18:31:37.923 [ts-auth-service] 2024-12-07 18:31:37.922 INFO 1 --- [io-12340-exec-3] auth.service.impl.TokenServiceImpl : LOGIN USER NEW:admin __ 222222 __ null  (×3)
  18:31:37.923 [ts-auth-service] 2024-12-07 18:31:37.922 INFO 1 --- [io-12340-exec-3] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×3)
All services, 30 seconds either side (sampled):
  18:31:11.514 [ts-admin-basic-info-service] 2024-12-07 18:31:11.514 INFO 1 --- [io-18767-exec-9] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×2)
  18:31:11.600 [ts-travel-service] 2024-12-07 18:31:11.600 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×7)
  18:31:11.625 [ts-basic-service] 2024-12-07 18:31:11.625 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: GaoTieO  (×3)
  18:31:11.643 [ts-basic-service] 2024-12-07 18:31:11.643 INFO 1 --- [io-15680-exec-3] f.microservice.service.BasicServiceImpl : Response Resutl to String Response(status=1, msg=Success, data={i  (×4)
  18:31:11.663 [ts-order-service] 2024-12-07 18:31:11.663 INFO 1 --- [io-12031-exec-6] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 0  (×3)
  18:31:11.717 [ts-order-service] 2024-12-07 18:31:11.716 INFO 1 --- [io-12031-exec-5] order.controller.OrderController : [Order Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GMT 2024  (×5)
  18:31:11.814 [ts-seat-service] 2024-12-07 18:31:11.814 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×3)
  18:31:11.991 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:11 +0800] "POST /api/v1/users/login HTTP/1.1" 503 19 "http://localhost:8080/client_login.html" "Mozilla/5.0 (Macintosh; Intel M  (×2)
  18:31:12.083 [ts-seat-service] 2024-12-07 18:31:12.083 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN
  18:31:12.102 [ts-travel2-service] 2024-12-07 18:31:12.102 INFO 1 --- [io-16346-exec-6] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  18:31:12.157 [ts-seat-service] 2024-12-07 18:31:12.157 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getRouteResult is Respon  (×2)
  18:31:12.212 [ts-travel-service] 2024-12-07 18:31:12.212 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=a3f256c1-0  (×2)
  18:31:12.292 [ts-basic-service] 2024-12-07 18:31:12.291 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Nan
  18:31:12.472 [ts-travel-service] 2024-12-07 18:31:12.472 INFO 1 --- [io-12346-exec-9] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=f3d4d4ef-6  (×2)
  18:31:13.839 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:02:31:13 +0800] "GET /api/v1/admintravelservice/admintravel HTTP/1.1" 403 145 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Ap  (×11)
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  18:31:18.568 [ts-auth-service] 2024-12-07 18:31:18.568 INFO 1 --- [io-12340-exec-3] org.mongodb.driver.connection : Opened connection [connectionId{localValue:3, serverValue:22}] to ts-auth-m  (×2)
  18:31:19.324 [ts-travel-service] 2024-12-07 18:31:19.323 INFO 1 --- [io-12346-exec-5] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345
  18:31:19.687 [ts-travel2-service] 2024-12-07 18:31:19.687 ERROR 1 --- [o-16346-exec-10] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  18:31:27.403 [ts-travel-mongo] {"t":{"$date":"2024-12-07T18:31:27.403+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:28.268 [ts-admin-travel-service] 2024-12-07 18:31:28.268 ERROR 1 --- [io-16114-exec-5] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×8)
  18:31:29.841 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:31:29.841+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:30.519 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T18:31:30.518+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:31.065 [ts-auth-service] 2024-12-07 18:31:31.064 INFO 1 --- [o-12340-exec-10] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :fdse_microservice  (×2)
  18:31:32.280 [ts-admin-basic-info-service] 2024-12-07 18:31:32.280 ERROR 1 --- [io-18767-exec-3] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt  (×13)
  18:31:42.161 [ts-travel2-mongo] {"t":{"$date":"2024-12-07T18:31:42.161+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359630
  18:31:51.505 [ts-food-service] 2024-12-07 18:31:51.504 ERROR 1 --- [io-18856-exec-1] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)

## p0445
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T08:06:06.402Z
```
{"timestamp":1732349166402005000,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 08:06:06.401  INFO [carts,,,] 7 --- [           main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionHandler"}
```
Same service, the 2 minutes before (oldest first):
  08:05:31.806 [carts] 2024-11-23 08:05:31.806 INFO [carts,,,] 7 --- [-carts-db:27017] org.mongodb.driver.cluster : Monitor thread successfully connected to server with description Se
  08:05:45.411 [carts] 2024-11-23 08:05:45.411 INFO [carts,,,] 7 --- [ main] o.s.b.f.config.PropertiesFactoryBean : Loading properties file from class path resource [rest-default-mess
  08:06:00.413 [carts] 2024-11-23 08:06:00.413 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/health],methods=[GET]}" onto public java.util.Map<ja
  08:06:00.500 [carts] 2024-11-23 08:06:00.500 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[DE
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[POST],consumes
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[PATCH],consume
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items],methods=[GET],produces=
  08:06:00.501 [carts] 2024-11-23 08:06:00.501 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId:.*}/items/{itemId:.*}],methods=[GE
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}/merge],methods=[GET]}" onto publi
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[GET],produces=[applicat
  08:06:00.502 [carts] 2024-11-23 08:06:00.502 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/carts/{customerId}],methods=[DELETE]}" onto public v
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error],produces=[text/html]}" onto public org.spring
  08:06:00.505 [carts] 2024-11-23 08:06:00.505 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerMapping : Mapped "{[/error]}" onto public org.springframework.http.Respon
  08:06:03.410 [carts] 2024-11-23 08:06:03.409 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.context
  08:06:03.602 [carts] 2024-11-23 08:06:03.600 INFO [carts,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.ac
  08:06:05.306 [carts] 2024-11-23 08:06:05.304 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/webjars/**] onto handler of type [class org.sp
  08:06:05.306 [carts] 2024-11-23 08:06:05.305 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springfram
  08:06:05.306 [carts] 2024-11-23 08:06:05.306 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/browser/**] onto handler of type [class org.sp
  08:06:05.306 [carts] 2024-11-23 08:06:05.306 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/] onto handler of type [class org.spr
  08:06:05.306 [carts] 2024-11-23 08:06:05.306 INFO [carts,,,] 7 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/actuator/**] onto handler of type [class org.s
All services, 30 seconds either side (sampled):
  08:05:36.411 [front-end] Order response: {"statusCode":503,"body":"upstream connect error or disconnect/reset before headers. retried and the latest reset reason: remote connection fail  (×13)
  08:05:36.620 [user] ts=2024-11-23T08:05:36.620436853Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=67418cc9a437380001deec1a took=3.572043ms  (×59)
  08:05:37.558 [user] ts=2024-11-23T08:05:37.55870177Z caller=middlewares.go:46 method=Register username=QTNxlk email=QTNxlk@gmail.com took=2.268833ms
  08:05:39.084 [orders] 2024-11-23 08:05:38.992 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerAdapter : Detected ResponseBodyAdvice bean in org.springframework.boot.act
  08:05:39.193 [orders] 2024-11-23 08:05:39.193 INFO [orders,,,] 8 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}/{property}],methods=[DELETE],produc
  08:05:39.388 [orders] 2024-11-23 08:05:39.388 INFO [orders,,,] 8 --- [ main] .m.m.a.ExceptionHandlerExceptionResolver : Detected @ExceptionHandler methods in repositoryRestExceptionH
  08:05:41.192 [orders] 2024-11-23 08:05:41.192 INFO [orders,,,] 8 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json
  08:05:44.157 [front-end] Posting Customer: {"username":"zFrpP","password":"lvSXmE","email":"zFrpP@gmail.com","firstName":"zFrpP","lastName":"zFrpP"}
  08:05:46.020 [front-end] {"id":"3395a43e-2d88-40de-b95f-e00e1502085b","name":"Colourful","description":"proident occaecat irure et excepteur labore minim nisi amet irure","imageUrl":["/  (×2)
  08:05:49.233 [front-end] Posting Customer: {"username":"psXVPVgRfTd","password":"byGXeUSnN","email":"psXVPVgRfTd@gmail.com","firstName":"psXVPVgRfTd","lastName":"psXVPVgRfTd"}
  08:05:51.461 [front-end] Posting Customer: {"username":"JfkloKMY","password":"BAlPTCaswY","email":"JfkloKMY@gmail.com","firstName":"JfkloKMY","lastName":"JfkloKMY"}
  08:05:54.909 [shipping] 2024-11-23 08:05:54.909 INFO [shipping,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/refresh || /refresh.json],methods=[POST]}" onto publi
  08:05:57.198 [shipping] 2024-11-23 08:05:57.110 INFO [shipping,,,] 7 --- [ main] s.w.s.m.m.a.RequestMappingHandlerAdapter : Looking for @ControllerAdvice: org.springframework.boot.cont
  08:06:00.060 [front-end] Received response: "{\"firstName\":\"VGvhEBXruush\",\"lastName\":\"VGvhEBXruush\",\"username\":\"VGvhEBXruush\",\"id\":\"67418cd5a437380001deec3f\",\"_links\":{
  08:06:04.542 [front-end] Received response: "{\"firstName\":\"yeVOXGwCs\",\"lastName\":\"yeVOXGwCs\",\"username\":\"yeVOXGwCs\",\"id\":\"67418cd3a437380001deec3b\",\"_links\":{\"address
  08:06:07.002 [shipping] 2024-11-23 08:06:07.002 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[HEAD],produces=[applica
  08:06:07.099 [shipping] 2024-11-23 08:06:07.099 INFO [shipping,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[GET],produce  (×2)
  08:06:10.340 [front-end] Posting Customer: {"username":"djVRqry","password":"CJLHmVgJ","email":"djVRqry@gmail.com","firstName":"djVRqry","lastName":"djVRqry"}
  08:06:14.400 [shipping] 2024-11-23 08:06:14.400 INFO [shipping,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Located managed bean 'environmentManager': registering with JMX ser
  08:06:15.802 [carts] 2024-11-23 08:06:15.802 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/{id}],methods=[PATCH],produces=[applicati
  08:06:15.906 [carts] 2024-11-23 08:06:15.904 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.BasePathAwareHandlerMapping : Mapped "{[/browser],methods=[GET]}" onto public org.springframewor
  08:06:19.002 [carts] 2024-11-23 08:06:19.001 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/env/{name:.*}],methods=[GET],produces=[application/json]
  08:06:19.274 [front-end] Posting Customer: {"username":"ctDNRPS","password":"kZNuA","email":"ctDNRPS@gmail.com","firstName":"ctDNRPS","lastName":"ctDNRPS"}
  08:06:24.199 [carts] 2024-11-23 08:06:24.199 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshEndpoint' has been autodetected for JMX exposur  (×2)
  08:06:26.760 [front-end] Posting Customer: {"username":"KGcCpZnH","password":"FAILN","email":"KGcCpZnH@gmail.com","firstName":"KGcCpZnH","lastName":"KGcCpZnH"}
  08:06:30.125 [front-end] Posting Customer: {"username":"dRUZXQgdp","password":"cwnWjNOrJ","email":"dRUZXQgdp@gmail.com","firstName":"dRUZXQgdp","lastName":"dRUZXQgdp"}
  08:06:32.706 [carts] 2024-11-23 08:06:32.705 INFO [carts,2647ced1ca3ed2a8,2ee10f17902bcac4,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/ || ],m  (×3)
  08:06:34.501 [carts] 2024-11-23 08:06:34.501 INFO [carts,1e903490db126ed7,0f10e1096f3be1bd,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×4)
  08:06:35.986 [orders-db] {"t":{"$date":"2024-11-23T08:06:35.986+00:00"},"s":"I", "c":"STORAGE", "id":20320, "ctx":"conn5","msg":"createCollection","attr":{"namespace":"data.customerOrde  (×5)

## p0258
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:12.479Z
```
{"timestamp":1732242492479143200,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"POST /cart 500 34.190 ms - 64"}
```
Same service, the 2 minutes before (oldest first):
  02:28:11.984 [front-end] POST to carts: http://carts/carts/673fec32b0df5c00019af95d/items body: {"itemId":"837ab141-399e-4c1f-9abc-bace40296bac","unitPrice":15}
  02:28:12.002 [front-end] User cart deleted with status: 503  (×2)
  02:28:12.004 [front-end] DELETE /cart 503 - ms - -  (×2)
  02:28:12.011 [front-end] Attempting to add to cart: {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","quantity":1}  (×2)
  02:28:12.017 [front-end] {"id":"a0a4f044-b040-410d-8ead-4de0446aec7e","name":"Nerd leg","description":"For all those leg lovers out there. A perfect example of a swivel chair trained ca
  02:28:12.017 [front-end] POST to carts: http://carts/carts/673fec36b0df5c00019af96c/items body: {"itemId":"a0a4f044-b040-410d-8ead-4de0446aec7e","unitPrice":7.99}  (×2)
  02:28:12.038 [front-end] POST /cart 500 24.341 ms - 64  (×2)
  02:28:12.175 [front-end] GET /catalogue 200 - ms - -  (×2)
  02:28:12.251 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec35b0df5c00019af968"}
  02:28:12.260 [front-end] POST /addresses 200 - ms - -
  02:28:12.308 [front-end] Posting Card: {"longNum":"123123321","expires":"1232","ccv":"123","userID":"673fec35b0df5c00019af968"}
  02:28:12.316 [front-end] POST /cards 200 - ms - -
  02:28:12.361 [front-end] Attempting to delete cart for user: 673fec35b0df5c00019af968
  02:28:12.452 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×40)
  02:28:03.122 [front-end] GET /catalogue 200 - ms - -  (×43)
  02:28:03.196 [front-end] Received response: "{\"firstName\":\"FbddLnzSA\",\"lastName\":\"FbddLnzSA\",\"username\":\"FbddLnzSA\",\"id\":\"673fec21b0df5c00019af922\",\"_links\":{\"address
  02:28:03.245 [orders] 2024-11-22 02:28:03.244 ERROR [orders,,,] 6 --- [p-nio-80-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×16)
  02:28:03.391 [user] ts=2024-11-22T02:28:03.390808559Z caller=middlewares.go:46 method=Register username=kMzzAppFcYY email=kMzzAppFcYY@gmail.com took=958.317µs  (×5)
  02:28:03.523 [user] ts=2024-11-22T02:28:03.52331003Z caller=middlewares.go:46 method=Register username=sgQXbZQ email=sgQXbZQ@gmail.com took=1.065166ms
  02:28:05.055 [user] ts=2024-11-22T02:28:05.055011754Z caller=middlewares.go:104 method=GetAddresses id=673fec25b0df5c00019af92f result=1 took=781.934µs  (×18)
  02:28:06.796 [front-end] Posting Customer: {"username":"oyShDJ","password":"sWqvpeFZPy","email":"oyShDJ@gmail.com","firstName":"oyShDJ","lastName":"oyShDJ"}
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.451 [carts] 2024-11-22 02:28:10.451 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'environmentManager' has been autodetected for JMX expo
  02:28:11.984 [front-end] {"id":"837ab141-399e-4c1f-9abc-bace40296bac","name":"Cat socks","description":"consequat amet cupidatat minim laborum tempor elit ex consequat in","imageUrl":["  (×5)
  02:28:14.941 [carts] 2024-11-22 02:28:14.939 INFO [carts,,,] 7 --- [ main] s.b.c.e.t.TomcatEmbeddedServletContainer : Tomcat started on port(s): 80 (http)
  02:28:17.377 [front-end] Received response: "{\"firstName\":\"vtFUiCYPGkr\",\"lastName\":\"vtFUiCYPGkr\",\"username\":\"vtFUiCYPGkr\",\"id\":\"673fec2bb0df5c00019af944\",\"_links\":{\"a
  02:28:19.135 [carts] 2024-11-22 02:28:18.940 INFO [carts,cb305558d352107b,fbb223eea295e77c,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×15)
  02:28:21.967 [front-end] Posting Customer: {"username":"PDQejFz","password":"UItpfuss","email":"PDQejFz@gmail.com","firstName":"PDQejFz","lastName":"PDQejFz"}
  02:28:23.046 [orders] 2024-11-22 02:28:23.045 INFO [orders,42b8db16309cb127,ec51d06c93f89779,false] 6 --- [-nio-80-exec-10] w.w.s.o.controllers.OrdersController : Sending payment req  (×8)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.870 [front-end] Received response: "{\"firstName\":\"sgQXbZQ\",\"lastName\":\"sgQXbZQ\",\"username\":\"sgQXbZQ\",\"id\":\"673fec33b0df5c00019af963\",\"_links\":{\"addresses\":{
  02:28:25.536 [carts] 2024-11-22 02:28:25.536 INFO [carts,6520439a83bfe6a5,665041f8b8d92cb8,false] 7 --- [p-nio-80-exec-2] w.w.s.cart.controllers.ItemsController : Did not find item.  (×12)
  02:28:26.351 [queue-master] Received shipment task: 673fec2db0df5c00019af953  (×19)
  02:28:26.765 [orders] 2024-11-22 02:28:26.764 INFO [orders,9ff167fa001736c5,9aeb7d9b52262f94,false] 6 --- [p-nio-80-exec-9] org.mongodb.driver.connection : Opened connection [connect  (×7)
  02:28:26.959 [front-end] Order response: {"id":"673fec4ad94b9000069b39cf","customerId":"673fec36b0df5c00019af96c","customer":{"id":null,"firstName":"oyShDJ","lastName":"oyShDJ","usernam
  02:28:27.046 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d7","customerId":"673fec2fb0df5c00019af954","customer":{"id":null,"firstName":"uBxHmzyg","
  02:28:27.065 [front-end] Order response: {"id":"673fec4ad94b9000069b39d4","customerId":"673fec33b0df5c00019af963","customer":{"id":null,"firstName":"sgQXbZQ","lastName":"sgQXbZQ","usern
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory at org.newsclub.net.unix.NativeUnixSocket.connect(Native Method) ~[unix-socket
  02:28:33.840 [front-end] Posting Customer: {"username":"MywYMGzyoIdhsgg","password":"SiEqM","email":"MywYMGzyoIdhsgg@gmail.com","firstName":"MywYMGzyoIdhsgg","lastName":"MywYMGzyoIdhsgg
  02:28:38.668 [front-end] Received response: "{\"firstName\":\"PDQejFz\",\"lastName\":\"PDQejFz\",\"username\":\"PDQejFz\",\"id\":\"673fec45b0df5c00019af990\",\"_links\":{\"addresses\":{
  02:28:40.321 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec58d94b9000069b39dd","customerId":"673fec38b0df5c00019af971","customer":{"id":null,"firstName":"nbZCdAQyR",
  02:28:42.062 [front-end] Received response: "{\"firstName\":\"XaRPipq\",\"lastName\":\"XaRPipq\",\"username\":\"XaRPipq\",\"id\":\"673fec41b0df5c00019af98d\",\"_links\":{\"addresses\":{

## p0091
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service mobservice2, 2021-08-13T20:41:00.048Z
```
{"service":"mobservice2","message":"2021-08-13 20:41:00,048 | ERROR | 0.0.0.4 | mobservice2 | mob_helper.py -> mob_info_to_redis -> 88 | 151769695153043e | uuid:afbf79cc-fc33-11eb-8bef-0242ac110004 information has expired, mobile phone login is invalid"}
```
Same service, the 2 minutes before (oldest first):
  20:40:45.844 [mobservice2] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'adde7ec8-fc33-11eb-ba14-0242ac110004', 'value': 'ERSdWpfg'}  (×4)
  20:40:45.888 [mobservice2] INFO info adde7ec8-fc33-11eb-ba14-0242ac110004:ERSdWpfg write success
  20:40:46.597 [mobservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×4)
  20:40:46.597 [mobservice2] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×4)
  20:40:46.597 [mobservice2] INFO request http://0.0.0.2:9387/get_value_from_redis and param={'keys': 'ae586c74-fc33-11eb-bc64-0242ac110003'}  (×4)
  20:40:46.724 [mobservice2] INFO info ae586c74-fc33-11eb-bc64-0242ac110003:piekgYwo write success
  20:40:48.266 [mobservice2] INFO info af4d8d9e-fc33-11eb-9f87-0242ac110003:SYUdXTMn write success
  20:40:48.681 [mobservice2] INFO info af86ec06-fc33-11eb-b36b-0242ac110004:HxQpIWMr write success
All services, 30 seconds either side (sampled):
  20:40:30.115 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×36)
  20:40:30.289 [webservice1] INFO call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×36)
  20:40:30.515 [logservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×38)
  20:40:30.622 [logservice1] INFO the list of all available services are dbservice1: http://0.0.0.4:9388, dbservice2: http://0.0.0.2:9389  (×38)
  20:40:30.819 [dbservice1] INFO a4aa936e-fc33-11eb-864d-0242ac110003-ohjceMiy-I2a}pKgH4W#_ token generate success token=MTYyODg1ODQzMC44MTkyMjcyOmE0YWE5MzZlLWZjMzMtMTFlYi04NjRkLTAyNDJhYzE
  20:40:31.334 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'a536127c-fc33-11eb-8b23-0242ac110003', 'value': 'bNtPLwUk'}  (×28)
  20:40:31.577 [logservice1] INFO now call service:logservice2, inst:http://0.0.0.2:9385 as a downstream service  (×27)
  20:40:31.834 [dbservice1] INFO a524d318-fc33-11eb-acc5-0242ac110003-zBtAqOdX-dNtBkshuAxiD token generate success token=MTYyODg1ODQzMS44MzQzMTE6YTUyNGQzMTgtZmMzMy0xMWViLWFjYzUtMDI0MmFjMTE  (×2)
  20:40:32.842 [webservice2] INFO uuid: a63f3e78-fc33-11eb-89f3-0242ac110004 write redis successfully  (×32)
  20:40:34.314 [mobservice1] INFO info a6f8da36-fc33-11eb-907c-0242ac110003:nxGFAjVa write success
  20:40:36.713 [mobservice2] INFO info a860cce4-fc33-11eb-8373-0242ac110004:eNWPvrgG write success
  20:40:38.756 [dbservice1] INFO a96329a2-fc33-11eb-b405-0242ac110003-HYsctkhi-NFMe>j?6OAvx token generate success token=MTYyODg1ODQzOC43NTYwMDE1OmE5NjMyOWEyLWZjMzMtMTFlYi1iNDA1LTAyNDJhYzE
  20:40:40.871 [mobservice2] INFO info aae38326-fc33-11eb-9d86-0242ac110003:OKolGsUM write success
  20:40:43.333 [dbservice1] INFO ac15e5e0-fc33-11eb-a727-0242ac110004-vUOZQjfI-:siR+JHw*zYA token generate success token=MTYyODg1ODQ0My4zMzI5NzI4OmFjMTVlNWUwLWZjMzMtMTFlYi1hNzI3LTAyNDJhYzE
  20:40:45.831 [mobservice1] INFO info add101c6-fc33-11eb-a27b-0242ac110004:gKPfDFAT write success
  20:40:47.862 [dbservice1] INFO aed33b48-fc33-11eb-a46c-0242ac110004-YXLKvufE-RlNLZm@n6u!V token generate success token=MTYyODg1ODQ0Ny44NjIxMDk3OmFlZDMzYjQ4LWZjMzMtMTFlYi1hNDZjLTAyNDJhYzE
  20:40:54.540 [mobservice1] INFO info b2fcaa24-fc33-11eb-b529-0242ac110003:rXbZtUoM write success
  20:41:00.180 [logservice1] ERROR uuid expired, invalid phone request
  20:41:03.049 [mobservice2] INFO info b81687d2-fc33-11eb-b7f2-0242ac110003:PBlgjmAH write success
  20:41:12.419 [mobservice1] ERROR uuid:b71f45bc-fc33-11eb-80dd-0242ac110004 information has expired, mobile phone login is invalid
  20:41:14.542 [mobservice1] INFO info beece31c-fc33-11eb-ab45-0242ac110004:ahqTsjZo write success
  20:41:16.745 [dbservice2] INFO c008bc9e-fc33-11eb-8218-0242ac110004-chfTZIqp-uM7{Uk9q0Q>% token generate success token=MTYyODg1ODQ3Ni43NDU0MTQ1OmMwMDhiYzllLWZjMzMtMTFlYi04MjE4LTAyNDJhYzE
  20:41:18.534 [dbservice1] INFO c11f0304-fc33-11eb-a2ee-0242ac110004-OiYedVug-CgNB*r/q!wic token generate success token=MTYyODg1ODQ3OC41MzQzOTQzOmMxMWYwMzA0LWZjMzMtMTFlYi1hMmVlLTAyNDJhYzE
  20:41:20.800 [dbservice2] INFO c25ce7fe-fc33-11eb-8961-0242ac110003-suCOBkmp-=SHq@W8nJ7Me token generate success token=MTYyODg1ODQ4MC43OTk3ODM3OmMyNWNlN2ZlLWZjMzMtMTFlYi04OTYxLTAyNDJhYzE
  20:41:23.302 [mobservice1] INFO info c4249ef6-fc33-11eb-8d06-0242ac110004:DjVLApUI write success
  20:41:26.051 [mobservice2] INFO info c5b9a702-fc33-11eb-b5a6-0242ac110003:zWnEcpYU write success
  20:41:28.701 [dbservice1] INFO c7353e3e-fc33-11eb-8ff0-0242ac110004-wzNVdLGu->w?zB:biZ0y_ token generate success token=MTYyODg1ODQ4OC43MDA4Mjk6YzczNTNlM2UtZmMzMy0xMWViLThmZjAtMDI0MmFjMTE

## p0581
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-other-service, 2024-12-07T18:31:21.809Z
```
{"timestamp":1733596281809381600,"container_name":"ts-order-other-service","pod_name":"ts-order-other-service-746fccc88f-4lb46","node_name":"ip-192-168-55-200.ap-southeast-2.compute.internal","message":"2024-12-07 18:31:21.808 ERROR 1 --- [io-12032-exec-4] edu.fudan.common.security.jwt.JWTUtil    : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwtException: JWT strings must contain exactly 2 period characters. Found: 0"}
```
Same service, the 2 minutes before (oldest first):
  18:31:06.805 [ts-order-other-service] 2024-12-07 18:31:06.805 INFO 1 --- [io-12032-exec-8] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×7)
  18:31:07.705 [ts-order-other-service] 2024-12-07 18:31:07.705 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0
  18:31:07.707 [ts-order-other-service] 2024-12-07 18:31:07.707 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0
  18:31:07.938 [ts-order-other-service] 2024-12-07 18:31:07.938 INFO 1 --- [io-12032-exec-4] other.controller.OrderOtherController : [Order Other Service][Query Orders] Query Orders for   (×2)
  18:31:07.942 [ts-order-other-service] 2024-12-07 18:31:07.941 ERROR 1 --- [io-12032-exec-4] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×2)
  18:31:07.942 [ts-order-other-service] java.lang.IllegalArgumentException: Invalid UUID string: at java.util.UUID.fromString(UUID.java:194) ~[na:1.8.0_402] at other.service.OrderOtherServiceImpl.quer  (×2)
  18:31:09.375 [ts-order-other-service] 2024-12-07 18:31:09.375 INFO 1 --- [io-12032-exec-7] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×2)
  18:31:09.378 [ts-order-other-service] 2024-12-07 18:31:09.378 INFO 1 --- [io-12032-exec-7] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 0  (×2)
  18:31:12.237 [ts-order-other-service] 2024-12-07 18:31:12.236 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM
All services, 30 seconds either side (sampled):
  18:30:52.162 [ts-auth-mongo] {"t":{"$date":"2024-12-07T18:30:52.161+00:00"},"s":"I", "c":"NETWORK", "id":22943, "ctx":"listener","msg":"Connection accepted","attr":{"remote":"127.0.0.6:4914  (×4)
  18:30:53.492 [ts-basic-service] 2024-12-07 18:30:53.491 INFO 1 --- [io-15680-exec-5] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Station Id] Station Id: Sha  (×49)
  18:30:53.549 [ts-basic-service] 2024-12-07 18:30:53.549 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: 0b23  (×4)
  18:30:53.576 [ts-travel2-service] 2024-12-07 18:30:53.576 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave  (×7)
  18:30:53.663 [ts-seat-service] 2024-12-07 18:30:53.662 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The result of getTrainTypeResult is Re  (×23)
  18:30:53.756 [ts-route-service] 2024-12-07 18:30:53.756 INFO 1 --- [o-11178-exec-10] route.controller.RouteController : Route id: 9fc9c261-3263-4bfa-82f8-bb44e06b2f52  (×10)
  18:30:57.121 [ts-seat-service] 2024-12-07 18:30:57.121 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is confortClass 
  18:30:58.158 [ts-travel2-service] 2024-12-07 18:30:58.158 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  18:31:00.863 [ts-auth-service] 2024-12-07 18:31:00.862 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.security.web.util.matcher.AnyReques
  18:31:01.962 [ts-auth-service] 2024-12-07 18:31:01.962 INFO 1 --- [ main] o.s.w.s.handler.SimpleUrlHandlerMapping : Mapped URL path [/**] onto handler of type [class org.springframework.web.s
  18:31:03.838 [ts-travel-service] 2024-12-07 18:31:03.838 INFO 1 --- [io-12346-exec-1] travel.service.TravelServiceImpl : Route is: Route{id='92708982-77af-4318-be25-57ccb0ff69ad', stations=[nan  (×14)
  18:31:03.867 [ts-auth-service] 2024-12-07 18:31:03.867 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/autoconfig || /autoconfig.json],methods=[GET],produces=[application
  18:31:03.872 [ts-auth-service] 2024-12-07 18:31:03.872 INFO 1 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/metrics/{name:.*}],methods=[GET],produces=[application/vnd.spring-b
  18:31:03.916 [ts-order-service] 2024-12-07 18:31:03.916 INFO 1 --- [io-12031-exec-8] order.service.OrderServiceImpl : [Order Service][Calculate Sold Ticket] Get Orders Number: 38  (×5)
  18:31:04.061 [ts-auth-service] 2024-12-07 18:31:04.061 INFO 1 --- [ main] o.s.s.web.DefaultSecurityFilterChain : Creating filter chain: org.springframework.boot.actuate.autoconfigure.Manageme
  18:31:06.711 [ts-basic-service] 2024-12-07 18:31:06.711 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: d693  (×4)
  18:31:08.394 [ts-auth-service] 2024-12-07 18:31:08.394 INFO 1 --- [ main] trationDelegate$BeanPostProcessorChecker : Bean 'org.springframework.security.config.annotation.configuration.ObjectP
  18:31:09.467 [ts-auth-service] 2024-12-07 18:31:09.467 INFO 1 --- [ main] o.s.i.channel.PublishSubscribeChannel : Channel 'ts-auth-service:12340.errorChannel' has 1 subscriber(s).
  18:31:11.697 [ts-travel-service] 2024-12-07 18:31:11.697 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Get Route By Trip ID] TripId: G1234  (×5)
  18:31:12.245 [ts-basic-service] 2024-12-07 18:31:12.245 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: a3f2
  18:31:17.162 [ts-auth-service] 2024-12-07 18:31:17.162 INFO 1 --- [io-12340-exec-2] o.a.c.c.C.[Tomcat].[localhost].[/] : Initializing Spring FrameworkServlet 'dispatcherServlet'
  18:31:19.313 [ts-food-map-service] 2024-12-07 18:31:19.313 INFO 1 --- [io-18855-exec-1] food.controller.TrainFoodController : [Food Map Service][Get TrainFoods By TripId]
  18:31:20.904 [ts-travel-service] 2024-12-07 18:31:20.904 ERROR 1 --- [io-12346-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×3)
  18:31:28.040 [ts-auth-service] 2024-12-07 18:31:28.039 INFO 1 --- [io-12340-exec-7] auth.security.UserDetailsServiceImpl : UsernamePasswordAuthenticationToken username :admin  (×6)
  18:31:29.879 [ts-consign-mongo] {"t":{"$date":"2024-12-07T18:31:29.879+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359628
  18:31:30.949 [ts-order-mongo] {"t":{"$date":"2024-12-07T18:31:30.949+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173359629
  18:31:32.290 [ts-admin-basic-info-service] 2024-12-07 18:31:32.289 ERROR 1 --- [io-18767-exec-3] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in context with   (×8)
  18:31:44.201 [ts-admin-basic-info-service] 2024-12-07 18:31:44.201 ERROR 1 --- [o-18767-exec-10] edu.fudan.common.security.jwt.JWTUtil : Token is not properly constructed: {} io.jsonwebtoken.MalformedJwt

## p0609
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-order-other-service, 2024-12-07T20:10:50.487Z
```
{"timestamp":1733602250487238400,"container_name":"ts-order-other-service","pod_name":"ts-order-other-service-746fccc88f-4npbx","node_name":"ip-192-168-69-80.ap-southeast-2.compute.internal","message":"2024-12-07 20:10:50.487  INFO 1 --- [io-12032-exec-1] other.controller.OrderOtherController    : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00 GMT 2024 TrainNumber: Z1236"}
```
Same service, the 2 minutes before (oldest first):
  20:10:29.885 [ts-order-other-service] 2024-12-07 20:10:29.884 INFO 1 --- [io-12032-exec-9] other.controller.OrderOtherController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:0  (×4)
  20:10:29.887 [ts-order-other-service] 2024-12-07 20:10:29.887 INFO 1 --- [io-12032-exec-9] other.service.OrderOtherServiceImpl : [Order Other Service][Calculate Sold Ticket] Get Orders Number: 52  (×4)
  20:10:29.969 [ts-order-other-service] 2024-12-07 20:10:29.969 INFO 1 --- [o-12032-exec-10] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×2)
  20:10:29.972 [ts-order-other-service] 2024-12-07 20:10:29.972 INFO 1 --- [o-12032-exec-10] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392
  20:10:30.052 [ts-order-other-service] 2024-12-07 20:10:30.052 INFO 1 --- [io-12032-exec-2] other.controller.OrderOtherController : [Order Other Service][Get Sold Ticket] Date: Sat Dec 07 00:00:00 GM  (×6)
  20:10:30.055 [ts-order-other-service] 2024-12-07 20:10:30.054 INFO 1 --- [io-12032-exec-2] other.service.OrderOtherServiceImpl : Left ticket info is: LeftTicketInfo{soldTickets=[Ticket(seatNo=127392  (×3)
All services, 30 seconds either side (sampled):
  20:10:20.565 [ts-auth-service] 2024-12-07 20:10:20.564 INFO 1 --- [io-12340-exec-5] auth.service.impl.TokenServiceImpl : eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJmZHNlX21pY3Jvc2VydmljZSIsInJvbGVzIjpbI  (×20)
  20:10:20.626 [ts-basic-service] 2024-12-07 20:10:20.625 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : [Basic Information Service][Check Station Exists] Station Name: N  (×16)
  20:10:20.670 [ts-basic-service] 2024-12-07 20:10:20.669 INFO 1 --- [io-15680-exec-8] f.microservice.service.BasicServiceImpl : indexStart : 0 __ indexEnd : 1  (×25)
  20:10:20.746 [ts-travel2-service] 2024-12-07 20:10:20.746 INFO 1 --- [io-16346-exec-6] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1234  (×25)
  20:10:20.826 [ts-seat-service] 2024-12-07 20:10:20.826 INFO 1 --- [io-18898-exec-3] seat.service.SeatServiceImpl : Seat request To String: Seat{travelDate=Sat Dec 07 00:00:00 GMT 2024, trainN  (×44)
  20:10:20.885 [ts-travel2-service] 2024-12-07 20:10:20.885 INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：0 time: Sat May 04 01:51:52 GMT 2013  (×22)
  20:10:23.399 [ts-travel-service] 2024-12-07 20:10:23.399 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×18)
  20:10:26.370 [ts-auth-service] 2024-12-07 20:10:26.369 INFO 1 --- [io-12340-exec-9] auth.service.impl.TokenServiceImpl : LOGIN USER :admin __ 222222 __ null  (×8)
  20:10:27.552 [ts-admin-basic-info-service] 2024-12-07 20:10:27.552 INFO 1 --- [io-18767-exec-9] a.service.AdminBasicInfoServiceImpl : [!!!!GetAllPriceResult]   (×8)
  20:10:28.435 [ts-config-mongo] {"t":{"$date":"2024-12-07T20:10:28.435+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360222
  20:10:31.028 [ts-food-mongo] {"t":{"$date":"2024-12-07T20:10:31.027+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360223
  20:10:32.148 [ts-order-mongo] {"t":{"$date":"2024-12-07T20:10:32.148+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360223
  20:10:33.722 [ts-order-service] 2024-12-07 20:10:33.720 INFO 1 --- [io-12031-exec-9] order.controller.OrderController : [Order Other Service][Calculate Sold Tickets] Date: Sat Dec 07 00:00:00   (×10)
  20:10:33.812 [ts-travel-service] 2024-12-07 20:10:33.812 INFO 1 --- [io-12346-exec-6] travel.service.TravelServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Inter  (×22)
  20:10:34.152 [ts-travel-service] 2024-12-07 20:10:34.152 INFO 1 --- [io-12346-exec-7] travel.controller.TravelController : [Get Route By Trip ID] TripId: D1345  (×10)
  20:10:39.930 [ts-basic-service] 2024-12-07 20:10:39.930 INFO 1 --- [io-15680-exec-4] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query For Price Config] RouteId: aefc
  20:10:43.207 [ts-travel-service] 2024-12-07 20:10:43.207 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : [Travel Service][Get Route By Id] Route ID：92708982-77af-4318-be25-57ccb  (×11)
  20:10:50.640 [ts-seat-service] 2024-12-07 20:10:50.639 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat
  20:10:56.051 [ts-travel-service] 2024-12-07 20:10:56.051 INFO 1 --- [io-12346-exec-3] travel.service.TravelServiceImpl : [Train Service] calculate time：0 time: Fri May 03 23:00:00 GMT 2013  (×4)
  20:10:58.660 [ts-consign-service] 2024-12-07 20:10:58.660 INFO 1 --- [o-16111-exec-10] consign.service.ConsignServiceImpl : [Consign servie] [ Insert new consign record] 3c56a662-36e2-4561-a350-
  20:11:00.087 [ts-basic-service] 2024-12-07 20:11:00.087 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Success.
  20:11:12.868 [ts-travel-service] 2024-12-07 20:11:12.867 INFO 1 --- [o-12346-exec-10] travel.service.TravelServiceImpl : Query for Station id is: Response(status=1, msg=Success, data=shanghai)  (×3)
  20:11:13.203 [ts-contacts-service] 2024-12-07 20:11:13.203 INFO 1 --- [io-12347-exec-1] contacts.controller.ContactsController : [ContactsService][VerifyLogin] Success
  20:11:13.247 [ts-security-service] 2024-12-07 20:11:13.246 INFO 1 --- [io-11188-exec-9] security.service.SecurityServiceImpl : [Security Service][Get Order Info For Security] Last One Hour: 26 To
  20:11:13.297 [ts-contacts-service] 2024-12-07 20:11:13.297 INFO 1 --- [io-12347-exec-2] contacts.controller.ContactsController : [ContactsService][Contacts Id Print] d14da0ec-da93-46c3-842d-23fc3
  20:11:13.585 [ts-preserve-service] 2024-12-07 20:11:13.585 INFO 1 --- [io-14568-exec-2] preserve.service.PreserveServiceImpl : TripResponse:TripResponse(tripId=D1345, startingStation=Shang Hai, t
  20:11:13.703 [ts-seat-service] 2024-12-07 20:11:13.703 INFO 1 --- [io-18898-exec-6] seat.service.SeatServiceImpl : [SeatService distributeSeat] Use a new seat number! 800631439
  20:11:13.745 [ts-assurance-service] 2024-12-07 20:11:13.745 INFO 1 --- [io-18888-exec-5] assurance.service.AssuranceServiceImpl : [Assurance-Add&Delete-Service][AddAssurance] Success.

## p0135
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service adservice, 2024-11-18T05:31:14.646Z
```
{"timestamp":1731907874646909700,"container_name":"adservice","pod_name":"adservice-b9bcc6cc9-sdkf5","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"received ad request (context_words=[kitchen])"}
```
Same service, the 2 minutes before (oldest first):
  05:31:12.168 [adservice] received ad request (context_words=[])  (×2)
  05:31:13.252 [adservice] received ad request (context_words=[clothing, tops])
  05:31:13.958 [adservice] received ad request (context_words=[kitchen])  (×2)
  05:31:13.997 [adservice] received ad request (context_words=[hair, beauty])
All services, 30 seconds either side (sampled):
  05:31:12.113 [frontend] request started  (×181)
  05:31:12.116 [currencyservice] Getting supported currencies...  (×148)
  05:31:12.130 [currencyservice] conversion request successful  (×420)
  05:31:12.168 [adservice] received ad request (context_words=[])  (×21)
  05:31:12.225 [frontend] setting currency  (×12)
  05:31:13.241 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '1YMWWN1N4O', '0PUK6V6EV0', '9SIQT8TOJO', 'L9ECAV7KIM']  (×121)
  05:31:13.958 [adservice] received ad request (context_words=[kitchen])  (×31)
  05:31:15.546 [adservice] received ad request (context_words=[decor, home])  (×9)
  05:31:16.969 [frontend] adding to cart  (×21)
  05:31:16.983 [frontend] view user cart  (×34)
  05:31:17.008 [shippingservice] [GetQuote] completed request  (×40)
  05:31:17.030 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="EUR"
  05:31:17.056 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"139","nanos":655019905},"credit_card":{"credit_card_number":"49231259390927
  05:31:17.058 [checkoutservice] payment went through (transaction_id: f193f55b-9ec1-41b5-abef-e610b8b840af)  (×6)
  05:31:17.059 [shippingservice] [ShipOrder] completed request  (×6)
  05:31:17.070 [emailservice] A request to send order confirmation email to curtis26@example.org has been received.
  05:31:17.072 [frontend] order placed  (×6)
  05:31:17.380 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"29721","nanos":50862865},"credit_card":{"credit_card_number":"4397529817152  (×2)
  05:31:17.393 [emailservice] A request to send order confirmation email to beckrobert@example.net has been received.
  05:31:18.456 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '1YMWWN1N4O']
  05:31:18.597 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"2702","nanos":280000000},"credit_card":{"credit_card_number":"4761344760685
  05:31:18.613 [emailservice] A request to send order confirmation email to etate@example.com has been received.
  05:31:20.895 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '66VCHSJNUP', '1YMWWN1N4O']  (×2)
  05:31:31.384 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="TRY"  (×2)
  05:31:31.434 [paymentservice] Transaction processed: visa ending 2674 Amount: TRY7986.543787768  (×2)
  05:31:31.447 [checkoutservice] order confirmation email sent to "ncoleman@example.com"
  05:31:34.240 [checkoutservice] order confirmation email sent to "stephanieadams@example.org"
  05:31:37.485 [checkoutservice] order confirmation email sent to "jeffrey07@example.org"

## p0247
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service front-end, 2024-11-22T02:28:05.172Z
```
{"timestamp":1732242485172132400,"container_name":"front-end","pod_name":"front-end-f77549869-gj5b4","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"Received response: \"{\\\"_embedded\\\":{\\\"address\\\":[{\\\"street\\\":\\\"123\\\",\\\"number\\\":\\\"123\\\",\\\"country\\\":\\\"123\\\",\\\"city\\\":\\\"123\\\",\\\"postcode\\\":\\\"123\\\",\\\"id\\\":\\\"673fec29b0df5c00019af940\\\",\\\"_links\\\":{\\\"address\\\":{\\\"href\\\":\\\"http://user/addresses/673fec29b0df5c00019af940\\\"},\\\"self\\\":{\\\"href\\\":\\\"http://user/addresses/673fec29b0df5c00019af940\\\"}}}]}}\\n\""}
```
Same service, the 2 minutes before (oldest first):
  02:28:05.033 [front-end] Received response: "{\"firstName\":\"NWbwBHv\",\"lastName\":\"NWbwBHv\",\"username\":\"NWbwBHv\",\"id\":\"673fec1db0df5c00019af90f\",\"_links\":{\"addresses\":{
  02:28:05.033 [front-end] GET Request to: http://user/customers/673fec1db0df5c00019af90f/addresses  (×4)
  02:28:05.047 [front-end] Received response: "{\"_embedded\":{\"address\":[{\"street\":\"123\",\"number\":\"123\",\"country\":\"123\",\"city\":\"123\",\"postcode\":\"123\",\"id\":\"673fe
  02:28:05.047 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673fec25b0df5c00019af930\",\"_links\":{\"
  02:28:05.047 [front-end] [ undefined, undefined ]
  02:28:05.047 [front-end] Posting Order: {"customer":"http://user/customers/673fec1db0df5c00019af90f","address":"http://user/addresses/673fec25b0df5c00019af92f","card":"http://user/cards
  02:28:05.062 [front-end] User cart deleted with status: 503
  02:28:05.065 [front-end] DELETE /cart 503 - ms - -
  02:28:05.071 [front-end] Attempting to add to cart: {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","quantity":1}
  02:28:05.078 [front-end] {"id":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","name":"Crossed","description":"A mature sock, crossed, with an air of nonchalance.","imageUrl":["/catalogue/images
  02:28:05.078 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af952/items body: {"itemId":"808a2de1-1aaa-4c25-a9b9-6612e8f29a38","unitPrice":17.32}
  02:28:05.097 [front-end] Order response: {"statusCode":500,"body":{"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","
  02:28:05.097 [front-end] Order response: {"timestamp":1732242485094,"status":500,"error":"Internal Server Error","exception":"java.lang.IllegalStateException","message":"Unable to creat
  02:28:05.100 [front-end] POST /orders 500 - ms - -
  02:28:05.146 [front-end] POST /cart 500 72.021 ms - 64
  02:28:05.160 [front-end] Request received with body: {}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
All services, 30 seconds either side (sampled):
  02:28:03.042 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"673fec2db0df5c00019af953"}  (×32)
  02:28:03.118 [catalogue] ts=2024-11-22T02:28:03Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.040202ms  (×36)
  02:28:03.190 [front-end] POST to carts: http://carts/carts/673fec2db0df5c00019af953/items body: {"itemId":"3395a43e-2d88-40de-b95f-e00e1502085b","unitPrice":18}  (×18)
  02:28:03.211 [user] ts=2024-11-22T02:28:03.211690554Z caller=middlewares.go:75 method=GetUsers id=673fec21b0df5c00019af922 result=1 took=1.207621ms  (×36)
  02:28:03.252 [front-end] POST /orders 500 - ms - -  (×30)
  02:28:03.410 [front-end] Carts merged.  (×31)
  02:28:04.929 [front-end] Posting Customer: {"username":"JGQXvUjPbFrtK","password":"HtglbTyNG","email":"JGQXvUjPbFrtK@gmail.com","firstName":"JGQXvUjPbFrtK","lastName":"JGQXvUjPbFrtK"}
  02:28:05.166 [front-end] Received response: "{\"firstName\":\"eqCNYXcvyTG\",\"lastName\":\"eqCNYXcvyTG\",\"username\":\"eqCNYXcvyTG\",\"id\":\"673fec20b0df5c00019af91e\",\"_links\":{\"a
  02:28:06.800 [user] ts=2024-11-22T02:28:06.800234478Z caller=middlewares.go:46 method=Register username=oyShDJ email=oyShDJ@gmail.com took=993.111µs
  02:28:08.952 [user] ts=2024-11-22T02:28:08.951992308Z caller=middlewares.go:46 method=Register username=nbZCdAQyR email=nbZCdAQyR@gmail.com took=1.083076ms
  02:28:10.445 [carts] 2024-11-22 02:28:10.445 INFO [carts,,,] 7 --- [ main] o.s.j.e.a.AnnotationMBeanExporter : Bean with name 'refreshScope' has been autodetected for JMX exposure
  02:28:11.650 [front-end] Received response: "{\"firstName\":\"YmTwTEt\",\"lastName\":\"YmTwTEt\",\"username\":\"YmTwTEt\",\"id\":\"673fec2ab0df5c00019af942\",\"_links\":{\"addresses\":{
  02:28:14.197 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×4)
  02:28:16.205 [front-end] Received response: "{\"firstName\":\"WiHheQzgSpJzgy\",\"lastName\":\"WiHheQzgSpJzgy\",\"username\":\"WiHheQzgSpJzgy\",\"id\":\"673fec2db0df5c00019af952\",\"_lin
  02:28:17.879 [user] ts=2024-11-22T02:28:17.879034554Z caller=middlewares.go:46 method=Register username=QGHrdp email=QGHrdp@gmail.com took=1.008054ms
  02:28:19.969 [carts] 2024-11-22 02:28:19.969 INFO [carts,36afebe61b500330,bce545f5625d769a,false] 7 --- [-nio-80-exec-12] org.mongodb.driver.connection : Opened connection [connecti  (×4)
  02:28:21.971 [user] ts=2024-11-22T02:28:21.971606392Z caller=middlewares.go:46 method=Register username=PDQejFz email=PDQejFz@gmail.com took=1.195014ms
  02:28:23.061 [payment] ts=2024-11-22T02:28:23Z caller=logging.go:29 method=Authorise result=true took=1.213µs  (×4)
  02:28:23.586 [shipping] 2024-11-22 02:28:23.586 INFO [shipping,,,] 7 --- [p-nio-80-exec-4] o.s.web.servlet.DispatcherServlet : FrameworkServlet 'dispatcherServlet': initialization comp
  02:28:24.819 [front-end] Received response: "{\"firstName\":\"KoWsmDtUqsE\",\"lastName\":\"KoWsmDtUqsE\",\"username\":\"KoWsmDtUqsE\",\"id\":\"673fec2cb0df5c00019af949\",\"_links\":{\"a
  02:28:25.463 [carts-db] {"t":{"$date":"2024-11-22T02:28:25.462+00:00"},"s":"I", "c":"INDEX", "id":20345, "ctx":"conn10","msg":"Index build: done building","attr":{"buildUUID":null,"nam
  02:28:25.786 [shipping] 2024-11-22 02:28:25.786 INFO [shipping,fb98be28dae5ea9a,b566bc7933720160,false] 7 --- [p-nio-80-exec-6] o.s.amqp.rabbit.core.RabbitAdmin : Auto-declaring a non-
  02:28:26.669 [front-end] Posting Customer: {"username":"YUPgfoSQ","password":"QfAdlpOVE","email":"YUPgfoSQ@gmail.com","firstName":"YUPgfoSQ","lastName":"YUPgfoSQ"}
  02:28:26.957 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d6","customerId":"673fec35b0df5c00019af969","customer":{"id":null,"firstName":"vuOxCKL","l
  02:28:26.962 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d3","customerId":"673fec34b0df5c00019af964","customer":{"id":null,"firstName":"JGQXvUjPbFr
  02:28:27.060 [front-end] Order response: {"statusCode":201,"body":{"id":"673fec4ad94b9000069b39d2","customerId":"673fec34b0df5c00019af967","customer":{"id":null,"firstName":"HFHBXn","la
  02:28:27.463 [orders-db] {"t":{"$date":"2024-11-22T02:28:27.462+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173224250
  02:28:31.413 [user] ts=2024-11-22T02:28:31.413284511Z caller=middlewares.go:46 method=Register username=Wcxwva email=Wcxwva@gmail.com took=994.783µs
  02:28:32.341 [queue-master] Caused by: java.lang.RuntimeException: org.newsclub.net.unix.AFUNIXSocketException: No such file or directory (socket: /var/run/docker.sock) at com.google.commo
  02:28:32.647 [queue-master] 2024-11-22 02:28:32.647 INFO 6 --- [ool-6-thread-10] o.apache.http.impl.execchain.RetryExec : Retrying request to {}->unix://localhost:80  (×12)

## p0366
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service user, 2024-11-22T03:36:43.853Z
```
{"timestamp":1732246603853461500,"container_name":"user","pod_name":"user-558cdfd768-wmzlf","node_name":"ip-192-168-62-166.ap-southeast-2.compute.internal","message":"ts=2024-11-22T03:36:43.853241773Z caller=middlewares.go:46 method=Register username=ytBoY email=ytBoY@gmail.com took=982.502µs"}
```
Same service, the 2 minutes before (oldest first):
  03:36:42.298 [user] ts=2024-11-22T03:36:42.298673628Z caller=middlewares.go:75 method=GetUsers id=673ffc31b0df5c00019b2a3b result=1 took=845.23µs  (×11)
  03:36:42.313 [user] ts=2024-11-22T03:36:42.313828237Z caller=middlewares.go:104 method=GetAddresses id=673ffc3bb0df5c00019b2a57 result=1 took=747.68µs  (×2)
  03:36:42.313 [user] ts=2024-11-22T03:36:42.31383097Z caller=middlewares.go:134 method=GetCards id=673ffc3bb0df5c00019b2a58 result=1 took=764.785µs  (×3)
  03:36:42.319 [user] ts=2024-11-22T03:36:42.31901963Z caller=middlewares.go:104 method=GetAddresses id=673ffc3bb0df5c00019b2a59 result=1 took=1.167349ms
  03:36:42.406 [user] ts=2024-11-22T03:36:42.40666827Z caller=middlewares.go:75 method=GetUsers id=673ffc39b0df5c00019b2a4e result=1 took=1.016173ms
  03:36:43.466 [user] ts=2024-11-22T03:36:43.466223645Z caller=middlewares.go:88 method=PostAddress street=123 number=123 user=673ffc41b0df5c00019b2a6f took=1.675621ms
  03:36:43.478 [user] ts=2024-11-22T03:36:43.47865477Z caller=middlewares.go:118 method=PostCard card=*****3321 user=673ffc41b0df5c00019b2a6f took=1.301979ms
All services, 30 seconds either side (sampled):
  03:36:14.032 [catalogue] ts=2024-11-22T03:36:14Z caller=logging.go:36 method=List tags= order=id pageNum=1 pageSize=10 result=9 err=null took=4.582756ms  (×62)
  03:36:14.896 [catalogue] ts=2024-11-22T03:36:14Z caller=logging.go:62 method=Get id=a0a4f044-b040-410d-8ead-4de0446aec7e sock=a0a4f044-b040-410d-8ead-4de0446aec7e err=null took=4.577722  (×53)
  03:36:14.990 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"673ffc25b0df5c00019b2a24\",\"_links\":{\"  (×59)
  03:36:15.016 [queue-master] 2024-11-22 03:36:15.016 INFO 6 --- [ool-6-thread-24] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×135)
  03:36:15.119 [front-end] Order response: {"id":"673ffc2fd94b9000069b4634","customerId":"673ffc1cb0df5c00019b2a01","customer":{"id":null,"firstName":"qZkcGcTWaVPxjY","lastName":"qZkcGcTW
  03:36:15.855 [front-end] Carts merged.  (×64)
  03:36:17.098 [carts] 2024-11-22 03:36:17.098 INFO [carts,697a3b0f31bc3d8f,3eebb932f0d93922,false] 7 --- [p-nio-80-exec-1] w.w.s.cart.controllers.CartsController : Merge carts reques  (×30)
  03:36:19.273 [front-end] Order response: {"id":"673ffc33d94b9000069b4638","customerId":"673ffc1ab0df5c00019b29fb","customer":{"id":null,"firstName":"UWAmo","lastName":"UWAmo","username"
  03:36:21.849 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×5)
  03:36:23.109 [front-end] Received response: "{\"firstName\":\"uvMTxIVdMmuCLX\",\"lastName\":\"uvMTxIVdMmuCLX\",\"username\":\"uvMTxIVdMmuCLX\",\"id\":\"673ffc19b0df5c00019b29fa\",\"_lin
  03:36:25.468 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×7)
  03:36:28.759 [front-end] Received response: "{\"firstName\":\"TzbTYFIna\",\"lastName\":\"TzbTYFIna\",\"username\":\"TzbTYFIna\",\"id\":\"673ffc23b0df5c00019b2a12\",\"_links\":{\"address
  03:36:32.044 [front-end] Received response: "{\"firstName\":\"bgjkfAfrLnOixr\",\"lastName\":\"bgjkfAfrLnOixr\",\"username\":\"bgjkfAfrLnOixr\",\"id\":\"673ffc24b0df5c00019b2a1e\",\"_lin
  03:36:35.674 [front-end] Received response: "{\"firstName\":\"POxhkiv\",\"lastName\":\"POxhkiv\",\"username\":\"POxhkiv\",\"id\":\"673ffc34b0df5c00019b2a40\",\"_links\":{\"addresses\":{
  03:36:37.251 [user] ts=2024-11-22T03:36:37.25125601Z caller=middlewares.go:46 method=Register username=bqtPj email=bqtPj@gmail.com took=960.499µs
  03:36:39.911 [front-end] Order response: {"id":"673ffc47d94b9000069b4646","customerId":"673ffc33b0df5c00019b2a3e","customer":{"id":null,"firstName":"MabmetW","lastName":"MabmetW","usern
  03:36:41.956 [front-end] Order response: {"id":"673ffc49d94b9000069b4649","customerId":"673ffc2db0df5c00019b2a32","customer":{"id":null,"firstName":"MRYnLbahhGnKX","lastName":"MRYnLbahh
  03:36:43.889 [user] ts=2024-11-22T03:36:43.889204304Z caller=middlewares.go:46 method=Register username=vNYfBsZi email=vNYfBsZi@gmail.com took=1.023343ms
  03:36:45.136 [front-end] Posting Customer: {"username":"IKMNbYvcvF","password":"VfNAIx","email":"IKMNbYvcvF@gmail.com","firstName":"IKMNbYvcvF","lastName":"IKMNbYvcvF"}
  03:36:48.600 [front-end] Received response: "{\"firstName\":\"PLzvZIoTqnQFHn\",\"lastName\":\"PLzvZIoTqnQFHn\",\"username\":\"PLzvZIoTqnQFHn\",\"id\":\"673ffc35b0df5c00019b2a42\",\"_lin
  03:36:50.922 [front-end] Posting Customer: {"username":"lVAux","password":"KfZcRpZyq","email":"lVAux@gmail.com","firstName":"lVAux","lastName":"lVAux"}
  03:36:52.146 [front-end] Received response: "{\"firstName\":\"tuuSStJZIKgZfMH\",\"lastName\":\"tuuSStJZIKgZfMH\",\"username\":\"tuuSStJZIKgZfMH\",\"id\":\"673ffc46b0df5c00019b2a87\",\"_
  03:36:54.560 [front-end] Posting Customer: {"username":"bbOrwKQpCK","password":"xdSeZQhYcY","email":"bbOrwKQpCK@gmail.com","firstName":"bbOrwKQpCK","lastName":"bbOrwKQpCK"}
  03:36:56.518 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc58d94b9000069b465c","customerId":"673ffc45b0df5c00019b2a7d","customer":{"id":null,"firstName":"bqtPj","las
  03:37:00.344 [front-end] Order response: {"id":"673ffc5cd94b9000069b465f","customerId":"673ffc45b0df5c00019b2a82","customer":{"id":null,"firstName":"dpgTbLjv","lastName":"dpgTbLjv","use
  03:37:05.142 [front-end] Received response: "{\"firstName\":\"vNYfBsZi\",\"lastName\":\"vNYfBsZi\",\"username\":\"vNYfBsZi\",\"id\":\"673ffc4bb0df5c00019b2a92\",\"_links\":{\"addresses\
  03:37:07.334 [front-end] Order response: {"id":"673ffc63d94b9000069b4664","customerId":"673ffc55b0df5c00019b2aae","customer":{"id":null,"firstName":"AObUYqBlFGRlcO","lastName":"AObUYqBl
  03:37:10.262 [front-end] Order response: {"statusCode":201,"body":{"id":"673ffc66d94b9000069b4666","customerId":"673ffc4fb0df5c00019b2aa0","customer":{"id":null,"firstName":"GKmDyaqen",
  03:37:12.973 [user] ts=2024-11-22T03:37:12.973421978Z caller=middlewares.go:46 method=Register username=MryyscIog email=MryyscIog@gmail.com took=896.178µs

## p0134
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service shippingservice, 2024-11-18T05:25:50.673Z
```
{"timestamp":1731907550673268000,"container_name":"shippingservice","pod_name":"shippingservice-547ddf469c-vjbwz","node_name":"ip-192-168-50-98.ap-southeast-2.compute.internal","message":"[GetQuote] received request"}
```
Same service, the 2 minutes before (oldest first):
  05:25:45.367 [shippingservice] [GetQuote] received request  (×8)
  05:25:45.367 [shippingservice] [GetQuote] completed request  (×8)
  05:25:46.753 [shippingservice] [ShipOrder] received request  (×2)
  05:25:46.753 [shippingservice] [ShipOrder] completed request  (×2)
All services, 30 seconds either side (sampled):
  05:25:20.673 [frontend] failed to retrieve ads  (×188)
  05:25:20.992 [frontend] serving product page  (×147)
  05:25:21.007 [currencyservice] conversion request successful  (×792)
  05:25:21.025 [frontend] adding to cart  (×34)
  05:25:21.066 [shippingservice] [GetQuote] received request  (×69)
  05:25:25.039 [frontend] home  (×40)
  05:25:32.555 [recommendationservice] [Recv ListRecommendations] product_ids=['66VCHSJNUP', '6E92ZMYYFZ', '2ZYFJ3GM2N']  (×5)
  05:25:46.716 [checkoutservice] [PlaceOrder] user_id="58e83383-a5c9-4a61-9291-cb65bc2a888b" user_currency="EUR"  (×4)
  05:25:46.752 [checkoutservice] payment went through (transaction_id: 0794a115-bc7c-4925-bcc1-ac98b35ab5c3)  (×9)
  05:25:46.756 [cartservice] EmptyCartAsync called with userId=58e83383-a5c9-4a61-9291-cb65bc2a888b  (×9)
  05:25:46.765 [frontend] order placed  (×9)
  05:25:48.997 [paymentservice] Transaction processed: visa ending 4832 Amount: CAD877.691633787  (×3)
  05:25:53.413 [emailservice] A request to send order confirmation email to ashley15@example.org has been received.
  05:25:55.268 [emailservice] A request to send order confirmation email to sweeneybonnie@example.org has been received.
  05:25:56.038 [redis] 1:M 18 Nov 2024 05:25:56.038 * Background saving started by pid 51
  05:25:56.139 [redis] 1:M 18 Nov 2024 05:25:56.139 * Background saving terminated with success
  05:26:11.888 [emailservice] A request to send order confirmation email to fjordan@example.org has been received.
  05:26:14.061 [emailservice] A request to send order confirmation email to wardpenny@example.org has been received.
  05:26:14.077 [paymentservice] Transaction processed: visa ending 6694 Amount: TRY1256.200078756
  05:26:16.520 [checkoutservice] [PlaceOrder] user_id="0ae6d9b6-4e7f-4d38-a0eb-042389dcac30" user_currency="JPY"
  05:26:16.567 [emailservice] A request to send order confirmation email to davisjoseph@example.org has been received.

## p0137
System: Online Boutique: an e-commerce demo of about ten microservices (frontend, cart, checkout, payment, currency, email, ads, recommendations, shipping)
Event: service cartservice, 2024-11-18T05:31:31.672Z
```
{"timestamp":1731907891672593000,"container_name":"cartservice","pod_name":"cartservice-68c55747f8-m2ddm","node_name":"ip-192-168-79-115.ap-southeast-2.compute.internal","message":"AddItemAsync called with userId=0ae6d9b6-4e7f-4d38-a0eb-042389dcac30, productId=1YMWWN1N4O, quantity=6"}
```
Same service, the 2 minutes before (oldest first):
  05:31:28.051 [cartservice] AddItemAsync called with userId=acc735c5-72d0-48e6-b237-46a63eac4c4d, productId=L9ECAV7KIM, quantity=5  (×3)
  05:31:28.067 [cartservice] GetCartAsync called with userId=acc735c5-72d0-48e6-b237-46a63eac4c4d  (×16)
  05:31:31.441 [cartservice] EmptyCartAsync called with userId=65f4eef7-6576-4be2-805b-c27cafa8ee53
All services, 30 seconds either side (sampled):
  05:31:12.113 [frontend] request started  (×255)
  05:31:12.116 [currencyservice] Getting supported currencies...  (×211)
  05:31:12.130 [currencyservice] conversion request successful  (×585)
  05:31:12.168 [adservice] received ad request (context_words=[])  (×29)
  05:31:12.225 [frontend] setting currency  (×19)
  05:31:13.241 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '1YMWWN1N4O', '0PUK6V6EV0', '9SIQT8TOJO', 'L9ECAV7KIM']  (×173)
  05:31:13.958 [adservice] received ad request (context_words=[kitchen])  (×44)
  05:31:15.546 [adservice] received ad request (context_words=[decor, home])  (×13)
  05:31:16.969 [frontend] adding to cart  (×25)
  05:31:16.983 [frontend] view user cart  (×49)
  05:31:17.008 [shippingservice] [GetQuote] completed request  (×56)
  05:31:17.030 [checkoutservice] [PlaceOrder] user_id="79b6fc41-70d8-42ea-9810-1ae877ff7add" user_currency="EUR"  (×2)
  05:31:17.056 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"EUR","units":"139","nanos":655019905},"credit_card":{"credit_card_number":"49231259390927  (×2)
  05:31:17.058 [checkoutservice] payment went through (transaction_id: f193f55b-9ec1-41b5-abef-e610b8b840af)  (×7)
  05:31:17.059 [shippingservice] [ShipOrder] completed request  (×7)
  05:31:17.070 [emailservice] A request to send order confirmation email to curtis26@example.org has been received.
  05:31:17.072 [frontend] order placed  (×7)
  05:31:17.380 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"JPY","units":"29721","nanos":50862865},"credit_card":{"credit_card_number":"4397529817152  (×2)
  05:31:17.393 [emailservice] A request to send order confirmation email to beckrobert@example.net has been received.
  05:31:18.456 [recommendationservice] [Recv ListRecommendations] product_ids=['2ZYFJ3GM2N', '1YMWWN1N4O']  (×2)
  05:31:18.597 [paymentservice] PaymentService#Charge invoked with request {"amount":{"currency_code":"USD","units":"2702","nanos":280000000},"credit_card":{"credit_card_number":"4761344760685
  05:31:18.613 [emailservice] A request to send order confirmation email to etate@example.com has been received.
  05:31:20.895 [recommendationservice] [Recv ListRecommendations] product_ids=['LS4PSXUNUM', '66VCHSJNUP', '1YMWWN1N4O']  (×3)
  05:31:31.384 [checkoutservice] [PlaceOrder] user_id="65f4eef7-6576-4be2-805b-c27cafa8ee53" user_currency="TRY"  (×2)
  05:31:31.434 [paymentservice] Transaction processed: visa ending 2674 Amount: TRY7986.543787768  (×2)
  05:31:31.447 [checkoutservice] order confirmation email sent to "ncoleman@example.com"
  05:31:34.240 [checkoutservice] order confirmation email sent to "stephanieadams@example.org"
  05:31:37.485 [checkoutservice] order confirmation email sent to "jeffrey07@example.org"
  05:31:46.696 [checkoutservice] order confirmation email sent to "duranalexander@example.net"

## p0600
System: Train Ticket: a railway booking system of many microservices (auth, route, order, travel, seat, payment, ...)
Event: service ts-travel2-service, 2024-12-07T20:03:30.684Z
```
{"timestamp":1733601810684879000,"container_name":"ts-travel2-service","pod_name":"ts-travel2-service-b48dd94b8-f7tv2","node_name":"ip-192-168-38-0.ap-southeast-2.compute.internal","message":"2024-12-07 20:03:30.684  INFO 1 --- [io-16346-exec-2] travel2.service.Travel2ServiceImpl       : [Travel Service][Get Route By Id] Route ID：d693a2c5-ef87-4a3c-bef8-600b43f62c68"}
```
Same service, the 2 minutes before (oldest first):
  20:03:30.443 [ts-travel2-service] 2024-12-07 20:03:30.443 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.
  20:03:30.484 [ts-travel2-service] 2024-12-07 20:03:30.484 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int
  20:03:30.484 [ts-travel2-service] 2024-12-07 20:03:30.484 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [TravelService][getTickets] route: d693a2c5-ef87-4a3c-bef8-600b43f62c6
  20:03:30.500 [ts-travel2-service] 2024-12-07 20:03:30.500 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Train Service] calculate time：475 time: Sat May 04 07:00:52 GMT 2013  (×2)
  20:03:30.500 [ts-travel2-service] 2024-12-07 20:03:30.500 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：20eb7122-3a11-423f-b10a-be0  (×3)
  20:03:30.508 [ts-travel2-service] 2024-12-07 20:03:30.508 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Ticket info is: Response(status=1, msg=Success, data=TravelResult(stat
  20:03:30.510 [ts-travel2-service] 2024-12-07 20:03:30.510 INFO 1 --- [io-16346-exec-7] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×3)
  20:03:30.518 [ts-travel2-service] 2024-12-07 20:03:30.518 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Order other Ticket info is: Response(status=1, msg=Success, data=Trave
  20:03:30.567 [ts-travel2-service] 2024-12-07 20:03:30.566 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Seat request To String: Seat(travelDate=Sat Dec 07 00:00:00 GMT 2024,   (×2)
  20:03:30.581 [ts-travel2-service] 2024-12-07 20:03:30.580 INFO 1 --- [io-16346-exec-5] travel2.controller.Travel2Controller : [Get Route By Trip ID] TripId: Z1236  (×2)
  20:03:30.591 [ts-travel2-service] 2024-12-07 20:03:30.591 INFO 1 --- [io-16346-exec-5] travel2.service.Travel2ServiceImpl : [Get Route By Trip ID] Success
  20:03:30.634 [ts-travel2-service] 2024-12-07 20:03:30.634 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int
  20:03:30.679 [ts-travel2-service] 2024-12-07 20:03:30.678 INFO 1 --- [io-16346-exec-1] travel2.controller.Travel2Controller : [Travel Service] Query TripResponse
All services, 30 seconds either side (sampled):
  20:03:00.960 [ts-auth-service] 2024-12-07 20:03:00.960 INFO 1 --- [io-12340-exec-6] auth.service.impl.TokenServiceImpl : LOGIN USER :fdse_microservice __ 111111 __ null  (×14)
  20:03:01.284 [ts-travel2-service] 2024-12-07 20:03:01.284 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : [Travel Other Service][Get Route By Id] Success.  (×126)
  20:03:01.402 [ts-basic-service] 2024-12-07 20:03:01.402 INFO 1 --- [io-15680-exec-7] f.microservice.service.BasicServiceImpl : startingPlaceId : shanghaiendPlaceId : nanjing  (×4)
  20:03:01.506 [ts-seat-service] 2024-12-07 20:03:01.505 INFO 1 --- [io-18898-exec-2] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with other capital  (×25)
  20:03:01.568 [ts-travel2-service] 2024-12-07 20:03:01.568 INFO 1 --- [io-16346-exec-8] travel2.service.Travel2ServiceImpl : Get Rest tickets num is: Response(status=1, msg=Get Left Ticket of Int  (×24)
  20:03:01.707 [ts-travel-service] 2024-12-07 20:03:01.706 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Routes Response is : Response(status=1, msg=Success, data={id=92708982-7  (×19)
  20:03:01.801 [ts-travel-service] 2024-12-07 20:03:01.801 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Order info is: Response(status=1, msg=Success, data=SoldTicket(travelDat  (×14)
  20:03:02.291 [ts-travel-service] 2024-12-07 20:03:02.290 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : [Train Service] calculate time：48 time: Sat May 04 01:48:00 GMT 2013  (×18)
  20:03:02.962 [ts-travel-service] 2024-12-07 20:03:02.962 INFO 1 --- [io-12346-exec-2] travel.service.TravelServiceImpl : Route is: Route{id='084837bb-53c8-4438-87c8-0321a4d09917', stations=[suz  (×16)
  20:03:03.474 [ts-seat-service] 2024-12-07 20:03:03.474 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] The request seat type is economyClass   (×4)
  20:03:06.801 [ts-admin-basic-info-service] 2024-12-07 20:03:06.800 INFO 1 --- [io-18767-exec-2] a.controller.AdminBasicInfoController : [Admin Basic Info Service][Find All Price by admin   (×8)
  20:03:09.566 [ts-basic-service] 2024-12-07 20:03:09.566 INFO 1 --- [io-15680-exec-6] f.microservice.service.BasicServiceImpl : [Basic Information Service][Get Route By Id] Route ID：d693a2c5-ef  (×9)
  20:03:11.244 [ts-seat-service] 2024-12-07 20:03:11.243 INFO 1 --- [io-18898-exec-5] seat.service.SeatServiceImpl : [SeatService getLeftTicketOfInterval] TrainNumber start with G|D D1345  (×8)
  20:03:11.686 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:03:11 +0800] "GET /api/v1/foodservice/foods/2021-07-14/Shang%20Hai/Su%20Zhou/D1345 HTTP/1.1" 200 5994 "-" "Mozilla/5.0 (Macintosh;  (×4)
  20:03:13.240 [ts-basic-service] 2024-12-07 20:03:13.240 INFO 1 --- [o-15680-exec-10] f.microservice.service.BasicServiceImpl : [Basic Information Service][Query Train Type] Train Type: ZhiDa
  20:03:13.587 [ts-preserve-service] 2024-12-07 20:03:13.587 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Other Service][Check Security] Checking....  (×2)
  20:03:13.925 [ts-security-service] 2024-12-07 20:03:13.925 INFO 1 --- [io-11188-exec-3] security.service.SecurityServiceImpl : [Security Service][Get Order Other Info For Security] Getting....  (×2)
  20:03:14.104 [ts-contacts-service] 2024-12-07 20:03:14.104 INFO 1 --- [io-12347-exec-7] contacts.controller.ContactsController : [ContactsService][VerifyLogin] Success.  (×2)
  20:03:14.953 [ts-travel2-service] 2024-12-07 20:03:14.953 INFO 1 --- [o-16346-exec-10] travel2.service.Travel2ServiceImpl : [Travel Service][Get Route By Id] Route ID：0b23bd3e-876a-4af3-b920-c50  (×17)
  20:03:15.429 [ts-preserve-service] 2024-12-07 20:03:15.429 INFO 1 --- [io-14568-exec-1] preserve.service.PreserveServiceImpl : [Preserve Other Service][Get Station Name]  (×2)
  20:03:15.657 [ts-order-service] 2024-12-07 20:03:15.657 INFO 1 --- [io-12031-exec-1] order.controller.OrderController : [Order Service][Create Order] Create Order form shanghai ---> suzhou at 
  20:03:16.361 [ts-assurance-service] 2024-12-07 20:03:16.360 INFO 1 --- [io-18888-exec-5] assurance.service.AssuranceServiceImpl : [Assurance-Add&Delete-Service][AddAssurance] Success.
  20:03:16.596 [ts-ui-dashboard] 127.0.0.1 - - [08/Dec/2024:04:03:16 +0800] "POST /api/v1/preserveservice/preserve HTTP/1.1" 200 57 "-" "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWeb
  20:03:18.449 [ts-consign-service] 2024-12-07 20:03:18.449 INFO 1 --- [io-16111-exec-4] consign.service.ConsignServiceImpl : The target date is 2024-12-07 20:03:18
  20:03:28.372 [ts-config-mongo] {"t":{"$date":"2024-12-07T20:03:28.371+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360180
  20:03:30.712 [ts-seat-service] 2024-12-07 20:03:30.712 INFO 1 --- [o-18898-exec-10] seat.service.SeatServiceImpl : Get Order tickets result is : <200,Response(status=0, msg=Seat is Null., dat  (×3)
  20:03:31.469 [ts-food-map-mongo] {"t":{"$date":"2024-12-07T20:03:31.469+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360181
  20:03:42.749 [ts-contacts-mongo] {"t":{"$date":"2024-12-07T20:03:42.749+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173360182
  20:03:44.353 [ts-order-other-service] 2024-12-07 20:03:44.353 INFO 1 --- [io-12032-exec-3] other.service.OrderOtherServiceImpl : [Order Other Service][Query Order][Step 1] Get Orders Number of Accou
  20:03:51.866 [ts-admin-travel-service] 2024-12-07 20:03:51.866 INFO 1 --- [o-16114-exec-10] a.service.AdminTravelServiceImpl : [Admin Travel Service][Get All Travels]

## p0337
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-22T03:21:19.192Z
```
{"timestamp":1732245679192158700,"container_name":"carts","pod_name":"carts-78d749cf8c-85vxn","node_name":"ip-192-168-83-253.ap-southeast-2.compute.internal","message":"java.util.ConcurrentModificationException: null\n\tat java.util.HashMap$HashIterator.nextNode(HashMap.java:1437) ~[na:1.8.0_131]\n\tat java.util.HashMap$KeyIterator.next(HashMap.java:1461) ~[na:1.8.0_131]\n\tat works.weave.socks.cart.middleware.HTTPMonitoringInterceptor.getMatchingURLPattern(HTTPMonitoringInterceptor.java:74) ~[classes!/:1.4.4.RELEASE]\n\tat works.weave.socks.cart.middleware.HTTPMonitorin…"}
```
Same service, the 2 minutes before (oldest first):
  03:21:18.384 [carts] 2024-11-22 03:21:18.383 INFO [carts,fb7913950d676f18,6e117eba14b3663e,false] 7 --- [-nio-80-exec-11] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{reposi  (×19)
  03:21:19.192 [carts] 2024-11-22 03:21:19.191 ERROR [carts,,,] 7 --- [-nio-80-exec-21] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in co
All services, 30 seconds either side (sampled):
  03:20:49.209 [front-end] User cart deleted with status: 503  (×62)
  03:20:49.812 [user] ts=2024-11-22T03:20:49.812751686Z caller=middlewares.go:46 method=Register username=YwTYsSUGcmNRsJY email=YwTYsSUGcmNRsJY@gmail.com took=1.047817ms  (×25)
  03:20:51.499 [user] ts=2024-11-22T03:20:51.499248244Z caller=middlewares.go:75 method=GetUsers id=673ff880b0df5c00019b1f04 result=1 took=993.546µs  (×170)
  03:20:51.552 [front-end] POST /addresses 200 - ms - -  (×61)
  03:20:51.970 [front-end] Posting Customer: {"username":"nPklGOsvzh","password":"YuEpn","email":"nPklGOsvzh@gmail.com","firstName":"nPklGOsvzh","lastName":"nPklGOsvzh"}
  03:20:54.954 [orders] 2024-11-22 03:20:54.954 ERROR [orders,,,] 6 --- [-nio-80-exec-15] o.a.c.c.C.[.[.[/].[dispatcherServlet] : Servlet.service() for servlet [dispatcherServlet] in c  (×8)
  03:20:59.100 [user] ts=2024-11-22T03:20:59.100482586Z caller=middlewares.go:46 method=Register username=mLiQP email=mLiQP@gmail.com took=1.31638ms
  03:20:59.690 [carts] 2024-11-22 03:20:59.690 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}],methods=[OPTIONS],produces=[application/
  03:20:59.789 [carts] 2024-11-22 03:20:59.789 INFO [carts,,,] 7 --- [ main] o.s.d.r.w.RepositoryRestHandlerMapping : Mapped "{[/{repository}/search/{search}],methods=[HEAD],produces=
  03:21:02.119 [front-end] Posting Customer: {"username":"gKGbBfBuFal","password":"jTPEzN","email":"gKGbBfBuFal@gmail.com","firstName":"gKGbBfBuFal","lastName":"gKGbBfBuFal"}
  03:21:03.087 [carts] 2024-11-22 03:21:03.087 INFO [carts,,,] 7 --- [ main] o.s.b.a.e.mvc.EndpointHandlerMapping : Mapped "{[/mappings || /mappings.json],methods=[GET],produces=[appl
  03:21:03.503 [front-end] Posting Customer: {"username":"gxEQQKdgPqad","password":"JuVTj","email":"gxEQQKdgPqad@gmail.com","firstName":"gxEQQKdgPqad","lastName":"gxEQQKdgPqad"}
  03:21:08.309 [front-end] Posting Customer: {"username":"MszyyqkjNcAvcB","password":"ooieHc","email":"MszyyqkjNcAvcB@gmail.com","firstName":"MszyyqkjNcAvcB","lastName":"MszyyqkjNcAvcB"}
  03:21:09.807 [front-end] Received response: "{\"firstName\":\"URVWiLVbByzZ\",\"lastName\":\"URVWiLVbByzZ\",\"username\":\"URVWiLVbByzZ\",\"id\":\"673ff889b0df5c00019b1f1d\",\"_links\":{
  03:21:13.089 [carts] 2024-11-22 03:21:13.089 INFO [carts,,,] 7 --- [ main] works.weave.socks.cart.CartApplication : Started CartApplication in 139.303 seconds (JVM running for 144.3
  03:21:15.774 [front-end] Posting Customer: {"username":"eSafJJOuc","password":"LrXrl","email":"eSafJJOuc@gmail.com","firstName":"eSafJJOuc","lastName":"eSafJJOuc"}
  03:21:18.113 [orders] java.util.concurrent.TimeoutException: null at java.util.concurrent.FutureTask.get(FutureTask.java:205) ~[na:1.8.0_131] at works.weave.socks.orders.controllers.  (×2)
  03:21:18.613 [queue-master] 2024-11-22 03:21:18.612 INFO 6 --- [ool-6-thread-44] o.apache.http.impl.execchain.RetryExec : I/O exception (org.newsclub.net.unix.AFUNIXSocketException) caught  (×72)
  03:21:18.854 [front-end] Received response: "{\"firstName\":\"sQAAadzpZlKDfq\",\"lastName\":\"sQAAadzpZlKDfq\",\"username\":\"sQAAadzpZlKDfq\",\"id\":\"673ff89eb0df5c00019b1f58\",\"_lin
  03:21:19.502 [front-end] Order response: {"id":"673ff8afd94b9000069b4392","customerId":"673ff89eb0df5c00019b1f58","customer":{"id":null,"firstName":"sQAAadzpZlKDfq","lastName":"sQAAadzp
  03:21:20.407 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8b0d94b9000069b4396","customerId":"673ff893b0df5c00019b1f31","customer":{"id":null,"firstName":"nPklGOsvzh"
  03:21:21.636 [user] ts=2024-11-22T03:21:21.636419176Z caller=middlewares.go:46 method=Register username=XaQgsgBGh email=XaQgsgBGh@gmail.com took=1.069756ms
  03:21:26.558 [user] ts=2024-11-22T03:21:26.558433542Z caller=middlewares.go:46 method=Register username=ZaeWmQ email=ZaeWmQ@gmail.com took=1.00428ms
  03:21:29.663 [user] ts=2024-11-22T03:21:29.663548471Z caller=middlewares.go:46 method=Register username=QoPcWQ email=QoPcWQ@gmail.com took=1.079037ms
  03:21:34.256 [front-end] Order response: {"statusCode":201,"body":{"id":"673ff8bed94b9000069b439f","customerId":"673ff8a8b0df5c00019b1f85","customer":{"id":null,"firstName":"yXmVwShR","
  03:21:36.190 [front-end] Posting Customer: {"username":"DXXEAuEZfGxuPq","password":"zJmqdnrGmo","email":"DXXEAuEZfGxuPq@gmail.com","firstName":"DXXEAuEZfGxuPq","lastName":"DXXEAuEZfGxuP
  03:21:38.477 [user] ts=2024-11-22T03:21:38.477181232Z caller=middlewares.go:46 method=Register username=otqrpqrI email=otqrpqrI@gmail.com took=1.018878ms
  03:21:42.175 [front-end] Posting Customer: {"username":"aQnXDQax","password":"zSTTcvaI","email":"aQnXDQax@gmail.com","firstName":"aQnXDQax","lastName":"aQnXDQax"}
  03:21:44.658 [front-end] Posting Customer: {"username":"uJQuaCc","password":"YlkPMNT","email":"uJQuaCc@gmail.com","firstName":"uJQuaCc","lastName":"uJQuaCc"}

## p0044
System: GAIA MicroSS: a QR-code login system of microservices (webservice, mobservice, logservice, dbservice, redisservice), two instances each
Event: service dbservice1, 2021-08-13T08:02:36.707Z
```
{"service":"dbservice1","message":"2021-08-13 08:02:36,707 | INFO | 0.0.0.4 | dbservice1 | permission_operate.py -> permission_operation -> 35 | c9419b28c4376d7d | the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387"}
```
Same service, the 2 minutes before (oldest first):
  08:02:30.955 [dbservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×5)
  08:02:30.956 [dbservice1] INFO now call service:redisservice2, inst:http://0.0.0.2:9387 as a downstream service  (×5)
  08:02:30.989 [dbservice1] INFO query = select passwards from username_table where user_name='QClFzynH'  (×5)
  08:02:31.065 [dbservice1] INFO c09fe606-fbc9-11eb-bc15-0242ac110003-QClFzynH-qP%6L:4dAwRi token generate success token=MTYyODgxMjk1MS4wNjUwMDcyOmMwOWZlNjA2LWZiYzktMTFlYi1iYzE1LTAyNDJhYzE
  08:02:32.522 [dbservice1] INFO c16de966-fbc9-11eb-9ea6-0242ac110003-xhrnIDOM-BZQ+M*L^EHNg token generate success token=MTYyODgxMjk1Mi41MjI1Mjk0OmMxNmRlOTY2LWZiYzktMTFlYi05ZWE2LTAyNDJhYzE
  08:02:34.278 [dbservice1] INFO c28ce234-fbc9-11eb-b842-0242ac110004-wcXjOMum-+g}IH=z_BQ!. token generate success token=MTYyODgxMjk1NC4yNzgzOTk1OmMyOGNlMjM0LWZiYzktMTFlYi1iODQyLTAyNDJhYzE
  08:02:35.420 [dbservice1] INFO c32fa884-fbc9-11eb-b7fe-0242ac110003-xwrmCNQd-VxKpC&#$T?.S token generate success token=MTYyODgxMjk1NS40MjA0MjU6YzMyZmE4ODQtZmJjOS0xMWViLWI3ZmUtMDI0MmFjMTE
  08:02:35.874 [dbservice1] INFO c3801f44-fbc9-11eb-8918-0242ac110003-VxubFBRX-Qgr73J_$>S}{ token generate success token=MTYyODgxMjk1NS44NzM4MDA4OmMzODAxZjQ0LWZiYzktMTFlYi04OTE4LTAyNDJhYzE
All services, 30 seconds either side (sampled):
  08:02:06.720 [redisservice1] INFO redis write success  (×56)
  08:02:06.855 [logservice1] INFO the list of all available services are logservice2: http://0.0.0.2:9385  (×28)
  08:02:06.948 [dbservice2] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×29)
  08:02:09.079 [webservice1] INFO the list of all available services are redisservice1: http://0.0.0.1:9386, redisservice2: http://0.0.0.2:9387  (×30)
  08:02:09.263 [webservice1] INFO call service:mobservice1, inst:http://0.0.0.1:9382 as a downstream service  (×30)
  08:02:09.371 [mobservice1] INFO request http://0.0.0.2:9387/set_key_value_into_redis and param={'keys': 'b3ef6ee0-fbc9-11eb-9802-0242ac110003', 'value': 'vOcCSRZA'}  (×24)
  08:02:10.835 [mobservice2] INFO request http://0.0.0.1:9386/get_value_from_redis and param={'keys': 'ae4829b4-fbc9-11eb-9224-0242ac110004'}  (×40)
  08:02:11.039 [logservice2] ERROR uuid expired, invalid phone request
  08:02:11.748 [dbservice1] INFO query = select passwards from username_table where user_name='ItWBCNrc'  (×34)
  08:02:11.904 [webservice2] INFO uuid: b59333ee-fbc9-11eb-94fd-0242ac110004 write redis successfully  (×35)
  08:02:12.370 [logservice2] INFO the list of all available services are logservice1: http://0.0.0.3:9384  (×36)
  08:02:13.084 [mobservice1] INFO info b61ea758-fbc9-11eb-baa1-0242ac110004:DjXaKYNR write success
  08:02:15.058 [mobservice2] INFO info b74b0e82-fbc9-11eb-a6be-0242ac110004:jnAxEKot write success
  08:02:17.719 [mobservice2] INFO info b8e86244-fbc9-11eb-b7ef-0242ac110003:HkLmPgZU write success
  08:02:20.404 [dbservice1] INFO ba4716d0-fbc9-11eb-b839-0242ac110004-ckfeNPTM-WcHR.sT#4DEu token generate success token=MTYyODgxMjk0MC40MDQwNjU4OmJhNDcxNmQwLWZiYzktMTFlYi1iODM5LTAyNDJhYzE
  08:02:22.041 [dbservice1] ERROR (pymysql.err.OperationalError) (1054, "Unknown column 'system_data_time' in 'field list'")[SQL: select service_name, system_data_time, system_cpu_utilizat
  08:02:24.741 [dbservice1] INFO bca9a29e-fbc9-11eb-98f3-0242ac110003-qepNbChc-fH.oSuxnyI{B token generate success token=MTYyODgxMjk0NC43NDA4Mjk1OmJjYTlhMjllLWZiYzktMTFlYi05OGYzLTAyNDJhYzE
  08:02:26.685 [dbservice1] INFO bdf9ef5a-fbc9-11eb-8a02-0242ac110004-GZqDYHLc--PqE2macry.D token generate success token=MTYyODgxMjk0Ni42ODU2MDU6YmRmOWVmNWEtZmJjOS0xMWViLThhMDItMDI0MmFjMTE
  08:02:29.348 [mobservice1] INFO info bfb718fe-fbc9-11eb-a1a3-0242ac110004:zepqgvua write success
  08:02:32.389 [mobservice1] INFO info c18d42fc-fbc9-11eb-8d78-0242ac110003:gWaJIfYM write success
  08:02:35.022 [mobservice1] INFO info c32fa884-fbc9-11eb-b7fe-0242ac110003:xwrmCNQd write success
  08:02:37.321 [mobservice1] INFO info c491cb1c-fbc9-11eb-a95f-0242ac110004:GOhWXRIV write success
  08:02:46.319 [mobservice1] INFO info c9f2824a-fbc9-11eb-a880-0242ac110004:sJSHvCwD write success
  08:02:49.608 [mobservice2] INFO info cbeb3682-fbc9-11eb-b5a8-0242ac110003:aejQpHvi write success
  08:02:55.117 [dbservice1] INFO ceef44b8-fbc9-11eb-9f71-0242ac110003-BxzuqLwT-.Fbo:+=87Kmn token generate success token=MTYyODgxMjk3NS4xMTcwNjQ3OmNlZWY0NGI4LWZiYzktMTFlYi05ZjcxLTAyNDJhYzE
  08:03:02.366 [dbservice1] INFO d34b5bd2-fbc9-11eb-b4df-0242ac110004-SDgLpeFn-kr3n*Mg_:JQ4 token generate success token=MTYyODgxMjk4Mi4zNjY1NzQ4OmQzNGI1YmQyLWZiYzktMTFlYi1iNGRmLTAyNDJhYzE
  08:03:04.440 [mobservice1] INFO info d4bb08be-fbc9-11eb-8159-0242ac110003:sjignBZH write success
  08:03:06.379 [dbservice1] INFO d59993f4-fbc9-11eb-9b83-0242ac110004-bsnOITed-e}X9/n3_NGC: token generate success token=MTYyODgxMjk4Ni4zNzg5Njc4OmQ1OTk5M2Y0LWZiYzktMTFlYi05YjgzLTAyNDJhYzE

## p0534
System: Sock Shop: an e-commerce demo of microservices (front-end, carts, orders, payment, user, catalogue, shipping)
Event: service carts, 2024-11-23T11:03:58.607Z
```
{"timestamp":1732359838607489300,"container_name":"carts","pod_name":"carts-78d749cf8c-ftxr8","node_name":"ip-192-168-6-79.ap-southeast-2.compute.internal","message":"2024-11-23 11:03:58.607  INFO [carts,8ce12dee52e3d13e,2023fb7ee4fcd7bb,false] 7 --- [p-nio-80-exec-3] w.w.s.cart.controllers.ItemsController   : Did not find item. Creating item for user: 6741b697a437380001df54d4, Item{id='6741b69ef074bf000700589b', itemId='3395a43e-2d88-40de-b95f-e00e1502085b', quantity=1, unitPrice=18.0}"}
```
Same service, the 2 minutes before (oldest first):
  11:03:53.798 [carts] 2024-11-23 11:03:53.797 INFO [carts,69950acf3df27cad,476f5ba2f1b463a1,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.CartsController : Merge carts reques  (×8)
  11:03:54.342 [carts] 2024-11-23 11:03:54.342 INFO [carts,33a892a7cfc7bf8e,21e854d413904219,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×4)
  11:03:56.332 [carts] 2024-11-23 11:03:56.331 INFO [carts,ba4205b9d1c84368,dce3f30ebe66fb5f,false] 7 --- [-nio-80-exec-17] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  11:03:56.341 [carts] 2024-11-23 11:03:56.340 INFO [carts,ba4205b9d1c84368,dce3f30ebe66fb5f,false] 7 --- [-nio-80-exec-17] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
  11:03:56.382 [carts] 2024-11-23 11:03:56.381 INFO [carts,8ec7ce6c89d752ee,d87e8f54055f3ce3,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.ItemsController : Did not find item.  (×2)
  11:03:56.390 [carts] 2024-11-23 11:03:56.390 INFO [carts,8ec7ce6c89d752ee,d87e8f54055f3ce3,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.cart.CartContentsResource : Adding for user: Car  (×2)
All services, 30 seconds either side (sampled):
  11:03:28.850 [user] ts=2024-11-23T11:03:28.850586259Z caller=middlewares.go:157 method=Health result=2 took=2.728746ms  (×40)
  11:03:47.282 [front-end] Posting Customer: {"username":"efjgmmJtKv","password":"RMUFsiyY","email":"efjgmmJtKv@gmail.com","firstName":"efjgmmJtKv","lastName":"efjgmmJtKv"}
  11:03:47.302 [carts] 2024-11-23 11:03:47.301 INFO [carts,5a0a5bec5562a998,10d7f3b5bd52a0a9,false] 7 --- [-nio-80-exec-13] w.w.s.cart.controllers.CartsController : Merge carts reques  (×15)
  11:03:48.042 [front-end] Posting Customer: {"username":"NzdAqPAXT","password":"WSOhs","email":"NzdAqPAXT@gmail.com","firstName":"NzdAqPAXT","lastName":"NzdAqPAXT"}
  11:03:51.097 [user] ts=2024-11-23T11:03:51.097470932Z caller=middlewares.go:46 method=Register username=izuCR email=izuCR@gmail.com took=2.202784ms
  11:03:53.347 [front-end] Posting Address: {"number":"123","street":"123","city":"123","postcode":"123","country":"123","userID":"6741b693a437380001df54d0"}  (×21)
  11:03:53.375 [front-end] POST /cards 200 - ms - -  (×21)
  11:03:53.463 [catalogue] ts=2024-11-23T11:03:53Z caller=logging.go:62 method=Get id=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 sock=808a2de1-1aaa-4c25-a9b9-6612e8f29a38 err=null took=5.433436  (×20)
  11:03:53.523 [front-end] POST /cart 201 - ms - -  (×20)
  11:03:55.832 [front-end] Posting Customer: {"username":"BvVYVeMmWCoOHQZ","password":"XEqkLs","email":"BvVYVeMmWCoOHQZ@gmail.com","firstName":"BvVYVeMmWCoOHQZ","lastName":"BvVYVeMmWCoOHQ
  11:03:56.382 [carts] 2024-11-23 11:03:56.381 INFO [carts,8ec7ce6c89d752ee,d87e8f54055f3ce3,false] 7 --- [p-nio-80-exec-7] w.w.s.cart.controllers.ItemsController : Did not find item.  (×11)
  11:03:56.543 [front-end] Posting Customer: {"username":"YWOBdjLIWnSTg","password":"jTWvGWdK","email":"YWOBdjLIWnSTg@gmail.com","firstName":"YWOBdjLIWnSTg","lastName":"YWOBdjLIWnSTg"}
  11:03:57.772 [front-end] {"id":"zzz4f044-b040-410d-8ead-4de0446aec7e","name":"Classic","description":"Keep it simple.","imageUrl":["/catalogue/images/classic.jpg","/catalogue/images/cla  (×3)
  11:03:59.669 [front-end] Posting Customer: {"username":"imhZTN","password":"PxvCtnJ","email":"imhZTN@gmail.com","firstName":"imhZTN","lastName":"imhZTN"}
  11:04:00.291 [front-end] {"id":"d3588630-ad8e-49df-bbd7-3167f7efb246","name":"YouTube.sock","description":"We were not paid to sell this sock. It's just a bit geeky.","imageUrl":["/cata  (×2)
  11:04:01.454 [user] ts=2024-11-23T11:04:01.454479736Z caller=middlewares.go:46 method=Register username=zDIHdeVWu email=zDIHdeVWu@gmail.com took=2.48915ms
  11:04:03.984 [front-end] {"id":"510a0d7e-8e83-4193-b483-e27e09ddc34d","name":"SuperSport XL","description":"Ready for action. Engineers: be ready to smash that next bug! Be ready, with   (×2)
  11:04:06.542 [user] ts=2024-11-23T11:04:06.541921827Z caller=middlewares.go:75 method=GetUsers id=6741b693a437380001df54d0 result=1 took=1.972827ms  (×4)
  11:04:06.562 [front-end] Received response: "{\"_embedded\":{\"card\":[{\"longNum\":\"123123321\",\"expires\":\"1232\",\"ccv\":\"123\",\"id\":\"6741b699a437380001df54d8\",\"_links\":{\"
  11:04:06.577 [user] ts=2024-11-23T11:04:06.577774678Z caller=middlewares.go:134 method=GetCards id=6741b699a437380001df54d8 result=1 took=1.80299ms
  11:04:06.606 [queue-master] Received shipment task: 6741b693a437380001df54d0
  11:04:06.609 [front-end] Order response: {"statusCode":201,"headers":{"x-application-context":"orders:80","content-length":"0","date":"Sat, 23 Nov 2024 11:04:06 GMT","x-envoy-upstream-s
  11:04:06.643 [front-end] npm timing command:run-script Completed in 43497ms
  11:04:06.644 [front-end] npm notice Run `npm install -g npm@10.9.1` to update!
  11:04:27.042 [carts-db] {"t":{"$date":"2024-11-23T11:04:27.042+00:00"},"s":"I", "c":"STORAGE", "id":22430, "ctx":"Checkpointer","msg":"WiredTiger message","attr":{"message":"[173235986
